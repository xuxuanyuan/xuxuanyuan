"""Runtime diagnostics for optional numeric kernel backends."""

from __future__ import annotations

import importlib.util
import ctypes
import importlib.machinery
import json
from pathlib import Path
from types import ModuleType
from typing import Any

import numpy as np

from iroll.kernels.backend import (
    KernelBackendError,
    load_gpu_module,
    load_rust_module,
    resolve_backend,
)

KERNEL_CAPABILITIES = (
    "segment_segment_distance",
    "segment_segment_distances",
    "segment_intersections_2d",
    "segment_bbox_candidate_pairs_2d",
    "segment_bbox_candidate_pairs_3d",
    "compute_writhe",
    "compute_gaussian_linking_number",
)


class _IrollKernelOwnedString(ctypes.Structure):
    _fields_ = [
        ("data", ctypes.c_void_p),
        ("length", ctypes.c_size_t),
        ("handle", ctypes.c_void_p),
    ]


def backend_report() -> dict[str, Any]:
    """Return JSON-compatible availability details for numeric backends."""

    rust_module = load_rust_module()
    gpu_module = load_gpu_module()
    auto_backend = resolve_backend(
        "auto",
        rust_available=rust_module is not None,
        gpu_available=gpu_module is not None,
    )
    return {
        "auto_backend": auto_backend,
        "kernel_capabilities": list(KERNEL_CAPABILITIES),
        "backends": {
            "numpy": {
                "available": True,
                "module": "numpy",
                "version": np.__version__,
                "selected_by_auto": auto_backend == "numpy",
                "explicit_only": False,
                "capabilities": {
                    name: True
                    for name in KERNEL_CAPABILITIES
                },
                "missing_capabilities": [],
            },
            "rust": _optional_backend_payload(
                rust_module,
                module_name="iroll_kernels_rust",
                selected_by_auto=auto_backend == "rust",
                explicit_only=False,
            ),
            "gpu": _optional_backend_payload(
                gpu_module,
                module_name="iroll_kernels_gpu",
                selected_by_auto=False,
                explicit_only=True,
            ),
        },
        "notes": [
            "backend='auto' may select Rust when iroll_kernels_rust is importable",
            "GPU kernels are explicit-only and are never selected by backend='auto'",
            "missing optional native modules do not affect the base NumPy backend",
        ],
    }


def rust_native_extension_path(module_origin: str | None) -> Path | None:
    """Return the installed Rust native extension path from a module origin."""

    if module_origin is None:
        return None
    origin = Path(module_origin)
    if any(origin.name.endswith(suffix) for suffix in importlib.machinery.EXTENSION_SUFFIXES):
        return origin
    package_dir = origin.parent
    for suffix in importlib.machinery.EXTENSION_SUFFIXES:
        matches = sorted(package_dir.glob(f"iroll_kernels_rust*{suffix}"))
        if matches:
            return matches[0]
    return None


def rust_unsupported_invariant_result_handle_report(
    invariant: str = "homfly",
) -> dict[str, Any]:
    """Create an unsupported Rust invariant result handle and return its JSON report."""

    if invariant not in {"homfly", "alexander"}:
        raise ValueError("invariant must be 'homfly' or 'alexander'")

    rust = backend_report()["backends"]["rust"]
    if not rust["available"]:
        raise KernelBackendError("Rust kernels are not installed")
    native_extension = rust_native_extension_path(rust["module_origin"])
    if native_extension is None:
        raise KernelBackendError("Rust native extension path is unavailable")

    try:
        library = ctypes.CDLL(str(native_extension))
    except OSError as exc:
        raise KernelBackendError(
            f"Rust native extension could not be loaded: {native_extension}"
        ) from exc
    try:
        create_unsupported = library.iroll_invariant_result_handle_create_unsupported
        report_json = library.iroll_invariant_result_handle_report_json
        free_handle = library.iroll_invariant_result_handle_free
        free_owned_string = library.iroll_kernel_owned_string_free
    except AttributeError as exc:
        raise KernelBackendError(
            "Rust unsupported invariant result-handle C ABI symbols are unavailable"
        ) from exc
    create_unsupported.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p)]
    create_unsupported.restype = ctypes.c_int
    report_json.argtypes = [ctypes.c_void_p, ctypes.POINTER(_IrollKernelOwnedString)]
    report_json.restype = ctypes.c_int
    free_handle.argtypes = [ctypes.c_void_p]
    free_handle.restype = None
    free_owned_string.argtypes = [_IrollKernelOwnedString]
    free_owned_string.restype = None

    handle = ctypes.c_void_p()
    status = create_unsupported(invariant.encode("utf-8"), ctypes.byref(handle))
    if status != 0 or not handle.value:
        raise KernelBackendError(
            f"Rust unsupported invariant result handle create failed: status={status}"
        )
    try:
        report = _IrollKernelOwnedString()
        try:
            report_status = report_json(handle, ctypes.byref(report))
            if report_status != 0 or not report.data or not report.handle:
                raise KernelBackendError(
                    "Rust unsupported invariant result handle report failed: "
                    f"status={report_status}"
                )
            raw = ctypes.string_at(report.data, report.length).decode("utf-8")
            payload = json.loads(raw)
        finally:
            free_owned_string(report)
    finally:
        free_handle(handle)
    if not isinstance(payload, dict):
        raise KernelBackendError("Rust unsupported invariant result handle report was not a JSON object")
    return payload


def _optional_backend_payload(
    module: ModuleType | None,
    *,
    module_name: str,
    selected_by_auto: bool,
    explicit_only: bool,
) -> dict[str, Any]:
    spec = importlib.util.find_spec(module_name)
    capabilities = _capability_payload(module)
    payload = {
        "available": module is not None,
        "module": module_name,
        "module_origin": spec.origin if spec is not None else None,
        "selected_by_auto": selected_by_auto,
        "explicit_only": explicit_only,
        "capabilities": capabilities,
        "missing_capabilities": [
            name
            for name, available in capabilities.items()
            if not available
        ],
    }
    if module is not None and hasattr(module, "backend_info"):
        try:
            payload["backend_info"] = module.backend_info()
        except Exception as exc:  # pragma: no cover - optional native/GPU env
            payload["backend_info_error"] = str(exc)
    return payload


def _capability_payload(module: ModuleType | None) -> dict[str, bool]:
    return {
        name: module is not None and hasattr(module, name)
        for name in KERNEL_CAPABILITIES
    }
