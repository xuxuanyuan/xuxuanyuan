"""Command-line interface for iroll."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
import re
import sys
from pathlib import Path
from typing import Mapping, Sequence
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from iroll.adapters import list_available_adapters
from iroll.core.curve import Polyline3D
from iroll.core.link import Link3D
from iroll.io import dump_report, load_points, load_ribbon_json, write_report
from iroll.kernels import (
    backend_report,
    rust_unsupported_invariant_result_handle_report,
)
from iroll.reports import (
    imgui_analysis_payload_from_acceptance_reports,
    imgui_fixture_comparison_payload_from_acceptance_reports,
    imgui_geometry_payload_from_report,
    imgui_host_payload_from_acceptance_reports,
    imgui_invariant_status_payload_from_acceptance_reports,
    imgui_invariant_status_payload_from_reports,
    imgui_kernel_backend_status_payload_from_backend_report,
    imgui_link_classification_summary_payload_from_report,
    imgui_signed_pd_payload_from_acceptance_reports,
)
from iroll.topology import (
    analyze_curve,
    analyze_link,
    analyze_ribbon,
    builtin_knot_table,
    builtin_link_table,
    cross_workstream_validation_pack_audit,
    full_homfly_pt_evaluation_readiness_report,
    full_multivariable_alexander_normalization_readiness_report,
    homfly_complete_evaluation_from_pd,
    homfly_fixture_acceptance_report,
    homfly_input_certification_evidence,
    homfly_iterative_certified_evaluation_from_pd,
    homfly_skein_identity_audit_from_pd,
    homfly_small_diagram_coverage_report,
    homfly_terminal_reduction_audit,
    get_diagram_fixture,
    multivariable_alexander_admissible_minor_normalization_audit,
    multivariable_alexander_fixture_acceptance_report,
    multivariable_alexander_from_pd,
    multivariable_alexander_improve_scanned_gcd_result,
    multivariable_alexander_input_certification_evidence,
    multivariable_alexander_minor_divisibility_audit,
    multivariable_alexander_scanned_gcd_audit,
    multivariable_alexander_signed_pd_coverage_report,
    multivariable_alexander_wirtinger_fox_audit,
    production_imgui_renderer_framebuffer_readiness_report,
    signed_release_publication_readiness_report,
    validate_table_file,
    verified_signed_crossing_assignment_readiness_report,
    PDOrientation,
    PDCrossing,
    PlanarDiagram,
)
from iroll.topology.polynomial import parse_multivariate_laurent_polynomial
from iroll.topology.pd_fixtures import (
    completion_evidence_artifact_audit,
    completion_evidence_artifact_preflight_contract_coverage,
    verified_signed_crossing_assignment_audit,
)
from iroll.topology.alexander_certification import (
    canonical_json_sha256,
    full_alexander_pinned_sources,
    full_multivariable_alexander_normalization_certification_report,
    full_multivariable_alexander_normalization_certification_report_audit,
    serialized_certification_report_sha256,
)
from iroll.topology.homfly_certification import (
    full_homfly_pinned_sources,
    full_homfly_pt_evaluation_certification_report_audit,
    homfly_implementation_bundle_witness,
    homfly_complete_certification_case as _replay_homfly_complete_certification_case,
)
from iroll.validation import run_validation
from iroll.viewer import write_report_html


_KNOT_ATLAS_PINNED_ASSIGNMENT_SOURCES = {
    "Planar Diagrams": {
        "revision_id": 1719338,
        "sha256": "bb539ab3b2fd39b16960c4fe541bd44bf0c0ea69e773b6270aec42566c6f6616",
        "role": "source_convention",
    },
    "L5a1": {
        "pd_presentation": {
            "title": "Data:L5a1/PD Presentation",
            "revision_id": 64045,
            "sha256": "2eb8f6b4a1f99e3ac00ada61e003bd1c2d33020113defb6d8766948a4622c440",
        },
        "gauss_code": {
            "title": "Data:L5a1/Gauss Code",
            "revision_id": 64043,
            "sha256": "c1d871b777792bd15e4cdbac3494fdbb612d955d3472721a0ef8483bf06f6874",
        },
        "jones": {
            "title": "Data:L5a1/Jones Polynomial",
            "revision_id": 1717700,
            "sha256": "bdc265c6cd1ae4151d713cc41b92cbc0b50d6baeba663bcecb7ec3d56d74d5b3",
            "expected_math_source": (
                r"<math>\frac{1}{q^{7/2}}-\frac{2}{q^{5/2}}-q^{3/2}"
                r"+\frac{1}{q^{3/2}}+\sqrt{q}-\frac{2}{\sqrt{q}}</math>"
            ),
            "expected_fixture_value": (
                "q^-7/2 - 2q^-5/2 + q^-3/2 - 2q^-1/2 + q^1/2 - q^3/2"
            ),
        },
        "homfly": {
            "title": "Data:L5a1/HOMFLYPT Polynomial",
            "revision_id": 64048,
            "sha256": "9d1fe93a45cfdd2ec596760913d25162c194246864bddaef57316210c5519e74",
            "expected_math_source": (
                r"<math>-za^3+z^3a+2za+az^{-1}-za^{-1}-a^{-1}z^{-1}</math>"
            ),
            "expected_fixture_value": (
                "-a^3*z + a*z^3 + 2a*z + a*z^-1 - a^-1*z - a^-1*z^-1"
            ),
        },
        "multivariable_alexander": {
            "title": "Data:L5a1/Multivariable Alexander",
            "revision_id": 1692217,
            "sha256": "20daa3f2b5af9ddfd7b70046e53d95f618eb86949cf634d162805236070580c3",
            "expected_math_source": (
                r"<math>\frac{(u-1)(v-1)}{\sqrt{u}\sqrt{v}}</math>"
            ),
            "expected_fixture_value": "(u - 1)*(v - 1)/(sqrt(u)*sqrt(v))",
        },
    },
    "L6a4": {
        "pd_presentation": {
            "title": "Data:L6a4/PD Presentation",
            "revision_id": 69371,
            "sha256": "f2c761a305ff182500414e4e1ce9128f3b235e414f91f852381efead076668e4",
        },
        "gauss_code": {
            "title": "Data:L6a4/Gauss Code",
            "revision_id": 69369,
            "sha256": "c5aa0dfcaf015afb7a5da287111450690c8edd3f42d382aacfddedd49a9b3704",
        },
        "jones": {
            "title": "Data:L6a4/Jones Polynomial",
            "revision_id": 1714143,
            "sha256": "24462735a7df6ce82ee0955306bdb8d737215e5779c17edd28f695549659e605",
            "expected_math_source": (
                r"<math>-q^3-q^{-3}+3q^2+3q^{-2}-2q-2q^{-1}+4</math>"
            ),
            "expected_fixture_value": (
                "-q^3 - q^-3 + 3q^2 + 3q^-2 - 2q - 2q^-1 + 4"
            ),
        },
        "homfly": {
            "title": "Data:L6a4/HOMFLYPT Polynomial",
            "revision_id": 1718118,
            "sha256": "92f541fd98781658d454ea832e43c53b8df04a743a64ca6a43552512214a06ab",
            "expected_math_source": (
                r"<math>-a^2z^2-z^2a^{-2}+a^2z^{-2}+a^{-2}z^{-2}"
                r"+z^4+2z^2-2z^{-2}</math>"
            ),
            "expected_fixture_value": (
                "-a^2*z^2 - a^-2*z^2 + a^2*z^-2 + a^-2*z^-2 + "
                "z^4 + 2z^2 - 2z^-2"
            ),
        },
        "multivariable_alexander": {
            "title": "Data:L6a4/Multivariable Alexander",
            "revision_id": 1693896,
            "sha256": "2458f37aee2f3727dac33fde8fa2ba9d88a31142960e600fd47e90d08e289011",
            "expected_math_source": (
                r"<math>\frac{(u-1)(v-1)(w-1)}"
                r"{\sqrt{u}\sqrt{v}\sqrt{w}}</math>"
            ),
            "expected_fixture_value": (
                "(u - 1)*(v - 1)*(w - 1)/(sqrt(u)*sqrt(v)*sqrt(w))"
            ),
        },
    },
}


_KNOT_ATLAS_PINNED_HOMFLY_SOURCES = full_homfly_pinned_sources()


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    report = args.func(args)
    exit_code = int(report.pop("_exit_code", 0))
    output = write_report(report, args.output)
    if output is not None:
        print(output)
    return exit_code


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="iroll",
        description="Analyze 3D curves, knots, and links.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    curve = subparsers.add_parser("analyze-curve", help="Analyze one 3D point chain.")
    curve.add_argument("path", type=Path, help="Input .csv or .json point file.")
    curve.add_argument("--closed", action="store_true", help="Treat the input chain as closed.")
    curve.add_argument("--name", default=None, help="Optional curve name.")
    curve.add_argument("--direction", default=None, help="Projection direction such as 0,0,1.")
    curve.add_argument(
        "--closure-method",
        choices=["direct", "ray", "random_sphere"],
        default=None,
        help="Closure strategy for open curves.",
    )
    curve.add_argument("--closure-samples", type=int, default=1)
    curve.add_argument("--closure-seed", type=int, default=None)
    curve.add_argument("--closure-scale", type=float, default=10.0)
    curve.add_argument("--backend", choices=["auto", "numpy", "rust", "gpu"], default="auto")
    curve.add_argument("--contact-threshold", type=float, default=None)
    curve.add_argument("--max-contacts", type=int, default=100)
    curve.add_argument("--include-diagram-matrix", action="store_true")
    curve.add_argument("--subchain-window-points", type=int, default=None)
    curve.add_argument("--subchain-step", type=int, default=1)
    curve.add_argument("--subchain-max-windows", type=int, default=200)
    curve.add_argument("--adapter", choices=["pyknotid", "topoly"], default=None)
    curve.add_argument("-o", "--output", type=Path, default=None, help="Output JSON file.")
    curve.set_defaults(func=_analyze_curve_command)

    link = subparsers.add_parser("analyze-link", help="Analyze multiple 3D point chains.")
    link.add_argument("paths", nargs="+", type=Path, help="Input .csv or .json component files.")
    link.add_argument("--closed", action="store_true", help="Treat all components as closed.")
    link.add_argument("--name", default=None, help="Optional link name.")
    link.add_argument("--direction", default=None, help="Projection direction such as 0,0,1.")
    link.add_argument("--backend", choices=["auto", "numpy", "rust", "gpu"], default="auto")
    link.add_argument("--contact-threshold", type=float, default=None)
    link.add_argument("--max-contacts", type=int, default=100)
    link.add_argument("-o", "--output", type=Path, default=None, help="Output JSON file.")
    link.set_defaults(func=_analyze_link_command)

    ribbon = subparsers.add_parser("analyze-ribbon", help="Analyze one ribbon JSON file.")
    ribbon.add_argument("path", type=Path, help="Input JSON with points and directors.")
    ribbon.add_argument("--closed", action="store_true", help="Treat the centerline as closed.")
    ribbon.add_argument("--name", default=None, help="Optional ribbon name.")
    ribbon.add_argument("--backend", choices=["auto", "numpy", "rust", "gpu"], default="auto")
    ribbon.add_argument("--contact-threshold", type=float, default=None)
    ribbon.add_argument("--max-contacts", type=int, default=100)
    ribbon.add_argument("-o", "--output", type=Path, default=None, help="Output JSON file.")
    ribbon.set_defaults(func=_analyze_ribbon_command)

    adapters = subparsers.add_parser("adapters", help="List optional external adapters.")
    adapters.add_argument("-o", "--output", type=Path, default=None, help="Output JSON file.")
    adapters.set_defaults(func=_adapters_command)

    validate = subparsers.add_parser("validate", help="Run built-in validation fixtures.")
    validate.add_argument("--points", type=int, default=256)
    validate.add_argument("-o", "--output", type=Path, default=None, help="Output JSON file.")
    validate.set_defaults(func=_validate_command)

    backends = subparsers.add_parser("backends", help="Print numeric backend diagnostics.")
    backends.add_argument("-o", "--output", type=Path, default=None, help="Output JSON file.")
    backends.set_defaults(func=_backends_command)

    rust_unsupported_handle = subparsers.add_parser(
        "rust-unsupported-invariant-result-handle-report",
        help="Export the installed Rust unsupported invariant result-handle report.",
    )
    rust_unsupported_handle.add_argument(
        "--invariant",
        choices=["homfly", "alexander"],
        default="homfly",
        help="Invariant handle kind to probe.",
    )
    rust_unsupported_handle.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    rust_unsupported_handle.set_defaults(
        func=_rust_unsupported_invariant_result_handle_report_command
    )

    knot_table = subparsers.add_parser("knot-table", help="Print the built-in knot table.")
    knot_table.add_argument("-o", "--output", type=Path, default=None, help="Output JSON file.")
    knot_table.set_defaults(func=_knot_table_command)

    link_table = subparsers.add_parser("link-table", help="Print the built-in link table.")
    link_table.add_argument("-o", "--output", type=Path, default=None, help="Output JSON file.")
    link_table.set_defaults(func=_link_table_command)

    validate_table = subparsers.add_parser(
        "validate-table",
        help="Validate an optional knot or link table JSON file.",
    )
    validate_table.add_argument("path", type=Path, help="Input table JSON file.")
    validate_table.add_argument("--kind", choices=["knot", "link"], required=True)
    validate_table.add_argument("--expected-convention", default=None)
    validate_table.add_argument("-o", "--output", type=Path, default=None, help="Output JSON file.")
    validate_table.set_defaults(func=_validate_table_command)

    fixture_validation_pack = subparsers.add_parser(
        "fixture-validation-pack-audit",
        help="Audit cross-workstream validation-pack fixture metadata readiness.",
    )
    fixture_validation_pack.add_argument(
        "--notation",
        action="append",
        default=None,
        help="Required fixture notation to audit. Repeat to override the default pack.",
    )
    fixture_validation_pack.add_argument(
        "--completion-evidence-bundle-json",
        type=Path,
        default=None,
        help=(
            "Optional final completion evidence bundle JSON containing all "
            "strong validation-pack artifacts."
        ),
    )
    fixture_validation_pack.add_argument(
        "--verified-signed-crossing-assignment-json",
        action="append",
        type=Path,
        default=None,
        help=(
            "Verified signed crossing assignment JSON for a source-table "
            "fixture. Repeat for multiple fixtures."
        ),
    )
    fixture_validation_pack.add_argument(
        "--production-imgui-renderer-framebuffer-pack-json",
        type=Path,
        default=None,
        help=(
            "Optional production Dear ImGui renderer framebuffer pack JSON to "
            "use as final validation-pack renderer evidence."
        ),
    )
    fixture_validation_pack.add_argument(
        "--signed-release-publication-manifest-json",
        type=Path,
        default=None,
        help=(
            "Optional signed release publication manifest JSON to use as final "
            "validation-pack release evidence."
        ),
    )
    fixture_validation_pack.add_argument(
        "--full-homfly-pt-evaluation-certification-pack-json",
        type=Path,
        default=None,
        help=(
            "Optional full HOMFLY-PT evaluation certification pack JSON to use "
            "as final validation-pack HOMFLY evidence."
        ),
    )
    fixture_validation_pack.add_argument(
        "--full-multivariable-alexander-normalization-certification-pack-json",
        type=Path,
        default=None,
        help=(
            "Optional full multi-variable Alexander normalization certification "
            "pack JSON to use as final validation-pack Alexander evidence."
        ),
    )
    fixture_validation_pack.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    fixture_validation_pack.add_argument(
        "--fail-on-not-ready",
        action="store_true",
        help=(
            "Return exit code 1 when the validation-pack audit does not report "
            "final_completion_ready=true."
        ),
    )
    fixture_validation_pack.set_defaults(
        func=_fixture_validation_pack_audit_command
    )

    completion_evidence_bundle = subparsers.add_parser(
        "completion-evidence-bundle",
        help="Assemble a final validation-pack completion evidence bundle.",
    )
    completion_evidence_bundle.add_argument(
        "--verified-signed-crossing-assignment-json",
        action="append",
        type=Path,
        default=None,
        help=(
            "Verified signed crossing assignment JSON. Repeat for every "
            "source-table fixture assignment."
        ),
    )
    completion_evidence_bundle.add_argument(
        "--production-imgui-renderer-framebuffer-pack-json",
        type=Path,
        default=None,
        help="Production Dear ImGui renderer framebuffer pack JSON.",
    )
    completion_evidence_bundle.add_argument(
        "--signed-release-publication-manifest-json",
        type=Path,
        default=None,
        help="Signed release publication manifest JSON.",
    )
    completion_evidence_bundle.add_argument(
        "--full-homfly-pt-evaluation-certification-pack-json",
        type=Path,
        default=None,
        help="Full HOMFLY-PT evaluation certification pack JSON.",
    )
    completion_evidence_bundle.add_argument(
        "--full-multivariable-alexander-normalization-certification-pack-json",
        type=Path,
        default=None,
        help="Full multi-variable Alexander normalization certification pack JSON.",
    )
    completion_evidence_bundle.add_argument(
        "--evidence-directory",
        type=Path,
        default=None,
        help=(
            "Directory containing completion evidence JSON files, such as files "
            "derived from completion-evidence-templates --directory."
        ),
    )
    completion_evidence_bundle.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    completion_evidence_bundle.set_defaults(
        func=_completion_evidence_bundle_command
    )

    completion_evidence_directory_audit = subparsers.add_parser(
        "completion-evidence-directory-audit",
        help="Audit completion evidence files discoverable from a directory.",
    )
    completion_evidence_directory_audit.add_argument(
        "directory",
        type=Path,
        help="Directory containing completion evidence JSON files.",
    )
    completion_evidence_directory_audit.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    completion_evidence_directory_audit.add_argument(
        "--validate-artifacts",
        action="store_true",
        help=(
            "When all inputs are present, validate discovered artifact contents "
            "through the final validation-pack audit."
        ),
    )
    completion_evidence_directory_audit.add_argument(
        "--bundle-output",
        type=Path,
        default=None,
        help=(
            "When all inputs are present, write the discovered completion "
            "evidence bundle to this JSON path."
        ),
    )
    completion_evidence_directory_audit.add_argument(
        "--validation-output",
        type=Path,
        default=None,
        help=(
            "When all inputs are present, write the final validation-pack audit "
            "for the discovered bundle to this JSON path."
        ),
    )
    completion_evidence_directory_audit.add_argument(
        "--fail-on-not-ready",
        action="store_true",
        help=(
            "Return exit code 1 when the discovered evidence directory is not "
            "pipeline-ready after the requested checks."
        ),
    )
    completion_evidence_directory_audit.set_defaults(
        func=_completion_evidence_directory_audit_command
    )

    completion_evidence_requirements = subparsers.add_parser(
        "completion-evidence-requirements",
        help="List final validation-pack evidence artifacts still required.",
    )
    completion_evidence_requirements.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    completion_evidence_requirements.set_defaults(
        func=_completion_evidence_requirements_command
    )

    completion_evidence_contracts = subparsers.add_parser(
        "completion-evidence-contracts",
        help="Emit machine-readable contracts for required completion evidence.",
    )
    completion_evidence_contracts.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    completion_evidence_contracts.set_defaults(
        func=_completion_evidence_contracts_command
    )

    completion_evidence_templates = subparsers.add_parser(
        "completion-evidence-templates",
        help="Emit non-certified JSON templates for required completion evidence.",
    )
    completion_evidence_templates.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    completion_evidence_templates.add_argument(
        "--directory",
        type=Path,
        default=None,
        help="Optional directory where individual template JSON files are written.",
    )
    completion_evidence_templates.add_argument(
        "--expand-repeatable",
        action="store_true",
        help=(
            "Expand repeatable template rows into one template per blocker "
            "label, such as separate L5a1 and L6a4 assignment templates."
        ),
    )
    completion_evidence_templates.set_defaults(
        func=_completion_evidence_templates_command
    )

    completion_evidence_producer_workspace = subparsers.add_parser(
        "completion-evidence-producer-workspace",
        help=(
            "Create a producer workspace index for filling final completion "
            "evidence artifacts."
        ),
    )
    completion_evidence_producer_workspace.add_argument(
        "directory",
        type=Path,
        help="Workspace directory where templates and the producer index are written.",
    )
    completion_evidence_producer_workspace.add_argument(
        "-o",
        "--output",
        type=Path,
        default=None,
        help=(
            "Output workspace index JSON file. Defaults to "
            "<directory>/completion-evidence-producer-workspace.json."
        ),
    )
    completion_evidence_producer_workspace.set_defaults(
        func=_completion_evidence_producer_workspace_command
    )

    completion_evidence_ci_plan = subparsers.add_parser(
        "completion-evidence-ci-plan",
        help="Emit the recommended CI command plan for final completion evidence.",
    )
    completion_evidence_ci_plan.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    completion_evidence_ci_plan.set_defaults(
        func=_completion_evidence_ci_plan_command
    )

    completion_evidence_review_bundle = subparsers.add_parser(
        "completion-evidence-review-bundle",
        help=(
            "Write the current completion requirements, templates, readiness "
            "reports, CI plan, and validation audit into one review directory."
        ),
    )
    completion_evidence_review_bundle.add_argument(
        "directory",
        type=Path,
        help="Directory where review JSON artifacts are written.",
    )
    completion_evidence_review_bundle.add_argument(
        "-o", "--output", type=Path, default=None, help="Output index JSON file."
    )
    completion_evidence_review_bundle.set_defaults(
        func=_completion_evidence_review_bundle_command
    )

    completion_evidence_artifact = subparsers.add_parser(
        "completion-evidence-artifact-audit",
        help="Preflight one completion evidence JSON artifact.",
    )
    completion_evidence_artifact.add_argument(
        "path",
        type=Path,
        help="Input completion evidence JSON artifact.",
    )
    completion_evidence_artifact.add_argument(
        "--artifact-type",
        choices=[
            "verified_signed_crossing_assignment",
            "production_imgui_renderer_framebuffer_pack",
            "signed_release_publication_manifest",
            "full_homfly_pt_evaluation_certification_pack",
            "full_multivariable_alexander_normalization_certification_pack",
        ],
        default=None,
        help="Optional expected completion evidence artifact type.",
    )
    completion_evidence_artifact.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    completion_evidence_artifact.add_argument(
        "--fail-on-not-certified",
        action="store_true",
        help="Return exit code 1 when the artifact is not certified.",
    )
    completion_evidence_artifact.set_defaults(
        func=_completion_evidence_artifact_audit_command
    )

    verified_assignment_audit = subparsers.add_parser(
        "verified-signed-crossing-assignment-audit",
        help="Preflight one verified signed crossing assignment JSON artifact.",
    )
    verified_assignment_audit.add_argument(
        "path",
        type=Path,
        help="Input verified_signed_crossing_assignment JSON artifact.",
    )
    verified_assignment_audit.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    verified_assignment_audit.add_argument(
        "--fail-on-not-certified",
        action="store_true",
        help="Return exit code 1 when the assignment artifact is not certified.",
    )
    verified_assignment_audit.set_defaults(
        func=_verified_signed_crossing_assignment_audit_command
    )

    verified_assignment_producer = subparsers.add_parser(
        "verified-signed-crossing-assignment-producer",
        help=(
            "Produce a verified L5a1/L6a4 signed assignment from pinned Knot "
            "Atlas revisions and the documented PD convention."
        ),
    )
    verified_assignment_producer.add_argument(
        "notation",
        choices=["L5a1", "L6a4"],
        help="Knot Atlas link notation to certify.",
    )
    verified_assignment_producer.add_argument(
        "--network-timeout",
        type=float,
        default=30.0,
        help="Timeout in seconds for each pinned source revision fetch.",
    )
    verified_assignment_producer.add_argument(
        "-o", "--output", type=Path, default=None, help="Output evidence JSON file."
    )
    verified_assignment_producer.add_argument(
        "--fail-on-not-certified",
        action="store_true",
        help="Return exit code 1 unless the produced artifact passes preflight.",
    )
    verified_assignment_producer.set_defaults(
        func=_verified_signed_crossing_assignment_producer_command
    )

    homfly_certification_report = subparsers.add_parser(
        "homfly-full-certification-report",
        help=(
            "Run the cutoff-free descending-diagram HOMFLY evaluator and "
            "verify pinned Knot Atlas normalization witnesses."
        ),
    )
    homfly_certification_report.add_argument(
        "--network-timeout",
        type=float,
        default=30.0,
        help="Timeout in seconds for each pinned source revision fetch.",
    )
    homfly_certification_report.add_argument(
        "-o", "--output", type=Path, default=None, help="Output report JSON file."
    )
    homfly_certification_report.add_argument(
        "--fail-on-not-certified",
        action="store_true",
        help="Return exit code 1 unless every mathematical and source check passes.",
    )
    homfly_certification_report.set_defaults(
        func=_homfly_full_certification_report_command
    )

    homfly_pack_producer = subparsers.add_parser(
        "homfly-full-certification-pack-producer",
        help=(
            "Produce the final HOMFLY completion pack from a generated report "
            "and its publicly retained byte-identical URL."
        ),
    )
    homfly_pack_producer.add_argument(
        "certification_report_json",
        type=Path,
        help="Local homfly-full-certification-report JSON file.",
    )
    homfly_pack_producer.add_argument(
        "--certification-report-url",
        default="",
        help=(
            "Public HTTP(S) URL serving exactly the local report bytes. "
            "The producer fetches and hashes it before certifying."
        ),
    )
    homfly_pack_producer.add_argument(
        "--network-timeout",
        type=float,
        default=30.0,
        help="Timeout in seconds for the published report fetch.",
    )
    homfly_pack_producer.add_argument(
        "-o", "--output", type=Path, default=None, help="Output evidence JSON file."
    )
    homfly_pack_producer.add_argument(
        "--fail-on-not-certified",
        action="store_true",
        help="Return exit code 1 unless the resulting pack passes artifact preflight.",
    )
    homfly_pack_producer.set_defaults(
        func=_homfly_full_certification_pack_producer_command
    )

    verified_assignment_readiness = subparsers.add_parser(
        "verified-signed-crossing-assignment-readiness",
        help=(
            "Report source-candidate readiness for producing verified signed "
            "crossing assignment artifacts."
        ),
    )
    verified_assignment_readiness.add_argument(
        "--notation",
        action="append",
        default=None,
        help=(
            "Required unsigned source-table fixture notation to inspect. "
            "Repeat to override the default L5a1/L6a4 set."
        ),
    )
    verified_assignment_readiness.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    verified_assignment_readiness.add_argument(
        "--fail-on-not-ready",
        action="store_true",
        help="Return exit code 1 when verified assignment readiness is not complete.",
    )
    verified_assignment_readiness.set_defaults(
        func=_verified_signed_crossing_assignment_readiness_command
    )

    production_imgui_readiness = subparsers.add_parser(
        "production-imgui-renderer-framebuffer-readiness",
        help=(
            "Report readiness for producing the production Dear ImGui "
            "renderer framebuffer evidence pack."
        ),
    )
    production_imgui_readiness.add_argument(
        "--production-imgui-renderer-framebuffer-pack-json",
        type=Path,
        default=None,
        help=(
            "Optional production renderer framebuffer pack JSON to evaluate "
            "against readiness checks."
        ),
    )
    production_imgui_readiness.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    production_imgui_readiness.add_argument(
        "--fail-on-not-ready",
        action="store_true",
        help="Return exit code 1 when production framebuffer readiness is incomplete.",
    )
    production_imgui_readiness.set_defaults(
        func=_production_imgui_renderer_framebuffer_readiness_command
    )

    signed_release_readiness = subparsers.add_parser(
        "signed-release-publication-readiness",
        help="Report readiness for producing the signed release publication manifest.",
    )
    signed_release_readiness.add_argument(
        "--signed-release-publication-manifest-json",
        type=Path,
        default=None,
        help="Optional signed release publication manifest JSON to evaluate.",
    )
    signed_release_readiness.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    signed_release_readiness.add_argument(
        "--fail-on-not-ready",
        action="store_true",
        help="Return exit code 1 when signed release publication readiness is incomplete.",
    )
    signed_release_readiness.set_defaults(
        func=_signed_release_publication_readiness_command
    )

    homfly_readiness = subparsers.add_parser(
        "full-homfly-pt-evaluation-readiness",
        help="Report readiness for producing the full HOMFLY-PT certification pack.",
    )
    homfly_readiness.add_argument(
        "--full-homfly-pt-evaluation-certification-pack-json",
        type=Path,
        default=None,
        help="Optional full HOMFLY-PT certification pack JSON to evaluate.",
    )
    homfly_readiness.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    homfly_readiness.add_argument(
        "--fail-on-not-ready",
        action="store_true",
        help="Return exit code 1 when full HOMFLY-PT readiness is incomplete.",
    )
    homfly_readiness.set_defaults(
        func=_full_homfly_pt_evaluation_readiness_command
    )

    alexander_readiness = subparsers.add_parser(
        "full-multivariable-alexander-normalization-readiness",
        help=(
            "Report readiness for producing the full multi-variable Alexander "
            "normalization certification pack."
        ),
    )
    alexander_readiness.add_argument(
        "--full-multivariable-alexander-normalization-certification-pack-json",
        type=Path,
        default=None,
        help=(
            "Optional full multi-variable Alexander normalization certification "
            "pack JSON to evaluate."
        ),
    )
    alexander_readiness.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    alexander_readiness.add_argument(
        "--fail-on-not-ready",
        action="store_true",
        help=(
            "Return exit code 1 when full multi-variable Alexander readiness "
            "is incomplete."
        ),
    )
    alexander_readiness.set_defaults(
        func=_full_multivariable_alexander_normalization_readiness_command
    )

    alexander_certification_producer = subparsers.add_parser(
        "full-multivariable-alexander-normalization-certification-producer",
        help=(
            "Produce the uncapped exact Fox-minor/SymPy-ZZ Alexander "
            "normalization certificate from verified signed assignments and "
            "pinned Knot Atlas revisions."
        ),
    )
    alexander_certification_producer.add_argument(
        "--verified-signed-crossing-assignment-json",
        type=Path,
        action="append",
        required=True,
        help=(
            "Verified L5a1/L6a4 signed assignment JSON. Repeat once for each "
            "required notation."
        ),
    )
    alexander_certification_producer.add_argument(
        "--network-timeout",
        type=float,
        default=30.0,
        help="Timeout in seconds for each pinned Knot Atlas source fetch.",
    )
    alexander_certification_producer.add_argument(
        "--certification-report-output",
        type=Path,
        required=True,
        help="Output path for the standalone replayable certification report.",
    )
    alexander_certification_producer.add_argument(
        "--certification-report-url",
        default=None,
        help=(
            "Published HTTP(S) URL for the byte-identical standalone report. "
            "Omitting it only stages an uncertified embedded report; the final "
            "gate requires downloaded raw-file and canonical replay digests."
        ),
    )
    alexander_certification_producer.add_argument(
        "-o",
        "--output",
        type=Path,
        default=None,
        help="Output path for the final certification pack.",
    )
    alexander_certification_producer.add_argument(
        "--fail-on-not-certified",
        action="store_true",
        help="Return exit code 1 unless source, replay, and artifact audits pass.",
    )
    alexander_certification_producer.set_defaults(
        func=(
            _full_multivariable_alexander_normalization_certification_producer_command
        )
    )

    homfly_acceptance = subparsers.add_parser(
        "homfly-fixture-acceptance",
        help="Export the full HOMFLY fixture acceptance evidence report.",
    )
    _add_fixture_acceptance_report_arguments(homfly_acceptance)
    homfly_acceptance.set_defaults(func=_homfly_fixture_acceptance_command)

    alexander_acceptance = subparsers.add_parser(
        "multivariable-alexander-fixture-acceptance",
        help="Export the full multi-variable Alexander fixture acceptance evidence report.",
    )
    _add_fixture_acceptance_report_arguments(alexander_acceptance)
    alexander_acceptance.set_defaults(
        func=_multivariable_alexander_fixture_acceptance_command
    )

    alexander_coverage = subparsers.add_parser(
        "multivariable-alexander-signed-pd-coverage",
        help="Export generated signed-PD Alexander input-chain coverage evidence.",
    )
    _add_alexander_signed_pd_coverage_arguments(alexander_coverage)
    alexander_coverage.set_defaults(
        func=_multivariable_alexander_signed_pd_coverage_command
    )

    alexander_pd = subparsers.add_parser(
        "multivariable-alexander-pd",
        help="Compute multi-variable Alexander evidence from a signed-PD JSON file.",
    )
    alexander_pd.add_argument("path", type=Path, help="Input signed-PD JSON file.")
    alexander_pd.add_argument(
        "--variable",
        action="append",
        default=None,
        help="Component variable name. Repeat for multi-component diagrams.",
    )
    alexander_pd.add_argument(
        "--role-order",
        type=_parse_role_order,
        default=None,
        help="Global crossing-field order such as 1,0,2,3 for external signed-PD sources.",
    )
    alexander_pd.add_argument(
        "--auto-role-order",
        action="store_true",
        help=(
            "Infer a global crossing-field order only when exactly one strict "
            "candidate exists; ambiguous inputs are reported as skipped."
        ),
    )
    alexander_pd.add_argument(
        "--target-size",
        type=int,
        default=None,
        help="Optional Fox square-minor target size.",
    )
    alexander_pd.add_argument(
        "--max-matrix-size",
        type=int,
        default=4,
        help="Maximum Fox matrix size for determinant expansion.",
    )
    alexander_pd.add_argument(
        "--max-minors",
        type=int,
        default=64,
        help="Maximum Fox square minors to scan.",
    )
    alexander_pd.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    alexander_pd.set_defaults(func=_multivariable_alexander_pd_command)

    alexander_improve = subparsers.add_parser(
        "multivariable-alexander-improve-scanned-gcd-result",
        help=(
            "Materialize an audit-proved improved bounded scanned-gcd "
            "candidate from an Alexander result JSON file."
        ),
    )
    alexander_improve.add_argument(
        "path",
        type=Path,
        help="Input multivariable-alexander-pd report or bare result JSON file.",
    )
    alexander_improve.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    alexander_improve.set_defaults(
        func=_multivariable_alexander_improve_scanned_gcd_result_command
    )

    alexander_scanned_gcd_audit = subparsers.add_parser(
        "multivariable-alexander-scanned-gcd-audit",
        help=(
            "Audit an existing Alexander result JSON against its bounded "
            "scanned Fox-minor set."
        ),
    )
    alexander_scanned_gcd_audit.add_argument(
        "path",
        type=Path,
        help="Input multivariable-alexander-pd report or bare result JSON file.",
    )
    alexander_scanned_gcd_audit.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    alexander_scanned_gcd_audit.set_defaults(
        func=_multivariable_alexander_scanned_gcd_audit_command
    )

    alexander_minor_divisibility_audit = subparsers.add_parser(
        "multivariable-alexander-minor-divisibility-audit",
        help=(
            "Audit whether an existing Alexander result divides every nonzero "
            "scanned Fox minor in its bounded scan."
        ),
    )
    alexander_minor_divisibility_audit.add_argument(
        "path",
        type=Path,
        help="Input multivariable-alexander-pd report or bare result JSON file.",
    )
    alexander_minor_divisibility_audit.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    alexander_minor_divisibility_audit.set_defaults(
        func=_multivariable_alexander_minor_divisibility_audit_command
    )

    alexander_admissible_normalization_audit = subparsers.add_parser(
        "multivariable-alexander-admissible-minor-normalization-audit",
        help=(
            "Audit whether scanned nonzero Alexander Fox minors normalize to "
            "one Laurent-unit representative."
        ),
    )
    alexander_admissible_normalization_audit.add_argument(
        "path",
        type=Path,
        help="Input multivariable-alexander-pd report or bare result JSON file.",
    )
    alexander_admissible_normalization_audit.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    alexander_admissible_normalization_audit.set_defaults(
        func=_multivariable_alexander_admissible_minor_normalization_audit_command
    )

    alexander_wirtinger_fox_audit = subparsers.add_parser(
        "multivariable-alexander-wirtinger-fox-audit",
        help=(
            "Audit an existing Alexander result JSON for Wirtinger/Fox "
            "presentation and scanned-minor consistency."
        ),
    )
    alexander_wirtinger_fox_audit.add_argument(
        "path",
        type=Path,
        help="Input multivariable-alexander-pd report or bare result JSON file.",
    )
    alexander_wirtinger_fox_audit.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    alexander_wirtinger_fox_audit.set_defaults(
        func=_multivariable_alexander_wirtinger_fox_audit_command
    )

    alexander_input_evidence = subparsers.add_parser(
        "multivariable-alexander-input-certification-evidence",
        help=(
            "Summarize bounded scanned-gcd and Wirtinger/Fox input evidence "
            "for an Alexander result JSON file."
        ),
    )
    alexander_input_evidence.add_argument(
        "path",
        type=Path,
        help="Input multivariable-alexander-pd report or bare result JSON file.",
    )
    alexander_input_evidence.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    alexander_input_evidence.set_defaults(
        func=_multivariable_alexander_input_certification_evidence_command
    )

    homfly_pd = subparsers.add_parser(
        "homfly-pd",
        help="Compute bounded HOMFLY evidence from a signed-PD JSON file.",
    )
    homfly_pd.add_argument("path", type=Path, help="Input signed-PD JSON file.")
    homfly_pd.add_argument(
        "--role-order",
        type=_parse_role_order,
        default=None,
        help="Global crossing-field order such as 1,0,2,3 for external signed-PD sources.",
    )
    homfly_pd.add_argument(
        "--auto-role-order",
        action="store_true",
        help=(
            "Infer a global crossing-field order only when exactly one strict "
            "candidate exists; ambiguous inputs are reported as skipped."
        ),
    )
    homfly_pd.add_argument(
        "--max-crossings",
        type=int,
        default=8,
        help="Maximum crossing count accepted by the bounded HOMFLY evaluator.",
    )
    homfly_pd.add_argument(
        "--initial-depth",
        type=int,
        default=0,
        help="Initial recursive depth for iterative HOMFLY certification.",
    )
    homfly_pd.add_argument(
        "--max-depth",
        type=int,
        default=16,
        help="Maximum recursive depth for iterative HOMFLY certification.",
    )
    homfly_pd.add_argument(
        "--max-nodes",
        type=int,
        default=4096,
        help="Maximum recursive HOMFLY nodes per depth attempt.",
    )
    homfly_pd.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    homfly_pd.set_defaults(func=_homfly_pd_command)

    homfly_terminal_audit = subparsers.add_parser(
        "homfly-terminal-reduction-audit",
        help=(
            "Audit an existing HOMFLY result JSON against its recorded "
            "terminal and memoized reduction contributions."
        ),
    )
    homfly_terminal_audit.add_argument(
        "path",
        type=Path,
        help="Input homfly-pd report or bare HOMFLY result JSON file.",
    )
    homfly_terminal_audit.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    homfly_terminal_audit.set_defaults(
        func=_homfly_terminal_reduction_audit_command
    )

    homfly_input_evidence = subparsers.add_parser(
        "homfly-input-certification-evidence",
        help="Summarize bounded input-level certification evidence for a HOMFLY result JSON file.",
    )
    homfly_input_evidence.add_argument(
        "path",
        type=Path,
        help="Input homfly-pd report or bare HOMFLY result JSON file.",
    )
    homfly_input_evidence.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    homfly_input_evidence.set_defaults(
        func=_homfly_input_certification_evidence_command
    )

    homfly_skein_audit = subparsers.add_parser(
        "homfly-skein-identity-audit",
        help="Audit local HOMFLY skein identities for a signed-PD JSON file.",
    )
    homfly_skein_audit.add_argument("path", type=Path, help="Input signed-PD JSON file.")
    homfly_skein_audit.add_argument(
        "--role-order",
        type=_parse_role_order,
        default=None,
        help="Global crossing-field order such as 1,0,2,3 for external signed-PD sources.",
    )
    homfly_skein_audit.add_argument(
        "--auto-role-order",
        action="store_true",
        help=(
            "Infer a global crossing-field order only when exactly one strict "
            "candidate exists; ambiguous inputs are reported as skipped."
        ),
    )
    homfly_skein_audit.add_argument(
        "--max-crossings",
        type=int,
        default=8,
        help="Maximum crossing count accepted by the bounded HOMFLY evaluator.",
    )
    homfly_skein_audit.add_argument(
        "--max-depth",
        type=int,
        default=16,
        help="Maximum recursive HOMFLY depth per skein branch.",
    )
    homfly_skein_audit.add_argument(
        "--max-nodes",
        type=int,
        default=512,
        help="Maximum recursive HOMFLY nodes per skein branch.",
    )
    homfly_skein_audit.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    homfly_skein_audit.set_defaults(func=_homfly_skein_identity_audit_command)

    role_candidates = subparsers.add_parser(
        "signed-pd-role-order-candidates",
        help="Audit global signed-PD crossing-field role-order candidates.",
    )
    role_candidates.add_argument("path", type=Path, help="Input signed-PD JSON file.")
    role_candidates.add_argument(
        "--include-component-mismatches",
        action="store_true",
        help="Include flow-valid candidates whose component count does not match the diagram.",
    )
    role_candidates.add_argument(
        "--include-invariant-signatures",
        action="store_true",
        help="Compute bounded HOMFLY/Alexander signatures for strict candidates.",
    )
    role_candidates.add_argument(
        "--signature-max-candidates",
        type=int,
        default=8,
        help="Maximum strict role-order candidates to evaluate when signatures are enabled.",
    )
    role_candidates.add_argument(
        "--signature-max-depth",
        type=int,
        default=8,
        help="Maximum recursive HOMFLY depth for candidate signatures.",
    )
    role_candidates.add_argument(
        "--signature-max-nodes",
        type=int,
        default=2048,
        help="Maximum recursive HOMFLY nodes per candidate signature depth attempt.",
    )
    role_candidates.add_argument(
        "--signature-max-minors",
        type=int,
        default=64,
        help="Maximum Fox square minors to scan per Alexander candidate signature.",
    )
    role_candidates.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    role_candidates.set_defaults(func=_signed_pd_role_order_candidates_command)

    homfly_coverage = subparsers.add_parser(
        "homfly-small-diagram-coverage",
        help="Export generated HOMFLY small-diagram coverage evidence.",
    )
    homfly_coverage.add_argument(
        "--notation",
        action="append",
        default=None,
        help="Fixture notation to include. Repeat for multiple fixtures.",
    )
    homfly_coverage.add_argument(
        "--max-depth",
        type=int,
        default=16,
        help="Maximum recursive HOMFLY depth per generated case.",
    )
    homfly_coverage.add_argument(
        "--max-nodes",
        type=int,
        default=4096,
        help="Maximum recursive HOMFLY nodes per generated case.",
    )
    homfly_coverage.add_argument(
        "--branch-depth",
        type=int,
        default=1,
        help="Maximum generated skein-branch depth to audit.",
    )
    homfly_coverage.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    homfly_coverage.set_defaults(func=_homfly_small_diagram_coverage_command)

    source_invariant_candidates = subparsers.add_parser(
        "fixture-source-invariant-candidates",
        help=(
            "Audit source-Gauss-matched signed candidates for an unsigned fixture "
            "and summarize invariant convergence."
        ),
    )
    source_invariant_candidates.add_argument(
        "notation",
        help="Fixture notation such as L5a1 or L6a4.",
    )
    source_invariant_candidates.add_argument(
        "--target-pairwise-linking",
        type=_parse_pairwise_linking,
        default=None,
        help="Override target pairwise-linking values, for example 0 or 0,0,0.",
    )
    source_invariant_candidates.add_argument(
        "--max-orientation-samples",
        type=int,
        default=64,
        help="Maximum local orientation samples to scan before Gauss-code matching.",
    )
    source_invariant_candidates.add_argument(
        "--max-sign-patterns",
        type=int,
        default=None,
        help="Maximum sign patterns to scan. Defaults to all sign patterns.",
    )
    source_invariant_candidates.add_argument(
        "--max-candidates",
        type=int,
        default=64,
        help="Maximum matching candidates to return with invariant signatures.",
    )
    source_invariant_candidates.add_argument(
        "--no-homfly",
        action="store_true",
        help="Skip bounded HOMFLY evaluation for matching candidates.",
    )
    source_invariant_candidates.add_argument(
        "--no-alexander",
        action="store_true",
        help="Skip multi-variable Alexander evaluation for matching candidates.",
    )
    source_invariant_candidates.add_argument("--homfly-max-depth", type=int, default=12)
    source_invariant_candidates.add_argument("--homfly-max-nodes", type=int, default=2048)
    source_invariant_candidates.add_argument(
        "--alexander-max-matrix-size",
        type=int,
        default=5,
    )
    source_invariant_candidates.add_argument(
        "--alexander-max-minors",
        type=int,
        default=128,
    )
    source_invariant_candidates.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    source_invariant_candidates.set_defaults(
        func=_fixture_source_invariant_candidates_command,
    )

    source_table_audit = subparsers.add_parser(
        "fixture-source-table-invariant-audit",
        help=(
            "Compare source-Gauss-matched signed candidates against recorded "
            "source-table invariant values without registering fixture signs."
        ),
    )
    source_table_audit.add_argument(
        "notation",
        help="Fixture notation such as L5a1 or L6a4.",
    )
    source_table_audit.add_argument(
        "--target-pairwise-linking",
        type=_parse_pairwise_linking,
        default=None,
        help="Override target pairwise-linking values, for example 0 or 0,0,0.",
    )
    source_table_audit.add_argument(
        "--max-orientation-samples",
        type=int,
        default=64,
        help="Maximum local orientation samples to scan before Gauss-code matching.",
    )
    source_table_audit.add_argument(
        "--max-sign-patterns",
        type=int,
        default=None,
        help="Maximum sign patterns to scan. Defaults to all sign patterns.",
    )
    source_table_audit.add_argument(
        "--max-candidates",
        type=int,
        default=64,
        help="Maximum matching candidates to return with invariant signatures.",
    )
    source_table_audit.add_argument(
        "--include-homfly",
        action="store_true",
        help="Also compute bounded HOMFLY candidates for the source-table comparison.",
    )
    source_table_audit.add_argument(
        "--no-alexander",
        action="store_true",
        help="Skip multi-variable Alexander candidate computation.",
    )
    source_table_audit.add_argument("--homfly-max-depth", type=int, default=12)
    source_table_audit.add_argument("--homfly-max-nodes", type=int, default=2048)
    source_table_audit.add_argument(
        "--alexander-max-matrix-size",
        type=int,
        default=5,
    )
    source_table_audit.add_argument(
        "--alexander-max-minors",
        type=int,
        default=128,
    )
    source_table_audit.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    source_table_audit.set_defaults(
        func=_fixture_source_table_invariant_audit_command,
    )

    render = subparsers.add_parser(
        "render-report", help="Render a JSON report to static HTML."
    )
    render.add_argument("path", type=Path, help="Input report JSON file.")
    render.add_argument(
        "-o",
        "--output",
        dest="html_output",
        type=Path,
        required=True,
        help="Output HTML file.",
    )
    render.add_argument("--title", default="iroll report")
    render.set_defaults(func=_render_report_command, output=None)

    imgui_geometry = subparsers.add_parser(
        "imgui-geometry-payload",
        help="Convert a JSON analysis report to a Dear ImGui geometry payload.",
    )
    imgui_geometry.add_argument("path", type=Path, help="Input report JSON file.")
    imgui_geometry.add_argument("-o", "--output", type=Path, default=None, help="Output JSON file.")
    imgui_geometry.set_defaults(func=_imgui_geometry_payload_command)

    imgui_link_classification = subparsers.add_parser(
        "imgui-link-classification-summary-payload",
        help="Convert a JSON link report to a Dear ImGui link classification summary payload.",
    )
    imgui_link_classification.add_argument(
        "path",
        type=Path,
        help="Input report JSON file.",
    )
    imgui_link_classification.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    imgui_link_classification.set_defaults(
        func=_imgui_link_classification_summary_payload_command
    )

    imgui_analysis = subparsers.add_parser(
        "imgui-analysis-payload",
        help="Export HOMFLY/Alexander acceptance summaries for Dear ImGui.",
    )
    _add_acceptance_payload_arguments(imgui_analysis)
    _add_homfly_small_coverage_argument(imgui_analysis)
    _add_alexander_signed_pd_coverage_summary_argument(imgui_analysis)
    _add_extra_analysis_report_arguments(imgui_analysis)
    _add_analysis_signed_pd_role_order_arguments(imgui_analysis)
    _add_analysis_source_table_audit_arguments(imgui_analysis)
    imgui_analysis.set_defaults(func=_imgui_analysis_payload_command)

    imgui_analysis_reports = subparsers.add_parser(
        "imgui-analysis-summary-payload",
        help="Flatten existing report JSON files into Dear ImGui analysis summaries.",
    )
    imgui_analysis_reports.add_argument(
        "paths",
        nargs="+",
        type=Path,
        help="Input report JSON files to summarize for IrollAnalysisSummary loading.",
    )
    imgui_analysis_reports.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    imgui_analysis_reports.set_defaults(func=_imgui_analysis_summary_payload_command)

    imgui_invariants = subparsers.add_parser(
        "imgui-invariant-status-payload",
        help="Export HOMFLY/Alexander invariant-status rows for Dear ImGui.",
    )
    _add_acceptance_payload_arguments(imgui_invariants)
    imgui_invariants.set_defaults(func=_imgui_invariant_status_payload_command)

    imgui_invariant_reports = subparsers.add_parser(
        "imgui-invariant-status-summary-payload",
        help="Flatten existing invariant report JSON files into Dear ImGui status rows.",
    )
    imgui_invariant_reports.add_argument(
        "paths",
        nargs="+",
        type=Path,
        help="Input acceptance, HOMFLY-PD, or Alexander-PD report JSON files.",
    )
    imgui_invariant_reports.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    imgui_invariant_reports.set_defaults(func=_imgui_invariant_status_summary_payload_command)

    imgui_signed_pd_invariants = subparsers.add_parser(
        "imgui-signed-pd-invariant-status-payload",
        help="Compute HOMFLY/Alexander from signed-PD JSON and emit Dear ImGui invariant rows.",
    )
    imgui_signed_pd_invariants.add_argument("path", type=Path, help="Input signed-PD JSON file.")
    imgui_signed_pd_invariants.add_argument(
        "--variable",
        action="append",
        default=None,
        help="Component variable name. Repeat for multi-component diagrams.",
    )
    imgui_signed_pd_invariants.add_argument(
        "--role-order",
        type=_parse_role_order,
        default=None,
        help="Global crossing-field order such as 1,0,2,3 for external signed-PD sources.",
    )
    imgui_signed_pd_invariants.add_argument(
        "--auto-role-order",
        action="store_true",
        help="Infer a global role order only when exactly one strict candidate exists.",
    )
    imgui_signed_pd_invariants.add_argument("--max-crossings", type=int, default=8)
    imgui_signed_pd_invariants.add_argument("--initial-depth", type=int, default=0)
    imgui_signed_pd_invariants.add_argument("--max-depth", type=int, default=16)
    imgui_signed_pd_invariants.add_argument("--max-nodes", type=int, default=4096)
    imgui_signed_pd_invariants.add_argument("--target-size", type=int, default=None)
    imgui_signed_pd_invariants.add_argument("--max-matrix-size", type=int, default=4)
    imgui_signed_pd_invariants.add_argument("--max-minors", type=int, default=64)
    imgui_signed_pd_invariants.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )
    imgui_signed_pd_invariants.set_defaults(func=_imgui_signed_pd_invariant_status_payload_command)

    imgui_fixtures = subparsers.add_parser(
        "imgui-fixture-comparison-payload",
        help="Export HOMFLY/Alexander fixture comparison rows for Dear ImGui.",
    )
    _add_acceptance_payload_arguments(imgui_fixtures)
    imgui_fixtures.set_defaults(func=_imgui_fixture_comparison_payload_command)

    imgui_signed_pd = subparsers.add_parser(
        "imgui-signed-pd-payload",
        help="Export fixture signed-PD records for Dear ImGui.",
    )
    _add_acceptance_payload_arguments(imgui_signed_pd)
    imgui_signed_pd.set_defaults(func=_imgui_signed_pd_payload_command)

    imgui_backend_status = subparsers.add_parser(
        "imgui-kernel-backend-status-payload",
        help="Export numeric backend diagnostics as Dear ImGui rows.",
    )
    imgui_backend_status.add_argument("-o", "--output", type=Path, default=None, help="Output JSON file.")
    imgui_backend_status.set_defaults(func=_imgui_kernel_backend_status_payload_command)

    imgui_host = subparsers.add_parser(
        "imgui-host-payload",
        help="Export a combined Dear ImGui host payload bundle.",
    )
    imgui_host.add_argument(
        "--geometry-report",
        type=Path,
        default=None,
        help="Optional analysis report JSON to include as geometry payload.",
    )
    _add_acceptance_payload_arguments(imgui_host)
    _add_homfly_small_coverage_argument(imgui_host)
    _add_alexander_signed_pd_coverage_summary_argument(imgui_host)
    _add_extra_analysis_report_arguments(imgui_host)
    _add_extra_invariant_report_arguments(imgui_host)
    _add_analysis_signed_pd_role_order_arguments(imgui_host)
    _add_analysis_source_table_audit_arguments(imgui_host)
    imgui_host.set_defaults(func=_imgui_host_payload_command)

    return parser


def _analyze_curve_command(args: argparse.Namespace) -> dict:
    curve = Polyline3D(load_points(args.path), closed=args.closed, name=args.name)
    closure = None
    if args.closure_method is not None:
        closure = {
            "method": args.closure_method,
            "samples": args.closure_samples,
            "seed": args.closure_seed,
            "scale": args.closure_scale,
        }
    return analyze_curve(
        curve,
        closure=closure,
        direction=_parse_direction(args.direction),
        backend=args.backend,
        contact_threshold=args.contact_threshold,
        max_contacts=args.max_contacts,
        include_diagram_matrix=args.include_diagram_matrix,
        subchain_window_points=args.subchain_window_points,
        subchain_step=args.subchain_step,
        subchain_max_windows=args.subchain_max_windows,
        adapter=args.adapter,
    )


def _analyze_link_command(args: argparse.Namespace) -> dict:
    components = [
        Polyline3D(load_points(path), closed=args.closed, name=path.stem)
        for path in args.paths
    ]
    return analyze_link(
        Link3D(components, name=args.name),
        direction=_parse_direction(args.direction),
        backend=args.backend,
        contact_threshold=args.contact_threshold,
        max_contacts=args.max_contacts,
    )


def _analyze_ribbon_command(args: argparse.Namespace) -> dict:
    ribbon = load_ribbon_json(args.path, closed=args.closed, name=args.name)
    return analyze_ribbon(
        ribbon,
        backend=args.backend,
        contact_threshold=args.contact_threshold,
        max_contacts=args.max_contacts,
    )


def _adapters_command(args: argparse.Namespace) -> dict:
    return {"adapters": list_available_adapters()}


def _validate_command(args: argparse.Namespace) -> dict:
    return run_validation(count=args.points)


def _backends_command(args: argparse.Namespace) -> dict:
    return backend_report()


def _rust_unsupported_invariant_result_handle_report_command(
    args: argparse.Namespace,
) -> dict:
    return rust_unsupported_invariant_result_handle_report(args.invariant)


def _knot_table_command(args: argparse.Namespace) -> dict:
    return {"knots": builtin_knot_table()}


def _link_table_command(args: argparse.Namespace) -> dict:
    return {"links": builtin_link_table()}


def _validate_table_command(args: argparse.Namespace) -> dict:
    return validate_table_file(
        args.path,
        kind=args.kind,
        expected_convention=args.expected_convention,
    )


def _fixture_validation_pack_audit_command(args: argparse.Namespace) -> dict:
    completion_evidence_bundle = None
    if args.completion_evidence_bundle_json is not None:
        completion_evidence_bundle = json.loads(
            args.completion_evidence_bundle_json.read_text(encoding="utf-8-sig")
        )
    verified_signed_assignments = []
    for path in args.verified_signed_crossing_assignment_json or []:
        verified_signed_assignments.append(
            json.loads(path.read_text(encoding="utf-8-sig"))
        )
    production_imgui_pack = None
    if args.production_imgui_renderer_framebuffer_pack_json is not None:
        production_imgui_pack = json.loads(
            args.production_imgui_renderer_framebuffer_pack_json.read_text(
                encoding="utf-8-sig"
            )
        )
    signed_release_manifest = None
    if args.signed_release_publication_manifest_json is not None:
        signed_release_manifest = json.loads(
            args.signed_release_publication_manifest_json.read_text(
                encoding="utf-8-sig"
            )
        )
    homfly_certification_pack = None
    if args.full_homfly_pt_evaluation_certification_pack_json is not None:
        homfly_certification_pack = json.loads(
            args.full_homfly_pt_evaluation_certification_pack_json.read_text(
                encoding="utf-8-sig"
            )
        )
    alexander_certification_pack = None
    if (
        args.full_multivariable_alexander_normalization_certification_pack_json
        is not None
    ):
        alexander_certification_pack = json.loads(
            args.full_multivariable_alexander_normalization_certification_pack_json.read_text(
                encoding="utf-8-sig"
            )
        )
    report = cross_workstream_validation_pack_audit(
        required_notations=args.notation,
        completion_evidence_bundle=completion_evidence_bundle,
        verified_signed_crossing_assignments=verified_signed_assignments,
        production_imgui_renderer_framebuffer_pack=production_imgui_pack,
        signed_release_publication_manifest=signed_release_manifest,
        full_homfly_pt_evaluation_certification_pack=homfly_certification_pack,
        full_multivariable_alexander_normalization_certification_pack=(
            alexander_certification_pack
        ),
    )
    ci_exit_code = (
        1
        if args.fail_on_not_ready and report["final_completion_ready"] is not True
        else 0
    )
    report["_exit_code"] = ci_exit_code
    report["ci_fail_on_not_ready"] = args.fail_on_not_ready
    report["ci_exit_code"] = ci_exit_code
    return report


def _verified_signed_crossing_assignment_audit_command(
    args: argparse.Namespace,
) -> dict:
    assignment = json.loads(args.path.read_text(encoding="utf-8-sig"))
    report = verified_signed_crossing_assignment_audit(assignment)
    _add_completion_evidence_producer_metadata(
        report,
        missing_artifact="verified_signed_crossing_assignment",
    )
    ci_exit_code = (
        1
        if args.fail_on_not_certified
        and report["assignment_certified"] is not True
        else 0
    )
    report["_exit_code"] = ci_exit_code
    report["ci_fail_on_not_certified"] = args.fail_on_not_certified
    report["ci_exit_code"] = ci_exit_code
    return report


def _knot_atlas_pinned_revision_url(title: str, revision_id: int) -> str:
    return "https://katlas.org/index.php?" + urlencode(
        {
            "title": title,
            "oldid": revision_id,
            "action": "raw",
        }
    )


def _fetch_knot_atlas_pinned_witness(
    title: str,
    revision_id: int,
    expected_sha256: str,
    *,
    timeout: float,
) -> dict:
    url = _knot_atlas_pinned_revision_url(title, revision_id)
    witness = {
        "title": title,
        "revision_id": revision_id,
        "url": url,
        "expected_sha256": expected_sha256,
        "actual_sha256": "",
        "byte_count": 0,
        "fetched": False,
        "sha256_verified": False,
        "error": None,
        "_content": "",
    }
    try:
        request = Request(
            url,
            headers={"User-Agent": "iroll-completion-evidence/1.0"},
        )
        with urlopen(request, timeout=timeout) as response:
            content = response.read()
        actual_sha256 = sha256(content).hexdigest()
        witness.update(
            {
                "actual_sha256": actual_sha256,
                "byte_count": len(content),
                "fetched": True,
                "sha256_verified": actual_sha256 == expected_sha256,
                "_content": content.decode("utf-8"),
            }
        )
    except Exception as exc:  # pragma: no cover - exercised by network failures
        witness["error"] = f"{type(exc).__name__}: {exc}"
    return witness


def _fetch_pinned_url_witness(
    *,
    title: str,
    revision_id: int,
    url: str,
    expected_sha256: str,
    timeout: float,
) -> dict:
    """Fetch one exact URL and retain a fail-closed SHA-256 witness."""

    witness = {
        "title": title,
        "revision_id": revision_id,
        "url": url,
        "expected_sha256": expected_sha256,
        "actual_sha256": "",
        "byte_count": 0,
        "fetched": False,
        "sha256_verified": False,
        "error": None,
        "_content": "",
    }
    try:
        request = Request(
            url,
            headers={"User-Agent": "iroll-completion-evidence/1.0"},
        )
        with urlopen(request, timeout=timeout) as response:
            content = response.read()
        actual_sha256 = sha256(content).hexdigest()
        witness.update(
            {
                "actual_sha256": actual_sha256,
                "byte_count": len(content),
                "fetched": True,
                "sha256_verified": actual_sha256 == expected_sha256,
                "_content": content.decode("utf-8"),
            }
        )
    except Exception as exc:  # pragma: no cover - exercised by network failures
        witness["error"] = f"{type(exc).__name__}: {exc}"
    return witness


def _knot_atlas_pd_source_matches_fixture(content: str, fixture) -> bool:
    if fixture.pd_code is None:
        return False
    source_codes = [
        re.sub(r"[^0-9]", "", value)
        for value in re.findall(r"X<sub>([^<]+)</sub>", content)
    ]
    fixture_codes = [
        "".join(str(edge) for edge in crossing) for crossing in fixture.pd_code
    ]
    return source_codes == fixture_codes


def _knot_atlas_gauss_source_matches_fixture(content: str, fixture) -> bool:
    if fixture.gauss_code is None:
        return False
    try:
        source_gauss = tuple(
            tuple(int(value.strip()) for value in component.split(","))
            for component in re.findall(r"\{([^}]+)\}", content)
        )
    except ValueError:
        return False
    return source_gauss == fixture.gauss_code


def _knot_atlas_invariant_table_value_audit(
    fixture,
    pinned: Mapping[str, Mapping[str, object]],
    witnesses: Mapping[str, Mapping[str, object]],
) -> dict:
    fixture_fields = {
        "jones": "source_table_jones",
        "homfly": "source_table_homfly",
        "multivariable_alexander": "source_table_multivariable_alexander",
    }
    rows = []
    for role, fixture_field in fixture_fields.items():
        declaration = pinned[role]
        witness = witnesses[role]
        expected_math_source = re.sub(
            r"\s+", "", str(declaration.get("expected_math_source") or "")
        )
        actual_math_source = re.sub(
            r"\s+", "", str(witness.get("_content") or "")
        )
        expected_fixture_value = str(
            declaration.get("expected_fixture_value") or ""
        )
        actual_fixture_value = getattr(fixture, fixture_field, None)
        rows.append(
            {
                "role": role,
                "fixture_field": fixture_field,
                "source_revision_sha256_verified": (
                    witness.get("sha256_verified") is True
                ),
                "source_math_matches_pinned_declaration": (
                    bool(expected_math_source)
                    and actual_math_source == expected_math_source
                ),
                "fixture_value_matches_pinned_declaration": (
                    bool(expected_fixture_value)
                    and actual_fixture_value == expected_fixture_value
                ),
                "expected_fixture_value": expected_fixture_value,
                "actual_fixture_value": actual_fixture_value,
            }
        )
    return {
        "rows": rows,
        "source_revision_sha256s_verified": all(
            row["source_revision_sha256_verified"] for row in rows
        ),
        "source_values_match_pinned_declarations": all(
            row["source_math_matches_pinned_declaration"] for row in rows
        ),
        "fixture_values_match_pinned_declarations": all(
            row["fixture_value_matches_pinned_declaration"] for row in rows
        ),
        "verified": all(
            row["source_revision_sha256_verified"]
            and row["source_math_matches_pinned_declaration"]
            and row["fixture_value_matches_pinned_declaration"]
            for row in rows
        ),
    }


def _public_knot_atlas_witness(witness: Mapping[str, object], *, role: str) -> dict:
    return {
        "role": role,
        **{key: value for key, value in witness.items() if not key.startswith("_")},
    }


def _verified_signed_crossing_assignment_producer_command(
    args: argparse.Namespace,
) -> dict:
    fixture = get_diagram_fixture(args.notation)
    derivation = fixture.source_pd_convention_assignment_audit()
    pinned = _KNOT_ATLAS_PINNED_ASSIGNMENT_SOURCES[args.notation]
    convention_pinned = _KNOT_ATLAS_PINNED_ASSIGNMENT_SOURCES["Planar Diagrams"]
    convention = _fetch_knot_atlas_pinned_witness(
        "Planar Diagrams",
        int(convention_pinned["revision_id"]),
        str(convention_pinned["sha256"]),
        timeout=args.network_timeout,
    )
    witnesses = {
        role: _fetch_knot_atlas_pinned_witness(
            str(record["title"]),
            int(record["revision_id"]),
            str(record["sha256"]),
            timeout=args.network_timeout,
        )
        for role, record in pinned.items()
    }

    convention_content = str(convention.get("_content") or "")
    convention_semantics_verified = all(
        phrase in convention_content
        for phrase in (
            "increasing labels as we go around each component",
            "starting from the incoming lower edge and proceeding counterclockwise",
            "upper strand is therefore oriented from l to j",
            "upper strand is therefore oriented from j to l",
        )
    )
    pd_source_matches = _knot_atlas_pd_source_matches_fixture(
        str(witnesses["pd_presentation"].get("_content") or ""),
        fixture,
    )
    gauss_source_matches = _knot_atlas_gauss_source_matches_fixture(
        str(witnesses["gauss_code"].get("_content") or ""),
        fixture,
    )
    invariant_roles = ("jones", "homfly", "multivariable_alexander")
    invariant_value_audit = _knot_atlas_invariant_table_value_audit(
        fixture,
        pinned,
        witnesses,
    )
    invariant_witnesses_verified = invariant_value_audit[
        "source_revision_sha256s_verified"
    ]
    invariant_values_available = all(
        row["actual_fixture_value"] is not None
        for row in invariant_value_audit["rows"]
    )
    unique_assignment_certified = all(
        (
            derivation.get("assignment_unique_under_source_convention") is True,
            convention.get("sha256_verified") is True,
            convention_semantics_verified,
            witnesses["pd_presentation"].get("sha256_verified") is True,
            witnesses["gauss_code"].get("sha256_verified") is True,
            pd_source_matches,
            gauss_source_matches,
        )
    )

    replay = json.loads(
        json.dumps(derivation.get("candidate_replay") or {}, allow_nan=False)
    )
    replay.update(
        {
            "source_url": witnesses["pd_presentation"]["url"],
            "source_revision_id": witnesses["pd_presentation"]["revision_id"],
            "source_sha256": witnesses["pd_presentation"]["actual_sha256"],
            "source_gauss_code_url": witnesses["gauss_code"]["url"],
            "source_gauss_code_revision_id": witnesses["gauss_code"]["revision_id"],
            "source_gauss_code_sha256": witnesses["gauss_code"]["actual_sha256"],
            "source_convention_url": convention["url"],
            "source_convention_revision_id": convention["revision_id"],
            "source_convention_sha256": convention["actual_sha256"],
        }
    )
    replay_bytes = json.dumps(
        replay,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    source_candidate_replay_valid = all(
        (
            derivation.get("source_candidate_replay_valid") is True,
            pd_source_matches,
            gauss_source_matches,
            witnesses["pd_presentation"].get("sha256_verified") is True,
            witnesses["gauss_code"].get("sha256_verified") is True,
        )
    )
    invariant_table_values_verified = invariant_value_audit["verified"]
    producer_checks = {
        "source_convention_revision_sha256_verified": (
            convention.get("sha256_verified") is True
        ),
        "source_convention_semantics_verified": convention_semantics_verified,
        "source_pd_revision_sha256_verified": (
            witnesses["pd_presentation"].get("sha256_verified") is True
        ),
        "source_pd_matches_fixture": pd_source_matches,
        "source_gauss_code_revision_sha256_verified": (
            witnesses["gauss_code"].get("sha256_verified") is True
        ),
        "source_gauss_code_matches_fixture": gauss_source_matches,
        "local_assignment_unique_under_source_convention": (
            derivation.get("assignment_unique_under_source_convention") is True
        ),
        "source_candidate_replay_valid": source_candidate_replay_valid,
        "invariant_table_revision_sha256s_verified": invariant_witnesses_verified,
        "invariant_table_values_available": invariant_values_available,
        "invariant_table_source_values_match_pinned_declarations": (
            invariant_value_audit["source_values_match_pinned_declarations"]
        ),
        "invariant_table_fixture_values_match_pinned_declarations": (
            invariant_value_audit["fixture_values_match_pinned_declarations"]
        ),
    }
    producer_failed_checks = [
        name for name, passed in producer_checks.items() if not passed
    ]
    artifact = {
        "artifact_schema_version": 1,
        "artifact_kind": "verified_signed_crossing_assignment",
        "claim_scope": "verified_signed_crossing_assignment",
        "notation": args.notation,
        "source_url": witnesses["pd_presentation"]["url"],
        "crossing_count": int(derivation.get("crossing_count") or 0),
        "signs": list(derivation.get("signs") or []),
        "role_orders": list(derivation.get("role_orders") or []),
        "source_gauss_code_match": (
            derivation.get("source_gauss_code_exact_match") is True
            and gauss_source_matches
        ),
        "source_candidate_replay_valid": source_candidate_replay_valid,
        "candidate_replay_sha256": sha256(replay_bytes).hexdigest(),
        "unique_assignment_certified": unique_assignment_certified,
        "invariant_table_values_verified": invariant_table_values_verified,
        "invariant_table_source_urls": [
            witnesses[role]["url"] for role in invariant_roles
        ],
        "invariant_table_source_sha256s": [
            witnesses[role]["actual_sha256"] for role in invariant_roles
        ],
        "orientation_validation_issue_count": int(
            derivation.get("orientation_validation_issue_count") or 0
        ),
        "source_method": (
            "iroll verified-signed-crossing-assignment-producer with pinned "
            "Knot Atlas revisions"
        ),
        "source_convention": derivation.get("source_convention"),
        "source_convention_url": convention["url"],
        "source_convention_sha256": convention["actual_sha256"],
        "source_gauss_code_url": witnesses["gauss_code"]["url"],
        "source_gauss_code_sha256": witnesses["gauss_code"]["actual_sha256"],
        "source_pd_sha256": witnesses["pd_presentation"]["actual_sha256"],
        "candidate_replay_digest_scope": "canonical_utf8_json_sort_keys_compact",
        "candidate_replay": replay,
        "source_table_values": {
            "jones": fixture.source_table_jones,
            "homfly": fixture.source_table_homfly,
            "multivariable_alexander": (
                fixture.source_table_multivariable_alexander
            ),
        },
        "invariant_table_value_checks": invariant_value_audit["rows"],
        "producer_checks": producer_checks,
        "producer_check_count": len(producer_checks),
        "producer_failed_check_count": len(producer_failed_checks),
        "producer_failed_checks": producer_failed_checks,
        "source_witnesses": [
            _public_knot_atlas_witness(convention, role="source_convention"),
            *[
                _public_knot_atlas_witness(witnesses[role], role=role)
                for role in (
                    "pd_presentation",
                    "gauss_code",
                    *invariant_roles,
                )
            ],
        ],
        "local_derivation": derivation,
        "completion_claimed": False,
        "template_placeholder": False,
    }
    preflight = verified_signed_crossing_assignment_audit(artifact)
    artifact["producer_preflight_assignment_certified"] = preflight[
        "assignment_certified"
    ]
    artifact["producer_preflight_failed_check_count"] = preflight[
        "failed_check_count"
    ]
    artifact["producer_preflight_failed_checks"] = preflight["failed_checks"]
    artifact["completion_claimed"] = preflight["assignment_certified"] is True
    ci_exit_code = (
        1
        if args.fail_on_not_certified
        and preflight["assignment_certified"] is not True
        else 0
    )
    artifact["_exit_code"] = ci_exit_code
    artifact["ci_fail_on_not_certified"] = args.fail_on_not_certified
    artifact["ci_exit_code"] = ci_exit_code
    return artifact


def _knot_atlas_homfly_source_url(record: Mapping[str, object]) -> str:
    # MediaWiki honours ``title`` while the distinct PATH_INFO suffix gives
    # every retained witness a distinct URL filename for evidence auditing.
    slug = str(record["url_slug"])
    return f"https://katlas.org/index.php/{slug}?" + urlencode(
        {
            "title": str(record["title"]),
            "oldid": int(record["revision_id"]),
            "action": "raw",
        }
    )


def _fetch_url_sha256_witness(
    url: str,
    expected_sha256: str,
    *,
    timeout: float,
    title: str | None = None,
    revision_id: int | None = None,
) -> dict:
    witness = {
        "title": title,
        "revision_id": revision_id,
        "url": url,
        "expected_sha256": expected_sha256,
        "actual_sha256": "",
        "byte_count": 0,
        "fetched": False,
        "sha256_verified": False,
        "error": None,
        "_content": "",
        "_bytes": b"",
    }
    try:
        request = Request(
            url,
            headers={"User-Agent": "iroll-completion-evidence/1.0"},
        )
        with urlopen(request, timeout=timeout) as response:
            content = response.read()
        actual_sha256 = sha256(content).hexdigest()
        witness.update(
            {
                "actual_sha256": actual_sha256,
                "byte_count": len(content),
                "fetched": True,
                "sha256_verified": actual_sha256 == expected_sha256,
                "_content": content.decode("utf-8"),
                "_bytes": content,
            }
        )
    except Exception as exc:  # pragma: no cover - exercised by network failures
        witness["error"] = f"{type(exc).__name__}: {exc}"
    return witness


def _homfly_polynomial_equal(first: str | None, second: str | None) -> bool:
    if first is None or second is None:
        return False
    try:
        first_polynomial = parse_multivariate_laurent_polynomial(
            first,
            variables=("a", "z"),
        )
        second_polynomial = parse_multivariate_laurent_polynomial(
            second,
            variables=("a", "z"),
        )
    except ValueError:
        return False
    return first_polynomial == second_polynomial


def _homfly_complete_certification_case(notation: str) -> dict:
    return _replay_homfly_complete_certification_case(notation)


def _homfly_full_certification_report_command(args: argparse.Namespace) -> dict:
    witnesses = {}
    for role, record in _KNOT_ATLAS_PINNED_HOMFLY_SOURCES.items():
        witnesses[role] = _fetch_url_sha256_witness(
            _knot_atlas_homfly_source_url(record),
            str(record["sha256"]),
            timeout=args.network_timeout,
            title=str(record["title"]),
            revision_id=int(record["revision_id"]),
        )

    definition_record = _KNOT_ATLAS_PINNED_HOMFLY_SOURCES["definition"]
    definition_content = str(witnesses["definition"].get("_content") or "")
    definition_semantics_verified = all(
        phrase in definition_content
        for phrase in definition_record["required_phrases"]
    )
    source_value_rows = []
    for notation in ("4_1", "L5a1", "L6a4"):
        record = _KNOT_ATLAS_PINNED_HOMFLY_SOURCES[notation]
        witness = witnesses[notation]
        source_value_rows.append(
            {
                "notation": notation,
                "url": witness["url"],
                "revision_id": witness["revision_id"],
                "sha256": witness["actual_sha256"],
                "source_revision_sha256_verified": (
                    witness.get("sha256_verified") is True
                ),
                "source_math_matches_pinned_declaration": (
                    re.sub(r"\s+", "", str(witness.get("_content") or ""))
                    == re.sub(r"\s+", "", str(record["expected_math_source"]))
                ),
                "expected_polynomial": record["expected_polynomial"],
            }
        )

    case_rows = [
        _homfly_complete_certification_case(notation)
        for notation in ("0_1", "L0a1", "L2a1", "3_1", "4_1", "L5a1", "L6a4")
    ]
    cases_by_notation = {row["notation"]: row for row in case_rows}
    external_normalization_rows = []
    for source_row in source_value_rows:
        case = cases_by_notation[source_row["notation"]]
        external_normalization_rows.append(
            {
                **source_row,
                "computed_polynomial": case["observed_homfly"],
                "computed_polynomial_matches_external_table": (
                    source_row["source_revision_sha256_verified"]
                    and source_row["source_math_matches_pinned_declaration"]
                    and _homfly_polynomial_equal(
                        str(case["observed_homfly"]),
                        str(source_row["expected_polynomial"]),
                    )
                ),
                "complete_evaluation_certified_for_input": (
                    case["case_certified"] is True
                ),
            }
        )

    from inspect import getsource, signature

    implementation_source = getsource(homfly_complete_evaluation_from_pd)
    implementation_bytes = implementation_source.encode("utf-8")
    implementation_parameters = list(
        signature(homfly_complete_evaluation_from_pd).parameters
    )
    implementation_bundle = homfly_implementation_bundle_witness()
    implementation_contract_checks = {
        "only_diagram_and_orientation_parameters": (
            implementation_parameters == ["diagram", "orientation"]
        ),
        "explicit_work_list_present": "while stack:" in implementation_source,
        "switch_measure_comparison_present": (
            "switch_measure < parent_measure" in implementation_source
        ),
        "smooth_measure_comparison_present": (
            "smooth_measure < parent_measure" in implementation_source
        ),
        "no_depth_or_node_cutoff_parameter": all(
            name not in implementation_parameters
            for name in ("max_crossings", "max_depth", "max_nodes")
        ),
        "free_circle_component_count_retained": (
            "diagram.component_count" in implementation_source
        ),
        "implementation_bundle_covers_complete_runtime_modules": (
            implementation_bundle["module_count"] == 3
            and [row["module"] for row in implementation_bundle["modules"]]
            == [
                "iroll.topology.homfly",
                "iroll.topology.pd",
                "iroll.topology.polynomial",
            ]
        ),
    }
    formal_termination_argument = {
        "domain": "finite valid oriented signed planar diagrams",
        "measure": "lexicographic(crossing_count,bad_crossing_count) in N x N",
        "terminal": (
            "bad_crossing_count=0 is a descending diagram and therefore an unlink; "
            "all free circles are included in component_count"
        ),
        "switch_branch": (
            "switching the first under-first crossing preserves crossing_count "
            "and oriented traversal while reducing bad_crossing_count by one"
        ),
        "smoothing_branch": (
            "oriented smoothing removes exactly one crossing, so crossing_count "
            "strictly decreases regardless of the child bad-crossing count"
        ),
        "well_foundedness": (
            "the lexicographic order on N x N is well founded; every work-list "
            "dependency terminates at a descending unlink"
        ),
        "resource_boundary": (
            "worst-case time and storage are exponential; resource exhaustion "
            "aborts report production and is never converted into certification"
        ),
    }
    report_checks = {
        "all_pinned_source_sha256s_verified": all(
            witness.get("sha256_verified") is True
            for witness in witnesses.values()
        ),
        "definition_semantics_verified": definition_semantics_verified,
        "all_external_source_values_verified": all(
            row["source_math_matches_pinned_declaration"]
            for row in source_value_rows
        ),
        "implementation_contract_verified": all(
            implementation_contract_checks.values()
        ),
        "all_registered_fixture_regressions_certified": all(
            row["case_certified"] for row in case_rows
        ),
        "all_transition_termination_measures_certified": all(
            row["evaluation"]["termination_measure_certified"]
            for row in case_rows
        ),
        "all_exact_skein_replays_certified": all(
            row["evaluation"]["skein_replay_certified"] for row in case_rows
        ),
        "all_terminal_normalizations_certified": all(
            row["evaluation"]["terminal_normalization_certified"]
            for row in case_rows
        ),
        "external_table_normalization_certified": all(
            row["computed_polynomial_matches_external_table"]
            and row["complete_evaluation_certified_for_input"]
            for row in external_normalization_rows
        ),
        "resource_cutoffs_absent": all(
            row["evaluation"]["resource_cutoffs_used"] is False
            for row in case_rows
        ),
        "frontiers_empty": all(
            int(row["evaluation"]["frontier_count"]) == 0 for row in case_rows
        ),
    }
    failed_checks = [name for name, passed in report_checks.items() if not passed]
    counterexamples = [
        {
            "notation": row["notation"],
            "failed_checks": row["case_failed_checks"],
        }
        for row in case_rows
        if not row["case_certified"]
    ]
    certified = not failed_checks and not counterexamples
    report = {
        "artifact_schema_version": 1,
        "artifact_kind": "full_homfly_pt_evaluation_certification_report",
        "claim_scope": "full_homfly_pt_evaluation_mathematical_and_external_normalization_certificate",
        "method": "cutoff_free_descending_diagram_skein_certification",
        "normalization": (
            "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1; "
            "P(unlink_c)=((a-a^-1)/z)^(c-1)"
        ),
        "algorithm_scope": "arbitrary_finite_valid_oriented_signed_pd",
        "certified": certified,
        "arbitrary_signed_pd_coverage_certified": certified,
        "external_table_normalization_certified": report_checks[
            "external_table_normalization_certified"
        ],
        "skein_relation_certified": (
            definition_semantics_verified
            and report_checks["all_exact_skein_replays_certified"]
        ),
        "registered_fixture_regression_certified": report_checks[
            "all_registered_fixture_regressions_certified"
        ],
        "counterexample_count": len(counterexamples),
        "counterexamples": counterexamples,
        "report_check_count": len(report_checks),
        "report_failed_check_count": len(failed_checks),
        "report_failed_checks": failed_checks,
        "report_checks": report_checks,
        "formal_termination_argument": formal_termination_argument,
        "implementation_function": (
            "iroll.topology.homfly.homfly_complete_evaluation_from_pd"
        ),
        "implementation_parameters": implementation_parameters,
        "implementation_source_sha256": sha256(implementation_bytes).hexdigest(),
        "implementation_source_utf8_byte_count": len(implementation_bytes),
        "implementation_bundle_sha256": implementation_bundle["bundle_sha256"],
        "implementation_bundle": implementation_bundle,
        "implementation_contract_checks": implementation_contract_checks,
        "source_witnesses": [
            _public_knot_atlas_witness(witnesses[role], role=role)
            for role in ("definition", "4_1", "L5a1", "L6a4")
        ],
        "external_normalization_rows": external_normalization_rows,
        "case_count": len(case_rows),
        "cases": case_rows,
        "total_state_count": sum(
            int(row["evaluation"]["state_count"]) for row in case_rows
        ),
        "total_transition_count": sum(
            int(row["evaluation"]["transition_count"]) for row in case_rows
        ),
        "total_terminal_count": sum(
            int(row["evaluation"]["terminal_count"]) for row in case_rows
        ),
        "completion_claimed": certified,
        "notes": [
            "external values are compared as exact sparse Laurent polynomials, not display strings",
            "the complete evaluator has no max_crossings, max_depth, or max_nodes fallback",
            "a MemoryError or process failure prevents this report from being emitted",
            "the finite table cases validate normalization; arbitrary-input coverage follows from the recorded well-founded skein recursion",
        ],
    }
    ci_exit_code = 1 if args.fail_on_not_certified and not certified else 0
    report["_exit_code"] = ci_exit_code
    report["ci_fail_on_not_certified"] = args.fail_on_not_certified
    report["ci_exit_code"] = ci_exit_code
    return report


def _homfly_full_certification_pack_producer_command(
    args: argparse.Namespace,
) -> dict:
    report_bytes = args.certification_report_json.read_bytes()
    report_sha256 = sha256(report_bytes).hexdigest()
    report = json.loads(report_bytes.decode("utf-8-sig"))
    report_canonical_sha256 = canonical_json_sha256(report)
    report_deterministic_raw_sha256 = serialized_certification_report_sha256(
        report
    )
    report_audit = full_homfly_pt_evaluation_certification_report_audit(report)
    report_url = str(args.certification_report_url or "")
    published_witness = (
        _fetch_url_sha256_witness(
            report_url,
            report_sha256,
            timeout=args.network_timeout,
            title="published full HOMFLY-PT evaluation certification report",
        )
        if report_url
        else {
            "title": "published full HOMFLY-PT evaluation certification report",
            "revision_id": None,
            "url": "",
            "expected_sha256": report_sha256,
            "actual_sha256": "",
            "byte_count": 0,
            "fetched": False,
            "sha256_verified": False,
            "error": "certification_report_url not supplied",
            "_content": "",
            "_bytes": b"",
        }
    )
    published_report = None
    try:
        published_report = json.loads(
            bytes(published_witness.get("_bytes") or b"").decode("utf-8-sig")
        )
    except (TypeError, UnicodeDecodeError, ValueError):
        pass
    published_report_canonical_sha256 = (
        canonical_json_sha256(published_report)
        if isinstance(published_report, Mapping)
        else ""
    )
    published_report_json_matches = bool(
        isinstance(published_report, Mapping)
        and published_report_canonical_sha256 == report_canonical_sha256
    )
    published_report_verified = bool(
        published_witness.get("fetched") is True
        and published_witness.get("sha256_verified") is True
        and published_witness.get("expected_sha256") == report_sha256
        and published_witness.get("actual_sha256") == report_sha256
        and published_witness.get("byte_count") == len(report_bytes)
        and report_sha256 == report_deterministic_raw_sha256
        and published_report_json_matches
    )

    source_witnesses = [
        row
        for row in report.get("source_witnesses", [])
        if isinstance(row, Mapping)
    ]
    external_table_source_urls = [str(row.get("url") or "") for row in source_witnesses]
    external_table_source_sha256s = [
        str(row.get("actual_sha256") or "") for row in source_witnesses
    ]
    core_certified = bool(
        report_audit.get("certified") is True
        and report_sha256 == report_deterministic_raw_sha256
    )
    full_certified = core_certified and published_report_verified
    producer_checks = {
        "local_report_replay_audit_certified": core_certified,
        "local_report_canonical_sha256_available": (
            len(report_canonical_sha256) == 64
        ),
        "local_report_raw_sha256_matches_deterministic_serializer": (
            report_sha256 == report_deterministic_raw_sha256
        ),
        "embedded_certification_report_available": isinstance(report, Mapping),
        "published_report_fetched": published_witness.get("fetched") is True,
        "published_report_sha256_matches_local_bytes": published_report_verified,
        "published_report_json_matches_embedded_report": (
            published_report_json_matches
        ),
        "published_report_canonical_sha256_matches_local_report": (
            published_report_canonical_sha256 == report_canonical_sha256
        ),
    }
    producer_failed_checks = [
        name for name, passed in producer_checks.items() if not passed
    ]
    pack = {
        "artifact_schema_version": 1,
        "artifact_kind": "full_homfly_pt_evaluation_certification_pack",
        "claim_scope": "full_homfly_pt_evaluation",
        "full_homfly_pt_evaluation_certified": full_certified,
        "arbitrary_signed_pd_coverage_certified": (
            full_certified
            and report.get("arbitrary_signed_pd_coverage_certified") is True
        ),
        "external_table_normalization_certified": (
            full_certified
            and report.get("external_table_normalization_certified") is True
        ),
        "skein_relation_certified": (
            full_certified and report.get("skein_relation_certified") is True
        ),
        "registered_fixture_regression_certified": (
            full_certified
            and report.get("registered_fixture_regression_certified") is True
        ),
        "counterexample_count": int(report.get("counterexample_count") or 0),
        "certification_report_url": report_url,
        "certification_report_sha256": report_sha256,
        "certification_report_raw_sha256": report_deterministic_raw_sha256,
        "certification_report_canonical_sha256": report_canonical_sha256,
        "certification_report": report,
        "published_report_canonical_sha256": (
            published_report_canonical_sha256
        ),
        "published_report_json_matches_embedded": published_report_json_matches,
        "external_table_source_urls": external_table_source_urls,
        "external_table_source_sha256s": external_table_source_sha256s,
        "source_method": "iroll homfly-full-certification-pack-producer",
        "certification_report_artifact_kind": report.get("artifact_kind"),
        "certification_report_method": report.get("method"),
        "certification_report_algorithm_scope": report.get("algorithm_scope"),
        "certification_report_case_count": int(report.get("case_count") or 0),
        "certification_report_total_state_count": int(
            report.get("total_state_count") or 0
        ),
        "certification_report_total_transition_count": int(
            report.get("total_transition_count") or 0
        ),
        "certification_report_total_terminal_count": int(
            report.get("total_terminal_count") or 0
        ),
        "certification_report_implementation_source_sha256": report.get(
            "implementation_source_sha256"
        ),
        "certification_report_implementation_bundle_sha256": report.get(
            "implementation_bundle_sha256"
        ),
        "certification_report_replay_audit": report_audit,
        "published_report_witness": {
            key: value
            for key, value in published_witness.items()
            if not str(key).startswith("_")
        },
        "producer_checks": producer_checks,
        "producer_check_count": len(producer_checks),
        "producer_failed_check_count": len(producer_failed_checks),
        "producer_failed_checks": producer_failed_checks,
        "template_placeholder": False,
        "completion_claimed": full_certified,
    }
    preflight = completion_evidence_artifact_audit(
        pack,
        artifact_type="full_homfly_pt_evaluation_certification_pack",
    )
    pack["producer_preflight_artifact_certified"] = preflight[
        "artifact_certified"
    ]
    pack["producer_preflight_failed_check_count"] = preflight[
        "failed_check_count"
    ]
    pack["producer_preflight_failed_checks"] = preflight["failed_checks"]
    certified_by_preflight = preflight["artifact_certified"] is True
    pack["completion_claimed"] = certified_by_preflight
    ci_exit_code = (
        1 if args.fail_on_not_certified and not certified_by_preflight else 0
    )
    pack["_exit_code"] = ci_exit_code
    pack["ci_fail_on_not_certified"] = args.fail_on_not_certified
    pack["ci_exit_code"] = ci_exit_code
    return pack


def _full_multivariable_alexander_normalization_certification_producer_command(
    args: argparse.Namespace,
) -> dict:
    assignments = [
        json.loads(path.read_text(encoding="utf-8-sig"))
        for path in args.verified_signed_crossing_assignment_json
    ]
    pinned_sources = full_alexander_pinned_sources()
    data_witnesses = {
        notation: _fetch_knot_atlas_pinned_witness(
            str(records["data"]["title"]),
            int(records["data"]["revision_id"]),
            str(records["data"]["sha256"]),
            timeout=args.network_timeout,
        )
        for notation, records in pinned_sources.items()
    }
    page_witnesses = {
        notation: _fetch_pinned_url_witness(
            title=str(records["page"]["title"]),
            revision_id=int(records["page"]["revision_id"]),
            url=str(records["page"]["url"]),
            expected_sha256=str(records["page"]["sha256"]),
            timeout=args.network_timeout,
        )
        for notation, records in pinned_sources.items()
    }
    report = full_multivariable_alexander_normalization_certification_report(
        verified_signed_crossing_assignments=assignments,
        source_witnesses=data_witnesses,
    )
    report_audit = (
        full_multivariable_alexander_normalization_certification_report_audit(
            report
        )
    )
    report_canonical_sha256 = canonical_json_sha256(report)
    # Use explicit UTF-8/LF bytes so the published raw digest is identical on
    # Windows and POSIX hosts.
    args.certification_report_output.write_bytes(
        (dump_report(report, indent=2) + "\n").encode("utf-8")
    )
    local_report_bytes = args.certification_report_output.read_bytes()
    local_report_raw_sha256 = sha256(local_report_bytes).hexdigest()
    certification_report_url = getattr(args, "certification_report_url", None)
    published_report_witness: dict | None = None
    published_report_json_matches = False
    published_report_canonical_sha256 = ""
    if certification_report_url:
        published_report_witness = _fetch_pinned_url_witness(
            title="iroll full multivariable Alexander certification report",
            revision_id=0,
            url=str(certification_report_url),
            expected_sha256=local_report_raw_sha256,
            timeout=args.network_timeout,
        )
        try:
            published_report = json.loads(
                str(published_report_witness.get("_content") or "")
            )
        except (TypeError, ValueError):
            published_report = None
        if isinstance(published_report, Mapping):
            published_report_canonical_sha256 = canonical_json_sha256(
                published_report
            )
            published_report_json_matches = (
                published_report_canonical_sha256 == report_canonical_sha256
            )

    notation_order = ("L5a1", "L6a4")
    page_source_urls = [
        str(pinned_sources[notation]["page"]["url"])
        for notation in notation_order
    ]
    page_source_sha256s = [
        str(pinned_sources[notation]["page"]["sha256"])
        for notation in notation_order
    ]
    public_page_witnesses = [
        {
            "notation": notation,
            **{
                key: value
                for key, value in page_witnesses[notation].items()
                if not key.startswith("_")
            },
        }
        for notation in notation_order
    ]
    producer_checks = {
        "required_assignment_file_count": len(assignments) == 2,
        "pinned_data_source_revisions_verified": all(
            witness.get("sha256_verified") is True
            for witness in data_witnesses.values()
        ),
        "pinned_page_source_revisions_verified": all(
            witness.get("sha256_verified") is True
            for witness in page_witnesses.values()
        ),
        "uncapped_exact_certification_report_certified": (
            report.get("certified") is True
        ),
        "certification_report_replay_audit_certified": (
            report_audit.get("certified") is True
        ),
        "certification_report_counterexample_count_zero": (
            report.get("counterexample_count") == 0
        ),
        "local_report_raw_bytes_sha256_available": (
            len(local_report_raw_sha256) == 64
        ),
        "local_report_raw_bytes_match_deterministic_serializer": (
            local_report_raw_sha256
            == serialized_certification_report_sha256(report)
        ),
        "certification_report_url_http": bool(
            certification_report_url
            and str(certification_report_url).startswith(("http://", "https://"))
        ),
        "published_report_downloaded": bool(
            published_report_witness is not None
            and published_report_witness.get("fetched") is True
        ),
        "published_report_raw_bytes_match_local_report": bool(
            published_report_witness is not None
            and published_report_witness.get("sha256_verified") is True
            and published_report_witness.get("actual_sha256")
            == local_report_raw_sha256
        ),
        "published_report_json_matches_local_report": (
            published_report_json_matches
        ),
        "published_report_canonical_sha256_matches_local_report": (
            published_report_canonical_sha256 == report_canonical_sha256
        ),
    }
    producer_failed_checks = [
        name for name, passed in producer_checks.items() if not passed
    ]
    producer_certified = not producer_failed_checks
    artifact = {
        "artifact_schema_version": 1,
        "artifact_kind": (
            "full_multivariable_alexander_normalization_certification_pack"
        ),
        "claim_scope": "full_multivariable_alexander_normalization",
        "full_multivariable_alexander_normalization_certified": (
            producer_certified and report.get("certified") is True
        ),
        "signed_pd_wirtinger_fox_certified": (
            producer_certified
            and report.get("signed_pd_wirtinger_fox_certified") is True
        ),
        "admissible_minor_normalization_certified": (
            producer_certified
            and report.get("admissible_minor_normalization_certified") is True
        ),
        "all_admissible_minors_consistent": (
            producer_certified
            and report.get("all_admissible_minors_consistent") is True
        ),
        "external_table_normalization_certified": (
            producer_certified
            and report.get("external_table_normalization_certified") is True
        ),
        "counterexample_count": int(report.get("counterexample_count", 0)),
        "certification_report_url": (
            str(certification_report_url)
            if certification_report_url
            else "embedded:certification_report"
        ),
        "certification_report_sha256": local_report_raw_sha256,
        "certification_report_raw_sha256": local_report_raw_sha256,
        "certification_report_canonical_sha256": report_canonical_sha256,
        "certification_report_published_witness": (
            {
                key: value
                for key, value in (published_report_witness or {}).items()
                if not key.startswith("_")
            }
            if published_report_witness is not None
            else None
        ),
        "certification_report_published_json_matches": (
            published_report_json_matches if certification_report_url else None
        ),
        "certification_report_published_canonical_sha256": (
            published_report_canonical_sha256
            if certification_report_url
            else None
        ),
        "certification_report": report,
        "certification_report_replay_audit": report_audit,
        "external_table_source_urls": page_source_urls,
        "external_table_source_sha256s": page_source_sha256s,
        "external_table_source_witnesses": public_page_witnesses,
        "producer_checks": producer_checks,
        "producer_check_count": len(producer_checks),
        "producer_failed_check_count": len(producer_failed_checks),
        "producer_failed_checks": producer_failed_checks,
        "producer_certified": producer_certified,
        "template_placeholder": False,
        "completion_claimed": False,
        "notes": [
            "the embedded report is retained for replay but cannot close the final gate without a verified public HTTP(S) URL",
            "certification_report_sha256 is the raw remote file digest and certification_report_canonical_sha256 binds parsed JSON replay",
            "all full=true fields are derived from uncapped exact replay and pinned source witnesses",
        ],
    }
    preflight = completion_evidence_artifact_audit(
        artifact,
        artifact_type=(
            "full_multivariable_alexander_normalization_certification_pack"
        ),
    )
    artifact["producer_preflight_artifact_certified"] = preflight[
        "artifact_certified"
    ]
    artifact["producer_preflight_failed_check_count"] = preflight[
        "failed_check_count"
    ]
    artifact["producer_preflight_failed_checks"] = preflight["failed_checks"]
    artifact["completion_claimed"] = preflight["artifact_certified"] is True
    final_certified = producer_certified and preflight["artifact_certified"] is True
    ci_exit_code = 1 if args.fail_on_not_certified and not final_certified else 0
    artifact["_exit_code"] = ci_exit_code
    artifact["ci_fail_on_not_certified"] = args.fail_on_not_certified
    artifact["ci_exit_code"] = ci_exit_code
    return artifact


def _verified_signed_crossing_assignment_readiness_command(
    args: argparse.Namespace,
) -> dict:
    report = verified_signed_crossing_assignment_readiness_report(
        notations=args.notation
    )
    _add_completion_evidence_producer_metadata(
        report,
        missing_artifact="verified_signed_crossing_assignment",
    )
    ci_exit_code = (
        1
        if args.fail_on_not_ready and report["readiness_all_ready"] is not True
        else 0
    )
    report["_exit_code"] = ci_exit_code
    report["ci_fail_on_not_ready"] = args.fail_on_not_ready
    report["ci_exit_code"] = ci_exit_code
    return report


def _production_imgui_renderer_framebuffer_readiness_command(
    args: argparse.Namespace,
) -> dict:
    production_pack = None
    if args.production_imgui_renderer_framebuffer_pack_json is not None:
        production_pack = json.loads(
            args.production_imgui_renderer_framebuffer_pack_json.read_text(
                encoding="utf-8-sig"
            )
        )
    report = production_imgui_renderer_framebuffer_readiness_report(
        production_imgui_renderer_framebuffer_pack=production_pack
    )
    _add_completion_evidence_producer_metadata(
        report,
        missing_artifact="production_imgui_renderer_framebuffer_pack",
    )
    ci_exit_code = (
        1
        if args.fail_on_not_ready and report["readiness_all_ready"] is not True
        else 0
    )
    report["_exit_code"] = ci_exit_code
    report["ci_fail_on_not_ready"] = args.fail_on_not_ready
    report["ci_exit_code"] = ci_exit_code
    return report


def _signed_release_publication_readiness_command(
    args: argparse.Namespace,
) -> dict:
    release_manifest = None
    if args.signed_release_publication_manifest_json is not None:
        release_manifest = json.loads(
            args.signed_release_publication_manifest_json.read_text(
                encoding="utf-8-sig"
            )
        )
    report = signed_release_publication_readiness_report(
        signed_release_publication_manifest=release_manifest
    )
    _add_completion_evidence_producer_metadata(
        report,
        missing_artifact="signed_release_publication_manifest",
    )
    ci_exit_code = (
        1
        if args.fail_on_not_ready and report["readiness_all_ready"] is not True
        else 0
    )
    report["_exit_code"] = ci_exit_code
    report["ci_fail_on_not_ready"] = args.fail_on_not_ready
    report["ci_exit_code"] = ci_exit_code
    return report


def _full_homfly_pt_evaluation_readiness_command(
    args: argparse.Namespace,
) -> dict:
    certification_pack = None
    if args.full_homfly_pt_evaluation_certification_pack_json is not None:
        certification_pack = json.loads(
            args.full_homfly_pt_evaluation_certification_pack_json.read_text(
                encoding="utf-8-sig"
            )
        )
    report = full_homfly_pt_evaluation_readiness_report(
        full_homfly_pt_evaluation_certification_pack=certification_pack
    )
    _add_completion_evidence_producer_metadata(
        report,
        missing_artifact="full_homfly_pt_evaluation_certification_pack",
    )
    ci_exit_code = (
        1
        if args.fail_on_not_ready and report["readiness_all_ready"] is not True
        else 0
    )
    report["_exit_code"] = ci_exit_code
    report["ci_fail_on_not_ready"] = args.fail_on_not_ready
    report["ci_exit_code"] = ci_exit_code
    return report


def _full_multivariable_alexander_normalization_readiness_command(
    args: argparse.Namespace,
) -> dict:
    certification_pack = None
    if (
        args.full_multivariable_alexander_normalization_certification_pack_json
        is not None
    ):
        certification_pack = json.loads(
            args.full_multivariable_alexander_normalization_certification_pack_json.read_text(
                encoding="utf-8-sig"
            )
        )
    report = full_multivariable_alexander_normalization_readiness_report(
        full_multivariable_alexander_normalization_certification_pack=(
            certification_pack
        )
    )
    _add_completion_evidence_producer_metadata(
        report,
        missing_artifact="full_multivariable_alexander_normalization_certification_pack",
    )
    ci_exit_code = (
        1
        if args.fail_on_not_ready and report["readiness_all_ready"] is not True
        else 0
    )
    report["_exit_code"] = ci_exit_code
    report["ci_fail_on_not_ready"] = args.fail_on_not_ready
    report["ci_exit_code"] = ci_exit_code
    return report


def _add_completion_evidence_producer_metadata(
    report: dict,
    *,
    missing_artifact: str,
    requirements: Mapping[str, object] | None = None,
) -> None:
    requirements = requirements or _completion_evidence_requirements_command(None)
    rows = [
        row
        for row in requirements["artifact_instance_command_rows"]
        if row["missing_artifact"] == missing_artifact
    ]
    report["completion_evidence_missing_artifact"] = missing_artifact
    report["completion_evidence_artifact_filename_count"] = len(rows)
    artifact_filenames = [row["artifact_filename"] for row in rows]
    template_to_artifact_filenames = [
        row["template_to_artifact_filename"] for row in rows
    ]
    artifact_filename_signature = "|".join(artifact_filenames)
    report["completion_evidence_artifact_filenames"] = artifact_filenames
    report["completion_evidence_artifact_filename_signature"] = (
        artifact_filename_signature
    )
    report["completion_evidence_template_filenames"] = [
        row["template_filename"] for row in rows
    ]
    report["completion_evidence_template_to_artifact_filenames"] = (
        template_to_artifact_filenames
    )
    report["completion_evidence_artifact_instance_row_count"] = len(rows)
    report["completion_evidence_artifact_instance_rows"] = rows
    expected_filenames = list(requirements["expected_evidence_filenames"])
    report["completion_evidence_artifact_filenames_are_expected"] = all(
        filename in expected_filenames for filename in artifact_filenames
    )
    report[
        "completion_evidence_template_to_artifact_filenames_match_artifact_filenames"
    ] = (template_to_artifact_filenames == artifact_filenames)
    report[
        "completion_evidence_artifact_filename_count_matches_instance_row_count"
    ] = (len(artifact_filenames) == len(rows))
    report[
        "completion_evidence_artifact_filename_signature_matches_instance_rows"
    ] = (
        artifact_filename_signature
        == "|".join(row["artifact_filename"] for row in rows)
    )
    report["completion_evidence_producer_metadata_consistency_passed"] = (
        report["completion_evidence_artifact_filenames_are_expected"]
        and report[
            "completion_evidence_template_to_artifact_filenames_match_artifact_filenames"
        ]
        and report[
            "completion_evidence_artifact_filename_count_matches_instance_row_count"
        ]
        and report[
            "completion_evidence_artifact_filename_signature_matches_instance_rows"
        ]
    )
    report["completion_evidence_final_completion_failed_gates"] = sorted(
        {
            gate
            for row in rows
            for gate in row.get("final_completion_failed_gates", [])
        }
    )
    report["completion_evidence_final_completion_failed_gate_count"] = len(
        report["completion_evidence_final_completion_failed_gates"]
    )
    report["completion_evidence_final_completion_failed_gate_signature"] = "|".join(
        report["completion_evidence_final_completion_failed_gates"]
    )
    report["completion_evidence_final_completion_blocker_codes"] = sorted(
        {
            code
            for row in rows
            for code in row.get("final_completion_blocker_codes", [])
        }
    )
    report["completion_evidence_final_completion_blocker_code_count"] = len(
        report["completion_evidence_final_completion_blocker_codes"]
    )
    report["completion_evidence_final_completion_blocker_labels"] = sorted(
        {
            label
            for row in rows
            for label in row.get("final_completion_blocker_labels", [])
        }
    )
    report["completion_evidence_final_completion_blocker_label_count"] = len(
        report["completion_evidence_final_completion_blocker_labels"]
    )
    report["completion_evidence_final_completion_blocker_count"] = sum(
        int(row.get("final_completion_blocker_count") or 0) for row in rows
    )
    report["expected_evidence_filename_count"] = requirements[
        "expected_evidence_filename_count"
    ]
    report["expected_evidence_filenames"] = requirements[
        "expected_evidence_filenames"
    ]
    report["expected_evidence_filename_signature"] = requirements[
        "expected_evidence_filename_signature"
    ]
    report["bundle_all_inputs_command"] = requirements["bundle_all_inputs_command"]
    report["directory_audit_command"] = requirements["directory_audit_command"]
    report["final_validation_command"] = requirements["final_validation_command"]


def _completion_evidence_artifact_audit_command(args: argparse.Namespace) -> dict:
    artifact = json.loads(args.path.read_text(encoding="utf-8-sig"))
    report = completion_evidence_artifact_audit(
        artifact,
        artifact_type=args.artifact_type,
    )
    _add_completion_evidence_producer_metadata(
        report,
        missing_artifact=report["audited_artifact_type"],
    )
    ci_exit_code = (
        1
        if args.fail_on_not_certified and report["artifact_certified"] is not True
        else 0
    )
    report["_exit_code"] = ci_exit_code
    report["ci_fail_on_not_certified"] = args.fail_on_not_certified
    report["ci_exit_code"] = ci_exit_code
    return report


def _completion_evidence_bundle_command(args: argparse.Namespace) -> dict:
    requirements = _completion_evidence_requirements_command(args)
    retained_summary = _completion_evidence_retained_summary_from_requirements(
        requirements
    )
    bundle_metadata = _completion_evidence_bundle_metadata_from_requirements(
        requirements
    )
    discovered = _discover_completion_evidence_files(args.evidence_directory)
    verified_assignment_paths = list(
        args.verified_signed_crossing_assignment_json or []
    )
    verified_assignment_paths.extend(discovered["verified_signed_crossing_assignments"])
    production_pack_path = (
        args.production_imgui_renderer_framebuffer_pack_json
        or discovered["production_imgui_renderer_framebuffer_pack"]
    )
    signed_release_path = (
        args.signed_release_publication_manifest_json
        or discovered["signed_release_publication_manifest"]
    )
    homfly_pack_path = (
        args.full_homfly_pt_evaluation_certification_pack_json
        or discovered["full_homfly_pt_evaluation_certification_pack"]
    )
    alexander_pack_path = (
        args.full_multivariable_alexander_normalization_certification_pack_json
        or discovered[
            "full_multivariable_alexander_normalization_certification_pack"
        ]
    )
    missing_inputs = []
    if not verified_assignment_paths:
        missing_inputs.append("--verified-signed-crossing-assignment-json")
    for path, argument in (
        (production_pack_path, "--production-imgui-renderer-framebuffer-pack-json"),
        (signed_release_path, "--signed-release-publication-manifest-json"),
        (homfly_pack_path, "--full-homfly-pt-evaluation-certification-pack-json"),
        (
            alexander_pack_path,
            "--full-multivariable-alexander-normalization-certification-pack-json",
        ),
    ):
        if path is None:
            missing_inputs.append(argument)
    if missing_inputs:
        raise SystemExit(
            "completion-evidence-bundle requires explicit artifact paths or "
            f"--evidence-directory; missing: {', '.join(missing_inputs)}"
        )
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "cross_workstream_completion_evidence_bundle",
        "claim_scope": "cross_workstream_final_completion_evidence",
        "source_method": "iroll completion-evidence-bundle",
        "source_evidence_directory": (
            str(args.evidence_directory) if args.evidence_directory is not None else None
        ),
        "discovered_evidence_file_count": discovered["discovered_file_count"],
        "bundle_inputs_complete": True,
        "bundle_input_count": 5,
        "bundle_repeatable_assignment_count": len(verified_assignment_paths),
        "bundle_certified_by_audit": False,
        "expected_evidence_filename_count": requirements[
            "expected_evidence_filename_count"
        ],
        "expected_evidence_filenames": requirements["expected_evidence_filenames"],
        "expected_evidence_filename_signature": requirements[
            "expected_evidence_filename_signature"
        ],
        "bundle_all_inputs_command": requirements["bundle_all_inputs_command"],
        "directory_audit_command": requirements["directory_audit_command"],
        "final_validation_command": requirements["final_validation_command"],
        **bundle_metadata,
        **retained_summary,
        "completion_claimed": False,
        "verified_signed_crossing_assignments": [
            json.loads(path.read_text(encoding="utf-8-sig"))
            for path in verified_assignment_paths
        ],
        "production_imgui_renderer_framebuffer_pack": json.loads(
            production_pack_path.read_text(encoding="utf-8-sig")
        ),
        "signed_release_publication_manifest": json.loads(
            signed_release_path.read_text(encoding="utf-8-sig")
        ),
        "full_homfly_pt_evaluation_certification_pack": json.loads(
            homfly_pack_path.read_text(encoding="utf-8-sig")
        ),
        "full_multivariable_alexander_normalization_certification_pack": (
            json.loads(
                alexander_pack_path.read_text(encoding="utf-8-sig")
            )
        ),
    }


def _completion_evidence_directory_audit_command(args: argparse.Namespace) -> dict:
    requirements = _completion_evidence_requirements_command(args)
    contracts = _completion_evidence_contracts_command(
        args,
        requirements=requirements,
    )
    retained_summary = _completion_evidence_retained_summary_from_requirements(
        requirements
    )
    directory_kind = _completion_evidence_directory_kind(args.directory)
    review_bundle_index_expected_evidence_filename_count_matches_requirements = (
        directory_kind["review_bundle_index_expected_evidence_filename_count"]
        == requirements["expected_evidence_filename_count"]
    )
    review_bundle_index_expected_evidence_filename_signature_matches_requirements = (
        directory_kind["review_bundle_index_expected_evidence_filename_signature"]
        == requirements["expected_evidence_filename_signature"]
    )
    review_bundle_index_final_completion_blocker_count_matches_requirements = (
        directory_kind["review_bundle_index_final_completion_blocker_count"]
        == requirements["final_completion_blocker_count"]
    )
    review_bundle_index_final_completion_failed_gate_count_matches_requirements = (
        directory_kind["review_bundle_index_final_completion_failed_gate_count"]
        == requirements["final_completion_failed_gate_count"]
    )
    review_bundle_index_final_completion_failed_gate_signature_matches_requirements = (
        directory_kind["review_bundle_index_final_completion_failed_gate_signature"]
        == requirements["final_completion_failed_gate_signature"]
    )
    review_bundle_index_final_completion_missing_artifact_count_matches_requirements = (
        directory_kind["review_bundle_index_final_completion_missing_artifact_count"]
        == requirements["final_completion_missing_artifact_count"]
    )
    review_bundle_index_final_completion_missing_artifact_signature_matches_requirements = (
        directory_kind[
            "review_bundle_index_final_completion_missing_artifact_signature"
        ]
        == requirements["final_completion_missing_artifact_signature"]
    )
    review_bundle_index_final_state_matches_requirements = (
        review_bundle_index_final_completion_blocker_count_matches_requirements
        and review_bundle_index_final_completion_failed_gate_count_matches_requirements
        and review_bundle_index_final_completion_failed_gate_signature_matches_requirements
        and review_bundle_index_final_completion_missing_artifact_count_matches_requirements
        and review_bundle_index_final_completion_missing_artifact_signature_matches_requirements
    )
    review_bundle_index_non_claim_consistency_passed = (
        directory_kind["review_bundle_index_completion_claimed"] is False
        and directory_kind["review_bundle_index_final_completion_ready"] is False
    )
    review_bundle_index_handoff_consistency_passed = (
        directory_kind["review_bundle_index_present"] is True
        and directory_kind["review_bundle_index_valid_json"] is True
        and directory_kind["review_bundle_index_matches_review_bundle_contract"]
        is True
        and review_bundle_index_expected_evidence_filename_count_matches_requirements
        and review_bundle_index_expected_evidence_filename_signature_matches_requirements
        and review_bundle_index_final_state_matches_requirements
        and directory_kind[
            "review_bundle_index_producer_metadata_consistency_all_passed"
        ]
        is True
        and review_bundle_index_non_claim_consistency_passed
    )
    discovered = _discover_completion_evidence_files(args.directory)
    rows = _completion_evidence_directory_rows(discovered)
    missing_rows = [row for row in rows if not row["present"]]
    missing_input_keys = {row["bundle_key"] for row in missing_rows}
    missing_input_artifact_rows = [
        {
            "missing_input": (
                "verified_signed_crossing_assignments"
                if row["missing_artifact"] == "verified_signed_crossing_assignment"
                else row["missing_artifact"]
            ),
            "missing_artifact": row["missing_artifact"],
            "instance_label": row["instance_label"],
            "artifact_filename": row["artifact_filename"],
            "template_filename": row["template_filename"],
            "template_to_artifact_filename": row[
                "template_to_artifact_filename"
            ],
            "template_to_artifact_note": row["template_to_artifact_note"],
            "producer_cli_argument": row["producer_cli_argument"],
            "preflight_command": row["preflight_command"],
            "bundle_input_example": row["bundle_input_example"],
            "final_completion_failed_gate_count": row[
                "final_completion_failed_gate_count"
            ],
            "final_completion_failed_gates": row[
                "final_completion_failed_gates"
            ],
            "final_completion_failed_gate_signature": row[
                "final_completion_failed_gate_signature"
            ],
            "final_completion_blocker_count": row[
                "final_completion_blocker_count"
            ],
            "final_completion_blocker_codes": row[
                "final_completion_blocker_codes"
            ],
            "final_completion_blocker_labels": row[
                "final_completion_blocker_labels"
            ],
        }
        for row in requirements["artifact_instance_command_rows"]
        if (
            (
                "verified_signed_crossing_assignments"
                if row["missing_artifact"] == "verified_signed_crossing_assignment"
                else row["missing_artifact"]
            )
            in missing_input_keys
        )
    ]
    signed_assignment_discovery_row = next(
        (
            row
            for row in rows
            if row["bundle_key"] == "verified_signed_crossing_assignments"
        ),
        {},
    )
    instance_filename_coverage_complete = (
        signed_assignment_discovery_row.get("instance_filename_coverage_complete")
        is True
    )
    artifact_preflight_audits = _completion_evidence_artifact_preflight_rows(
        discovered,
        requirements=requirements,
    )
    artifact_preflight_failed_rows = [
        row for row in artifact_preflight_audits if row["artifact_certified"] is not True
    ]
    artifact_preflight_field_coverage_failed_rows = [
        row
        for row in artifact_preflight_audits
        if row["audit"]["artifact_field_coverage_complete"] is not True
    ]
    artifact_preflight_field_coverage_complete = (
        not missing_rows
        and len(artifact_preflight_audits) > 0
        and not artifact_preflight_field_coverage_failed_rows
    )
    missing_artifact_fields_by_path = (
        _completion_evidence_missing_artifact_fields_by_path(
            artifact_preflight_field_coverage_failed_rows
        )
    )
    signed_assignment_notation_coverage = (
        _completion_evidence_signed_assignment_notation_coverage(
            artifact_preflight_audits
        )
    )
    artifact_preflight_contract_coverage = (
        completion_evidence_artifact_preflight_contract_coverage(
            artifact_preflight_audits,
            claim_scope="completion_evidence_directory_artifact_preflight_contract_coverage",
            required_signed_assignment_notations=(
                signed_assignment_notation_coverage["required_notations"]
            ),
            present_signed_assignment_notations=(
                signed_assignment_notation_coverage["present_notations"]
            ),
        )
    )
    artifact_preflight_all_certified = (
        not missing_rows
        and len(artifact_preflight_audits) > 0
        and not artifact_preflight_failed_rows
        and signed_assignment_notation_coverage["all_required_notations_present"]
        and artifact_preflight_contract_coverage["coverage_complete"]
    )
    validation_pack = None
    discovered_bundle = None
    bundle_written = False
    validation_written = False
    validation_requested = args.validate_artifacts or args.validation_output is not None
    if validation_requested and not missing_rows:
        discovered_bundle = _completion_evidence_bundle_from_discovered(
            discovered,
            source_directory=args.directory,
            retained_summary=retained_summary,
            requirements=requirements,
        )
        validation_pack = cross_workstream_validation_pack_audit(
            completion_evidence_bundle=discovered_bundle
        )
    elif args.bundle_output is not None and not missing_rows:
        discovered_bundle = _completion_evidence_bundle_from_discovered(
            discovered,
            source_directory=args.directory,
            retained_summary=retained_summary,
            requirements=requirements,
        )
    if args.bundle_output is not None and discovered_bundle is not None:
        write_report(discovered_bundle, args.bundle_output)
        bundle_written = True
    if args.validation_output is not None and validation_pack is not None:
        write_report(validation_pack, args.validation_output)
        validation_written = True
    validation_ready = (
        validation_pack is not None and validation_pack["final_completion_ready"] is True
    )
    validation_failed_gate_names = (
        [
            row["gate"]
            for row in validation_pack["final_completion_gate_checks"]
            if row.get("passed") is not True
        ]
        if validation_pack is not None
        else []
    )
    validation_missing_artifacts = (
        [
            row["missing_artifact"]
            for row in validation_pack["final_completion_missing_artifact_summary"]
        ]
        if validation_pack is not None
        else []
    )
    validation_failed_gate_signature = "|".join(validation_failed_gate_names)
    validation_missing_artifact_signature = "|".join(validation_missing_artifacts)
    pipeline_steps = [
        {
            "step": "discover_required_inputs",
            "required": True,
            "passed": not missing_rows,
            "skipped_reason": None,
        },
        {
            "step": "preflight_discovered_artifacts",
            "required": True,
            "passed": artifact_preflight_all_certified,
            "skipped_reason": "missing_inputs" if missing_rows else None,
        },
        {
            "step": "validate_artifact_contents",
            "required": True,
            "passed": validation_ready,
            "skipped_reason": (
                None
                if validation_pack is not None
                else (
                    "missing_inputs"
                    if validation_requested and missing_rows
                    else "not_requested"
                )
            ),
        },
        {
            "step": "write_completion_bundle",
            "required": False,
            "passed": bundle_written,
            "skipped_reason": (
                None
                if bundle_written
                else (
                    "missing_inputs"
                    if args.bundle_output is not None and missing_rows
                    else "not_requested"
                )
            ),
        },
        {
            "step": "write_validation_audit",
            "required": False,
            "passed": validation_written,
            "skipped_reason": (
                None
                if validation_written
                else (
                    "missing_inputs"
                    if args.validation_output is not None and missing_rows
                    else "not_requested"
                )
            ),
        },
    ]
    required_pipeline_steps = [row for row in pipeline_steps if row["required"]]
    passed_required_pipeline_steps = [
        row for row in required_pipeline_steps if row["passed"]
    ]
    failed_required_pipeline_steps = [
        row for row in required_pipeline_steps if row["passed"] is not True
    ]
    failed_required_pipeline_step_names = [
        str(row["step"]) for row in failed_required_pipeline_steps
    ]
    skipped_required_pipeline_steps = [
        row
        for row in required_pipeline_steps
        if row.get("skipped_reason") is not None
    ]
    pipeline_blockers = []
    if missing_rows:
        pipeline_blockers.append(
            {
                "step": "discover_required_inputs",
                "code": "required_inputs_missing",
                "missing_input_count": len(missing_rows),
                "missing_inputs": [row["bundle_key"] for row in missing_rows],
                "skipped_reason": None,
            }
        )
    if not artifact_preflight_all_certified:
        pipeline_blockers.append(
            {
                "step": "preflight_discovered_artifacts",
                "code": "artifact_preflight_not_certified",
                "artifact_preflight_failed_count": len(
                    artifact_preflight_failed_rows
                ),
                "artifact_preflight_field_coverage_failed_count": len(
                    artifact_preflight_field_coverage_failed_rows
                ),
                "artifact_preflight_contract_coverage_complete": (
                    artifact_preflight_contract_coverage["coverage_complete"]
                ),
                "signed_assignment_notation_coverage_complete": (
                    signed_assignment_notation_coverage[
                        "all_required_notations_present"
                    ]
                ),
                "missing_signed_assignment_notations": (
                    signed_assignment_notation_coverage["missing_notations"]
                ),
                "skipped_reason": "missing_inputs" if missing_rows else None,
            }
        )
    if not instance_filename_coverage_complete:
        pipeline_blockers.append(
            {
                "step": "check_required_instance_files",
                "code": "required_instance_files_missing",
                "expected_instance_filenames": list(
                    signed_assignment_discovery_row.get(
                        "expected_instance_filenames", []
                    )
                ),
                "present_instance_filenames": list(
                    signed_assignment_discovery_row.get(
                        "present_instance_filenames", []
                    )
                ),
                "missing_instance_filenames": list(
                    signed_assignment_discovery_row.get(
                        "missing_instance_filenames", []
                    )
                ),
                "instance_filename_coverage_complete": False,
                "skipped_reason": None,
            }
        )
    if not validation_ready:
        pipeline_blockers.append(
            {
                "step": "validate_artifact_contents",
                "code": "artifact_validation_not_ready",
                "artifact_validation_performed": validation_pack is not None,
                "artifact_validation_skipped_reason": (
                    None
                    if validation_pack is not None
                    else (
                        "missing_inputs"
                        if validation_requested and missing_rows
                        else "not_requested"
                    )
                ),
                "artifact_validation_failed_gate_count": (
                    validation_pack["final_completion_failed_gate_count"]
                    if validation_pack is not None
                    else None
                ),
                "artifact_validation_failed_gates": validation_failed_gate_names,
                "artifact_validation_missing_artifact_count": len(
                    validation_missing_artifacts
                ),
                "artifact_validation_missing_artifacts": (
                    validation_missing_artifacts
                ),
            }
        )
    pipeline_blocker_code_counts = {
        code: sum(1 for row in pipeline_blockers if row["code"] == code)
        for code in sorted({row["code"] for row in pipeline_blockers})
    }
    pipeline_blocker_signature = ",".join(
        f"{code}:{pipeline_blocker_code_counts[code]}"
        for code in sorted(pipeline_blocker_code_counts)
    )
    ci_exit_code = 1 if args.fail_on_not_ready and not validation_ready else 0
    return {
        "_exit_code": ci_exit_code,
        "artifact_schema_version": 1,
        "artifact_kind": "cross_workstream_completion_evidence_directory_audit",
        "claim_scope": "cross_workstream_final_completion_evidence_directory_audit",
        "source_method": "iroll completion-evidence-directory-audit",
        "source_evidence_directory": str(args.directory),
        **directory_kind,
        "review_bundle_index_expected_evidence_filename_count_matches_requirements": (
            review_bundle_index_expected_evidence_filename_count_matches_requirements
        ),
        "review_bundle_index_expected_evidence_filename_signature_matches_requirements": (
            review_bundle_index_expected_evidence_filename_signature_matches_requirements
        ),
        "review_bundle_index_non_claim_consistency_passed": (
            review_bundle_index_non_claim_consistency_passed
        ),
        "review_bundle_index_final_completion_blocker_count_matches_requirements": (
            review_bundle_index_final_completion_blocker_count_matches_requirements
        ),
        "review_bundle_index_final_completion_failed_gate_count_matches_requirements": (
            review_bundle_index_final_completion_failed_gate_count_matches_requirements
        ),
        "review_bundle_index_final_completion_failed_gate_signature_matches_requirements": (
            review_bundle_index_final_completion_failed_gate_signature_matches_requirements
        ),
        "review_bundle_index_final_completion_missing_artifact_count_matches_requirements": (
            review_bundle_index_final_completion_missing_artifact_count_matches_requirements
        ),
        "review_bundle_index_final_completion_missing_artifact_signature_matches_requirements": (
            review_bundle_index_final_completion_missing_artifact_signature_matches_requirements
        ),
        "review_bundle_index_final_state_matches_requirements": (
            review_bundle_index_final_state_matches_requirements
        ),
        "review_bundle_index_handoff_consistency_passed": (
            review_bundle_index_handoff_consistency_passed
        ),
        "discovered_evidence_file_count": discovered["discovered_file_count"],
        "required_input_count": len(rows),
        "present_input_count": sum(1 for row in rows if row["present"]),
        "missing_input_count": len(missing_rows),
        "missing_inputs": [row["bundle_key"] for row in missing_rows],
        "missing_input_artifact_count": len(missing_input_artifact_rows),
        "missing_input_artifact_filenames": [
            row["artifact_filename"] for row in missing_input_artifact_rows
        ],
        "missing_input_artifact_rows": missing_input_artifact_rows,
        "bundle_inputs_complete": not missing_rows,
        **retained_summary,
        "discovered_inputs": rows,
        "expected_evidence_filename_count": requirements[
            "expected_evidence_filename_count"
        ],
        "expected_evidence_filenames": requirements["expected_evidence_filenames"],
        "expected_evidence_filename_signature": requirements[
            "expected_evidence_filename_signature"
        ],
        "contract_instance_row_count": contracts["contract_instance_row_count"],
        "contract_instance_filename_count": contracts[
            "contract_instance_filename_count"
        ],
        "contract_instance_filenames": contracts["contract_instance_filenames"],
        "contract_instance_filename_signature": contracts[
            "contract_instance_filename_signature"
        ],
        "contract_instance_filenames_match_expected_evidence_filenames": contracts[
            "contract_instance_filenames_match_expected_evidence_filenames"
        ],
        "contract_preflight_consistency_passed_count": contracts[
            "contract_preflight_consistency_passed_count"
        ],
        "all_contract_preflight_consistency_passed": contracts[
            "all_contract_preflight_consistency_passed"
        ],
        "all_contract_consistency_passed": contracts[
            "all_contract_consistency_passed"
        ],
        "bundle_all_inputs_command": requirements["bundle_all_inputs_command"],
        "directory_audit_command": requirements["directory_audit_command"],
        "final_validation_command": requirements["final_validation_command"],
        "expected_instance_filenames": list(
            signed_assignment_discovery_row.get("expected_instance_filenames", [])
        ),
        "expected_instance_filename_count": int(
            signed_assignment_discovery_row.get("expected_instance_filename_count")
            or 0
        ),
        "present_instance_filenames": list(
            signed_assignment_discovery_row.get("present_instance_filenames", [])
        ),
        "present_instance_filename_count": int(
            signed_assignment_discovery_row.get("present_instance_filename_count")
            or 0
        ),
        "missing_instance_filenames": list(
            signed_assignment_discovery_row.get("missing_instance_filenames", [])
        ),
        "missing_instance_filename_count": int(
            signed_assignment_discovery_row.get("missing_instance_filename_count")
            or 0
        ),
        "instance_filename_coverage_complete": instance_filename_coverage_complete,
        "artifact_preflight_count": len(artifact_preflight_audits),
        "artifact_preflight_certified_count": (
            len(artifact_preflight_audits) - len(artifact_preflight_failed_rows)
        ),
        "artifact_preflight_failed_count": len(artifact_preflight_failed_rows),
        "artifact_preflight_all_certified": artifact_preflight_all_certified,
        "artifact_preflight_audits": artifact_preflight_audits,
        "artifact_preflight_field_coverage_failed_count": (
            len(artifact_preflight_field_coverage_failed_rows)
        ),
        "artifact_preflight_field_coverage_failed_rows": (
            artifact_preflight_field_coverage_failed_rows
        ),
        "artifact_preflight_field_coverage_complete": (
            artifact_preflight_field_coverage_complete
        ),
        "missing_artifact_fields_by_path": missing_artifact_fields_by_path,
        "artifact_preflight_contract_coverage": (
            artifact_preflight_contract_coverage
        ),
        "artifact_preflight_contract_coverage_complete": (
            artifact_preflight_contract_coverage["coverage_complete"]
        ),
        "required_signed_assignment_notations": (
            signed_assignment_notation_coverage["required_notations"]
        ),
        "present_signed_assignment_notations": (
            signed_assignment_notation_coverage["present_notations"]
        ),
        "missing_signed_assignment_notation_count": (
            signed_assignment_notation_coverage["missing_notation_count"]
        ),
        "missing_signed_assignment_notations": (
            signed_assignment_notation_coverage["missing_notations"]
        ),
        "signed_assignment_notation_coverage_complete": (
            signed_assignment_notation_coverage["all_required_notations_present"]
        ),
        "artifact_validation_requested": validation_requested,
        "artifact_validation_performed": validation_pack is not None,
        "artifact_validation_skipped_reason": (
            None
            if validation_pack is not None
            else (
                "missing_inputs"
                if validation_requested and missing_rows
                else "not_requested"
            )
        ),
        "artifact_validation_final_completion_ready": (
            validation_pack["final_completion_ready"]
            if validation_pack is not None
            else False
        ),
        "artifact_validation_final_completion_blocker_count": (
            validation_pack["final_completion_blocker_count"]
            if validation_pack is not None
            else None
        ),
        "artifact_validation_blocker_code_counts": (
            validation_pack["final_completion_blocker_code_counts"]
            if validation_pack is not None
            else {}
        ),
        "artifact_validation_failed_gate_count": (
            validation_pack["final_completion_failed_gate_count"]
            if validation_pack is not None
            else None
        ),
        "artifact_validation_failed_gates": validation_failed_gate_names,
        "artifact_validation_failed_gate_signature": (
            validation_failed_gate_signature
        ),
        "artifact_validation_gate_checks": (
            validation_pack["final_completion_gate_checks"]
            if validation_pack is not None
            else []
        ),
        "artifact_validation_missing_artifact_count": len(
            validation_missing_artifacts
        ),
        "artifact_validation_missing_artifacts": validation_missing_artifacts,
        "artifact_validation_missing_artifact_signature": (
            validation_missing_artifact_signature
        ),
        "artifact_validation_missing_artifact_summary": (
            validation_pack["final_completion_missing_artifact_summary"]
            if validation_pack is not None
            else []
        ),
        "bundle_output_requested": args.bundle_output is not None,
        "bundle_output_path": str(args.bundle_output) if args.bundle_output else None,
        "bundle_output_written": bundle_written,
        "bundle_output_skipped_reason": (
            None
            if bundle_written
            else (
                "missing_inputs"
                if args.bundle_output is not None and missing_rows
                else "not_requested"
            )
        ),
        "validation_output_requested": args.validation_output is not None,
        "validation_output_path": (
            str(args.validation_output) if args.validation_output else None
        ),
        "validation_output_written": validation_written,
        "validation_output_skipped_reason": (
            None
            if validation_written
            else (
                "missing_inputs"
                if args.validation_output is not None and missing_rows
                else "not_requested"
            )
        ),
        "completion_evidence_pipeline_ready": validation_ready,
        "completion_evidence_pipeline_blocker_count": len(pipeline_blockers),
        "completion_evidence_pipeline_blocker_codes": sorted(
            pipeline_blocker_code_counts
        ),
        "completion_evidence_pipeline_blocker_code_counts": (
            pipeline_blocker_code_counts
        ),
        "completion_evidence_pipeline_blocker_signature": (
            pipeline_blocker_signature
        ),
        "completion_evidence_pipeline_blockers": pipeline_blockers,
        "ci_fail_on_not_ready": args.fail_on_not_ready,
        "ci_exit_code": ci_exit_code,
        "pipeline_required_step_count": len(required_pipeline_steps),
        "pipeline_passed_required_step_count": len(passed_required_pipeline_steps),
        "pipeline_failed_required_step_count": len(failed_required_pipeline_steps),
        "pipeline_failed_required_steps": failed_required_pipeline_step_names,
        "pipeline_failed_required_step_signature": "|".join(
            failed_required_pipeline_step_names
        ),
        "pipeline_skipped_required_step_count": len(skipped_required_pipeline_steps),
        "pipeline_step_count": len(pipeline_steps),
        "pipeline_steps": pipeline_steps,
        "bundle_command": (
            f"iroll completion-evidence-bundle --evidence-directory {args.directory}"
        ),
        "audit_command": (
            "iroll fixture-validation-pack-audit "
            "--completion-evidence-bundle-json <path>"
        ),
        "completion_claimed": False,
        "notes": [
            "directory audit checks file discovery only",
            "it does not certify artifact contents or close validation-pack gates",
            *(
                [
                    "review_bundle_handoff_detected=true means this directory is a review handoff, not the final evidence directory"
                ]
                if directory_kind["review_bundle_handoff_detected"]
                else []
            ),
        ],
    }


def _completion_evidence_bundle_from_discovered(
    discovered: dict,
    *,
    source_directory: Path,
    retained_summary: Mapping[str, object] | None = None,
    requirements: Mapping[str, object] | None = None,
) -> dict:
    retained_summary = dict(retained_summary or {})
    requirements = dict(requirements or _completion_evidence_requirements_command(None))
    bundle_metadata = _completion_evidence_bundle_metadata_from_requirements(
        requirements
    )
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "cross_workstream_completion_evidence_bundle",
        "claim_scope": "cross_workstream_final_completion_evidence",
        "source_method": "iroll completion-evidence-directory-audit",
        "source_evidence_directory": str(source_directory),
        "discovered_evidence_file_count": discovered["discovered_file_count"],
        "bundle_inputs_complete": True,
        "bundle_input_count": 5,
        "bundle_repeatable_assignment_count": len(
            discovered["verified_signed_crossing_assignments"]
        ),
        "bundle_certified_by_audit": False,
        "expected_evidence_filename_count": requirements[
            "expected_evidence_filename_count"
        ],
        "expected_evidence_filenames": requirements["expected_evidence_filenames"],
        "expected_evidence_filename_signature": requirements[
            "expected_evidence_filename_signature"
        ],
        "bundle_all_inputs_command": requirements["bundle_all_inputs_command"],
        "directory_audit_command": requirements["directory_audit_command"],
        "final_validation_command": requirements["final_validation_command"],
        **bundle_metadata,
        **retained_summary,
        "completion_claimed": False,
        "verified_signed_crossing_assignments": [
            json.loads(path.read_text(encoding="utf-8-sig"))
            for path in discovered["verified_signed_crossing_assignments"]
        ],
        "production_imgui_renderer_framebuffer_pack": json.loads(
            discovered["production_imgui_renderer_framebuffer_pack"].read_text(
                encoding="utf-8-sig"
            )
        ),
        "signed_release_publication_manifest": json.loads(
            discovered["signed_release_publication_manifest"].read_text(
                encoding="utf-8-sig"
            )
        ),
        "full_homfly_pt_evaluation_certification_pack": json.loads(
            discovered["full_homfly_pt_evaluation_certification_pack"].read_text(
                encoding="utf-8-sig"
            )
        ),
        "full_multivariable_alexander_normalization_certification_pack": json.loads(
            discovered[
                "full_multivariable_alexander_normalization_certification_pack"
            ].read_text(encoding="utf-8-sig")
        ),
    }


def _completion_evidence_bundle_metadata_from_requirements(
    requirements: Mapping[str, object],
) -> dict:
    artifact_instance_rows = list(requirements["artifact_instance_command_rows"])
    return {
        "completion_evidence_artifact_instance_row_count": len(
            artifact_instance_rows
        ),
        "completion_evidence_artifact_instance_rows": artifact_instance_rows,
        "completion_evidence_artifact_filenames": [
            row["artifact_filename"] for row in artifact_instance_rows
        ],
        "completion_evidence_artifact_filename_signature": "|".join(
            row["artifact_filename"] for row in artifact_instance_rows
        ),
    }


def _completion_evidence_directory_rows(discovered: dict) -> list[dict]:
    signed_assignment_paths = discovered["verified_signed_crossing_assignments"]
    expected_assignment_filenames = [
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    present_assignment_filenames = sorted(path.name for path in signed_assignment_paths)
    missing_assignment_filenames = [
        filename
        for filename in expected_assignment_filenames
        if filename not in present_assignment_filenames
    ]
    rows = [
        {
            "bundle_key": "verified_signed_crossing_assignments",
            "missing_artifact": "verified_signed_crossing_assignment",
            "repeatable": True,
            "present": bool(signed_assignment_paths),
            "discovered_path_count": len(signed_assignment_paths),
            "discovered_paths": [
                str(path) for path in signed_assignment_paths
            ],
            "expected_instance_filenames": expected_assignment_filenames,
            "expected_instance_filename_count": len(expected_assignment_filenames),
            "present_instance_filenames": present_assignment_filenames,
            "present_instance_filename_count": len(present_assignment_filenames),
            "missing_instance_filenames": missing_assignment_filenames,
            "missing_instance_filename_count": len(missing_assignment_filenames),
            "instance_filename_coverage_complete": not missing_assignment_filenames,
        }
    ]
    for artifact in (
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
    ):
        path = discovered[artifact]
        rows.append(
            {
                "bundle_key": artifact,
                "missing_artifact": artifact,
                "repeatable": False,
                "present": path is not None,
                "discovered_path_count": 1 if path is not None else 0,
                "discovered_paths": [str(path)] if path is not None else [],
            }
        )
    return rows


def _completion_evidence_artifact_preflight_rows(
    discovered: dict,
    *,
    requirements: Mapping[str, object],
) -> list[dict]:
    rows = []
    assignment_paths = discovered["verified_signed_crossing_assignments"]
    for path in assignment_paths:
        audit = completion_evidence_artifact_audit(
            json.loads(path.read_text(encoding="utf-8-sig")),
            artifact_type="verified_signed_crossing_assignment",
        )
        _add_completion_evidence_producer_metadata(
            audit,
            missing_artifact="verified_signed_crossing_assignment",
            requirements=requirements,
        )
        rows.append(
            {
                "bundle_key": "verified_signed_crossing_assignments",
                "artifact_type": "verified_signed_crossing_assignment",
                "artifact_path": str(path),
                "artifact_certified": audit["artifact_certified"],
                "failed_check_count": audit["failed_check_count"],
                "failed_checks": audit["failed_checks"],
                "audit": audit,
            }
        )
    for artifact_type in (
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
    ):
        path = discovered[artifact_type]
        if path is None:
            continue
        audit = completion_evidence_artifact_audit(
            json.loads(path.read_text(encoding="utf-8-sig")),
            artifact_type=artifact_type,
        )
        _add_completion_evidence_producer_metadata(
            audit,
            missing_artifact=artifact_type,
            requirements=requirements,
        )
        rows.append(
            {
                "bundle_key": artifact_type,
                "artifact_type": artifact_type,
                "artifact_path": str(path),
                "artifact_certified": audit["artifact_certified"],
                "failed_check_count": audit["failed_check_count"],
                "failed_checks": audit["failed_checks"],
                "audit": audit,
            }
        )
    return rows


def _completion_evidence_directory_kind(directory: Path) -> dict:
    marker_names = [
        "completion-evidence-requirements.json",
        "completion-evidence-contracts.json",
        "completion-evidence-ci-plan.json",
        "validation-pack-audit.json",
        "completion-evidence-templates.json",
    ]
    marker_files = [
        name
        for name in marker_names
        if (directory / name).is_file()
    ]
    templates_directory_present = (directory / "completion-evidence-templates").is_dir()
    review_bundle_handoff_detected = (
        len(marker_files) >= 3 and templates_directory_present
    )
    review_index_path = directory / "completion-evidence-review-index.json"
    review_index = None
    review_index_valid_json = False
    review_index_error = None
    if review_index_path.is_file():
        try:
            review_index = json.loads(
                review_index_path.read_text(encoding="utf-8-sig")
            )
            review_index_valid_json = isinstance(review_index, Mapping)
        except (OSError, json.JSONDecodeError) as exc:
            review_index_error = str(exc)
    review_index_artifact_kind = (
        review_index.get("artifact_kind") if isinstance(review_index, Mapping) else None
    )
    review_index_claim_scope = (
        review_index.get("claim_scope") if isinstance(review_index, Mapping) else None
    )
    review_index_completion_claimed = (
        review_index.get("completion_claimed")
        if isinstance(review_index, Mapping)
        else None
    )
    review_index_final_completion_ready = (
        review_index.get("final_completion_ready")
        if isinstance(review_index, Mapping)
        else None
    )
    review_index_final_completion_blocker_count = (
        review_index.get("final_completion_blocker_count")
        if isinstance(review_index, Mapping)
        else None
    )
    review_index_final_completion_failed_gate_count = (
        review_index.get("final_completion_failed_gate_count")
        if isinstance(review_index, Mapping)
        else None
    )
    review_index_final_completion_failed_gate_signature = (
        review_index.get("final_completion_failed_gate_signature")
        if isinstance(review_index, Mapping)
        else None
    )
    review_index_final_completion_missing_artifact_count = (
        review_index.get("final_completion_missing_artifact_count")
        if isinstance(review_index, Mapping)
        else None
    )
    review_index_final_completion_missing_artifact_signature = (
        review_index.get("final_completion_missing_artifact_signature")
        if isinstance(review_index, Mapping)
        else None
    )
    review_index_matches_review_bundle_contract = (
        review_index_valid_json
        and review_index_artifact_kind
        == "cross_workstream_completion_evidence_review_bundle"
        and review_index_claim_scope == "cross_workstream_final_completion_evidence_review"
        and review_index_completion_claimed is False
    )
    return {
        "source_evidence_directory_kind": (
            "review_bundle_handoff"
            if review_bundle_handoff_detected
            else "completion_evidence_directory"
        ),
        "review_bundle_handoff_detected": review_bundle_handoff_detected,
        "review_bundle_marker_files": marker_files,
        "review_bundle_marker_file_count": len(marker_files),
        "review_bundle_templates_directory_present": templates_directory_present,
        "review_bundle_not_final_evidence_directory": review_bundle_handoff_detected,
        "review_bundle_index_filename": "completion-evidence-review-index.json",
        "review_bundle_index_path": str(review_index_path),
        "review_bundle_index_present": review_index_path.is_file(),
        "review_bundle_index_valid_json": review_index_valid_json,
        "review_bundle_index_error": review_index_error,
        "review_bundle_index_artifact_kind": review_index_artifact_kind,
        "review_bundle_index_claim_scope": review_index_claim_scope,
        "review_bundle_index_completion_claimed": review_index_completion_claimed,
        "review_bundle_index_final_completion_ready": (
            review_index_final_completion_ready
        ),
        "review_bundle_index_final_completion_blocker_count": (
            review_index_final_completion_blocker_count
        ),
        "review_bundle_index_final_completion_failed_gate_count": (
            review_index_final_completion_failed_gate_count
        ),
        "review_bundle_index_final_completion_failed_gate_signature": (
            review_index_final_completion_failed_gate_signature
        ),
        "review_bundle_index_final_completion_missing_artifact_count": (
            review_index_final_completion_missing_artifact_count
        ),
        "review_bundle_index_final_completion_missing_artifact_signature": (
            review_index_final_completion_missing_artifact_signature
        ),
        "review_bundle_index_matches_review_bundle_contract": (
            review_index_matches_review_bundle_contract
        ),
        "review_bundle_index_traceability_report_count": (
            review_index.get("traceability_report_count")
            if isinstance(review_index, Mapping)
            else None
        ),
        "review_bundle_index_expected_evidence_filename_count": (
            review_index.get("expected_evidence_filename_count")
            if isinstance(review_index, Mapping)
            else None
        ),
        "review_bundle_index_expected_evidence_filename_signature": (
            review_index.get("expected_evidence_filename_signature")
            if isinstance(review_index, Mapping)
            else None
        ),
        "review_bundle_index_producer_metadata_consistency_report_count": (
            review_index.get("producer_metadata_consistency_report_count")
            if isinstance(review_index, Mapping)
            else None
        ),
        "review_bundle_index_producer_metadata_consistency_passed_count": (
            review_index.get("producer_metadata_consistency_passed_count")
            if isinstance(review_index, Mapping)
            else None
        ),
        "review_bundle_index_producer_metadata_consistency_failed_count": (
            review_index.get("producer_metadata_consistency_failed_count")
            if isinstance(review_index, Mapping)
            else None
        ),
        "review_bundle_index_producer_metadata_consistency_all_passed": (
            review_index.get("producer_metadata_consistency_all_passed")
            if isinstance(review_index, Mapping)
            else None
        ),
        "review_bundle_index_producer_metadata_consistency_failed_files": (
            review_index.get("producer_metadata_consistency_failed_files")
            if isinstance(review_index, Mapping)
            else None
        ),
    }


def _completion_evidence_missing_artifact_fields_by_path(
    artifact_preflight_rows: Sequence[Mapping[str, object]],
) -> dict[str, dict]:
    result: dict[str, dict] = {}
    for row in artifact_preflight_rows:
        audit = row.get("audit")
        if not isinstance(audit, Mapping):
            continue
        artifact_path = str(row.get("artifact_path") or "")
        if not artifact_path:
            continue
        result[artifact_path] = {
            "bundle_key": row.get("bundle_key"),
            "artifact_type": row.get("artifact_type"),
            "missing_artifact_fields": list(
                audit.get("missing_artifact_fields") or []
            ),
        }
    return result


def _completion_evidence_signed_assignment_notation_coverage(
    artifact_preflight_rows: list[dict],
) -> dict:
    required_notations = ["L5a1", "L6a4"]
    present_notations = sorted(
        {
            str(
                row.get("audit", {})
                .get("artifact_evidence", {})
                .get("notation")
            )
            for row in artifact_preflight_rows
            if row.get("artifact_type") == "verified_signed_crossing_assignment"
            and row.get("artifact_certified") is True
            and row.get("audit", {})
            .get("artifact_evidence", {})
            .get("notation")
            in required_notations
        }
    )
    missing_notations = [
        notation for notation in required_notations if notation not in present_notations
    ]
    return {
        "required_notations": required_notations,
        "present_notations": present_notations,
        "missing_notation_count": len(missing_notations),
        "missing_notations": missing_notations,
        "all_required_notations_present": not missing_notations,
    }


def _discover_completion_evidence_files(directory: Path | None) -> dict:
    result = {
        "verified_signed_crossing_assignments": [],
        "production_imgui_renderer_framebuffer_pack": None,
        "signed_release_publication_manifest": None,
        "full_homfly_pt_evaluation_certification_pack": None,
        "full_multivariable_alexander_normalization_certification_pack": None,
        "discovered_file_count": 0,
    }
    if directory is None:
        return result
    single_artifacts = [
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
    ]
    for path in sorted(directory.glob("verified_signed_crossing_assignment*.json")):
        result["verified_signed_crossing_assignments"].append(path)
    for artifact in single_artifacts:
        result[artifact] = _discover_completion_evidence_file(directory, artifact)
    result["discovered_file_count"] = len(
        result["verified_signed_crossing_assignments"]
    ) + sum(1 for artifact in single_artifacts if result[artifact] is not None)
    return result


def _discover_completion_evidence_file(directory: Path, artifact: str) -> Path | None:
    preferred = directory / f"{artifact}.json"
    if preferred.exists():
        return preferred
    template = directory / f"{artifact}.template.json"
    if template.exists():
        return template
    matches = sorted(directory.glob(f"{artifact}*.json"))
    return matches[0] if matches else None


def _completion_evidence_requirements_command(args: argparse.Namespace) -> dict:
    audit = cross_workstream_validation_pack_audit()
    artifact_rows = []
    artifact_metadata = _completion_evidence_artifact_metadata_by_id()
    final_blockers_by_missing_artifact = {}
    for blocker in audit["final_completion_blockers"]:
        missing_artifact = blocker.get("missing_artifact")
        if isinstance(missing_artifact, str) and missing_artifact:
            final_blockers_by_missing_artifact.setdefault(missing_artifact, []).append(
                blocker
            )
    final_gates_by_missing_artifact = {}
    for gate_row in audit["final_completion_gate_checks"]:
        if gate_row.get("passed") is True:
            continue
        for missing_artifact in audit["final_completion_missing_artifacts"]:
            artifact_filenames = list(
                gate_row.get("completion_evidence_artifact_filenames") or []
            )
            artifact_referenced = any(
                filename == f"{missing_artifact}.json"
                or filename.startswith(f"{missing_artifact}.")
                for filename in artifact_filenames
            )
            if (
                gate_row.get("missing_artifact") == missing_artifact
                or gate_row.get("missing_artifact_id") == missing_artifact
                or artifact_referenced
            ):
                final_gates_by_missing_artifact.setdefault(
                    missing_artifact, []
                ).append(gate_row)
    for row in audit["final_completion_missing_artifact_summary"]:
        missing_artifact = row["missing_artifact"]
        metadata = artifact_metadata.get(missing_artifact, {})
        final_blockers = final_blockers_by_missing_artifact.get(missing_artifact, [])
        final_gates = final_gates_by_missing_artifact.get(missing_artifact, [])
        final_gate_names = [str(gate_row["gate"]) for gate_row in final_gates]
        readiness_rows = []
        readiness_blockers = set()
        for blocker in final_blockers:
            source_candidate_evidence = blocker.get("source_candidate_evidence")
            if not isinstance(source_candidate_evidence, dict):
                continue
            readiness = source_candidate_evidence.get(
                "verified_assignment_readiness"
            )
            if not isinstance(readiness, dict):
                continue
            readiness_row = {
                "notation": blocker.get("notation"),
                "claim_scope": readiness.get("claim_scope"),
                "ready": readiness.get("ready") is True,
                "check_count": int(readiness.get("check_count") or 0),
                "passed_check_count": int(readiness.get("passed_check_count") or 0),
                "failed_check_count": int(readiness.get("failed_check_count") or 0),
                "checks": dict(readiness.get("checks") or {}),
                "blockers": list(readiness.get("blockers") or []),
                "source_candidate_evidence_available": (
                    source_candidate_evidence.get("available") is True
                ),
                "source_method": source_candidate_evidence.get("source_method"),
                "gauss_code_match_required": (
                    source_candidate_evidence.get("gauss_code_match_required")
                    is True
                ),
                "target_pairwise_linking": source_candidate_evidence.get(
                    "target_pairwise_linking"
                ),
                "orientation_sample_count": int(
                    source_candidate_evidence.get("orientation_sample_count") or 0
                ),
                "matching_candidate_count": int(
                    source_candidate_evidence.get("matching_candidate_count") or 0
                ),
                "returned_candidate_count": int(
                    source_candidate_evidence.get("returned_candidate_count") or 0
                ),
                "unique_sign_pattern_count": int(
                    source_candidate_evidence.get("unique_sign_pattern_count") or 0
                ),
                "mirror_pair_count": int(
                    source_candidate_evidence.get("mirror_pair_count") or 0
                ),
                "candidate_group_count": int(
                    source_candidate_evidence.get("candidate_group_count") or 0
                ),
                "complete_candidate_set": (
                    source_candidate_evidence.get("complete_candidate_set") is True
                ),
                "stable_invariants": list(
                    source_candidate_evidence.get("stable_invariants") or []
                ),
                "stable_invariant_count": int(
                    source_candidate_evidence.get("stable_invariant_count") or 0
                ),
                "replay_checked_candidate_count": int(
                    source_candidate_evidence.get("replay_checked_candidate_count")
                    or 0
                ),
                "replay_valid_replay_count": int(
                    source_candidate_evidence.get("replay_valid_replay_count") or 0
                ),
                "all_returned_candidates_have_valid_replay": (
                    source_candidate_evidence.get(
                        "all_returned_candidates_have_valid_replay"
                    )
                    is True
                ),
                "unique_candidate": (
                    source_candidate_evidence.get("unique_candidate") is True
                ),
                "registration_blocker_code": source_candidate_evidence.get(
                    "registration_blocker_code"
                ),
            }
            readiness_rows.append(readiness_row)
            readiness_blockers.update(readiness_row["blockers"])
        if not readiness_rows:
            readiness_row = _completion_evidence_artifact_readiness(
                missing_artifact,
                final_blockers=final_blockers,
            )
            if readiness_row is not None:
                readiness_rows.append(readiness_row)
                readiness_blockers.update(readiness_row["blockers"])
        repeatable = metadata.get("repeatable", False)
        required_instance_labels = (
            sorted(
                {
                    str(label)
                    for label in row.get("blocker_labels", [])
                    if isinstance(label, str) and label
                }
            )
            if repeatable
            else []
        )
        artifact_rows.append(
            {
                **row,
                "bundle_key": metadata.get("bundle_key"),
                "bundle_required": metadata.get("bundle_required", True),
                "producer_cli_argument": metadata.get("producer_cli_argument"),
                "audit_cli_argument": metadata.get("audit_cli_argument"),
                "template_filename": _completion_evidence_template_filename(
                    missing_artifact,
                    label=None,
                ),
                "preflight_command": (
                    "iroll completion-evidence-artifact-audit "
                    f"<{missing_artifact}.json> "
                    f"--artifact-type {metadata.get('artifact_type', missing_artifact)} "
                    "--fail-on-not-certified"
                ),
                "bundle_input_example": (
                    "iroll completion-evidence-bundle "
                    f"{metadata.get('producer_cli_argument')} "
                    f"<{missing_artifact}.json>"
                    if metadata.get("producer_cli_argument") is not None
                    else None
                ),
                "repeatable": repeatable,
                "repeatable_instance_coverage_required": (
                    repeatable and bool(required_instance_labels)
                ),
                "required_instance_count": len(required_instance_labels),
                "required_instance_labels": required_instance_labels,
                "expected_artifact_kind": metadata.get("expected_artifact_kind"),
                "expected_claim_scope": metadata.get("expected_claim_scope"),
                "final_blocker_count": len(final_blockers),
                "final_completion_blocker_codes": list(row["blocker_codes"]),
                "final_completion_blocker_count": int(row["blocker_count"]),
                "final_completion_blocker_labels": list(row["blocker_labels"]),
                "final_completion_failed_gates": final_gate_names,
                "final_completion_failed_gate_count": len(final_gate_names),
                "final_completion_failed_gate_signature": "|".join(
                    final_gate_names
                ),
                "producer_readiness_available": bool(readiness_rows),
                "producer_readiness_count": len(readiness_rows),
                "producer_readiness_ready_count": sum(
                    1 for readiness in readiness_rows if readiness["ready"]
                ),
                "producer_readiness_blockers": sorted(readiness_blockers),
                "producer_readiness": readiness_rows,
            }
        )
    producer_readiness_count = sum(
        row["producer_readiness_count"] for row in artifact_rows
    )
    producer_readiness_ready_count = sum(
        row["producer_readiness_ready_count"] for row in artifact_rows
    )
    producer_readiness_blockers = sorted(
        {
            blocker
            for row in artifact_rows
            for readiness in row["producer_readiness"]
            for blocker in readiness["blockers"]
        }
    )
    producer_readiness_blocker_code_counts = {
        blocker: sum(
            1
            for row in artifact_rows
            for readiness in row["producer_readiness"]
            for row_blocker in readiness["blockers"]
            if row_blocker == blocker
        )
        for blocker in producer_readiness_blockers
    }
    producer_readiness_blocker_occurrence_count = sum(
        producer_readiness_blocker_code_counts.values()
    )
    required_instance_labels = sorted(
        {
            label
            for row in artifact_rows
            for label in row["required_instance_labels"]
        }
    )
    retained_evidence_summary = _completion_evidence_retained_readiness_summary(
        artifact_rows
    )
    final_completion_failed_gates = [
        str(row["gate"])
        for row in audit["final_completion_gate_checks"]
        if row.get("passed") is not True
    ]
    artifact_instance_command_rows = []
    for row in artifact_rows:
        labels = row["required_instance_labels"] or [None]
        for label in labels:
            template_filename = _completion_evidence_template_filename(
                row["missing_artifact"],
                label=label,
            )
            artifact_filename = template_filename.replace(".template.json", ".json")
            final_blocker_labels = (
                [label]
                if label is not None
                else row["final_completion_blocker_labels"]
            )
            final_blocker_count = (
                len(final_blocker_labels)
                if label is not None
                else row["final_completion_blocker_count"]
            )
            artifact_instance_command_rows.append(
                {
                    "missing_artifact": row["missing_artifact"],
                    "instance_label": label,
                    "artifact_filename": artifact_filename,
                    "template_filename": template_filename,
                    "template_to_artifact_filename": artifact_filename,
                    "template_to_artifact_note": (
                        f"copy {template_filename} to {artifact_filename} "
                        "and replace placeholder values with certified evidence"
                    ),
                    "preflight_command": (
                        "iroll completion-evidence-artifact-audit "
                        f"<{artifact_filename}> "
                        f"--artifact-type {row['missing_artifact']} "
                        "--fail-on-not-certified"
                    ),
                    "bundle_input_example": (
                        "iroll completion-evidence-bundle "
                        f"{row['producer_cli_argument']} <{artifact_filename}>"
                    ),
                    "producer_cli_argument": row["producer_cli_argument"],
                    "audit_cli_argument": row["audit_cli_argument"],
                    "repeatable_instance_coverage_required": row[
                        "repeatable_instance_coverage_required"
                    ],
                    "required_instance_labels": row["required_instance_labels"],
                    "final_completion_blocker_codes": row[
                        "final_completion_blocker_codes"
                    ],
                    "final_completion_blocker_count": final_blocker_count,
                    "final_completion_blocker_labels": final_blocker_labels,
                    "final_completion_failed_gates": row[
                        "final_completion_failed_gates"
                    ],
                    "final_completion_failed_gate_count": row[
                        "final_completion_failed_gate_count"
                    ],
                    "final_completion_failed_gate_signature": row[
                        "final_completion_failed_gate_signature"
                    ],
                    "producer_readiness_ready_count": row[
                        "producer_readiness_ready_count"
                    ],
                    "producer_readiness_count": row["producer_readiness_count"],
                    "producer_readiness_blockers": row[
                        "producer_readiness_blockers"
                    ],
                }
            )
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "cross_workstream_completion_evidence_requirements",
        "claim_scope": "cross_workstream_final_completion_evidence_requirements",
        "source_method": "iroll completion-evidence-requirements",
        "final_completion_ready": audit["final_completion_ready"],
        "final_completion_blocker_count": audit["final_completion_blocker_count"],
        "final_completion_gate_count": audit["final_completion_gate_count"],
        "final_completion_passed_gate_count": audit[
            "final_completion_passed_gate_count"
        ],
        "final_completion_failed_gate_count": audit[
            "final_completion_failed_gate_count"
        ],
        "final_completion_failed_gates": final_completion_failed_gates,
        "final_completion_failed_gate_signature": "|".join(
            final_completion_failed_gates
        ),
        "final_completion_blocker_code_count": audit[
            "final_completion_blocker_code_count"
        ],
        "final_completion_blocker_code_counts": (
            audit["final_completion_blocker_code_counts"]
        ),
        "final_completion_blocker_codes": audit["final_completion_blocker_codes"],
        "final_completion_blocker_signature": audit[
            "final_completion_blocker_signature"
        ],
        "final_completion_missing_artifact_count": audit[
            "final_completion_missing_artifact_count"
        ],
        "final_completion_missing_artifacts": audit[
            "final_completion_missing_artifacts"
        ],
        "final_completion_missing_artifact_signature": audit[
            "final_completion_missing_artifact_signature"
        ],
        "final_completion_missing_artifact_summary_consistency": audit[
            "final_completion_missing_artifact_summary_consistency"
        ],
        "final_completion_missing_artifact_summary_consistency_matched": (
            audit["final_completion_missing_artifact_summary_consistency"][
                "matched"
            ]
            is True
        ),
        "required_artifact_count": len(artifact_rows),
        "required_missing_artifacts": [
            row["missing_artifact"] for row in artifact_rows
        ],
        "required_missing_artifact_signature": "|".join(
            row["missing_artifact"] for row in artifact_rows
        ),
        "required_artifacts": artifact_rows,
        "artifact_preflight_commands": [
            row["preflight_command"] for row in artifact_rows
        ],
        "artifact_bundle_input_examples": [
            row["bundle_input_example"]
            for row in artifact_rows
            if row.get("bundle_input_example") is not None
        ],
        "artifact_template_filenames": [
            row["template_filename"] for row in artifact_rows
        ],
        "artifact_producer_cli_arguments": [
            row["producer_cli_argument"]
            for row in artifact_rows
            if row.get("producer_cli_argument") is not None
        ],
        "artifact_audit_cli_arguments": [
            row["audit_cli_argument"]
            for row in artifact_rows
            if row.get("audit_cli_argument") is not None
        ],
        "artifact_command_rows": [
            {
                "missing_artifact": row["missing_artifact"],
                "expected_artifact_kind": row["expected_artifact_kind"],
                "expected_claim_scope": row["expected_claim_scope"],
                "template_filename": row["template_filename"],
                "preflight_command": row["preflight_command"],
                "bundle_input_example": row["bundle_input_example"],
                "producer_cli_argument": row["producer_cli_argument"],
                "audit_cli_argument": row["audit_cli_argument"],
                "repeatable_instance_coverage_required": row[
                    "repeatable_instance_coverage_required"
                ],
                "required_instance_labels": row["required_instance_labels"],
                "final_completion_blocker_codes": row[
                    "final_completion_blocker_codes"
                ],
                "final_completion_blocker_count": row[
                    "final_completion_blocker_count"
                ],
                "final_completion_blocker_labels": row[
                    "final_completion_blocker_labels"
                ],
                "final_completion_failed_gates": row[
                    "final_completion_failed_gates"
                ],
                "final_completion_failed_gate_count": row[
                    "final_completion_failed_gate_count"
                ],
                "final_completion_failed_gate_signature": row[
                    "final_completion_failed_gate_signature"
                ],
                "producer_readiness_ready_count": row[
                    "producer_readiness_ready_count"
                ],
                "producer_readiness_count": row["producer_readiness_count"],
                "producer_readiness_blockers": row["producer_readiness_blockers"],
            }
            for row in artifact_rows
        ],
        "artifact_command_row_count": len(artifact_rows),
        "artifact_instance_command_rows": artifact_instance_command_rows,
        "artifact_instance_command_row_count": len(artifact_instance_command_rows),
        "expected_evidence_filename_count": len(artifact_instance_command_rows),
        "expected_evidence_filenames": [
            row["artifact_filename"] for row in artifact_instance_command_rows
        ],
        "expected_evidence_filename_signature": "|".join(
            row["artifact_filename"] for row in artifact_instance_command_rows
        ),
        "bundle_all_inputs_command": (
            "iroll completion-evidence-bundle "
            + " ".join(
                f"{row['producer_cli_argument']} <{row['artifact_filename']}>"
                for row in artifact_instance_command_rows
            )
            + " -o completion-evidence-bundle.json"
        ),
        "directory_audit_command": (
            "iroll completion-evidence-directory-audit <evidence-directory> "
            "--validate-artifacts --bundle-output completion-evidence-bundle.json "
            "--validation-output validation-pack-audit.json --fail-on-not-ready"
        ),
        "final_validation_command": (
            "iroll fixture-validation-pack-audit "
            "--completion-evidence-bundle-json completion-evidence-bundle.json "
            "--fail-on-not-ready"
        ),
        "producer_readiness_available": producer_readiness_count > 0,
        "producer_readiness_count": producer_readiness_count,
        "producer_readiness_ready_count": producer_readiness_ready_count,
        "producer_readiness_all_ready": (
            producer_readiness_count > 0
            and producer_readiness_ready_count == producer_readiness_count
        ),
        "producer_readiness_blocker_count": len(producer_readiness_blockers),
        "producer_readiness_blockers": producer_readiness_blockers,
        "producer_readiness_blocker_occurrence_count": (
            producer_readiness_blocker_occurrence_count
        ),
        "producer_readiness_blocker_code_counts": (
            producer_readiness_blocker_code_counts
        ),
        "producer_readiness_blocker_count_signature": ",".join(
            f"{blocker}:{producer_readiness_blocker_code_counts[blocker]}"
            for blocker in producer_readiness_blockers
        ),
        "producer_readiness_blocker_signature": "|".join(
            producer_readiness_blockers
        ),
        "repeatable_instance_coverage_required": any(
            row["repeatable_instance_coverage_required"] for row in artifact_rows
        ),
        "required_instance_count": len(required_instance_labels),
        "required_instance_labels": required_instance_labels,
        **retained_evidence_summary,
        "bundle_artifact_kind": "cross_workstream_completion_evidence_bundle",
        "bundle_claim_scope": "cross_workstream_final_completion_evidence",
        "bundle_producer_command": "iroll completion-evidence-bundle",
        "bundle_audit_command": (
            "iroll fixture-validation-pack-audit "
            "--completion-evidence-bundle-json <path>"
        ),
        "notes": [
            "requirements are derived from the default validation-pack audit",
            "this manifest does not certify or fabricate missing external evidence",
        ],
    }


def _completion_evidence_retained_readiness_summary(
    artifact_rows: Sequence[Mapping[str, object]],
) -> dict:
    readiness_rows = [
        readiness
        for row in artifact_rows
        for readiness in (
            row.get("producer_readiness")
            if isinstance(row.get("producer_readiness"), list)
            else []
        )
        if isinstance(readiness, Mapping)
    ]
    retained_ids = sorted(
        {
            str(evidence_id)
            for readiness in readiness_rows
            for evidence_id in (
                readiness.get("retained_evidence_ids")
                if isinstance(readiness.get("retained_evidence_ids"), list)
                else []
            )
            if evidence_id
        }
    )
    retained_kinds = sorted(
        {
            str(kind)
            for readiness in readiness_rows
            for kind in (
                readiness.get("retained_evidence_kinds")
                if isinstance(readiness.get("retained_evidence_kinds"), list)
                else []
            )
            if kind
        }
    )
    retained_source_methods = sorted(
        {
            str(source_method)
            for readiness in readiness_rows
            for source_method in (
                readiness.get("retained_evidence_source_methods")
                if isinstance(readiness.get("retained_evidence_source_methods"), list)
                else []
            )
            if source_method
        }
    )

    def sum_int(field: str) -> int:
        return sum(int(readiness.get(field) or 0) for readiness in readiness_rows)

    return {
        "retained_evidence_available": bool(retained_ids),
        "retained_evidence_readiness_row_count": sum(
            1
            for readiness in readiness_rows
            if readiness.get("retained_evidence_available") is True
        ),
        "retained_evidence_count": sum_int("retained_evidence_count"),
        "retained_evidence_distinct_count": len(retained_ids),
        "retained_evidence_ids": retained_ids,
        "retained_evidence_kinds": retained_kinds,
        "retained_evidence_source_methods": retained_source_methods,
        "retained_evidence_repository_test_count": sum_int(
            "retained_evidence_repository_test_count"
        ),
        "retained_evidence_ci_retained_artifact_count": sum_int(
            "retained_evidence_ci_retained_artifact_count"
        ),
        "retained_evidence_registered_fixture_scope_count": sum_int(
            "retained_evidence_registered_fixture_scope_count"
        ),
        "retained_evidence_bounded_scope_count": sum_int(
            "retained_evidence_bounded_scope_count"
        ),
        "retained_evidence_completion_claimed_count": sum_int(
            "retained_evidence_completion_claimed_count"
        ),
        "retained_evidence_signed_release_artifacts_published_count": sum_int(
            "retained_evidence_signed_release_artifacts_published_count"
        ),
        "retained_evidence_publication_claimed_count": sum_int(
            "retained_evidence_publication_claimed_count"
        ),
        "retained_evidence_platform_index_publication_claimed_count": sum_int(
            "retained_evidence_platform_index_publication_claimed_count"
        ),
        "retained_evidence_real_graphics_backend_framebuffer_verified_count": sum_int(
            "retained_evidence_real_graphics_backend_framebuffer_verified_count"
        ),
        "retained_evidence_screenshot_verified_count": sum_int(
            "retained_evidence_screenshot_verified_count"
        ),
    }


def _completion_evidence_retained_summary_from_requirements(
    requirements: Mapping[str, object],
) -> dict:
    return {
        key: requirements[key]
        for key in (
            "retained_evidence_available",
            "retained_evidence_readiness_row_count",
            "retained_evidence_count",
            "retained_evidence_distinct_count",
            "retained_evidence_ids",
            "retained_evidence_kinds",
            "retained_evidence_source_methods",
            "retained_evidence_repository_test_count",
            "retained_evidence_ci_retained_artifact_count",
            "retained_evidence_registered_fixture_scope_count",
            "retained_evidence_bounded_scope_count",
            "retained_evidence_completion_claimed_count",
            "retained_evidence_signed_release_artifacts_published_count",
            "retained_evidence_publication_claimed_count",
            "retained_evidence_platform_index_publication_claimed_count",
            "retained_evidence_real_graphics_backend_framebuffer_verified_count",
            "retained_evidence_screenshot_verified_count",
        )
    }


def _completion_evidence_final_audit_summary_from_requirements(
    requirements: Mapping[str, object],
) -> dict:
    return {
        key: requirements[key]
        for key in (
            "final_completion_gate_count",
            "final_completion_passed_gate_count",
            "final_completion_failed_gate_count",
            "final_completion_failed_gates",
            "final_completion_failed_gate_signature",
            "final_completion_blocker_count",
            "final_completion_blocker_code_count",
            "final_completion_blocker_code_counts",
            "final_completion_blocker_codes",
            "final_completion_blocker_signature",
            "final_completion_missing_artifact_count",
            "final_completion_missing_artifacts",
            "final_completion_missing_artifact_signature",
            "final_completion_missing_artifact_summary_consistency",
            "final_completion_missing_artifact_summary_consistency_matched",
        )
    }


def _completion_evidence_source_candidate_diagnostics(notation: str) -> dict:
    fixture = get_diagram_fixture(notation)
    report = fixture.source_invariant_candidate_diagnostics(
        max_orientation_samples=64,
        max_candidates=64,
        compute_homfly=True,
        compute_alexander=True,
        homfly_max_depth=12,
        homfly_max_nodes=4096,
        alexander_max_minors=128,
    )
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "verified_signed_crossing_assignment_source_candidate_diagnostics",
        "claim_scope": "verified_signed_crossing_assignment_candidate_diagnostics",
        "source_method": "iroll completion-evidence-review-bundle",
        "required_artifact": "verified_signed_crossing_assignment",
        "completion_claimed": False,
        "final_completion_ready": False,
        "notes": [
            "review-bundle source-candidate diagnostics are convention evidence only",
            "they do not certify a unique signed crossing assignment",
            *list(report.get("notes", [])),
        ],
        **{key: value for key, value in report.items() if key != "notes"},
    }


def _completion_evidence_source_table_diagnostics(notation: str) -> dict:
    fixture = get_diagram_fixture(notation)
    report = fixture.source_table_invariant_audit(
        max_orientation_samples=64,
        max_candidates=64,
        compute_homfly=True,
        compute_alexander=True,
        homfly_max_depth=12,
        homfly_max_nodes=4096,
        alexander_max_minors=128,
    )
    return {
        "artifact_schema_version": 1,
        "artifact_kind": (
            "verified_signed_crossing_assignment_source_table_diagnostics"
        ),
        "claim_scope": "verified_signed_crossing_assignment_source_table_diagnostics",
        "source_method": "iroll completion-evidence-review-bundle",
        "required_artifact": "verified_signed_crossing_assignment",
        "completion_claimed": False,
        "final_completion_ready": False,
        "notes": [
            "review-bundle source-table diagnostics compare candidates to external table values",
            "they do not certify a unique signed crossing assignment",
            *list(report.get("notes", [])),
        ],
        **{key: value for key, value in report.items() if key != "notes"},
    }


def _completion_evidence_review_generated_report_row(
    filename: str,
    path: Path,
    report: Mapping[str, object],
) -> dict:
    row = {
        "filename": filename,
        "path": str(path),
        "artifact_kind": report.get("artifact_kind"),
        "claim_scope": report.get("claim_scope"),
        "final_completion_ready": report.get("final_completion_ready"),
        "completion_claimed": report.get("completion_claimed", False),
        "readiness_all_ready": report.get("readiness_all_ready"),
        "readiness_blocker_count": report.get("readiness_blocker_count"),
        "readiness_blocker_codes": report.get("readiness_blocker_codes"),
        "readiness_blocker_code_counts": report.get(
            "readiness_blocker_code_counts"
        ),
        "readiness_blocker_count_signature": report.get(
            "readiness_blocker_count_signature"
        ),
        "readiness_blocker_signature": report.get("readiness_blocker_signature"),
    }
    mirrored_keys = (
        "completion_evidence_missing_artifact",
        "completion_evidence_artifact_filename_count",
        "completion_evidence_artifact_filenames",
        "completion_evidence_artifact_filename_signature",
        "completion_evidence_template_filenames",
        "completion_evidence_template_to_artifact_filenames",
        "completion_evidence_artifact_instance_row_count",
        "completion_evidence_artifact_filenames_are_expected",
        "completion_evidence_template_to_artifact_filenames_match_artifact_filenames",
        "completion_evidence_artifact_filename_count_matches_instance_row_count",
        "completion_evidence_artifact_filename_signature_matches_instance_rows",
        "completion_evidence_producer_metadata_consistency_passed",
        "completion_evidence_final_completion_failed_gates",
        "completion_evidence_final_completion_failed_gate_count",
        "completion_evidence_final_completion_failed_gate_signature",
        "completion_evidence_final_completion_blocker_codes",
        "completion_evidence_final_completion_blocker_code_count",
        "completion_evidence_final_completion_blocker_count",
        "completion_evidence_final_completion_blocker_labels",
        "completion_evidence_final_completion_blocker_label_count",
        "expected_evidence_filename_count",
        "expected_evidence_filenames",
        "expected_evidence_filename_signature",
        "final_completion_failed_gate_count",
        "final_completion_failed_gates",
        "final_completion_failed_gate_signature",
        "final_completion_blocker_count",
        "final_completion_blocker_code_count",
        "final_completion_blocker_code_counts",
        "final_completion_blocker_codes",
        "final_completion_blocker_signature",
        "final_completion_missing_artifact_count",
        "final_completion_missing_artifacts",
        "final_completion_missing_artifact_signature",
        "contract_instance_row_count",
        "missing_input_artifact_count",
        "missing_input_artifact_filenames",
        "missing_input_artifact_signature",
        "template_file_count",
        "template_filenames",
        "template_to_artifact_filenames",
    )
    for key in mirrored_keys:
        if key in report:
            row[key] = report[key]
    if "template_to_artifact_filenames" in report:
        row["template_to_artifact_filename_signature"] = "|".join(
            str(value) for value in report["template_to_artifact_filenames"]
        )
    return row


def _completion_evidence_review_bundle_command(args: argparse.Namespace) -> dict:
    directory = args.directory
    directory.mkdir(parents=True, exist_ok=True)
    templates_directory = directory / "completion-evidence-templates"
    assignment_readiness = verified_signed_crossing_assignment_readiness_report()
    _add_completion_evidence_producer_metadata(
        assignment_readiness,
        missing_artifact="verified_signed_crossing_assignment",
    )
    imgui_readiness = production_imgui_renderer_framebuffer_readiness_report()
    _add_completion_evidence_producer_metadata(
        imgui_readiness,
        missing_artifact="production_imgui_renderer_framebuffer_pack",
    )
    release_readiness = signed_release_publication_readiness_report()
    _add_completion_evidence_producer_metadata(
        release_readiness,
        missing_artifact="signed_release_publication_manifest",
    )
    homfly_readiness = full_homfly_pt_evaluation_readiness_report()
    _add_completion_evidence_producer_metadata(
        homfly_readiness,
        missing_artifact="full_homfly_pt_evaluation_certification_pack",
    )
    alexander_readiness = full_multivariable_alexander_normalization_readiness_report()
    _add_completion_evidence_producer_metadata(
        alexander_readiness,
        missing_artifact="full_multivariable_alexander_normalization_certification_pack",
    )
    source_candidate_diagnostics = [
        _completion_evidence_source_candidate_diagnostics(notation)
        for notation in ("L5a1", "L6a4")
    ]
    source_table_diagnostics = [
        _completion_evidence_source_table_diagnostics(notation)
        for notation in ("L5a1", "L6a4")
    ]

    reports: list[tuple[str, dict]] = [
        (
            "completion-evidence-requirements.json",
            _completion_evidence_requirements_command(args),
        ),
        (
            "completion-evidence-contracts.json",
            _completion_evidence_contracts_command(args),
        ),
        (
            "completion-evidence-ci-plan.json",
            _completion_evidence_ci_plan_command(args),
        ),
        (
            "verified-signed-crossing-assignment-readiness.json",
            assignment_readiness,
        ),
        (
            "production-imgui-renderer-framebuffer-readiness.json",
            imgui_readiness,
        ),
        (
            "signed-release-publication-readiness.json",
            release_readiness,
        ),
        (
            "full-homfly-pt-evaluation-readiness.json",
            homfly_readiness,
        ),
        (
            "full-multivariable-alexander-normalization-readiness.json",
            alexander_readiness,
        ),
        *(
            (f"source-invariant-{report['notation'].lower()}-candidates.json", report)
            for report in source_candidate_diagnostics
        ),
        *(
            (f"source-table-{report['notation'].lower()}-audit.json", report)
            for report in source_table_diagnostics
        ),
        (
            "validation-pack-audit.json",
            {
                "artifact_kind": "cross_workstream_validation_pack_audit",
                **cross_workstream_validation_pack_audit(),
            },
        ),
    ]
    template_index = _completion_evidence_templates_command(
        argparse.Namespace(
            directory=templates_directory,
            expand_repeatable=True,
        )
    )
    reports.append(("completion-evidence-templates.json", template_index))
    reports.append(
        (
            "completion-evidence-template-directory-audit.json",
            _completion_evidence_directory_audit_command(
                argparse.Namespace(
                    directory=templates_directory,
                    validate_artifacts=True,
                    bundle_output=None,
                    validation_output=None,
                    fail_on_not_ready=False,
                )
            ),
        )
    )
    template_directory_audit = reports[-1][1]
    validation = next(
        report for filename, report in reports if filename == "validation-pack-audit.json"
    )

    report_rows = []
    for filename, report in reports:
        path = directory / filename
        write_report(report, path)
        report_rows.append(
            _completion_evidence_review_generated_report_row(filename, path, report)
        )

    template_files = [
        path
        for path in sorted(templates_directory.glob("*.json"))
        if path.is_file()
    ]
    requirements = reports[0][1]
    traceability_report_rows = [
        row
        for row in report_rows
        if (
            row.get("completion_evidence_artifact_filename_signature")
            or row.get("expected_evidence_filename_signature")
            or row.get("template_to_artifact_filename_signature")
            or row.get("missing_input_artifact_signature")
        )
    ]
    producer_metadata_report_rows = [
        row
        for row in report_rows
        if "completion_evidence_producer_metadata_consistency_passed" in row
    ]
    producer_metadata_failed_rows = [
        row
        for row in producer_metadata_report_rows
        if row["completion_evidence_producer_metadata_consistency_passed"] is not True
    ]
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "cross_workstream_completion_evidence_review_bundle",
        "claim_scope": "cross_workstream_final_completion_evidence_review",
        "source_method": "iroll completion-evidence-review-bundle",
        "directory": str(directory),
        "generated_report_count": len(report_rows),
        "generated_reports": report_rows,
        "traceability_report_count": len(traceability_report_rows),
        "traceability_report_files": [
            row["filename"] for row in traceability_report_rows
        ],
        "traceability_artifact_filename_signatures_by_report": {
            row["filename"]: (
                row.get("completion_evidence_artifact_filename_signature")
                or row.get("expected_evidence_filename_signature")
                or row.get("template_to_artifact_filename_signature")
                or row.get("missing_input_artifact_signature")
            )
            for row in traceability_report_rows
        },
        "producer_metadata_consistency_report_count": len(
            producer_metadata_report_rows
        ),
        "producer_metadata_consistency_passed_count": (
            len(producer_metadata_report_rows) - len(producer_metadata_failed_rows)
        ),
        "producer_metadata_consistency_failed_count": len(
            producer_metadata_failed_rows
        ),
        "producer_metadata_consistency_all_passed": (
            bool(producer_metadata_report_rows)
            and not producer_metadata_failed_rows
        ),
        "producer_metadata_consistency_report_files": [
            row["filename"] for row in producer_metadata_report_rows
        ],
        "producer_metadata_consistency_failed_files": [
            row["filename"] for row in producer_metadata_failed_rows
        ],
        "source_candidate_diagnostic_count": len(source_candidate_diagnostics),
        "source_candidate_diagnostic_files": [
            f"source-invariant-{report['notation'].lower()}-candidates.json"
            for report in source_candidate_diagnostics
        ],
        "source_table_diagnostic_count": len(source_table_diagnostics),
        "source_table_diagnostic_files": [
            f"source-table-{report['notation'].lower()}-audit.json"
            for report in source_table_diagnostics
        ],
        "template_directory": str(templates_directory),
        "template_file_count": len(template_files),
        "template_files": [str(path) for path in template_files],
        "template_directory_audit_available": True,
        "template_directory_audit_pipeline_ready": template_directory_audit[
            "completion_evidence_pipeline_ready"
        ],
        "template_directory_audit_blocker_count": template_directory_audit[
            "completion_evidence_pipeline_blocker_count"
        ],
        "template_directory_audit_blocker_codes": template_directory_audit[
            "completion_evidence_pipeline_blocker_codes"
        ],
        "template_directory_audit_blocker_signature": template_directory_audit[
            "completion_evidence_pipeline_blocker_signature"
        ],
        "template_directory_audit_missing_instance_filenames": (
            template_directory_audit["missing_instance_filenames"]
        ),
        "required_artifact_count": requirements["required_artifact_count"],
        "required_missing_artifacts": requirements["required_missing_artifacts"],
        "producer_readiness_count": requirements["producer_readiness_count"],
        "producer_readiness_ready_count": requirements[
            "producer_readiness_ready_count"
        ],
        "producer_readiness_blocker_count": requirements[
            "producer_readiness_blocker_count"
        ],
        "producer_readiness_blocker_occurrence_count": requirements[
            "producer_readiness_blocker_occurrence_count"
        ],
        "producer_readiness_blocker_code_counts": requirements[
            "producer_readiness_blocker_code_counts"
        ],
        "producer_readiness_blocker_count_signature": requirements[
            "producer_readiness_blocker_count_signature"
        ],
        "producer_readiness_blocker_signature": requirements[
            "producer_readiness_blocker_signature"
        ],
        "artifact_command_row_count": requirements["artifact_command_row_count"],
        "artifact_instance_command_row_count": requirements[
            "artifact_instance_command_row_count"
        ],
        "expected_evidence_filename_count": requirements[
            "expected_evidence_filename_count"
        ],
        "expected_evidence_filenames": requirements["expected_evidence_filenames"],
        "expected_evidence_filename_signature": requirements[
            "expected_evidence_filename_signature"
        ],
        "bundle_all_inputs_command": requirements["bundle_all_inputs_command"],
        "directory_audit_command": requirements["directory_audit_command"],
        "final_validation_command": requirements["final_validation_command"],
        "final_completion_ready": validation["final_completion_ready"],
        "final_completion_failed_gate_count": validation[
            "final_completion_failed_gate_count"
        ],
        "final_completion_failed_gates": requirements[
            "final_completion_failed_gates"
        ],
        "final_completion_failed_gate_signature": requirements[
            "final_completion_failed_gate_signature"
        ],
        "final_completion_blocker_count": validation[
            "final_completion_blocker_count"
        ],
        "final_completion_blocker_code_count": requirements[
            "final_completion_blocker_code_count"
        ],
        "final_completion_blocker_codes": requirements[
            "final_completion_blocker_codes"
        ],
        "final_completion_blocker_code_counts": requirements[
            "final_completion_blocker_code_counts"
        ],
        "final_completion_blocker_signature": requirements[
            "final_completion_blocker_signature"
        ],
        "final_completion_missing_artifact_count": validation[
            "final_completion_missing_artifact_count"
        ],
        "final_completion_missing_artifacts": validation[
            "final_completion_missing_artifacts"
        ],
        "final_completion_missing_artifact_signature": requirements[
            "final_completion_missing_artifact_signature"
        ],
        "completion_claimed": False,
        "notes": [
            "review bundle materializes current blocker evidence only",
            "it does not certify or fabricate missing external completion artifacts",
        ],
    }


def _completion_evidence_ci_plan_command(args: argparse.Namespace) -> dict:
    requirements = _completion_evidence_requirements_command(args)
    evidence_directory = "<evidence-dir>"
    bundle_path = "<completion-evidence-bundle.json>"
    validation_path = "<validation-pack-audit.json>"
    review_bundle_directory = f"{evidence_directory}/completion-evidence-review-bundle"
    review_bundle_index_path = (
        f"{review_bundle_directory}/completion-evidence-review-index.json"
    )
    required_artifacts = list(requirements["required_artifacts"])
    plan_steps = [
        {
            "step": "publish_requirements",
            "required": True,
            "hard_gate": False,
            "command": "iroll completion-evidence-requirements",
            "purpose": "publish the current missing-artifact and producer-readiness manifest",
            "expected_output_artifact_kind": (
                "cross_workstream_completion_evidence_requirements"
            ),
            "expected_output_claim_scope": (
                "cross_workstream_final_completion_evidence_requirements"
            ),
            "ready_field": "final_completion_ready",
            "required_ready_fields": ["final_completion_ready"],
            "ready_when": "false_until_external_artifacts_exist",
            "failure_mode": "report_only",
        },
        {
            "step": "publish_templates",
            "required": False,
            "hard_gate": False,
            "command": (
                f"iroll completion-evidence-templates --expand-repeatable "
                f"--directory {evidence_directory}"
            ),
            "purpose": "retain non-certified template files for external evidence producers",
            "expected_output_artifact_kind": (
                "cross_workstream_completion_evidence_templates"
            ),
            "expected_output_claim_scope": (
                "cross_workstream_final_completion_evidence_templates"
            ),
            "ready_field": "completion_claimed",
            "required_ready_fields": ["completion_claimed"],
            "ready_when": "false_template_scaffolding",
            "failure_mode": "report_only",
        },
        {
            "step": "publish_review_bundle",
            "required": False,
            "hard_gate": False,
            "command": (
                "iroll completion-evidence-review-bundle "
                f"{review_bundle_directory} -o {review_bundle_index_path}"
            ),
            "purpose": (
                "retain a single handoff directory containing the current "
                "requirements, contracts, CI plan, templates, readiness reports, "
                "and validation-pack audit"
            ),
            "expected_output_artifact_kind": (
                "cross_workstream_completion_evidence_review_bundle"
            ),
            "expected_output_claim_scope": (
                "cross_workstream_final_completion_evidence_review"
            ),
            "expected_output_index_filename": (
                "completion-evidence-review-index.json"
            ),
            "expected_output_index_path": review_bundle_index_path,
            "ready_field": "completion_claimed",
            "required_ready_fields": ["completion_claimed"],
            "ready_when": "false_review_handoff_bundle",
            "failure_mode": "report_only",
        },
        {
            "step": "produce_external_artifacts",
            "required": True,
            "hard_gate": False,
            "command": f"<external jobs write certified JSON artifacts into {evidence_directory}>",
            "purpose": "replace placeholders with independently certified completion evidence",
            "expected_output_artifact_kind": "external_completion_evidence_artifacts",
            "expected_output_claim_scope": "external_completion_evidence_production",
            "ready_field": "producer_readiness_ready_count",
            "required_ready_fields": ["producer_readiness_ready_count"],
            "ready_when": "all_required_external_artifacts_certified",
            "failure_mode": "external_job_failure",
        },
        {
            "step": "preflight_signed_assignment_readiness",
            "required": True,
            "hard_gate": False,
            "command": (
                "iroll verified-signed-crossing-assignment-readiness "
                "--fail-on-not-ready"
            ),
            "purpose": (
                "retain source-candidate blocker evidence before producing "
                "verified signed crossing assignment artifacts"
            ),
            "expected_output_artifact_kind": (
                "verified_signed_crossing_assignment_readiness_report"
            ),
            "expected_output_claim_scope": (
                "verified_signed_crossing_assignment_readiness"
            ),
            "ready_field": "readiness_all_ready",
            "required_ready_fields": [
                "readiness_all_ready",
                "readiness_blocker_codes",
                "readiness_blocker_signature",
            ],
            "ready_when": (
                "true_only_after_each_required_unsigned_source_fixture_has_a_"
                "unique_externally_verified_assignment"
            ),
            "failure_mode": "exit_1_with_fail_on_not_ready",
        },
        {
            "step": "preflight_production_imgui_framebuffer_readiness",
            "required": True,
            "hard_gate": False,
            "command": (
                "iroll production-imgui-renderer-framebuffer-readiness "
                "--fail-on-not-ready"
            ),
            "purpose": (
                "retain renderer blocker evidence before producing the "
                "production ImGui framebuffer pack"
            ),
            "expected_output_artifact_kind": (
                "production_imgui_renderer_framebuffer_readiness_report"
            ),
            "expected_output_claim_scope": (
                "production_imgui_renderer_framebuffer_readiness"
            ),
            "ready_field": "readiness_all_ready",
            "required_ready_fields": [
                "readiness_all_ready",
                "readiness_blocker_codes",
                "readiness_blocker_signature",
                "retained_real_graphics_backend_framebuffer_verified_count",
                "retained_screenshot_verified_count",
            ],
            "ready_when": (
                "true_only_after_a_real_graphics_backend_framebuffer_and_"
                "screenshot_are_verified"
            ),
            "failure_mode": "exit_1_with_fail_on_not_ready",
        },
        {
            "step": "preflight_signed_release_publication_readiness",
            "required": True,
            "hard_gate": False,
            "command": "iroll signed-release-publication-readiness --fail-on-not-ready",
            "purpose": (
                "retain publication blocker evidence before producing the "
                "signed release publication manifest"
            ),
            "expected_output_artifact_kind": (
                "signed_release_publication_readiness_report"
            ),
            "expected_output_claim_scope": "signed_release_publication_readiness",
            "ready_field": "readiness_all_ready",
            "required_ready_fields": [
                "readiness_all_ready",
                "readiness_blocker_codes",
                "readiness_blocker_signature",
                "retained_signed_release_artifacts_published_count",
                "retained_publication_claimed_count",
                "retained_platform_index_publication_claimed_count",
            ],
            "ready_when": (
                "true_only_after_signed_artifacts_and_platform_index_are_published"
            ),
            "failure_mode": "exit_1_with_fail_on_not_ready",
        },
        {
            "step": "preflight_full_homfly_pt_evaluation_readiness",
            "required": True,
            "hard_gate": False,
            "command": (
                "iroll full-homfly-pt-evaluation-readiness "
                "--fail-on-not-ready"
            ),
            "purpose": (
                "retain bounded HOMFLY-PT blocker evidence before producing "
                "the full HOMFLY-PT evaluation certification pack"
            ),
            "expected_output_artifact_kind": (
                "full_homfly_pt_evaluation_readiness_report"
            ),
            "expected_output_claim_scope": "full_homfly_pt_evaluation_readiness",
            "ready_field": "readiness_all_ready",
            "required_ready_fields": [
                "readiness_all_ready",
                "readiness_blocker_codes",
                "readiness_blocker_signature",
                "retained_repository_test_count",
                "retained_registered_fixture_scope_count",
                "retained_bounded_scope_count",
            ],
            "ready_when": (
                "true_only_after_full_homfly_pt_evaluation_"
                "certification_pack_is_certified"
            ),
            "failure_mode": "exit_1_with_fail_on_not_ready",
        },
        {
            "step": "preflight_full_multivariable_alexander_normalization_readiness",
            "required": True,
            "hard_gate": False,
            "command": (
                "iroll full-multivariable-alexander-normalization-readiness "
                "--fail-on-not-ready"
            ),
            "purpose": (
                "retain bounded Alexander blocker evidence before producing "
                "the full multivariable Alexander normalization certification pack"
            ),
            "expected_output_artifact_kind": (
                "full_multivariable_alexander_normalization_readiness_report"
            ),
            "expected_output_claim_scope": (
                "full_multivariable_alexander_normalization_readiness"
            ),
            "ready_field": "readiness_all_ready",
            "required_ready_fields": [
                "readiness_all_ready",
                "readiness_blocker_codes",
                "readiness_blocker_signature",
                "retained_repository_test_count",
                "retained_registered_fixture_scope_count",
                "retained_bounded_scope_count",
            ],
            "ready_when": (
                "true_only_after_full_multivariable_alexander_normalization_"
                "certification_pack_is_certified"
            ),
            "failure_mode": "exit_1_with_fail_on_not_ready",
        },
        {
            "step": "preflight_external_artifacts",
            "required": True,
            "hard_gate": True,
            "command": (
                "iroll completion-evidence-artifact-audit <artifact-json> "
                "--fail-on-not-certified"
            ),
            "purpose": "fail CI on each uncertified retained evidence artifact before bundling",
            "expected_output_artifact_kind": "completion_evidence_artifact_audit",
            "expected_output_claim_scope": "completion_evidence_artifact_preflight",
            "ready_field": "artifact_certified",
            "required_ready_fields": [
                "artifact_certified",
                "artifact_field_coverage_complete",
            ],
            "ready_when": "true_when_each_required_artifact_preflight_certified",
            "failure_mode": "exit_1_with_fail_on_not_certified",
        },
        {
            "step": "assemble_bundle",
            "required": True,
            "hard_gate": False,
            "command": (
                f"iroll completion-evidence-bundle --evidence-directory "
                f"{evidence_directory} -o {bundle_path}"
            ),
            "purpose": "assemble the discovered evidence into one auditable bundle",
            "expected_output_artifact_kind": (
                "cross_workstream_completion_evidence_bundle"
            ),
            "expected_output_claim_scope": "cross_workstream_final_completion_evidence",
            "ready_field": "bundle_inputs_complete",
            "required_ready_fields": [
                "bundle_inputs_complete",
                "bundle_contract_coverage_complete",
                "instance_filename_coverage_complete",
            ],
            "ready_when": "true_when_all_required_inputs_present",
            "failure_mode": "missing_inputs",
        },
        {
            "step": "audit_directory",
            "required": True,
            "hard_gate": True,
            "command": (
                f"iroll completion-evidence-directory-audit {evidence_directory} "
                f"--validate-artifacts --bundle-output {bundle_path} "
                f"--validation-output {validation_path} --fail-on-not-ready"
            ),
            "purpose": "fail CI if discovery or artifact-content validation is not ready",
            "expected_output_artifact_kind": (
                "cross_workstream_completion_evidence_directory_audit"
            ),
            "expected_output_claim_scope": (
                "cross_workstream_final_completion_evidence_directory_audit"
            ),
            "ready_field": "completion_evidence_pipeline_ready",
            "required_ready_fields": [
                "completion_evidence_pipeline_ready",
                "artifact_preflight_all_certified",
                "artifact_preflight_field_coverage_complete",
                "artifact_preflight_contract_coverage_complete",
                "artifact_validation_final_completion_ready",
                "instance_filename_coverage_complete",
                "pipeline_failed_required_step_signature",
                "completion_evidence_pipeline_blocker_signature",
            ],
            "ready_when": "true_when_discovery_and_validation_pass",
            "failure_mode": "exit_1_with_fail_on_not_ready",
        },
        {
            "step": "audit_bundle",
            "required": True,
            "hard_gate": True,
            "command": (
                f"iroll fixture-validation-pack-audit "
                f"--completion-evidence-bundle-json {bundle_path} "
                f"--fail-on-not-ready"
            ),
            "purpose": "fail CI unless the final validation-pack audit is ready",
            "expected_output_artifact_kind": "cross_workstream_validation_pack_audit",
            "expected_output_claim_scope": "final_completion_checklist_metadata_audit",
            "ready_field": "final_completion_ready",
            "required_ready_fields": [
                "final_completion_ready",
                "completion_evidence_bundle_certified",
                "artifact_preflight_field_coverage_complete",
                "bundle_contract_coverage_complete",
                "bundle_evidence_failed_check_signature",
            ],
            "ready_when": "true_when_all_final_gates_pass",
            "failure_mode": "exit_1_with_fail_on_not_ready",
        },
    ]
    hard_gate_steps = [row["step"] for row in plan_steps if row["hard_gate"]]
    artifact_instance_command_rows = []
    for row in required_artifacts:
        instance_labels = (
            row["required_instance_labels"]
            if row["repeatable_instance_coverage_required"]
            else [None]
        )
        for label in instance_labels:
            template_filename = _completion_evidence_template_filename(
                row["missing_artifact"],
                label=label,
            )
            artifact_filename = template_filename.replace(".template.json", ".json")
            final_blocker_labels = (
                [label]
                if label is not None
                else row["final_completion_blocker_labels"]
            )
            final_blocker_count = (
                len(final_blocker_labels)
                if label is not None
                else row["final_completion_blocker_count"]
            )
            artifact_instance_command_rows.append(
                {
                    "missing_artifact": row["missing_artifact"],
                    "instance_label": label,
                    "artifact_filename": artifact_filename,
                    "template_filename": template_filename,
                    "template_to_artifact_filename": artifact_filename,
                    "template_to_artifact_note": (
                        f"copy {template_filename} to {artifact_filename} "
                        "and replace placeholder values with certified evidence"
                    ),
                    "expected_artifact_kind": row["expected_artifact_kind"],
                    "expected_claim_scope": row["expected_claim_scope"],
                    "preflight_command": (
                        "iroll completion-evidence-artifact-audit "
                        f"<{artifact_filename}> "
                        f"--artifact-type {row['missing_artifact']} "
                        "--fail-on-not-certified"
                    ),
                    "bundle_input_example": (
                        "iroll completion-evidence-bundle "
                        f"{row['producer_cli_argument']} <{artifact_filename}>"
                    ),
                    "producer_cli_argument": row["producer_cli_argument"],
                    "audit_cli_argument": row["audit_cli_argument"],
                    "repeatable_instance_coverage_required": row[
                        "repeatable_instance_coverage_required"
                    ],
                    "required_instance_labels": row["required_instance_labels"],
                    "final_completion_blocker_codes": row[
                        "final_completion_blocker_codes"
                    ],
                    "final_completion_blocker_count": final_blocker_count,
                    "final_completion_blocker_labels": final_blocker_labels,
                    "final_completion_failed_gates": row[
                        "final_completion_failed_gates"
                    ],
                    "final_completion_failed_gate_count": row[
                        "final_completion_failed_gate_count"
                    ],
                    "final_completion_failed_gate_signature": row[
                        "final_completion_failed_gate_signature"
                    ],
                    "producer_readiness_ready_count": row[
                        "producer_readiness_ready_count"
                    ],
                    "producer_readiness_count": row["producer_readiness_count"],
                    "producer_readiness_blockers": row[
                        "producer_readiness_blockers"
                    ],
                }
            )
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "cross_workstream_completion_evidence_ci_plan",
        "claim_scope": "cross_workstream_final_completion_evidence_ci_plan",
        "source_method": "iroll completion-evidence-ci-plan",
        "final_completion_ready": requirements["final_completion_ready"],
        "final_completion_blocker_count": requirements[
            "final_completion_blocker_count"
        ],
        "final_completion_blocker_code_counts": requirements[
            "final_completion_blocker_code_counts"
        ],
        "required_artifact_count": requirements["required_artifact_count"],
        "producer_readiness_available": requirements[
            "producer_readiness_available"
        ],
        "producer_readiness_count": requirements["producer_readiness_count"],
        "producer_readiness_ready_count": requirements[
            "producer_readiness_ready_count"
        ],
        "producer_readiness_all_ready": requirements[
            "producer_readiness_all_ready"
        ],
        "producer_readiness_blocker_count": requirements[
            "producer_readiness_blocker_count"
        ],
        "producer_readiness_blockers": requirements["producer_readiness_blockers"],
        "producer_readiness_blocker_occurrence_count": requirements[
            "producer_readiness_blocker_occurrence_count"
        ],
        "producer_readiness_blocker_code_counts": requirements[
            "producer_readiness_blocker_code_counts"
        ],
        "producer_readiness_blocker_count_signature": requirements[
            "producer_readiness_blocker_count_signature"
        ],
        "producer_readiness_blocker_signature": requirements[
            "producer_readiness_blocker_signature"
        ],
        **_completion_evidence_final_audit_summary_from_requirements(requirements),
        **_completion_evidence_retained_summary_from_requirements(requirements),
        "repeatable_instance_coverage_required": requirements[
            "repeatable_instance_coverage_required"
        ],
        "required_instance_count": requirements["required_instance_count"],
        "required_instance_labels": requirements["required_instance_labels"],
        "required_missing_artifacts": [
            row["missing_artifact"] for row in required_artifacts
        ],
        "required_missing_artifact_signature": "|".join(
            row["missing_artifact"] for row in required_artifacts
        ),
        "artifact_preflight_commands": [
            row["preflight_command"] for row in required_artifacts
        ],
        "artifact_bundle_input_examples": [
            row["bundle_input_example"]
            for row in required_artifacts
            if row.get("bundle_input_example") is not None
        ],
        "artifact_template_filenames": [
            row["template_filename"] for row in required_artifacts
        ],
        "artifact_producer_cli_arguments": [
            row["producer_cli_argument"]
            for row in required_artifacts
            if row.get("producer_cli_argument") is not None
        ],
        "artifact_audit_cli_arguments": [
            row["audit_cli_argument"]
            for row in required_artifacts
            if row.get("audit_cli_argument") is not None
        ],
        "artifact_command_rows": [
            {
                "missing_artifact": row["missing_artifact"],
                "expected_artifact_kind": row["expected_artifact_kind"],
                "expected_claim_scope": row["expected_claim_scope"],
                "template_filename": row["template_filename"],
                "preflight_command": row["preflight_command"],
                "bundle_input_example": row["bundle_input_example"],
                "producer_cli_argument": row["producer_cli_argument"],
                "audit_cli_argument": row["audit_cli_argument"],
                "repeatable_instance_coverage_required": row[
                    "repeatable_instance_coverage_required"
                ],
                "required_instance_labels": row["required_instance_labels"],
                "producer_readiness_ready_count": row[
                    "producer_readiness_ready_count"
                ],
                "producer_readiness_count": row["producer_readiness_count"],
                "producer_readiness_blockers": row["producer_readiness_blockers"],
            }
            for row in required_artifacts
        ],
        "artifact_command_row_count": len(required_artifacts),
        "artifact_instance_command_rows": artifact_instance_command_rows,
        "artifact_instance_command_row_count": len(artifact_instance_command_rows),
        "expected_evidence_filename_count": requirements[
            "expected_evidence_filename_count"
        ],
        "expected_evidence_filenames": requirements["expected_evidence_filenames"],
        "expected_evidence_filename_signature": requirements[
            "expected_evidence_filename_signature"
        ],
        "bundle_all_inputs_command": requirements["bundle_all_inputs_command"],
        "directory_audit_command": requirements["directory_audit_command"],
        "final_validation_command": requirements["final_validation_command"],
        "review_bundle_directory": review_bundle_directory,
        "review_bundle_index_filename": "completion-evidence-review-index.json",
        "review_bundle_index_path": review_bundle_index_path,
        "hard_gate_commands": [
            row["command"]
            for row in plan_steps
            if row["hard_gate"]
        ],
        "hard_gate_step_count": len(hard_gate_steps),
        "hard_gate_steps": hard_gate_steps,
        "expected_output_artifact_kinds": [
            row["expected_output_artifact_kind"] for row in plan_steps
        ],
        "ready_check_fields": [
            row["ready_field"] for row in plan_steps
        ],
        "required_ready_field_sets": [
            row["required_ready_fields"] for row in plan_steps
        ],
        "required_ready_fields": sorted(
            {
                field
                for row in plan_steps
                for field in row["required_ready_fields"]
            }
        ),
        "plan_step_count": len(plan_steps),
        "required_plan_step_count": sum(1 for row in plan_steps if row["required"]),
        "plan_steps": plan_steps,
        "completion_claimed": False,
        "notes": [
            "CI plan is derived from the current completion-evidence requirements",
            "the plan documents command order and preflight gates but does not certify evidence",
        ],
    }


def _completion_evidence_artifact_readiness(
    missing_artifact: str,
    *,
    final_blockers: Sequence[Mapping[str, object]],
) -> dict | None:
    readiness_checks_by_artifact = {
        "production_imgui_renderer_framebuffer_pack": [
            "passed",
            "render_frame_count",
            "framebuffer_touched",
            "estimated_nonzero_pixels",
            "real_graphics_backend_framebuffer_verified",
            "screenshot_verified",
            "graphics_backend_name",
            "framebuffer_width",
            "framebuffer_height",
            "screenshot_url",
        ],
        "signed_release_publication_manifest": [
            "signed_release_artifacts_published",
            "publication_claimed",
            "platform_index_publication_claimed",
            "published_artifact_count",
            "signature_count",
            "package_index_url",
            "artifact_urls",
            "signature_urls",
        ],
        "full_homfly_pt_evaluation_certification_pack": [
            "arbitrary_signed_pd_coverage_certified",
            "external_table_normalization_certified",
            "skein_relation_certified",
            "registered_fixture_regression_certified",
            "certification_report_url",
            "embedded_certification_report_available",
            "embedded_certification_report_replay_certified",
            "published_certification_report_witness_verified",
            "external_table_source_urls",
            "counterexample_count_zero",
        ],
        "full_multivariable_alexander_normalization_certification_pack": [
            "signed_pd_wirtinger_fox_certified",
            "admissible_minor_normalization_certified",
            "all_admissible_minors_consistent",
            "external_table_normalization_certified",
            "certification_report_url",
            "external_table_source_urls",
            "counterexample_count_zero",
        ],
    }
    check_names = readiness_checks_by_artifact.get(missing_artifact)
    if check_names is None:
        return None
    checks = {name: False for name in check_names}
    retained_evidence_rows = [
        evidence
        for blocker in final_blockers
        for evidence in (
            blocker.get("retained_evidence")
            if isinstance(blocker.get("retained_evidence"), list)
            else []
        )
        if isinstance(evidence, Mapping)
    ]
    retained_evidence_ids = sorted(
        {
            str(evidence.get("evidence_id"))
            for evidence in retained_evidence_rows
            if evidence.get("evidence_id")
        }
    )
    retained_evidence_claim_scopes = sorted(
        {
            str(evidence.get("claim_scope"))
            for evidence in retained_evidence_rows
            if evidence.get("claim_scope")
        }
    )
    retained_evidence_source_methods = sorted(
        {
            str(evidence.get("source_method"))
            for evidence in retained_evidence_rows
            if evidence.get("source_method")
        }
    )
    retained_evidence_kinds = sorted(
        {
            str(evidence.get("evidence_kind"))
            for evidence in retained_evidence_rows
            if evidence.get("evidence_kind")
        }
    )
    blocker_labels = [
        label
        for blocker in final_blockers
        for label in (
            blocker.get("blocker_labels")
            if isinstance(blocker.get("blocker_labels"), list)
            else [blocker.get("label") or blocker.get("gate") or blocker.get("requirement")]
        )
        if isinstance(label, str)
    ]
    return {
        "claim_scope": "completion_evidence_artifact_producer_readiness",
        "missing_artifact": missing_artifact,
        "ready": False,
        "check_count": len(checks),
        "passed_check_count": 0,
        "failed_check_count": len(checks),
        "checks": checks,
        "blockers": list(checks),
        "blocker_count": len(checks),
        "blocker_labels": blocker_labels,
        "retained_evidence_available": bool(retained_evidence_rows),
        "retained_evidence_count": len(retained_evidence_rows),
        "retained_evidence_distinct_count": len(retained_evidence_ids),
        "retained_evidence_ids": retained_evidence_ids,
        "retained_evidence_claim_scopes": retained_evidence_claim_scopes,
        "retained_evidence_source_methods": retained_evidence_source_methods,
        "retained_evidence_kinds": retained_evidence_kinds,
        "retained_evidence_repository_test_count": sum(
            1
            for evidence in retained_evidence_rows
            if evidence.get("evidence_kind") == "repository_test"
        ),
        "retained_evidence_ci_retained_artifact_count": sum(
            1
            for evidence in retained_evidence_rows
            if evidence.get("evidence_kind") == "ci_retained_artifact"
        ),
        "retained_evidence_registered_fixture_scope_count": sum(
            1
            for evidence in retained_evidence_rows
            if "registered_fixture" in str(evidence.get("claim_scope") or "")
        ),
        "retained_evidence_bounded_scope_count": sum(
            1
            for evidence in retained_evidence_rows
            if "bounded_" in str(evidence.get("claim_scope") or "")
        ),
        "retained_evidence_completion_claimed_count": sum(
            1
            for evidence in retained_evidence_rows
            if evidence.get("completion_claimed") is True
        ),
        "retained_evidence_signed_release_artifacts_published_count": sum(
            1
            for evidence in retained_evidence_rows
            if evidence.get("signed_release_artifacts_published") is True
        ),
        "retained_evidence_publication_claimed_count": sum(
            1
            for evidence in retained_evidence_rows
            if evidence.get("publication_claimed") is True
        ),
        "retained_evidence_platform_index_publication_claimed_count": sum(
            1
            for evidence in retained_evidence_rows
            if evidence.get("platform_index_publication_claimed") is True
        ),
        "retained_evidence_real_graphics_backend_framebuffer_verified_count": sum(
            1
            for evidence in retained_evidence_rows
            if evidence.get("real_graphics_backend_framebuffer_verified") is True
        ),
        "retained_evidence_screenshot_verified_count": sum(
            1
            for evidence in retained_evidence_rows
            if evidence.get("screenshot_verified") is True
        ),
        "required_evidence": sorted(
            {
                str(blocker.get("required_evidence"))
                for blocker in final_blockers
                if blocker.get("required_evidence")
            }
        ),
        "current_evidence": sorted(
            {
                str(blocker.get("current_evidence"))
                for blocker in final_blockers
                if blocker.get("current_evidence")
            }
        ),
        "notes": [
            "artifact-level readiness lists the certification fields a producer must satisfy",
            "retained evidence is summarized for triage and does not certify the missing artifact",
            "all checks remain false until an external evidence artifact is supplied and audited",
        ],
    }


def _completion_evidence_contracts_command(
    args: argparse.Namespace,
    *,
    requirements: Mapping[str, object] | None = None,
) -> dict:
    if requirements is None:
        requirements = _completion_evidence_requirements_command(args)
    contracts = []
    for row in requirements["required_artifacts"]:
        missing_artifact = row["missing_artifact"]
        field_names = _completion_evidence_contract_required_fields(missing_artifact)
        field_rules = _completion_evidence_contract_field_rules(missing_artifact)
        preflight_checks = _completion_evidence_contract_preflight_checks(
            missing_artifact
        )
        field_rule_preflight_links = (
            _completion_evidence_contract_field_rule_preflight_links(
                missing_artifact
            )
        )
        unlinked_field_rules = sorted(
            field for field in field_rules if field not in field_rule_preflight_links
        )
        invalid_preflight_links = sorted(
            {
                check
                for checks in field_rule_preflight_links.values()
                for check in checks
                if check not in preflight_checks
            }
        )
        linked_preflight_checks = sorted(
            {
                check
                for checks in field_rule_preflight_links.values()
                for check in checks
            }
        )
        structural_preflight_checks = sorted(
            check
            for check in preflight_checks
            if check in {"artifact_schema_version", "artifact_kind", "claim_scope"}
        )
        accounted_preflight_checks = sorted(
            set(linked_preflight_checks) | set(structural_preflight_checks)
        )
        unexpected_unlinked_preflight_checks = sorted(
            set(preflight_checks) - set(accounted_preflight_checks)
        )
        contract_preflight_consistency_passed = (
            len(field_names) == len(set(field_names))
            and len(field_names) > 0
            and len(field_rules) > 0
            and len(preflight_checks) > 0
            and not unlinked_field_rules
            and not invalid_preflight_links
            and not unexpected_unlinked_preflight_checks
        )
        contracts.append(
            {
                "missing_artifact": missing_artifact,
                "bundle_key": row["bundle_key"],
                "repeatable": row["repeatable"],
                "repeatable_instance_coverage_required": row[
                    "repeatable_instance_coverage_required"
                ],
                "required_instance_count": row["required_instance_count"],
                "required_instance_labels": row["required_instance_labels"],
                "expected_artifact_kind": row["expected_artifact_kind"],
                "expected_claim_scope": row["expected_claim_scope"],
                "template_filename": row["template_filename"],
                "producer_cli_argument": row["producer_cli_argument"],
                "audit_cli_argument": row["audit_cli_argument"],
                "preflight_command": row["preflight_command"],
                "bundle_input_example": row["bundle_input_example"],
                "final_completion_blocker_codes": row[
                    "final_completion_blocker_codes"
                ],
                "final_completion_blocker_count": row[
                    "final_completion_blocker_count"
                ],
                "final_completion_blocker_labels": row[
                    "final_completion_blocker_labels"
                ],
                "final_completion_failed_gates": row[
                    "final_completion_failed_gates"
                ],
                "final_completion_failed_gate_count": row[
                    "final_completion_failed_gate_count"
                ],
                "final_completion_failed_gate_signature": row[
                    "final_completion_failed_gate_signature"
                ],
                "required_field_count": len(field_names),
                "required_fields": field_names,
                "field_rule_count": len(field_rules),
                "field_rules": field_rules,
                "preflight_check_count": len(preflight_checks),
                "preflight_checks": preflight_checks,
                "field_rule_preflight_links": field_rule_preflight_links,
                "linked_field_rule_count": len(field_rule_preflight_links),
                "linked_preflight_check_count": len(linked_preflight_checks),
                "linked_preflight_checks": linked_preflight_checks,
                "structural_preflight_check_count": len(
                    structural_preflight_checks
                ),
                "structural_preflight_checks": structural_preflight_checks,
                "accounted_preflight_check_count": len(
                    accounted_preflight_checks
                ),
                "accounted_preflight_checks": accounted_preflight_checks,
                "unlinked_field_rules": unlinked_field_rules,
                "invalid_preflight_links": invalid_preflight_links,
                "unexpected_unlinked_preflight_checks": (
                    unexpected_unlinked_preflight_checks
                ),
                "all_preflight_checks_accounted_for": (
                    not unexpected_unlinked_preflight_checks
                ),
                "contract_preflight_consistency_passed": (
                    contract_preflight_consistency_passed
                ),
                "producer_readiness_blockers": row["producer_readiness_blockers"],
                "producer_readiness": row["producer_readiness"],
            }
        )
    contract_preflight_consistency_passed_count = sum(
        1
        for row in contracts
        if row["contract_preflight_consistency_passed"] is True
    )
    contract_instance_rows = [
        {
            "missing_artifact": row["missing_artifact"],
            "instance_label": instance_row["instance_label"],
            "artifact_filename": instance_row["artifact_filename"],
            "template_filename": instance_row["template_filename"],
            "template_to_artifact_filename": instance_row[
                "template_to_artifact_filename"
            ],
            "expected_artifact_kind": row["expected_artifact_kind"],
            "expected_claim_scope": row["expected_claim_scope"],
            "required_field_count": row["required_field_count"],
            "required_fields": row["required_fields"],
            "preflight_check_count": row["preflight_check_count"],
            "preflight_checks": row["preflight_checks"],
            "preflight_command": instance_row["preflight_command"],
            "bundle_input_example": instance_row["bundle_input_example"],
            "final_completion_blocker_codes": instance_row[
                "final_completion_blocker_codes"
            ],
            "final_completion_blocker_count": instance_row[
                "final_completion_blocker_count"
            ],
            "final_completion_blocker_labels": instance_row[
                "final_completion_blocker_labels"
            ],
            "final_completion_failed_gates": instance_row[
                "final_completion_failed_gates"
            ],
            "final_completion_failed_gate_count": instance_row[
                "final_completion_failed_gate_count"
            ],
            "final_completion_failed_gate_signature": instance_row[
                "final_completion_failed_gate_signature"
            ],
            "producer_readiness_blockers": instance_row[
                "producer_readiness_blockers"
            ],
            "producer_readiness_count": instance_row["producer_readiness_count"],
            "producer_readiness_ready_count": instance_row[
                "producer_readiness_ready_count"
            ],
        }
        for row in contracts
        for instance_row in requirements["artifact_instance_command_rows"]
        if instance_row["missing_artifact"] == row["missing_artifact"]
    ]
    contract_instance_filenames = [
        row["artifact_filename"] for row in contract_instance_rows
    ]
    expected_evidence_filenames = requirements["expected_evidence_filenames"]
    contract_instance_filenames_match_expected_evidence_filenames = (
        contract_instance_filenames == expected_evidence_filenames
    )
    contract_instance_filename_signature = "|".join(contract_instance_filenames)
    for contract in contracts:
        filenames = [
            row["artifact_filename"]
            for row in contract_instance_rows
            if row["missing_artifact"] == contract["missing_artifact"]
        ]
        expected_filename_count = (
            contract["required_instance_count"]
            if contract["repeatable_instance_coverage_required"]
            else 1
        )
        contract["contract_instance_filenames"] = filenames
        contract["contract_instance_filename_count"] = len(filenames)
        contract["contract_instance_filename_signature"] = "|".join(filenames)
        contract["contract_expected_evidence_filename_count"] = (
            expected_filename_count
        )
        contract[
            "contract_instance_count_matches_expected_evidence_filename_count"
        ] = (len(filenames) == expected_filename_count)
        contract[
            "contract_instance_count_matches_contract_expected_evidence_filename_count"
        ] = (len(filenames) == expected_filename_count)
        contract["contract_instance_count_matches_required_instance_count"] = (
            len(filenames) == expected_filename_count
        )
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "cross_workstream_completion_evidence_contracts",
        "claim_scope": "cross_workstream_final_completion_evidence_contracts",
        "source_method": "iroll completion-evidence-contracts",
        "final_completion_ready": requirements["final_completion_ready"],
        "final_completion_blocker_count": requirements[
            "final_completion_blocker_count"
        ],
        "contract_count": len(contracts),
        "required_artifact_count": len(contracts),
        "required_missing_artifacts": [
            row["missing_artifact"] for row in contracts
        ],
        "required_missing_artifact_signature": "|".join(
            row["missing_artifact"] for row in contracts
        ),
        "expected_evidence_filename_count": requirements[
            "expected_evidence_filename_count"
        ],
        "expected_evidence_filenames": requirements["expected_evidence_filenames"],
        "expected_evidence_filename_signature": requirements[
            "expected_evidence_filename_signature"
        ],
        "bundle_all_inputs_command": requirements["bundle_all_inputs_command"],
        "directory_audit_command": requirements["directory_audit_command"],
        "final_validation_command": requirements["final_validation_command"],
        "contracts": contracts,
        "contract_instance_row_count": len(contract_instance_rows),
        "contract_instance_rows": contract_instance_rows,
        "contract_instance_filename_count": len(contract_instance_filenames),
        "contract_instance_filenames": contract_instance_filenames,
        "contract_instance_filename_signature": contract_instance_filename_signature,
        "contract_instance_filenames_match_expected_evidence_filenames": (
            contract_instance_filenames_match_expected_evidence_filenames
        ),
        "contract_preflight_consistency_passed_count": (
            contract_preflight_consistency_passed_count
        ),
        "all_contract_preflight_consistency_passed": (
            contract_preflight_consistency_passed_count == len(contracts)
        ),
        "all_contract_consistency_passed": (
            contract_preflight_consistency_passed_count == len(contracts)
            and contract_instance_filenames_match_expected_evidence_filenames
            and all(
                row[
                    "contract_instance_count_matches_expected_evidence_filename_count"
                ]
                for row in contracts
            )
        ),
        "producer_readiness_available": requirements[
            "producer_readiness_available"
        ],
        "producer_readiness_count": requirements["producer_readiness_count"],
        "producer_readiness_ready_count": requirements[
            "producer_readiness_ready_count"
        ],
        "producer_readiness_all_ready": requirements[
            "producer_readiness_all_ready"
        ],
        "producer_readiness_blocker_count": requirements[
            "producer_readiness_blocker_count"
        ],
        "producer_readiness_blockers": requirements["producer_readiness_blockers"],
        "producer_readiness_blocker_occurrence_count": requirements[
            "producer_readiness_blocker_occurrence_count"
        ],
        "producer_readiness_blocker_code_counts": requirements[
            "producer_readiness_blocker_code_counts"
        ],
        "producer_readiness_blocker_count_signature": requirements[
            "producer_readiness_blocker_count_signature"
        ],
        "producer_readiness_blocker_signature": requirements[
            "producer_readiness_blocker_signature"
        ],
        **_completion_evidence_final_audit_summary_from_requirements(requirements),
        **_completion_evidence_retained_summary_from_requirements(requirements),
        "repeatable_instance_coverage_required": any(
            row["repeatable_instance_coverage_required"] for row in contracts
        ),
        "required_instance_count": len(
            sorted(
                {
                    label
                    for row in contracts
                    for label in row["required_instance_labels"]
                }
            )
        ),
        "required_instance_labels": sorted(
            {
                label
                for row in contracts
                for label in row["required_instance_labels"]
            }
        ),
        "bundle_artifact_kind": requirements["bundle_artifact_kind"],
        "bundle_claim_scope": requirements["bundle_claim_scope"],
        "bundle_producer_command": requirements["bundle_producer_command"],
        "bundle_audit_command": requirements["bundle_audit_command"],
        "completion_claimed": False,
        "notes": [
            "contracts are derived from completion-evidence requirements",
            "contracts document required producer fields but do not certify evidence",
        ],
    }


def _completion_evidence_contract_required_fields(missing_artifact: str) -> list[str]:
    fields_by_artifact = {
        "verified_signed_crossing_assignment": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "notation",
            "source_url",
            "crossing_count",
            "signs",
            "role_orders",
            "source_gauss_code_match",
            "source_candidate_replay_valid",
            "candidate_replay_sha256",
            "unique_assignment_certified",
            "invariant_table_values_verified",
            "invariant_table_source_urls",
            "invariant_table_source_sha256s",
            "orientation_validation_issue_count",
        ],
        "production_imgui_renderer_framebuffer_pack": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "passed",
            "render_frame_count",
            "framebuffer_touched",
            "estimated_nonzero_pixels",
            "real_graphics_backend_framebuffer_verified",
            "screenshot_verified",
            "graphics_backend_name",
            "framebuffer_width",
            "framebuffer_height",
            "screenshot_url",
            "screenshot_sha256",
        ],
        "signed_release_publication_manifest": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "signed_release_artifacts_published",
            "publication_claimed",
            "platform_index_publication_claimed",
            "published_artifact_count",
            "signature_count",
            "package_index_url",
            "artifact_urls",
            "artifact_sha256s",
            "signature_urls",
            "signature_sha256s",
        ],
        "full_homfly_pt_evaluation_certification_pack": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "full_homfly_pt_evaluation_certified",
            "arbitrary_signed_pd_coverage_certified",
            "external_table_normalization_certified",
            "skein_relation_certified",
            "registered_fixture_regression_certified",
            "certification_report_url",
            "certification_report_sha256",
            "certification_report_raw_sha256",
            "certification_report_canonical_sha256",
            "certification_report",
            "published_report_witness",
            "published_report_canonical_sha256",
            "published_report_json_matches_embedded",
            "certification_report_replay_audit",
            "certification_report_implementation_source_sha256",
            "certification_report_implementation_bundle_sha256",
            "external_table_source_urls",
            "external_table_source_sha256s",
            "counterexample_count",
        ],
        "full_multivariable_alexander_normalization_certification_pack": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "full_multivariable_alexander_normalization_certified",
            "signed_pd_wirtinger_fox_certified",
            "admissible_minor_normalization_certified",
            "all_admissible_minors_consistent",
            "external_table_normalization_certified",
            "certification_report_url",
            "certification_report_sha256",
            "external_table_source_urls",
            "external_table_source_sha256s",
            "counterexample_count",
        ],
    }
    return fields_by_artifact.get(missing_artifact, [])


def _completion_evidence_contract_field_rules(missing_artifact: str) -> dict[str, str]:
    true_fields = {
        "verified_signed_crossing_assignment": [
            "source_gauss_code_match",
            "source_candidate_replay_valid",
            "unique_assignment_certified",
            "invariant_table_values_verified",
        ],
        "production_imgui_renderer_framebuffer_pack": [
            "passed",
            "real_graphics_backend_framebuffer_verified",
            "screenshot_verified",
        ],
        "signed_release_publication_manifest": [
            "signed_release_artifacts_published",
            "publication_claimed",
            "platform_index_publication_claimed",
        ],
        "full_homfly_pt_evaluation_certification_pack": [
            "full_homfly_pt_evaluation_certified",
            "arbitrary_signed_pd_coverage_certified",
            "external_table_normalization_certified",
            "skein_relation_certified",
            "registered_fixture_regression_certified",
            "published_report_json_matches_embedded",
        ],
        "full_multivariable_alexander_normalization_certification_pack": [
            "full_multivariable_alexander_normalization_certified",
            "signed_pd_wirtinger_fox_certified",
            "admissible_minor_normalization_certified",
            "all_admissible_minors_consistent",
            "external_table_normalization_certified",
        ],
    }
    positive_int_fields = {
        "verified_signed_crossing_assignment": ["crossing_count"],
        "production_imgui_renderer_framebuffer_pack": [
            "render_frame_count",
            "framebuffer_touched",
            "estimated_nonzero_pixels",
            "framebuffer_width",
            "framebuffer_height",
        ],
        "signed_release_publication_manifest": [
            "published_artifact_count",
            "signature_count",
        ],
    }
    zero_int_fields = {
        "verified_signed_crossing_assignment": ["orientation_validation_issue_count"],
        "full_homfly_pt_evaluation_certification_pack": ["counterexample_count"],
        "full_multivariable_alexander_normalization_certification_pack": [
            "counterexample_count"
        ],
    }
    http_url_fields = {
        "verified_signed_crossing_assignment": ["source_url"],
        "production_imgui_renderer_framebuffer_pack": ["screenshot_url"],
        "signed_release_publication_manifest": ["package_index_url"],
        "full_homfly_pt_evaluation_certification_pack": [
            "certification_report_url"
        ],
        "full_multivariable_alexander_normalization_certification_pack": [
            "certification_report_url"
        ],
    }
    http_url_list_fields = {
        "verified_signed_crossing_assignment": ["invariant_table_source_urls"],
        "signed_release_publication_manifest": ["artifact_urls", "signature_urls"],
        "full_homfly_pt_evaluation_certification_pack": [
            "external_table_source_urls"
        ],
        "full_multivariable_alexander_normalization_certification_pack": [
            "external_table_source_urls"
        ],
    }
    sha256_fields = {
        "verified_signed_crossing_assignment": ["candidate_replay_sha256"],
        "production_imgui_renderer_framebuffer_pack": ["screenshot_sha256"],
        "full_homfly_pt_evaluation_certification_pack": [
            "certification_report_sha256",
            "certification_report_raw_sha256",
            "certification_report_canonical_sha256",
            "published_report_canonical_sha256",
            "certification_report_implementation_source_sha256",
            "certification_report_implementation_bundle_sha256",
        ],
        "full_multivariable_alexander_normalization_certification_pack": [
            "certification_report_sha256"
        ],
    }
    sha256_list_fields = {
        "verified_signed_crossing_assignment": [
            "invariant_table_source_sha256s"
        ],
        "signed_release_publication_manifest": [
            "artifact_sha256s",
            "signature_sha256s",
        ],
        "full_homfly_pt_evaluation_certification_pack": [
            "external_table_source_sha256s"
        ],
        "full_multivariable_alexander_normalization_certification_pack": [
            "external_table_source_sha256s"
        ],
    }
    rules: dict[str, str] = {}
    for field in true_fields.get(missing_artifact, []):
        rules[field] = "must_be_true"
    for field in positive_int_fields.get(missing_artifact, []):
        rules[field] = "positive_integer"
    for field in zero_int_fields.get(missing_artifact, []):
        rules[field] = "must_equal_zero"
    for field in http_url_fields.get(missing_artifact, []):
        rules[field] = "non_placeholder_http_or_https_url"
    for field in http_url_list_fields.get(missing_artifact, []):
        rules[field] = "nonempty_non_placeholder_http_or_https_url_list"
    for field in sha256_fields.get(missing_artifact, []):
        rules[field] = "sha256_hex_64"
    for field in sha256_list_fields.get(missing_artifact, []):
        rules[field] = "nonempty_sha256_hex_64_list"
    if missing_artifact == "verified_signed_crossing_assignment":
        rules["signs"] = "list_length_matches_crossing_count"
        rules["role_orders"] = "list_length_matches_crossing_count"
        rules["notation"] = "one_of_L5a1_L6a4"
        rules["invariant_table_source_urls"] = (
            "unique_nonempty_non_placeholder_http_or_https_url_list"
        )
        rules["invariant_table_source_sha256s"] = (
            "unique_nonempty_sha256_hex_64_list_length_matches_invariant_table_source_urls"
        )
    if missing_artifact == "signed_release_publication_manifest":
        rules["artifact_urls"] = (
            "unique_nonempty_non_placeholder_http_or_https_url_list_length_matches_published_artifact_count"
        )
        rules["signature_urls"] = (
            "unique_nonempty_non_placeholder_http_or_https_url_list_length_matches_signature_count"
        )
        rules["artifact_sha256s"] = (
            "unique_nonempty_sha256_hex_64_list_length_matches_published_artifact_count_and_artifact_urls"
        )
        rules["signature_sha256s"] = (
            "unique_nonempty_sha256_hex_64_list_length_matches_signature_count_and_signature_urls"
        )
    if missing_artifact in {
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
    }:
        rules["external_table_source_urls"] = (
            "unique_nonempty_non_placeholder_http_or_https_url_list"
        )
        rules["external_table_source_sha256s"] = (
            "unique_nonempty_sha256_hex_64_list_length_matches_external_table_source_urls"
        )
    if missing_artifact == "full_homfly_pt_evaluation_certification_pack":
        rules["certification_report"] = (
            "embedded_report_object_with_exact_recomputed_case_and_trace_replay"
        )
        rules["published_report_witness"] = (
            "url_expected_actual_sha256_fetch_and_verification_witness"
        )
        rules["certification_report_replay_audit"] = (
            "must_match_recomputed_embedded_report_audit"
        )
    if missing_artifact == "production_imgui_renderer_framebuffer_pack":
        rules["graphics_backend_name"] = "nonempty_string"
    return rules


def _completion_evidence_contract_preflight_checks(
    missing_artifact: str,
) -> list[str]:
    checks_by_artifact = {
        "verified_signed_crossing_assignment": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "notation",
            "source_url",
            "source_url_http",
            "source_url_matches_notation",
            "source_url_not_invariant_table_source_urls",
            "crossing_count_positive",
            "crossing_count_matches_notation",
            "signs_match_crossing_count",
            "signs_are_plus_or_minus_one",
            "role_orders_match_crossing_count",
            "role_orders_are_four_role_permutations",
            "source_gauss_code_match",
            "source_candidate_replay_valid",
            "candidate_replay_sha256_available",
            "candidate_replay_sha256_not_invariant_table_source_sha256s",
            "unique_assignment_certified",
            "invariant_table_values_verified",
            "invariant_table_source_urls_available",
            "invariant_table_source_urls_items_nonempty_strings",
            "invariant_table_source_urls_http",
            "invariant_table_source_urls_unique",
            "invariant_table_source_sha256s_available",
            "invariant_table_source_sha256s_items_nonempty_strings",
            "invariant_table_source_sha256_count_matches_source_url_count",
            "invariant_table_source_sha256s_hex",
            "invariant_table_source_sha256s_unique",
            "invariant_table_source_witness_pairs_unique",
            "orientation_validation_issue_count_zero",
            "template_placeholder_not_true",
        ],
        "production_imgui_renderer_framebuffer_pack": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "passed",
            "render_frame_count_positive",
            "framebuffer_touched",
            "framebuffer_touched_unit_flag",
            "estimated_nonzero_pixels",
            "estimated_nonzero_pixels_covers_framebuffer_touched",
            "estimated_nonzero_pixels_within_framebuffer_area",
            "real_graphics_backend_framebuffer_verified",
            "screenshot_verified",
            "graphics_backend_name_available",
            "graphics_backend_name_not_test_or_stub",
            "framebuffer_width_positive",
            "framebuffer_height_positive",
            "screenshot_url_http",
            "screenshot_sha256_available",
            "template_placeholder_not_true",
        ],
        "signed_release_publication_manifest": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "signed_release_artifacts_published",
            "publication_claimed",
            "platform_index_publication_claimed",
            "published_artifact_count",
            "signature_count",
            "signature_count_matches_published_artifact_count",
            "package_index_url_available",
            "package_index_url_http",
            "package_index_url_not_artifact_or_signature_url",
            "artifact_urls_available",
            "artifact_urls_items_nonempty_strings",
            "artifact_url_count_matches_published_artifact_count",
            "artifact_urls_http",
            "artifact_urls_unique",
            "artifact_url_filenames_unique",
            "artifact_sha256s_available",
            "artifact_sha256s_items_nonempty_strings",
            "artifact_sha256_count_matches_published_artifact_count",
            "artifact_sha256_count_matches_artifact_url_count",
            "artifact_sha256s_hex",
            "artifact_sha256s_unique",
            "artifact_url_sha256_pairs_unique",
            "signature_urls_available",
            "signature_urls_items_nonempty_strings",
            "signature_url_count_matches_signature_count",
            "signature_urls_http",
            "signature_urls_unique",
            "signature_url_filenames_unique",
            "signature_url_filenames_have_signature_extension",
            "artifact_urls_disjoint_from_signature_urls",
            "signature_urls_match_artifact_url_filenames",
            "signature_sha256s_available",
            "signature_sha256s_items_nonempty_strings",
            "signature_sha256_count_matches_signature_count",
            "signature_sha256_count_matches_signature_url_count",
            "signature_sha256s_hex",
            "signature_sha256s_unique",
            "signature_url_sha256_pairs_unique",
            "artifact_sha256s_disjoint_from_signature_sha256s",
            "template_placeholder_not_true",
        ],
        "full_homfly_pt_evaluation_certification_pack": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "full_homfly_pt_evaluation_certified",
            "arbitrary_signed_pd_coverage_certified",
            "external_table_normalization_certified",
            "skein_relation_certified",
            "registered_fixture_regression_certified",
            "counterexample_count_zero",
            "embedded_certification_report_available",
            "embedded_certification_report_replay_certified",
            "embedded_certification_report_canonical_sha256_matches",
            "embedded_certification_report_raw_sha256_matches",
            "published_certification_report_witness_verified",
            "pinned_external_table_sources_exact",
            "embedded_report_implementation_source_sha256_matches_pack",
            "embedded_report_implementation_bundle_sha256_matches_pack",
            "embedded_report_summary_counts_match_pack",
            "embedded_report_claims_match_pack",
            "producer_replay_audit_matches_embedded_report",
            "producer_checks_all_true",
            "certification_report_url_http",
            "certification_report_url_not_external_table_source_urls",
            "certification_report_sha256_available",
            "certification_report_sha256_not_external_table_source_sha256s",
            "external_table_source_urls_available",
            "external_table_source_urls_items_nonempty_strings",
            "external_table_source_urls_http",
            "external_table_source_urls_unique",
            "external_table_source_url_filenames_unique",
            "external_table_source_sha256s_available",
            "external_table_source_sha256s_items_nonempty_strings",
            "external_table_source_sha256_count_matches_source_url_count",
            "external_table_source_sha256s_hex",
            "external_table_source_sha256s_unique",
            "external_table_source_witness_pairs_unique",
            "template_placeholder_not_true",
        ],
        "full_multivariable_alexander_normalization_certification_pack": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "full_multivariable_alexander_normalization_certified",
            "signed_pd_wirtinger_fox_certified",
            "admissible_minor_normalization_certified",
            "all_admissible_minors_consistent",
            "external_table_normalization_certified",
            "counterexample_count_zero",
            "certification_report_url_http",
            "certification_report_url_not_external_table_source_urls",
            "certification_report_sha256_available",
            "certification_report_sha256_not_external_table_source_sha256s",
            "external_table_source_urls_available",
            "external_table_source_urls_items_nonempty_strings",
            "external_table_source_urls_http",
            "external_table_source_urls_unique",
            "external_table_source_url_filenames_unique",
            "external_table_source_sha256s_available",
            "external_table_source_sha256s_items_nonempty_strings",
            "external_table_source_sha256_count_matches_source_url_count",
            "external_table_source_sha256s_hex",
            "external_table_source_sha256s_unique",
            "external_table_source_witness_pairs_unique",
            "template_placeholder_not_true",
        ],
    }
    return checks_by_artifact.get(missing_artifact, [])


def _completion_evidence_contract_field_rule_preflight_links(
    missing_artifact: str,
) -> dict[str, list[str]]:
    links_by_artifact = {
        "verified_signed_crossing_assignment": {
            "source_gauss_code_match": ["source_gauss_code_match"],
            "source_candidate_replay_valid": ["source_candidate_replay_valid"],
            "unique_assignment_certified": ["unique_assignment_certified"],
            "invariant_table_values_verified": [
                "invariant_table_values_verified"
            ],
            "crossing_count": [
                "crossing_count_positive",
                "crossing_count_matches_notation",
            ],
            "orientation_validation_issue_count": [
                "orientation_validation_issue_count_zero"
            ],
            "source_url": [
                "source_url",
                "source_url_http",
                "source_url_matches_notation",
                "source_url_not_invariant_table_source_urls",
            ],
            "invariant_table_source_urls": [
                "invariant_table_source_urls_available",
                "invariant_table_source_urls_items_nonempty_strings",
                "invariant_table_source_urls_http",
                "invariant_table_source_urls_unique",
                "invariant_table_source_witness_pairs_unique",
            ],
            "invariant_table_source_sha256s": [
                "invariant_table_source_sha256s_available",
                "invariant_table_source_sha256s_items_nonempty_strings",
                "invariant_table_source_sha256_count_matches_source_url_count",
                "invariant_table_source_sha256s_hex",
                "invariant_table_source_sha256s_unique",
                "invariant_table_source_witness_pairs_unique",
            ],
            "candidate_replay_sha256": [
                "candidate_replay_sha256_available",
                "candidate_replay_sha256_not_invariant_table_source_sha256s",
            ],
            "signs": [
                "signs_match_crossing_count",
                "signs_are_plus_or_minus_one",
            ],
            "role_orders": [
                "role_orders_match_crossing_count",
                "role_orders_are_four_role_permutations",
            ],
            "notation": ["notation", "crossing_count_matches_notation"],
            "template_placeholder": ["template_placeholder_not_true"],
        },
        "production_imgui_renderer_framebuffer_pack": {
            "passed": ["passed"],
            "real_graphics_backend_framebuffer_verified": [
                "real_graphics_backend_framebuffer_verified"
            ],
            "screenshot_verified": ["screenshot_verified"],
            "render_frame_count": ["render_frame_count_positive"],
            "framebuffer_touched": [
                "framebuffer_touched",
                "framebuffer_touched_unit_flag",
                "estimated_nonzero_pixels_covers_framebuffer_touched",
            ],
            "estimated_nonzero_pixels": [
                "estimated_nonzero_pixels",
                "estimated_nonzero_pixels_covers_framebuffer_touched",
                "estimated_nonzero_pixels_within_framebuffer_area",
            ],
            "framebuffer_width": [
                "framebuffer_width_positive",
                "estimated_nonzero_pixels_within_framebuffer_area",
            ],
            "framebuffer_height": [
                "framebuffer_height_positive",
                "estimated_nonzero_pixels_within_framebuffer_area",
            ],
            "screenshot_url": ["screenshot_url_http"],
            "screenshot_sha256": ["screenshot_sha256_available"],
            "graphics_backend_name": [
                "graphics_backend_name_available",
                "graphics_backend_name_not_test_or_stub",
            ],
            "template_placeholder": ["template_placeholder_not_true"],
        },
        "signed_release_publication_manifest": {
            "signed_release_artifacts_published": [
                "signed_release_artifacts_published"
            ],
            "publication_claimed": ["publication_claimed"],
            "platform_index_publication_claimed": [
                "platform_index_publication_claimed"
            ],
            "published_artifact_count": ["published_artifact_count"],
            "signature_count": [
                "signature_count",
                "signature_count_matches_published_artifact_count",
            ],
            "package_index_url": [
                "package_index_url_available",
                "package_index_url_http",
                "package_index_url_not_artifact_or_signature_url",
            ],
            "artifact_urls": [
                "artifact_urls_available",
                "artifact_urls_items_nonempty_strings",
                "artifact_url_count_matches_published_artifact_count",
                "artifact_urls_http",
                "artifact_urls_unique",
                "artifact_url_filenames_unique",
                "artifact_url_sha256_pairs_unique",
                "artifact_urls_disjoint_from_signature_urls",
                "signature_urls_match_artifact_url_filenames",
            ],
            "artifact_sha256s": [
                "artifact_sha256s_available",
                "artifact_sha256s_items_nonempty_strings",
                "artifact_sha256_count_matches_published_artifact_count",
                "artifact_sha256_count_matches_artifact_url_count",
                "artifact_sha256s_hex",
                "artifact_sha256s_unique",
                "artifact_url_sha256_pairs_unique",
                "artifact_sha256s_disjoint_from_signature_sha256s",
            ],
            "signature_urls": [
                "signature_urls_available",
                "signature_urls_items_nonempty_strings",
                "signature_url_count_matches_signature_count",
                "signature_urls_http",
                "signature_urls_unique",
                "signature_url_filenames_unique",
                "signature_url_filenames_have_signature_extension",
                "signature_url_sha256_pairs_unique",
                "artifact_urls_disjoint_from_signature_urls",
                "signature_urls_match_artifact_url_filenames",
            ],
            "signature_sha256s": [
                "signature_sha256s_available",
                "signature_sha256s_items_nonempty_strings",
                "signature_sha256_count_matches_signature_count",
                "signature_sha256_count_matches_signature_url_count",
                "signature_sha256s_hex",
                "signature_sha256s_unique",
                "signature_url_sha256_pairs_unique",
                "artifact_sha256s_disjoint_from_signature_sha256s",
            ],
            "template_placeholder": ["template_placeholder_not_true"],
        },
        "full_homfly_pt_evaluation_certification_pack": {
            "full_homfly_pt_evaluation_certified": [
                "full_homfly_pt_evaluation_certified"
            ],
            "arbitrary_signed_pd_coverage_certified": [
                "arbitrary_signed_pd_coverage_certified"
            ],
            "external_table_normalization_certified": [
                "external_table_normalization_certified"
            ],
            "skein_relation_certified": ["skein_relation_certified"],
            "registered_fixture_regression_certified": [
                "registered_fixture_regression_certified"
            ],
            "counterexample_count": ["counterexample_count_zero"],
            "certification_report_url": [
                "certification_report_url_http",
                "published_certification_report_witness_verified",
            ],
            "certification_report_sha256": [
                "certification_report_sha256_available",
                "certification_report_sha256_not_external_table_source_sha256s",
                "published_certification_report_witness_verified",
                "embedded_certification_report_raw_sha256_matches",
            ],
            "certification_report_raw_sha256": [
                "embedded_certification_report_raw_sha256_matches",
                "published_certification_report_witness_verified",
            ],
            "certification_report_canonical_sha256": [
                "embedded_certification_report_canonical_sha256_matches"
            ],
            "certification_report": [
                "embedded_certification_report_available",
                "embedded_certification_report_replay_certified",
                "embedded_report_summary_counts_match_pack",
                "embedded_report_claims_match_pack",
            ],
            "published_report_witness": [
                "published_certification_report_witness_verified"
            ],
            "published_report_canonical_sha256": [
                "published_certification_report_witness_verified",
                "embedded_certification_report_canonical_sha256_matches",
            ],
            "published_report_json_matches_embedded": [
                "published_certification_report_witness_verified"
            ],
            "certification_report_replay_audit": [
                "producer_replay_audit_matches_embedded_report",
                "producer_checks_all_true",
            ],
            "certification_report_implementation_source_sha256": [
                "embedded_report_implementation_source_sha256_matches_pack"
            ],
            "certification_report_implementation_bundle_sha256": [
                "embedded_report_implementation_bundle_sha256_matches_pack"
            ],
            "external_table_source_urls": [
                "external_table_source_urls_available",
                "external_table_source_urls_items_nonempty_strings",
                "external_table_source_urls_http",
                "external_table_source_urls_unique",
                "external_table_source_url_filenames_unique",
                "external_table_source_witness_pairs_unique",
                "certification_report_url_not_external_table_source_urls",
                "pinned_external_table_sources_exact",
            ],
            "external_table_source_sha256s": [
                "external_table_source_sha256s_available",
                "external_table_source_sha256s_items_nonempty_strings",
                "external_table_source_sha256_count_matches_source_url_count",
                "external_table_source_sha256s_hex",
                "external_table_source_sha256s_unique",
                "external_table_source_witness_pairs_unique",
                "certification_report_sha256_not_external_table_source_sha256s",
                "pinned_external_table_sources_exact",
            ],
            "template_placeholder": ["template_placeholder_not_true"],
        },
        "full_multivariable_alexander_normalization_certification_pack": {
            "full_multivariable_alexander_normalization_certified": [
                "full_multivariable_alexander_normalization_certified"
            ],
            "signed_pd_wirtinger_fox_certified": [
                "signed_pd_wirtinger_fox_certified"
            ],
            "admissible_minor_normalization_certified": [
                "admissible_minor_normalization_certified"
            ],
            "all_admissible_minors_consistent": [
                "all_admissible_minors_consistent"
            ],
            "external_table_normalization_certified": [
                "external_table_normalization_certified"
            ],
            "counterexample_count": ["counterexample_count_zero"],
            "certification_report_url": ["certification_report_url_http"],
            "certification_report_sha256": [
                "certification_report_sha256_available",
                "certification_report_sha256_not_external_table_source_sha256s",
            ],
            "external_table_source_urls": [
                "external_table_source_urls_available",
                "external_table_source_urls_items_nonempty_strings",
                "external_table_source_urls_http",
                "external_table_source_urls_unique",
                "external_table_source_url_filenames_unique",
                "external_table_source_witness_pairs_unique",
                "certification_report_url_not_external_table_source_urls",
            ],
            "external_table_source_sha256s": [
                "external_table_source_sha256s_available",
                "external_table_source_sha256s_items_nonempty_strings",
                "external_table_source_sha256_count_matches_source_url_count",
                "external_table_source_sha256s_hex",
                "external_table_source_sha256s_unique",
                "external_table_source_witness_pairs_unique",
                "certification_report_sha256_not_external_table_source_sha256s",
            ],
            "template_placeholder": ["template_placeholder_not_true"],
        },
    }
    return links_by_artifact.get(missing_artifact, {})


def _completion_evidence_producer_workspace_command(
    args: argparse.Namespace,
) -> dict:
    directory = args.directory
    directory.mkdir(parents=True, exist_ok=True)
    if args.output is None:
        args.output = directory / "completion-evidence-producer-workspace.json"
    else:
        args.output.parent.mkdir(parents=True, exist_ok=True)

    template_directory = directory / "templates"
    audit_directory = directory / "audits"
    audit_directory.mkdir(parents=True, exist_ok=True)
    templates = _completion_evidence_templates_command(
        argparse.Namespace(directory=template_directory, expand_repeatable=True)
    )
    requirements = _completion_evidence_requirements_command(args)
    contracts = _completion_evidence_contracts_command(args)
    contracts_by_missing_artifact = {
        contract["missing_artifact"]: contract
        for contract in contracts["contracts"]
    }

    producer_rows = []
    for instance_row in requirements["artifact_instance_command_rows"]:
        missing_artifact = instance_row["missing_artifact"]
        contract = contracts_by_missing_artifact[missing_artifact]
        artifact_filename = instance_row["artifact_filename"]
        template_filename = instance_row["template_filename"]
        artifact_path = directory / artifact_filename
        template_path = template_directory / template_filename
        audit_output_path = audit_directory / f"{artifact_filename}.audit.json"
        producer_rows.append(
            {
                "missing_artifact": missing_artifact,
                "instance_label": instance_row["instance_label"],
                "artifact_type": missing_artifact,
                "expected_artifact_kind": contract["expected_artifact_kind"],
                "expected_claim_scope": contract["expected_claim_scope"],
                "artifact_filename": artifact_filename,
                "artifact_path": str(artifact_path),
                "artifact_file_exists": artifact_path.exists(),
                "template_filename": template_filename,
                "template_path": str(template_path),
                "template_written": template_path.exists(),
                "template_to_artifact_note": instance_row[
                    "template_to_artifact_note"
                ],
                "required_field_count": contract["required_field_count"],
                "required_fields": contract["required_fields"],
                "field_rule_count": contract["field_rule_count"],
                "field_rules": contract["field_rules"],
                "preflight_command": (
                    "iroll completion-evidence-artifact-audit "
                    f"{artifact_path} --artifact-type {missing_artifact} "
                    f"--fail-on-not-certified -o {audit_output_path}"
                ),
                "audit_output_path": str(audit_output_path),
                "bundle_input_command": (
                    "iroll completion-evidence-bundle "
                    f"{instance_row['producer_cli_argument']} {artifact_path}"
                ),
                "producer_cli_argument": instance_row["producer_cli_argument"],
                "audit_cli_argument": instance_row["audit_cli_argument"],
                "repeatable_instance_coverage_required": instance_row[
                    "repeatable_instance_coverage_required"
                ],
                "required_instance_labels": instance_row[
                    "required_instance_labels"
                ],
                "final_completion_failed_gates": instance_row[
                    "final_completion_failed_gates"
                ],
                "final_completion_failed_gate_count": instance_row[
                    "final_completion_failed_gate_count"
                ],
                "final_completion_failed_gate_signature": instance_row[
                    "final_completion_failed_gate_signature"
                ],
                "final_completion_blocker_codes": instance_row[
                    "final_completion_blocker_codes"
                ],
                "final_completion_blocker_count": instance_row[
                    "final_completion_blocker_count"
                ],
                "final_completion_blocker_labels": instance_row[
                    "final_completion_blocker_labels"
                ],
                "producer_readiness_count": instance_row[
                    "producer_readiness_count"
                ],
                "producer_readiness_ready_count": instance_row[
                    "producer_readiness_ready_count"
                ],
                "producer_readiness_blockers": instance_row[
                    "producer_readiness_blockers"
                ],
            }
        )

    bundle_output_path = directory / "completion-evidence-bundle.json"
    validation_output_path = directory / "validation-pack-audit.json"
    target_artifact_filenames = [
        row["artifact_filename"] for row in producer_rows
    ]
    missing_target_artifact_filenames = [
        row["artifact_filename"]
        for row in producer_rows
        if row["artifact_file_exists"] is not True
    ]
    return {
        "artifact_schema_version": 1,
        "artifact_kind": (
            "cross_workstream_completion_evidence_producer_workspace"
        ),
        "claim_scope": "cross_workstream_final_completion_evidence_production",
        "source_method": "iroll completion-evidence-producer-workspace",
        "workspace_directory": str(directory),
        "workspace_index_path": str(args.output),
        "template_directory": str(template_directory),
        "template_file_count": templates["template_file_count"],
        "template_filenames": templates["template_filenames"],
        "audit_directory": str(audit_directory),
        "target_artifact_file_count": len(target_artifact_filenames),
        "target_artifact_filenames": target_artifact_filenames,
        "target_artifact_filename_signature": "|".join(
            target_artifact_filenames
        ),
        "present_target_artifact_file_count": (
            len(target_artifact_filenames) - len(missing_target_artifact_filenames)
        ),
        "missing_target_artifact_file_count": len(
            missing_target_artifact_filenames
        ),
        "missing_target_artifact_filenames": missing_target_artifact_filenames,
        "all_target_artifact_files_present": (
            not missing_target_artifact_filenames
        ),
        "target_artifact_files_written": False,
        "producer_row_count": len(producer_rows),
        "producer_rows": producer_rows,
        "artifact_preflight_commands": [
            row["preflight_command"] for row in producer_rows
        ],
        "bundle_command": (
            "iroll completion-evidence-bundle "
            f"--evidence-directory {directory} -o {bundle_output_path}"
        ),
        "directory_audit_command": (
            "iroll completion-evidence-directory-audit "
            f"{directory} --validate-artifacts --bundle-output "
            f"{bundle_output_path} --validation-output {validation_output_path} "
            "--fail-on-not-ready"
        ),
        "final_validation_command": (
            "iroll fixture-validation-pack-audit "
            f"--completion-evidence-bundle-json {bundle_output_path} "
            "--fail-on-not-ready"
        ),
        "expected_evidence_filename_count": requirements[
            "expected_evidence_filename_count"
        ],
        "expected_evidence_filenames": requirements[
            "expected_evidence_filenames"
        ],
        "expected_evidence_filename_signature": requirements[
            "expected_evidence_filename_signature"
        ],
        **_completion_evidence_final_audit_summary_from_requirements(
            requirements
        ),
        "completion_claimed": False,
        "notes": [
            "workspace templates are non-certified placeholders",
            "target artifact JSON files are intentionally not written",
            "copy a template to the target artifact path only after replacing placeholder values with certified external evidence",
        ],
    }


def _completion_evidence_templates_command(args: argparse.Namespace) -> dict:
    requirements = _completion_evidence_requirements_command(args)
    template_rows = []
    for row in requirements["required_artifacts"]:
        expand_labels = (
            row["blocker_labels"]
            if args.expand_repeatable and row["repeatable"]
            else [None]
        )
        for label in expand_labels:
            template = _completion_evidence_template_for_artifact(row, label=label)
            template_filename = _completion_evidence_template_filename(
                row["missing_artifact"],
                label=label,
            )
            artifact_filename = template_filename.replace(".template.json", ".json")
            final_blocker_labels = (
                [label]
                if label is not None
                else row["final_completion_blocker_labels"]
            )
            final_blocker_count = (
                len(final_blocker_labels)
                if label is not None
                else row["final_completion_blocker_count"]
            )
            template_rows.append(
                {
                    "missing_artifact": row["missing_artifact"],
                    "bundle_key": row["bundle_key"],
                    "producer_cli_argument": row["producer_cli_argument"],
                    "audit_cli_argument": row["audit_cli_argument"],
                    "preflight_command": row["preflight_command"],
                    "bundle_input_example": row["bundle_input_example"],
                    "producer_readiness_available": row[
                        "producer_readiness_available"
                    ],
                    "producer_readiness_count": len(
                        template.get("producer_readiness", [])
                    ),
                    "producer_readiness_ready_count": sum(
                        1
                        for readiness in template.get("producer_readiness", [])
                        if readiness.get("ready") is True
                    ),
                    "producer_readiness_blockers": template[
                        "producer_readiness_blockers"
                    ],
                    "producer_readiness": template["producer_readiness"],
                    "repeatable": row["repeatable"],
                    "repeatable_instance_coverage_required": row[
                        "repeatable_instance_coverage_required"
                    ],
                    "required_instance_count": row["required_instance_count"],
                    "required_instance_labels": row["required_instance_labels"],
                    "expanded_repeatable": label is not None,
                    "blocker_label": label,
                    "blocker_labels": row["blocker_labels"],
                    "final_completion_blocker_codes": row[
                        "final_completion_blocker_codes"
                    ],
                    "final_completion_blocker_count": final_blocker_count,
                    "final_completion_blocker_labels": final_blocker_labels,
                    "final_completion_failed_gates": row[
                        "final_completion_failed_gates"
                    ],
                    "final_completion_failed_gate_count": row[
                        "final_completion_failed_gate_count"
                    ],
                    "final_completion_failed_gate_signature": row[
                        "final_completion_failed_gate_signature"
                    ],
                    "template_filename": template_filename,
                    "artifact_filename": artifact_filename,
                    "template_to_artifact_filename": artifact_filename,
                    "template_to_artifact_note": (
                        f"copy {template_filename} to {artifact_filename} "
                        "and replace placeholder values with certified evidence"
                    ),
                    "template_path": None,
                    "template_written": False,
                    "template": template,
                }
            )
    if args.directory is not None:
        args.directory.mkdir(parents=True, exist_ok=True)
        for row in template_rows:
            template_path = args.directory / row["template_filename"]
            write_report(row["template"], template_path)
            row["template_path"] = str(template_path)
            row["template_written"] = True
    producer_readiness_count = sum(
        row["producer_readiness_count"] for row in template_rows
    )
    producer_readiness_ready_count = sum(
        row["producer_readiness_ready_count"] for row in template_rows
    )
    producer_readiness_blockers = sorted(
        {
            blocker
            for row in template_rows
            for blocker in row["producer_readiness_blockers"]
        }
    )
    producer_readiness_blocker_code_counts = {
        blocker: sum(
            1
            for row in template_rows
            for row_blocker in row["producer_readiness_blockers"]
            if row_blocker == blocker
        )
        for blocker in producer_readiness_blockers
    }
    producer_readiness_blocker_occurrence_count = sum(
        producer_readiness_blocker_code_counts.values()
    )
    required_instance_labels = sorted(
        {
            label
            for row in template_rows
            for label in row["required_instance_labels"]
        }
    )
    required_missing_artifacts = sorted(
        {row["missing_artifact"] for row in template_rows}
    )
    template_to_artifact_filenames = [
        row["template_to_artifact_filename"] for row in template_rows
    ]
    template_to_artifact_filenames_match_expected_evidence_filenames = (
        template_to_artifact_filenames == requirements["expected_evidence_filenames"]
    )
    template_expansion_required_for_expected_evidence_filenames = (
        not template_to_artifact_filenames_match_expected_evidence_filenames
        and any(row["repeatable_instance_coverage_required"] for row in template_rows)
    )
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "cross_workstream_completion_evidence_templates",
        "claim_scope": "cross_workstream_final_completion_evidence_templates",
        "source_method": "iroll completion-evidence-templates",
        "template_count": len(template_rows),
        "required_artifact_count": len(required_missing_artifacts),
        "required_missing_artifacts": required_missing_artifacts,
        "required_missing_artifact_signature": "|".join(required_missing_artifacts),
        "expected_evidence_filename_count": requirements[
            "expected_evidence_filename_count"
        ],
        "expected_evidence_filenames": requirements["expected_evidence_filenames"],
        "expected_evidence_filename_signature": requirements[
            "expected_evidence_filename_signature"
        ],
        "bundle_all_inputs_command": requirements["bundle_all_inputs_command"],
        "directory_audit_command": requirements["directory_audit_command"],
        "final_validation_command": requirements["final_validation_command"],
        "template_directory": str(args.directory) if args.directory is not None else None,
        "template_file_count": sum(1 for row in template_rows if row["template_written"]),
        "template_filenames": [
            row["template_filename"] for row in template_rows
        ],
        "template_to_artifact_filename_count": len(template_to_artifact_filenames),
        "template_to_artifact_filenames": template_to_artifact_filenames,
        "template_to_artifact_filenames_match_expected_evidence_filenames": (
            template_to_artifact_filenames_match_expected_evidence_filenames
        ),
        "template_expansion_required_for_expected_evidence_filenames": (
            template_expansion_required_for_expected_evidence_filenames
        ),
        "template_to_artifact_notes": [
            row["template_to_artifact_note"] for row in template_rows
        ],
        "template_to_artifact_rows": [
            {
                "missing_artifact": row["missing_artifact"],
                "blocker_label": row["blocker_label"],
                "final_completion_blocker_codes": row[
                    "final_completion_blocker_codes"
                ],
                "final_completion_blocker_count": row[
                    "final_completion_blocker_count"
                ],
                "final_completion_blocker_labels": row[
                    "final_completion_blocker_labels"
                ],
                "final_completion_failed_gates": row[
                    "final_completion_failed_gates"
                ],
                "final_completion_failed_gate_count": row[
                    "final_completion_failed_gate_count"
                ],
                "final_completion_failed_gate_signature": row[
                    "final_completion_failed_gate_signature"
                ],
                "template_filename": row["template_filename"],
                "artifact_filename": row["artifact_filename"],
                "template_to_artifact_filename": row[
                    "template_to_artifact_filename"
                ],
                "template_to_artifact_note": row["template_to_artifact_note"],
            }
            for row in template_rows
        ],
        "repeatable_expanded": args.expand_repeatable,
        "expanded_repeatable_template_count": sum(
            1 for row in template_rows if row["expanded_repeatable"]
        ),
        "producer_readiness_available": producer_readiness_count > 0,
        "producer_readiness_count": producer_readiness_count,
        "producer_readiness_ready_count": producer_readiness_ready_count,
        "producer_readiness_all_ready": (
            producer_readiness_count > 0
            and producer_readiness_ready_count == producer_readiness_count
        ),
        "producer_readiness_blocker_count": len(producer_readiness_blockers),
        "producer_readiness_blockers": producer_readiness_blockers,
        "producer_readiness_blocker_occurrence_count": (
            producer_readiness_blocker_occurrence_count
        ),
        "producer_readiness_blocker_code_counts": (
            producer_readiness_blocker_code_counts
        ),
        "producer_readiness_blocker_count_signature": ",".join(
            f"{blocker}:{producer_readiness_blocker_code_counts[blocker]}"
            for blocker in producer_readiness_blockers
        ),
        "producer_readiness_blocker_signature": "|".join(
            producer_readiness_blockers
        ),
        **_completion_evidence_final_audit_summary_from_requirements(requirements),
        **_completion_evidence_retained_summary_from_requirements(requirements),
        "repeatable_instance_coverage_required": any(
            row["repeatable_instance_coverage_required"] for row in template_rows
        ),
        "required_instance_count": len(required_instance_labels),
        "required_instance_labels": required_instance_labels,
        "templates": template_rows,
        "bundle_artifact_kind": requirements["bundle_artifact_kind"],
        "bundle_claim_scope": requirements["bundle_claim_scope"],
        "bundle_producer_command": requirements["bundle_producer_command"],
        "bundle_audit_command": requirements["bundle_audit_command"],
        "completion_claimed": False,
        "notes": [
            "templates are intentionally non-certified placeholders",
            "replace placeholder values with externally verified evidence before bundling",
        ],
    }


def _completion_evidence_template_filename(
    missing_artifact: str,
    *,
    label: str | None,
) -> str:
    if label:
        return f"{missing_artifact}.{label}.template.json"
    return f"{missing_artifact}.template.json"


def _completion_evidence_template_for_artifact(
    row: dict,
    *,
    label: str | None = None,
) -> dict:
    missing_artifact = row["missing_artifact"]
    readiness = row.get("producer_readiness", [])
    if label:
        readiness = [
            readiness_row
            for readiness_row in readiness
            if readiness_row.get("notation") == label
        ]
    final_blocker_labels = (
        [label]
        if label is not None
        else row.get("final_completion_blocker_labels", [])
    )
    final_blocker_count = (
        len(final_blocker_labels)
        if label is not None
        else row.get("final_completion_blocker_count", 0)
    )
    readiness_fields = {
        "producer_readiness": readiness,
        "producer_readiness_blockers": row.get("producer_readiness_blockers", []),
        "repeatable_instance_coverage_required": row.get(
            "repeatable_instance_coverage_required", False
        ),
        "required_instance_count": row.get("required_instance_count", 0),
        "required_instance_labels": row.get("required_instance_labels", []),
        "template_instance_label": label,
        "final_completion_blocker_codes": row.get(
            "final_completion_blocker_codes", []
        ),
        "final_completion_blocker_count": final_blocker_count,
        "final_completion_blocker_labels": final_blocker_labels,
        "final_completion_failed_gates": row.get(
            "final_completion_failed_gates", []
        ),
        "final_completion_failed_gate_count": row.get(
            "final_completion_failed_gate_count", 0
        ),
        "final_completion_failed_gate_signature": row.get(
            "final_completion_failed_gate_signature", ""
        ),
    }
    if missing_artifact == "verified_signed_crossing_assignment":
        return {
            "artifact_schema_version": 1,
            "artifact_kind": "verified_signed_crossing_assignment",
            "claim_scope": "verified_signed_crossing_assignment",
            "notation": label or "<L5a1-or-L6a4>",
            "source_url": "<source-url>",
            "crossing_count": 0,
            "signs": [],
            "role_orders": [],
            "source_gauss_code_match": False,
            "source_candidate_replay_valid": False,
            "candidate_replay_sha256": "",
            "unique_assignment_certified": False,
            "invariant_table_values_verified": False,
            "invariant_table_source_urls": [],
            "invariant_table_source_sha256s": [],
            "orientation_validation_issue_count": 1,
            **readiness_fields,
            "completion_claimed": False,
            "template_placeholder": True,
        }
    if missing_artifact == "production_imgui_renderer_framebuffer_pack":
        return {
            "artifact_schema_version": 1,
            "artifact_kind": "imgui_production_renderer_framebuffer_pack",
            "claim_scope": "production_imgui_renderer_framebuffer_verification",
            "passed": False,
            "render_frame_count": 0,
            "framebuffer_touched": 0,
            "estimated_nonzero_pixels": 0,
            "graphics_backend_name": "",
            "framebuffer_width": 0,
            "framebuffer_height": 0,
            "screenshot_url": "",
            "screenshot_sha256": "",
            "real_graphics_backend_framebuffer_verified": False,
            "screenshot_verified": False,
            **readiness_fields,
            "completion_claimed": False,
            "template_placeholder": True,
        }
    if missing_artifact == "signed_release_publication_manifest":
        return {
            "artifact_schema_version": 1,
            "artifact_kind": "signed_release_publication_manifest",
            "claim_scope": "signed_release_publication",
            "signed_release_artifacts_published": False,
            "publication_claimed": False,
            "platform_index_publication_claimed": False,
            "published_artifact_count": 0,
            "signature_count": 0,
            "package_index_url": "",
            "artifact_urls": [],
            "artifact_sha256s": [],
            "signature_urls": [],
            "signature_sha256s": [],
            **readiness_fields,
            "completion_claimed": False,
            "template_placeholder": True,
        }
    if missing_artifact == "full_homfly_pt_evaluation_certification_pack":
        return {
            "artifact_schema_version": 1,
            "artifact_kind": "full_homfly_pt_evaluation_certification_pack",
            "claim_scope": "full_homfly_pt_evaluation",
            "full_homfly_pt_evaluation_certified": False,
            "arbitrary_signed_pd_coverage_certified": False,
            "external_table_normalization_certified": False,
            "skein_relation_certified": False,
            "registered_fixture_regression_certified": False,
            "certification_report_url": "",
            "certification_report_sha256": "",
            "certification_report_raw_sha256": "",
            "certification_report_canonical_sha256": "",
            "certification_report": {},
            "published_report_witness": {},
            "published_report_canonical_sha256": "",
            "published_report_json_matches_embedded": False,
            "certification_report_replay_audit": {},
            "certification_report_implementation_source_sha256": "",
            "certification_report_implementation_bundle_sha256": "",
            "external_table_source_urls": [],
            "external_table_source_sha256s": [],
            "counterexample_count": 1,
            **readiness_fields,
            "completion_claimed": False,
            "template_placeholder": True,
        }
    if (
        missing_artifact
        == "full_multivariable_alexander_normalization_certification_pack"
    ):
        return {
            "artifact_schema_version": 1,
            "artifact_kind": (
                "full_multivariable_alexander_normalization_certification_pack"
            ),
            "claim_scope": "full_multivariable_alexander_normalization",
            "full_multivariable_alexander_normalization_certified": False,
            "signed_pd_wirtinger_fox_certified": False,
            "admissible_minor_normalization_certified": False,
            "all_admissible_minors_consistent": False,
            "external_table_normalization_certified": False,
            "certification_report_url": "",
            "certification_report_sha256": "",
            "external_table_source_urls": [],
            "external_table_source_sha256s": [],
            "counterexample_count": 1,
            **readiness_fields,
            "completion_claimed": False,
            "template_placeholder": True,
        }
    return {
        "artifact_schema_version": 1,
        "artifact_kind": row.get("expected_artifact_kind"),
        "claim_scope": row.get("expected_claim_scope"),
        **readiness_fields,
        "completion_claimed": False,
        "template_placeholder": True,
    }


def _completion_evidence_artifact_metadata_by_id() -> dict[str, dict]:
    return {
        "verified_signed_crossing_assignment": {
            "bundle_key": "verified_signed_crossing_assignments",
            "producer_cli_argument": "--verified-signed-crossing-assignment-json",
            "audit_cli_argument": "--verified-signed-crossing-assignment-json",
            "repeatable": True,
            "artifact_type": "verified_signed_crossing_assignment",
            "expected_artifact_kind": "verified_signed_crossing_assignment",
            "expected_claim_scope": "verified_signed_crossing_assignment",
        },
        "production_imgui_renderer_framebuffer_pack": {
            "bundle_key": "production_imgui_renderer_framebuffer_pack",
            "producer_cli_argument": (
                "--production-imgui-renderer-framebuffer-pack-json"
            ),
            "audit_cli_argument": (
                "--production-imgui-renderer-framebuffer-pack-json"
            ),
            "artifact_type": "production_imgui_renderer_framebuffer_pack",
            "expected_artifact_kind": "imgui_production_renderer_framebuffer_pack",
            "expected_claim_scope": (
                "production_imgui_renderer_framebuffer_verification"
            ),
        },
        "signed_release_publication_manifest": {
            "bundle_key": "signed_release_publication_manifest",
            "producer_cli_argument": "--signed-release-publication-manifest-json",
            "audit_cli_argument": "--signed-release-publication-manifest-json",
            "artifact_type": "signed_release_publication_manifest",
            "expected_artifact_kind": "signed_release_publication_manifest",
            "expected_claim_scope": "signed_release_publication",
        },
        "full_homfly_pt_evaluation_certification_pack": {
            "bundle_key": "full_homfly_pt_evaluation_certification_pack",
            "producer_cli_argument": (
                "--full-homfly-pt-evaluation-certification-pack-json"
            ),
            "audit_cli_argument": (
                "--full-homfly-pt-evaluation-certification-pack-json"
            ),
            "artifact_type": "full_homfly_pt_evaluation_certification_pack",
            "expected_artifact_kind": (
                "full_homfly_pt_evaluation_certification_pack"
            ),
            "expected_claim_scope": "full_homfly_pt_evaluation",
        },
        "full_multivariable_alexander_normalization_certification_pack": {
            "bundle_key": (
                "full_multivariable_alexander_normalization_certification_pack"
            ),
            "producer_cli_argument": (
                "--full-multivariable-alexander-normalization-certification-pack-json"
            ),
            "audit_cli_argument": (
                "--full-multivariable-alexander-normalization-certification-pack-json"
            ),
            "artifact_type": (
                "full_multivariable_alexander_normalization_certification_pack"
            ),
            "expected_artifact_kind": (
                "full_multivariable_alexander_normalization_certification_pack"
            ),
            "expected_claim_scope": "full_multivariable_alexander_normalization",
        },
    }


def _homfly_fixture_acceptance_command(args: argparse.Namespace) -> dict:
    return homfly_fixture_acceptance_report(
        notations=_notations_from_args(args),
        include_unregistered=args.include_unregistered,
    )


def _multivariable_alexander_fixture_acceptance_command(
    args: argparse.Namespace,
) -> dict:
    return multivariable_alexander_fixture_acceptance_report(
        notations=_notations_from_args(args),
        include_unregistered=args.include_unregistered,
    )


def _multivariable_alexander_signed_pd_coverage_command(
    args: argparse.Namespace,
) -> dict:
    return multivariable_alexander_signed_pd_coverage_report(
        notations=_notations_from_args(args),
        max_matrix_size=args.max_matrix_size,
        max_minors=args.max_minors,
        branch_depth=args.branch_depth,
    )


def _fixture_source_invariant_candidates_command(args: argparse.Namespace) -> dict:
    fixture = get_diagram_fixture(args.notation)
    return fixture.source_invariant_candidate_diagnostics(
        max_orientation_samples=args.max_orientation_samples,
        max_sign_patterns=args.max_sign_patterns,
        max_candidates=args.max_candidates,
        target_pairwise_linking=args.target_pairwise_linking,
        compute_homfly=not args.no_homfly,
        compute_alexander=not args.no_alexander,
        homfly_max_depth=args.homfly_max_depth,
        homfly_max_nodes=args.homfly_max_nodes,
        alexander_max_matrix_size=args.alexander_max_matrix_size,
        alexander_max_minors=args.alexander_max_minors,
    )


def _fixture_source_table_invariant_audit_command(args: argparse.Namespace) -> dict:
    fixture = get_diagram_fixture(args.notation)
    return fixture.source_table_invariant_audit(
        max_orientation_samples=args.max_orientation_samples,
        max_sign_patterns=args.max_sign_patterns,
        max_candidates=args.max_candidates,
        target_pairwise_linking=args.target_pairwise_linking,
        compute_homfly=args.include_homfly,
        compute_alexander=not args.no_alexander,
        homfly_max_depth=args.homfly_max_depth,
        homfly_max_nodes=args.homfly_max_nodes,
        alexander_max_matrix_size=args.alexander_max_matrix_size,
        alexander_max_minors=args.alexander_max_minors,
    )


def _multivariable_alexander_pd_command(args: argparse.Namespace) -> dict:
    payload = _load_signed_pd_json(args.path)
    signed_pd_input = _signed_pd_input_from_payload(
        payload,
        role_order_override=args.role_order,
        auto_role_order=getattr(args, "auto_role_order", False),
    )
    diagram = signed_pd_input["diagram"]
    orientation = signed_pd_input["orientation"]
    role_order = signed_pd_input["compute_role_order"]

    variables = tuple(args.variable) if args.variable else _variables_from_payload(payload)
    if _auto_role_order_blocks_computation(signed_pd_input):
        return _auto_role_order_skipped_report(
            signed_pd_input,
            method="multivariable_alexander_pd_report",
            extra_input={
                "variables": list(variables) if variables is not None else [],
                "target_size": args.target_size,
                "max_matrix_size": args.max_matrix_size,
                "max_minors": args.max_minors,
            },
        )

    result = multivariable_alexander_from_pd(
        diagram,
        orientation=orientation,
        role_order=role_order,
        variables=variables,
        target_size=args.target_size,
        max_matrix_size=args.max_matrix_size,
        max_minors=args.max_minors,
    )
    scanned_gcd_audit = multivariable_alexander_scanned_gcd_audit(result)
    wirtinger_fox_audit = multivariable_alexander_wirtinger_fox_audit(result)
    admissible_minor_normalization_audit = (
        multivariable_alexander_admissible_minor_normalization_audit(result)
    )
    evidence = multivariable_alexander_input_certification_evidence(
        scanned_gcd_audit,
        wirtinger_fox_audit,
        admissible_minor_normalization_audit,
    )
    return {
        "method": "multivariable_alexander_pd_report",
        "input": {
            **_signed_pd_input_report(signed_pd_input),
            "variables": list(variables) if variables is not None else [],
            "target_size": args.target_size,
            "max_matrix_size": args.max_matrix_size,
            "max_minors": args.max_minors,
        },
        "result": result,
        "presentation": result.get("presentation"),
        "orientation_inference": result.get("orientation_inference"),
        "input_certification_evidence": evidence,
        "scanned_gcd_audit": scanned_gcd_audit,
        "wirtinger_fox_audit": wirtinger_fox_audit,
        "admissible_minor_normalization_audit": (
            admissible_minor_normalization_audit
        ),
        "multivariable_alexander_polynomial": result.get(
            "multivariable_alexander_polynomial"
        ),
        "candidate_polynomials": list(result.get("candidate_polynomials", [])),
        "zero_crossing_unlink_certified": bool(
            result.get("zero_crossing_unlink_certified", False)
        ),
        "bounded_scanned_gcd_certified": bool(
            evidence.get("bounded_scanned_gcd_certified", False)
        ),
        "complete_scanned_gcd_certified": bool(
            evidence.get("complete_scanned_gcd_certified", False)
        ),
        "quotient_gcd_certified": bool(
            evidence.get("quotient_gcd_certified", False)
        ),
        "bounded_admissible_minor_normalization_certified": bool(
            evidence.get(
                "bounded_admissible_minor_normalization_certified",
                False,
            )
        ),
        "all_nonzero_minors_laurent_unit_equivalent": bool(
            evidence.get(
                "all_nonzero_minors_laurent_unit_equivalent",
                False,
            )
        ),
        "admissible_minor_normalized_representative_polynomial": (
            evidence.get("admissible_minor_normalized_representative_polynomial")
        ),
        "checked_nonzero_minor_count": int(
            evidence.get("checked_nonzero_minor_count", 0) or 0
        ),
        "failed_nonzero_minor_count": int(
            evidence.get("failed_nonzero_minor_count", 0) or 0
        ),
        "scanned_minor_count": int(evidence.get("scanned_minor_count", 0) or 0),
        "division_record_count": int(evidence.get("division_record_count", 0) or 0),
        "truncated": bool(evidence.get("truncated", False)),
        "wirtinger_fox_input_chain_consistent": bool(
            evidence.get("wirtinger_fox_input_chain_consistent", False)
        ),
        "full_admissible_minor_normalization_certified": bool(
            result.get("full_admissible_minor_normalization_certified", False)
        ),
        "full_invariant_certified": bool(result.get("full_invariant_certified", False)),
        "skipped": bool(result.get("skipped", False)),
        "notes": list(result.get("notes", [])),
    }


def _homfly_blocker_fields_from_evidence(evidence: dict | None) -> dict:
    if not isinstance(evidence, dict):
        evidence = {}
    certification_blockers = list(evidence.get("certification_blockers", []))
    certification_blocker_details = list(
        evidence.get("certification_blocker_details", [])
    )
    homfly_completion_blockers = list(
        evidence.get("homfly_completion_blockers", [])
    )
    homfly_completion_blocker_details = list(
        evidence.get("homfly_completion_blocker_details", [])
    )
    return {
        "certification_blockers": certification_blockers,
        "certification_blocker_count": int(
            evidence.get("certification_blocker_count", len(certification_blockers))
            or 0
        ),
        "certification_blocker_details": certification_blocker_details,
        "certification_blocker_detail_count": int(
            evidence.get(
                "certification_blocker_detail_count",
                len(certification_blocker_details),
            )
            or 0
        ),
        "homfly_completion_blockers": homfly_completion_blockers,
        "homfly_completion_blocker_count": int(
            evidence.get(
                "homfly_completion_blocker_count",
                len(homfly_completion_blockers),
            )
            or 0
        ),
        "homfly_completion_blocker_details": homfly_completion_blocker_details,
        "homfly_completion_blocker_detail_count": int(
            evidence.get(
                "homfly_completion_blocker_detail_count",
                len(homfly_completion_blocker_details),
            )
            or 0
        ),
    }


def _homfly_pd_command(args: argparse.Namespace) -> dict:
    payload = _load_signed_pd_json(args.path)
    signed_pd_input = _signed_pd_input_from_payload(
        payload,
        role_order_override=args.role_order,
        auto_role_order=getattr(args, "auto_role_order", False),
    )
    diagram = signed_pd_input["diagram"]
    orientation = signed_pd_input["orientation"]
    orientation_generated_for_homfly = False
    role_order = signed_pd_input["compute_role_order"]
    if _auto_role_order_blocks_computation(signed_pd_input):
        return _auto_role_order_skipped_report(
            signed_pd_input,
            method="homfly_pd_report",
            claim_scope="iterative_recursive_frontier_exhaustion_for_one_signed_pd_input",
            extra_input={
                "orientation_generated_for_homfly": False,
                "max_crossings": args.max_crossings,
                "initial_depth": args.initial_depth,
                "max_depth": args.max_depth,
                "max_nodes": args.max_nodes,
            },
        )
    if orientation is None and role_order is not None:
        orientation = PDOrientation.from_signed_pd_roles(diagram, role_order=role_order)
        orientation_generated_for_homfly = True

    result = homfly_iterative_certified_evaluation_from_pd(
        diagram,
        orientation=orientation,
        max_crossings=args.max_crossings,
        initial_depth=args.initial_depth,
        max_depth=args.max_depth,
        max_nodes=args.max_nodes,
    )
    evidence = homfly_input_certification_evidence(result)
    return {
        "method": "homfly_pd_report",
        "claim_scope": "iterative_recursive_frontier_exhaustion_for_one_signed_pd_input",
        "input": {
            **_signed_pd_input_report(signed_pd_input),
            "orientation_generated_for_homfly": orientation_generated_for_homfly,
            "max_crossings": args.max_crossings,
            "initial_depth": args.initial_depth,
            "max_depth": args.max_depth,
            "max_nodes": args.max_nodes,
        },
        "result": result,
        "input_certification_evidence": evidence,
        "homfly_polynomial": result.get("homfly_polynomial"),
        "certified_for_input": bool(result.get("certified_for_input", False)),
        "max_crossings": evidence.get("max_crossings"),
        "initial_depth": evidence.get("initial_depth"),
        "max_depth": evidence.get("max_depth"),
        "max_nodes": evidence.get("max_nodes"),
        "frontier_exhausted": bool(evidence.get("frontier_exhausted", False)),
        "zero_crossing_certified": bool(
            evidence.get("zero_crossing_certified", False)
        ),
        "recursion_nodes": int(evidence.get("recursion_nodes", 0) or 0),
        "cache_hits": int(evidence.get("cache_hits", 0) or 0),
        "terminal_reduction_count": int(
            evidence.get("terminal_reduction_count", 0) or 0
        ),
        "memoized_reduction_count": int(
            evidence.get("memoized_reduction_count", 0) or 0
        ),
        "reduction_contribution_count": int(
            evidence.get("reduction_contribution_count", 0) or 0
        ),
        "frontier_count": int(evidence.get("frontier_count", 0) or 0),
        "frontier_reason_count": int(
            evidence.get("frontier_reason_count", 0) or 0
        ),
        "frontier_reasons": list(evidence.get("frontier_reasons", [])),
        "truncated": bool(evidence.get("truncated", False)),
        "iterative_attempt_count": int(
            evidence.get("iterative_attempt_count", 0) or 0
        ),
        "iterative_solved_depth": evidence.get("iterative_solved_depth"),
        "terminal_contribution_matches_result": bool(
            evidence.get("terminal_contribution_matches_result", False)
        ),
        "terminal_contribution_audit_skipped": bool(
            evidence.get("terminal_contribution_audit_skipped", False)
        ),
        **_homfly_blocker_fields_from_evidence(evidence),
        "full_table_normalization_certified": bool(
            result.get("full_table_normalization_certified", False)
        ),
        "arbitrary_diagram_coverage_certified": bool(
            result.get("arbitrary_diagram_coverage_certified", False)
        ),
        "skipped": bool(result.get("skipped", False)),
        "notes": list(result.get("notes", [])),
    }


def _homfly_terminal_reduction_audit_command(args: argparse.Namespace) -> dict:
    report = _load_report_json(args.path)
    result = report.get("result") if isinstance(report.get("result"), dict) else report
    payload = homfly_terminal_reduction_audit(result)
    payload["source_path"] = str(args.path)
    payload["input_report_method"] = report.get("method")
    return payload


def _homfly_input_certification_evidence_command(args: argparse.Namespace) -> dict:
    report = _load_report_json(args.path)
    result = report.get("result") if isinstance(report.get("result"), dict) else report
    payload = homfly_input_certification_evidence(result)
    payload["source_path"] = str(args.path)
    payload["input_report_method"] = report.get("method")
    return payload


def _homfly_skein_identity_audit_command(args: argparse.Namespace) -> dict:
    payload = _load_signed_pd_json(args.path)
    signed_pd_input = _signed_pd_input_from_payload(
        payload,
        role_order_override=args.role_order,
        auto_role_order=getattr(args, "auto_role_order", False),
    )
    diagram = signed_pd_input["diagram"]
    orientation = signed_pd_input["orientation"]
    role_order = signed_pd_input["compute_role_order"]
    orientation_generated_for_homfly = False
    input_report = {
        **_signed_pd_input_report(signed_pd_input),
        "orientation_generated_for_homfly": False,
        "max_crossings": args.max_crossings,
        "max_depth": args.max_depth,
        "max_nodes": args.max_nodes,
    }
    if _auto_role_order_blocks_computation(signed_pd_input):
        return {
            "method": "homfly_skein_identity_audit",
            "claim_scope": "local_homfly_skein_identity_for_signed_pd_input",
            "normalization": "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1",
            "source_signed_pd": str(args.path),
            "input": input_report,
            "crossing_count": diagram.crossing_count,
            "checked_crossing_count": 0,
            "max_crossings": args.max_crossings,
            "max_depth": args.max_depth,
            "max_nodes": args.max_nodes,
            "matched": False,
            "skipped": True,
            "truncated": False,
            "crossing_audits": [],
            "full_table_normalization_certified": False,
            "arbitrary_diagram_coverage_certified": False,
            "notes": [
                "auto role-order inference did not select a unique strict global candidate; pass --role-order or per-crossing role_order metadata before auditing skein identities",
            ],
        }
    if orientation is None and role_order is not None:
        orientation = PDOrientation.from_signed_pd_roles(diagram, role_order=role_order)
        orientation_generated_for_homfly = True
        input_report["orientation_generated_for_homfly"] = True

    audit = homfly_skein_identity_audit_from_pd(
        diagram,
        orientation=orientation,
        max_crossings=args.max_crossings,
        max_depth=args.max_depth,
        max_nodes=args.max_nodes,
    )
    audit["claim_scope"] = "local_homfly_skein_identity_for_signed_pd_input"
    audit["source_signed_pd"] = str(args.path)
    input_report["orientation_generated_for_homfly"] = orientation_generated_for_homfly
    audit["input"] = input_report
    audit["full_table_normalization_certified"] = False
    audit["arbitrary_diagram_coverage_certified"] = False
    return audit


def _multivariable_alexander_improve_scanned_gcd_result_command(
    args: argparse.Namespace,
) -> dict:
    report = _load_report_json(args.path)
    result = report.get("result") if isinstance(report.get("result"), dict) else report
    payload = multivariable_alexander_improve_scanned_gcd_result(result)
    payload["source_path"] = str(args.path)
    payload["input_report_method"] = report.get("method")
    return payload


def _multivariable_alexander_scanned_gcd_audit_command(
    args: argparse.Namespace,
) -> dict:
    report = _load_report_json(args.path)
    result = report.get("result") if isinstance(report.get("result"), dict) else report
    payload = multivariable_alexander_scanned_gcd_audit(result)
    payload["source_path"] = str(args.path)
    payload["input_report_method"] = report.get("method")
    return payload


def _multivariable_alexander_minor_divisibility_audit_command(
    args: argparse.Namespace,
) -> dict:
    report = _load_report_json(args.path)
    result = report.get("result") if isinstance(report.get("result"), dict) else report
    payload = multivariable_alexander_minor_divisibility_audit(result)
    payload["source_path"] = str(args.path)
    payload["input_report_method"] = report.get("method")
    return payload


def _multivariable_alexander_admissible_minor_normalization_audit_command(
    args: argparse.Namespace,
) -> dict:
    report = _load_report_json(args.path)
    result = report.get("result") if isinstance(report.get("result"), dict) else report
    payload = multivariable_alexander_admissible_minor_normalization_audit(result)
    payload["source_path"] = str(args.path)
    payload["input_report_method"] = report.get("method")
    return payload


def _multivariable_alexander_wirtinger_fox_audit_command(
    args: argparse.Namespace,
) -> dict:
    report = _load_report_json(args.path)
    result = report.get("result") if isinstance(report.get("result"), dict) else report
    payload = multivariable_alexander_wirtinger_fox_audit(result)
    payload["source_path"] = str(args.path)
    payload["input_report_method"] = report.get("method")
    return payload


def _multivariable_alexander_input_certification_evidence_command(
    args: argparse.Namespace,
) -> dict:
    report = _load_report_json(args.path)
    result = report.get("result") if isinstance(report.get("result"), dict) else report
    scanned_gcd_audit = report.get("scanned_gcd_audit")
    if not isinstance(scanned_gcd_audit, dict):
        if report.get("method") == "multivariable_alexander_scanned_gcd_audit":
            scanned_gcd_audit = report
        else:
            scanned_gcd_audit = multivariable_alexander_scanned_gcd_audit(result)
    wirtinger_fox_audit = report.get("wirtinger_fox_audit")
    if not isinstance(wirtinger_fox_audit, dict):
        if report.get("method") == "multivariable_alexander_wirtinger_fox_audit":
            wirtinger_fox_audit = report
        elif isinstance(result, dict):
            wirtinger_fox_audit = multivariable_alexander_wirtinger_fox_audit(result)
        else:
            wirtinger_fox_audit = None
    admissible_minor_normalization_audit = report.get(
        "admissible_minor_normalization_audit"
    )
    if not isinstance(admissible_minor_normalization_audit, dict):
        if report.get("method") == (
            "multivariable_alexander_admissible_minor_normalization_audit"
        ):
            admissible_minor_normalization_audit = report
        elif isinstance(result, dict):
            admissible_minor_normalization_audit = (
                multivariable_alexander_admissible_minor_normalization_audit(
                    result
                )
            )
        else:
            admissible_minor_normalization_audit = None
    payload = multivariable_alexander_input_certification_evidence(
        scanned_gcd_audit,
        wirtinger_fox_audit,
        admissible_minor_normalization_audit,
    )
    payload["source_path"] = str(args.path)
    payload["input_report_method"] = report.get("method")
    return payload


def _signed_pd_role_order_candidates_command(args: argparse.Namespace) -> dict:
    return _signed_pd_role_order_candidates_report_from_payload(
        _load_signed_pd_json(args.path),
        include_component_mismatches=args.include_component_mismatches,
        include_invariant_signatures=args.include_invariant_signatures,
        signature_max_candidates=args.signature_max_candidates,
        signature_max_depth=args.signature_max_depth,
        signature_max_nodes=args.signature_max_nodes,
        signature_max_minors=args.signature_max_minors,
    )


def _signed_pd_role_order_candidates_report_from_payload(
    payload: dict,
    *,
    include_component_mismatches: bool = False,
    include_invariant_signatures: bool = False,
    signature_max_candidates: int = 8,
    signature_max_depth: int = 8,
    signature_max_nodes: int = 2048,
    signature_max_minors: int = 64,
) -> dict:
    signed_pd_input = _signed_pd_input_from_payload(
        payload,
        role_order_override=None,
    )
    variables = _variables_from_payload(payload)
    candidate_report = _signed_pd_role_order_candidate_report(
        signed_pd_input["diagram"],
        include_component_mismatches=include_component_mismatches,
        include_invariant_signatures=include_invariant_signatures,
        signature_variables=variables,
        signature_max_candidates=signature_max_candidates,
        signature_max_depth=signature_max_depth,
        signature_max_nodes=signature_max_nodes,
        signature_max_minors=signature_max_minors,
    )
    return {
        "method": "signed_pd_role_order_candidates_report",
        "input": {
            **_signed_pd_input_report(signed_pd_input),
            "variables": list(variables) if variables is not None else [],
        },
        **candidate_report,
    }
def _auto_role_order_blocks_computation(signed_pd_input: dict) -> bool:
    auto_role_order = signed_pd_input["auto_role_order"]
    return bool(
        auto_role_order["requested"]
        and not auto_role_order["applied"]
        and auto_role_order["status"] in {"ambiguous", "no_strict_candidate"}
    )


def _auto_role_order_skipped_report(
    signed_pd_input: dict,
    *,
    method: str,
    claim_scope: str | None = None,
    extra_input: dict | None = None,
) -> dict:
    notes = [
        "auto role-order inference did not select a unique strict global candidate; pass --role-order or per-crossing role_order metadata before computing invariants"
    ]
    report = {
        "method": method,
        "input": {
            **_signed_pd_input_report(signed_pd_input),
            **(extra_input or {}),
        },
        "result": None,
        "presentation": None,
        "orientation_inference": None,
        "homfly_polynomial": None,
        "multivariable_alexander_polynomial": None,
        "candidate_polynomials": [],
        "input_certification_evidence": None,
        "certified_for_input": False,
        "full_table_normalization_certified": False,
        "arbitrary_diagram_coverage_certified": False,
        "full_invariant_certified": False,
        "skipped": True,
        "notes": notes,
    }
    if claim_scope is not None:
        report["claim_scope"] = claim_scope
    if method == "homfly_pd_report":
        evidence = homfly_input_certification_evidence(
            {
                "method": "skipped_auto_role_order_ambiguity",
                "homfly_polynomial": None,
                "max_crossings": (extra_input or {}).get("max_crossings"),
                "initial_depth": (extra_input or {}).get("initial_depth"),
                "max_depth": (extra_input or {}).get("max_depth"),
                "max_nodes": (extra_input or {}).get("max_nodes"),
                "certified_for_input": False,
                "full_table_normalization_certified": False,
                "arbitrary_diagram_coverage_certified": False,
                "recursive_evaluation": None,
                "skipped": True,
                "notes": notes,
            }
        )
        report.update(
            {
                "input_certification_evidence": evidence,
                **_homfly_blocker_fields_from_evidence(evidence),
            }
        )
    return report


def _homfly_small_diagram_coverage_command(args: argparse.Namespace) -> dict:
    return homfly_small_diagram_coverage_report(
        notations=_notations_from_args(args),
        max_depth=args.max_depth,
        max_nodes=args.max_nodes,
        branch_depth=args.branch_depth,
    )


def _render_report_command(args: argparse.Namespace) -> dict:
    report = json.loads(args.path.read_text(encoding="utf-8-sig"))
    output_path = write_report_html(report, args.html_output, title=args.title)
    return {
        "output": str(output_path),
        "format": "html",
    }


def _imgui_geometry_payload_command(args: argparse.Namespace) -> dict:
    report = json.loads(args.path.read_text(encoding="utf-8-sig"))
    return imgui_geometry_payload_from_report(report)


def _imgui_link_classification_summary_payload_command(
    args: argparse.Namespace,
) -> dict:
    report = json.loads(args.path.read_text(encoding="utf-8-sig"))
    return imgui_link_classification_summary_payload_from_report(report)


def _imgui_analysis_payload_command(args: argparse.Namespace) -> dict:
    return imgui_analysis_payload_from_acceptance_reports(
        _analysis_reports_from_args(args)
    )


def _imgui_analysis_summary_payload_command(args: argparse.Namespace) -> dict:
    reports = [_load_report_json(path) for path in args.paths]
    return imgui_analysis_payload_from_acceptance_reports(reports)


def _imgui_invariant_status_payload_command(args: argparse.Namespace) -> dict:
    return imgui_invariant_status_payload_from_acceptance_reports(
        _acceptance_reports_from_args(args)
    )


def _imgui_invariant_status_summary_payload_command(args: argparse.Namespace) -> dict:
    reports = [_load_report_json(path) for path in args.paths]
    return imgui_invariant_status_payload_from_reports(reports)


def _imgui_signed_pd_invariant_status_payload_command(args: argparse.Namespace) -> dict:
    signed_pd_payload = _load_signed_pd_json(args.path)
    reports = [
        _homfly_pd_command(args),
        _multivariable_alexander_pd_command(args),
    ]
    payload = imgui_invariant_status_payload_from_reports(
        reports,
        signed_pd_revision=_signed_pd_revision_from_payload(signed_pd_payload),
    )
    payload["source_signed_pd"] = str(args.path)
    payload["notes"] = [
        *payload.get("notes", []),
        "computed from one signed-PD input through homfly-pd and multivariable-alexander-pd report paths",
    ]
    return payload

def _imgui_fixture_comparison_payload_command(args: argparse.Namespace) -> dict:
    return imgui_fixture_comparison_payload_from_acceptance_reports(
        _acceptance_reports_from_args(args)
    )


def _imgui_signed_pd_payload_command(args: argparse.Namespace) -> dict:
    return imgui_signed_pd_payload_from_acceptance_reports(
        _acceptance_reports_from_args(args)
    )


def _imgui_kernel_backend_status_payload_command(args: argparse.Namespace) -> dict:
    return imgui_kernel_backend_status_payload_from_backend_report()


def _imgui_host_payload_command(args: argparse.Namespace) -> dict:
    acceptance_reports = _acceptance_reports_from_args(args)
    geometry_report = None
    if args.geometry_report is not None:
        geometry_report = _load_report_json(args.geometry_report)
    invariant_reports = _invariant_reports_from_args(args)
    return imgui_host_payload_from_acceptance_reports(
        acceptance_reports,
        geometry_report=geometry_report,
        analysis_reports=_analysis_reports_from_args(args),
        invariant_reports=invariant_reports,
    )


def _add_alexander_signed_pd_coverage_arguments(command: argparse.ArgumentParser) -> None:
    command.add_argument(
        "--notation",
        action="append",
        default=None,
        help="Fixture notation to include. Repeat for multiple fixtures.",
    )
    command.add_argument(
        "--max-matrix-size",
        type=int,
        default=4,
        help="Maximum Fox matrix size for generated signed-PD cases.",
    )
    command.add_argument(
        "--max-minors",
        type=int,
        default=64,
        help="Maximum Fox square minors to scan per generated signed-PD case.",
    )
    command.add_argument(
        "--branch-depth",
        type=int,
        default=1,
        help="Maximum generated skein-branch depth to audit.",
    )
    command.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )

def _add_fixture_acceptance_report_arguments(command: argparse.ArgumentParser) -> None:
    command.add_argument(
        "--notation",
        action="append",
        default=None,
        help="Fixture notation to include. Repeat for multiple fixtures.",
    )
    command.add_argument(
        "--include-unregistered",
        action="store_true",
        help="Keep fixtures without registered invariant values as skipped rows.",
    )
    command.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )


def _add_acceptance_payload_arguments(command: argparse.ArgumentParser) -> None:
    command.add_argument(
        "--report",
        action="append",
        choices=["homfly", "alexander"],
        default=None,
        help="Acceptance report family to include. Repeat to include both explicitly.",
    )
    command.add_argument(
        "--notation",
        action="append",
        default=None,
        help="Fixture notation to include. Repeat for multiple fixtures.",
    )
    command.add_argument(
        "--include-unregistered",
        action="store_true",
        help="Keep fixtures without registered invariant values as skipped rows.",
    )
    command.add_argument(
        "--branch-depth",
        type=int,
        default=1,
        help="Maximum generated skein-branch depth for optional coverage summaries.",
    )
    command.add_argument(
        "-o", "--output", type=Path, default=None, help="Output JSON file."
    )


def _add_extra_analysis_report_arguments(command: argparse.ArgumentParser) -> None:
    command.add_argument(
        "--analysis-report-json",
        action="append",
        default=None,
        type=Path,
        help=(
            "Existing report JSON to append to the ImGui analysis-summary section. "
            "Repeat for multiple reports, including signed-PD role-order diagnostics."
        ),
    )


def _add_extra_invariant_report_arguments(command: argparse.ArgumentParser) -> None:
    command.add_argument(
        "--invariant-report-json",
        action="append",
        default=None,
        type=Path,
        help=(
            "Existing HOMFLY/Alexander invariant report JSON to append to the "
            "ImGui invariant-status section. Repeat for multiple reports."
        ),
    )


def _add_analysis_signed_pd_role_order_arguments(command: argparse.ArgumentParser) -> None:
    command.add_argument(
        "--analysis-signed-pd-role-order-candidates",
        action="append",
        default=None,
        type=Path,
        help=(
            "Signed-PD JSON to audit and append as a role-order candidate analysis "
            "summary. Repeat for multiple signed-PD inputs."
        ),
    )
    command.add_argument(
        "--analysis-role-order-signatures",
        action="store_true",
        help="Include bounded HOMFLY/Alexander signatures in generated role-order candidate reports.",
    )
    command.add_argument(
        "--analysis-role-order-signature-max-candidates",
        type=int,
        default=8,
        help="Maximum strict role-order candidates to sign for analysis summaries.",
    )
    command.add_argument(
        "--analysis-role-order-signature-max-depth",
        type=int,
        default=8,
        help="Maximum recursive HOMFLY depth for analysis role-order signatures.",
    )
    command.add_argument(
        "--analysis-role-order-signature-max-nodes",
        type=int,
        default=2048,
        help="Maximum HOMFLY nodes per analysis role-order signature attempt.",
    )
    command.add_argument(
        "--analysis-role-order-signature-max-minors",
        type=int,
        default=64,
        help="Maximum Fox square minors per analysis role-order signature.",
    )


def _add_analysis_source_table_audit_arguments(command: argparse.ArgumentParser) -> None:
    command.add_argument(
        "--analysis-source-table-invariant-audit",
        action="append",
        default=None,
        help=(
            "Fixture notation whose source-table invariant audit should be generated "
            "and appended as an analysis summary. Repeat for multiple fixtures."
        ),
    )
    command.add_argument(
        "--analysis-source-table-target-pairwise-linking",
        type=_parse_pairwise_linking,
        default=None,
        help="Override source-table audit target pairwise-linking values.",
    )
    command.add_argument(
        "--analysis-source-table-max-orientation-samples",
        type=int,
        default=64,
        help="Maximum orientation samples for generated source-table audits.",
    )
    command.add_argument(
        "--analysis-source-table-max-sign-patterns",
        type=int,
        default=None,
        help="Maximum sign patterns for generated source-table audits.",
    )
    command.add_argument(
        "--analysis-source-table-max-candidates",
        type=int,
        default=64,
        help="Maximum candidates returned by generated source-table audits.",
    )
    command.add_argument(
        "--analysis-source-table-include-homfly",
        action="store_true",
        help="Compute bounded HOMFLY candidates in generated source-table audits.",
    )
    command.add_argument(
        "--analysis-source-table-no-alexander",
        action="store_true",
        help="Skip multi-variable Alexander candidates in generated source-table audits.",
    )
    command.add_argument(
        "--analysis-source-table-homfly-max-depth",
        type=int,
        default=12,
        help="Maximum recursive HOMFLY depth for generated source-table audits.",
    )
    command.add_argument(
        "--analysis-source-table-homfly-max-nodes",
        type=int,
        default=2048,
        help="Maximum HOMFLY nodes for generated source-table audits.",
    )
    command.add_argument(
        "--analysis-source-table-alexander-max-matrix-size",
        type=int,
        default=5,
        help="Maximum Fox matrix size for generated source-table audits.",
    )
    command.add_argument(
        "--analysis-source-table-alexander-max-minors",
        type=int,
        default=128,
        help="Maximum Fox square minors for generated source-table audits.",
    )


def _add_alexander_signed_pd_coverage_summary_argument(
    command: argparse.ArgumentParser,
) -> None:
    command.add_argument(
        "--include-alexander-signed-pd-coverage",
        action="store_true",
        help=(
            "Add the generated Alexander signed-PD input-chain coverage report "
            "to the analysis summary payload."
        ),
    )
    command.add_argument(
        "--alexander-coverage-max-matrix-size",
        type=int,
        default=None,
        help=(
            "Override the generated Alexander signed-PD coverage Fox matrix "
            "size limit."
        ),
    )
    command.add_argument(
        "--alexander-coverage-max-minors",
        type=int,
        default=None,
        help=(
            "Override the generated Alexander signed-PD coverage Fox square "
            "minor scan limit."
        ),
    )


def _add_homfly_small_coverage_argument(command: argparse.ArgumentParser) -> None:
    command.add_argument(
        "--include-homfly-small-coverage",
        action="store_true",
        help=(
            "Add the generated HOMFLY small-diagram coverage report to the "
            "analysis summary payload."
        ),
    )
    command.add_argument(
        "--homfly-coverage-max-depth",
        type=int,
        default=None,
        help=(
            "Override the generated HOMFLY small-diagram coverage recursion "
            "depth limit."
        ),
    )
    command.add_argument(
        "--homfly-coverage-max-nodes",
        type=int,
        default=None,
        help="Override the generated HOMFLY small-diagram coverage node limit.",
    )


def _analysis_reports_from_args(args: argparse.Namespace) -> list[dict]:
    reports = _acceptance_reports_from_args(args)
    if getattr(args, "include_homfly_small_coverage", False):
        homfly_coverage_kwargs = {
            "notations": _notations_from_args(args),
            "branch_depth": getattr(args, "branch_depth", 1),
        }
        homfly_max_depth = getattr(args, "homfly_coverage_max_depth", None)
        if homfly_max_depth is not None:
            homfly_coverage_kwargs["max_depth"] = homfly_max_depth
        homfly_max_nodes = getattr(args, "homfly_coverage_max_nodes", None)
        if homfly_max_nodes is not None:
            homfly_coverage_kwargs["max_nodes"] = homfly_max_nodes
        reports.append(
            homfly_small_diagram_coverage_report(**homfly_coverage_kwargs)
        )
    if getattr(args, "include_alexander_signed_pd_coverage", False):
        alexander_coverage_kwargs = {
            "notations": _notations_from_args(args),
            "branch_depth": getattr(args, "branch_depth", 1),
        }
        alexander_max_matrix_size = getattr(
            args,
            "alexander_coverage_max_matrix_size",
            None,
        )
        if alexander_max_matrix_size is not None:
            alexander_coverage_kwargs["max_matrix_size"] = alexander_max_matrix_size
        alexander_max_minors = getattr(args, "alexander_coverage_max_minors", None)
        if alexander_max_minors is not None:
            alexander_coverage_kwargs["max_minors"] = alexander_max_minors
        reports.append(
            multivariable_alexander_signed_pd_coverage_report(
                **alexander_coverage_kwargs
            )
        )
    for path in getattr(args, "analysis_report_json", None) or []:
        reports.append(_load_report_json(path))
    for path in getattr(args, "analysis_signed_pd_role_order_candidates", None) or []:
        reports.append(
            _signed_pd_role_order_candidates_report_from_payload(
                _load_signed_pd_json(path),
                include_invariant_signatures=getattr(
                    args,
                    "analysis_role_order_signatures",
                    False,
                ),
                signature_max_candidates=getattr(
                    args,
                    "analysis_role_order_signature_max_candidates",
                    8,
                ),
                signature_max_depth=getattr(
                    args,
                    "analysis_role_order_signature_max_depth",
                    8,
                ),
                signature_max_nodes=getattr(
                    args,
                    "analysis_role_order_signature_max_nodes",
                    2048,
                ),
                signature_max_minors=getattr(
                    args,
                    "analysis_role_order_signature_max_minors",
                    64,
                ),
            )
        )
    for notation in getattr(args, "analysis_source_table_invariant_audit", None) or []:
        fixture = get_diagram_fixture(notation)
        reports.append(
            fixture.source_table_invariant_audit(
                max_orientation_samples=getattr(
                    args,
                    "analysis_source_table_max_orientation_samples",
                    64,
                ),
                max_sign_patterns=getattr(
                    args,
                    "analysis_source_table_max_sign_patterns",
                    None,
                ),
                max_candidates=getattr(
                    args,
                    "analysis_source_table_max_candidates",
                    64,
                ),
                target_pairwise_linking=getattr(
                    args,
                    "analysis_source_table_target_pairwise_linking",
                    None,
                ),
                compute_homfly=getattr(
                    args,
                    "analysis_source_table_include_homfly",
                    False,
                ),
                compute_alexander=not getattr(
                    args,
                    "analysis_source_table_no_alexander",
                    False,
                ),
                homfly_max_depth=getattr(
                    args,
                    "analysis_source_table_homfly_max_depth",
                    12,
                ),
                homfly_max_nodes=getattr(
                    args,
                    "analysis_source_table_homfly_max_nodes",
                    2048,
                ),
                alexander_max_matrix_size=getattr(
                    args,
                    "analysis_source_table_alexander_max_matrix_size",
                    5,
                ),
                alexander_max_minors=getattr(
                    args,
                    "analysis_source_table_alexander_max_minors",
                    128,
                ),
            )
        )
    return reports


def _invariant_reports_from_args(args: argparse.Namespace) -> list[dict] | None:
    paths = getattr(args, "invariant_report_json", None) or []
    if not paths:
        return None
    reports = _acceptance_reports_from_args(args)
    for path in paths:
        reports.append(_load_report_json(path))
    return reports


def _acceptance_reports_from_args(args: argparse.Namespace) -> list[dict]:
    selected: list[str] = []
    for name in args.report or ["homfly", "alexander"]:
        if name not in selected:
            selected.append(name)

    notations = _notations_from_args(args)
    reports = []
    if "homfly" in selected:
        reports.append(
            homfly_fixture_acceptance_report(
                notations=notations,
                include_unregistered=args.include_unregistered,
            )
        )
    if "alexander" in selected:
        reports.append(
            multivariable_alexander_fixture_acceptance_report(
                notations=notations,
                include_unregistered=args.include_unregistered,
            )
        )
    return reports


def _notations_from_args(args: argparse.Namespace) -> tuple[str, ...] | None:
    return tuple(args.notation) if args.notation else None


def _variables_from_payload(payload: dict) -> tuple[str, ...] | None:
    raw_variables = payload.get("variables")
    if raw_variables is None:
        return None
    if not isinstance(raw_variables, list):
        raise ValueError("variables must be a list of component variable names")
    return tuple(str(variable) for variable in raw_variables)


def _load_signed_pd_json(path: Path) -> dict:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(payload, dict):
        raise ValueError("signed-PD input JSON must be an object")
    return payload


def _signed_pd_revision_from_payload(payload: dict) -> int | None:
    revision = payload.get("signed_pd_revision")
    if isinstance(revision, bool) or not isinstance(revision, int):
        return None
    return revision if revision >= 0 else None


def _load_report_json(path: Path) -> dict:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(payload, dict):
        raise ValueError("report JSON must be an object")
    return payload


def _auto_role_order_report_not_requested() -> dict:
    return {
        "requested": False,
        "applied": False,
        "status": "not_requested",
        "candidate_count": 0,
        "strict_candidate_count": 0,
        "unique_strict_global_role_order": None,
        "candidate_role_orders": [],
        "notes": [],
    }


def _resolve_auto_role_order(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None,
    input_role_order: tuple[int, int, int, int] | None,
    compute_role_order: tuple[int, int, int, int] | None,
) -> dict:
    if orientation is not None:
        return {
            **_auto_role_order_report_not_requested(),
            "requested": True,
            "status": "not_needed",
            "notes": ["explicit orientation metadata is already available"],
        }
    if input_role_order is not None or compute_role_order is not None:
        return {
            **_auto_role_order_report_not_requested(),
            "requested": True,
            "status": "not_needed",
            "notes": ["a caller-declared role_order is already available"],
        }
    if diagram.crossing_count == 0:
        return {
            **_auto_role_order_report_not_requested(),
            "requested": True,
            "status": "not_needed",
            "notes": ["zero-crossing diagrams do not need role-order inference"],
        }

    report = _signed_pd_role_order_candidate_report(diagram)
    unique_role_order = report["unique_strict_global_role_order"]
    status = "unique_applied" if unique_role_order is not None else report["status"]
    notes = list(report["notes"])
    if unique_role_order is not None:
        notes.append("unique strict global role_order selected for this input")
    return {
        "requested": True,
        "applied": unique_role_order is not None,
        "status": status,
        "candidate_count": report["candidate_count"],
        "strict_candidate_count": report["strict_candidate_count"],
        "unique_strict_global_role_order": unique_role_order,
        "candidate_role_orders": report["candidate_role_orders"],
        "notes": notes,
    }


def _signed_pd_role_order_candidate_report(
    diagram: PlanarDiagram,
    *,
    include_component_mismatches: bool = False,
    include_invariant_signatures: bool = False,
    signature_variables: tuple[str, ...] | None = None,
    signature_max_candidates: int = 8,
    signature_max_depth: int = 8,
    signature_max_nodes: int = 2048,
    signature_max_minors: int = 64,
) -> dict:
    raw_candidates = PDOrientation.role_permutation_candidates(
        diagram,
        include_component_mismatches=include_component_mismatches,
    )
    candidates = [
        _signed_pd_role_order_candidate_to_dict(candidate)
        for candidate in raw_candidates
    ]
    strict_candidates = [candidate for candidate in candidates if candidate["strict"]]
    signature_report = _signed_pd_role_order_signature_report_not_requested()
    if include_invariant_signatures:
        signature_report = _attach_signed_pd_role_order_signatures(
            diagram,
            candidates,
            variables=signature_variables,
            max_candidates=signature_max_candidates,
            max_depth=signature_max_depth,
            max_nodes=signature_max_nodes,
            max_minors=signature_max_minors,
        )
    unique_role_order = None
    if len(strict_candidates) == 1:
        unique_role_order = strict_candidates[0]["role_order"]
    if unique_role_order is not None:
        status = "unique"
        notes = ["exactly one strict global role_order candidate matched the diagram"]
    elif strict_candidates:
        status = "ambiguous"
        notes = [
            "multiple strict global role_order candidates matched the diagram; supply --role-order or per-crossing role_order metadata"
        ]
    else:
        status = "no_strict_candidate"
        notes = [
            "no strict global role_order candidate matched the diagram; per-crossing role_order metadata may be required"
        ]
    return {
        "diagram": diagram.to_dict(),
        "status": status,
        "include_component_mismatches": include_component_mismatches,
        "candidate_count": len(candidates),
        "strict_candidate_count": len(strict_candidates),
        "unique_strict_global_role_order": unique_role_order,
        "candidate_role_orders": [
            candidate["role_order"] for candidate in strict_candidates
        ],
        "invariant_signatures": signature_report,
        "candidates": candidates,
        "notes": notes,
    }


def _signed_pd_role_order_signature_report_not_requested() -> dict:
    return {
        "requested": False,
        "signature_resolution_status": "not_requested",
        "signature_resolution_status_code": 0,
        "strict_candidate_count": 0,
        "all_strict_candidates_evaluated": False,
        "evaluated_candidate_count": 0,
        "skipped_candidate_count": 0,
        "max_candidates": 0,
        "homfly_signature_count": 0,
        "alexander_signature_count": 0,
        "combined_signature_count": 0,
        "alexander_complete_scanned_gcd_certified_candidate_count": 0,
        "groups": [],
        "notes": [],
    }


_SIGNED_PD_ROLE_ORDER_SIGNATURE_RESOLUTION_STATUS_CODES = {
    "not_requested": 0,
    "no_strict_candidates": 1,
    "not_evaluated": 2,
    "evaluated_candidates_same_signature": 3,
    "all_strict_candidates_same_signature": 4,
    "partially_distinguishes_candidates": 5,
    "distinguishes_strict_candidates": 6,
}


def _signed_pd_role_order_signature_resolution_status_code(status: str) -> int:
    return _SIGNED_PD_ROLE_ORDER_SIGNATURE_RESOLUTION_STATUS_CODES.get(status, 0)

def _signed_pd_role_order_signature_resolution_status(
    *,
    strict_candidate_count: int,
    evaluated_candidate_count: int,
    combined_signature_count: int,
) -> str:
    if strict_candidate_count == 0:
        return "no_strict_candidates"
    if evaluated_candidate_count == 0:
        return "not_evaluated"
    all_evaluated = evaluated_candidate_count >= strict_candidate_count
    if combined_signature_count <= 1:
        if all_evaluated:
            return "all_strict_candidates_same_signature"
        return "evaluated_candidates_same_signature"
    if all_evaluated:
        return "distinguishes_strict_candidates"
    return "partially_distinguishes_candidates"


def _attach_signed_pd_role_order_signatures(
    diagram: PlanarDiagram,
    candidates: list[dict],
    *,
    variables: tuple[str, ...] | None,
    max_candidates: int,
    max_depth: int,
    max_nodes: int,
    max_minors: int,
) -> dict:
    strict_candidates = [candidate for candidate in candidates if candidate["strict"]]
    limit = max(0, int(max_candidates))
    selected_candidates = strict_candidates[:limit]
    groups: dict[tuple[object, object], dict] = {}
    for candidate in selected_candidates:
        signature = _signed_pd_role_order_candidate_signature(
            diagram,
            tuple(candidate["role_order"]),
            variables=variables,
            max_depth=max_depth,
            max_nodes=max_nodes,
            max_minors=max_minors,
        )
        candidate["invariant_signature"] = signature
        key = (
            signature["homfly"]["polynomial"],
            signature["alexander"]["polynomial"],
        )
        group = groups.setdefault(
            key,
            {
                "homfly_polynomial": signature["homfly"]["polynomial"],
                "multivariable_alexander_polynomial": signature["alexander"]["polynomial"],
                "role_orders": [],
                "count": 0,
                "homfly_certified_count": 0,
                "homfly_frontier_count": 0,
                "homfly_frontier_reason_count": 0,
                "homfly_truncated_count": 0,
                "alexander_bounded_scanned_gcd_certified_count": 0,
                "alexander_complete_scanned_gcd_certified_count": 0,
                "alexander_quotient_gcd_certified_count": 0,
                "alexander_failed_nonzero_minor_count": 0,
                "alexander_truncated_count": 0,
            },
        )
        group["role_orders"].append(list(candidate["role_order"]))
        group["count"] += 1
        if signature["homfly"]["certified_for_input"]:
            group["homfly_certified_count"] += 1
        group["homfly_frontier_count"] += int(
            signature["homfly"].get("frontier_count") or 0
        )
        group["homfly_frontier_reason_count"] += int(
            signature["homfly"].get("frontier_reason_count") or 0
        )
        if signature["homfly"].get("truncated"):
            group["homfly_truncated_count"] += 1
        if signature["alexander"].get("bounded_scanned_gcd_certified"):
            group["alexander_bounded_scanned_gcd_certified_count"] += 1
        if signature["alexander"].get("complete_scanned_gcd_certified"):
            group["alexander_complete_scanned_gcd_certified_count"] += 1
        if signature["alexander"].get("quotient_gcd_certified"):
            group["alexander_quotient_gcd_certified_count"] += 1
        group["alexander_failed_nonzero_minor_count"] += int(
            signature["alexander"].get("failed_nonzero_minor_count") or 0
        )
        if signature["alexander"].get("truncated"):
            group["alexander_truncated_count"] += 1

    skipped_count = max(0, len(strict_candidates) - len(selected_candidates))
    evaluated_count = len(selected_candidates)
    all_strict_candidates_evaluated = bool(strict_candidates) and evaluated_count == len(strict_candidates)
    homfly_values = {
        candidate["invariant_signature"]["homfly"]["polynomial"]
        for candidate in selected_candidates
        if "invariant_signature" in candidate
    }
    alexander_values = {
        candidate["invariant_signature"]["alexander"]["polynomial"]
        for candidate in selected_candidates
        if "invariant_signature" in candidate
    }
    notes = [
        "bounded invariant signatures are convention diagnostics, not external table-normalization proof"
    ]
    if skipped_count:
        notes.append(
            "not all strict candidates were evaluated; increase --signature-max-candidates for a wider diagnostic scan"
        )
    signature_resolution_status = _signed_pd_role_order_signature_resolution_status(
        strict_candidate_count=len(strict_candidates),
        evaluated_candidate_count=evaluated_count,
        combined_signature_count=len(groups),
    )
    notes.append(f"signature resolution status: {signature_resolution_status}")
    return {
        "requested": True,
        "signature_resolution_status": signature_resolution_status,
        "signature_resolution_status_code": (
            _signed_pd_role_order_signature_resolution_status_code(
                signature_resolution_status
            )
        ),
        "strict_candidate_count": len(strict_candidates),
        "all_strict_candidates_evaluated": all_strict_candidates_evaluated,
        "evaluated_candidate_count": evaluated_count,
        "skipped_candidate_count": skipped_count,
        "max_candidates": limit,
        "homfly_signature_count": len(homfly_values),
        "alexander_signature_count": len(alexander_values),
        "combined_signature_count": len(groups),
        "homfly_certified_candidate_count": sum(
            1
            for candidate in selected_candidates
            if candidate["invariant_signature"]["homfly"]["certified_for_input"]
        ),
        "homfly_frontier_count": sum(
            int(candidate["invariant_signature"]["homfly"].get("frontier_count") or 0)
            for candidate in selected_candidates
        ),
        "homfly_frontier_reason_count": sum(
            int(
                candidate["invariant_signature"]["homfly"].get(
                    "frontier_reason_count"
                )
                or 0
            )
            for candidate in selected_candidates
        ),
        "homfly_truncated_candidate_count": sum(
            1
            for candidate in selected_candidates
            if candidate["invariant_signature"]["homfly"].get("truncated")
        ),
        "alexander_bounded_scanned_gcd_certified_candidate_count": sum(
            1
            for candidate in selected_candidates
            if candidate["invariant_signature"]["alexander"].get(
                "bounded_scanned_gcd_certified"
            )
        ),
        "alexander_complete_scanned_gcd_certified_candidate_count": sum(
            1
            for candidate in selected_candidates
            if candidate["invariant_signature"]["alexander"].get(
                "complete_scanned_gcd_certified"
            )
        ),
        "alexander_quotient_gcd_certified_candidate_count": sum(
            1
            for candidate in selected_candidates
            if candidate["invariant_signature"]["alexander"].get(
                "quotient_gcd_certified"
            )
        ),
        "alexander_failed_nonzero_minor_count": sum(
            int(
                candidate["invariant_signature"]["alexander"].get(
                    "failed_nonzero_minor_count"
                )
                or 0
            )
            for candidate in selected_candidates
        ),
        "alexander_truncated_candidate_count": sum(
            1
            for candidate in selected_candidates
            if candidate["invariant_signature"]["alexander"].get("truncated")
        ),
        "groups": list(groups.values()),
        "max_depth": max_depth,
        "max_nodes": max_nodes,
        "max_minors": max_minors,
        "variables": list(variables) if variables is not None else [],
        "notes": notes,
    }


def _signed_pd_role_order_candidate_signature(
    diagram: PlanarDiagram,
    role_order: tuple[int, int, int, int],
    *,
    variables: tuple[str, ...] | None,
    max_depth: int,
    max_nodes: int,
    max_minors: int,
) -> dict:
    orientation = PDOrientation.from_signed_pd_roles(diagram, role_order=role_order)
    homfly_result = homfly_iterative_certified_evaluation_from_pd(
        diagram,
        orientation=orientation,
        max_depth=max_depth,
        max_nodes=max_nodes,
    )
    homfly_evidence = homfly_input_certification_evidence(homfly_result)
    alexander_result = multivariable_alexander_from_pd(
        diagram,
        orientation=orientation,
        variables=variables,
        max_minors=max_minors,
    )
    alexander_scanned_gcd_audit = multivariable_alexander_scanned_gcd_audit(
        alexander_result
    )
    alexander_wirtinger_fox_audit = multivariable_alexander_wirtinger_fox_audit(
        alexander_result
    )
    alexander_admissible_minor_normalization_audit = (
        multivariable_alexander_admissible_minor_normalization_audit(
            alexander_result
        )
    )
    alexander_evidence = multivariable_alexander_input_certification_evidence(
        alexander_scanned_gcd_audit,
        alexander_wirtinger_fox_audit,
        alexander_admissible_minor_normalization_audit,
    )
    return {
        "role_order": list(role_order),
        "homfly": {
            "polynomial": homfly_result.get("homfly_polynomial"),
            "certified_for_input": bool(homfly_result.get("certified_for_input", False)),
            "skipped": bool(homfly_result.get("skipped", False)),
            "frontier_count": homfly_evidence.get("frontier_count"),
            "frontier_reason_count": homfly_evidence.get("frontier_reason_count"),
            "frontier_reasons": list(homfly_evidence.get("frontier_reasons", [])),
            "truncated": bool(homfly_evidence.get("truncated", False)),
            "solved_depth": homfly_evidence.get("iterative_solved_depth"),
            "notes": list(homfly_result.get("notes", [])),
        },
        "alexander": {
            "polynomial": alexander_result.get("multivariable_alexander_polynomial"),
            "candidate_polynomials": list(alexander_result.get("candidate_polynomials", [])),
            "skipped": bool(alexander_result.get("skipped", False)),
            "bounded_scanned_gcd_certified": bool(
                alexander_evidence.get("bounded_scanned_gcd_certified", False)
            ),
            "complete_scanned_gcd_certified": bool(
                alexander_evidence.get("complete_scanned_gcd_certified", False)
            ),
            "quotient_gcd_certified": bool(
                alexander_evidence.get("quotient_gcd_certified", False)
            ),
            "quotient_gcd_polynomial": alexander_evidence.get(
                "quotient_gcd_polynomial"
            ),
            "quotient_gcd_method": alexander_evidence.get("quotient_gcd_method"),
            "bounded_admissible_minor_normalization_certified": bool(
                alexander_evidence.get(
                    "bounded_admissible_minor_normalization_certified",
                    False,
                )
            ),
            "all_nonzero_minors_laurent_unit_equivalent": bool(
                alexander_evidence.get(
                    "all_nonzero_minors_laurent_unit_equivalent",
                    False,
                )
            ),
            "admissible_minor_normalized_representative_polynomial": (
                alexander_evidence.get(
                    "admissible_minor_normalized_representative_polynomial"
                )
            ),
            "checked_nonzero_minor_count": alexander_evidence.get(
                "checked_nonzero_minor_count"
            ),
            "failed_nonzero_minor_count": alexander_evidence.get(
                "failed_nonzero_minor_count"
            ),
            "truncated": bool(alexander_evidence.get("truncated", False)),
            "full_invariant_certified": bool(
                alexander_result.get("full_invariant_certified", False)
            ),
            "input_certification_evidence": alexander_evidence,
            "notes": list(alexander_result.get("notes", [])),
        },
    }
def _signed_pd_role_order_candidate_to_dict(candidate: dict) -> dict:
    return {
        "role_order": list(candidate["role_order"]),
        "role_mapping": [dict(item) for item in candidate.get("role_mapping", ())],
        "component_count": candidate.get("component_count"),
        "component_count_matches": bool(candidate.get("component_count_matches", False)),
        "strict": bool(candidate.get("strict", False)),
        "traversals": [dict(item) for item in candidate.get("traversals", ())],
        "notes": list(candidate.get("notes", [])),
    }
def _signed_pd_input_from_payload(
    payload: dict,
    *,
    role_order_override: tuple[int, int, int, int] | None,
    auto_role_order: bool = False,
) -> dict:
    diagram_payload = payload.get("diagram", payload)
    if not isinstance(diagram_payload, dict):
        raise ValueError("signed-PD input JSON must contain an object diagram")

    input_shape = "planar_diagram"
    per_crossing_role_orders: tuple[tuple[int, int, int, int], ...] | None = None
    per_crossing_role_order_explicit: tuple[bool, ...] | None = None
    if _looks_like_imgui_signed_pd_payload(diagram_payload):
        (
            diagram,
            per_crossing_role_orders,
            per_crossing_role_order_explicit,
        ) = _diagram_from_imgui_signed_pd_payload(diagram_payload)
        input_shape = "imgui_signed_pd"
    else:
        diagram = PlanarDiagram.from_dict(diagram_payload)

    raw_orientation = payload.get("orientation")
    orientation_supplied = isinstance(raw_orientation, dict)
    orientation = PDOrientation.from_dict(raw_orientation) if orientation_supplied else None
    input_role_order = role_order_override
    if input_role_order is None:
        input_role_order = _normalize_role_order(payload.get("role_order"))

    compute_role_order = input_role_order
    orientation_generated_from_role_orders = False
    if orientation is None and input_role_order is None and per_crossing_role_orders:
        unique_orders = set(per_crossing_role_orders)
        if len(unique_orders) == 1:
            only_order = next(iter(unique_orders))
            compute_role_order = None if only_order == (0, 1, 2, 3) else only_order
            input_role_order = compute_role_order
        elif any(order != (0, 1, 2, 3) for order in per_crossing_role_orders):
            orientation = PDOrientation.from_signed_pd_role_orders(
                diagram,
                per_crossing_role_orders,
            )
            orientation_generated_from_role_orders = True
            compute_role_order = None
    auto_role_order_report = _auto_role_order_report_not_requested()
    if auto_role_order:
        auto_role_order_report = _resolve_auto_role_order(
            diagram,
            orientation=orientation,
            input_role_order=input_role_order,
            compute_role_order=compute_role_order,
        )
        inferred_role_order = auto_role_order_report.get("unique_strict_global_role_order")
        if inferred_role_order is not None:
            input_role_order = tuple(inferred_role_order)
            compute_role_order = input_role_order

    if orientation is not None:
        compute_role_order = None

    return {
        "diagram": diagram,
        "orientation": orientation,
        "orientation_supplied": orientation_supplied,
        "orientation_generated_from_role_orders": orientation_generated_from_role_orders,
        "role_order": input_role_order,
        "compute_role_order": compute_role_order,
        "per_crossing_role_orders": per_crossing_role_orders,
        "per_crossing_role_order_explicit": per_crossing_role_order_explicit,
        "input_shape": input_shape,
        "signed_pd_revision": _signed_pd_revision_from_payload(payload),
        "auto_role_order": auto_role_order_report,
        "source_candidate_replay": _source_candidate_replay_metadata(payload),
    }


def _source_candidate_replay_metadata(payload: dict) -> dict:
    replay_keys = (
        "claim_scope",
        "source_notation",
        "source_name",
        "source",
        "source_url",
        "signs",
        "role_orders",
        "pairwise_linking",
        "orientation_validation_issues",
    )
    if not any(key in payload for key in replay_keys):
        return {}
    metadata = {"present": True}
    for key in replay_keys:
        if key not in payload:
            continue
        value = payload[key]
        if isinstance(value, (str, int, float, bool)) or value is None:
            metadata[key] = value
        elif isinstance(value, (list, dict)):
            metadata[key] = json.loads(json.dumps(value, allow_nan=False))
    return metadata


def _signed_pd_input_report(signed_pd_input: dict) -> dict:
    role_order = signed_pd_input["role_order"]
    per_crossing_role_orders = signed_pd_input["per_crossing_role_orders"]
    per_crossing_role_order_explicit = signed_pd_input[
        "per_crossing_role_order_explicit"
    ]
    report = {
        "diagram": signed_pd_input["diagram"].to_dict(),
        "input_shape": signed_pd_input["input_shape"],
        "orientation_supplied": bool(signed_pd_input["orientation_supplied"]),
        "orientation_generated_from_role_orders": bool(
            signed_pd_input["orientation_generated_from_role_orders"]
        ),
        "role_order": list(role_order) if role_order is not None else None,
        "per_crossing_role_orders": (
            [list(order) for order in per_crossing_role_orders]
            if per_crossing_role_orders is not None
            else None
        ),
        "per_crossing_role_order_explicit": (
            list(per_crossing_role_order_explicit)
            if per_crossing_role_order_explicit is not None
            else None
        ),
        "per_crossing_role_order_explicit_count": (
            sum(1 for explicit in per_crossing_role_order_explicit if explicit)
            if per_crossing_role_order_explicit is not None
            else 0
        ),
        "auto_role_order": signed_pd_input["auto_role_order"],
    }
    signed_pd_revision = signed_pd_input.get("signed_pd_revision")
    if signed_pd_revision is not None:
        report["signed_pd_revision"] = signed_pd_revision
    source_candidate_replay = signed_pd_input.get("source_candidate_replay")
    if source_candidate_replay:
        report["source_candidate_replay"] = dict(source_candidate_replay)
    return report


def _looks_like_imgui_signed_pd_payload(payload: dict) -> bool:
    return isinstance(payload.get("crossings"), list)


def _diagram_from_imgui_signed_pd_payload(
    payload: dict,
) -> tuple[PlanarDiagram, tuple[tuple[int, int, int, int], ...], tuple[bool, ...]]:
    rows = payload.get("crossings")
    if not isinstance(rows, list):
        raise ValueError("ImGui signed-PD payload must contain a crossings list")
    crossings = []
    role_orders = []
    role_order_explicit = []
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("ImGui signed-PD crossing rows must be objects")
        edge_labels = row.get("edge_labels", row.get("code"))
        if not isinstance(edge_labels, (list, tuple)) or len(edge_labels) != 4:
            raise ValueError("ImGui signed-PD crossing edge_labels must have length four")
        role_order = _normalize_role_order(row.get("role_order")) or (0, 1, 2, 3)
        role_orders.append(role_order)
        role_order_explicit.append(
            _imgui_role_order_explicit(row, role_order=role_order)
        )
        crossings.append(
            PDCrossing(
                tuple(int(label) for label in edge_labels),
                sign=int(row.get("sign", 1)),
            )
        )
    component_count = payload.get("component_count")
    if component_count is not None:
        component_count = int(component_count)
    diagram = PlanarDiagram(
        tuple(crossings),
        component_count=component_count,
        name=payload.get("name") or payload.get("fixture_name"),
        convention=payload.get("convention", "imgui_signed_pd_payload_v1"),
    )
    return diagram, tuple(role_orders), tuple(role_order_explicit)


def _imgui_role_order_explicit(
    row: dict,
    *,
    role_order: tuple[int, int, int, int],
) -> bool:
    value = row.get("role_order_explicit")
    if value is None:
        return "role_order" in row and role_order != (0, 1, 2, 3)
    if not isinstance(value, bool):
        raise ValueError("ImGui signed-PD crossing role_order_explicit must be a boolean")
    return value


def _parse_role_order(value: str | None) -> tuple[int, int, int, int] | None:
    if value is None:
        return None
    try:
        return _normalize_role_order(
            [part.strip() for part in value.replace(";", ",").split(",")]
        )
    except ValueError as exc:
        raise argparse.ArgumentTypeError(str(exc)) from exc


def _normalize_role_order(value: object) -> tuple[int, int, int, int] | None:
    if value is None:
        return None
    if not isinstance(value, (list, tuple)):
        raise ValueError("role_order must be a list or comma-separated permutation")
    try:
        order = tuple(int(item) for item in value)
    except (TypeError, ValueError) as exc:
        raise ValueError("role_order must contain four integer positions") from exc
    if len(order) != 4 or set(order) != {0, 1, 2, 3}:
        raise ValueError("role_order must be a permutation of 0,1,2,3")
    return order  # type: ignore[return-value]


def _parse_pairwise_linking(value: str | None) -> tuple[float, ...] | None:
    if value is None:
        return None
    parts = [
        part.strip()
        for part in value.replace(";", ",").split(",")
        if part.strip()
    ]
    if not parts:
        raise argparse.ArgumentTypeError(
            "pairwise linking must contain at least one comma-separated number"
        )
    try:
        return tuple(float(part) for part in parts)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            "pairwise linking values must be numbers"
        ) from exc


def _parse_direction(value: str | None) -> list[float] | None:
    if value is None:
        return None
    parts = [part.strip() for part in value.replace(";", ",").split(",") if part.strip()]
    if len(parts) != 3:
        raise argparse.ArgumentTypeError("direction must contain three comma-separated numbers")
    return [float(part) for part in parts]


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
