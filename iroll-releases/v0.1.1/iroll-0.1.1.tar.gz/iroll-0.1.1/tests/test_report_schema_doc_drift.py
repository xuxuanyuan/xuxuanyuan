﻿from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_validate_table_source_metadata_note_tokens_are_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")

    expected_note_tokens = [
        "validate_table_source_metadata=",
        "validate_table_source_metadata_sources=",
        "validate_table_source_metadata_source_value_rows=",
        "validate_table_source_metadata_source_url_schemes=",
        "validate_table_source_metadata_source_url_scheme_rows=",
        "validate_table_source_metadata_source_url_domains=",
        "validate_table_source_metadata_source_url_domain_rows=",
        "validate_table_source_metadata_source_url_issue_codes=",
        "validate_table_source_metadata_source_url_issue_code_rows=",
        "validate_table_source_metadata_issue_paths=",
        "validate_table_source_metadata_issue_messages=",
        "validate_table_source_metadata_provenance_blocker_codes=",
        "validate_table_source_metadata_missing_source_rows=",
        "validate_table_source_metadata_missing_source_url_rows=",
        "validate_table_source_metadata_source_url_without_source_rows=",
        "validate_table_source_metadata_convention_mismatch_rows=",
        "validate_table_source_metadata_known_limitations_rows=",
        "validate_table_source_metadata_convention_metadata_without_name_rows=",
    ]

    for token in expected_note_tokens:
        assert token in imgui_source
        assert token in report_schema


def test_strict_json_non_finite_report_boundary_is_documented() -> None:
    report_writer_source = (ROOT / "src/iroll/io/report.py").read_text(
        encoding="utf-8"
    )
    schema_source = (ROOT / "src/iroll/reports/schema.py").read_text(
        encoding="utf-8"
    )
    cli_source = (ROOT / "src/iroll/cli.py").read_text(encoding="utf-8")
    viewer_source = (ROOT / "src/iroll/viewer.py").read_text(encoding="utf-8")
    geometry_generator = (
        ROOT / "examples/generate_imgui_geometry_payload.py"
    ).read_text(encoding="utf-8")
    host_generator = (ROOT / "examples/generate_imgui_host_payload.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )

    assert "allow_nan=False" in report_writer_source
    assert "allow_nan=False" in schema_source
    assert "strict JSON serializable" in schema_source
    assert "json.dumps(value, allow_nan=False)" in cli_source
    assert "dump_report(report)" in viewer_source
    assert "dump_report(payload)" in geometry_generator
    assert "dump_report(payload)" in host_generator

    docs_tokens = [
        "strict JSON serialization",
        "shared report writer uses the same strict JSON boundary",
        "non-finite",
        "NaN",
        "Infinity",
        "before CLI/report files are written",
    ]
    for token in docs_tokens:
        assert token in report_schema
        assert token in native_release_docs
    for token in ["dump_report()", "write_report()", "host-loadable"]:
        assert token in native_release_docs

    viewer_tokens = [
        "static HTML report viewer",
        "shared strict JSON report writer",
        "reject non-finite",
        "before writing HTML",
    ]
    for token in viewer_tokens:
        assert token in execution_status

    sample_generator_tokens = [
        "committed Dear ImGui sample payload generators",
        "examples/generate_imgui_geometry_payload.py",
        "examples/generate_imgui_host_payload.py",
        "dump_report(payload)",
        "sample parity tests",
    ]
    for token in sample_generator_tokens:
        assert token in execution_status

    replay_metadata_tokens = [
        "Source-candidate replay metadata",
        "_source_candidate_replay_metadata",
        "allow_nan=False",
        "before the final report writer boundary",
    ]
    for token in replay_metadata_tokens:
        assert token in execution_status


def test_cli_json_export_strict_boundary_is_documented() -> None:
    io_cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    test_boundary_tokens = [
        "def _assert_strict_json_serializable",
        "json.dumps(payload, allow_nan=False)",
        "test_cli_validate_table_writes_review_ready_payload",
        "test_cli_validate_table_retains_provenance_blocker_vocabulary",
        "test_cli_single_input_certification_retained_pack_exports_imgui_payloads",
        "test_cli_source_table_invariant_audit_retained_pack_exports_imgui_payloads",
        "test_cli_generated_l2a1_coverage_retained_pack_exports_imgui_payloads",
        "test_cli_analyze_link_writes_output_file",
    ]
    for token in test_boundary_tokens:
        assert token in io_cli_tests

    docs_tokens = [
        "CLI JSON export regressions",
        "read-back raw report, ImGui analysis, and ImGui host JSON files",
        "validate-table retained metadata packs",
        "Rust unsupported-result-handle status files",
        "analyze-link JSON output chains",
        "same strict JSON boundary as schema/report-writer payloads",
    ]
    for token in docs_tokens:
        assert token in execution_status

    for token in [
        "shared report writer uses the same strict JSON boundary",
        "before CLI/report files are written",
    ]:
        assert token in report_schema


def test_dev_wrapper_script_mode_minimal_path_contract_is_documented() -> None:
    dev_cmd = (ROOT / "scripts/dev.cmd").read_text(encoding="utf-8")
    dev_ps1 = (ROOT / "scripts/dev.ps1").read_text(encoding="utf-8")
    dev_docs = (ROOT / "docs/development-environment.md").read_text(
        encoding="utf-8"
    )
    dev_tests = (ROOT / "tests/test_dev_environment_scripts.py").read_text(
        encoding="utf-8"
    )

    cmd_tokens = [
        r"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe",
        "-NoProfile -ExecutionPolicy Bypass -File",
    ]
    for token in cmd_tokens:
        assert token in dev_cmd
        assert token in dev_docs

    script_tokens = [
        "Get-NestedPowerShellExecutable",
        "Join-Path $PSHOME 'powershell.exe'",
        "Join-Path $PSHOME 'pwsh.exe'",
        ". $envScript -Quiet -NoMsvc:$NoMsvc",
    ]
    for token in script_tokens:
        assert token in dev_ps1
        assert token in dev_docs

    docs_tokens = [
        "Native commands therefore do not depend on a previous shell remembering PATH",
        (
            "Script-mode commands also use the current PowerShell installation "
            "path directly instead of looking up `powershell.exe` through PATH"
        ),
        "The base Python package must continue to work without Rust, CUDA, C++, or Dear ImGui",
    ]
    for token in docs_tokens:
        assert token in dev_docs

    behavior_tokens = [
        "test_dev_wrapper_script_mode_does_not_need_powershell_on_path",
        r"C:\Windows\System32;C:\Windows",
        "Write-Output ok",
    ]
    for token in behavior_tokens:
        assert token in dev_tests


def test_dev_cmd_wrapper_pythonpath_contract_is_documented() -> None:
    dev_env = (ROOT / "scripts/dev-env.ps1").read_text(encoding="utf-8")
    dev_docs = (ROOT / "docs/development-environment.md").read_text(
        encoding="utf-8"
    )
    dev_tests = (ROOT / "tests/test_dev_cmd_wrapper.py").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "$repoPythonPathCandidates = @(",
        "Join-Path $repoRoot 'src'",
        r"Join-Path $repoRoot 'native\iroll-kernels-gpu'",
        "Add-ProcessPythonPathEntry",
        "$env:PYTHONPATH",
        r"Join-Path $repoRoot '.venv\Scripts'",
    ]
    for token in source_tokens:
        assert token in dev_env

    docs_tokens = [
        r"prefers the repository `.venv\Scripts` directory",
        "prepends the repository `src` directory",
        "`native/iroll-kernels-gpu` package directory to `PYTHONPATH`",
        "local Python commands resolve the checkout modules consistently",
        "The repository wrappers set that process-local `PYTHONPATH` automatically",
    ]
    for token in docs_tokens:
        assert token in dev_docs

    behavior_tokens = [
        "test_dev_cmd_wrapper_sets_repository_pythonpath",
        "test_dev_cmd_wrapper_prefers_project_python_environment_for_imports",
        "repository Python paths were not added",
        "python -c 'import iroll'",
    ]
    for token in behavior_tokens:
        assert token in dev_tests


def test_validate_table_source_completeness_row_pack_is_documented() -> None:
    table_loader_source = (ROOT / "src/iroll/topology/table_loader.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )

    raw_row_pack_tokens = [
        "source_completeness_rows",
        "source_completeness_row_count_matched",
        "source_completeness_source_count_matched",
        "source_completeness_source_url_count_matched",
        "source_completeness_invalid_url_count_matched",
        "validate_table_source_metadata_source_completeness",
        "row_count_matched",
        "source_count_matched",
        "source_url_count_matched",
        "invalid_url_count_matched",
    ]
    for token in raw_row_pack_tokens:
        assert token in report_schema
    for token in raw_row_pack_tokens[:5]:
        assert token in table_loader_source
    for token in raw_row_pack_tokens[5:]:
        assert token in (ROOT / "src/iroll/reports/imgui.py").read_text(
            encoding="utf-8"
        )

    host_counter_tokens = [
        "analysis_validate_table_source_metadata_source_completeness_row_count",
        (
            "analysis_validate_table_source_metadata_"
            "source_completeness_row_count_matched_count"
        ),
        (
            "analysis_validate_table_source_metadata_"
            "source_completeness_source_count_matched_count"
        ),
        (
            "analysis_validate_table_source_metadata_"
            "source_completeness_source_url_count_matched_count"
        ),
        (
            "analysis_validate_table_source_metadata_"
            "source_completeness_invalid_url_count_matched_count"
        ),
    ]
    for token in host_counter_tokens:
        assert token in report_schema
        assert token in native_release_docs


def test_validate_table_source_completeness_boolean_bridge_is_documented() -> None:
    table_loader_source = (ROOT / "src/iroll/topology/table_loader.py").read_text(
        encoding="utf-8"
    )
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    validation_docs = (ROOT / "docs/validation-and-robustness.md").read_text(
        encoding="utf-8"
    )
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    report_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    raw_boolean_tokens = [
        "all_records_have_source",
        "all_source_records_have_source_url",
        "all_source_urls_have_source",
        "all_source_urls_are_http_or_https",
    ]
    for token in raw_boolean_tokens:
        assert token in table_loader_source
        assert token in validation_docs
        assert token in report_schema

    host_counter_tokens = [
        "analysis_validate_table_source_metadata_all_records_have_source_count",
        (
            "analysis_validate_table_source_metadata_"
            "all_source_records_have_source_url_count"
        ),
        "analysis_validate_table_source_metadata_all_source_urls_have_source_count",
        (
            "analysis_validate_table_source_metadata_"
            "all_source_urls_are_http_or_https_count"
        ),
    ]
    for token in host_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs
        assert token in execution_status

    negative_path_tokens = [
        "source_url=ftp://example.test/iroll/link/L2a1",
        "provenance_blocker_codes=[\"invalid_source_url\"]",
        "source_url_issue_code_counts={\"unsupported_scheme\":1}",
        "analysis_validate_table_source_metadata_all_source_urls_are_http_or_https_count=0",
        "with the other completeness counters still `1`",
    ]
    for token in negative_path_tokens:
        assert token in report_schema
        assert token in execution_status

    behavior_tokens = [
        "test_imgui_analysis_summary_mirrors_validate_table_source_completeness_booleans",
        "test_cli_validate_table_retains_invalid_source_url_pack",
    ]
    for token in behavior_tokens:
        assert token in report_tests or token in cli_tests


def test_validate_table_source_url_parser_consistency_is_documented() -> None:
    table_loader_source = (ROOT / "src/iroll/topology/table_loader.py").read_text(
        encoding="utf-8"
    )
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )

    raw_consistency_tokens = [
        "source_url_scheme_row_count_total_matched",
        "source_url_domain_row_count_total_matched",
        "source_url_issue_code_count_total_matched",
        "source_url_issue_code_invalid_row_coverage_matched",
    ]
    for token in raw_consistency_tokens:
        assert token in table_loader_source
        assert token in report_schema
        assert token in native_release_docs

    diagnostic_tokens = [
        "source_url_issue_codes",
        "source_url_issue_code_counts",
        "source_url_issue_code_rows",
        "source_url_issue_code_total",
        "missing_scheme",
        "missing_domain",
        "unsupported_scheme",
    ]
    for token in diagnostic_tokens:
        assert token in table_loader_source
        assert token in report_schema
        assert token in native_release_docs

    host_counter_tokens = [
        "analysis_validate_table_source_metadata_source_url_scheme_count",
        "analysis_validate_table_source_metadata_source_url_domain_count",
        "analysis_validate_table_source_metadata_source_url_missing_scheme_count",
        "analysis_validate_table_source_metadata_source_url_missing_domain_count",
        "analysis_validate_table_source_metadata_source_url_issue_code_total",
    ]
    for token in host_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs


def test_validate_table_source_metadata_non_claim_boundary_is_documented() -> None:
    table_loader_source = (ROOT / "src/iroll/topology/table_loader.py").read_text(
        encoding="utf-8"
    )
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    validation_docs = (ROOT / "docs/validation-and-robustness.md").read_text(
        encoding="utf-8"
    )
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )

    raw_boundary_tokens = [
        "table_correctness_certified",
        "external_source_verified",
    ]
    for token in raw_boundary_tokens:
        assert token in table_loader_source

    imgui_boundary_tokens = [
        "validate_table_source_metadata_table_correctness_certified_count",
        "validate_table_source_metadata_external_source_verified_count",
        "table_correctness_certified=",
        "external_source_verified=",
        "not external table correctness or invariant normalization evidence",
    ]
    for token in imgui_boundary_tokens:
        assert token in imgui_source

    docs_boundary_tokens = [
        "table_correctness_certified=false",
        "external_source_verified=false",
    ]
    for token in docs_boundary_tokens:
        assert token in report_schema
        assert token in validation_docs
        assert token in native_release_docs

    host_counter_tokens = [
        "analysis_validate_table_source_metadata_table_correctness_certified_count=0",
        "analysis_validate_table_source_metadata_external_source_verified_count=0",
    ]
    for token in host_counter_tokens:
        assert token in report_schema
        assert token in native_release_docs


def test_validate_table_source_metadata_report_bridge_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )

    bridge_tokens = [
        "validate_table_source_metadata_report",
        "table_source_metadata_scan",
    ]
    for token in bridge_tokens:
        assert token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    aggregate_family_tokens = [
        "analysis_validate_table_source_metadata_*",
    ]
    for token in aggregate_family_tokens:
        assert token in report_schema
        assert token in native_release_docs

    source_method_tokens = [
        "source_method=validate_table_source_metadata_report",
    ]
    for token in source_method_tokens:
        assert token in report_schema
        assert token in native_release_docs

    root_counter_tokens = [
        "analysis_validate_table_source_metadata_artifact_count",
        "analysis_validate_table_source_metadata_valid_count",
        "analysis_validate_table_source_metadata_record_count",
        "analysis_validate_table_source_metadata_provenance_review_ready_count",
        "analysis_validate_table_source_metadata_table_correctness_certified_count",
        "analysis_validate_table_source_metadata_external_source_verified_count",
    ]
    for token in root_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    pinned_ci_tokens = [
        "analysis_validate_table_source_metadata_artifact_count=1",
        "analysis_validate_table_source_metadata_valid_count=1",
        "analysis_validate_table_source_metadata_record_count=2",
        "analysis_validate_table_source_metadata_provenance_review_ready_count=1",
        "analysis_validate_table_source_metadata_table_correctness_certified_count=0",
        "analysis_validate_table_source_metadata_external_source_verified_count=0",
    ]
    for token in pinned_ci_tokens:
        assert token in report_schema
        assert token in native_release_docs


def test_validate_table_retained_pack_file_manifest_is_documented() -> None:
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    native_contract_tests = (
        ROOT / "tests/test_native_embedding_contracts.py"
    ).read_text(encoding="utf-8")

    retained_pack_stems = [
        "validate-table-source-metadata",
        "validate-table-source-metadata-blocked",
        "validate-table-source-metadata-invalid-known-limitations",
        "validate-table-source-metadata-invalid-known-limitations-item",
        "validate-table-source-metadata-invalid-source-url",
        "validate-table-source-metadata-provenance-blockers",
    ]
    retained_pack_files = []
    for stem in retained_pack_stems:
        retained_pack_files.extend(
            [
                f"{stem}-input.json",
                f"{stem}.json",
                f"{stem}-imgui-analysis.json",
                f"{stem}-imgui-host.json",
            ]
        )

    for token in retained_pack_files:
        assert token in native_release_docs
        assert token in native_contract_tests

    bridge_tokens = [
        "iroll-validate-table-source-metadata-py${{ matrix.python-version }}",
        "imgui-host-payload --analysis-report-json",
    ]
    for token in bridge_tokens:
        assert token in native_release_docs
        assert token in native_contract_tests
    assert "Upload validate-table source metadata artifact" in native_contract_tests


def test_link_classification_summary_payload_bridge_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    bridge_tokens = [
        "imgui_link_classification_summary_payload_from_report",
        "has_link_classification_summary",
        "link_classification_summary",
        "IrollLinkClassificationSummary",
        "source_table_source_match_resolution_statuses",
    ]
    for token in bridge_tokens:
        assert token in imgui_source
        assert token in report_schema

    behavior_tokens = [
        "test_imgui_link_classification_summary_payload_flattens_for_c_abi",
        "test_imgui_link_classification_summary_payload_flattens_borromean_candidate",
        "source_table_source_match_resolution_status_count",
        "L6a4:homfly:not_computed",
    ]
    for token in behavior_tokens:
        assert token in reports_schema_tests

    doc_tokens = [
        "imgui-link-classification-summary-payload",
        "ABI 88",
        "ABI 90",
        "Whitehead-style candidates",
        "Borromean `L6a4` candidates",
        "automatic table",
        "classifications",
    ]
    for token in doc_tokens:
        assert token in report_schema or token in execution_status


def test_host_payload_direct_invariant_reports_bridge_is_documented() -> None:
    cli_source = (ROOT / "src/iroll/cli.py").read_text(encoding="utf-8")
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    rust_kernel_docs = (ROOT / "docs/rust-kernel-interface.md").read_text(
        encoding="utf-8"
    )
    imgui_readme = (ROOT / "ui/imgui/README.md").read_text(encoding="utf-8")

    source_tokens = [
        "invariant_reports",
        "imgui_invariant_status_payload_from_reports",
        "without changing the acceptance-based fixture sections",
    ]
    for token in source_tokens:
        assert token in imgui_source

    cli_bridge_tokens = [
        "--invariant-report-json",
        "_invariant_reports_from_args(args)",
        "invariant_reports=invariant_reports",
    ]
    for token in cli_bridge_tokens:
        assert token in cli_source

    behavior_tokens = [
        "test_imgui_host_payload_can_append_direct_invariant_reports",
        "invariant_reports=[acceptance_report, direct_report]",
        '"imgui_invariant_status_payload_from_reports"',
        '"signed_pd_revision"] == 11',
        '"fixture_comparison_count"] == 1',
        '"signed_pd_diagram_count"',
    ]
    for token in behavior_tokens:
        assert token in reports_schema_tests

    doc_tokens = [
        "imgui_host_payload_from_acceptance_reports(..., invariant_reports=[...])",
        "imgui_invariant_status_payload_from_reports",
        "without changing the acceptance-based fixture-comparison or signed-PD sections",
        "imgui-host-payload --invariant-report-json",
    ]
    for token in doc_tokens:
        assert token in report_schema

    cli_scope_tokens = [
        "under its `invariants` section",
        "analysis summaries empty",
        "does not add those rows to the analysis section",
    ]
    assert cli_scope_tokens[0] in rust_kernel_docs
    assert cli_scope_tokens[1] in rust_kernel_docs
    assert cli_scope_tokens[2] in imgui_readme


def test_validate_table_known_limitations_shape_boundary_is_documented() -> None:
    table_loader_source = (ROOT / "src/iroll/topology/table_loader.py").read_text(
        encoding="utf-8"
    )
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    validation_docs = (ROOT / "docs/validation-and-robustness.md").read_text(
        encoding="utf-8"
    )
    table_tests = (ROOT / "tests/test_table_loader.py").read_text(
        encoding="utf-8"
    )
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    source_tokens = [
        "known_limitations",
        "known_limitations_count",
        "known_limitations_rows",
        "expected non-empty string or non-empty list of non-empty strings",
        "expected non-empty string",
    ]
    for token in source_tokens:
        assert token in table_loader_source
        assert token in report_schema
        assert token in validation_docs

    behavior_test_tokens = [
        "test_validate_table_file_counts_non_empty_known_limitations_text",
        "test_validate_table_file_flags_invalid_known_limitations_item",
        "test_validate_table_file_flags_invalid_known_limitations_shape",
        "test_cli_validate_table_retains_invalid_known_limitations_pack",
        "test_cli_validate_table_retains_invalid_known_limitations_item_path",
    ]
    for token in behavior_test_tokens:
        assert token in table_tests or token in cli_tests

    behavior_doc_tokens = [
        "$[0].known_limitations",
        "$[0].known_limitations[1]",
    ]
    for token in behavior_doc_tokens:
        assert token in table_tests
        assert token in cli_tests
        assert token in report_schema
        assert token in validation_docs

    imgui_tokens = [
        "validate_table_source_metadata_issue_paths=",
        "validate_table_source_metadata_known_limitations_rows=",
        "validate_table_source_metadata_issue_messages=",
    ]
    for token in imgui_tokens:
        assert token in imgui_source
        assert token in report_schema
        assert token in validation_docs

    boundary_tokens = [
        "provenance_review_ready=true",
        "provenance_blocker_count=0",
        "analysis_validate_table_source_metadata_known_limitations_count=1",
        "metadata-shape evidence only",
    ]
    for token in boundary_tokens:
        assert token in report_schema

    native_release_tokens = [
        "validate-table-source-metadata-invalid-known-limitations-item.json",
        (
            "validate-table-source-metadata-invalid-known-limitations-item-"
            "imgui-analysis.json"
        ),
        (
            "validate-table-source-metadata-invalid-known-limitations-item-"
            "imgui-host.json"
        ),
        "path=$[0].known_limitations[1]",
        "known_limitations_count=1",
        "validate_table_source_metadata_known_limitations_rows=$[0]",
        "analysis_validate_table_source_metadata_known_limitations_count=1",
        "validate_table_source_metadata_issue_paths=$[0].known_limitations[1]",
        "item-level metadata-shape errors",
    ]
    for token in native_release_tokens:
        assert token in native_release_docs


def test_validate_table_expected_convention_imgui_boolean_is_documented() -> None:
    table_loader_source = (ROOT / "src/iroll/topology/table_loader.py").read_text(
        encoding="utf-8"
    )
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    remaining_plan = (ROOT / "docs/remaining-deep-completion-plan.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    raw_expected_convention_tokens = [
        "expected_convention",
        "all_conventions_match_expected",
        "convention_mismatch_count_matched",
    ]
    for token in raw_expected_convention_tokens:
        assert token in table_loader_source
        assert token in report_schema
        assert token in remaining_plan

    imgui_row_boolean_tokens = [
        "validate_table_source_metadata_all_conventions_match_expected",
    ]
    for token in imgui_row_boolean_tokens:
        assert token in imgui_source
        assert token in report_schema
        assert token in execution_status

    imgui_root_counter_tokens = [
        "analysis_validate_table_source_metadata_all_conventions_match_expected_count",
    ]
    for token in imgui_root_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in execution_status

    non_claim_tokens = [
        "table_correctness_certified=false",
        "external_source_verified=false",
    ]
    for token in non_claim_tokens:
        assert token in report_schema
        assert token in remaining_plan

    abi_boundary_tokens = [
        "Rust C ABI 19",
        "Dear ImGui ABI 117",
    ]
    for token in abi_boundary_tokens:
        assert token in execution_status


def test_source_table_registration_summary_consistency_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    remaining_plan = (ROOT / "docs/remaining-deep-completion-plan.md").read_text(
        encoding="utf-8"
    )
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "source_table_registration_summary_consistency",
        "source_table_audit_registration_summary_consistency_available_count",
        "source_table_audit_registration_summary_consistency_matched_count",
        "source_table_audit_registration_summary_consistency_mismatch_count",
        "source_table_audit_registration_summary_consistency_status",
        "source_table_audit_registration_summary_consistency_first_mismatch",
        "registration_summary_consistency=",
    ]
    for token in source_tokens:
        assert token in imgui_source
        assert token in report_schema

    root_counter_tokens = [
        "analysis_source_table_audit_registration_summary_consistency_available_count",
        "analysis_source_table_audit_registration_summary_consistency_matched_count",
        "analysis_source_table_audit_registration_summary_consistency_mismatch_count",
        "invariant_source_table_audit_registration_summary_consistency_available_count",
        "invariant_source_table_audit_registration_summary_consistency_matched_count",
        "invariant_source_table_audit_registration_summary_consistency_mismatch_count",
    ]
    for token in root_counter_tokens:
        source_token = token.removeprefix("analysis_").removeprefix("invariant_")
        assert source_token in imgui_source
        assert token in report_schema

    mismatch_tokens = [
        "registration_summary_consistency=mismatched",
        "registration_summary_first_mismatch=count_total:blocked_count",
        "analysis_source_table_audit_registration_summary_consistency_mismatch_count",
        "invariant_source_table_audit_registration_summary_consistency_mismatch_count",
    ]
    for token in mismatch_tokens:
        assert token in native_release_docs
        assert token in reports_schema_tests
        assert token in execution_status

    legacy_fallback_tokens = [
        "test_imgui_analysis_summary_infers_source_table_registration_blockers_for_older_reports",
        "fixture_signs_not_registered",
        "registered_fixture_invariant_claim_disabled",
        "source_table_audit_registration_blocker_count_signature",
    ]
    for token in legacy_fallback_tokens:
        assert token in reports_schema_tests

    legacy_doc_tokens = [
        "Older source-table audit rows that lack the root registration blocker fields",
        "infer `registration_blockers=`",
        "source_table_audit_registration_blocker_count_signature",
        "nested diagnostics",
    ]
    for token in legacy_doc_tokens:
        assert token in report_schema

    boundary_tokens = [
        "not complete source-table coverage",
        "not signed fixture registration",
        "not native HOMFLY/Alexander computation",
    ]
    for token in boundary_tokens:
        assert token in remaining_plan


def test_source_table_alexander_source_divisibility_witness_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    io_cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )

    witness_field_tokens = [
        "source_table_alexander_source_divisibility_candidate_indices",
        "source_table_alexander_source_divisibility_first_failed_candidate_index",
        "source_table_alexander_source_divisibility_first_failed_notation",
        "source_table_alexander_source_divisibility_first_failed_input_polynomial",
    ]
    for token in witness_field_tokens:
        assert token in imgui_source
        assert token in report_schema
        assert token in native_release_docs
        assert token in io_cli_tests
        assert token in reports_schema_tests

    witness_note_tokens = [
        "candidate_indices=...",
        "first_failed_notation=...",
        "first_failed_candidate=...",
        "first_failed_input=...",
    ]
    for token in witness_note_tokens:
        assert token in report_schema

    retained_witness_tokens = [
        "source_table_alexander_source_divisibility_candidate_indices=4,5,10,11,12,13,18,19",
        "source_table_alexander_source_divisibility_first_failed_candidate_index=4",
        "source_table_alexander_source_divisibility_first_failed_notation=L5a1",
        (
            "source_table_alexander_source_divisibility_first_failed_input_polynomial="
            "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2"
        ),
    ]
    for token in retained_witness_tokens:
        assert token in native_release_docs


def test_alexander_quotient_polynomial_witness_truncation_mismatch_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "quotient_polynomial_witness_count",
        "quotient_polynomial_witness_truncated",
        "quotient_polynomial_witness_consistency",
        "first_quotient_polynomial_witness",
    ]
    for token in source_tokens:
        assert token in imgui_source
        assert token in report_schema

    test_tokens = [
        (
            "test_imgui_payloads_preserve_quotient_polynomial_"
            "witness_truncation_mismatch"
        ),
        "quotient_polynomial_witness_count=3",
        "quotient_polynomial_witness_truncated=True",
        "first_quotient_polynomial_witness=1 - t1",
        "analysis_quotient_polynomial_witness_truncated",
        "invariant_quotient_polynomial_witness_truncated",
    ]
    for token in test_tokens:
        assert token in reports_schema_tests

    doc_tokens = [
        "Synthetic stale witness",
        "quotient_polynomial_witness_count=3",
        "quotient_polynomial_witness_truncated=True",
        "first_quotient_polynomial_witness=1 - t1",
        "analysis_quotient_polynomial_witness_truncated=1",
        "invariant_quotient_polynomial_witness_truncated=1",
        "bounded quotient-witness drift evidence",
        "full_admissible_minor_normalization",
        "Rust C ABI 19 / Dear ImGui ABI 117",
    ]
    for token in doc_tokens:
        assert token in report_schema or token in execution_status


def test_source_table_alexander_failed_candidate_witness_truncation_mismatch_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "source_table_alexander_source_divisibility_failed_candidate_witness_count",
        "source_table_alexander_source_divisibility_failed_candidate_witness_truncated",
        "failed_candidate_witness_consistency",
        "first_failed_candidate_witness",
    ]
    for token in source_tokens:
        assert token in imgui_source
        assert token in report_schema

    test_tokens = [
        (
            "test_imgui_source_table_alexander_witness_flattening_"
            "infers_truncated_stale_count"
        ),
        (
            "test_imgui_source_table_alexander_witness_flattening_"
            "defaults_legacy_reports_to_zero"
        ),
        "failed_candidate_witness_count=3",
        "failed_candidate_witness_truncated=True",
        "first_failed_candidate_witness_candidate=4",
        '"failed_candidate_witness_count=" not in summary["notes"]',
        '"first_failed_candidate_witness_" not in status["notes"]',
        (
            "analysis_source_table_alexander_source_divisibility_"
            "failed_candidate_witness_truncated"
        ),
        (
            "invariant_source_table_alexander_source_divisibility_"
            "failed_candidate_witness_truncated"
        ),
    ]
    for token in test_tokens:
        assert token in reports_schema_tests

    doc_tokens = [
        "Source-table stale witness",
        "failed_candidate_witness_count=3",
        "failed_candidate_witness_truncated=True",
        "first_failed_candidate_witness_candidate=4",
        (
            "analysis_source_table_alexander_source_divisibility_"
            "failed_candidate_witness_truncated=1"
        ),
        (
            "invariant_source_table_alexander_source_divisibility_"
            "failed_candidate_witness_truncated=1"
        ),
        "bounded source-table witness drift evidence",
        "Older source-table Alexander reports without failed-candidate witness summaries",
        "do not fabricate `failed_candidate_witness_count=`",
        "or `first_failed_candidate_witness_` notes",
        "does not register Whitehead/Borromean signed fixtures",
        "Rust C ABI 19 / Dear ImGui ABI 117",
    ]
    for token in doc_tokens:
        assert token in report_schema or token in execution_status


def test_alexander_blocker_witness_summary_consistency_mismatch_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "bounded_admissible_minor_normalization_blocker_witness_summary",
        "summary_consistency_status",
        "summary_consistency_matched",
        "blocker_witness_source_count_matched",
    ]
    for token in source_tokens:
        assert token in imgui_source
        assert token in report_schema

    test_tokens = [
        (
            "test_imgui_alexander_blocker_witness_summary_"
            "consistency_mismatch_is_host_visible"
        ),
        "summary_consistency_status=stale",
        "summary_consistency_matched=False",
        "summary_consistency_reason_count_matched=False",
        "summary_consistency_blocker_witness_source_count_matched=False",
        "analysis_admissible_minor_normalization_blocker_witness_source_missing_count",
        "invariant_admissible_minor_normalization_blocker_witness_source_missing_count",
    ]
    for token in test_tokens:
        assert token in reports_schema_tests

    doc_tokens = [
        "Synthetic stale blocker-witness summary",
        "summary_consistency_status=stale",
        "summary_consistency_matched=False",
        "summary_consistency_reason_count_matched=False",
        "summary_consistency_blocker_witness_source_count_matched=False",
        "analysis_admissible_minor_normalization_blocker_witness_source_missing_count=2",
        "invariant_admissible_minor_normalization_blocker_witness_source_missing_count=2",
        "bounded blocker-witness summary drift evidence",
        "full_admissible_minor_normalization_certified=false",
        "Rust C ABI 19 / Dear ImGui ABI 117",
    ]
    for token in doc_tokens:
        assert token in report_schema or token in execution_status


def test_alexander_wirtinger_fox_shape_and_component_count_mismatch_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "wirtinger_fox_relation_shape_count_consistency_matched_count",
        "wirtinger_fox_generator_component_count_consistency_matched_count",
        "wirtinger_relation_shape=",
        "wirtinger_generator_components=",
        "count_consistent=",
    ]
    for token in source_tokens:
        assert token in imgui_source
        assert token in report_schema

    test_tokens = [
        "test_imgui_payloads_preserve_wirtinger_relation_shape_consistency_mismatch",
        "wirtinger_relation_shape=valid=False",
        "invalid=2; ",
        "witnesses=1; count_consistent=False",
        "wirtinger_generator_components=coverage_complete=False",
        "rows=2; total_generators=2; ",
        "count_consistent=False",
        "analysis_wirtinger_fox_relation_shape_count_consistency_matched_count",
        "invariant_wirtinger_fox_generator_component_count_consistency_matched_count",
    ]
    for token in test_tokens:
        assert token in reports_schema_tests

    doc_tokens = [
        "Synthetic stale Wirtinger/Fox relation-shape",
        "wirtinger_relation_shape=valid=False",
        "invalid=2; witnesses=1; count_consistent=False",
        "wirtinger_generator_components=coverage_complete=False",
        "rows=2; total_generators=2; count_consistent=False",
        "analysis_wirtinger_fox_relation_shape_count_consistency_matched_count=0",
        (
            "invariant_wirtinger_fox_generator_component_count_consistency_"
            "matched_count=0"
        ),
        "reviewer drift evidence",
        "full Alexander normalization",
        "Rust C ABI 19 / Dear ImGui ABI 117",
    ]
    for token in doc_tokens:
        assert token in report_schema or token in execution_status


def test_alexander_fox_minor_invalid_witness_truncation_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "fox_minor_invalid_witnesses=",
        "reference_truncated=",
        "normalization_truncated=",
        "first_invalid_normalization_minor=",
        "fox_square_minor_invalid_reference_witness_truncated",
        "invalid_minor_reference_witness_truncated",
    ]
    for token in source_tokens:
        assert token in imgui_source
        assert token in report_schema

    test_tokens = [
        (
            "test_imgui_payloads_preserve_alexander_fox_minor_"
            "invalid_witness_truncation"
        ),
        "fox_minor_invalid_witnesses=reference=2/1",
        "reference_truncated=True",
        "normalization=1/1",
        "normalization_truncated=True",
        "first_invalid_normalization_minor=1",
    ]
    for token in test_tokens:
        assert token in reports_schema_tests

    doc_tokens = [
        "Synthetic stale Fox-minor invalid-witness truncation",
        (
            "fox_minor_invalid_witnesses=reference=2/1; "
            "reference_truncated=True; normalization=1/1; "
            "normalization_truncated=True"
        ),
        "first_invalid_normalization_minor=1",
        "bounded Wirtinger/Fox invalid-witness drift evidence",
        "full Alexander normalization",
        "Rust C ABI 19 / Dear ImGui ABI 117",
    ]
    for token in doc_tokens:
        assert token in report_schema or token in execution_status


def test_imgui_source_open_request_contract_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "imgui_source_open_request_smoke",
        "imgui_source_open_request_smoke_host_action",
        "imgui_source_open_request_smoke_selected_fixture_name",
        "imgui_source_open_request_smoke_selected_fixture_source",
        "imgui_source_open_request_smoke_source_url",
        "imgui_source_open_request_smoke_consumed_source_url",
        "imgui_source_open_request_smoke_consumed_source_url_matched",
        "not production platform URL-opening evidence",
    ]
    for token in source_tokens:
        assert token in imgui_source
        assert token in report_schema
        assert token in native_release_docs
    assert "host_polled_source_open_request_contract" in report_schema
    assert "host_polled_source_open_request_contract" in native_release_docs

    documented_note_tokens = [
        "host_action=open_source_url",
        "opened_by_real_host=false",
        "scheme_allowed=true",
        "request_cleared_after_consumption=true",
        "final_request_pending=true",
        "not production platform URL-opening evidence",
        "imgui_source_open_request_smoke_selected_fixture_name=3_1",
        "imgui_source_open_request_smoke_selected_fixture_source=Knot Atlas",
        "imgui_source_open_request_smoke_source_url=https://katlas.org/wiki/3_1",
        "imgui_source_open_request_smoke_consumed_source_url_matched=true",
    ]
    for token in documented_note_tokens:
        assert token in report_schema

    documented_retained_tokens = [
        "host_action=open_source_url",
        "opened_by_real_host=false",
        "not production platform URL-opening evidence",
        "imgui_source_open_request_smoke_selected_fixture_name=3_1",
        "imgui_source_open_request_smoke_selected_fixture_source=Knot Atlas",
        "imgui_source_open_request_smoke_source_url=https://katlas.org/wiki/3_1",
        "imgui_source_open_request_smoke_consumed_source_url_matched=true",
    ]
    for token in documented_retained_tokens:
        assert token in native_release_docs

    host_counter_tokens = [
        "analysis_imgui_source_open_request_smoke_artifact_count",
        "analysis_imgui_source_open_request_smoke_passed_count",
        "analysis_imgui_source_open_request_smoke_opened_by_real_host_count",
        "analysis_imgui_source_open_request_smoke_request_consumed_count",
        "analysis_imgui_source_open_request_smoke_scheme_allowed_count",
        "analysis_imgui_source_open_request_smoke_request_cleared_count",
        "analysis_imgui_source_open_request_smoke_final_pending_count",
        "analysis_imgui_source_open_request_smoke_source_url_length_total",
    ]
    for token in host_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    pinned_ci_tokens = [
        "analysis_imgui_source_open_request_smoke_scheme_allowed_count=1",
        "analysis_imgui_source_open_request_smoke_request_cleared_count=1",
        "analysis_imgui_source_open_request_smoke_final_pending_count=1",
        "analysis_imgui_source_open_request_smoke_source_url_length_total=27",
    ]
    for token in pinned_ci_tokens:
        assert token in native_release_docs


def test_imgui_source_open_request_length_witness_tokens_are_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")
    native_contract_tests = (
        ROOT / "tests/test_native_embedding_contracts.py"
    ).read_text(encoding="utf-8")

    raw_length_tokens = [
        "selected_fixture_source_url_length",
        "requested_fixture_source_url_length",
    ]
    for token in raw_length_tokens:
        assert token in imgui_source
        assert token in report_schema
        assert token in reports_schema_tests
        assert token in cli_tests
        assert token in native_contract_tests

    analysis_length_tokens = [
        "analysis_imgui_source_open_request_smoke_source_url_length_total",
        (
            "analysis_imgui_source_open_request_smoke_"
            "selected_source_url_length_total"
        ),
        (
            "analysis_imgui_source_open_request_smoke_"
            "requested_source_url_length_total"
        ),
    ]
    for token in analysis_length_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    pinned_length_tokens = [
        "analysis_imgui_source_open_request_smoke_source_url_length_total=27",
        (
            "analysis_imgui_source_open_request_smoke_"
            "selected_source_url_length_total=27"
        ),
        (
            "analysis_imgui_source_open_request_smoke_"
            "requested_source_url_length_total=27"
        ),
    ]
    for token in pinned_length_tokens:
        assert token in native_release_docs

    behavior_tokens = [
        "test_imgui_analysis_summary_wraps_imgui_source_open_request_smoke_artifact",
        "test_cli_imgui_analysis_payload_accepts_imgui_source_open_request_smoke_artifact",
        "test_native_release_ci_workflow_covers_wheel_parity_and_optional_gpu",
    ]
    assert behavior_tokens[0] in reports_schema_tests
    assert behavior_tokens[1] in cli_tests
    assert behavior_tokens[2] in native_contract_tests


def test_imgui_signed_pd_snapshot_contract_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "imgui_signed_pd_snapshot",
        "host_exported_imgui_signed_pd_snapshot_shape",
        "imgui_signed_pd_snapshot_validation=",
        "signed_pd_revision=",
        "imgui_signed_pd_snapshot_artifact_count",
        "imgui_signed_pd_snapshot_valid_count",
        "imgui_signed_pd_snapshot_validation_available_count",
        "imgui_signed_pd_snapshot_component_count_matches_count",
        "imgui_signed_pd_snapshot_explicit_role_order_count_total",
        "imgui_signed_pd_snapshot_invalid_flow_label_count_total",
        "invariant computation evidence",
    ]
    for token in source_tokens:
        assert token in imgui_source
        assert token in report_schema

    root_counter_tokens = [
        "analysis_imgui_signed_pd_snapshot_artifact_count",
        "analysis_imgui_signed_pd_snapshot_valid_count",
        "analysis_imgui_signed_pd_snapshot_validation_available_count",
        "analysis_imgui_signed_pd_snapshot_component_count_matches_count",
        "analysis_imgui_signed_pd_snapshot_explicit_role_order_count_total",
        "analysis_imgui_signed_pd_snapshot_invalid_flow_label_count_total",
    ]
    for token in root_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    pinned_ci_tokens = [
        "signed_pd_revision=42",
        "source_signed_pd_revision=42",
        "analysis_imgui_signed_pd_snapshot_artifact_count=1",
        "not invariant computation",
    ]
    for token in pinned_ci_tokens:
        assert token in native_release_docs


def test_imgui_signed_pd_snapshot_counter_family_tokens_are_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    native_workflow = (
        ROOT / ".github/workflows/native-kernels-ci.yml"
    ).read_text(encoding="utf-8")
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    counter_tokens = [
        "analysis_imgui_signed_pd_snapshot_revision_present_count",
        "analysis_imgui_signed_pd_snapshot_crossing_count_total",
        "analysis_imgui_signed_pd_snapshot_component_count_total",
        "analysis_imgui_signed_pd_snapshot_validation_component_count_total",
        "analysis_imgui_signed_pd_snapshot_edge_label_slot_count_total",
        "analysis_imgui_signed_pd_snapshot_unique_edge_label_count_total",
        "analysis_imgui_signed_pd_snapshot_nonpositive_edge_label_count_total",
        (
            "analysis_imgui_signed_pd_snapshot_"
            "unexpected_occurrence_label_count_total"
        ),
        "analysis_imgui_signed_pd_snapshot_invalid_role_order_count_total",
        "analysis_imgui_signed_pd_snapshot_oriented_component_count_total",
    ]
    for token in counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs
        assert token in native_workflow

    pinned_counter_tokens = [
        "analysis_imgui_signed_pd_snapshot_revision_present_count=1",
        "analysis_imgui_signed_pd_snapshot_crossing_count_total=2",
        "analysis_imgui_signed_pd_snapshot_component_count_total=2",
        "analysis_imgui_signed_pd_snapshot_validation_component_count_total=2",
        "analysis_imgui_signed_pd_snapshot_edge_label_slot_count_total=8",
        "analysis_imgui_signed_pd_snapshot_unique_edge_label_count_total=4",
        "analysis_imgui_signed_pd_snapshot_nonpositive_edge_label_count_total=0",
        (
            "analysis_imgui_signed_pd_snapshot_"
            "unexpected_occurrence_label_count_total=0"
        ),
        "analysis_imgui_signed_pd_snapshot_invalid_role_order_count_total=0",
        "analysis_imgui_signed_pd_snapshot_oriented_component_count_total=2",
        "required_check_count=5",
        "certified=false",
    ]
    for token in pinned_counter_tokens:
        assert token in native_release_docs

    source_note_tokens = [
        "component_count=",
        "crossings=",
        "unique_edge_labels=",
        "explicit_role_orders=",
        "invalid_role_order_count=",
        "labels_with_invalid_flow_count=",
        "not invariant computation evidence",
    ]
    for token in source_note_tokens:
        assert token in imgui_source

    exact_note_tokens = [
        "component_count=...",
        "crossings=...",
        "unique_edge_labels=...",
        "explicit_role_orders=...",
        "invalid_role_order_count=0",
        "labels_with_invalid_flow_count=0",
    ]
    for token in exact_note_tokens:
        assert token in report_schema

    behavior_tokens = [
        "test_imgui_analysis_summary_wraps_imgui_signed_pd_snapshot_artifact",
        "test_cli_imgui_analysis_payload_accepts_imgui_signed_pd_snapshot_artifact",
    ]
    assert behavior_tokens[0] in reports_schema_tests
    assert behavior_tokens[1] in cli_tests


def test_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke",
        "host_owned_thread_pool_signed_pd_recompute_scheduler_contract",
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_host_reload_payload",
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_request_scope",
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_loaded_revision",
    ]
    for token in source_tokens:
        assert token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    precise_non_claim_tokens = [
        "not native HOMFLY/Alexander C++ computation evidence",
    ]
    for token in precise_non_claim_tokens:
        assert token in imgui_source
        assert token in report_schema

    native_ci_non_claim_tokens = [
        "not HOMFLY/Alexander C++ computation evidence",
    ]
    for token in native_ci_non_claim_tokens:
        assert token in native_release_docs

    exact_note_tokens = [
        "host_reload_payload=imgui-signed-pd-invariant-status-payload",
    ]
    for token in exact_note_tokens:
        assert token in report_schema
        assert token in native_release_docs

    root_counter_tokens = [
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact_count",
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_passed_count",
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "handoff_complete_count"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "worker_count_total"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "progress_completed_count"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "progress_inactive_after_completion_count"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "final_status_fresh_count"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "stale_result_count_total"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "current_result_count_total"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "final_invariant_status_count_total"
        ),
    ]
    for token in root_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    pinned_ci_tokens = [
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact_count=1",
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_passed_count=1",
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "handoff_complete_count=1"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "worker_count_total=2"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "progress_completed_count=1"
        ),
        (
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "current_request_scope=alexander"
        ),
        (
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "host_reload_payload=imgui-signed-pd-invariant-status-payload"
        ),
        (
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "current_loaded_revision=2"
        ),
    ]
    for token in pinned_ci_tokens:
        assert token in native_release_docs


def test_imgui_signed_pd_thread_pool_scheduler_lifecycle_witness_tokens_are_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    lifecycle_counter_tokens = [
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "stale_result_rejected_count"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "snapshot_hash_present_count"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "stale_request_lifecycle_complete_count"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "current_request_lifecycle_complete_count"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "thread_pool_worker_count_matched_count"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "loaded_revision_current_count"
        ),
    ]
    for token in lifecycle_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    pinned_lifecycle_tokens = [
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "stale_result_rejected_count=1"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "snapshot_hash_present_count=1"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "stale_request_lifecycle_complete_count=1"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "current_request_lifecycle_complete_count=1"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "thread_pool_worker_count_matched_count=1"
        ),
        (
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_"
            "loaded_revision_current_count=1"
        ),
    ]
    for token in pinned_lifecycle_tokens:
        assert token in native_release_docs

    behavior_tokens = [
        "test_imgui_analysis_summary_wraps_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact",
        "test_cli_imgui_analysis_payload_accepts_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact",
    ]
    assert behavior_tokens[0] in reports_schema_tests
    assert behavior_tokens[1] in cli_tests


def test_imgui_signed_pd_recompute_scheduler_smoke_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "imgui_signed_pd_recompute_scheduler_smoke",
        "host_owned_signed_pd_recompute_scheduler_contract",
        "imgui_signed_pd_recompute_scheduler_smoke_host_reload_payload",
        "imgui_signed_pd_recompute_scheduler_smoke_current_scope",
        "imgui_signed_pd_recompute_scheduler_smoke_current_request_revision",
    ]
    for token in source_tokens:
        assert token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    precise_non_claim_tokens = [
        "not native HOMFLY/Alexander C++ computation evidence",
    ]
    for token in precise_non_claim_tokens:
        assert token in imgui_source
        assert token in report_schema

    native_ci_non_claim_tokens = [
        "not HOMFLY/Alexander C++ computation evidence",
    ]
    for token in native_ci_non_claim_tokens:
        assert token in native_release_docs

    exact_note_tokens = [
        "host_reload_payload=imgui-signed-pd-invariant-status-payload",
    ]
    for token in exact_note_tokens:
        assert token in report_schema
        assert token in native_release_docs

    root_counter_tokens = [
        "analysis_imgui_signed_pd_recompute_scheduler_smoke_artifact_count",
        "analysis_imgui_signed_pd_recompute_scheduler_smoke_passed_count",
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "stale_recompute_rejected_count"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "current_revision_reloaded_count"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "requested_snapshot_cleared_count"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "handoff_complete_count"
        ),
    ]
    for token in root_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    pinned_ci_tokens = [
        "analysis_imgui_signed_pd_recompute_scheduler_smoke_artifact_count=1",
        "analysis_imgui_signed_pd_recompute_scheduler_smoke_passed_count=1",
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "stale_recompute_rejected_count=1"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "current_revision_reloaded_count=1"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "requested_snapshot_cleared_count=1"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "handoff_complete_count=1"
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_current_scope=homfly",
        (
            "imgui_signed_pd_recompute_scheduler_smoke_"
            "host_reload_payload=imgui-signed-pd-invariant-status-payload"
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_current_request_revision=2",
    ]
    for token in pinned_ci_tokens:
        assert token in native_release_docs


def test_imgui_signed_pd_recompute_scheduler_lifecycle_witness_tokens_are_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    native_workflow = (
        ROOT / ".github/workflows/native-kernels-ci.yml"
    ).read_text(encoding="utf-8")
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    lifecycle_counter_tokens = [
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "first_revision_reloaded_count"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "current_revision_rows_reloaded_count"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "host_queue_drained_count"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "stale_results_rejected_count"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "stale_error_revision_mismatch_count"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "snapshot_hash_present_count"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "final_status_fresh_count"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "first_result_count_total"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "stale_result_count_total"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "current_result_count_total"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "final_invariant_status_count_total"
        ),
    ]
    for token in lifecycle_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs
        assert token in native_workflow

    pinned_lifecycle_tokens = [
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "first_revision_reloaded_count=1"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "current_revision_rows_reloaded_count=1"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "host_queue_drained_count=1"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "stale_results_rejected_count=1"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "stale_error_revision_mismatch_count=1"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "snapshot_hash_present_count=1"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "final_status_fresh_count=1"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "first_result_count_total=2"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "stale_result_count_total=2"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "current_result_count_total=1"
        ),
        (
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_"
            "final_invariant_status_count_total=1"
        ),
    ]
    for token in pinned_lifecycle_tokens:
        assert token in native_release_docs

    source_note_tokens = [
        "host_queue_drained=",
        "final_status_fresh=",
        "first_results=",
        "stale_results=",
        "current_results=",
        "final_invariant_statuses=",
    ]
    for token in source_note_tokens:
        assert token in imgui_source

    exact_note_tokens = [
        "host_queue_drained=true",
        "final_status_fresh=true",
        "first_results=",
        "stale_results=",
        "current_results=",
        "final_invariant_statuses=",
    ]
    for token in exact_note_tokens:
        assert token in report_schema

    behavior_tokens = [
        "test_imgui_analysis_summary_wraps_imgui_signed_pd_recompute_scheduler_smoke_artifact",
        "test_cli_imgui_analysis_payload_accepts_imgui_signed_pd_recompute_scheduler_smoke_artifact",
    ]
    assert behavior_tokens[0] in reports_schema_tests
    assert behavior_tokens[1] in cli_tests


def test_imgui_framebuffer_smoke_contract_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "imgui_test_stub_framebuffer_smoke",
        "imgui_framebuffer_smoke_real_backend_verified_count",
        "imgui_framebuffer_smoke_screenshot_verified_count",
        "imgui_framebuffer_smoke_text_count",
        "not production renderer screenshot/framebuffer evidence",
    ]
    for token in source_tokens:
        assert token in imgui_source
        assert token in report_schema
        assert token in native_release_docs
    assert "repository_imgui_test_stub_draw_list_framebuffer_estimate" in report_schema
    assert "repository_imgui_test_stub_draw_list_framebuffer_estimate" in native_release_docs

    schema_counter_tokens = [
        "analysis_imgui_framebuffer_smoke_artifact_count",
        "analysis_imgui_framebuffer_smoke_passed_count",
        "analysis_imgui_framebuffer_smoke_real_backend_verified_count",
        "analysis_imgui_framebuffer_smoke_screenshot_verified_count",
        "analysis_imgui_framebuffer_smoke_render_frame_count",
        "analysis_imgui_framebuffer_smoke_geometry_nonempty_count",
        "analysis_imgui_framebuffer_smoke_text_count",
    ]
    for token in schema_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    pinned_native_counter_tokens = [
        "analysis_imgui_framebuffer_smoke_artifact_count=1",
        "analysis_imgui_framebuffer_smoke_passed_count=1",
        "analysis_imgui_framebuffer_smoke_real_backend_verified_count=0",
        "analysis_imgui_framebuffer_smoke_screenshot_verified_count=0",
        "analysis_imgui_framebuffer_smoke_render_frame_count=1",
        "analysis_imgui_framebuffer_smoke_geometry_nonempty_count=1",
        "analysis_imgui_framebuffer_smoke_text_count>=10",
    ]
    for token in pinned_native_counter_tokens:
        assert token in native_release_docs


def test_imgui_production_framebuffer_pack_contract_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")
    cli_source = (ROOT / "src/iroll/cli.py").read_text(encoding="utf-8")
    pd_fixtures = (ROOT / "src/iroll/topology/pd_fixtures.py").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "imgui_production_renderer_framebuffer_pack",
        "production_imgui_renderer_framebuffer_verification",
    ]
    for token in source_tokens:
        assert token in imgui_source
        assert token in pd_fixtures

    schema_tokens = [
        *source_tokens,
        "repository_test_stub=false",
        "draw_list_framebuffer_estimate=false",
        "production_renderer_verified=true",
        "real_graphics_backend_framebuffer_verified=true",
        "screenshot_verified=true",
        "screenshot_sha256",
        "certification_certified_count=1",
    ]
    for token in schema_tokens:
        assert token in report_schema
    assert "--production-imgui-renderer-framebuffer-pack-json" in cli_source
    assert "--production-imgui-renderer-framebuffer-pack-json" in report_schema

    behavior_tokens = [
        "test_imgui_analysis_summary_accepts_production_framebuffer_pack",
        "test_cli_imgui_analysis_payload_accepts_production_framebuffer_pack",
        "test_cli_fixture_validation_pack_audit_accepts_production_imgui_pack",
    ]
    assert behavior_tokens[0] in reports_schema_tests
    assert behavior_tokens[1] in cli_tests
    assert behavior_tokens[2] in cli_tests


def test_signed_release_publication_manifest_gate_contract_is_documented() -> None:
    cli_source = (ROOT / "src/iroll/cli.py").read_text(encoding="utf-8")
    pd_fixtures = (ROOT / "src/iroll/topology/pd_fixtures.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    pd_tests = (ROOT / "tests/test_pd_polynomials.py").read_text(
        encoding="utf-8"
    )
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    tokens = [
        "signed_release_publication_manifest",
        "signed_release_publication",
        "signed_release_artifacts_published=true",
        "publication_claimed=true",
        "platform_index_publication_claimed=true",
        "published_artifact_count",
        "signature_count",
        "package_index_url",
        "artifact_urls",
        "artifact_sha256s",
        "signature_urls",
        "signature_sha256s",
    ]
    assert "verified_signed_crossing_assignment" in cli_source
    for token in tokens[:2]:
        assert token in pd_fixtures
    for token in tokens:
        assert token in report_schema
        assert token in native_release_docs
        assert token in execution_status

    assert "--signed-release-publication-manifest-json" in cli_source
    assert "--signed-release-publication-manifest-json" in report_schema
    assert "--signed-release-publication-manifest-json" in native_release_docs
    assert (
        "test_cross_workstream_validation_pack_accepts_signed_release_manifest"
        in pd_tests
    )
    assert (
        "test_cli_fixture_validation_pack_audit_accepts_signed_release_manifest"
        in cli_tests
    )


def test_full_homfly_and_alexander_certification_pack_contracts_are_documented() -> None:
    cli_source = (ROOT / "src/iroll/cli.py").read_text(encoding="utf-8")
    pd_fixtures = (ROOT / "src/iroll/topology/pd_fixtures.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    pd_tests = (ROOT / "tests/test_pd_polynomials.py").read_text(
        encoding="utf-8"
    )
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    tokens = [
        "full_homfly_pt_evaluation_certification_pack",
        "full_homfly_pt_evaluation",
        "arbitrary_signed_pd_coverage_certified=true",
        "skein_relation_certified=true",
        "registered_fixture_regression_certified=true",
        "full_multivariable_alexander_normalization_certification_pack",
        "full_multivariable_alexander_normalization",
        "signed_pd_wirtinger_fox_certified=true",
        "admissible_minor_normalization_certified=true",
        "all_admissible_minors_consistent=true",
        "external_table_normalization_certified=true",
        "certification_report_sha256",
        "external_table_source_sha256s",
        "counterexample_count=0",
    ]
    for token in tokens[:2] + tokens[5:7]:
        assert token in cli_source
        assert token in pd_fixtures
    for token in tokens:
        assert token in report_schema
        assert token in native_release_docs
        assert token in execution_status

    assert "--full-homfly-pt-evaluation-certification-pack-json" in cli_source
    assert "--full-homfly-pt-evaluation-certification-pack-json" in report_schema
    assert (
        "--full-multivariable-alexander-normalization-certification-pack-json"
        in cli_source
    )
    assert (
        "--full-multivariable-alexander-normalization-certification-pack-json"
        in report_schema
    )
    assert "test_cross_workstream_validation_pack_accepts_full_homfly_pack" in pd_tests
    assert "test_cross_workstream_validation_pack_accepts_full_alexander_pack" in pd_tests
    assert (
        "test_cli_fixture_validation_pack_audit_accepts_full_invariant_packs"
        in cli_tests
    )


def test_verified_signed_crossing_assignment_contract_is_documented() -> None:
    cli_source = (ROOT / "src/iroll/cli.py").read_text(encoding="utf-8")
    pd_fixtures = (ROOT / "src/iroll/topology/pd_fixtures.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    pd_tests = (ROOT / "tests/test_pd_polynomials.py").read_text(
        encoding="utf-8"
    )
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    tokens = [
        "verified_signed_crossing_assignment",
        "verified_signed_crossing_assignment_pack",
        "source_gauss_code_match=true",
        "source_candidate_replay_valid=true",
        "candidate_replay_sha256",
        "unique_assignment_certified=true",
        "invariant_table_values_verified=true",
        "invariant_table_source_urls",
        "invariant_table_source_sha256s",
        "orientation_validation_issue_count=0",
        "final_completion_ready=true",
        "final_completion_blocker_count=0",
    ]
    assert "verified_signed_crossing_assignment" in cli_source
    for token in tokens[:2]:
        assert token in pd_fixtures
    for token in tokens:
        assert token in report_schema
        assert token in native_release_docs
        assert token in execution_status

    assert "--verified-signed-crossing-assignment-json" in cli_source
    assert "--verified-signed-crossing-assignment-json" in report_schema
    assert "--verified-signed-crossing-assignment-json" in native_release_docs
    assert (
        "test_cross_workstream_validation_pack_accepts_verified_signed_assignments"
        in pd_tests
    )
    assert "test_cross_workstream_validation_pack_all_strong_evidence_reaches_ready" in pd_tests
    assert (
        "test_cli_fixture_validation_pack_audit_accepts_verified_signed_assignments"
        in cli_tests
    )


def test_completion_evidence_bundle_contract_is_documented() -> None:
    cli_source = (ROOT / "src/iroll/cli.py").read_text(encoding="utf-8")
    pd_fixtures = (ROOT / "src/iroll/topology/pd_fixtures.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    tokens = [
        "cross_workstream_completion_evidence_bundle",
        "cross_workstream_final_completion_evidence",
        "cross_workstream_completion_evidence_requirements",
        "cross_workstream_final_completion_evidence_requirements",
        "cross_workstream_completion_evidence_ci_plan",
        "cross_workstream_final_completion_evidence_ci_plan",
        "cross_workstream_completion_evidence_templates",
        "cross_workstream_final_completion_evidence_templates",
        "cross_workstream_completion_evidence_directory_audit",
        "cross_workstream_final_completion_evidence_directory_audit",
        "source_evidence_directory",
        "discovered_evidence_file_count",
        "bundle_input_count",
        "bundle_repeatable_assignment_count",
        "bundle_certified_by_audit",
        "bundle_inputs_complete",
        "present_input_count",
        "missing_input_count",
        "missing_inputs",
        "discovered_inputs",
        "discovered_path_count",
        "discovered_paths",
        "artifact_validation_requested",
        "artifact_validation_performed",
        "artifact_validation_skipped_reason",
        "artifact_validation_final_completion_ready",
        "artifact_validation_final_completion_blocker_count",
        "artifact_validation_blocker_code_counts",
        "artifact_validation_failed_gate_count",
        "artifact_validation_failed_gates",
        "artifact_validation_failed_gate_signature",
        "artifact_validation_gate_checks",
        "artifact_validation_missing_artifact_count",
        "artifact_validation_missing_artifacts",
        "artifact_validation_missing_artifact_signature",
        "artifact_validation_missing_artifact_summary",
        "bundle_output_requested",
        "bundle_output_path",
        "bundle_output_written",
        "bundle_output_skipped_reason",
        "validation_output_requested",
        "validation_output_path",
        "validation_output_written",
        "validation_output_skipped_reason",
        "completion_evidence_pipeline_ready",
        "ci_fail_on_not_ready",
        "ci_exit_code",
        "pipeline_required_step_count",
        "pipeline_passed_required_step_count",
        "pipeline_step_count",
        "pipeline_steps",
        "artifact_preflight_count",
        "artifact_preflight_certified_count",
        "artifact_preflight_failed_count",
        "artifact_preflight_all_certified",
        "artifact_preflight_audits",
        "artifact_preflight_field_coverage_failed_count",
        "artifact_preflight_field_coverage_failed_rows",
            "artifact_preflight_field_coverage_complete",
            "missing_artifact_fields_by_path",
            "final_evidence_digest_witness_count",
            "final_evidence_digest_witness_invalid_fields",
            "final_evidence_digest_witness_invalid_reasons",
            "final_evidence_digest_witnesses",
            "valid_final_evidence_digest",
            "digest_missing",
            "digest_not_sha256_hex_64",
            "artifact_preflight_contract_coverage",
            "artifact_preflight_contract_coverage_complete",
        "expected_artifact_types",
        "preflight_artifact_types",
        "preflight_artifact_type_counts",
        "missing_artifact_types",
        "unexpected_artifact_types",
        "signed_assignment_preflight_count",
        "required_signed_assignment_count",
        "signed_assignment_count_matches_required",
        "coverage_complete",
        "template_placeholder_not_true",
        "required_signed_assignment_notations",
        "present_signed_assignment_notations",
        "missing_signed_assignment_notation_count",
        "missing_signed_assignment_notations",
        "signed_assignment_notation_coverage_complete",
        "completion_evidence_bundle_available",
        "completion_evidence_bundle_certified",
        "required_bundle_keys",
        "missing_bundle_keys",
        "missing_bundle_key_count",
        "invalid_bundle_fields",
        "invalid_bundle_field_count",
        "invalid_bundle_non_claim_fields",
        "invalid_bundle_non_claim_field_count",
        "bundle_completion_claimed",
        "bundle_certified_by_audit",
        "expected_artifact_preflight_row_count",
        "artifact_preflight_row_count",
        "artifact_preflight_passed_count",
        "artifact_preflight_failed_count",
        "artifact_preflight_rows",
        "artifact_preflight_failed_rows",
        "artifact_preflight_field_coverage_failed_count",
        "artifact_preflight_field_coverage_failed_rows",
        "artifact_preflight_field_coverage_complete",
        "missing_artifact_fields_by_bundle_key",
        "all_bundle_artifacts_certified",
        "bundle_contract_coverage",
        "bundle_contract_coverage_complete",
        "required_signed_assignment_notations",
        "present_signed_assignment_notations",
        "missing_signed_assignment_notation_count",
        "missing_signed_assignment_notations",
        "required_artifacts",
        "plan_steps",
        "hard_gate_commands",
        "required_missing_artifacts",
        "required_missing_artifact_signature",
        "final_blocker_count",
        "template_filename",
        "preflight_command",
        "bundle_input_example",
        "repeatable_instance_coverage_required",
        "required_instance_count",
        "required_instance_labels",
        "required_missing_artifacts",
        "required_missing_artifact_signature",
        "template_instance_label",
        "producer_readiness_available",
        "producer_readiness_count",
        "producer_readiness_ready_count",
        "producer_readiness_blockers",
        "producer_readiness",
        "completion_evidence_artifact_producer_readiness",
        "real_graphics_backend_framebuffer_verified",
        "graphics_backend_name",
        "framebuffer_width",
        "framebuffer_height",
        "screenshot_url",
        "signed_release_artifacts_published",
        "artifact_urls",
        "signature_urls",
        "arbitrary_signed_pd_coverage_certified",
        "certification_report_url",
        "external_table_source_urls",
        "admissible_minor_normalization_certified",
        "templates",
        "template_placeholder",
        "template_directory",
        "template_file_count",
        "template_filename",
        "template_path",
        "template_written",
        "repeatable_expanded",
        "expanded_repeatable_template_count",
        "expanded_repeatable",
        "blocker_label",
        "producer_readiness_all_ready",
        "producer_readiness_blocker_count",
        "producer_readiness_blocker_signature",
        "producer_cli_argument",
        "audit_cli_argument",
        "expected_artifact_kind",
        "expected_claim_scope",
        "verified_signed_crossing_assignments",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
    ]
    for token in tokens:
        assert token in cli_source or token in pd_fixtures
        assert token in report_schema
        assert token in native_release_docs
        assert token in execution_status

    assert "--completion-evidence-bundle-json" in cli_source
    assert "--completion-evidence-bundle-json" in report_schema
    assert "--completion-evidence-bundle-json" in native_release_docs
    assert "--evidence-directory" in cli_source
    assert "--evidence-directory DIR" in report_schema
    assert "--evidence-directory DIR" in native_release_docs
    assert "--evidence-directory DIR" in execution_status
    assert "completion-evidence-bundle" in cli_source
    assert "completion-evidence-bundle" in report_schema
    assert "completion-evidence-bundle" in native_release_docs
    assert "completion-evidence-bundle" in execution_status
    assert "completion-evidence-directory-audit" in cli_source
    assert "completion-evidence-directory-audit" in report_schema
    assert "completion-evidence-directory-audit" in native_release_docs
    assert "completion-evidence-directory-audit" in execution_status
    assert "--validate-artifacts" in cli_source
    assert "--validate-artifacts" in report_schema
    assert "--validate-artifacts" in native_release_docs
    assert "--validate-artifacts" in execution_status
    assert "--bundle-output" in cli_source
    assert "--bundle-output <path>" in report_schema
    assert "--bundle-output <path>" in native_release_docs
    assert "--bundle-output <path>" in execution_status
    assert "--validation-output" in cli_source
    assert "--validation-output <path>" in report_schema
    assert "--validation-output <path>" in native_release_docs
    assert "--validation-output <path>" in execution_status
    assert "--fail-on-not-ready" in cli_source
    assert "--fail-on-not-ready" in report_schema
    assert "--fail-on-not-ready" in native_release_docs
    assert "--fail-on-not-ready" in execution_status
    assert "completion-evidence-requirements" in cli_source
    assert "completion-evidence-requirements" in report_schema
    assert "completion-evidence-requirements" in native_release_docs
    assert "completion-evidence-requirements" in execution_status
    for token in [
        "producer_readiness_available",
        "producer_readiness_count",
        "producer_readiness_ready_count",
        "producer_readiness_all_ready",
        "producer_readiness_blocker_count",
        "producer_readiness_blockers",
        "producer_readiness_blocker_signature",
        "required_artifact_count",
        "repeatable_instance_coverage_required",
        "required_instance_count",
        "required_instance_labels",
        "required_missing_artifacts",
        "required_missing_artifact_signature",
        "screenshot_sha256_available",
        "artifact_sha256_count_matches_artifact_url_count",
        "signature_sha256_count_matches_signature_url_count",
        "certification_report_sha256_available",
        "external_table_source_sha256_count_matches_source_url_count",
        "invariant_table_source_sha256_count_matches_source_url_count",
    ]:
        assert token in cli_source
        assert token in report_schema
        assert token in native_release_docs
        assert token in execution_status
    assert "completion-evidence-contracts" in cli_source
    assert "completion-evidence-contracts" in report_schema
    assert "completion-evidence-contracts" in native_release_docs
    assert "completion-evidence-contracts" in execution_status
    for token in [
        "cross_workstream_completion_evidence_contracts",
        "cross_workstream_final_completion_evidence_contracts",
        "required_fields",
        "required_field_count",
        "field_rule_count",
        "field_rules",
        "preflight_checks",
        "preflight_check_count",
        "field_rule_preflight_links",
        "linked_field_rule_count",
        "linked_preflight_check_count",
        "linked_preflight_checks",
        "structural_preflight_check_count",
        "structural_preflight_checks",
        "accounted_preflight_check_count",
        "accounted_preflight_checks",
        "unexpected_unlinked_preflight_checks",
        "all_preflight_checks_accounted_for",
        "contract_preflight_consistency_passed",
        "contract_preflight_consistency_passed_count",
        "all_contract_preflight_consistency_passed",
        "producer_readiness_available",
        "producer_readiness_count",
        "producer_readiness_ready_count",
        "producer_readiness_all_ready",
        "producer_readiness_blocker_count",
        "producer_readiness_blockers",
        "producer_readiness_blocker_signature",
        "required_artifact_count",
        "repeatable_instance_coverage_required",
        "required_instance_count",
        "required_instance_labels",
        "required_missing_artifacts",
        "required_missing_artifact_signature",
    ]:
        assert token in cli_source
        assert token in report_schema
        assert token in native_release_docs
        assert token in execution_status
    assert "completion-evidence-ci-plan" in cli_source
    assert "completion-evidence-ci-plan" in report_schema
    assert "completion-evidence-ci-plan" in native_release_docs
    assert "completion-evidence-ci-plan" in execution_status
    for token in [
        "hard_gate_step_count",
        "hard_gate_steps",
        "expected_output_artifact_kinds",
        "ready_check_fields",
        "required_ready_field_sets",
        "required_ready_fields",
        "expected_output_artifact_kind",
        "expected_output_claim_scope",
        "ready_field",
        "producer_readiness_all_ready",
        "producer_readiness_blocker_count",
        "producer_readiness_blocker_signature",
        "repeatable_instance_coverage_required",
        "required_instance_count",
        "required_instance_labels",
        "artifact_field_coverage_complete",
        "artifact_preflight_field_coverage_complete",
        "artifact_preflight_contract_coverage_complete",
        "bundle_contract_coverage_complete",
        "completion_evidence_bundle_certified",
        "ready_when",
        "failure_mode",
    ]:
        assert token in cli_source
        assert token in report_schema
        assert token in native_release_docs
        assert token in execution_status
    assert "completion-evidence-templates" in cli_source
    assert "completion-evidence-templates" in report_schema
    assert "completion-evidence-templates" in native_release_docs
    assert "completion-evidence-templates" in execution_status
    assert "verified-signed-crossing-assignment-audit" in cli_source
    assert "verified-signed-crossing-assignment-audit" in report_schema
    assert "verified-signed-crossing-assignment-audit" in native_release_docs
    assert "verified-signed-crossing-assignment-audit" in execution_status
    assert "completion-evidence-artifact-audit" in cli_source
    assert "completion-evidence-artifact-audit" in report_schema
    assert "completion-evidence-artifact-audit" in native_release_docs
    assert "completion-evidence-artifact-audit" in execution_status
    assert "--artifact-type" in cli_source
    assert "--artifact-type" in report_schema
    assert "--artifact-type" in native_release_docs
    assert "--artifact-type" in execution_status
    assert "--fail-on-not-certified" in cli_source
    assert "--fail-on-not-certified" in report_schema
    assert "--fail-on-not-certified" in native_release_docs
    assert "--fail-on-not-certified" in execution_status
    for token in [
        "verified_signed_crossing_assignment_audit",
        "verified_signed_crossing_assignment_preflight",
        "assignment_available",
        "assignment_certified",
        "assignment_evidence",
        "completion_evidence_artifact_audit",
        "completion_evidence_artifact_preflight",
        "audited_artifact_type",
        "audited_artifact_kind",
        "artifact_available",
        "artifact_certified",
        "required_artifact_field_count",
        "required_artifact_fields",
        "missing_artifact_field_count",
        "missing_artifact_fields",
        "artifact_field_coverage_complete",
        "artifact_evidence",
        "ci_fail_on_not_certified",
    ]:
        assert token in cli_source or token in pd_fixtures
        assert token in report_schema
        assert token in native_release_docs
        assert token in execution_status
    assert "--directory" in cli_source
    assert "--directory DIR" in report_schema
    assert "--directory DIR" in native_release_docs
    assert "--directory DIR" in execution_status
    assert "--expand-repeatable" in cli_source
    assert "--expand-repeatable" in report_schema
    assert "--expand-repeatable" in native_release_docs
    assert "--expand-repeatable" in execution_status
    assert (
        "test_cli_fixture_validation_pack_audit_accepts_completion_evidence_bundle"
        in cli_tests
    )
    assert (
        "test_cli_fixture_validation_pack_audit_can_fail_ci_when_not_ready"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_bundle_builds_auditable_bundle"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_bundle_requires_both_signed_assignments"
        in cli_tests
    )
    assert (
        "test_cli_fixture_validation_pack_audit_rejects_self_certifying_bundle"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_artifact_audit_rejects_template_placeholder"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_bundle_discovers_evidence_directory"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_directory_audit_reports_complete_directory"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_directory_audit_validates_complete_directory"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_directory_audit_requires_both_signed_assignments"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_directory_audit_explains_invalid_complete_directory"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_directory_audit_can_fail_ci_when_not_ready"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_directory_audit_writes_bundle_output"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_directory_audit_writes_validation_output"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_directory_audit_reports_missing_inputs"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_directory_audit_skips_validation_when_incomplete"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_directory_audit_skips_bundle_output_when_incomplete"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_directory_audit_skips_validation_output_when_incomplete"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_requirements_lists_current_missing_artifacts"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_ci_plan_lists_hard_gate_commands"
        in cli_tests
    )
    assert (
        "test_cli_fixture_validation_pack_audit_explains_incomplete_bundle"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_templates_emit_non_certified_placeholders"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_templates_writes_template_files"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_templates_expands_repeatable_files"
        in cli_tests
    )
    assert (
        "test_cli_completion_evidence_templates_do_not_close_audit_gates"
        in cli_tests
    )
    assert "_write_completion_evidence_bundle" in cli_tests


def test_imgui_framebuffer_smoke_geometry_detail_counts_are_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")
    native_contract_tests = (
        ROOT / "tests/test_native_embedding_contracts.py"
    ).read_text(encoding="utf-8")

    raw_geometry_tokens = [
        "last_render_geometry_canvas_count",
        "last_render_geometry_filled_rect_count",
        "last_render_geometry_rect_count",
        "last_render_geometry_polyline_count",
        "last_render_geometry_marker_count",
        "estimated_nonzero_pixels",
    ]
    for token in raw_geometry_tokens:
        assert token in imgui_source
        assert token in native_contract_tests

    analysis_geometry_tokens = [
        "analysis_imgui_framebuffer_smoke_geometry_canvas_count",
        "analysis_imgui_framebuffer_smoke_geometry_filled_rect_count",
        "analysis_imgui_framebuffer_smoke_geometry_rect_count",
        "analysis_imgui_framebuffer_smoke_geometry_polyline_count",
        "analysis_imgui_framebuffer_smoke_geometry_marker_count",
        "analysis_imgui_framebuffer_smoke_estimated_nonzero_pixel_count",
    ]
    for token in analysis_geometry_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs or token in reports_schema_tests

    pinned_geometry_tokens = [
        "analysis_imgui_framebuffer_smoke_geometry_canvas_count=2",
        "analysis_imgui_framebuffer_smoke_geometry_filled_rect_count=2",
        "analysis_imgui_framebuffer_smoke_geometry_rect_count=2",
        "analysis_imgui_framebuffer_smoke_geometry_polyline_count>=4",
        "analysis_imgui_framebuffer_smoke_geometry_marker_count>=2",
    ]
    for token in pinned_geometry_tokens:
        assert token in report_schema
        assert token in native_release_docs

    behavior_tokens = [
        "test_imgui_analysis_summary_wraps_imgui_framebuffer_smoke_artifact",
        "test_cli_imgui_analysis_payload_accepts_imgui_framebuffer_smoke_artifact",
        "test_native_release_ci_workflow_covers_wheel_parity_and_optional_gpu",
    ]
    assert behavior_tokens[0] in reports_schema_tests
    assert behavior_tokens[1] in cli_tests
    assert behavior_tokens[2] in native_contract_tests


def test_imgui_real_kernel_loader_smoke_contract_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "imgui_real_kernel_loader_smoke",
        "imgui_real_kernel_loader_smoke_artifact_count",
        "imgui_real_kernel_loader_smoke_passed_count",
        "imgui_real_kernel_loader_smoke_dynamic_library_loaded_count",
        "imgui_real_kernel_loader_smoke_callback_thread_pool_completed_count",
        "imgui_real_kernel_loader_smoke_non_claim_false_count",
        "imgui_real_kernel_loader_smoke_python_file_recompute_boundary",
        "native_homfly_cpp_computation_claimed=false",
        "native_alexander_cpp_computation_claimed=false",
    ]
    for token in source_tokens:
        assert token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    host_counter_tokens = [
        "analysis_imgui_real_kernel_loader_smoke_artifact_count",
        "analysis_imgui_real_kernel_loader_smoke_passed_count",
        "analysis_imgui_real_kernel_loader_smoke_dynamic_library_loaded_count",
        (
            "analysis_imgui_real_kernel_loader_smoke_"
            "callback_thread_pool_completed_count"
        ),
        "analysis_imgui_real_kernel_loader_smoke_non_claim_false_count",
    ]
    for token in host_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    pinned_native_tokens = [
        "analysis_imgui_real_kernel_loader_smoke_artifact_count=1",
        "analysis_imgui_real_kernel_loader_smoke_passed_count=1",
        "analysis_imgui_real_kernel_loader_smoke_dynamic_library_loaded_count=1",
        (
            "analysis_imgui_real_kernel_loader_smoke_"
            "callback_thread_pool_completed_count=1"
        ),
        "analysis_imgui_real_kernel_loader_smoke_non_claim_false_count=5",
        "python_file_recompute_boundary=true",
    ]
    for token in pinned_native_tokens:
        assert token in native_release_docs


def test_imgui_real_kernel_loader_smoke_metadata_witness_counts_are_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")
    native_contract_tests = (
        ROOT / "tests/test_native_embedding_contracts.py"
    ).read_text(encoding="utf-8")

    root_counter_tokens = [
        (
            "analysis_imgui_real_kernel_loader_smoke_"
            "backend_report_byte_count_total"
        ),
        (
            "analysis_imgui_real_kernel_loader_smoke_"
            "invariant_handles_report_byte_count_total"
        ),
        (
            "analysis_imgui_real_kernel_loader_smoke_"
            "required_metadata_field_count_total"
        ),
        (
            "analysis_imgui_real_kernel_loader_smoke_"
            "required_metadata_fields_present_count"
        ),
        (
            "analysis_imgui_real_kernel_loader_smoke_"
            "readiness_provenance_present_count"
        ),
        (
            "analysis_imgui_real_kernel_loader_smoke_"
            "native_homfly_cpp_computation_claimed_count"
        ),
        (
            "analysis_imgui_real_kernel_loader_smoke_"
            "native_alexander_cpp_computation_claimed_count"
        ),
    ]
    for token in root_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    row_witness_tokens = [
        "imgui_real_kernel_loader_smoke_metadata_schema_version",
        "imgui_real_kernel_loader_smoke_metadata_contract_version",
        "imgui_real_kernel_loader_smoke_required_metadata_fields_present",
        "imgui_real_kernel_loader_smoke_readiness_provenance_present",
        "imgui_real_kernel_loader_smoke_ready_for_native_result_handles",
        "imgui_real_kernel_loader_smoke_readiness_blocked_by_required_gates",
        "backend_report_bytes",
        "required_metadata_field_count=30",
        "required_metadata_fields_present=true",
    ]
    for token in row_witness_tokens:
        assert token in imgui_source or token in native_contract_tests
        assert token in report_schema or token in native_release_docs

    pinned_native_tokens = [
        (
            "analysis_imgui_real_kernel_loader_smoke_"
            "backend_report_byte_count_total=4096"
        ),
        (
            "analysis_imgui_real_kernel_loader_smoke_"
            "invariant_handles_report_byte_count_total=2048"
        ),
        (
            "analysis_imgui_real_kernel_loader_smoke_"
            "required_metadata_field_count_total=30"
        ),
        (
            "analysis_imgui_real_kernel_loader_smoke_"
            "required_metadata_fields_present_count=1"
        ),
        (
            "analysis_imgui_real_kernel_loader_smoke_"
            "readiness_provenance_present_count=1"
        ),
        (
            "analysis_imgui_real_kernel_loader_smoke_"
            "native_homfly_cpp_computation_claimed_count=0"
        ),
        (
            "analysis_imgui_real_kernel_loader_smoke_"
            "native_alexander_cpp_computation_claimed_count=0"
        ),
    ]
    for token in pinned_native_tokens:
        assert token in native_release_docs

    behavior_tokens = [
        "test_imgui_analysis_summary_wraps_imgui_real_kernel_loader_smoke_artifact",
        "test_imgui_kernel_backend_status_preserves_readiness_provenance_mismatch",
        "test_cli_imgui_analysis_payload_accepts_imgui_real_kernel_loader_smoke_artifact",
        "test_native_release_ci_workflow_covers_wheel_parity_and_optional_gpu",
    ]
    assert behavior_tokens[0] in reports_schema_tests
    assert behavior_tokens[1] in reports_schema_tests
    assert behavior_tokens[2] in cli_tests
    assert behavior_tokens[3] in native_contract_tests

    mismatch_note_tokens = [
        "unsupported_rows=1",
        "per_invariant_links=1",
        "gate_blocker_links=5",
        "blocked_by_required_gates=false",
        "native_non_claim=false",
    ]
    for token in mismatch_note_tokens:
        assert token in reports_schema_tests
        assert token in report_schema
        assert token in execution_status

    mismatch_counter_tokens = [
        (
            "kernel_backend_invariant_result_handles_"
            "readiness_blocked_by_required_gates_count"
        ),
    ]
    for token in mismatch_counter_tokens:
        assert token in reports_schema_tests
        assert token in execution_status


def test_homfly_reduction_contribution_consistency_mismatch_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "consistency_matched=",
        "consistency_mismatch_count=",
        "first_mismatch={mismatch_kind}:{mismatch_field}",
        "homfly_reduction_contribution_consistency_mismatch_count",
    ]
    for token in source_tokens:
        assert token in imgui_source

    test_tokens = [
        (
            "test_imgui_analysis_summary_preserves_homfly_reduction_"
            "contribution_consistency_mismatch"
        ),
        "homfly_reduction_contribution_consistency_mismatch_count",
        "consistency_matched=False",
        "consistency_mismatch_count=2",
        "first_mismatch=reduction_contribution_witness_count:",
        "reduction_contribution_witness_count",
    ]
    for token in test_tokens:
        assert token in reports_schema_tests

    doc_tokens = [
        "Synthetic stale witness-accounting",
        "homfly_reduction_contribution_consistency_mismatch_count=2",
        "consistency_matched=False",
        "consistency_mismatch_count=2",
        (
            "first_mismatch=reduction_contribution_witness_count:"
            "reduction_contribution_witness_count"
        ),
        "Rust C ABI 19 / Dear ImGui ABI 117",
    ]
    for token in doc_tokens:
        assert token in report_schema or token in execution_status


def test_rust_wheel_retained_manifest_contract_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "rust_wheel_retained_metadata_manifest",
        "unsigned_ci_rust_wheel_artifact_index",
        "rust_wheel_retained_manifest_abi_matched_count",
        "rust_wheel_retained_manifest_wheel_count_total",
        "rust_wheel_retained_manifest_wheel_file_count_total",
        "rust_wheel_retained_manifest_wheel_count_matched_count",
        "rust_wheel_retained_manifest_unsigned_ci_artifact_count",
        "rust_wheel_retained_manifest_non_claim_false_count",
        "rust_wheel_retained_manifest_non_claim_evidence_index_entry_count_total",
        "release_non_claim_consistency=",
        "non_claim_evidence_index_entries=",
        "not signed release publication",
        "native HOMFLY/Alexander computation evidence",
    ]
    for token in source_tokens:
        assert token in imgui_source

    doc_tokens = [
        "rust_wheel_retained_metadata_manifest",
        "unsigned_ci_rust_wheel_artifact_index",
        "unsigned wheel CI artifact",
        "not signed release publication",
        "native HOMFLY/Alexander computation evidence",
        "release_non_claim_consistency=flags=6; false=6; all_false=true",
        "non_claim_evidence_index_entries=6",
    ]
    for token in doc_tokens:
        assert token in report_schema
        assert token in native_release_docs

    documented_counter_tokens = [
        "analysis_rust_wheel_retained_manifest_artifact_count",
        "analysis_rust_wheel_retained_manifest_abi_matched_count",
        "analysis_rust_wheel_retained_manifest_wheel_count_total",
        "analysis_rust_wheel_retained_manifest_wheel_file_count_total",
        "analysis_rust_wheel_retained_manifest_wheel_count_matched_count",
        "analysis_rust_wheel_retained_manifest_unsigned_ci_artifact_count",
        "analysis_rust_wheel_retained_manifest_non_claim_false_count",
        (
            "analysis_rust_wheel_retained_manifest_"
            "non_claim_evidence_index_entry_count_total"
        ),
    ]
    for token in documented_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_rust_wheel_"
            "release_non_claim_consistency_mismatch"
        ),
        "release_non_claim_consistency=flags=6; false=5; all_false=false",
    ]
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    assert mismatch_tokens[0] in reports_schema_tests
    for token in mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        assert token in reports_schema_tests


def test_rust_wheel_retained_manifest_non_claim_counters_are_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")
    native_contract_tests = (
        ROOT / "tests/test_native_embedding_contracts.py"
    ).read_text(encoding="utf-8")

    non_claim_counter_tokens = [
        (
            "analysis_rust_wheel_retained_manifest_"
            "signed_release_artifacts_published_count"
        ),
        "analysis_rust_wheel_retained_manifest_publication_claimed_count",
        (
            "analysis_rust_wheel_retained_manifest_"
            "platform_index_publication_claimed_count"
        ),
        "analysis_rust_wheel_retained_manifest_release_grade_speedup_claimed_count",
        (
            "analysis_rust_wheel_retained_manifest_"
            "native_homfly_cpp_computation_claimed_count"
        ),
        (
            "analysis_rust_wheel_retained_manifest_"
            "native_alexander_cpp_computation_claimed_count"
        ),
    ]
    for token in non_claim_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    pinned_non_claim_tokens = [
        (
            "analysis_rust_wheel_retained_manifest_"
            "signed_release_artifacts_published_count=0"
        ),
        "analysis_rust_wheel_retained_manifest_publication_claimed_count=0",
        (
            "analysis_rust_wheel_retained_manifest_"
            "platform_index_publication_claimed_count=0"
        ),
        "analysis_rust_wheel_retained_manifest_release_grade_speedup_claimed_count=0",
        (
            "analysis_rust_wheel_retained_manifest_"
            "native_homfly_cpp_computation_claimed_count=0"
        ),
        (
            "analysis_rust_wheel_retained_manifest_"
            "native_alexander_cpp_computation_claimed_count=0"
        ),
    ]
    for token in pinned_non_claim_tokens:
        assert token in native_release_docs

    behavior_tokens = [
        "test_imgui_analysis_summary_wraps_rust_wheel_retained_manifest",
        "test_cli_imgui_analysis_payload_accepts_rust_wheel_retained_manifest",
        "test_native_release_ci_workflow_covers_wheel_parity_and_optional_gpu",
    ]
    assert behavior_tokens[0] in reports_schema_tests
    assert behavior_tokens[1] in cli_tests
    assert behavior_tokens[2] in native_contract_tests


def test_imgui_windows_retained_artifacts_manifest_contract_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "imgui_windows_retained_artifacts_manifest",
        "windows_dear_imgui_retained_artifact_manifest",
        "imgui_windows_retained_artifacts_manifest_artifact_count",
        "imgui_windows_retained_artifacts_manifest_abi_matched_count",
        "imgui_windows_retained_artifacts_manifest_retained_json_file_count_total",
        (
            "imgui_windows_retained_artifacts_manifest_"
            "retained_json_file_reference_count_total"
        ),
        (
            "imgui_windows_retained_artifacts_manifest_"
            "unique_retained_json_file_count_total"
        ),
        (
            "imgui_windows_retained_artifacts_manifest_"
            "shared_retained_json_file_count_total"
        ),
        (
            "imgui_windows_retained_artifacts_manifest_"
            "retained_json_file_count_matched_count"
        ),
        (
            "imgui_windows_retained_artifacts_manifest_"
            "complete_raw_analysis_host_group_count_total"
        ),
        (
            "imgui_windows_retained_artifacts_manifest_"
            "invariant_status_host_group_count_total"
        ),
        (
            "imgui_windows_retained_artifacts_manifest_"
            "smoke_executed_no_retained_json_count_total"
        ),
        "imgui_windows_retained_artifacts_manifest_non_claim_false_count",
        (
            "imgui_windows_retained_artifacts_manifest_"
            "non_claim_evidence_index_entry_count_total"
        ),
        "imgui_windows_retained_artifacts_manifest_shared_files=",
        "retained_json_file_references=",
        "shared_retained_json_files=",
        "not release completion evidence",
    ]
    for token in source_tokens:
        assert token in imgui_source
        assert token in report_schema

    documented_native_tokens = [
        "artifact_kind=imgui_windows_retained_artifacts_manifest",
        "claim_scope=windows_dear_imgui_retained_artifact_manifest",
        "retained_json_file_count=22",
        "raw_analysis_host_group_count=6",
        "invariant_status_host_group_count=1",
        "smoke_executed_no_retained_json_count=0",
        "complete_raw_analysis_host",
        "invariant_status_host_only",
        "release gate completion signal",
    ]
    for token in documented_native_tokens:
        assert token in native_release_docs

    documented_counter_tokens = [
        "analysis_imgui_windows_retained_artifacts_manifest_artifact_count",
        (
            "analysis_imgui_windows_retained_artifacts_manifest_"
            "retained_json_file_reference_count_total"
        ),
        (
            "analysis_imgui_windows_retained_artifacts_manifest_"
            "unique_retained_json_file_count_total"
        ),
        (
            "analysis_imgui_windows_retained_artifacts_manifest_"
            "shared_retained_json_file_count_total"
        ),
        (
            "analysis_imgui_windows_retained_artifacts_manifest_"
            "retained_json_file_count_matched_count"
        ),
        (
            "analysis_imgui_windows_retained_artifacts_manifest_"
            "non_claim_evidence_index_entry_count_total"
        ),
    ]
    for token in documented_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    pinned_note_tokens = [
        "unique_retained_json_files=22",
        "retained_json_file_references=23",
        "shared_retained_json_files=1",
        "retained_json_file_count_matched=true",
        (
            "imgui_windows_retained_artifacts_manifest_shared_files="
            "iroll-imgui-signed-pd.json"
        ),
        "non_claim_evidence_index_entries=5",
        "production_renderer_verified=false",
        "production_scheduler_completion_claimed=false",
        "native_homfly_cpp_computation_claimed=false",
        "native_alexander_cpp_computation_claimed=false",
        "signed_release_artifacts_published=false",
    ]
    for token in pinned_note_tokens:
        assert token in report_schema
        assert token in native_release_docs

    mismatch_tokens = [
        "test_imgui_analysis_summary_preserves_imgui_windows_retained_artifacts_manifest_count_mismatch",
        "retained_json_files=23",
        "retained_json_file_references=23",
        "unique_retained_json_files=22",
        "shared_retained_json_files=1",
        "retained_json_file_count_matched=false",
        (
            "analysis_imgui_windows_retained_artifacts_manifest_"
            "retained_json_file_count_matched_count=0"
        ),
    ]
    assert mismatch_tokens[0] in reports_schema_tests
    for token in mismatch_tokens[1:]:
        assert token in report_schema
        assert token in native_release_docs
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests
    index_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_imgui_windows_"
            "retained_manifest_non_claim_index_mismatch"
        ),
        "non_claim_evidence_index_entries=4",
    ]
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    assert index_mismatch_tokens[0] in reports_schema_tests
    for token in index_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        assert token in reports_schema_tests


def test_imgui_windows_retained_artifacts_manifest_sidecar_group_totals_are_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")
    native_contract_tests = (
        ROOT / "tests/test_native_embedding_contracts.py"
    ).read_text(encoding="utf-8")

    sidecar_counter_tokens = [
        (
            "analysis_imgui_windows_retained_artifacts_manifest_"
            "complete_raw_analysis_host_group_count_total"
        ),
        (
            "analysis_imgui_windows_retained_artifacts_manifest_"
            "invariant_status_host_group_count_total"
        ),
        (
            "analysis_imgui_windows_retained_artifacts_manifest_"
            "smoke_executed_no_retained_json_count_total"
        ),
        "analysis_imgui_windows_retained_artifacts_manifest_non_claim_false_count",
    ]
    for token in sidecar_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs
        assert token in native_contract_tests

    pinned_sidecar_tokens = [
        (
            "analysis_imgui_windows_retained_artifacts_manifest_"
            "complete_raw_analysis_host_group_count_total=6"
        ),
        (
            "analysis_imgui_windows_retained_artifacts_manifest_"
            "invariant_status_host_group_count_total=1"
        ),
        (
            "analysis_imgui_windows_retained_artifacts_manifest_"
            "smoke_executed_no_retained_json_count_total=0"
        ),
        "analysis_imgui_windows_retained_artifacts_manifest_non_claim_false_count=5",
    ]
    for token in pinned_sidecar_tokens:
        assert token in native_release_docs

    workflow_exact_tokens = [
        (
            "analysis_imgui_windows_retained_artifacts_manifest_"
            "complete_raw_analysis_host_group_count_total']==6"
        ),
        (
            "analysis_imgui_windows_retained_artifacts_manifest_"
            "smoke_executed_no_retained_json_count_total']==0"
        ),
        (
            "analysis_imgui_windows_retained_artifacts_manifest_"
            "non_claim_false_count']==5"
        ),
    ]
    for token in workflow_exact_tokens:
        assert token in native_contract_tests

    behavior_tokens = [
        "test_imgui_analysis_summary_wraps_imgui_windows_retained_artifacts_manifest",
        "test_cli_imgui_analysis_payload_accepts_imgui_windows_retained_artifacts_manifest",
        "test_native_release_ci_workflow_covers_wheel_parity_and_optional_gpu",
    ]
    assert behavior_tokens[0] in reports_schema_tests
    assert behavior_tokens[1] in cli_tests
    assert behavior_tokens[2] in native_contract_tests


def test_validation_pack_retained_artifact_accounting_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )

    raw_accounting_tokens = [
        "retained_evidence_artifact_file_consistency",
        "artifact_file_reference_count",
        "unique_artifact_file_count",
        "raw_file_count",
        "analysis_file_count",
        "host_file_count",
        "complete_raw_analysis_host_group_count",
        "incomplete_artifact_group_count",
        "artifact_file_reference_count_matches_groups",
        "raw_analysis_host_file_counts_matched",
        "all_artifact_evidence_groups_complete",
        "all_artifact_files_unique",
    ]
    for token in raw_accounting_tokens:
        assert token in imgui_source
        assert token in report_schema

    source_note_fragments = [
        "retained_evidence_artifact_files=",
        "entries=",
        "artifact_entries=",
        "non_artifact=",
        "refs=",
        "unique=",
        "raw=",
        "analysis=",
        "host=",
        "complete_groups=",
        "incomplete_groups=",
        "refs_matched=",
        "file_types_matched=",
        "groups_complete=",
        "files_unique=",
        "matched=",
    ]
    for token in source_note_fragments:
        assert token in imgui_source
        assert token in report_schema
    assert "retained_evidence_artifact_files=entries=" in report_schema

    pinned_native_note_fragments = [
        "retained_evidence_artifact_files=entries=13; artifact_entries=3",
        "non_artifact=10; refs=9; unique=9",
        "raw=3; analysis=3; host=3",
        "complete_groups=3; incomplete_groups=0",
        "refs_matched=true; file_types_matched=true; groups_complete=true",
        "files_unique=true; matched=true",
    ]
    for token in pinned_native_note_fragments:
        assert token in native_release_docs

    counter_suffixes = [
        "entry_count",
        "artifact_evidence_count",
        "non_artifact_evidence_count",
        "file_reference_count",
        "unique_file_count",
        "raw_file_count",
        "analysis_file_count",
        "host_file_count",
        "complete_raw_analysis_host_group_count",
        "incomplete_group_count",
        "reference_count_matched_count",
        "file_type_counts_matched_count",
        "all_groups_complete_count",
        "all_files_unique_count",
        "matched_count",
    ]
    for suffix in counter_suffixes:
        source_token = f"retained_evidence_artifact_file_consistency_{suffix}"
        host_token = f"analysis_{source_token}"
        assert source_token in imgui_source
        assert host_token in report_schema
        assert host_token in native_release_docs

    mismatch_tokens = [
        "test_imgui_payloads_preserve_validation_pack_retained_artifact_file_consistency_mismatch",
        (
            "retained_evidence_artifact_files=entries=5; artifact_entries=3; "
            "non_artifact=2; refs=8; unique=7"
        ),
        "raw=3; analysis=2; host=3",
        "complete_groups=2; incomplete_groups=1",
        (
            "refs_matched=false; file_types_matched=false; "
            "groups_complete=false; files_unique=false; matched=false"
        ),
        "analysis_retained_evidence_artifact_file_consistency_matched_count=0",
    ]
    assert mismatch_tokens[0] in reports_schema_tests
    for token in mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        elif "retained_evidence_artifact_files=entries=5" in token:
            assert "retained_evidence_artifact_files=entries=5" in reports_schema_tests
            assert "non_artifact=2; refs=8; unique=7" in reports_schema_tests
        elif "refs_matched=false" in token:
            assert "refs_matched=false; file_types_matched=false" in reports_schema_tests
            assert "files_unique=false; matched=false" in reports_schema_tests
        else:
            assert token in reports_schema_tests


def test_validation_pack_blocker_taxonomy_accounting_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )

    raw_tokens = [
        "final_completion_blocker_code_consistency",
        "final_completion_blocker_code_summary",
        "final_completion_blocker_code_summary_detail_consistency",
        "final_completion_blocker_kind_summary",
        "final_completion_blocker_kind_consistency",
        "final_completion_blocker_kind_summary_detail_consistency",
        "blocker_code_consistency=",
        "blocker_code_summary_detail=",
        "blocker_kind_consistency=",
        "blocker_kind_summary_detail=",
    ]
    for token in raw_tokens:
        assert token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    code_detail_suffixes = [
        "row_count",
        "code_count",
        "blocker_count",
        "kind_reference_count",
        "label_reference_count",
        "missing_artifact_reference_count",
        "unique_missing_artifact_count",
        "blocker_count_matched_count",
        "kinds_matched_count",
        "labels_matched_count",
        "missing_artifacts_matched_count",
        "mismatched_count",
        "matched_count",
    ]
    for suffix in code_detail_suffixes:
        source_token = (
            "final_completion_blocker_code_summary_detail_consistency_"
            f"{suffix}"
        )
        host_token = f"analysis_{source_token}"
        assert source_token in imgui_source
        assert host_token in report_schema
        assert host_token in native_release_docs

    kind_counter_tokens = [
        "analysis_final_completion_blocker_kind_summary_row_count",
        "analysis_final_completion_blocker_kind_summary_blocker_count",
        "analysis_final_completion_blocker_kind_signed_fixture_count",
        "analysis_final_completion_blocker_kind_non_diagram_requirement_count",
        "analysis_final_completion_blocker_kind_completion_gate_count",
        "analysis_final_completion_blocker_kind_consistency_blocker_count",
        "analysis_final_completion_blocker_kind_consistency_kind_count",
        "analysis_final_completion_blocker_kind_consistency_kind_total",
        "analysis_final_completion_blocker_kind_consistency_total_matched_count",
        "analysis_final_completion_blocker_kind_consistency_unique_matched_count",
        "analysis_final_completion_blocker_kind_all_have_kind_count",
        "analysis_final_completion_blocker_kind_consistency_matched_count",
        (
            "analysis_final_completion_blocker_kind_summary_detail_consistency_"
            "row_count"
        ),
        (
            "analysis_final_completion_blocker_kind_summary_detail_consistency_"
            "kind_count"
        ),
        (
            "analysis_final_completion_blocker_kind_summary_detail_consistency_"
            "blocker_count"
        ),
        (
            "analysis_final_completion_blocker_kind_summary_detail_consistency_"
            "code_reference_count"
        ),
        (
            "analysis_final_completion_blocker_kind_summary_detail_consistency_"
            "missing_artifact_reference_count"
        ),
        (
            "analysis_final_completion_blocker_kind_summary_detail_consistency_"
            "unique_missing_artifact_count"
        ),
        (
            "analysis_final_completion_blocker_kind_summary_detail_consistency_"
            "blocker_count_matched_count"
        ),
        (
            "analysis_final_completion_blocker_kind_summary_detail_consistency_"
            "codes_matched_count"
        ),
        (
            "analysis_final_completion_blocker_kind_summary_detail_consistency_"
            "missing_artifacts_matched_count"
        ),
        (
            "analysis_final_completion_blocker_kind_summary_detail_consistency_"
            "mismatched_count"
        ),
        (
            "analysis_final_completion_blocker_kind_summary_detail_consistency_"
            "matched_count"
        ),
    ]
    for token in kind_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    pinned_note_tokens = [
        "blocker_code_summary_detail=rows=8; codes=8; blockers=9",
        "missing_refs=8; unique_missing=7",
        "count_matched=8; kinds_matched=8; labels_matched=8",
        "missing_artifacts_matched=8; mismatched=0; matched=true",
        "blocker_kind_consistency=kinds=3; total=9; signed=2",
        "non_diagram=3; completion=4; rows=3",
        "total_matched=true; unique_matched=true; all_have_kind=true; matched=true",
        "blocker_kind_summary_detail=rows=3; kinds=3; blockers=9",
        "codes=8; missing_refs=8; unique_missing=7",
        "count_matched=3; codes_matched=3",
        "missing_artifacts_matched=3; mismatched=0; matched=true",
    ]
    for token in pinned_note_tokens:
        assert token in native_release_docs

    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    code_consistency_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "blocker_code_consistency_mismatch"
        ),
        (
            "blocker_code_consistency=codes=7; total=8; "
            "total_matched=false; unique_matched=false; "
            "signature_matched=false; all_have_code=false; matched=false"
        ),
        (
            "analysis_final_completion_blocker_code_"
            "consistency_matched_count=0"
        ),
    ]
    assert code_consistency_mismatch_tokens[0] in reports_schema_tests
    for token in code_consistency_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    code_detail_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "blocker_code_summary_detail_mismatch"
        ),
        (
            "blocker_code_summary_detail=rows=8; codes=8; blockers=9; "
            "kinds=7; labels=8; missing_refs=7; unique_missing=6; "
            "count_matched=6; kinds_matched=5; labels_matched=4; "
            "missing_artifacts_matched=4; mismatched=2; matched=false"
        ),
        (
            "analysis_final_completion_blocker_code_summary_detail_"
            "consistency_matched_count=0"
        ),
    ]
    assert code_detail_mismatch_tokens[0] in reports_schema_tests
    for token in code_detail_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    kind_consistency_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "blocker_kind_consistency_mismatch"
        ),
        (
            "blocker_kind_consistency=kinds=3; total=8; signed=2; "
            "non_diagram=2; completion=4; rows=3; total_matched=false; "
            "unique_matched=false; all_have_kind=false; matched=false"
        ),
        (
            "analysis_final_completion_blocker_kind_"
            "consistency_matched_count=0"
        ),
    ]
    assert kind_consistency_mismatch_tokens[0] in reports_schema_tests
    for token in kind_consistency_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    kind_detail_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "blocker_kind_summary_detail_mismatch"
        ),
        (
            "blocker_kind_summary_detail=rows=3; kinds=3; blockers=9; "
            "codes=7; missing_refs=7; unique_missing=6; count_matched=2; "
            "codes_matched=1; missing_artifacts_matched=1; "
            "mismatched=2; matched=false"
        ),
        (
            "analysis_final_completion_blocker_kind_summary_detail_"
            "consistency_matched_count=0"
        ),
    ]
    assert kind_detail_mismatch_tokens[0] in reports_schema_tests
    for token in kind_detail_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    boundary_tokens = [
        "does not alter any gate state",
        "`required_check_count`, any gate result, or the native ABI",
        "without changing the open",
        "`required_check_count=3` or any final gate",
    ]
    assert boundary_tokens[0] in report_schema
    assert boundary_tokens[1] in report_schema
    assert boundary_tokens[2] in native_release_docs
    assert boundary_tokens[3] in native_release_docs


def test_validation_pack_missing_artifact_and_evidence_fields_are_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    io_cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    raw_doc_tokens = [
        "final_completion_missing_artifact_summary",
        "final_completion_missing_artifact_summary_consistency",
        "final_completion_missing_artifact_summary_detail_consistency",
        "final_completion_blocker_evidence_field_summary",
        "final_completion_blocker_evidence_field_consistency",
        "final_completion_blocker_evidence_field_summary_detail_consistency",
    ]
    for token in raw_doc_tokens:
        assert token in report_schema
        assert token in native_release_docs
        assert token in reports_schema_tests
        assert token in io_cli_tests

    raw_row_tokens = [
        "final_completion_blocker_evidence_field_rows",
    ]
    for token in raw_row_tokens:
        assert token in report_schema
        assert token in reports_schema_tests
        assert token in io_cli_tests

    note_tokens = [
        "missing_artifact_summary=",
        "missing_artifact_summary_detail=",
        "blocker_evidence_fields=",
        "blocker_evidence_field_summary_detail=",
    ]
    for token in note_tokens:
        assert token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    claim_scope_tokens = [
        "validation_pack_final_completion_missing_artifact_summary_consistency",
        (
            "validation_pack_final_completion_"
            "missing_artifact_summary_detail_consistency"
        ),
        "validation_pack_final_completion_blocker_evidence_field_consistency",
        (
            "validation_pack_final_completion_"
            "blocker_evidence_field_summary_detail_consistency"
        ),
    ]
    for token in claim_scope_tokens:
        assert token in report_schema
        assert token in native_release_docs
        assert token in io_cli_tests

    report_schema_detail_claim_scope_tokens = [
        (
            "validation_pack_final_completion_"
            "missing_artifact_summary_detail_consistency"
        ),
        (
            "validation_pack_final_completion_"
            "blocker_evidence_field_summary_detail_consistency"
        ),
    ]
    for token in report_schema_detail_claim_scope_tokens:
        assert token in reports_schema_tests

    missing_artifact_suffixes = [
        "summary_row_count",
        "summary_consistency_matched_count",
        "summary_detail_consistency_row_count",
        "summary_detail_consistency_unique_count",
        "summary_detail_consistency_blocker_count",
        "summary_detail_consistency_code_reference_count",
        "summary_detail_consistency_label_reference_count",
        "summary_detail_consistency_blocker_count_matched_count",
        "summary_detail_consistency_codes_matched_count",
        "summary_detail_consistency_labels_matched_count",
        "summary_detail_consistency_mismatched_count",
        "summary_detail_consistency_matched_count",
    ]
    for suffix in missing_artifact_suffixes:
        source_token = f"final_completion_missing_artifact_{suffix}"
        host_token = f"analysis_{source_token}"
        assert source_token in imgui_source
        assert host_token in report_schema
    assert "analysis_final_completion_missing_artifact_*" in native_release_docs
    assert (
        "analysis_final_completion_missing_artifact_summary_detail_consistency_*"
        in native_release_docs
    )

    evidence_field_suffixes = [
        "summary_row_count",
        "missing_artifact_present_count",
        "required_evidence_present_count",
        "current_evidence_present_count",
        "all_present_count",
        "consistency_matched_count",
        "summary_detail_consistency_row_count",
        "summary_detail_consistency_blocker_count",
        "summary_detail_consistency_missing_count",
        "summary_detail_consistency_required_count",
        "summary_detail_consistency_current_count",
        "summary_detail_consistency_all_present_count",
        "summary_detail_consistency_blocker_count_matched_count",
        "summary_detail_consistency_missing_matched_count",
        "summary_detail_consistency_required_matched_count",
        "summary_detail_consistency_current_matched_count",
        "summary_detail_consistency_all_present_matched_count",
        "summary_detail_consistency_mismatched_count",
        "summary_detail_consistency_matched_count",
    ]
    for suffix in evidence_field_suffixes:
        source_token = f"final_completion_blocker_evidence_field_{suffix}"
        host_token = f"analysis_{source_token}"
        assert source_token in imgui_source
        assert host_token in report_schema
    assert "analysis_final_completion_blocker_evidence_field_*" in native_release_docs
    assert (
        "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_*"
        in native_release_docs
    )

    pinned_note_tokens = [
        "missing_artifact_summary=refs=9; unique=7; rows=7",
        "refs_matched=true; rows_matched=true; matched=true",
        "missing_artifact_summary_detail=rows=7; unique=7; blockers=9",
        "codes=8; labels=9; count_matched=7",
        "codes_matched=7; labels_matched=7; mismatched=0; matched=true",
        "blocker_evidence_fields=summary_rows=3; missing_artifact=9",
        "required=9; current=9; all_present=9; matched=true",
        "blocker_evidence_field_summary_detail=rows=3; blockers=9",
        "missing_artifact=9; required=9; current=9; all_present=9",
        "count_matched=3; missing_matched=3; required_matched=3",
        "current_matched=3; all_present_matched=3; mismatched=0; matched=true",
    ]
    for token in pinned_note_tokens:
        assert token in native_release_docs

    missing_summary_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "missing_artifact_summary_consistency_mismatch"
        ),
        (
            "missing_artifact_summary=refs=8; unique=6; rows=7; "
            "refs_matched=false; rows_matched=false; matched=false"
        ),
        (
            "analysis_final_completion_missing_artifact_summary_"
            "consistency_matched_count=0"
        ),
    ]
    assert missing_summary_mismatch_tokens[0] in reports_schema_tests
    for token in missing_summary_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    mismatch_tokens = [
        "test_imgui_payloads_preserve_validation_pack_missing_artifact_summary_detail_mismatch",
        "missing_artifact_summary_detail=rows=7; unique=7; blockers=9",
        "codes=8; labels=8; count_matched=6",
        "codes_matched=5; labels_matched=4; mismatched=2; matched=false",
        (
            "analysis_final_completion_missing_artifact_summary_detail_"
            "consistency_matched_count=0"
        ),
    ]
    assert mismatch_tokens[0] in reports_schema_tests
    for token in mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    blocker_evidence_link_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "blocker_evidence_link_consistency_mismatch"
        ),
        (
            "blocker_evidence_links=linked=2; unlinked=7; evidence_refs=3; "
            "refs_matched=false; ids_matched=false; non_claim_matched=false; "
            "labels=8; codes=7; missing=6; required=5; current=4; "
            "matched=false"
        ),
        (
            "analysis_final_completion_blocker_evidence_link_"
            "consistency_matched_count=0"
        ),
    ]
    assert blocker_evidence_link_mismatch_tokens[0] in reports_schema_tests
    for token in blocker_evidence_link_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    blocker_evidence_link_kind_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "blocker_evidence_link_kind_summary_detail_mismatch"
        ),
        (
            "blocker_evidence_link_kind_detail=rows=3; blockers=9; "
            "linked=2; unlinked=7; refs=3; ids=2; non_claimed_links=8; "
            "blocker_matched=2; linked_matched=2; unlinked_matched=1; "
            "refs_matched=1; ids_matched=1; non_claim_matched=0; "
            "mismatched=2; matched=false"
        ),
        (
            "analysis_final_completion_blocker_evidence_link_kind_"
            "summary_detail_consistency_matched_count=0"
        ),
    ]
    assert blocker_evidence_link_kind_mismatch_tokens[0] in reports_schema_tests
    for token in blocker_evidence_link_kind_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    evidence_field_consistency_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "blocker_evidence_field_consistency_mismatch"
        ),
        (
            "blocker_evidence_fields=summary_rows=3; missing_artifact=8; "
            "required=7; current=6; all_present=5; matched=false"
        ),
        (
            "analysis_final_completion_blocker_evidence_field_"
            "consistency_matched_count=0"
        ),
    ]
    assert evidence_field_consistency_mismatch_tokens[0] in reports_schema_tests
    for token in evidence_field_consistency_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    open_gate_summary_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "open_gate_blocker_summary_consistency_mismatch"
        ),
        (
            "open_gate_blocker_summary=failed_gates=6; summary_gates=5; "
            "blockers=9; summary_blockers=8; gate_sets_matched=false; "
            "blocker_count_matched=false; all_blockers_have_gate=false"
        ),
    ]
    assert open_gate_summary_mismatch_tokens[0] in reports_schema_tests
    for token in open_gate_summary_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        assert token in reports_schema_tests

    open_gate_detail_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "open_gate_blocker_summary_detail_mismatch"
        ),
        (
            "open_gate_blocker_summary_detail=gates=6; blockers=9; "
            "codes=8; missing_refs=7; unique_missing=6; retained=3; "
            "count_matched=5; codes_matched=4; "
            "missing_artifacts_matched=4; retained_matched=3; "
            "mismatched=2; matched=false"
        ),
        (
            "analysis_final_completion_open_gate_blocker_summary_detail_"
            "consistency_matched_count=0"
        ),
    ]
    assert open_gate_detail_mismatch_tokens[0] in reports_schema_tests
    for token in open_gate_detail_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    evidence_field_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "blocker_evidence_field_detail_mismatch"
        ),
        "blocker_evidence_field_summary_detail=rows=3; blockers=9",
        "missing_artifact=8; required=7; current=6; all_present=5",
        "count_matched=2; missing_matched=2; required_matched=1",
        (
            "current_matched=1; all_present_matched=0; mismatched=2; "
            "matched=false"
        ),
        (
            "analysis_final_completion_blocker_evidence_field_summary_detail_"
            "consistency_matched_count=0"
        ),
    ]
    assert evidence_field_mismatch_tokens[0] in reports_schema_tests
    for token in evidence_field_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    behavior_tokens = [
        "test_imgui_analysis_summary_payload_wraps_cross_workstream_validation_pack_audit",
        "test_cli_fixture_validation_pack_audit_exports_metadata_readiness",
        "verified_signed_crossing_assignment",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
    ]
    for token in behavior_tokens:
        assert token in reports_schema_tests or token in io_cli_tests

    boundary_tokens = [
        "not a new completion gate",
        "`required_check_count`, any gate result, or the native ABI",
        "reviewer metadata only",
        "without changing any gate, ABI, or `required_check_count=3`",
    ]
    assert boundary_tokens[0] in report_schema
    assert boundary_tokens[1] in report_schema
    assert boundary_tokens[2] in native_release_docs
    assert boundary_tokens[3] in native_release_docs


def test_rust_readme_completion_artifact_non_claims_are_documented() -> None:
    rust_readme = (ROOT / "native/iroll-kernels-rust/README.md").read_text(
        encoding="utf-8"
    )
    fixture_source = (ROOT / "src/iroll/topology/pd_fixtures.py").read_text(
        encoding="utf-8"
    )
    native_contract_tests = (
        ROOT / "tests/test_native_embedding_contracts.py"
    ).read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    missing_artifact_tokens = [
        "release_grade_high_point_performance_pack",
        "signed_release_publication_manifest",
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "production_imgui_renderer_framebuffer_pack",
    ]
    for token in missing_artifact_tokens:
        assert token in rust_readme
        assert token in fixture_source
        assert token in native_contract_tests

    boundary_tokens = [
        "retained unsigned wheel manifest",
        "local benchmark matrix",
        "do not publish signed artifacts",
        "do not certify",
        "release-grade speedup",
        "do not add native HOMFLY/Alexander compute handles",
        "do not close production ImGui",
        "framebuffer verification",
    ]
    for token in boundary_tokens:
        assert token in rust_readme
        assert token in native_contract_tests

    status_tokens = [
        "native/iroll-kernels-rust/README.md",
        "release/completion gate",
        "missing-artifact",
    ]
    for token in status_tokens:
        assert token in execution_status


def test_final_completion_checklist_names_validation_pack_evidence_artifacts() -> None:
    completion_plan = (ROOT / "docs/remaining-deep-completion-plan.md").read_text(
        encoding="utf-8"
    )
    fixture_source = (ROOT / "src/iroll/topology/pd_fixtures.py").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    evidence_artifact_tokens = [
        "verified_signed_crossing_assignment",
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "broad_noisy_curve_robustness_certification_pack",
        "release_grade_high_point_performance_pack",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
    ]
    for token in evidence_artifact_tokens:
        assert token in completion_plan
        assert token in fixture_source

    boundary_tokens = [
        "Bounded generated HOMFLY/Alexander coverage",
        "repository ImGui stubs",
        "wheel manifests",
        "local benchmark matrices",
        "reviewer evidence only",
        "completed claims come from the uncapped certification packs",
    ]
    for token in boundary_tokens:
        assert token in completion_plan

    status_tokens = [
        "final_completion_ready",
        "missing-artifact",
        "completion_claimed=false",
    ]
    for token in status_tokens:
        assert token in execution_status


def test_validation_pack_required_and_signed_fixture_consistency_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    fixture_source = (ROOT / "src/iroll/topology/pd_fixtures.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    raw_tokens = [
        "final_completion_required_check_consistency",
        "required_check_consistency=",
        "final_completion_signed_fixture_consistency",
        "signed_fixture_consistency=",
    ]
    for token in raw_tokens:
        assert token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    raw_claim_scope_tokens = [
        "validation_pack_final_completion_required_check_consistency",
        "validation_pack_final_completion_signed_fixture_consistency",
    ]
    for token in raw_claim_scope_tokens:
        assert token in report_schema
        assert token in native_release_docs

    required_counter_suffixes = [
        "count",
        "passed_count",
        "failed_count",
        "mismatched_count",
        "final_ready_matched_count",
        "all_matched_count",
        "consistency_matched_count",
    ]
    for suffix in required_counter_suffixes:
        source_token = f"final_completion_required_check_{suffix}"
        host_token = f"analysis_{source_token}"
        assert source_token in imgui_source
        assert host_token in report_schema
        assert host_token in native_release_docs

    required_fixture_metadata_suffixes = [
        "required_count",
        "registered_count",
        "missing_count",
        "metadata_complete_count",
        "metadata_incomplete_count",
        "metadata_blocker_count",
        "gate_passed_count",
        "gate_blocker_count",
        "mismatched_count",
        "matched_count",
    ]
    for suffix in required_fixture_metadata_suffixes:
        source_token = (
            "final_completion_required_diagram_fixture_metadata_consistency_"
            f"{suffix}"
        )
        host_token = f"analysis_{source_token}"
        assert source_token in imgui_source
        assert host_token in report_schema
        assert host_token in native_release_docs

    signed_fixture_suffixes = [
        "blocker_count",
        "final_blocker_count",
        "mismatched_count",
        "source_url_present_count",
        "unsigned_non_claim_count",
        "source_table_metadata_count",
        "missing_artifact_matched_count",
        "evidence_fields_matched_count",
        "source_candidate_evidence_available_count",
        "source_candidate_not_unique_count",
        "source_candidate_replay_all_valid_count",
        "source_candidate_matching_candidate_count_total",
        "source_candidate_unique_sign_pattern_count_total",
        "matched_count",
    ]
    for suffix in signed_fixture_suffixes:
        source_token = f"final_completion_signed_fixture_consistency_{suffix}"
        host_token = f"analysis_{source_token}"
        assert source_token in imgui_source
        assert host_token in report_schema
        assert host_token in native_release_docs

    pinned_note_tokens = [
        "required_check_consistency=required=3; passed=1; failed=2",
        "mismatched=2; final_ready_matched=true; all_matched=false; matched=false",
        "signed_fixture_consistency=blockers=2; final_blockers=2",
        "source_urls=2; unsigned_non_claims=2; source_table_metadata=2",
        "source_candidate_evidence=2; source_candidates_not_unique=2",
        "source_candidate_matches=32; source_candidate_unique_signs=20",
        "mismatched=0; matched=true",
    ]
    for token in pinned_note_tokens:
        assert token in native_release_docs

    verified_assignment_readiness_tokens = [
        "verified_assignment_readiness",
        "verified_signed_crossing_assignment_readiness",
        "unique_sign_pattern",
        "invariant_table_values_verified",
        "external_source_assignment_verified",
    ]
    for token in verified_assignment_readiness_tokens:
        assert token in fixture_source
        assert token in report_schema
        assert token in native_release_docs
        assert token in execution_status

    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    mismatch_tokens = [
        "test_imgui_payloads_preserve_validation_pack_required_check_consistency_mismatch",
        (
            "required_check_consistency=required=3; passed=2; failed=1; "
            "mismatched=1; final_ready_matched=false; all_matched=false; "
            "matched=false"
        ),
        "analysis_final_completion_required_check_consistency_matched_count=0",
    ]
    assert mismatch_tokens[0] in reports_schema_tests
    for token in mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    required_fixture_metadata_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "required_fixture_metadata_consistency_mismatch"
        ),
        (
            "required_fixture_metadata_consistency=required=7; "
            "registered=6; missing=1; metadata_complete=5; "
            "metadata_incomplete=2; blockers=2; gate_passed=false; "
            "matched=false"
        ),
        (
            "analysis_final_completion_required_diagram_fixture_metadata_"
            "consistency_matched_count=0"
        ),
    ]
    assert required_fixture_metadata_mismatch_tokens[0] in reports_schema_tests
    for token in required_fixture_metadata_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    signed_fixture_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "signed_fixture_consistency_mismatch"
        ),
        (
            "signed_fixture_consistency=blockers=2; final_blockers=1; "
            "source_urls=1; unsigned_non_claims=1; "
            "source_table_metadata=1; source_candidate_evidence=1; "
            "source_candidates_not_unique=1; source_candidate_replays_valid=1; "
            "source_candidate_matches=12; source_candidate_unique_signs=6; "
            "mismatched=1; matched=false"
        ),
        "analysis_final_completion_signed_fixture_consistency_matched_count=0",
    ]
    assert signed_fixture_mismatch_tokens[0] in reports_schema_tests
    for token in signed_fixture_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    non_diagram_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "non_diagram_requirement_consistency_mismatch"
        ),
        (
            "non_diagram_requirement_consistency=requirements=6; open=3; "
            "blockers=2; evidence_refs=3; evidence_ids=2; "
            "missing_artifacts_matched=2; evidence_fields_matched=1; "
            "refs_top_level_matched=false; ids_top_level_matched=false; "
            "mismatched=2; matched=false"
        ),
        (
            "analysis_final_completion_non_diagram_requirement_consistency_"
            "matched_count=0"
        ),
    ]
    assert non_diagram_mismatch_tokens[0] in reports_schema_tests
    for token in non_diagram_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    non_claim_gate_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "non_claim_gate_consistency_mismatch"
        ),
        (
            "non_claim_gate_consistency=fields=4; false=3; gates=4; "
            "blockers=3; missing_artifacts=3; codes_matched=2; "
            "missing_artifacts_matched_count=3; matched=false"
        ),
        "analysis_final_completion_non_claim_gate_consistency_matched_count=0",
    ]
    assert non_claim_gate_mismatch_tokens[0] in reports_schema_tests
    for token in non_claim_gate_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    boundary_tokens = [
        "each required check is expected",
        "rather than registered signed",
    ]
    for token in boundary_tokens:
        assert token in native_release_docs


def test_validation_pack_existing_analysis_counter_edges_are_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    io_cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    counter_tokens = [
        "analysis_final_completion_completion_gate_evidence_consistency_code_matched_count",
        "analysis_retained_evidence_non_claim_consistency_completion_top_level_matched_count",
        "analysis_retained_evidence_non_claim_consistency_release_speedup_top_level_matched_count",
        "analysis_retained_evidence_non_claim_consistency_real_backend_top_level_matched_count",
        "analysis_retained_evidence_non_claim_consistency_screenshot_top_level_matched_count",
    ]
    for token in counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs
        assert token in reports_schema_tests
        assert token in io_cli_tests

    note_tokens = [
        "completion_gate_evidence_consistency=gates=4; gate_checks=4",
        "blockers=4; failed=4; false=4; codes=4",
        "required=4; current=4; missing_artifacts=4; missing_artifact_ids=4; retained_evidence=8; retained_evidence_ids=8; retained_evidence_matched=4; mismatched=0",
        "retained_evidence_non_claim=entries=10; ids=8",
        "completion=0; release_speedup=0",
        "real_backend=0; screenshot=0; matched=true",
    ]
    for token in note_tokens:
        assert token in report_schema
        assert token in execution_status
        assert token in native_release_docs or token in report_schema
        assert token in reports_schema_tests
        assert token in io_cli_tests

    completion_gate_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "completion_gate_evidence_consistency_mismatch"
        ),
        (
            "completion_gate_evidence_consistency=gates=4; gate_checks=4; "
            "blockers=3; failed=4; false=3; codes=2; required=2; "
            "current=1; missing_artifacts=2; missing_artifact_ids=0; "
            "retained_evidence=0; retained_evidence_ids=0; "
            "retained_evidence_matched=0; mismatched=2; matched=false"
        ),
        (
            "analysis_final_completion_completion_gate_evidence_"
            "consistency_matched_count=0"
        ),
    ]
    assert completion_gate_mismatch_tokens[0] in reports_schema_tests
    for token in completion_gate_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    retained_non_claim_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "retained_evidence_non_claim_consistency_mismatch"
        ),
        (
            "retained_evidence_non_claim=entries=5; ids=3; "
            "completion=1; release_speedup=1; real_backend=1; "
            "screenshot=1; matched=false"
        ),
        "analysis_retained_evidence_non_claim_consistency_matched_count=0",
    ]
    assert retained_non_claim_mismatch_tokens[0] in reports_schema_tests
    for token in retained_non_claim_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests

    gate_blocker_mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_validation_pack_"
            "gate_blocker_consistency_mismatch"
        ),
        (
            "gate_blocker_consistency=checked=7; count_matched=5; "
            "codes_matched=4; mismatched=2; matched=false"
        ),
        "analysis_final_completion_gate_blocker_consistency_matched_count=0",
    ]
    assert gate_blocker_mismatch_tokens[0] in reports_schema_tests
    for token in gate_blocker_mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=0"):
            assert token.removesuffix("=0") in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests


def test_validation_pack_external_source_url_shape_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    pd_fixtures_source = (ROOT / "src/iroll/topology/pd_fixtures.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    pd_tests = (ROOT / "tests/test_pd_polynomials.py").read_text(encoding="utf-8")
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    url_shape_tokens = [
        "source_url_scheme",
        "source_url_domain",
        "source_url_http_or_https",
        "source_url_http_or_https_when_applicable",
    ]
    for token in url_shape_tokens:
        assert token in pd_fixtures_source
        assert token in report_schema
        assert token in execution_status
        assert token in pd_tests
        assert token in cli_tests

    implementation_summary_tokens = [
        "fixture_source_url_shape_summary",
        "validation_pack_fixture_source_url_fixture_row_count",
        "validation_pack_fixture_source_url_row_count",
        "validation_pack_fixture_source_url_http_or_https_count",
        "validation_pack_fixture_source_url_requirement_satisfied_count",
        "validation_pack_fixture_source_url_shape_matched_count",
        "source_url_scheme_count_matched",
        "source_url_domain_count_matched",
    ]
    for token in implementation_summary_tokens:
        assert token in imgui_source or token in pd_fixtures_source
        assert token in reports_schema_tests or token in pd_tests or token in cli_tests

    documented_summary_tokens = [
        "fixture_source_url_shape_summary",
        "validation_pack_fixture_source_url_shape_summary",
        "analysis_validation_pack_fixture_source_url_fixture_row_count",
        "analysis_validation_pack_fixture_source_url_shape_matched_count",
        "fixture_source_urls=rows=3; required=3",
        (
            "fixture_source_urls=rows=3; required=3; http_or_https=2; "
            "requirement_satisfied=2; schemes=3; domains=2; matched=false"
        ),
        "analysis_validation_pack_fixture_source_url_shape_matched_count=0",
    ]
    for token in documented_summary_tokens:
        assert token in report_schema
        assert token in execution_status
        if "matched=false" in token:
            assert (
                "fixture_source_urls=rows=3; required=3; http_or_https=2; "
                in reports_schema_tests
            )
            assert (
                "requirement_satisfied=2; schemes=3; domains=2; matched=false"
                in reports_schema_tests
            )
        elif token.endswith("matched_count=0"):
            source_key = token.removesuffix("=0")
            assert source_key in reports_schema_tests
            assert "== 0" in reports_schema_tests
        else:
            assert token in reports_schema_tests
        if token.endswith("matched_count=0"):
            assert token in report_schema
        else:
            assert token in native_release_docs or "matched=false" in token
            assert token in cli_tests or "matched=false" in token

    known_limitations_tokens = [
        "fixture_known_limitations_summary",
        "validation_pack_fixture_known_limitations_summary",
        "validation_pack_fixture_known_limitations_fixture_row_count",
        "validation_pack_fixture_known_limitations_available_count",
        "validation_pack_fixture_known_limitations_note_count_total",
        "validation_pack_fixture_known_limitations_matched_count",
        "analysis_validation_pack_fixture_known_limitations_fixture_row_count",
        "analysis_validation_pack_fixture_known_limitations_matched_count",
        "fixture_known_limitations=rows=7; available=7",
    ]
    for token in known_limitations_tokens:
        assert (
            token in imgui_source
            or token in pd_fixtures_source
            or token in reports_schema_tests
            or token in pd_tests
            or token in cli_tests
        )
        assert token in report_schema
        assert token in native_release_docs
        assert token in execution_status
        assert token in reports_schema_tests or token in pd_tests or token in cli_tests

    assert "_cross_workstream_fixture_known_limitations_summary" in pd_fixtures_source
    assert "known_limitations_note_count_total" in pd_tests
    known_limitations_mismatch_tokens = [
        "test_imgui_payloads_preserve_validation_pack_known_limitations_mismatch",
        "test_cli_imgui_payloads_preserve_validation_pack_known_limitations_mismatch",
        "fixture_known_limitations=rows=7; available=6; unavailable=1; notes=31; requirement_satisfied=6; matched=false",
        "analysis_validation_pack_fixture_known_limitations_matched_count=0",
        "reviewer drift evidence",
    ]
    for token in known_limitations_mismatch_tokens[:2]:
        assert token in reports_schema_tests or token in cli_tests
    for token in known_limitations_mismatch_tokens[2:]:
        assert token in report_schema
        assert token in execution_status
    known_limitations_host_tokens = [
        "host_payload = imgui_host_payload_from_acceptance_reports([report])",
        'host_analysis = host_payload["analysis"]',
        '"analysis_validation_pack_fixture_known_limitations_matched_count"',
        "direct schema helpers, CLI file payloads, and host payloads",
    ]
    for token in known_limitations_host_tokens[:3]:
        assert token in reports_schema_tests
    assert known_limitations_host_tokens[3] in execution_status
    matched_zero_token = (
        '"analysis_validation_pack_fixture_known_limitations_matched_count"]==0'
    )
    assert matched_zero_token in "".join(reports_schema_tests.split())
    assert matched_zero_token in "".join(cli_tests.split())

    behavior_tokens = [
        "_cross_workstream_source_url_shape",
        "_cross_workstream_fixture_source_url_shape_summary",
        "test_cross_workstream_validation_pack_fixture_row_rejects_non_http_source_url",
        "ftp://example.test/Xftp",
        "source_url_requirement_satisfied",
        "URL-shape reviewer evidence only",
    ]
    assert behavior_tokens[0] in pd_fixtures_source
    assert behavior_tokens[1] in pd_fixtures_source
    assert behavior_tokens[2] in pd_tests
    assert behavior_tokens[3] in pd_tests
    assert behavior_tokens[4] in cli_tests
    assert behavior_tokens[5] in execution_status

    boundary_tokens = [
        "does not fetch or verify",
        "external source",
        "does not fetch external sources",
        "does not fetch external sources or verify source correctness",
        "Rust C ABI 19 / Dear ImGui ABI 117",
    ]
    assert boundary_tokens[0] in report_schema
    assert boundary_tokens[1] in report_schema
    assert boundary_tokens[2] in execution_status
    assert boundary_tokens[3] in native_release_docs
    assert boundary_tokens[4] in execution_status


def test_benchmark_matrix_imgui_schema_bridge_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    bridge_tokens = [
        "iroll_core_benchmark_matrix",
        "local_backend_benchmark_matrix_profiling_evidence",
        "benchmark_matrix_rows=",
        "benchmark_matrix_shape=",
        "benchmark matrix analysis rows are host-visible profiling evidence",
    ]
    for token in bridge_tokens:
        assert token in imgui_source

    documented_bridge_tokens = [
        "iroll_core_benchmark_matrix",
        "benchmark_matrix_*",
        "benchmark_speedup_*",
        "benchmark_cuda_gpu_*",
        "local_backend_benchmark_matrix_profiling_evidence",
        "analysis-summary row",
        "benchmark_matrix_rows=expected=",
        "benchmark_matrix_shape=backends=",
    ]
    for token in documented_bridge_tokens:
        assert token in report_schema
        assert token in native_release_docs

    counter_suffixes = [
        "benchmark_matrix_expected_row_count",
        "benchmark_matrix_row_count",
        "benchmark_matrix_completed_row_count",
        "benchmark_matrix_skipped_row_count",
        "benchmark_matrix_failed_row_count",
        "benchmark_matrix_backend_count",
        "benchmark_matrix_workload_count",
        "benchmark_speedup_candidate_count",
        "benchmark_speedup_threshold_candidate_count",
        "benchmark_speedup_completed_comparison_count",
        "benchmark_speedup_missing_baseline_count",
        "benchmark_speedup_release_grade_claimed_count",
        "benchmark_cuda_gpu_requested_row_count",
        "benchmark_cuda_gpu_completed_row_count",
        "benchmark_cuda_gpu_skipped_row_count",
        "benchmark_cuda_gpu_failed_row_count",
        "benchmark_cuda_gpu_threshold_candidate_count",
        "benchmark_cuda_gpu_blocking_reason_count",
        "benchmark_cuda_gpu_runtime_observed_count",
        "benchmark_cuda_gpu_hosted_cuda_ci_claimed_count",
        "benchmark_cuda_gpu_parity_claimed_count",
        "benchmark_cuda_gpu_release_grade_speedup_claimed_count",
    ]
    for suffix in counter_suffixes:
        host_token = f"analysis_{suffix}"
        assert suffix in imgui_source
        assert host_token in report_schema
        assert host_token in native_release_docs

    retained_ci_tokens = [
        "repeat=1",
        "repeat_satisfied=false",
        "repeat_below_minimum",
        "release_grade_speedup_claimed=false",
        "analysis_benchmark_matrix_completed_row_count=4",
        "analysis_benchmark_matrix_failed_row_count=0",
        "analysis_benchmark_cuda_gpu_requested_row_count=0",
        "analysis_benchmark_cuda_gpu_release_grade_speedup_claimed_count=0",
        "analysis_benchmark_speedup_release_grade_claimed_count=0",
    ]
    for token in retained_ci_tokens:
        assert token in native_release_docs

    status_tokens = [
        "repeat=1",
        "minimum_repeat_for_release_claim=3",
        "speedup_threshold=1.25",
        "repeat_satisfied=false",
        "4 completed / 0 failed rows",
        "release-grade speedup / CUDA GPU claimed counts of 0",
        "Rust C ABI 19 / Dear ImGui ABI 117",
    ]
    for token in status_tokens:
        assert token in execution_status


def test_benchmark_matrix_imgui_schema_bridge_notes_are_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    note_shape_tokens = [
        "speedup_gate=",
        "cuda_gpu_benchmark_witness=",
        "repeat_satisfied=",
        "threshold_candidate_count=",
        "gate_scope=local_gpu_benchmark_witness",
        "hosted_cuda_ci_claimed=false",
        "cuda_parity_claimed=false",
        "release_grade_gpu_speedup_claimed=false",
    ]
    for token in note_shape_tokens:
        assert token in imgui_source or token in reports_schema_tests
        assert token in report_schema
        assert token in native_release_docs

    behavior_tokens = [
        "test_imgui_analysis_summary_wraps_core_benchmark_matrix_report",
        "test_imgui_analysis_summary_preserves_benchmark_speedup_release_gate",
        "test_cli_imgui_analysis_summary_payload_accepts_core_benchmark_matrix",
    ]
    assert behavior_tokens[0] in reports_schema_tests
    assert behavior_tokens[1] in reports_schema_tests
    assert behavior_tokens[2] in cli_tests


def test_gpu_smoke_witness_bridge_is_documented() -> None:
    gpu_smoke_source = (
        ROOT / "native/iroll-kernels-gpu/examples/gpu_smoke.py"
    ).read_text(encoding="utf-8")
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )

    artifact_kind_tokens = [
        "gpu_smoke_parity_result",
        "gpu_smoke_unavailable_boundary",
        "gpu_smoke_parity_failure",
    ]
    for token in artifact_kind_tokens:
        assert token in gpu_smoke_source
        assert token in imgui_source
        assert token in report_schema

    retained_artifact_kind_tokens = [
        "artifact_kind=gpu_smoke_unavailable_boundary",
        "artifact_kind=gpu_smoke_parity_failure",
    ]
    for token in retained_artifact_kind_tokens:
        assert token in native_release_docs

    row_tokens = [
        "gpu_smoke_required_capability_name_count",
        "gpu_smoke_required_capability_names",
        "gpu_smoke_failed_check_name_count",
        "gpu_smoke_failed_check_names",
        "gpu_smoke_required_capabilities=",
        "gpu_smoke_failed_check_names=",
    ]
    for token in row_tokens:
        assert token in imgui_source
        assert token in report_schema

    root_counter_tokens = [
        "analysis_gpu_smoke_required_capability_name_count",
        "analysis_gpu_smoke_failed_check_name_count",
        "analysis_gpu_smoke_cuda_parity_claimed_count",
        "analysis_gpu_smoke_release_grade_speedup_claimed_count",
        "analysis_gpu_smoke_release_gate_gpu_backend_unavailable_blocker_count",
        "analysis_gpu_smoke_release_gate_cuda_runtime_not_observed_blocker_count",
        "analysis_gpu_smoke_release_gate_required_checks_incomplete_blocker_count",
        "analysis_gpu_smoke_release_gate_required_checks_failed_blocker_count",
        "analysis_gpu_smoke_release_gate_forced_unavailable_blocker_count",
        "analysis_gpu_smoke_release_gate_simulated_parity_failure_blocker_count",
    ]
    for token in root_counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    pinned_note_tokens = [
        "gpu_smoke_required_capabilities=...",
        "gpu_smoke_failed_check_names=gpu_numpy_parity",
    ]
    for token in pinned_note_tokens:
        assert token in report_schema

    native_note_tokens = [
        "gpu_smoke_required_capabilities=...",
        "gpu_smoke_failed_check_names=...",
    ]
    for token in native_note_tokens:
        assert token in native_release_docs

    source_boundary_tokens = [
        "GPU smoke analysis row is host-visible artifact evidence",
        "not CUDA parity evidence or release-grade speedup evidence",
    ]
    for token in source_boundary_tokens:
        assert token in imgui_source

    docs_boundary_tokens = [
        "not hosted CUDA parity or release-grade",
        "not CUDA parity evidence or a release-grade",
    ]
    assert docs_boundary_tokens[0] in report_schema
    assert docs_boundary_tokens[1] in report_schema
    assert "not establish CUDA parity or release-grade" in native_release_docs


def test_gpu_smoke_counter_family_bridge_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    native_contract_tests = (
        ROOT / "tests/test_native_embedding_contracts.py"
    ).read_text(encoding="utf-8")

    counter_tokens = [
        "analysis_gpu_smoke_parity_result_count",
        "analysis_gpu_smoke_unavailable_boundary_count",
        "analysis_gpu_smoke_parity_failure_count",
        "analysis_gpu_smoke_required_capability_count",
        "analysis_gpu_smoke_required_capability_name_count",
        "analysis_gpu_smoke_parity_check_count",
        "analysis_gpu_smoke_passed_check_count",
        "analysis_gpu_smoke_failed_check_count",
        "analysis_gpu_smoke_failed_check_name_count",
        "analysis_gpu_smoke_blocking_reason_count",
        "analysis_gpu_smoke_backend_available_count",
        "analysis_gpu_smoke_runtime_observed_count",
        "analysis_gpu_smoke_gate_passed_count",
        "analysis_gpu_smoke_dispatch_parity_claimed_count",
        "analysis_gpu_smoke_no_cuda_boundary_count",
        "analysis_gpu_smoke_simulated_parity_failure_count",
        "analysis_gpu_smoke_cuda_parity_claimed_count",
        "analysis_gpu_smoke_release_grade_speedup_claimed_count",
    ]
    for token in counter_tokens:
        source_token = token.removeprefix("analysis_")
        assert source_token in imgui_source
        assert token in report_schema
        assert token in native_release_docs

    row_boolean_tokens = [
        "gpu_smoke_backend_available",
        "gpu_smoke_cuda_runtime_observed",
        "gpu_smoke_gate_passed",
        "gpu_smoke_dispatch_parity_claimed",
        "gpu_smoke_no_cuda_boundary",
        "gpu_smoke_simulated_parity_failure",
        "gpu_smoke_cuda_parity_claimed",
        "gpu_smoke_release_grade_speedup_claimed",
    ]
    for token in row_boolean_tokens:
        assert token in imgui_source
        assert token in report_schema

    note_tokens = [
        "gpu_smoke_checks=",
        "required_capabilities=",
        "parity_checks=",
        "passed=",
        "failed=",
        "gpu_release_gate=",
        "gpu_release_gate_blocker_codes=",
        "gpu_smoke_claims=",
        "gpu_dispatch_parity_smoke_claimed=",
        "cuda_parity_claimed=",
        "release_grade_speedup_claimed=",
    ]
    for token in note_tokens:
        assert token in imgui_source
        assert token in report_schema

    behavior_tokens = [
        "test_imgui_analysis_summary_wraps_gpu_smoke_artifacts",
        "test_native_release_ci_workflow_covers_wheel_parity_and_optional_gpu",
    ]
    assert behavior_tokens[0] in reports_schema_tests
    assert behavior_tokens[1] in native_contract_tests


def test_homfly_completion_blocker_provenance_bridge_is_documented() -> None:
    homfly_source = (ROOT / "src/iroll/topology/homfly.py").read_text(
        encoding="utf-8"
    )
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    remaining_plan = (ROOT / "docs/remaining-deep-completion-plan.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )

    raw_provenance_tokens = [
        "homfly_completion_blocker_provenance",
        "bounded_non_claim_completion_blocker_provenance",
        "gate_pressure_consistency_matched",
        "frontier_pressure_counts_matched",
        "frontier_witness_consistency_matched",
        "terminal_audit_consistency_matched",
        "arbitrary_diagram_completion_gate.frontier_witness_summary.run_cap_frontier_pressure",
        "arbitrary_diagram_coverage_not_certified",
    ]
    for token in raw_provenance_tokens:
        assert token in homfly_source
        assert token in report_schema

    compact_fields = [
        "homfly_completion_blocker_provenance_matched",
        "homfly_completion_blocker_provenance_non_claim_matched",
        "homfly_completion_blocker_provenance_gate_pressure_matched",
        "homfly_completion_blocker_provenance_frontier_pressure_matched",
        "homfly_completion_blocker_provenance_frontier_witness_matched",
        "homfly_completion_blocker_provenance_terminal_audit_matched",
        "homfly_completion_blocker_provenance_source_field_count",
    ]
    for token in compact_fields:
        assert token in imgui_source
        assert token in report_schema
        assert f"analysis_{token}" in report_schema
        assert f"invariant_{token}" in report_schema

    note_tokens = [
        "homfly_completion_blocker_provenance=",
        "matched=",
        "non_claim=",
        "gate_pressure=",
        "frontier_pressure=",
        "frontier_witness=",
        "terminal_audit=",
        "source_fields=",
        "blocker=",
    ]
    for token in note_tokens:
        assert token in imgui_source
        assert token in report_schema

    boundary_tokens = [
        "Older reports fall back to zero counts and do not fabricate provenance rows",
        "not completion certificates",
        "Rust C ABI 19",
        "Dear ImGui ABI 117",
        "without adding native HOMFLY/Alexander compute APIs",
    ]
    for token in boundary_tokens[:2]:
        assert token in report_schema
    for token in boundary_tokens[2:]:
        assert token in remaining_plan

    behavior_tokens = [
        "test_imgui_payloads_flatten_homfly_completion_blocker_provenance",
        "homfly_completion_blocker_provenance=matched=True",
        "non_claim=True",
        "source_fields=3",
        "blocker=arbitrary_diagram_coverage_not_certified",
    ]
    for token in behavior_tokens:
        assert token in reports_schema_tests


def test_homfly_completion_blocker_provenance_mismatch_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "homfly_completion_blocker_provenance_matched",
        "homfly_completion_blocker_provenance_non_claim_matched",
        "homfly_completion_blocker_provenance_gate_pressure_matched",
        "homfly_completion_blocker_provenance_frontier_pressure_matched",
        "homfly_completion_blocker_provenance_frontier_witness_matched",
        "homfly_completion_blocker_provenance_terminal_audit_matched",
    ]
    for token in source_tokens:
        assert token in imgui_source

    test_tokens = [
        "test_imgui_payloads_preserve_homfly_completion_blocker_provenance_mismatch",
        "homfly_completion_blocker_provenance=matched=False",
        "non_claim=False; gate_pressure=False; frontier_pressure=False",
        "frontier_witness=False; terminal_audit=False; source_fields=2",
        "homfly_completion_blocker_provenance_matched",
        'f"analysis_{key}"',
        'f"invariant_{key}"',
    ]
    for token in test_tokens:
        assert token in reports_schema_tests

    doc_tokens = [
        "Synthetic stale provenance",
        "homfly_completion_blocker_provenance=matched=False",
        "non_claim=False; gate_pressure=False; frontier_pressure=False",
        "frontier_witness=False; terminal_audit=False; source_fields=2",
        "analysis_homfly_completion_blocker_provenance_matched=0",
        "invariant_homfly_completion_blocker_provenance_matched=0",
        "not a completion certificate",
        "Rust C ABI 19 / Dear ImGui ABI 117",
    ]
    for token in doc_tokens:
        assert token in report_schema or token in execution_status


def test_alexander_gate_provenance_bridge_is_documented() -> None:
    alexander_source = (
        ROOT / "src/iroll/topology/multivariable_alexander.py"
    ).read_text(encoding="utf-8")
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    remaining_plan = (ROOT / "docs/remaining-deep-completion-plan.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    io_cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    raw_tokens = [
        "bounded_admissible_minor_normalization_gate_summary",
        "bounded_admissible_minor_normalization_gate_pressure_summary",
        "bounded_admissible_minor_normalization_failed_gate_blocker_provenance_consistency",
        "normalization_gate_provenance_consistent",
        "failed_gate_blocker_provenance_rows",
        "failed_gate_blocker_provenance_row_reason_counts",
        "failed_gate_blocker_provenance_source_available_count",
        "failed_gate_blocker_provenance_source_missing_count",
        "failed_gate_blocker_provenance_missing_source_blockers",
        "failed_gate_blocker_provenance_inconsistent_source_blockers",
    ]
    for token in raw_tokens:
        assert token in alexander_source
        assert token in report_schema

    compact_fields = [
        "admissible_minor_normalization_failed_gate_blocker_provenance_consistent",
        "admissible_minor_normalization_failed_gate_blocker_provenance_row_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_gate_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_attribution_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_reason_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_source_available_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_source_missing_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_missing_source_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_inconsistent_source_count",
    ]
    for token in compact_fields:
        assert token in imgui_source
        assert token in report_schema
        assert f"analysis_{token}" in report_schema
        assert f"invariant_{token}" in report_schema

    note_tokens = [
        "admissible_minor_normalization_gate_provenance=",
        "consistent=",
        "rows=",
        "gates=",
        "attributions=",
        "reasons=",
        "source_available=",
        "source_missing=",
        "missing_sources=",
        "inconsistent_sources=",
    ]
    for token in note_tokens:
        assert token in imgui_source
        assert token in report_schema

    boundary_tokens = [
        "full witness/provenance rows remain in the direct Alexander report JSON",
        "full_admissible_minor_normalization_certified=false",
        "full_invariant_certified=false",
        "Rust C ABI 19",
        "Dear ImGui ABI 117",
        "without adding native HOMFLY/Alexander compute APIs",
    ]
    for token in boundary_tokens[:3]:
        assert token in report_schema
    for token in boundary_tokens[3:]:
        assert token in remaining_plan

    behavior_tokens = [
        "test_imgui_payloads_flatten_alexander_gate_summary_compact_fields",
        "admissible_minor_normalization_gate_provenance=consistent=True",
        "source_available=2",
    ]
    for token in behavior_tokens:
        assert token in reports_schema_tests

    cli_tokens = [
        "admissible_minor_normalization_failed_gate_blocker_provenance_source_missing_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_missing_source_count",
        "source_missing=1",
    ]
    for token in cli_tokens:
        assert token in io_cli_tests


def test_alexander_gate_provenance_mismatch_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "admissible_minor_normalization_failed_gate_blocker_provenance_consistent",
        "admissible_minor_normalization_failed_gate_blocker_provenance_source_missing_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_missing_source_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_inconsistent_source_count",
        "admissible_minor_normalization_gate_provenance=",
    ]
    for token in source_tokens:
        assert token in imgui_source

    test_tokens = [
        "test_imgui_payloads_preserve_alexander_gate_provenance_mismatch",
        "admissible_minor_normalization_gate_provenance=consistent=False",
        "source_available=0; source_missing=1; missing_sources=1",
        "inconsistent_sources=1",
        "admissible_minor_normalization_failed_gate_blocker_provenance_consistent",
        'f"analysis_{key}"',
        'f"invariant_{key}"',
    ]
    for token in test_tokens:
        assert token in reports_schema_tests

    doc_tokens = [
        "Synthetic stale provenance",
        "admissible_minor_normalization_gate_provenance=consistent=False",
        "source_available=0; source_missing=1; missing_sources=1",
        "inconsistent_sources=1",
        (
            "analysis_admissible_minor_normalization_failed_gate_blocker_"
            "provenance_consistent=0"
        ),
        (
            "invariant_admissible_minor_normalization_failed_gate_blocker_"
            "provenance_consistent=0"
        ),
        "reviewer drift evidence",
        "not full admissible-minor normalization",
        "full_admissible_minor_normalization_certified=false",
        "full_invariant_certified=false",
        "Rust C ABI 19 / Dear ImGui ABI 117",
    ]
    for token in doc_tokens:
        assert token in report_schema or token in execution_status


def test_generated_source_summary_consistency_mismatch_witness_is_documented() -> None:
    homfly_source = (ROOT / "src/iroll/topology/homfly.py").read_text(
        encoding="utf-8"
    )
    alexander_source = (
        ROOT / "src/iroll/topology/multivariable_alexander.py"
    ).read_text(encoding="utf-8")
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    io_cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    raw_tokens = [
        "source_notation_summary_consistency",
        "mismatch_count",
        "first_mismatch",
        "mismatch_witnesses",
    ]
    for token in raw_tokens:
        assert token in homfly_source
        assert token in alexander_source
        assert token in report_schema

    compact_fields = [
        "generated_source_summary_consistency_matched",
        "generated_source_summary_count_totals_matched",
        "generated_source_summary_distribution_totals_matched",
        "generated_source_summary_frontier_reason_counts_matched",
        "generated_source_summary_source_notation_count_matches_fixture_count",
    ]
    for token in compact_fields:
        assert token in imgui_source
        assert token in report_schema
        assert f"analysis_{token}" in report_schema

    note_tokens = [
        "source_notation_summary_consistency=",
        "matched=",
        "count_totals_matched=",
        "distribution_totals_matched=",
        "frontier_reason_counts_matched=",
        "source_notation_count_matches_fixture_count=",
        "mismatch_count=",
        "first_mismatch=",
        "first_mismatch_tags=",
    ]
    for token in note_tokens:
        assert token in report_schema

    source_note_tokens = [
        "source_notation_summary_consistency=",
        'parts.append(f"{key}={value}")',
        "first_mismatch=",
        "first_mismatch_tags=",
    ]
    for token in source_note_tokens:
        assert token in imgui_source

    behavior_tokens = [
        "test_imgui_analysis_summary_exposes_homfly_source_summary_mismatch_witness",
        "test_imgui_analysis_summary_exposes_alexander_source_summary_mismatch_witness",
        (
            "test_imgui_payloads_preserve_generated_source_summary_"
            "consistency_mismatch"
        ),
        "first_mismatch=count_total:case_count",
        "first_mismatch_tags=count",
        "first_mismatch_tags=case,count",
        "analysis_generated_source_summary_consistency_matched",
        "analysis_generated_source_summary_count_totals_matched",
        "source_notation_summary_consistency=matched=False",
        "count_totals_matched=False",
    ]
    for token in behavior_tokens:
        assert token in reports_schema_tests

    cli_tokens = [
        "_assert_cli_homfly_source_notation_summary_consistency",
        "_assert_cli_alexander_source_notation_summary_consistency",
        "source_notation_summary_consistency=matched=True",
    ]
    for token in cli_tokens:
        assert token in io_cli_tests

    boundary_tokens = [
        "report self-consistency audit only",
        "does not strengthen the HOMFLY mathematical claim",
        "does not certify full Alexander normalization",
        "native invariant computation",
        "Rust C ABI 19 / Dear ImGui ABI 117",
    ]
    for token in boundary_tokens[:2]:
        assert token in report_schema
    for token in boundary_tokens[2:]:
        assert token in execution_status

    aggregate_drift_tokens = [
        "Synthetic generated source-summary mismatch",
        "analysis_generated_source_summary_consistency_matched=False",
        "analysis_generated_source_summary_count_totals_matched=False",
        "source_notation_summary_consistency=matched=False",
        "first_mismatch=count_total:case_count",
        "bounded generated source-summary drift evidence",
    ]
    for token in aggregate_drift_tokens:
        assert token in report_schema or token in execution_status


def test_homfly_fixture_normalization_metadata_mismatch_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    homfly_source = (ROOT / "src/iroll/topology/homfly.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )

    source_tokens = [
        "fixture_normalization_metadata_consistency",
        "mismatch_count",
        "first_mismatch",
        "mismatch_witnesses",
    ]
    for token in source_tokens:
        assert token in homfly_source

    imgui_tokens = [
        "fixture_normalization_metadata=",
        "metadata_consistency_matched=",
        "metadata_mismatch_count=",
        "metadata_first_mismatch=",
        "metadata_first_mismatch_source=",
    ]
    for token in imgui_tokens:
        assert token in imgui_source
        assert token in report_schema

    mismatch_tokens = [
        (
            "test_imgui_analysis_summary_preserves_homfly_"
            "fixture_normalization_metadata_mismatch"
        ),
        "metadata_consistency_matched=False",
        "metadata_mismatch_count=1",
        "metadata_first_mismatch=fixture_normalization_metadata:fixture_source_url",
        "metadata_first_mismatch_source=L2a1",
    ]
    assert mismatch_tokens[0] in reports_schema_tests
    for token in mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        assert token in reports_schema_tests

    boundary_tokens = [
        "external HOMFLY table normalization",
        "arbitrary signed-PD coverage",
        "native HOMFLY/Alexander computation",
        "Rust C ABI 19 / Dear ImGui ABI 117",
    ]
    for token in boundary_tokens:
        assert token in report_schema
        assert token in execution_status


def test_generated_coverage_analysis_reports_api_example_is_documented() -> None:
    api_examples = (ROOT / "docs/api-examples.md").read_text(encoding="utf-8")
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    io_cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    example_tokens = [
        "analysis_reports",
        "imgui_host_payload_from_acceptance_reports",
        "homfly_small_diagram_coverage_report",
        "multivariable_alexander_signed_pd_coverage_report",
        "source_notation_summary_consistency",
        "generated_source_summary_consistency_matched",
        "analysis_generated_source_summary_consistency_matched",
        "generated_source_notation_count",
        "generated_max_branch_depth",
        "source_notation_certified_cases",
        "source_notation_accepted_cases",
    ]
    for token in example_tokens:
        assert token in api_examples

    behavior_tokens = [
        "analysis_reports=analysis_reports",
        "test_imgui_host_sample_payload_matches_generated_hopf_bundle",
        "test_imgui_analysis_payload_aggregates_depth_two_generated_coverage_pack",
        "test_cli_imgui_analysis_payload_accepts_default_depth_two_generated_coverage",
    ]
    assert behavior_tokens[0] in reports_schema_tests
    assert behavior_tokens[1] in reports_schema_tests
    assert behavior_tokens[2] in reports_schema_tests
    assert behavior_tokens[3] in io_cli_tests

    schema_tokens = [
        "analysis_generated_source_summary_consistency_matched",
        "source_notation_summary_consistency=",
        "source_notation_certified_cases",
        "source_notation_accepted_cases",
    ]
    for token in schema_tokens:
        assert token in report_schema

    boundary_tokens = [
        "analysis-only diagnostics",
        "bounded generated fixture-branch evidence",
        "They do not certify",
        "arbitrary signed-PD HOMFLY evaluation",
        "full Alexander admissible-minor",
        "normalization",
        "native invariant computation",
    ]
    for token in boundary_tokens:
        assert token in api_examples


def test_alexander_generated_figure_eight_uncertified_frontier_is_documented() -> None:
    completion_plan = (ROOT / "docs/remaining-deep-completion-plan.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    post_mvp_tests = (ROOT / "tests/test_post_mvp_invariants.py").read_text(
        encoding="utf-8"
    )

    current_boundary_tokens = [
        "145 cases with 141 accepted and four skipped",
        "1489 with 1389 accepted and 100 skipped",
        "14329 with 12869 accepted and 1460 skipped",
        "131161 with 114341 accepted and 16820 skipped",
        "1,157,113 with 986,629 accepted and 170,484 skipped",
        "IROLL_RUN_DEEP_COVERAGE=1",
        "The default suite keeps Hopf and trefoil depth-six plus `4_1` depth-five",
        "not full admissible-minor normalization or arbitrary signed-PD solver certification",
    ]
    for token in current_boundary_tokens:
        assert (
            token in completion_plan
            or token in execution_status
            or token in report_schema
        )

    test_tokens = [
        '"accepted_case_count": 141',
        '"uncertified_case_count": 4',
        '"result_skipped_case_count": 4',
        '"accepted_case_count": 1389',
        '"uncertified_case_count": 100',
        '"accepted_case_count": 12869',
        '"uncertified_case_count": 1460',
        'assert report["accepted_case_count"] == 114341',
        'assert report["uncertified_case_count"] == 16820',
        'assert report["accepted_case_count"] == 986629',
        'assert report["uncertified_case_count"] == 170484',
        "IROLL_RUN_DEEP_COVERAGE",
        "1.15M-case",
    ]
    for token in test_tokens:
        assert token in post_mvp_tests

    stale_overclaim_tokens = [
        "explicit-orientation `4_1` exposes 145 accepted cases",
        "1489 explicit-orientation `4_1` cases with 17364 scanned minors, for 2262 total accepted generated cases",
        "14329 explicit-orientation `4_1` cases with 156628 scanned minors",
        "131161 accepted generated explicit-orientation `4_1` cases",
        "1157113 accepted generated explicit-orientation `4_1` bounded branch cases",
        "bounded scanned-gcd/Wirtinger-Fox evidence remains accepted for non-unlink generated cases",
    ]
    docs = "\n".join((completion_plan, execution_status, report_schema))
    for token in stale_overclaim_tokens:
        assert token not in docs


def test_whitehead_source_invariant_candidate_retained_pack_is_documented() -> None:
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    io_cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    command_tokens = [
        "fixture-source-invariant-candidates",
        "L5a1",
        "--no-homfly",
        "--max-candidates",
        "24",
    ]
    for token in command_tokens:
        assert token in report_schema
        assert token in execution_status
        assert token in io_cli_tests

    raw_tokens = [
        "diagram_fixture_source_invariant_candidate_diagnostics",
        "signed_pd_replay_summary",
        "source_candidate_replay_self_consistency",
        "all_returned_candidates_have_valid_replay",
        "valid_replay_count",
        "orientation_issue_count",
        "source_candidate_replay_summary_checked_candidate_count",
        "source_candidate_replay_summary_valid_replay_count",
        "source_candidate_replay_summary_invalid_replay_count",
        "source_candidate_replay_summary_all_valid_count",
        "analysis_source_candidate_replay_summary_checked_candidate_count",
        "matching_candidate_count",
        "returned_candidate_count",
        "complete_candidate_set",
        "stable_invariants",
        "candidate_group_count",
        "matching_candidate_count=24",
        "returned_candidate_count=24",
        "complete_candidate_set=true",
        "stable_invariants=[]",
        "candidate_group_count=20",
    ]
    for token in raw_tokens:
        assert token in report_schema
        assert token in io_cli_tests or token in execution_status

    convergence_tokens = [
        "computed_candidate_count=12",
        "missing_candidate_count=12",
        "unique_value_count=1",
        "computed_candidate_count=16",
        "missing_candidate_count=8",
        "skipped_candidate_count=8",
        "unique_value_count=2",
        "computed_candidate_count=0",
        "missing_candidate_count=24",
        "stable_across_complete_candidates=false",
    ]
    for token in convergence_tokens:
        assert token in report_schema

    cli_behavior_tokens = [
        "test_cli_whitehead_source_invariant_candidates_retained_pack_exports_imgui_payloads",
        "stable_across_complete_candidates",
        "signed candidates are diagnostics",
        "not registered as fixture invariants",
        "external source convention validation",
        "source_candidate_replay_summary=checked=24; valid=24",
    ]
    for token in cli_behavior_tokens:
        assert token in io_cli_tests

    boundary_tokens = [
        "Whitehead source-Gauss/pairwise-zero reviewer evidence only",
        "register `L5a1` signed fixture invariants",
        "certify source-table normalization",
        "Rust C ABI 19 / Dear ImGui ABI 117",
    ]
    for token in boundary_tokens:
        assert token in report_schema


def test_single_input_certification_retained_pack_is_documented() -> None:
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    native_contract_tests = (
        ROOT / "tests/test_native_embedding_contracts.py"
    ).read_text(encoding="utf-8")
    io_cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    artifact_file_tokens = [
        "input-certification-hopf-imgui-role-order.json",
        "input-certification-homfly-pd.json",
        "input-certification-homfly-terminal-audit.json",
        "input-certification-homfly-evidence.json",
        "input-certification-alexander-pd.json",
        "input-certification-alexander-admissible-audit.json",
        "input-certification-alexander-evidence.json",
        "input-certification-imgui-analysis.json",
        "input-certification-imgui-host.json",
    ]
    for token in artifact_file_tokens:
        assert token in report_schema
        assert token in native_release_docs
        assert token in native_contract_tests
        assert token in io_cli_tests
    upload_token = "iroll-single-input-certification-audits-py${{ matrix.python-version }}"
    assert upload_token in report_schema
    assert upload_token in native_release_docs
    assert upload_token in native_contract_tests

    raw_evidence_tokens = [
        "method=homfly_terminal_reduction_audit",
        "matched_result=true",
        "terminal_reduction_count=2",
        "failed_terminal_reduction_count=0",
        "frontier_count=0",
        "truncated=false",
        "certified_for_input=true",
        "frontier_exhausted=true",
        "terminal_contribution_matches_result=true",
        "bounded_scanned_gcd_certified=true",
        "complete_scanned_gcd_certified=true",
        "quotient_gcd_certified=true",
        "wirtinger_fox_input_chain_consistent=true",
        "bounded_admissible_minor_normalization_certified=false",
        "all_nonzero_minors_laurent_unit_equivalent=false",
        "failed_nonzero_minor_count=2",
    ]
    for token in raw_evidence_tokens:
        assert token in native_release_docs

    native_contract_evidence_tokens = [
        "method=homfly_terminal_reduction_audit",
        "matched_result",
        "terminal_reduction_count",
        "failed_terminal_reduction_count",
        "certified_for_input",
        "frontier_exhausted",
        "terminal_contribution_matches_result",
        "bounded_scanned_gcd_certified",
        "complete_scanned_gcd_certified",
        "quotient_gcd_certified",
        "wirtinger_fox_input_chain_consistent",
        "bounded_admissible_minor_normalization_certified",
        'alexander_audit["all_nonzero_minors_laurent_unit_equivalent"] is False',
        'alexander_audit["failed_nonzero_minor_count"] == 2',
    ]
    for token in native_contract_evidence_tokens:
        assert token in native_contract_tests

    bridge_tokens = [
        "analysis_summary_count=4",
        "analysis_required_check_count=14",
        "analysis_passed_check_count=12",
        "analysis_failed_check_count=2",
        "test_cli_single_input_certification_retained_pack_exports_imgui_payloads",
        "analysis[\"analysis_summary_count\"] == 4",
        "analysis[\"analysis_required_check_count\"] == 14",
        "analysis[\"analysis_passed_check_count\"] == 12",
        "analysis[\"analysis_failed_check_count\"] == 2",
    ]
    for token in bridge_tokens:
        assert (
            token in execution_status
            or token in native_contract_tests
            or token in io_cli_tests
        )

    boundary_tokens = [
        "one supplied Hopf-style signed-PD input",
        "does not certify arbitrary HOMFLY",
        "full Alexander admissible-minor normalization",
        "native HOMFLY/Alexander C++ computation",
        "release completion",
        "Rust C ABI 19 / Dear ImGui ABI 117",
    ]
    for token in boundary_tokens:
        assert token in native_release_docs or token in execution_status
    assert "not arbitrary HOMFLY coverage" in report_schema
    assert "full Alexander admissible-minor normalization" in report_schema


def test_source_candidate_replay_and_auto_role_order_bridge_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    imgui_readme = (ROOT / "ui/imgui/README.md").read_text(encoding="utf-8")
    native_contract_tests = (
        ROOT / "tests/test_native_embedding_contracts.py"
    ).read_text(encoding="utf-8")
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    io_cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")

    row_tokens = [
        "source_candidate_replay_present",
        "source_candidate_replay_claim_scope",
        "source_candidate_replay_source_notation",
        "source_candidate_replay_source_url",
        "source_candidate_replay_pairwise_linking",
        "source_candidate_replay_sign_count",
        "source_candidate_replay_role_order_count",
        "source_candidate_replay_orientation_issue_count",
        "signed_pd_auto_role_order_present",
        "signed_pd_auto_role_order_requested",
        "signed_pd_auto_role_order_applied",
        "signed_pd_auto_role_order_status",
        "signed_pd_auto_role_order_candidate_count",
        "signed_pd_auto_role_order_strict_candidate_count",
        "signed_pd_auto_role_order_unique_strict_global_role_order",
    ]
    for token in row_tokens:
        assert token in imgui_source
        assert token in report_schema
        assert token in native_release_docs
        assert token in native_contract_tests

    root_tokens = [
        "invariant_source_candidate_replay_count",
        "invariant_source_candidate_replay_source_notation_count",
        "invariant_source_candidate_replay_source_notations",
        "invariant_source_candidate_replay_claim_scope_count",
        "invariant_source_candidate_replay_claim_scopes",
        "invariant_source_candidate_replay_sign_count",
        "invariant_source_candidate_replay_role_order_count",
        "invariant_source_candidate_replay_orientation_issue_count",
        "invariant_signed_pd_auto_role_order_present_count",
        "invariant_signed_pd_auto_role_order_requested_count",
        "invariant_signed_pd_auto_role_order_applied_count",
        "invariant_signed_pd_auto_role_order_not_needed_count",
        "invariant_signed_pd_auto_role_order_unique_applied_count",
        "invariant_signed_pd_auto_role_order_ambiguous_count",
        "invariant_signed_pd_auto_role_order_no_strict_candidate_count",
        "invariant_signed_pd_auto_role_order_candidate_count",
        "invariant_signed_pd_auto_role_order_strict_candidate_count",
    ]
    for token in root_tokens:
        assert token in imgui_source
        assert token in report_schema

    note_tokens = [
        "source_candidate_replay=",
        "claim_scope=source_gauss_matched_signed_pd_candidate_replay",
        "source_notation=L6a4",
        "source_url=https://katlas.org/wiki/L6a4",
        "pairwise_linking=0.0,0.0,0.0",
        "signed_pd_auto_role_order=",
        "status=not_needed; applied=False",
        "status=unique_applied; applied=True",
        "unique_role_order=1,0,2,3",
    ]
    for token in note_tokens:
        assert token in reports_schema_tests or token in io_cli_tests
    for token in note_tokens[:1] + note_tokens[5:6]:
        assert token in imgui_source
        assert token in report_schema
        assert token in native_release_docs
        assert token in native_contract_tests

    behavior_tokens = [
        "test_imgui_invariant_status_payload_wraps_unique_applied_auto_role_order",
        "test_cli_imgui_invariant_status_payload_accepts_unique_applied_auto_role_order",
        "test_cli_source_candidate_replay_round_trips_to_pd_recompute",
        "test_cli_imgui_signed_pd_auto_role_order_keeps_zero_crossing_rows",
        "source_gauss_matched_signed_pd_candidate_replay",
    ]
    for token in behavior_tokens:
        assert token in reports_schema_tests or token in io_cli_tests

    boundary_tokens = [
        "not automatic convention recovery",
        "not signed-fixture registration evidence",
        "do not license a",
        "guess a convention after an ambiguous skipped report",
        "without treating the unsigned fixture candidate as a registered invariant",
    ]
    for token in boundary_tokens[:4]:
        assert token in report_schema
    for token in boundary_tokens[4:]:
        assert token in imgui_readme
    native_boundary_tokens = [
        "JSON hosts only",
        "do not register fixture signs",
        "guess a convention after an ambiguous skipped report",
        "native HOMFLY/Alexander C++ computation",
    ]
    for token in native_boundary_tokens:
        assert token in native_release_docs
        assert token in native_contract_tests

    native_reload_paragraph = native_release_docs.split(
        "- The file-oriented signed-PD invariant-status reload path", 1
    )[1].split("\n- The base Python job also writes", 1)[0]
    for token in row_tokens + note_tokens[:1] + note_tokens[5:6]:
        assert token in native_reload_paragraph
    for token in native_boundary_tokens:
        assert token in native_reload_paragraph


def test_unsupported_result_handle_lifecycle_bridge_is_documented() -> None:
    diagnostics_source = (ROOT / "src/iroll/kernels/diagnostics.py").read_text(
        encoding="utf-8"
    )
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )
    rust_interface_docs = (ROOT / "docs/rust-kernel-interface.md").read_text(
        encoding="utf-8"
    )
    imgui_readme = (ROOT / "ui/imgui/README.md").read_text(encoding="utf-8")
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    io_cli_tests = (ROOT / "tests/test_io_cli.py").read_text(encoding="utf-8")
    kernels_tests = (ROOT / "tests/test_kernels.py").read_text(encoding="utf-8")

    lifecycle_symbols = [
        "iroll_invariant_result_handle_create_unsupported",
        "iroll_invariant_result_handle_report_json",
        "iroll_invariant_result_handle_free",
        "iroll_kernel_owned_string_free",
    ]
    for token in lifecycle_symbols:
        assert token in diagnostics_source
        assert token in rust_interface_docs
        assert token in imgui_readme

    source_bridge_tokens = [
        "method == \"invariant_result_handle_report\"",
        "result_handle_transport: ",
        "result_handle_abi=",
        "report_transport_abi=",
        "handle_report_symbol=",
        "handle_free_symbol=",
        "owned_string_free_symbol=",
        "native_computation_claimed=",
        "result_available=",
        "claim_scope=",
    ]
    for token in source_bridge_tokens:
        assert token in imgui_source

    report_tokens = [
        "method=invariant_result_handle_report",
        "result_handle_transport:",
        "result_handle_abi=opaque_invariant_result_handle_v1",
        "report_transport_abi=owned_string_v1",
        "handle_report_symbol=iroll_invariant_result_handle_report_json",
        "handle_free_symbol=iroll_invariant_result_handle_free",
        "owned_string_free_symbol=iroll_kernel_owned_string_free",
        "native_computation_claimed=false",
        "result_available=false",
        "claim_scope=unsupported_lifecycle_probe_only",
    ]
    for token in report_tokens:
        assert token in report_schema
        assert token in native_release_docs
        assert token in rust_interface_docs

    behavior_tokens = [
        "test_imgui_invariant_status_payload_wraps_unsupported_result_handle_report",
        "test_cli_imgui_invariant_status_summary_payload_accepts_unsupported_handle_report",
        "test_rust_unsupported_result_handle_report_loads_as_imgui_status_when_installed",
        "native_computation_claimed=true",
        "result_available=true",
    ]
    for token in behavior_tokens:
        assert (
            token in reports_schema_tests
            or token in io_cli_tests
            or token in kernels_tests
        )

    boundary_tokens = [
        "zero required/passed/failed checks",
        "skipped/non-claim row",
        "not native HOMFLY/Alexander computation",
        "Rust C ABI 19",
        "Dear ImGui ABI 117",
    ]
    for token in boundary_tokens:
        assert token in report_schema or token in native_release_docs


def test_rust_owned_string_lifecycle_contract_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    diagnostics_source = (ROOT / "src/iroll/kernels/diagnostics.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    rust_interface_docs = (ROOT / "docs/rust-kernel-interface.md").read_text(
        encoding="utf-8"
    )
    imgui_readme = (ROOT / "ui/imgui/README.md").read_text(encoding="utf-8")
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    kernels_tests = (ROOT / "tests/test_kernels.py").read_text(encoding="utf-8")

    c_abi_tokens = [
        "iroll_kernel_backend_report_json",
        "iroll_kernel_owned_string_free",
        "rust_owned_string_v1",
        "free_required",
        "free_accepts_zero_initialized",
        "borrowed_across_calls",
    ]
    for token in c_abi_tokens:
        assert token in rust_interface_docs
        assert token in kernels_tests

    owned_string_fields = [
        "owned_string_contract_schema_version",
        "owned_string_contract_abi_version",
        "owned_string_contract_version_length",
        "owned_string_contract_free_required",
        "owned_string_contract_free_accepts_zero_initialized",
        "owned_string_contract_borrowed_across_calls",
    ]
    for token in owned_string_fields:
        assert token in imgui_source
        assert token in report_schema
        assert token in imgui_readme
        assert token in reports_schema_tests

    native_stats_tokens = [
        "kernel_backend_owned_string_contract_schema_v1_count",
        "kernel_backend_owned_string_contract_abi_version_19_count",
        "kernel_backend_owned_string_contract_free_required_count",
        "kernel_backend_owned_string_contract_free_accepts_zero_initialized_count",
        "kernel_backend_owned_string_contract_borrowed_across_calls_count",
        "kernel_backend_owned_string_contract_version_length_max",
    ]
    for token in native_stats_tokens:
        assert token in report_schema
        assert token in imgui_readme

    note_tokens = [
        "owned_string_contract:",
        "schema_version=1",
        "abi_version=19",
        "free_required=true",
        "free_accepts_zero_initialized=true",
        "borrowed_across_calls=false",
    ]
    for token in note_tokens:
        assert token in imgui_source or token in reports_schema_tests
        assert token in report_schema
        assert token in reports_schema_tests

    boundary_tokens = [
        "Dear ImGui ABI 109",
        "Rust owned-string contract JSON remain authoritative",
        "not HOMFLY/Alexander native compute",
        "does not add complete native invariant result handles",
        "HOMFLY/Alexander-specific native computation result objects still wait",
    ]
    assert boundary_tokens[0] in report_schema
    assert boundary_tokens[1] in report_schema
    assert boundary_tokens[2] in imgui_readme
    assert boundary_tokens[3] in imgui_readme
    assert boundary_tokens[4] in rust_interface_docs

    behavior_tokens = [
        "test_rust_backend_c_report_owned_string_contract_when_installed",
        "test_imgui_kernel_backend_status_payload_wraps_backend_report",
        "EXPECTED_OWNED_STRING_CONTRACT",
        "owned_string_contract: schema_version=1, abi_version=19",
    ]
    for token in behavior_tokens[:3]:
        assert token in kernels_tests or token in reports_schema_tests
    assert behavior_tokens[3] in reports_schema_tests


def test_homfly_maturity_path_counts_are_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")

    row_tokens = [
        "bounded_homfly_maturity_path_certified_count",
        "bounded_homfly_maturity_path_distinct_count",
        "bounded_homfly_maturity_path_zero_crossing_unlink_count",
        "bounded_homfly_maturity_path_recursive_frontier_exhausted_count",
        "bounded_homfly_maturity_path_source_table_diagnostic_count",
        "bounded_homfly_maturity_path_not_certified_count",
        "bounded_homfly_maturity_path=",
        "bounded_homfly_maturity_paths=",
    ]
    for token in row_tokens:
        assert token in imgui_source
        assert token in report_schema

    counter_suffixes = [
        "bounded_homfly_maturity_path_certified_count",
        "bounded_homfly_maturity_path_distinct_count",
        "bounded_homfly_maturity_path_zero_crossing_unlink_count",
        "bounded_homfly_maturity_path_recursive_frontier_exhausted_count",
        "bounded_homfly_maturity_path_source_table_diagnostic_count",
        "bounded_homfly_maturity_path_not_certified_count",
    ]
    for suffix in counter_suffixes:
        assert suffix in imgui_source
        assert f"analysis_{suffix}" in report_schema
        assert f"invariant_{suffix}" in report_schema

    boundary_tokens = [
        "do not certify external HOMFLY table normalization",
        "arbitrary signed-PD coverage",
        "Dear ImGui ABI 117",
        "Rust C ABI 19",
    ]
    for token in boundary_tokens:
        assert token in report_schema


def test_homfly_bounded_maturity_path_evidence_nested_diagnostic_is_documented() -> None:
    homfly_source = (ROOT / "src/iroll/topology/homfly.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    homfly_tests = (ROOT / "tests/test_homfly.py").read_text(encoding="utf-8")

    nested_tokens = [
        "bounded_homfly_maturity_path_evidence",
        "homfly_bounded_maturity_path_evidence",
        "bounded_maturity_path_classification_diagnostics",
        "expected_bounded_homfly_maturity_path",
        "bounded_homfly_maturity_path_matches_expected",
        "source_table_diagnostic_only",
        "zero_crossing_certified",
        "certified_for_input",
        "frontier_exhausted",
        "skipped",
        "truncated",
        "frontier_count",
        "certification_blocker_count",
        "full_table_normalization_certified",
        "arbitrary_diagram_coverage_certified",
    ]
    for token in nested_tokens:
        assert token in homfly_source
        assert token in report_schema
        assert token in homfly_tests

    status_tokens = [
        "bounded_homfly_maturity_path_evidence",
        "existing route classification only",
        "does not expand HOMFLY evaluation",
        "Rust native invariant handles",
        "Dear ImGui ABI fields",
    ]
    for token in status_tokens:
        assert token in execution_status

    boundary_tokens = [
        "does not add a HOMFLY solver path",
        "does not certify external table normalization",
        "does not claim arbitrary signed-PD coverage",
        "Dear ImGui ABI 117",
        "Rust C ABI 19",
    ]
    for token in boundary_tokens:
        assert token in report_schema


def test_homfly_case_evidence_consistency_bridge_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")
    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    homfly_tests = (ROOT / "tests/test_homfly.py").read_text(encoding="utf-8")

    raw_tokens = [
        "case_evidence_consistency",
        "bounded_homfly_maturity_path_counts_matched",
        "bounded_homfly_maturity_path_distinct_count_matched",
        "bounded_homfly_maturity_path_certified_count_matched",
        "mismatch_witnesses",
    ]
    for token in raw_tokens:
        assert token in homfly_tests
        assert token in report_schema

    counter_suffixes = [
        "available_count",
        "matched_count",
        "mismatch_count",
        "case_count",
        "checked_case_count",
        "missing_evidence_count",
    ]
    for suffix in counter_suffixes:
        source_token = f"homfly_case_evidence_consistency_{suffix}"
        assert source_token in imgui_source
        assert source_token in report_schema
        assert f"analysis_{source_token}" in report_schema
        assert f"invariant_{source_token}" in report_schema

    maturity_consistency_tokens = [
        "homfly_case_evidence_maturity_path_counts_matched_count",
        "homfly_case_evidence_maturity_path_distinct_count_matched_count",
        "homfly_case_evidence_maturity_path_certified_count_matched_count",
    ]
    for token in maturity_consistency_tokens:
        assert token in imgui_source
        assert token in report_schema
        assert f"analysis_{token}" in report_schema
        assert f"invariant_{token}" in report_schema

    note_tokens = [
        "homfly_case_evidence_consistency=",
        "maturity_path_counts_matched=",
        "maturity_path_distinct_matched=",
        "maturity_path_certified_matched=",
    ]
    for token in note_tokens:
        assert token in imgui_source
        assert token in report_schema

    behavior_tokens = [
        "test_imgui_analysis_summary_wraps_homfly_small_diagram_coverage_report",
        "test_homfly_case_evidence_maturity_path_counts_pinpoint_mismatch",
        (
            "test_imgui_payloads_preserve_homfly_case_evidence_"
            "consistency_mismatch"
        ),
        "homfly_case_evidence_consistency=matched=True",
        "homfly_case_evidence_consistency=matched=False",
        "missing=2",
        "maturity_path_counts_matched=False",
        "mismatch_count=2",
        "analysis_homfly_case_evidence_consistency_mismatch_count",
        "invariant_homfly_case_evidence_consistency_missing_evidence_count",
        "maturity_path_counts_matched=True",
    ]
    assert behavior_tokens[0] in reports_schema_tests
    assert behavior_tokens[1] in homfly_tests
    for token in behavior_tokens[2:]:
        assert token in reports_schema_tests

    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    drift_tokens = [
        "Synthetic stale HOMFLY case-evidence consistency",
        "homfly_case_evidence_consistency=matched=False",
        "missing=2",
        "maturity_path_counts_matched=False",
        "maturity_path_distinct_matched=False",
        "maturity_path_certified_matched=False",
        "mismatch_count=2",
        "analysis_homfly_case_evidence_consistency_mismatch_count=1",
        "invariant_homfly_case_evidence_consistency_missing_evidence_count=2",
        "bounded generated-case evidence drift",
        "Rust C ABI 19 / Dear ImGui ABI 117",
    ]
    for token in drift_tokens:
        assert token in report_schema or token in execution_status


def test_alexander_maturity_path_counts_are_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")

    row_tokens = [
        "bounded_alexander_maturity_path_certified_count",
        "bounded_alexander_maturity_path_distinct_count",
        "bounded_alexander_maturity_path_zero_crossing_unlink_count",
        "bounded_alexander_maturity_path_exact_scanned_gcd_count",
        (
            "bounded_alexander_maturity_path_"
            "laurent_unit_normalization_consensus_count"
        ),
        (
            "bounded_alexander_maturity_path_"
            "general_gcd_without_unit_normalization_consensus_count"
        ),
        "bounded_alexander_maturity_path_source_table_diagnostic_count",
        "bounded_alexander_maturity_path_not_certified_count",
        "bounded_alexander_maturity_path=",
        "bounded_alexander_maturity_paths=",
    ]
    for token in row_tokens:
        assert token in imgui_source
        assert token in report_schema

    counter_suffixes = [
        "bounded_alexander_maturity_path_certified_count",
        "bounded_alexander_maturity_path_distinct_count",
        "bounded_alexander_maturity_path_zero_crossing_unlink_count",
        "bounded_alexander_maturity_path_exact_scanned_gcd_count",
        (
            "bounded_alexander_maturity_path_"
            "laurent_unit_normalization_consensus_count"
        ),
        (
            "bounded_alexander_maturity_path_"
            "general_gcd_without_unit_normalization_consensus_count"
        ),
        "bounded_alexander_maturity_path_source_table_diagnostic_count",
        "bounded_alexander_maturity_path_not_certified_count",
    ]
    for suffix in counter_suffixes:
        assert suffix in imgui_source
        assert f"analysis_{suffix}" in report_schema
        assert f"invariant_{suffix}" in report_schema

    boundary_tokens = [
        "full admissible-minor normalization",
        "full Alexander invariance",
        "Dear ImGui ABI 117",
        "Rust C ABI 19",
    ]
    for token in boundary_tokens:
        assert token in report_schema

def test_alexander_maturity_path_summary_consistency_is_documented() -> None:
    imgui_source = (ROOT / "src/iroll/reports/imgui.py").read_text(
        encoding="utf-8"
    )
    report_schema = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")

    raw_tokens = [
        "bounded_alexander_maturity_path_summary_consistency",
        "bounded_alexander_maturity_path_summary_consistency=",
        "matched=",
        "path_total=",
        "reported_path_total=",
        "path_rows=",
        "certified=",
    ]
    for token in raw_tokens:
        assert token in imgui_source
        assert token in report_schema

    counter_suffixes = [
        "available_count",
        "matched_count",
        "mismatch_count",
        "record_count",
        "path_count_total",
        "reported_path_count_total",
        "path_count_row_count",
        "certified_count",
        "certified_path_count",
    ]
    for suffix in counter_suffixes:
        source_token = (
            "bounded_alexander_maturity_path_summary_consistency_" f"{suffix}"
        )
        assert source_token in imgui_source
        assert source_token in report_schema
        assert f"analysis_{source_token}" in report_schema
        assert f"invariant_{source_token}" in report_schema

    boundary_tokens = [
        "full admissible-minor normalization",
        "full Alexander invariance",
        "native HOMFLY/Alexander computation",
        "Rust C ABI 19",
        "Dear ImGui ABI 117",
    ]
    for token in boundary_tokens:
        assert token in report_schema

    reports_schema_tests = (ROOT / "tests/test_reports_schema.py").read_text(
        encoding="utf-8"
    )
    execution_status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    mismatch_tokens = [
        (
            "test_imgui_payloads_preserve_alexander_"
            "maturity_path_summary_consistency_mismatch"
        ),
        "bounded_alexander_maturity_path_summary_consistency=matched=False",
        (
            "analysis_bounded_alexander_maturity_path_"
            "summary_consistency_mismatch_count=1"
        ),
        (
            "invariant_bounded_alexander_maturity_path_"
            "summary_consistency_mismatch_count=1"
        ),
    ]
    assert mismatch_tokens[0] in reports_schema_tests
    for token in mismatch_tokens[1:]:
        assert token in report_schema
        assert token in execution_status
        if token.endswith("=1"):
            assert (
                "bounded_alexander_maturity_path_summary_consistency_mismatch_count"
                in reports_schema_tests
            )
            assert "== 1" in reports_schema_tests
        else:
            assert token in reports_schema_tests
