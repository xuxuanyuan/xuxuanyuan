from __future__ import annotations

import argparse
from copy import deepcopy
from hashlib import sha256
import json
from unittest.mock import patch

import pytest

from iroll.cli import (
    _KNOT_ATLAS_PINNED_HOMFLY_SOURCES,
    _homfly_full_certification_report_command,
)
from iroll.io import dump_report

from iroll.topology import (
    build_planar_diagram,
    cross_workstream_validation_pack_audit,
    disjoint_union,
    get_diagram_fixture,
    jones_polynomial_from_pd,
    kauffman_bracket,
    mirror_signed_pd,
    polynomial_result_from_pd,
    standard_diagram_fixtures,
    PDCrossingOrientation,
    PDOrientation,
)
from iroll.topology.pd_fixtures import (
    DiagramFixture,
    _cross_workstream_validation_pack_fixture_row,
    completion_evidence_artifact_audit,
)
from iroll.topology.pd import PlanarDiagram
from iroll.topology.multivariable_alexander import (
    WirtingerPresentation,
    exact_multivariate_laurent_gcd,
    multivariable_alexander_exact_from_oriented_pd,
    multivariable_alexander_exact_from_presentation,
    multivariable_alexander_exact_result_audit,
)
from iroll.topology.alexander_certification import (
    canonical_json_sha256,
    full_alexander_pinned_sources,
    full_multivariable_alexander_normalization_certification_report,
    full_multivariable_alexander_normalization_certification_report_audit,
    serialized_certification_report_sha256,
)
from iroll.topology.homfly_certification import (
    full_homfly_pt_evaluation_certification_report_audit,
)
from iroll.topology.polynomial import parse_multivariate_laurent_polynomial


TREFOIL_PD = [
    [1, 4, 2, 5],
    [3, 6, 4, 1],
    [5, 2, 6, 3],
]

_FULL_ALEXANDER_TEST_PACK_CACHE: dict | None = None
_FULL_HOMFLY_TEST_PACK_CACHE: dict | None = None


def _full_homfly_certification_pack() -> dict:
    global _FULL_HOMFLY_TEST_PACK_CACHE
    if _FULL_HOMFLY_TEST_PACK_CACHE is not None:
        return deepcopy(_FULL_HOMFLY_TEST_PACK_CACHE)

    content_by_title = {
        str(record["title"]): (
            "\n".join(str(value) for value in record["required_phrases"])
            if role == "definition"
            else str(record["expected_math_source"])
        )
        for role, record in _KNOT_ATLAS_PINNED_HOMFLY_SOURCES.items()
    }
    byte_count_by_title = {
        str(record["title"]): int(record["byte_count"])
        for record in _KNOT_ATLAS_PINNED_HOMFLY_SOURCES.values()
    }

    def fetch(url, expected_sha256, *, timeout, title=None, revision_id=None):
        content = content_by_title[str(title)]
        return {
            "title": title,
            "revision_id": revision_id,
            "url": url,
            "expected_sha256": expected_sha256,
            "actual_sha256": expected_sha256,
            "byte_count": byte_count_by_title[str(title)],
            "fetched": True,
            "sha256_verified": True,
            "error": None,
            "_content": content,
            "_bytes": content.encode("utf-8"),
        }

    with patch("iroll.cli._fetch_url_sha256_witness", fetch):
        report = _homfly_full_certification_report_command(
            argparse.Namespace(network_timeout=1.0, fail_on_not_certified=True)
        )
    assert report.pop("_exit_code") == 0
    report_bytes = (dump_report(report) + "\n").encode("utf-8")
    report_sha256 = sha256(report_bytes).hexdigest()
    report_canonical_sha256 = canonical_json_sha256(report)
    report_audit = full_homfly_pt_evaluation_certification_report_audit(report)
    assert report_audit["certified"] is True
    report_url = "https://evidence.iroll.dev/certification/full-homfly.json"
    source_witnesses = report["source_witnesses"]
    producer_checks = {
        "local_report_replay_audit_certified": True,
        "local_report_canonical_sha256_available": True,
        "local_report_raw_sha256_matches_deterministic_serializer": True,
        "embedded_certification_report_available": True,
        "published_report_fetched": True,
        "published_report_sha256_matches_local_bytes": True,
        "published_report_json_matches_embedded_report": True,
        "published_report_canonical_sha256_matches_local_report": True,
    }
    pack = {
        "artifact_schema_version": 1,
        "artifact_kind": "full_homfly_pt_evaluation_certification_pack",
        "claim_scope": "full_homfly_pt_evaluation",
        "full_homfly_pt_evaluation_certified": True,
        "arbitrary_signed_pd_coverage_certified": True,
        "external_table_normalization_certified": True,
        "skein_relation_certified": True,
        "registered_fixture_regression_certified": True,
        "counterexample_count": 0,
        "certification_report_url": report_url,
        "certification_report_sha256": report_sha256,
        "certification_report_raw_sha256": report_sha256,
        "certification_report_canonical_sha256": report_canonical_sha256,
        "certification_report": report,
        "published_report_canonical_sha256": report_canonical_sha256,
        "published_report_json_matches_embedded": True,
        "external_table_source_urls": [
            row["url"] for row in source_witnesses
        ],
        "external_table_source_sha256s": [
            row["actual_sha256"] for row in source_witnesses
        ],
        "certification_report_artifact_kind": report["artifact_kind"],
        "certification_report_method": report["method"],
        "certification_report_algorithm_scope": report["algorithm_scope"],
        "certification_report_case_count": report["case_count"],
        "certification_report_total_state_count": report["total_state_count"],
        "certification_report_total_transition_count": report[
            "total_transition_count"
        ],
        "certification_report_total_terminal_count": report[
            "total_terminal_count"
        ],
        "certification_report_implementation_source_sha256": report[
            "implementation_source_sha256"
        ],
        "certification_report_implementation_bundle_sha256": report[
            "implementation_bundle_sha256"
        ],
        "certification_report_replay_audit": report_audit,
        "published_report_witness": {
            "title": "published full HOMFLY-PT evaluation certification report",
            "revision_id": None,
            "url": report_url,
            "expected_sha256": report_sha256,
            "actual_sha256": report_sha256,
            "byte_count": len(report_bytes),
            "fetched": True,
            "sha256_verified": True,
            "error": None,
        },
        "producer_checks": producer_checks,
        "producer_check_count": len(producer_checks),
        "producer_failed_check_count": 0,
        "producer_failed_checks": [],
        "template_placeholder": False,
        "completion_claimed": True,
    }
    _FULL_HOMFLY_TEST_PACK_CACHE = deepcopy(pack)
    return pack


def test_exact_multivariate_laurent_gcd_preserves_integer_content_and_clears_units() -> None:
    variables = ("t1", "t2")
    inputs = [
        parse_multivariate_laurent_polynomial(
            "2*t1^-1 - 2*t2",
            variables=variables,
        ),
        parse_multivariate_laurent_polynomial(
            "4*t1^-1 - 4*t2",
            variables=variables,
        ),
    ]

    polynomial, certificate = exact_multivariate_laurent_gcd(
        inputs,
        variables=variables,
    )

    assert polynomial.format() == "2 - 2*t1*t2"
    assert certificate["coefficient_domain"] == "ZZ"
    assert certificate["integer_content_preserved"] is True
    assert certificate["laurent_monomial_units_cleared"] is True
    assert certificate["candidate_divides_all_nonzero_inputs"] is True
    assert certificate["quotient_gcd_polynomial"] == "1"
    assert certificate["candidate_is_exact_gcd"] is True


def test_exact_multivariate_laurent_gcd_empty_family_is_zero_ideal() -> None:
    polynomial, certificate = exact_multivariate_laurent_gcd(
        [],
        variables=("u", "v"),
    )

    assert polynomial.format() == "0"
    assert certificate["input_count"] == 0
    assert certificate["empty_input_family"] is True
    assert certificate["zero_ideal_certified"] is True
    assert certificate["exact_gcd_certification_basis"] == (
        "no_admissible_maximal_minors"
    )


@pytest.mark.parametrize(
    ("notation", "expected", "expected_minor_count"),
    [
        ("L2a1", "1", 4),
        ("3_1", "1 - t + t^2", 9),
        ("4_1", "1 - 3t + t^2", 16),
    ],
)
def test_uncapped_exact_alexander_path_enumerates_every_maximal_minor(
    notation: str,
    expected: str,
    expected_minor_count: int,
) -> None:
    fixture = get_diagram_fixture(notation)
    result = multivariable_alexander_exact_from_oriented_pd(
        fixture.diagram(),
        fixture.orientation(),
        variables=fixture.expected_multivariable_alexander_variables,
    )

    assert result["skipped"] is False
    assert result["resource_caps"] is None
    assert result["multivariable_alexander_polynomial"] == expected
    assert result["expected_maximal_minor_count"] == expected_minor_count
    assert result["enumerated_maximal_minor_count"] == expected_minor_count
    assert result["all_maximal_minors_enumerated"] is True
    assert result["exact_gcd_certificate"]["quotient_gcd_polynomial"] == "1"
    assert result["full_admissible_minor_normalization_certified"] is True
    assert result["full_invariant_certified"] is True
    assert multivariable_alexander_exact_result_audit(result)["certified"] is True


def test_exact_alexander_supports_rectangular_wirtinger_fox_zero_ideal() -> None:
    diagram = build_planar_diagram(
        [[1, 3, 2, 4], [2, 4, 1, 3]],
        signs=[1, -1],
        component_count=2,
        name="two-component-r2-unlink",
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(1, 2, 3, 4),
            PDCrossingOrientation(2, 1, 4, 3),
        ),
        edge_components=((1, 0), (2, 0), (3, 1), (4, 1)),
    )

    assert orientation.validation_issues(diagram) == []
    result = multivariable_alexander_exact_from_oriented_pd(
        diagram,
        orientation,
        variables=("u", "v"),
    )

    assert result["skipped"] is False
    assert result["admissible_minor_summary"]["matrix_size"] == [2, 3]
    assert result["admissible_minor_summary"]["target_size"] == 2
    assert result["expected_maximal_minor_count"] == 3
    assert result["enumerated_maximal_minor_count"] == 3
    assert result["all_maximal_minors_enumerated"] is True
    assert result["all_maximal_minors_zero"] is True
    assert result["multivariable_alexander_polynomial"] == "0"
    assert result["zero_ideal_certified"] is True
    certificate = result["exact_gcd_certificate"]
    assert certificate["all_inputs_zero"] is True
    assert certificate["zero_ideal_certified"] is True
    assert certificate["quotient_gcd_certified"] is False
    assert certificate["quotient_gcd_polynomial"] is None
    assert result["full_admissible_minor_normalization_certified"] is True
    assert result["full_invariant_certified"] is True
    assert multivariable_alexander_exact_result_audit(result)["certified"] is True


def test_exact_alexander_rejects_duplicate_component_ids_across_cycles() -> None:
    diagram = build_planar_diagram(
        [[1, 3, 2, 4], [2, 4, 1, 3]],
        signs=[1, -1],
        component_count=2,
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(1, 2, 3, 4),
            PDCrossingOrientation(2, 1, 4, 3),
        ),
        edge_components=((1, 0), (2, 0), (3, 0), (4, 0)),
    )

    # The general PD validation permits conservative component-count metadata,
    # but exact Alexander conversion must never collapse distinct cycles into
    # one abelianization variable.
    assert orientation.validation_issues(diagram) == []
    result = multivariable_alexander_exact_from_oriented_pd(
        diagram,
        orientation,
        variables=("u", "v"),
    )

    assert result["skipped"] is True
    assert result["full_admissible_minor_normalization_certified"] is False
    assert result["full_invariant_certified"] is False
    assert "unique contiguous component ids" in result["failure_reason"]


def test_exact_alexander_invalid_presentation_fails_closed() -> None:
    presentation = WirtingerPresentation(
        relations=(((99, 1),),),
        generator_components=(0,),
        variables=("t",),
    )

    result = multivariable_alexander_exact_from_presentation(presentation)

    assert result["skipped"] is True
    assert result["method"] == "skipped"
    assert result["full_admissible_minor_normalization_certified"] is False
    assert result["full_invariant_certified"] is False
    assert result["failure_reason"].startswith("ValueError:")


def test_exact_alexander_high_deficiency_empty_minor_family_is_zero_ideal() -> None:
    presentation = WirtingerPresentation(
        relations=(),
        generator_components=(0, 1),
        variables=("u", "v"),
    )

    result = multivariable_alexander_exact_from_presentation(presentation)

    assert result["skipped"] is False
    assert result["admissible_minor_summary"]["matrix_size"] == [0, 2]
    assert result["admissible_minor_summary"]["target_size"] == 1
    assert result["expected_maximal_minor_count"] == 0
    assert result["enumerated_maximal_minor_count"] == 0
    assert result["multivariable_alexander_polynomial"] == "0"
    assert result["zero_ideal_certified"] is True
    certificate = result["exact_gcd_certificate"]
    assert certificate["empty_input_family"] is True
    assert certificate["exact_gcd_certification_basis"] == (
        "no_admissible_maximal_minors"
    )
    assert multivariable_alexander_exact_result_audit(result)["certified"] is True


def test_exact_alexander_one_generator_empty_presentation_has_zero_by_zero_minor() -> None:
    presentation = WirtingerPresentation(
        relations=(),
        generator_components=(0,),
        variables=("t",),
    )

    result = multivariable_alexander_exact_from_presentation(presentation)

    assert result["skipped"] is False
    assert result["admissible_minor_summary"]["matrix_size"] == [0, 1]
    assert result["admissible_minor_summary"]["target_size"] == 0
    assert result["expected_maximal_minor_count"] == 1
    assert result["enumerated_maximal_minor_count"] == 1
    assert result["square_minors"]["minors"][0]["rows"] == []
    assert result["square_minors"]["minors"][0]["columns"] == []
    assert result["multivariable_alexander_polynomial"] == "1"
    assert result["zero_ideal_certified"] is False
    assert result["exact_gcd_certificate"]["empty_input_family"] is False
    assert multivariable_alexander_exact_result_audit(result)["certified"] is True


def test_exact_alexander_rejects_invalid_component_abelianization() -> None:
    presentation = WirtingerPresentation(
        relations=(((0, 1),),),
        generator_components=(0,),
        variables=("t",),
    )

    result = multivariable_alexander_exact_from_presentation(presentation)

    assert result["skipped"] is True
    assert result["full_invariant_certified"] is False
    assert result["failure_reason"] == (
        "fox_abelianization_or_fundamental_identity_failed"
    )
    certificate = result["fox_fundamental_identity_certificate"]
    assert certificate["all_fox_fundamental_identities_hold"] is True
    assert certificate["all_relators_abelianize_to_identity"] is False
    assert certificate["certified"] is False


@pytest.mark.parametrize(
    ("component_count", "expected", "zero_ideal"),
    [(1, "1", False), (2, "0", True), (3, "0", True)],
)
def test_exact_alexander_certifies_zero_crossing_unlink_terminals(
    component_count: int,
    expected: str,
    zero_ideal: bool,
) -> None:
    diagram = build_planar_diagram([], component_count=component_count)
    orientation = PDOrientation(())
    variables = tuple(f"t{index + 1}" for index in range(component_count))

    result = multivariable_alexander_exact_from_oriented_pd(
        diagram,
        orientation,
        variables=variables,
    )

    assert result["skipped"] is False
    assert result["method"] == "zero_crossing_unlink_exact_normalization"
    assert result["multivariable_alexander_polynomial"] == expected
    assert result["zero_ideal_certified"] is zero_ideal
    assert result["expected_maximal_minor_count"] == 0
    assert result["enumerated_maximal_minor_count"] == 0
    assert result["all_maximal_minors_enumerated"] is True
    assert result["full_admissible_minor_normalization_certified"] is True
    assert result["full_invariant_certified"] is True
    assert multivariable_alexander_exact_result_audit(result)["certified"] is True


def test_exact_alexander_zero_crossing_without_component_count_fails_closed() -> None:
    result = multivariable_alexander_exact_from_oriented_pd(
        build_planar_diagram([]),
        PDOrientation(()),
    )

    assert result["skipped"] is True
    assert result["full_admissible_minor_normalization_certified"] is False
    assert result["full_invariant_certified"] is False
    assert "positive explicit component_count" in result["failure_reason"]


def test_exact_alexander_split_free_component_allows_nonconsecutive_cycle_ids() -> None:
    diagram = build_planar_diagram(
        [[1, 3, 2, 4], [2, 4, 1, 3]],
        signs=[1, -1],
        component_count=3,
        name="two-crossing-cycles-plus-free-circle",
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(1, 2, 3, 4),
            PDCrossingOrientation(2, 1, 4, 3),
        ),
        edge_components=((1, 0), (2, 0), (3, 2), (4, 2)),
    )

    assert orientation.validation_issues(diagram) == []
    result = multivariable_alexander_exact_from_oriented_pd(
        diagram,
        orientation,
        variables=("u", "v", "w"),
    )

    assert result["skipped"] is False
    assert result["method"] == "split_free_component_exact_normalization"
    assert result["exact_algorithm"] == (
        "split_free_component_exact_normalization_v1"
    )
    assert result["represented_component_ids"] == [0, 2]
    assert result["free_component_ids"] == [1]
    assert result["split_free_component_count"] == 1
    assert result["multivariable_alexander_polynomial"] == "0"
    assert result["zero_ideal_certified"] is True
    assert result["full_admissible_minor_normalization_certified"] is True
    assert result["full_invariant_certified"] is True
    assert multivariable_alexander_exact_result_audit(result)["certified"] is True


def test_exact_alexander_split_free_component_infers_fully_absent_cycle_map() -> None:
    diagram = build_planar_diagram(
        [[1, 3, 2, 4], [2, 4, 1, 3]],
        signs=[1, -1],
        component_count=3,
        name="implicit-two-cycles-plus-free-circle",
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(1, 2, 3, 4),
            PDCrossingOrientation(2, 1, 4, 3),
        ),
    )

    result = multivariable_alexander_exact_from_oriented_pd(
        diagram,
        orientation,
        variables=("u", "v", "w"),
    )

    assert result["skipped"] is False
    assert result["method"] == "split_free_component_exact_normalization"
    assert result["represented_component_ids"] == [0, 1]
    assert result["free_component_ids"] == [2]
    assert multivariable_alexander_exact_result_audit(result)["certified"] is True


@pytest.mark.parametrize(
    "edge_components",
    [
        ((1, 0), (2, 0), (3, 0), (4, 0)),
        ((1, 0), (2, 0), (3, 3), (4, 3)),
        ((1, 0), (2, 0), (3, 2)),
    ],
)
def test_exact_alexander_split_free_component_rejects_invalid_cycle_maps(
    edge_components: tuple[tuple[int, int], ...],
) -> None:
    diagram = build_planar_diagram(
        [[1, 3, 2, 4], [2, 4, 1, 3]],
        signs=[1, -1],
        component_count=3,
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(1, 2, 3, 4),
            PDCrossingOrientation(2, 1, 4, 3),
        ),
        edge_components=edge_components,
    )

    result = multivariable_alexander_exact_from_oriented_pd(
        diagram,
        orientation,
        variables=("u", "v", "w"),
    )

    assert result["skipped"] is True
    assert result["full_admissible_minor_normalization_certified"] is False
    assert result["full_invariant_certified"] is False


def test_exact_alexander_split_free_component_audit_rejects_id_tampering() -> None:
    trefoil = get_diagram_fixture("3_1")
    source_diagram = trefoil.diagram()
    diagram = PlanarDiagram(
        source_diagram.crossings,
        component_count=2,
        name="trefoil-plus-free-circle",
    )
    source_orientation = trefoil.orientation()
    orientation = PDOrientation(
        source_orientation.crossings,
        edge_components=tuple((label, 1) for label in diagram.edge_labels),
    )
    result = multivariable_alexander_exact_from_oriented_pd(
        diagram,
        orientation,
        variables=("u", "v"),
    )
    tampered = dict(result)
    tampered["free_component_ids"] = [1]

    audit = multivariable_alexander_exact_result_audit(tampered)

    assert audit["certified"] is False
    assert audit["checks"]["terminal_certificate_semantics"] is False


def test_exact_alexander_oriented_pd_unexpected_conversion_error_fails_closed() -> None:
    class ExplodingVariables:
        def __iter__(self):
            raise RuntimeError("synthetic variable iterator failure")

    trefoil = get_diagram_fixture("3_1")
    result = multivariable_alexander_exact_from_oriented_pd(
        trefoil.diagram(),
        trefoil.orientation(),
        variables=ExplodingVariables(),
    )

    assert result["skipped"] is True
    assert result["full_admissible_minor_normalization_certified"] is False
    assert result["full_invariant_certified"] is False
    assert result["failure_reason"].startswith("RuntimeError:")


def test_exact_alexander_result_audit_replays_oriented_pd_bridge() -> None:
    trefoil = get_diagram_fixture("3_1")
    result = multivariable_alexander_exact_from_oriented_pd(
        trefoil.diagram(),
        trefoil.orientation(),
        variables=trefoil.expected_multivariable_alexander_variables,
    )
    tampered = dict(result)
    tampered["diagram"] = get_diagram_fixture("4_1").diagram().to_dict()

    audit = multivariable_alexander_exact_result_audit(tampered)

    assert audit["certified"] is False
    assert audit["checks"]["oriented_pd_payload_complete"] is True
    assert audit["checks"]["oriented_pd_presentation_matches"] is False
    assert "oriented_pd_presentation_matches" in audit["failed_checks"]


@pytest.mark.parametrize(
    ("field", "tampered_value"),
    [
        ("exact_algorithm", "tampered_exact_algorithm"),
        ("candidate_polynomials", ["tampered"]),
        ("variables", ["tampered"]),
        ("resource_caps", {"max_minors": 1}),
        ("requires_normalization", True),
    ],
)
def test_exact_alexander_result_audit_rejects_top_level_metadata_tampering(
    field: str,
    tampered_value: object,
) -> None:
    trefoil = get_diagram_fixture("3_1")
    result = multivariable_alexander_exact_from_oriented_pd(
        trefoil.diagram(),
        trefoil.orientation(),
        variables=trefoil.expected_multivariable_alexander_variables,
    )
    tampered = dict(result)
    tampered[field] = tampered_value

    audit = multivariable_alexander_exact_result_audit(tampered)

    assert audit["certified"] is False
    if field == "exact_algorithm":
        assert audit["checks"]["exact_algorithm_label"] is False
    else:
        assert audit["checks"]["recomputed_fields_match"] is False


def test_signed_pd_round_trips_through_json_payload() -> None:
    diagram = build_planar_diagram(
        TREFOIL_PD,
        signs=[-1, -1, -1],
        component_count=1,
        name="left-handed-trefoil",
    )

    payload = diagram.to_dict()
    restored = PlanarDiagram.from_dict(payload)

    assert restored.to_dict() == payload
    assert restored.crossing_count == 3
    assert restored.writhe == -3


def test_kauffman_bracket_and_jones_for_trefoil_pd() -> None:
    diagram = build_planar_diagram(TREFOIL_PD, signs=[-1, -1, -1], component_count=1)

    assert kauffman_bracket(diagram) == {7: 1, 3: -1, -5: -1}
    assert jones_polynomial_from_pd(diagram) == "-t^-4 + t^-3 + t^-1"


def test_jones_for_hopf_pd() -> None:
    diagram = build_planar_diagram(
        [
            [1, 4, 2, 3],
            [3, 2, 4, 1],
        ],
        signs=[1, -1],
        component_count=2,
        name="hopf-link",
    )

    result = polynomial_result_from_pd(diagram)

    assert result["method"] == "kauffman_bracket_state_sum"
    assert result["jones_polynomial"] == "-t^-1 - t"
    assert result["skipped"] is False


def test_pd_validation_rejects_unpaired_edges() -> None:
    with pytest.raises(ValueError, match="exactly twice"):
        build_planar_diagram([[1, 2, 3, 4]])


def test_pd_crossing_switch_and_smoothing_mutations() -> None:
    diagram = build_planar_diagram(TREFOIL_PD, signs=[-1, -1, -1], component_count=1)

    switched = diagram.switch_crossing(0)
    a_smoothed = diagram.smooth_crossing(0, smoothing="A")
    b_smoothed = diagram.smooth_crossing(0, smoothing="B")

    assert switched.crossings[0].sign == 1
    assert switched.writhe == -1
    assert a_smoothed.crossing_count == 2
    assert b_smoothed.crossing_count == 2
    assert a_smoothed.edge_labels == [1, 2, 3, 4]
    assert b_smoothed.edge_labels == [1, 2, 3, 4]


def test_signed_pd_mirror_mutation_is_orientation_preserving_involution() -> None:
    diagram = get_diagram_fixture("3_1").diagram()
    orientation = PDOrientation.from_signed_pd_roles(diagram)

    mirrored, mirrored_orientation = mirror_signed_pd(diagram, orientation=orientation)
    restored, restored_orientation = mirror_signed_pd(
        mirrored,
        orientation=mirrored_orientation,
    )

    assert mirrored.writhe == -diagram.writhe
    assert mirrored.pd_code() == diagram.pd_code()
    assert [crossing.sign for crossing in mirrored.crossings] == [
        -crossing.sign for crossing in diagram.crossings
    ]
    assert mirrored_orientation.crossings == orientation.crossings
    assert mirrored_orientation.validation_issues(mirrored) == []
    assert restored.canonical_key() == diagram.canonical_key()
    assert restored_orientation.crossings == orientation.crossings
    assert restored_orientation.validation_issues(restored) == []


def test_pd_orientation_round_trip_and_oriented_smoothing() -> None:
    diagram = build_planar_diagram(
        [[1, 4, 2, 3], [3, 2, 4, 1]],
        signs=[1, -1],
        component_count=2,
        name="oriented-hopf",
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(
                under_in=1,
                under_out=2,
                over_in=4,
                over_out=3,
            ),
            PDCrossingOrientation(
                under_in=3,
                under_out=4,
                over_in=2,
                over_out=1,
            ),
        ),
        edge_components=((1, 0), (2, 0), (3, 1), (4, 1)),
    )

    payload = orientation.to_dict()
    restored = PDOrientation.from_dict(payload)
    smoothed, smoothed_orientation = diagram.oriented_smooth_crossing_with_orientation(
        0,
        orientation=restored,
    )

    assert restored.to_dict() == payload
    assert smoothed.crossing_count == 1
    assert smoothed_orientation.validation_issues(smoothed) == []
    assert len(smoothed_orientation.crossings) == 1


def test_pd_orientation_can_be_inferred_from_signed_position_roles() -> None:
    diagram = build_planar_diagram(
        [[1, 4, 2, 3], [3, 2, 4, 1]],
        signs=[1, -1],
        component_count=2,
        name="oriented-hopf",
    )

    orientation = PDOrientation.from_signed_pd_roles(diagram)

    assert orientation.convention == "signed_pd_position_roles_v1"
    assert orientation.validation_issues(diagram) == []
    assert orientation.crossings[0].under_in == 1
    assert orientation.crossings[0].under_out == 2
    assert orientation.crossings[0].over_in == 4
    assert orientation.crossings[0].over_out == 3
    assert dict(orientation.edge_components) == {1: 0, 2: 0, 3: 1, 4: 1}


def test_pd_orientation_reports_role_permutation_candidates() -> None:
    hopf = build_planar_diagram(
        [[1, 4, 2, 3], [3, 2, 4, 1]],
        signs=[1, -1],
        component_count=2,
        name="oriented-hopf",
    )

    candidates = PDOrientation.role_permutation_candidates(hopf)

    assert candidates
    default = next(
        candidate
        for candidate in candidates
        if tuple(candidate["role_order"]) == (0, 1, 2, 3)
    )
    assert default["strict"] is True
    assert default["component_count_matches"] is True
    assert default["component_count"] == 2
    assert default["orientation"].convention == "signed_pd_position_roles_v1"


def test_pd_orientation_reports_figure_eight_role_permutation_blocker() -> None:
    fixture = get_diagram_fixture("4_1")
    figure_eight = fixture.diagram()
    default_orientation = PDOrientation.from_signed_pd_roles(figure_eight)
    explicit_orientation = fixture.orientation()

    strict_candidates = PDOrientation.role_permutation_candidates(figure_eight)
    diagnostic_candidates = PDOrientation.role_permutation_candidates(
        figure_eight,
        include_component_mismatches=True,
    )
    local_summary = PDOrientation.local_role_assignment_summary(
        figure_eight,
        max_samples=2,
    )

    assert any(
        "incoming" in issue
        for issue in default_orientation.validation_issues(figure_eight)
    )
    assert strict_candidates == ()
    assert len(diagnostic_candidates) == 8
    assert {candidate["component_count"] for candidate in diagnostic_candidates} == {3}
    assert not any(candidate["component_count_matches"] for candidate in diagnostic_candidates)
    assert not any(candidate["strict"] for candidate in diagnostic_candidates)
    assert local_summary["candidate_count"] == 1408
    assert local_summary["sample_count"] == 2
    assert local_summary["truncated"] is True
    assert all(sample["strict"] for sample in local_summary["samples"])
    assert {sample["component_count"] for sample in local_summary["samples"]} == {1}
    assert explicit_orientation.validation_issues(figure_eight) == []
    assert explicit_orientation.convention == "signed_pd_fixture_explicit_role_orders_v1"
    assert explicit_orientation.oriented_component_traversals(figure_eight) == (
        {"component": 0, "edges": [1, 2, 3, 4, 5, 6, 7, 8], "length": 8},
    )


def test_pd_orientation_rejects_explicit_cycle_count_mismatch() -> None:
    figure_eight = get_diagram_fixture("4_1").diagram()
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(under_in=4, under_out=2, over_in=5, over_out=1),
            PDCrossingOrientation(under_in=8, under_out=6, over_in=1, over_out=5),
            PDCrossingOrientation(under_in=6, under_out=3, over_in=7, over_out=4),
            PDCrossingOrientation(under_in=2, under_out=7, over_in=3, over_out=8),
        ),
        edge_components=tuple((label, 0) for label in figure_eight.edge_labels),
    )

    assert any(
        "component cycle count" in issue
        for issue in orientation.validation_issues(figure_eight)
    )


def test_pd_orientation_traverses_oriented_components() -> None:
    hopf = build_planar_diagram(
        [[1, 4, 2, 3], [3, 2, 4, 1]],
        signs=[1, -1],
        component_count=2,
        name="oriented-hopf",
    )
    trefoil = get_diagram_fixture("3_1").diagram()

    hopf_orientation = PDOrientation.from_signed_pd_roles(hopf)
    trefoil_orientation = PDOrientation.from_signed_pd_roles(trefoil)

    assert hopf_orientation.oriented_successor_map(hopf) == {
        1: 2,
        2: 1,
        3: 4,
        4: 3,
    }
    assert hopf_orientation.oriented_component_traversals(hopf) == (
        {"component": 0, "edges": [1, 2], "length": 2},
        {"component": 1, "edges": [3, 4], "length": 2},
    )
    assert trefoil_orientation.oriented_component_traversals(trefoil) == (
        {"component": 0, "edges": [1, 2, 3, 4, 5, 6], "length": 6},
    )


def test_pd_orientation_rejects_crossing_role_label_mismatch() -> None:
    diagram = build_planar_diagram(
        [[1, 4, 2, 3], [3, 2, 4, 1]],
        signs=[1, -1],
        component_count=2,
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(
                under_in=1,
                under_out=2,
                over_in=4,
                over_out=99,
            ),
            PDCrossingOrientation(
                under_in=3,
                under_out=4,
                over_in=2,
                over_out=1,
            ),
        ),
        edge_components=((1, 0), (2, 0), (3, 1), (4, 1)),
    )

    with pytest.raises(ValueError, match="labels must match"):
        diagram.oriented_smooth_crossing(0, orientation=orientation)


def test_pd_orientation_rejects_invalid_edge_flow_counts() -> None:
    diagram = build_planar_diagram(
        [[1, 4, 2, 3], [3, 2, 4, 1]],
        signs=[1, -1],
        component_count=2,
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(
                under_in=1,
                under_out=2,
                over_in=4,
                over_out=3,
            ),
            PDCrossingOrientation(
                under_in=3,
                under_out=4,
                over_in=1,
                over_out=2,
            ),
        ),
        edge_components=((1, 0), (2, 0), (3, 1), (4, 1)),
    )

    assert any("incoming" in issue for issue in orientation.validation_issues(diagram))
    with pytest.raises(ValueError, match="incoming"):
        orientation.oriented_successor_map(diagram)


def test_pd_orientation_rejects_component_assignment_mismatch() -> None:
    diagram = build_planar_diagram(
        [[1, 4, 2, 3], [3, 2, 4, 1]],
        signs=[1, -1],
        component_count=2,
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(
                under_in=1,
                under_out=2,
                over_in=4,
                over_out=3,
            ),
            PDCrossingOrientation(
                under_in=3,
                under_out=4,
                over_in=2,
                over_out=1,
            ),
        ),
        edge_components=((1, 0), (2, 1), (3, 1), (4, 1)),
    )

    assert any(
        "constant along each oriented component" in issue
        for issue in orientation.validation_issues(diagram)
    )


def test_pd_canonical_key_and_split_components() -> None:
    trefoil = build_planar_diagram(TREFOIL_PD, signs=[-1, -1, -1], component_count=1)
    hopf = build_planar_diagram(
        [[1, 4, 2, 3], [3, 2, 4, 1]],
        signs=[1, -1],
        component_count=2,
    )

    split = disjoint_union([trefoil, hopf], name="split-union")

    assert trefoil.canonical_key() == trefoil.relabel_edges().canonical_key()
    assert split.is_split() is True
    assert len(split.edge_component_sets()) == 2


def test_large_pd_jones_skips_instead_of_expanding_exponentially() -> None:
    crossings = []
    label_count = 26
    for index in range(13):
        base = 2 * index
        crossings.append(
            [
                base + 1,
                base + 2,
                (base + 2) % label_count + 1,
                (base + 3) % label_count + 1,
            ]
        )
    diagram = build_planar_diagram(crossings, signs=[1] * len(crossings))

    result = polynomial_result_from_pd(diagram, max_crossings=12)

    assert result["jones_polynomial"] is None
    assert result["skipped"] is True


def test_standard_diagram_fixture_conventions_are_registered() -> None:
    fixtures = {fixture.notation: fixture for fixture in standard_diagram_fixtures()}

    assert set(fixtures) >= {"0_1", "L0a1", "L2a1", "3_1", "4_1", "L5a1", "L6a4"}
    assert fixtures["L5a1"].has_pd_code is True
    assert fixtures["L5a1"].pd_code is not None
    assert fixtures["L5a1"].signs is None
    assert fixtures["L5a1"].gauss_code == (
        (1, -4, 5, -3),
        (3, -1, 2, -5, 4, -2),
    )
    assert fixtures["L6a4"].component_count == 3
    assert fixtures["L6a4"].has_pd_code is True
    assert fixtures["L6a4"].pd_code is not None
    assert fixtures["L6a4"].signs is None
    assert fixtures["L6a4"].gauss_code == (
        (1, -6, 5, -3),
        (4, -1, 2, -5),
        (6, -4, 3, -2),
    )


def test_unsigned_source_table_metadata_matches_link_table() -> None:
    from iroll.topology.knot_table import lookup_link

    for notation, link_type in (
        ("L5a1", "whitehead_link"),
        ("L6a4", "borromean_rings"),
    ):
        fixture = get_diagram_fixture(notation)
        entry = lookup_link(link_type=link_type)
        payload = entry.to_dict()

        assert payload["notation"] == notation
        assert payload["source_table_invariant_audit_available"] is True
        assert payload["source_table_jones"] == fixture.source_table_jones
        assert (
            payload["source_table_jones_iroll_normalized"]
            == fixture.source_table_jones_iroll_normalized
        )
        assert payload["source_table_homfly"] == fixture.source_table_homfly
        assert (
            payload["source_table_homfly_iroll_normalized"]
            == fixture.source_table_homfly_iroll_normalized
        )
        assert (
            payload["source_table_multivariable_alexander"]
            == fixture.source_table_multivariable_alexander
        )
        assert (
            payload["source_table_multivariable_alexander_numerator"]
            == fixture.source_table_multivariable_alexander_numerator
        )


def test_unsigned_whitehead_fixture_exposes_orientation_diagnostics() -> None:
    fixture = get_diagram_fixture("L5a1")

    with pytest.raises(ValueError, match="signed PD"):
        fixture.diagram()

    diagnostic_diagram = fixture.diagram_with_signs()
    diagnostics = fixture.orientation_diagnostics(max_samples=2)

    assert fixture.has_pd_code is True
    assert fixture.has_signed_pd is False
    assert diagnostic_diagram.crossing_count == 5
    assert [crossing.sign for crossing in diagnostic_diagram.crossings] == [1] * 5
    assert diagnostics["method"] == "diagram_fixture_orientation_diagnostics"
    assert diagnostics["has_signed_pd"] is False
    assert diagnostics["strict_candidate_count"] == 0
    assert diagnostics["flow_candidate_count"] == 8
    assert {candidate["component_count"] for candidate in diagnostics["flow_candidates"]} == {
        3,
        4,
    }
    local_summary = diagnostics["local_orientation_assignment_summary"]
    assert local_summary["skipped"] is False
    assert local_summary["search_strategy"] == "flow_pruned_bounded"
    assert local_summary["assignment_count"] == 24**5
    assert local_summary["flow_assignment_count"] == 26_624
    assert local_summary["candidate_count"] == 12_800
    assert local_summary["sample_count"] == 2
    assert local_summary["samples"][0]["strict"] is True
    assert local_summary["samples"][0]["component_count"] == 2
    assert "diagnostic signs" in diagnostics["notes"][1]


def test_unsigned_whitehead_fixture_matches_source_gauss_code_orientation() -> None:
    fixture = get_diagram_fixture("L5a1")

    diagnostics = fixture.gauss_code_orientation_diagnostics(
        max_orientation_samples=64,
    )

    assert diagnostics["method"] == "diagram_fixture_gauss_code_orientation_diagnostics"
    assert diagnostics["matched"] is True
    assert diagnostics["skipped"] is False
    assert diagnostics["target_gauss_code"] == [
        [1, -4, 5, -3],
        [3, -1, 2, -5, 4, -2],
    ]
    assert diagnostics["checked_sample_count"] == 64
    assert diagnostics["matching_sample_count"] == 2

    first = next(
        match
        for match in diagnostics["matches"]
        if match["encoded_gauss_code"] == diagnostics["target_gauss_code"]
    )
    assert first["sample_index"] == 6
    assert first["strand_sign_convention"] == "positive_entries_mark_over_strand"
    assert first["encoded_gauss_code"] == diagnostics["target_gauss_code"]
    assert first["role_orders"] == [
        [0, 1, 2, 3],
        [0, 1, 2, 3],
        [0, 1, 2, 3],
        [0, 3, 2, 1],
        [0, 3, 2, 1],
    ]
    assert first["traversals"] == (
        {"component": 0, "edges": [1, 2, 3, 4], "length": 4},
        {"component": 1, "edges": [5, 6, 7, 8, 9, 10], "length": 6},
    )
    assert diagnostics["notes"][0].startswith("Gauss-code matching")


def test_unsigned_borromean_fixture_matches_source_gauss_code_orientation() -> None:
    fixture = get_diagram_fixture("L6a4")

    with pytest.raises(ValueError, match="signed PD"):
        fixture.diagram()

    diagnostic_diagram = fixture.diagram_with_signs()
    diagnostics = fixture.gauss_code_orientation_diagnostics(
        max_orientation_samples=64,
    )

    assert fixture.has_pd_code is True
    assert fixture.has_signed_pd is False
    assert diagnostic_diagram.crossing_count == 6
    assert [crossing.sign for crossing in diagnostic_diagram.crossings] == [1] * 6
    assert diagnostics["method"] == "diagram_fixture_gauss_code_orientation_diagnostics"
    assert diagnostics["matched"] is True
    assert diagnostics["target_gauss_code"] == [
        [1, -6, 5, -3],
        [4, -1, 2, -5],
        [6, -4, 3, -2],
    ]
    assert diagnostics["checked_sample_count"] == 64
    assert diagnostics["matching_sample_count"] == 1

    first = diagnostics["matches"][0]
    assert first["sample_index"] == 56
    assert first["strand_sign_convention"] == "positive_entries_mark_over_strand"
    assert first["encoded_gauss_code"] == diagnostics["target_gauss_code"]
    assert first["role_orders"] == [
        [0, 1, 2, 3],
        [0, 3, 2, 1],
        [0, 3, 2, 1],
        [0, 1, 2, 3],
        [0, 3, 2, 1],
        [0, 1, 2, 3],
    ]
    assert first["traversals"] == (
        {"component": 0, "edges": [1, 2, 3, 4], "length": 4},
        {"component": 1, "edges": [5, 6, 7, 8], "length": 4},
        {"component": 2, "edges": [9, 10, 11, 12], "length": 4},
    )


@pytest.mark.parametrize(
    ("notation", "expected_signs", "expected_role_orders"),
    [
        (
            "L5a1",
            [-1, -1, -1, 1, 1],
            [
                [0, 1, 2, 3],
                [0, 1, 2, 3],
                [0, 1, 2, 3],
                [0, 3, 2, 1],
                [0, 3, 2, 1],
            ],
        ),
        (
            "L6a4",
            [-1, 1, 1, -1, 1, -1],
            [
                [0, 1, 2, 3],
                [0, 3, 2, 1],
                [0, 3, 2, 1],
                [0, 1, 2, 3],
                [0, 3, 2, 1],
                [0, 1, 2, 3],
            ],
        ),
    ],
)
def test_knot_atlas_pd_convention_derives_unique_source_assignment(
    notation: str,
    expected_signs: list[int],
    expected_role_orders: list[list[int]],
) -> None:
    audit = get_diagram_fixture(notation).source_pd_convention_assignment_audit()

    assert audit["method"] == (
        "diagram_fixture_source_pd_convention_assignment_audit"
    )
    assert audit["claim_scope"] == "source_pd_convention_assignment_derivation"
    assert audit["signs"] == expected_signs
    assert audit["role_orders"] == expected_role_orders
    assert audit["source_gauss_code_match"] is True
    assert audit["source_gauss_code_exact_match"] is True
    assert audit["orientation_validation_issue_count"] == 0
    assert audit["source_candidate_replay_valid"] is True
    assert audit["assignment_unique_under_source_convention"] is True
    assert audit["failed_checks"] == []
    assert audit["candidate_replay"]["signs"] == expected_signs
    assert audit["candidate_replay"]["role_orders"] == expected_role_orders


def test_unsigned_whitehead_fixture_scans_bounded_signed_candidates() -> None:
    fixture = get_diagram_fixture("L5a1")

    diagnostics = fixture.signed_candidate_diagnostics(
        max_orientation_samples=2,
        target_pairwise_linking=(0,),
        max_candidates=3,
    )

    assert diagnostics["method"] == "diagram_fixture_signed_candidate_diagnostics"
    assert diagnostics["has_signed_pd"] is False
    assert diagnostics["orientation_sample_count"] == 2
    assert diagnostics["all_sign_pattern_count"] == 32
    assert diagnostics["considered_sign_pattern_count"] == 32
    assert diagnostics["matching_candidate_count"] == 32
    assert diagnostics["returned_candidate_count"] == 3
    assert diagnostics["candidate_groups"]
    assert diagnostics["truncated"] is True

    sign_summary = diagnostics["matching_sign_summary"]
    assert sign_summary["method"] == "matching_sign_pattern_summary"
    assert sign_summary["unique_sign_pattern_count"] == 16
    assert sign_summary["reported_sign_pattern_count"] == 16
    assert sign_summary["sign_patterns_truncated"] is False
    assert sign_summary["per_sample_matching_counts"] == [
        {"sample_index": 0, "matching_sign_pattern_count": 16},
        {"sample_index": 1, "matching_sign_pattern_count": 16},
    ]
    assert sign_summary["mirror_pair_count"] == 8
    assert sign_summary["reported_mirror_pair_count"] == 8
    assert sign_summary["mirror_pairs_truncated"] is False
    assert sign_summary["mirror_pair_all_present_count"] == 8
    assert sign_summary["all_mirror_pairs_present"] is True
    assert sign_summary["sign_patterns"][0] == {
        "signs": [-1, -1, -1, -1, 1],
        "matching_sample_indices": [0, 1],
        "matching_candidate_count": 2,
    }
    assert sign_summary["mirror_pairs"][0] == {
        "canonical_signs": [-1, -1, -1, -1, 1],
        "mirrored_signs": [1, 1, 1, 1, -1],
        "canonical_present": True,
        "mirrored_present": True,
        "canonical_sample_indices": [0, 1],
        "mirrored_sample_indices": [0, 1],
    }

    first = diagnostics["candidates"][0]
    assert first["pairwise_linking"] == [0.0]
    assert first["signs"] == [-1, -1, -1, -1, 1]
    assert first["mirror_signs"] == [1, 1, 1, 1, -1]
    assert first["mirror_sign_pattern_present"] is True
    assert first["jones_polynomial"] == "t^-5 - 2t^-4 + t^-3 - 2t^-2 + t^-1 - 1"
    assert first["homfly"]["skipped"] is False
    assert first["homfly"]["method"] == "bounded_recursive_switching_to_descending"
    assert first["homfly_mirror_audit"]["matched"] is True
    assert first["homfly_mirror_audit"]["skipped"] is False
    assert first["multivariable_alexander"]["skipped"] is True
    assert first["multivariable_alexander"]["candidate_polynomials"]
    assert first["multivariable_alexander"]["notes"] == [
        "scanned square Fox minors do not have an immediate unit or consensus gcd",
        "a full multivariate Laurent gcd/admissible-minor implementation is still required",
    ]
    alexander_attempt = first["multivariable_alexander"][
        "common_gcd_attempt_evidence"
    ]
    assert alexander_attempt["method"] == (
        "fox_square_minor_common_gcd_attempt_evidence"
    )
    assert alexander_attempt["claim_scope"] == (
        "bounded_scanned_fox_minor_common_gcd_attempt"
    )
    assert alexander_attempt["status"] == "not_certified"
    assert alexander_attempt["certified"] is False
    assert alexander_attempt["full_invariant_certified"] is False
    assert alexander_attempt["input_polynomial_count"] == 75
    assert alexander_attempt["unique_input_polynomial_count"] == 24
    assert alexander_attempt["common_integer_content"] == 1
    assert alexander_attempt["candidate_methods_attempted"] == [
        "integer_content",
        "univariate_gcd",
        "rank_one_monomial_gcd",
        "direct_scanned_minor_divisor",
        "bounded_multivariate_binomial_factor",
        "bounded_multivariate_root_binomial_factor",
        "bounded_multivariate_sparse_factor",
        "bounded_multivariate_cofactor_factor",
    ]
    assert alexander_attempt["bounded_search_limits"]["max_candidate_terms"] == 14
    assert alexander_attempt["bounded_search_limits"][
        "full_invariant_certified"
    ] is False
    attempt_diagnostics = alexander_attempt["attempt_diagnostics"]
    assert attempt_diagnostics["method"] == "bounded_common_gcd_attempt_diagnostics"
    assert attempt_diagnostics["input_polynomial_count"] == 75
    assert attempt_diagnostics["unique_input_polynomial_count"] == 24
    assert attempt_diagnostics["common_variable_support"] == ["t1"]
    assert attempt_diagnostics["union_variable_support"] == ["t1", "t2"]
    assert attempt_diagnostics["support_signature_counts"] == [
        {"variables": ["t1"], "input_count": 49},
        {"variables": ["t1", "t2"], "input_count": 26},
    ]
    direct_divisor_summary = attempt_diagnostics[
        "direct_scanned_minor_divisor_summary"
    ]
    assert direct_divisor_summary["method"] == (
        "direct_scanned_minor_divisor_attempt_summary"
    )
    assert direct_divisor_summary["candidate_count"] == 24
    assert direct_divisor_summary["checked_candidate_count"] == 24
    assert direct_divisor_summary["divides_all_candidate_count"] == 0
    assert direct_divisor_summary["failed_candidate_count"] == 24
    assert direct_divisor_summary["candidate_term_count_min"] == 2
    assert direct_divisor_summary["candidate_term_count_max"] == 7
    assert direct_divisor_summary["first_failure"] == {
        "candidate_index": 0,
        "candidate_polynomial": "1 - t1",
        "candidate_term_count": 2,
        "failed_input_index": 6,
        "failed_input_polynomial": "1 - t1 + t1^2",
        "failed_input_term_count": 3,
    }
    assert alexander_attempt["notes"] == [
        "conservative bounded common-gcd search did not certify a common non-unit factor",
        "result remains skipped rather than claiming a completed multi-variable Alexander invariant",
    ]
    assert first["invariant_signature"]["jones_polynomial"] == first["jones_polynomial"]
    assert (
        first["invariant_signature"]["homfly_polynomial"]
        == first["homfly"]["homfly_polynomial"]
    )
    assert first["invariant_signature"]["alexander_notes"] == first[
        "multivariable_alexander"
    ]["notes"]
    assert first["invariant_signature"][
        "alexander_common_gcd_attempt_status"
    ] == "not_certified"
    assert first["invariant_signature"][
        "alexander_common_gcd_attempt_unique_input_polynomial_count"
    ] == 24
    assert first["invariant_signature"][
        "alexander_common_gcd_attempt_candidate_methods"
    ] == alexander_attempt["candidate_methods_attempted"]
    assert first["invariant_signature"][
        "alexander_common_gcd_attempt_common_variable_support"
    ] == ["t1"]
    assert first["invariant_signature"][
        "alexander_common_gcd_attempt_union_variable_support"
    ] == ["t1", "t2"]
    assert first["invariant_signature"][
        "alexander_common_gcd_attempt_direct_divisor_candidate_count"
    ] == 24
    assert first["invariant_signature"][
        "alexander_common_gcd_attempt_direct_divisor_divides_all_candidate_count"
    ] == 0
    assert first["invariant_signature"][
        "alexander_common_gcd_attempt_direct_divisor_failed_candidate_count"
    ] == 24
    assert first["invariant_signature"][
        "alexander_common_gcd_attempt_direct_divisor_first_failure_candidate"
    ] == "1 - t1"
    assert first["invariant_signature"][
        "alexander_common_gcd_attempt_direct_divisor_first_failure_input"
    ] == "1 - t1 + t1^2"
    assert first["invariant_signature"][
        "alexander_common_gcd_attempt_notes"
    ] == alexander_attempt["notes"]
    assert diagnostics["candidate_groups"][0]["signature"] == first["invariant_signature"]
    assert diagnostics["candidate_groups"][0]["count"] >= 1
    assert "not registered" in diagnostics["notes"][0]


def test_unsigned_whitehead_signed_candidates_can_require_gauss_code_match() -> None:
    fixture = get_diagram_fixture("L5a1")

    diagnostics = fixture.signed_candidate_diagnostics(
        max_orientation_samples=64,
        target_pairwise_linking=(0,),
        max_candidates=4,
        compute_alexander=False,
        require_gauss_code_match=True,
    )

    assert diagnostics["gauss_code_match_required"] is True
    assert diagnostics["orientation_sample_count"] == 2
    assert diagnostics["gauss_code_orientation_diagnostics"]["matched"] is True
    assert diagnostics["matching_candidate_count"] == 24
    assert diagnostics["returned_candidate_count"] == 4
    assert diagnostics["matching_sign_summary"]["per_sample_matching_counts"] == [
        {"sample_index": 0, "matching_sign_pattern_count": 12},
        {"sample_index": 1, "matching_sign_pattern_count": 12},
    ]

    first = diagnostics["candidates"][0]
    assert first["sample_index"] == 0
    assert first["role_orders"] == diagnostics["gauss_code_orientation_diagnostics"][
        "matches"
    ][0]["role_orders"]
    assert first["pairwise_linking"] == [0.0]
    assert first["homfly"]["skipped"] is False
    assert first["homfly_mirror_audit"]["matched"] is True


def test_unsigned_whitehead_source_pairwise_candidate_diagnostics() -> None:
    fixture = get_diagram_fixture("L5a1")

    diagnostics = fixture.source_pairwise_candidate_diagnostics(
        max_orientation_samples=64,
        max_candidates=4,
    )

    assert diagnostics["method"] == (
        "diagram_fixture_source_pairwise_candidate_diagnostics"
    )
    assert diagnostics["skipped"] is False
    assert diagnostics["gauss_code_match_required"] is True
    assert diagnostics["target_pairwise_linking"] == [0.0]
    assert diagnostics["link_table_entry"]["notation"] == "L5a1"
    assert diagnostics["orientation_sample_count"] == 2
    assert diagnostics["matching_candidate_count"] == 24
    assert diagnostics["returned_candidate_count"] == 4
    assert diagnostics["matching_sign_summary"]["unique_sign_pattern_count"] == 12
    assert diagnostics["matching_sign_summary"]["mirror_pair_count"] == 6

    first = diagnostics["candidates"][0]
    assert first["source_sample_index"] == 2
    assert first["pairwise_linking"] == [0.0]
    assert first["signs"] == [-1, -1, -1, 1, 1]
    assert first["jones_polynomial"] is None
    assert first["invariant_signature"]["homfly_skipped"] is None
    assert first["invariant_signature"]["alexander_skipped"] is None


def test_unsigned_whitehead_source_table_audit_keeps_candidate_gap_visible() -> None:
    fixture = get_diagram_fixture("L5a1")

    audit = fixture.source_table_invariant_audit(max_candidates=64)

    assert audit["method"] == "diagram_fixture_source_table_invariant_audit"
    assert audit["notation"] == "L5a1"
    assert audit["source"] == "Knot Atlas"
    assert audit["source_url"] == "https://katlas.org/wiki/L5a1"
    assert audit["has_signed_pd"] is False
    assert audit["registered_fixture_invariant_claim"] is False
    assert audit["complete_candidate_set"] is True
    assert audit["matched_source_table_invariants"] == []
    assert audit["uncomputed_source_table_invariants"] == [
        "jones",
        "homfly",
        "multivariable_alexander_numerator",
    ]
    assert audit["uncomputed_source_table_invariant_count"] == 3
    assert audit["mismatched_source_table_invariants"] == []
    assert audit["mismatched_source_table_invariant_count"] == 0
    assert audit["unstable_source_table_invariants"] == []
    assert audit["unstable_source_table_invariant_count"] == 0
    assert audit["source_table_registration_ready"] is False
    assert audit["source_table_registration_blockers"] == [
        "fixture_signs_not_registered",
        "registered_fixture_invariant_claim_disabled",
        "source_table_values_uncomputed",
        "source_compatible_sign_pattern_not_unique",
    ]
    assert audit["source_table_registration_blocker_count"] == 4
    assert audit["source_table_registration_blocker_details"][
        "source_table_values_uncomputed"
    ] == [
        "jones",
        "homfly",
        "multivariable_alexander_numerator",
    ]
    assert audit["source_table_registration_blocker_details"][
        "source_compatible_sign_pattern_not_unique"
    ] == {
        "complete_source_compatible_unique_sign_pattern_count": 0,
    }
    convergence_summary = audit["source_table_candidate_convergence_summary"]
    assert convergence_summary["source_value_seen_invariants"] == [
        "jones",
        "multivariable_alexander_numerator",
    ]
    assert convergence_summary["source_value_seen_invariant_count"] == 2
    assert convergence_summary[
        "source_value_seen_but_uncertified_invariants"
    ] == [
        "jones",
        "multivariable_alexander_numerator",
    ]
    assert (
        convergence_summary[
            "source_value_seen_but_uncertified_invariant_count"
        ]
        == 2
    )
    assert audit[
        "source_table_candidate_convergence_source_value_seen_invariant_count"
    ] == 2
    assert (
        audit[
            "source_table_candidate_convergence_source_value_seen_but_uncertified_invariant_count"
        ]
        == 2
    )

    jones = audit["comparisons"]["jones"]
    assert jones["source_value"] == "t^-2 - 2t^-1 + 1 - 2t + t^2 - t^3"
    assert jones["source_value_seen"] is True
    assert jones["complete_candidate_source_match"] is False
    assert jones["source_match_resolution_status"] == (
        "source_seen_with_incomplete_candidates"
    )
    assert jones["source_match_resolution_status_code"] == 5
    assert jones["candidate_unique_value_count"] == 1
    assert jones["computed_candidate_count"] == 12
    assert jones["missing_candidate_count"] == 12

    alexander = audit["comparisons"]["multivariable_alexander_numerator"]
    assert alexander["source_value"] == "1 - t2 - t1 + t1*t2"
    assert alexander["source_value_seen"] is True
    assert alexander["complete_candidate_source_match"] is False
    assert alexander["source_match_resolution_status"] == (
        "source_seen_with_incomplete_candidates"
    )
    assert alexander["source_match_resolution_status_code"] == 5
    assert alexander["candidate_unique_value_count"] == 2
    assert alexander["skipped_candidate_count"] == 8

    assert audit["source_table_candidate_count"] == 24
    assert audit["source_table_computed_source_compatible_candidate_count"] == 12
    assert audit["source_table_complete_source_compatible_candidate_count"] == 0
    assert audit["source_table_top_candidate_count"] == 12
    assert audit["source_table_top_candidate_unique_sign_pattern_count"] == 6
    assert audit["source_table_max_matched_source_value_count"] == 2
    assert audit["source_table_max_matched_candidate_count"] == 4
    assert audit["source_table_max_matched_candidate_unique_sign_pattern_count"] == 2

    match_summary = audit["candidate_source_table_match_summary"]
    assert match_summary["method"] == (
        "diagram_fixture_source_table_candidate_match_summary"
    )
    assert match_summary["source_value_names"] == [
        "jones",
        "homfly",
        "multivariable_alexander_numerator",
    ]
    assert match_summary["candidate_count"] == 24
    assert match_summary["computed_source_compatible_candidate_count"] == 12
    assert match_summary["complete_source_compatible_candidate_count"] == 0
    assert match_summary["max_matched_source_value_count"] == 2
    assert match_summary["max_matched_candidate_count"] == 4
    assert match_summary["max_matched_candidate_unique_sign_pattern_count"] == 2
    assert match_summary["max_matched_candidate_unique_sign_patterns"] == [
        [-1, 1, 1, -1, 1],
        [1, 1, 1, -1, -1],
    ]
    assert match_summary["top_candidate_count"] == 12
    assert match_summary["top_candidate_unique_sign_pattern_count"] == 6
    assert match_summary["top_candidate_unique_sign_patterns"] == [
        [-1, 1, 1, -1, 1],
        [1, 1, 1, -1, -1],
        [-1, -1, -1, 1, 1],
        [-1, 1, 1, 1, -1],
        [1, -1, -1, 1, -1],
        [1, 1, -1, -1, 1],
    ]
    assert match_summary["top_candidates"][0]["signs"] == [-1, 1, 1, -1, 1]
    assert match_summary["top_candidates"][0]["matched_source_values"] == [
        "jones",
        "multivariable_alexander_numerator",
    ]


def test_unsigned_whitehead_source_table_audit_keeps_homfly_gap_visible() -> None:
    fixture = get_diagram_fixture("L5a1")

    audit = fixture.source_table_invariant_audit(
        max_candidates=12,
        compute_homfly=True,
        homfly_max_depth=8,
        homfly_max_nodes=4096,
        alexander_max_minors=128,
    )

    assert audit["complete_candidate_set"] is False
    assert audit["registered_fixture_invariant_claim"] is False
    assert audit["matched_source_table_invariants"] == []
    assert audit["uncomputed_source_table_invariants"] == [
        "jones",
        "multivariable_alexander_numerator",
    ]
    assert audit["uncomputed_source_table_invariant_count"] == 2
    assert audit["mismatched_source_table_invariants"] == ["homfly"]
    assert audit["mismatched_source_table_invariant_count"] == 1
    assert audit["unstable_source_table_invariants"] == []
    assert audit["unstable_source_table_invariant_count"] == 0
    assert audit["source_table_registration_ready"] is False
    assert audit["source_table_registration_blockers"] == [
        "fixture_signs_not_registered",
        "registered_fixture_invariant_claim_disabled",
        "candidate_set_incomplete",
        "source_table_values_uncomputed",
        "source_table_values_mismatched",
        "source_compatible_sign_pattern_not_unique",
    ]
    assert audit["source_table_registration_blocker_count"] == 6
    assert audit["source_table_registration_blocker_details"][
        "source_table_values_uncomputed"
    ] == [
        "jones",
        "multivariable_alexander_numerator",
    ]
    assert audit["source_table_registration_blocker_details"][
        "source_table_values_mismatched"
    ] == ["homfly"]

    jones = audit["comparisons"]["jones"]
    assert jones["computed_candidate_count"] == 6
    assert jones["missing_candidate_count"] == 6
    assert jones["source_value_seen"] is True
    assert jones["complete_candidate_source_match"] is False

    homfly = audit["comparisons"]["homfly"]
    assert homfly["source_value"] == (
        "-a^3*z + a*z^3 + 2a*z + a*z^-1 - a^-1*z - a^-1*z^-1"
    )
    assert homfly["computed_candidate_count"] == 12
    assert homfly["missing_candidate_count"] == 0
    assert homfly["skipped_candidate_count"] == 0
    assert homfly["candidate_unique_value_count"] == 6
    assert homfly["source_value_seen"] is False
    assert homfly["complete_candidate_source_match"] is False
    assert homfly["returned_candidate_source_match"] is False
    assert homfly["source_match_resolution_status"] == "source_missed_with_candidates"
    assert homfly["source_match_resolution_status_code"] == 8
    assert homfly["source_value_variant_count"] == 8
    assert [
        variant["name"] for variant in homfly["source_value_variants"]
    ] == [
        "identity",
        "invert_a",
        "negate_z",
        "mirror_invert_a_negate_z",
        "invert_z",
        "invert_a_invert_z",
        "negate_z_invert_z",
        "mirror_invert_a_negate_z_invert_z",
    ]
    assert homfly["source_value_seen_variant_names"] == [
        "identity",
        "mirror_invert_a_negate_z",
    ]
    assert homfly["source_value_seen_variant_count"] == 2
    assert homfly["source_value_any_variant_seen"] is True
    assert homfly["source_value_seen_after_unit_normalization"] is True
    assert homfly["source_value_unit_normalized_variant_count"] == 8
    assert homfly["source_value_seen_unit_normalized_variant_names"] == [
        "identity",
        "invert_a",
        "negate_z",
        "mirror_invert_a_negate_z",
    ]
    assert homfly["source_value_seen_unit_normalized_variant_count"] == 4
    assert homfly["source_value_any_unit_normalized_variant_seen"] is True
    assert homfly["source_value_variant_resolution_status"] == "source_variant_seen"
    assert homfly["source_value_variant_resolution_status_code"] == 4
    assert homfly["candidate_unit_normalized_value_count"] == 6
    assert audit["source_table_homfly_candidate_unique_value_count"] == 6
    assert audit["source_table_homfly_candidate_unit_normalized_value_count"] == 6
    assert [
        variant["name"]
        for variant in homfly["source_value_variants"]
        if variant["source_value_seen"]
    ] == ["identity", "mirror_invert_a_negate_z"]
    assert [
        variant["name"]
        for variant in homfly["source_value_variants"]
        if variant["source_value_seen_after_unit_normalization"]
    ] == ["identity", "invert_a", "negate_z", "mirror_invert_a_negate_z"]
    assert homfly["notes"] == [
        "normalized source value was not seen among candidate values",
        "a normalized source convention variant was seen among candidate values",
        "a source convention variant matched after Laurent-unit normalization",
    ]

    alexander = audit["comparisons"]["multivariable_alexander_numerator"]
    assert alexander["computed_candidate_count"] == 8
    assert alexander["missing_candidate_count"] == 4
    assert alexander["skipped_candidate_count"] == 4
    assert alexander["source_value_seen"] is True
    assert alexander["complete_candidate_source_match"] is False

    match_summary = audit["candidate_source_table_match_summary"]
    assert match_summary["candidate_count"] == 12
    assert match_summary["computed_source_compatible_candidate_count"] == 0
    assert match_summary["complete_source_compatible_candidate_count"] == 0
    assert match_summary["max_matched_source_value_count"] == 2
    assert match_summary["max_matched_candidate_count"] == 2
    assert match_summary["max_matched_candidate_unique_sign_pattern_count"] == 1
    assert match_summary["max_matched_candidate_unique_sign_patterns"] == [
        [-1, 1, 1, -1, 1],
    ]
    assert match_summary["top_candidate_count"] == 0
    assert match_summary["top_candidate_unique_sign_pattern_count"] == 0
    assert match_summary["top_candidate_unique_sign_patterns"] == []


def test_unsigned_whitehead_source_table_audit_computes_complete_homfly_gap() -> None:
    fixture = get_diagram_fixture("L5a1")

    audit = fixture.source_table_invariant_audit(
        max_candidates=24,
        compute_homfly=True,
        homfly_max_depth=8,
        homfly_max_nodes=4096,
        alexander_max_minors=256,
    )

    assert audit["complete_candidate_set"] is True
    assert audit["registered_fixture_invariant_claim"] is False
    assert audit["matched_source_table_invariants"] == []
    assert audit["uncomputed_source_table_invariants"] == [
        "jones",
        "multivariable_alexander_numerator",
    ]
    assert audit["mismatched_source_table_invariants"] == ["homfly"]
    assert audit["source_table_registration_ready"] is False
    assert audit["source_table_registration_blockers"] == [
        "fixture_signs_not_registered",
        "registered_fixture_invariant_claim_disabled",
        "source_table_values_uncomputed",
        "source_table_values_mismatched",
        "source_compatible_sign_pattern_not_unique",
    ]
    assert audit["source_table_registration_blocker_count"] == 5
    assert audit["source_table_registration_blocker_details"][
        "source_table_values_uncomputed"
    ] == [
        "jones",
        "multivariable_alexander_numerator",
    ]
    assert audit["source_table_registration_blocker_details"][
        "source_table_values_mismatched"
    ] == ["homfly"]

    homfly = audit["comparisons"]["homfly"]
    assert homfly["source_value"] == (
        "-a^3*z + a*z^3 + 2a*z + a*z^-1 - a^-1*z - a^-1*z^-1"
    )
    assert homfly["computed_candidate_count"] == 24
    assert homfly["missing_candidate_count"] == 0
    assert homfly["skipped_candidate_count"] == 0
    assert homfly["candidate_unique_value_count"] == 10
    assert homfly["source_value_seen"] is False
    assert homfly["complete_candidate_source_match"] is False
    assert homfly["source_match_resolution_status"] == "source_missed_with_candidates"
    assert homfly["source_match_resolution_status_code"] == 8
    assert homfly["source_value_variant_resolution_status"] == "source_variant_seen"
    assert homfly["source_value_variant_resolution_status_code"] == 4
    assert homfly["candidate_unit_normalized_value_count"] == 10
    assert audit["source_table_homfly_candidate_unique_value_count"] == 10
    assert audit["source_table_homfly_candidate_unit_normalized_value_count"] == 10

    jones = audit["comparisons"]["jones"]
    assert jones["computed_candidate_count"] == 12
    assert jones["missing_candidate_count"] == 12
    assert jones["source_value_seen"] is True
    assert jones["source_match_resolution_status"] == (
        "source_seen_with_incomplete_candidates"
    )

    alexander = audit["comparisons"]["multivariable_alexander_numerator"]
    assert alexander["computed_candidate_count"] == 16
    assert alexander["missing_candidate_count"] == 8
    assert alexander["skipped_candidate_count"] == 8
    assert alexander["source_value_seen"] is True
    assert alexander["source_match_resolution_status"] == (
        "source_seen_with_incomplete_candidates"
    )
    alexander_attempt_summary = (
        audit["source_table_alexander_skipped_common_gcd_attempt_summary"]
    )
    assert alexander["skipped_common_gcd_attempt_summary"] == (
        alexander_attempt_summary
    )
    assert (
        audit["source_table_alexander_skipped_common_gcd_attempt_candidate_count"]
        == 8
    )
    assert (
        audit[
            "source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count"
        ]
        == 8
    )
    assert (
        audit["source_table_alexander_skipped_common_gcd_attempt_statuses"]
        == ["not_certified"]
    )
    assert (
        audit["source_table_alexander_skipped_common_gcd_attempt_status_counts"]
        == [{"status": "not_certified", "candidate_count": 8}]
    )
    assert (
        audit[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count"
        ]
        == 8
    )
    assert (
        audit[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_min"
        ]
        == 10
    )
    assert (
        audit[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max"
        ]
        == 10
    )
    assert (
        audit[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed"
        ]
        is True
    )
    assert alexander_attempt_summary["candidate_with_attempt_evidence_count"] == 8
    assert alexander_attempt_summary["candidate_without_attempt_evidence_count"] == 0
    assert alexander_attempt_summary["candidate_indices"] == [
        4,
        5,
        10,
        11,
        12,
        13,
        18,
        19,
    ]
    assert alexander_attempt_summary["direct_divisor_attempt_evidence_count"] == 8
    assert alexander_attempt_summary["direct_divisor_candidate_count_min"] == 10
    assert alexander_attempt_summary["direct_divisor_candidate_count_max"] == 10
    assert (
        alexander_attempt_summary[
            "direct_divisor_divides_all_candidate_count_min"
        ]
        == 0
    )
    assert (
        alexander_attempt_summary[
            "direct_divisor_divides_all_candidate_count_max"
        ]
        == 0
    )
    assert alexander_attempt_summary["direct_divisor_failed_candidate_count_min"] == 10
    assert alexander_attempt_summary["direct_divisor_failed_candidate_count_max"] == 10
    assert alexander_attempt_summary["direct_divisor_all_candidates_failed"] is True
    assert alexander_attempt_summary["direct_divisor_first_failure"] == {
        "candidate_index": 0,
        "candidate_polynomial": "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2",
        "candidate_term_count": 5,
        "failed_input_index": 0,
        "failed_input_polynomial": (
            "t2 - t2^2 + t1 - t1*t2 + 2*t1*t2^2 - t1^2 - t1^2*t2^2"
        ),
        "failed_input_term_count": 7,
    }
    assert alexander_attempt_summary["support_signature_evidence_count"] == 8
    assert alexander_attempt_summary["support_signature_variant_count"] == 1
    assert alexander_attempt_summary["support_signature_input_count_min"] == 25
    assert alexander_attempt_summary["support_signature_input_count_max"] == 25
    assert alexander_attempt_summary["support_signature_counts"] == [
        {
            "variables": ["t1", "t2"],
            "candidate_count": 8,
            "input_count_min": 25,
            "input_count_max": 25,
        }
    ]
    assert (
        audit[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 8
    )
    assert (
        audit[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count"
        ]
        == 1
    )
    assert (
        audit[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min"
        ]
        == 25
    )
    assert (
        audit[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max"
        ]
        == 25
    )
    source_divisibility = (
        audit["source_table_alexander_source_numerator_divisibility_summary"]
    )
    assert alexander["source_numerator_divisibility_summary"] == source_divisibility
    assert source_divisibility["method"] == (
        "diagram_fixture_alexander_source_numerator_divisibility_summary"
    )
    assert source_divisibility["source_value"] == "1 - t2 - t1 + t1*t2"
    assert source_divisibility["checked_candidate_count"] == 8
    assert source_divisibility["candidate_indices"] == [
        4,
        5,
        10,
        11,
        12,
        13,
        18,
        19,
    ]
    assert source_divisibility["statuses"] == [
        "source_does_not_divide_all_inputs"
    ]
    assert source_divisibility["status_counts"] == [
        {
            "status": "source_does_not_divide_all_inputs",
            "candidate_count": 8,
        }
    ]
    assert source_divisibility["source_divides_all_candidate_count"] == 0
    assert source_divisibility["source_division_failed_candidate_count"] == 8
    assert source_divisibility["all_checked_candidates_divisible"] is False
    assert source_divisibility["failed_input_count_min"] == 10
    assert source_divisibility["failed_input_count_max"] == 10
    assert source_divisibility["unique_input_polynomial_count_min"] == 10
    assert source_divisibility["unique_input_polynomial_count_max"] == 10
    assert source_divisibility["first_failed_candidate_index"] == 4
    assert source_divisibility["first_failed_input_polynomial"] == (
        "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2"
    )
    candidate_audit = audit["candidate_diagnostics"]["candidates"][4][
        "multivariable_alexander"
    ]["source_numerator_divisibility_audit"]
    assert candidate_audit["status"] == "source_does_not_divide_all_inputs"
    assert candidate_audit["source_polynomial"] == "1 - t2 - t1 + t1*t2"
    assert candidate_audit["normalized_source_polynomial"] == (
        "1 - t2 - t1 + t1*t2"
    )
    assert candidate_audit["checked_unique_input_polynomial_count"] == 10
    assert candidate_audit["failed_input_count"] == 10
    assert candidate_audit["failed_input_witness_count"] == 10
    assert candidate_audit["failed_input_witness_limit"] == 8
    assert candidate_audit["failed_input_witness_truncated"] is True
    assert len(candidate_audit["failed_input_witnesses"]) == 8
    assert candidate_audit["first_failed_input_witness"] == {
        "input_index": 0,
        "input_polynomial": "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2",
        "divisible": False,
        "invalid": False,
        "quotient_polynomial": None,
    }
    assert candidate_audit["failed_input_witness_consistency"][
        "count_list_limit_truncation_consistent"
    ] is True
    assert candidate_audit["divides_all_inputs"] is False
    assert alexander_attempt_summary["all_attempts_not_certified"] is True
    assert alexander_attempt_summary["input_polynomial_count_min"] == 25
    assert alexander_attempt_summary["input_polynomial_count_max"] == 25
    assert alexander_attempt_summary["unique_input_polynomial_count_min"] == 10
    assert alexander_attempt_summary["unique_input_polynomial_count_max"] == 10
    assert alexander_attempt_summary["common_integer_contents"] == [1]
    assert alexander_attempt_summary["candidate_method_count"] == 8
    assert alexander_attempt_summary["bounded_search_limit_variant_count"] == 1
    assert alexander_attempt_summary["bounded_search_limits"][
        "max_candidate_terms"
    ] == 14

    match_summary = audit["candidate_source_table_match_summary"]
    assert match_summary["candidate_count"] == 24
    assert match_summary["computed_source_compatible_candidate_count"] == 0
    assert match_summary["complete_source_compatible_candidate_count"] == 0
    assert match_summary["max_matched_source_value_count"] == 2
    assert match_summary["max_matched_candidate_count"] == 4
    assert match_summary["max_matched_candidate_unique_sign_pattern_count"] == 2
    assert match_summary["top_candidate_count"] == 0
    assert match_summary["top_candidate_unique_sign_pattern_count"] == 0


def test_unsigned_borromean_signed_candidates_can_require_gauss_code_match() -> None:
    fixture = get_diagram_fixture("L6a4")

    diagnostics = fixture.signed_candidate_diagnostics(
        max_orientation_samples=64,
        max_sign_patterns=64,
        target_pairwise_linking=(0, 0, 0),
        max_candidates=8,
        compute_homfly=False,
        compute_alexander=False,
        require_gauss_code_match=True,
    )

    assert diagnostics["gauss_code_match_required"] is True
    assert diagnostics["orientation_sample_count"] == 1
    assert diagnostics["gauss_code_orientation_diagnostics"]["matched"] is True
    assert diagnostics["matching_candidate_count"] == 8
    assert diagnostics["returned_candidate_count"] == 8
    assert diagnostics["candidate_groups"][0]["count"] == 8

    sign_summary = diagnostics["matching_sign_summary"]
    assert sign_summary["unique_sign_pattern_count"] == 8
    assert sign_summary["reported_sign_pattern_count"] == 8
    assert sign_summary["per_sample_matching_counts"] == [
        {"sample_index": 0, "matching_sign_pattern_count": 8},
    ]
    assert sign_summary["mirror_pair_count"] == 4
    assert sign_summary["mirror_pair_all_present_count"] == 4
    assert sign_summary["all_mirror_pairs_present"] is True
    assert sign_summary["sign_patterns"][0] == {
        "signs": [-1, -1, -1, 1, 1, 1],
        "matching_sample_indices": [0],
        "matching_candidate_count": 1,
    }

    first = diagnostics["candidates"][0]
    assert first["sample_index"] == 0
    assert first["pairwise_linking"] == [0.0, 0.0, 0.0]
    assert first["signs"] == [-1, -1, -1, 1, 1, 1]
    assert first["mirror_sign_pattern_present"] is True
    assert first["jones_polynomial"] == (
        "-t^-3 + 3t^-2 - 2t^-1 + 4 - 2t + 3t^2 - t^3"
    )
    assert first["invariant_signature"]["homfly_skipped"] is None
    assert first["invariant_signature"]["alexander_skipped"] is None


def test_unsigned_borromean_source_pairwise_candidate_diagnostics() -> None:
    fixture = get_diagram_fixture("L6a4")

    diagnostics = fixture.source_pairwise_candidate_diagnostics(
        max_orientation_samples=64,
        max_candidates=8,
    )

    assert diagnostics["method"] == (
        "diagram_fixture_source_pairwise_candidate_diagnostics"
    )
    assert diagnostics["skipped"] is False
    assert diagnostics["gauss_code_match_required"] is True
    assert diagnostics["target_pairwise_linking"] == [0.0, 0.0, 0.0]
    assert diagnostics["link_table_entry"]["notation"] == "L6a4"
    assert diagnostics["orientation_sample_count"] == 1
    assert diagnostics["matching_candidate_count"] == 8
    assert diagnostics["returned_candidate_count"] == 8
    assert diagnostics["matching_sign_summary"]["unique_sign_pattern_count"] == 8
    assert diagnostics["matching_sign_summary"]["mirror_pair_count"] == 4
    assert diagnostics["candidate_groups"][0]["count"] == 8

    first = diagnostics["candidates"][0]
    assert first["source_sample_index"] == 56
    assert first["pairwise_linking"] == [0.0, 0.0, 0.0]
    assert first["signs"] == [-1, -1, -1, 1, 1, 1]
    assert first["jones_polynomial"] == (
        "-t^-3 + 3t^-2 - 2t^-1 + 4 - 2t + 3t^2 - t^3"
    )
    assert first["invariant_signature"]["homfly_skipped"] is None
    assert first["invariant_signature"]["alexander_skipped"] is None


@pytest.mark.parametrize(
    ("notation", "expected_pairwise_linking"),
    [
        ("L5a1", [0.0]),
        ("L6a4", [0.0, 0.0, 0.0]),
    ],
)
def test_unsigned_source_invariant_candidates_expose_replayable_signed_pd_inputs(
    notation: str,
    expected_pairwise_linking: list[float],
) -> None:
    fixture = get_diagram_fixture(notation)

    diagnostics = fixture.source_invariant_candidate_diagnostics(
        max_orientation_samples=64,
        max_candidates=8,
        compute_homfly=False,
        compute_alexander=False,
    )

    assert diagnostics["returned_candidate_count"] == 8
    replay_summary = diagnostics["signed_pd_replay_summary"]
    assert replay_summary["method"] == "source_gauss_matched_signed_pd_replay_summary"
    assert replay_summary["claim_scope"] == "source_candidate_replay_self_consistency"
    assert replay_summary["checked_candidate_count"] == 8
    assert replay_summary["valid_replay_count"] == 8
    assert replay_summary["missing_replay_count"] == 0
    assert replay_summary["invalid_claim_scope_count"] == 0
    assert replay_summary["source_notation_mismatch_count"] == 0
    assert replay_summary["sign_mismatch_count"] == 0
    assert replay_summary["role_order_mismatch_count"] == 0
    assert replay_summary["pairwise_linking_mismatch_count"] == 0
    assert replay_summary["orientation_issue_count"] == 0
    assert replay_summary["missing_diagram_or_orientation_count"] == 0
    assert replay_summary["all_returned_candidates_have_valid_replay"] is True
    assert {row["valid_replay"] for row in replay_summary["rows"]} == {True}
    for candidate in diagnostics["candidates"]:
        replay = candidate["signed_pd_input"]
        diagram = PlanarDiagram.from_dict(replay["diagram"])
        orientation = PDOrientation.from_dict(replay["orientation"])

        assert replay["claim_scope"] == "source_gauss_matched_signed_pd_candidate_replay"
        assert replay["source_notation"] == notation
        assert replay["signs"] == candidate["signs"]
        assert replay["role_orders"] == [list(order) for order in candidate["role_orders"]]
        assert replay["pairwise_linking"] == expected_pairwise_linking
        assert replay["orientation_validation_issues"] == []
        assert orientation.validation_issues(diagram) == []
        assert PlanarDiagram.from_dict(diagram.to_dict()).to_dict() == diagram.to_dict()
        assert PDOrientation.from_dict(orientation.to_dict()).to_dict() == orientation.to_dict()


def test_cross_workstream_validation_pack_audit_tracks_fixture_metadata() -> None:
    report = cross_workstream_validation_pack_audit()

    assert report["method"] == "cross_workstream_validation_pack_audit"
    assert report["claim_scope"] == "final_completion_checklist_metadata_audit"
    assert report["required_diagram_fixture_notations"] == [
        "0_1",
        "3_1",
        "4_1",
        "L0a1",
        "L2a1",
        "L5a1",
        "L6a4",
    ]
    assert report["registered_required_diagram_fixture_count"] == 7
    assert report["missing_required_diagram_fixture_count"] == 0
    assert report["required_diagram_fixture_metadata_complete"] is True
    assert report["metadata_blocker_count"] == 0
    assert report["signed_diagram_fixture_registration_complete"] is False
    assert report["unsigned_required_fixture_count"] == 2
    bundle_evidence = report["completion_evidence_bundle"]
    assert bundle_evidence["available"] is False
    assert bundle_evidence["bundle_evidence_failed_check_count"] == 1
    assert bundle_evidence["bundle_evidence_failed_checks"] == [
        "completion_evidence_bundle_available"
    ]
    assert bundle_evidence["bundle_evidence_failed_check_signature"] == (
        "completion_evidence_bundle_available"
    )
    assert report["final_completion_gate_count"] == 7
    assert report["final_completion_passed_gate_count"] == 1
    assert report["final_completion_failed_gate_count"] == 6
    assert report["final_completion_blocker_count"] == 7
    assert report["final_completion_blocker_code_count"] == 6
    assert report["final_completion_blocker_code_counts"][
        "signed_pd_not_registered"
    ] == 2
    assert "noisy_sampled_curves_partial" not in report[
        "final_completion_blocker_code_counts"
    ]
    assert "high_point_count_performance_curves_partial" not in report[
        "final_completion_blocker_code_counts"
    ]
    assert report["final_completion_blocker_code_counts"][
        "native_imgui_screenshot_framebuffer_fixtures_partial"
    ] == 1
    expected_missing_artifacts = [
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "verified_signed_crossing_assignment",
    ]
    assert report["final_completion_missing_artifact_count"] == 5
    assert report["final_completion_missing_artifacts"] == expected_missing_artifacts
    assert report["final_completion_missing_artifact_signature"] == "|".join(
        expected_missing_artifacts
    )
    assert report["retained_evidence_count"] == 10
    assert report["retained_evidence_id_count"] == 8
    assert report["retained_evidence_ids"] == [
        "alexander_generated_signed_pd_coverage_report",
        "alexander_registered_fixture_acceptance_report",
        "homfly_registered_fixture_acceptance_report",
        "homfly_small_diagram_generated_coverage_report",
        "imgui_real_kernel_loader_smoke_retained_pack",
        "imgui_test_stub_framebuffer_smoke_retained_pack",
        "imgui_windows_retained_artifacts_manifest",
        "rust_wheel_retained_metadata_manifest",
    ]
    assert report["retained_evidence_completion_claimed_count"] == 0
    assert report["retained_evidence_release_grade_speedup_claimed_count"] == 0
    assert (
        report[
            "retained_evidence_real_graphics_backend_framebuffer_verified_count"
        ]
        == 0
    )
    assert report["retained_evidence_screenshot_verified_count"] == 0
    assert report["retained_evidence_all_non_claimed"] is True
    assert report["retained_evidence_non_claim_consistency"] == {
        "claim_scope": "validation_pack_retained_evidence_non_claim_consistency",
        "entry_count": 10,
        "evidence_id_count": 8,
        "top_level_entry_count": 10,
        "top_level_evidence_id_count": 8,
        "completion_claimed_count": 0,
        "release_grade_speedup_claimed_count": 0,
        "real_graphics_backend_framebuffer_verified_count": 0,
        "screenshot_verified_count": 0,
        "all_non_claimed": True,
        "entry_count_matches_top_level": True,
        "evidence_id_count_matches_top_level": True,
        "completion_claimed_count_matches_top_level": True,
        "release_grade_speedup_claimed_count_matches_top_level": True,
        "real_graphics_backend_framebuffer_verified_count_matches_top_level": True,
        "screenshot_verified_count_matches_top_level": True,
        "matched": True,
    }
    artifact_file_consistency = report[
        "retained_evidence_artifact_file_consistency"
    ]
    assert artifact_file_consistency["entry_count"] == 10
    assert artifact_file_consistency["artifact_evidence_count"] == 2
    assert artifact_file_consistency["non_artifact_evidence_count"] == 8
    assert artifact_file_consistency["artifact_file_reference_count"] == 6
    assert artifact_file_consistency["unique_artifact_file_count"] == 6
    assert artifact_file_consistency["raw_file_count"] == 2
    assert artifact_file_consistency["analysis_file_count"] == 2
    assert artifact_file_consistency["host_file_count"] == 2
    assert artifact_file_consistency["complete_raw_analysis_host_group_count"] == 2
    assert artifact_file_consistency["incomplete_artifact_group_count"] == 0
    assert artifact_file_consistency["matched"] is True
    retained_evidence = [
        evidence
        for blocker in report["final_completion_blockers"]
        for evidence in blocker.get("retained_evidence", [])
    ]
    assert len(retained_evidence) == report["retained_evidence_count"]
    assert (
        len({evidence["evidence_id"] for evidence in retained_evidence})
        == report["retained_evidence_id_count"]
    )
    assert (
        sum(1 for evidence in retained_evidence if evidence["completion_claimed"])
        == report["retained_evidence_completion_claimed_count"]
    )
    assert report["final_completion_ready"] is False
    assert report["full_homfly_pt_evaluation_certified"] is False
    assert report["full_multivariable_alexander_normalization_certified"] is False
    assert report["production_imgui_renderer_verified"] is False
    assert report["release_artifacts_published"] is False

    source_url_summary = report["fixture_source_url_shape_summary"]
    assert source_url_summary == {
        "claim_scope": "validation_pack_fixture_source_url_shape_summary",
        "fixture_row_count": 7,
        "source_url_row_count": 3,
        "external_source_url_row_count": 3,
        "source_url_required_count": 3,
        "source_url_http_or_https_count": 3,
        "source_url_requirement_satisfied_count": 3,
        "source_url_scheme_counts": {"https": 3},
        "source_url_domain_counts": {"katlas.org": 3},
        "source_url_scheme_count_total": 3,
        "source_url_domain_count_total": 3,
        "source_url_scheme_count_matched": True,
        "source_url_domain_count_matched": True,
        "source_url_http_or_https_count_matched": True,
        "source_url_requirement_satisfied_count_matched": True,
        "matched": True,
    }
    assert report["fixture_known_limitations_summary"] == {
        "claim_scope": "validation_pack_fixture_known_limitations_summary",
        "fixture_row_count": 7,
        "known_limitations_available_count": 7,
        "known_limitations_unavailable_count": 0,
        "known_limitations_note_count_total": 34,
        "known_limitations_requirement_satisfied_count": 7,
        "known_limitations_requirement_satisfied_count_matched": True,
        "known_limitations_unavailable_count_matched": True,
        "matched": True,
    }

    rows = {row["notation"]: row for row in report["fixtures"]}
    assert rows["4_1"]["source"] == "Knot Atlas"
    assert rows["4_1"]["source_url_required"] is True
    assert rows["4_1"]["source_url_scheme"] == "https"
    assert rows["4_1"]["source_url_domain"] == "katlas.org"
    assert rows["4_1"]["source_url_http_or_https"] is True
    assert rows["4_1"]["source_url_http_or_https_when_applicable"] is True
    assert rows["4_1"]["metadata_complete"] is True
    for row in rows.values():
        if row["source_url_required"]:
            assert row["source_url"]
            assert row["source_url_scheme"] in {"http", "https"}
            assert row["source_url_domain"]
            assert row["source_url_http_or_https"] is True
            assert row["source_url_http_or_https_when_applicable"] is True
            assert row["metadata_checks"][
                "source_url_http_or_https_when_applicable"
            ] is True
    assert rows["L5a1"]["registration_status"] == (
        "source_table_unsigned_fixture_pending_sign_registration"
    )
    assert rows["L5a1"]["source_table_homfly_available"] is True
    assert rows["L6a4"][
        "source_table_multivariable_alexander_numerator_available"
    ] is True
    assert {blocker["notation"] for blocker in report["signed_fixture_blockers"]} == {
        "L5a1",
        "L6a4",
    }
    signed_blockers = {
        blocker["notation"]: blocker for blocker in report["signed_fixture_blockers"]
    }
    assert signed_blockers["L5a1"]["registration_status"] == (
        "source_table_unsigned_fixture_pending_sign_registration"
    )
    assert signed_blockers["L5a1"]["source_url"] == "https://katlas.org/wiki/L5a1"
    assert signed_blockers["L5a1"]["has_signed_pd"] is False
    assert signed_blockers["L5a1"]["has_gauss_code"] is True
    assert signed_blockers["L5a1"]["source_table_homfly_available"] is True
    l5_candidate_evidence = signed_blockers["L5a1"]["source_candidate_evidence"]
    assert signed_blockers["L5a1"]["source_candidate_evidence_available"] is True
    assert signed_blockers["L5a1"]["source_candidate_matching_candidate_count"] == 24
    assert signed_blockers["L5a1"]["source_candidate_unique_sign_pattern_count"] == 12
    assert signed_blockers["L5a1"]["source_candidate_replay_all_valid"] is True
    assert l5_candidate_evidence["claim_scope"] == (
        "signed_fixture_candidate_blocker_evidence"
    )
    assert l5_candidate_evidence["registration_blocker_code"] == (
        "source_candidate_not_unique"
    )
    assert l5_candidate_evidence["complete_candidate_set"] is True
    assert l5_candidate_evidence["replay_checked_candidate_count"] == 24
    assert l5_candidate_evidence["replay_valid_replay_count"] == 24
    assert l5_candidate_evidence["all_returned_candidates_have_valid_replay"] is True
    l5_readiness = l5_candidate_evidence["verified_assignment_readiness"]
    assert l5_readiness["claim_scope"] == (
        "verified_signed_crossing_assignment_readiness"
    )
    assert l5_readiness["ready"] is False
    assert l5_readiness["passed_check_count"] == 3
    assert l5_readiness["failed_check_count"] == 3
    assert l5_readiness["blockers"] == [
        "unique_sign_pattern",
        "invariant_table_values_verified",
        "external_source_assignment_verified",
    ]
    assert "verified signed crossing assignment" in signed_blockers["L5a1"][
        "required_evidence"
    ]
    assert "fixture remains unsigned and unregistered" in signed_blockers["L5a1"][
        "current_evidence"
    ]
    assert "candidate evidence is not unique" in signed_blockers["L5a1"][
        "current_evidence"
    ]
    assert signed_blockers["L6a4"][
        "source_table_multivariable_alexander_available"
    ] is True
    l6_candidate_evidence = signed_blockers["L6a4"]["source_candidate_evidence"]
    assert signed_blockers["L6a4"]["source_candidate_matching_candidate_count"] == 8
    assert signed_blockers["L6a4"]["source_candidate_unique_sign_pattern_count"] == 8
    assert signed_blockers["L6a4"]["source_candidate_replay_all_valid"] is True
    assert l6_candidate_evidence["registration_blocker_code"] == (
        "source_candidate_not_unique"
    )
    assert l6_candidate_evidence["stable_invariants"] == ["jones"]
    assert l6_candidate_evidence["replay_checked_candidate_count"] == 8
    assert l6_candidate_evidence["replay_valid_replay_count"] == 8
    l6_readiness = l6_candidate_evidence["verified_assignment_readiness"]
    assert l6_readiness["ready"] is False
    assert l6_readiness["passed_check_count"] == 3
    assert l6_readiness["failed_check_count"] == 3
    assert l6_readiness["blockers"] == [
        "unique_sign_pattern",
        "invariant_table_values_verified",
        "external_source_assignment_verified",
    ]
    assert signed_blockers["L6a4"]["missing_artifact"] == (
        "verified_signed_crossing_assignment"
    )
    final_signed_blockers = {
        blocker["notation"]: blocker
        for blocker in report["final_completion_blockers"]
        if blocker["kind"] == "signed_fixture"
    }
    assert final_signed_blockers["L5a1"]["source"] == "Knot Atlas"
    assert final_signed_blockers["L5a1"]["source_table_homfly_available"] is True
    assert (
        final_signed_blockers["L5a1"]["source_candidate_matching_candidate_count"]
        == 24
    )
    assert (
        final_signed_blockers["L5a1"]["source_candidate_unique_sign_pattern_count"]
        == 12
    )
    assert (
        final_signed_blockers["L5a1"]["source_candidate_evidence"][
            "registration_blocker_code"
        ]
        == "source_candidate_not_unique"
    )
    assert "verified signed crossing assignment" in final_signed_blockers["L5a1"][
        "required_evidence"
    ]
    assert "fixture remains unsigned and unregistered" in final_signed_blockers[
        "L5a1"
    ]["current_evidence"]
    assert final_signed_blockers["L6a4"][
        "source_table_multivariable_alexander_numerator_available"
    ] is True
    assert (
        final_signed_blockers["L6a4"]["source_candidate_matching_candidate_count"]
        == 8
    )
    assert (
        final_signed_blockers["L6a4"]["source_candidate_unique_sign_pattern_count"]
        == 8
    )
    completion_gate_blockers = {
        blocker["gate"]: blocker
        for blocker in report["final_completion_blockers"]
        if blocker["kind"] == "completion_gate"
    }
    assert completion_gate_blockers["full_homfly_pt_evaluation"][
        "missing_artifact"
    ] == "full_homfly_pt_evaluation_certification_pack"
    assert "bounded generated small-diagram coverage" in completion_gate_blockers[
        "full_homfly_pt_evaluation"
    ]["current_evidence"]
    assert completion_gate_blockers["full_multivariable_alexander_normalization"][
        "missing_artifact"
    ] == "full_multivariable_alexander_normalization_certification_pack"
    assert completion_gate_blockers["production_imgui_renderer"][
        "missing_artifact"
    ] == "production_imgui_renderer_framebuffer_pack"
    assert "repository test-stub framebuffer" in completion_gate_blockers[
        "production_imgui_renderer"
    ]["current_evidence"]
    assert completion_gate_blockers["release_artifacts"][
        "missing_artifact"
    ] == "signed_release_publication_manifest"
    assert completion_gate_blockers["release_artifacts"][
        "missing_artifact_id"
    ] == "signed_release_publication_manifest"
    assert [
        row["evidence_id"]
        for row in completion_gate_blockers["release_artifacts"]["retained_evidence"]
    ] == [
        "rust_wheel_retained_metadata_manifest",
        "imgui_windows_retained_artifacts_manifest",
    ]
    gate_checks = {row["gate"]: row for row in report["final_completion_gate_checks"]}
    assert gate_checks["required_diagram_fixture_metadata"]["passed"] is True
    assert gate_checks["signed_diagram_fixture_registration"]["passed"] is False
    assert gate_checks["signed_diagram_fixture_registration"]["blocked_notations"] == [
        "L5a1",
        "L6a4",
    ]
    assert gate_checks["non_diagram_requirements"]["passed"] is False
    assert gate_checks["non_diagram_requirements"]["blocker_codes"] == [
        "native_imgui_screenshot_framebuffer_fixtures_partial",
    ]
    assert gate_checks["full_homfly_pt_evaluation"]["passed"] is False
    assert gate_checks["full_homfly_pt_evaluation"]["missing_artifact"] == (
        "full_homfly_pt_evaluation_certification_pack"
    )
    assert gate_checks["full_homfly_pt_evaluation"]["missing_artifact_id"] == (
        "full_homfly_pt_evaluation_certification_pack"
    )
    assert [
        row["evidence_id"]
        for row in gate_checks["full_homfly_pt_evaluation"]["retained_evidence"]
    ] == [
        "homfly_registered_fixture_acceptance_report",
        "homfly_small_diagram_generated_coverage_report",
    ]
    assert gate_checks["release_artifacts"]["blocker_codes"] == [
        "release_artifacts_not_published"
    ]
    assert gate_checks["release_artifacts"]["missing_artifact"] == (
        "signed_release_publication_manifest"
    )
    non_diagram_rows = {
        row["requirement"]: row for row in report["non_diagram_requirements"]
    }
    assert non_diagram_rows["native ImGui screenshot/framebuffer fixtures"][
        "status"
    ] == "partial"
    assert non_diagram_rows["native ImGui screenshot/framebuffer fixtures"][
        "missing_artifact"
    ] == "production_imgui_renderer_framebuffer_pack"
    assert non_diagram_rows["native ImGui screenshot/framebuffer fixtures"][
        "blocker_code"
    ] == "native_imgui_screenshot_framebuffer_fixtures_partial"
    assert non_diagram_rows["native ImGui screenshot/framebuffer fixtures"][
        "completion_claimed"
    ] is False
    native_artifacts = non_diagram_rows[
        "native ImGui screenshot/framebuffer fixtures"
    ]["retained_evidence"]
    assert [artifact["artifact_kind"] for artifact in native_artifacts] == [
        "imgui_test_stub_framebuffer_smoke",
        "imgui_real_kernel_loader_smoke",
    ]
    assert native_artifacts[0]["evidence_id"] == (
        "imgui_test_stub_framebuffer_smoke_retained_pack"
    )
    assert native_artifacts[0]["completion_claimed"] is False
    assert "repository test-stub framebuffer" in non_diagram_rows[
        "native ImGui screenshot/framebuffer fixtures"
    ]["current_evidence"]
    assert non_diagram_rows["noisy sampled curves"]["status"] == "available"
    assert non_diagram_rows["noisy sampled curves"]["certification_artifact"] == (
        "broad_noisy_curve_robustness_certification_pack"
    )
    noisy_evidence = non_diagram_rows["noisy sampled curves"][
        "certification_evidence"
    ][2]
    assert noisy_evidence["evidence_id"] == (
        "broad_noisy_curve_robustness_certification_pack"
    )
    assert noisy_evidence["test"] == (
        "tests/test_geometry.py::"
        "test_broad_noisy_sampled_curve_robustness_certification_pack"
    )
    assert noisy_evidence["completion_claimed"] is True
    assert non_diagram_rows["high-point-count performance curves"][
        "status"
    ] == "available"
    assert non_diagram_rows["high-point-count performance curves"][
        "certification_artifact"
    ] == "release_grade_high_point_performance_pack"
    high_point_evidence = non_diagram_rows[
        "high-point-count performance curves"
    ]["certification_evidence"]
    assert [row["evidence_id"] for row in high_point_evidence] == [
        "numpy_benchmark_matrix_local_profiling",
        "release_grade_high_point_performance_pack",
    ]
    assert high_point_evidence[1]["source_method"] == "iroll_core_benchmark_matrix"
    assert high_point_evidence[1]["release_grade_speedup_claimed"] is True
    assert high_point_evidence[1]["completion_claimed"] is True
    assert high_point_evidence[1]["point_sizes"] == [128]
    assert high_point_evidence[1]["repeat"] == 3
    non_diagram_blockers = {
        blocker["requirement"]: blocker
        for blocker in report["final_completion_blockers"]
        if blocker["kind"] == "non_diagram_requirement"
    }
    assert non_diagram_blockers["native ImGui screenshot/framebuffer fixtures"][
        "missing_artifact"
    ] == "production_imgui_renderer_framebuffer_pack"
    assert non_diagram_blockers["native ImGui screenshot/framebuffer fixtures"][
        "missing_artifact_id"
    ] == "production_imgui_renderer_framebuffer_pack"
    assert non_diagram_blockers["native ImGui screenshot/framebuffer fixtures"][
        "completion_claimed"
    ] is False
    assert non_diagram_blockers["native ImGui screenshot/framebuffer fixtures"][
        "retained_evidence"
    ][0]["artifact_kind"] == "imgui_test_stub_framebuffer_smoke"


def test_cross_workstream_validation_pack_accepts_production_imgui_pack() -> None:
    production_pack = {
        "artifact_schema_version": 1,
        "artifact_kind": "imgui_production_renderer_framebuffer_pack",
        "claim_scope": "production_imgui_renderer_framebuffer_verification",
        "real_graphics_backend_framebuffer_verified": True,
        "screenshot_verified": True,
        "graphics_backend_name": "Direct3D11",
        "framebuffer_width": 128,
        "framebuffer_height": 64,
        "screenshot_url": "https://evidence.iroll.dev/production-imgui.png",
        "screenshot_sha256": "a" * 64,
        "render_frame_count": 2,
        "framebuffer_touched": 1,
        "estimated_nonzero_pixels": 8192,
        "passed": True,
    }

    report = cross_workstream_validation_pack_audit(
        production_imgui_renderer_framebuffer_pack=production_pack,
    )

    assert report["final_completion_ready"] is False
    assert report["open_non_diagram_requirement_count"] == 0
    assert report["production_imgui_renderer_verified"] is True
    assert report["final_completion_blocker_count"] == 5
    assert report["final_completion_blocker_code_counts"] == {
        "signed_pd_not_registered": 2,
        "full_homfly_pt_evaluation_not_certified": 1,
        "full_multivariable_alexander_normalization_not_certified": 1,
        "release_artifacts_not_published": 1,
    }
    non_diagram_rows = {
        row["requirement"]: row for row in report["non_diagram_requirements"]
    }
    native_row = non_diagram_rows["native ImGui screenshot/framebuffer fixtures"]
    assert native_row["status"] == "available"
    assert native_row["certification_artifact"] == (
        "production_imgui_renderer_framebuffer_pack"
    )
    native_evidence = native_row["certification_evidence"][0]
    assert native_evidence["certified"] is True
    assert native_evidence["completion_claimed"] is True
    assert native_evidence["failed_check_count"] == 0
    assert native_evidence["real_graphics_backend_framebuffer_verified"] is True
    assert native_evidence["screenshot_verified"] is True
    assert native_evidence["graphics_backend_name"] == "Direct3D11"
    assert native_evidence["framebuffer_width"] == 128
    assert native_evidence["framebuffer_height"] == 64
    assert native_evidence["screenshot_url"] == (
        "https://evidence.iroll.dev/production-imgui.png"
    )

    gate_checks = {row["gate"]: row for row in report["final_completion_gate_checks"]}
    assert gate_checks["non_diagram_requirements"]["passed"] is True
    assert gate_checks["production_imgui_renderer"]["passed"] is True
    assert gate_checks["production_imgui_renderer"]["blocker_count"] == 0
    assert gate_checks["production_imgui_renderer"]["retained_evidence"][0][
        "evidence_id"
    ] == "production_imgui_renderer_framebuffer_pack"
    assert {
        blocker.get("gate") or blocker.get("requirement")
        for blocker in report["final_completion_blockers"]
    }.isdisjoint(
        {
            "native ImGui screenshot/framebuffer fixtures",
            "production_imgui_renderer",
        }
    )


def test_completion_evidence_artifact_audit_rejects_placeholder_evidence_urls() -> None:
    production_pack = {
        "artifact_schema_version": 1,
        "artifact_kind": "imgui_production_renderer_framebuffer_pack",
        "claim_scope": "production_imgui_renderer_framebuffer_verification",
        "real_graphics_backend_framebuffer_verified": True,
        "screenshot_verified": True,
        "graphics_backend_name": "Direct3D11",
        "framebuffer_width": 128,
        "framebuffer_height": 64,
        "screenshot_url": "https://example.invalid/iroll/production-imgui.png",
        "screenshot_sha256": "a" * 64,
        "render_frame_count": 2,
        "framebuffer_touched": 1,
        "estimated_nonzero_pixels": 8192,
        "passed": True,
    }

    preflight = completion_evidence_artifact_audit(
        production_pack,
        artifact_type="production_imgui_renderer_framebuffer_pack",
    )

    assert preflight["artifact_certified"] is False
    assert preflight["completion_claimed"] is False
    assert preflight["failed_checks"] == ["screenshot_url_http"]
    assert preflight["artifact_evidence"][
        "final_evidence_url_witness_invalid_fields"
    ] == ["screenshot_url"]
    assert preflight["artifact_evidence"][
        "final_evidence_url_witness_invalid_reasons"
    ] == ["placeholder_host"]
    assert preflight["artifact_evidence"]["final_evidence_url_witnesses"][0][
        "placeholder_host"
    ] is True
    assert preflight["artifact_evidence"][
        "final_evidence_digest_witness_valid_count"
    ] == 1
    assert preflight["artifact_evidence"][
        "final_evidence_digest_witness_invalid_count"
    ] == 0


def test_completion_evidence_artifact_audit_rejects_invalid_digest_witnesses() -> None:
    production_pack = {
        "artifact_schema_version": 1,
        "artifact_kind": "imgui_production_renderer_framebuffer_pack",
        "claim_scope": "production_imgui_renderer_framebuffer_verification",
        "real_graphics_backend_framebuffer_verified": True,
        "screenshot_verified": True,
        "graphics_backend_name": "Direct3D11",
        "framebuffer_width": 128,
        "framebuffer_height": 64,
        "screenshot_url": "https://evidence.iroll.dev/production-imgui.png",
        "screenshot_sha256": "not-a-digest",
        "render_frame_count": 2,
        "framebuffer_touched": 1,
        "estimated_nonzero_pixels": 8192,
        "passed": True,
    }

    preflight = completion_evidence_artifact_audit(
        production_pack,
        artifact_type="production_imgui_renderer_framebuffer_pack",
    )

    assert preflight["artifact_certified"] is False
    assert preflight["failed_checks"] == ["screenshot_sha256_available"]
    evidence = preflight["artifact_evidence"]
    assert evidence["final_evidence_digest_witness_invalid_fields"] == [
        "screenshot_sha256"
    ]
    assert evidence["final_evidence_digest_witness_invalid_reasons"] == [
        "digest_not_sha256_hex_64"
    ]
    assert evidence["final_evidence_digest_witnesses"][0]["paired_url"] == (
        "https://evidence.iroll.dev/production-imgui.png"
    )
    assert evidence["final_evidence_digest_witnesses"][0][
        "valid_final_evidence_digest"
    ] is False


def test_cross_workstream_validation_pack_rejects_production_imgui_pack_without_screenshot_witness() -> None:
    production_pack = {
        "artifact_schema_version": 1,
        "artifact_kind": "imgui_production_renderer_framebuffer_pack",
        "claim_scope": "production_imgui_renderer_framebuffer_verification",
        "real_graphics_backend_framebuffer_verified": True,
        "screenshot_verified": True,
        "render_frame_count": 2,
        "framebuffer_touched": 1,
        "estimated_nonzero_pixels": 8192,
        "passed": True,
    }

    report = cross_workstream_validation_pack_audit(
        production_imgui_renderer_framebuffer_pack=production_pack,
    )
    preflight = completion_evidence_artifact_audit(
        production_pack,
        artifact_type="production_imgui_renderer_framebuffer_pack",
    )

    gate_checks = {row["gate"]: row for row in report["final_completion_gate_checks"]}
    assert report["production_imgui_renderer_verified"] is False
    assert gate_checks["production_imgui_renderer"]["passed"] is False
    assert preflight["artifact_certified"] is False
    assert preflight["failed_checks"] == [
        "estimated_nonzero_pixels_within_framebuffer_area",
        "graphics_backend_name_available",
        "graphics_backend_name_not_test_or_stub",
        "framebuffer_width_positive",
        "framebuffer_height_positive",
        "screenshot_url_http",
        "screenshot_sha256_available",
    ]


def test_cross_workstream_validation_pack_accepts_signed_release_manifest() -> None:
    release_manifest = {
        "artifact_schema_version": 1,
        "artifact_kind": "signed_release_publication_manifest",
        "claim_scope": "signed_release_publication",
        "signed_release_artifacts_published": True,
        "publication_claimed": True,
        "platform_index_publication_claimed": True,
        "published_artifact_count": 2,
        "signature_count": 2,
        "package_index_url": "https://evidence.iroll.dev/releases/0.1.0",
        "artifact_urls": [
            "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0-py3-none-any.whl",
            "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0.tar.gz",
        ],
        "artifact_sha256s": ["a" * 64, "b" * 64],
        "signature_urls": [
            "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0-py3-none-any.whl.sig",
            "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0.tar.gz.sig",
        ],
        "signature_sha256s": ["c" * 64, "d" * 64],
    }

    report = cross_workstream_validation_pack_audit(
        signed_release_publication_manifest=release_manifest,
    )

    assert report["final_completion_ready"] is False
    assert report["release_artifacts_published"] is True
    assert report["final_completion_blocker_count"] == 6
    assert report["final_completion_blocker_code_counts"] == {
        "signed_pd_not_registered": 2,
        "native_imgui_screenshot_framebuffer_fixtures_partial": 1,
        "full_homfly_pt_evaluation_not_certified": 1,
        "full_multivariable_alexander_normalization_not_certified": 1,
        "production_imgui_renderer_not_verified": 1,
    }
    gate_checks = {row["gate"]: row for row in report["final_completion_gate_checks"]}
    assert gate_checks["release_artifacts"]["passed"] is True
    assert gate_checks["release_artifacts"]["blocker_count"] == 0
    evidence = gate_checks["release_artifacts"]["retained_evidence"][0]
    assert evidence["evidence_id"] == "signed_release_publication_manifest"
    assert evidence["certified"] is True
    assert evidence["completion_claimed"] is True
    assert evidence["published_artifact_count"] == 2
    assert evidence["signature_count"] == 2
    assert evidence["artifact_url_count"] == 2
    assert evidence["signature_url_count"] == 2
    assert "release_artifacts" not in {
        blocker.get("gate") for blocker in report["final_completion_blockers"]
    }


def test_cross_workstream_validation_pack_rejects_release_manifest_without_url_witnesses() -> None:
    release_manifest = {
        "artifact_schema_version": 1,
        "artifact_kind": "signed_release_publication_manifest",
        "claim_scope": "signed_release_publication",
        "signed_release_artifacts_published": True,
        "publication_claimed": True,
        "platform_index_publication_claimed": True,
        "published_artifact_count": 2,
        "signature_count": 2,
        "package_index_url": "https://evidence.iroll.dev/releases/0.1.0",
        "artifact_urls": [
            "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0-py3-none-any.whl",
        ],
        "artifact_sha256s": ["a" * 64, "b" * 64],
        "signature_urls": [],
        "signature_sha256s": ["c" * 64, "d" * 64],
    }

    report = cross_workstream_validation_pack_audit(
        signed_release_publication_manifest=release_manifest,
    )

    gate_checks = {row["gate"]: row for row in report["final_completion_gate_checks"]}
    preflight = completion_evidence_artifact_audit(
        release_manifest,
        artifact_type="signed_release_publication_manifest",
    )
    assert report["release_artifacts_published"] is False
    assert gate_checks["release_artifacts"]["passed"] is False
    assert preflight["artifact_certified"] is False
    assert preflight["completion_claimed"] is False
    assert preflight["artifact_evidence"]["artifact_url_count"] == 1
    assert preflight["artifact_evidence"]["signature_url_count"] == 0
    assert preflight["failed_checks"] == [
        "artifact_url_count_matches_published_artifact_count",
        "artifact_sha256_count_matches_artifact_url_count",
        "artifact_url_sha256_pairs_unique",
        "signature_urls_available",
        "signature_urls_items_nonempty_strings",
        "signature_url_count_matches_signature_count",
        "signature_url_filenames_unique",
        "signature_url_filenames_have_signature_extension",
        "signature_urls_match_artifact_url_filenames",
        "signature_sha256_count_matches_signature_url_count",
        "signature_url_sha256_pairs_unique",
    ]


def test_cross_workstream_validation_pack_accepts_full_homfly_pack() -> None:
    homfly_pack = _full_homfly_certification_pack()

    report = cross_workstream_validation_pack_audit(
        full_homfly_pt_evaluation_certification_pack=homfly_pack,
    )

    assert report["final_completion_ready"] is False
    assert report["full_homfly_pt_evaluation_certified"] is True
    assert report["full_multivariable_alexander_normalization_certified"] is False
    assert report["final_completion_blocker_count"] == 6
    assert "full_homfly_pt_evaluation_not_certified" not in report[
        "final_completion_blocker_code_counts"
    ]
    gate_checks = {row["gate"]: row for row in report["final_completion_gate_checks"]}
    assert gate_checks["full_homfly_pt_evaluation"]["passed"] is True
    evidence = gate_checks["full_homfly_pt_evaluation"]["retained_evidence"][0]
    assert evidence["evidence_id"] == "full_homfly_pt_evaluation_certification_pack"
    assert evidence["certified"] is True
    assert evidence["completion_claimed"] is True
    assert evidence["arbitrary_signed_pd_coverage_certified"] is True
    assert evidence["external_table_normalization_certified"] is True
    assert evidence["external_table_source_url_count"] == 4
    assert evidence["embedded_certification_report_available"] is True
    assert evidence["published_certification_report_witness_verified"] is True


def test_cross_workstream_validation_pack_rejects_full_homfly_pack_without_source_witnesses() -> None:
    homfly_pack = _full_homfly_certification_pack()
    homfly_pack["external_table_source_urls"] = []
    homfly_pack["external_table_source_sha256s"] = []

    report = cross_workstream_validation_pack_audit(
        full_homfly_pt_evaluation_certification_pack=homfly_pack,
    )
    preflight = completion_evidence_artifact_audit(
        homfly_pack,
        artifact_type="full_homfly_pt_evaluation_certification_pack",
    )

    gate_checks = {row["gate"]: row for row in report["final_completion_gate_checks"]}
    assert report["full_homfly_pt_evaluation_certified"] is False
    assert gate_checks["full_homfly_pt_evaluation"]["passed"] is False
    assert preflight["artifact_certified"] is False
    assert set(preflight["failed_checks"]) == {
        "pinned_external_table_sources_exact",
        "external_table_source_urls_available",
        "external_table_source_urls_items_nonempty_strings",
        "external_table_source_url_filenames_unique",
        "external_table_source_sha256s_available",
        "external_table_source_sha256s_items_nonempty_strings",
        "external_table_source_witness_pairs_unique",
    }


def test_cross_workstream_validation_pack_rejects_unreplayed_alexander_shell() -> None:
    alexander_pack = {
        "artifact_schema_version": 1,
        "artifact_kind": (
            "full_multivariable_alexander_normalization_certification_pack"
        ),
        "claim_scope": "full_multivariable_alexander_normalization",
        "full_multivariable_alexander_normalization_certified": True,
        "signed_pd_wirtinger_fox_certified": True,
        "admissible_minor_normalization_certified": True,
        "all_admissible_minors_consistent": True,
        "external_table_normalization_certified": True,
        "certification_report_url": (
            "https://evidence.iroll.dev/certification/full-alexander.json"
        ),
        "certification_report_sha256": "a" * 64,
        "external_table_source_urls": [
            "https://evidence.iroll.dev/tables/alexander"
        ],
        "external_table_source_sha256s": ["b" * 64],
        "counterexample_count": 0,
    }

    report = cross_workstream_validation_pack_audit(
        full_multivariable_alexander_normalization_certification_pack=(
            alexander_pack
        ),
    )
    preflight = completion_evidence_artifact_audit(
        alexander_pack,
        artifact_type="full_multivariable_alexander_normalization_certification_pack",
    )

    assert report["final_completion_ready"] is False
    assert report["full_homfly_pt_evaluation_certified"] is False
    assert report["full_multivariable_alexander_normalization_certified"] is False
    assert "full_multivariable_alexander_normalization_not_certified" in report[
        "final_completion_blocker_code_counts"
    ]
    gate_checks = {row["gate"]: row for row in report["final_completion_gate_checks"]}
    assert gate_checks["full_multivariable_alexander_normalization"]["passed"] is False
    retained_ids = {
        evidence.get("evidence_id")
        for evidence in gate_checks["full_multivariable_alexander_normalization"][
            "retained_evidence"
        ]
    }
    assert (
        "full_multivariable_alexander_normalization_certification_pack"
        not in retained_ids
    )
    assert preflight["artifact_certified"] is False
    assert {
        "embedded_certification_report_available",
        "published_certification_report_witness_verified",
        "external_table_page_sources_match_pinned_revisions",
    }.issubset(preflight["failed_checks"])


def test_cross_workstream_validation_pack_rejects_full_alexander_pack_without_source_witnesses() -> None:
    alexander_pack = {
        "artifact_schema_version": 1,
        "artifact_kind": (
            "full_multivariable_alexander_normalization_certification_pack"
        ),
        "claim_scope": "full_multivariable_alexander_normalization",
        "full_multivariable_alexander_normalization_certified": True,
        "signed_pd_wirtinger_fox_certified": True,
        "admissible_minor_normalization_certified": True,
        "all_admissible_minors_consistent": True,
        "external_table_normalization_certified": True,
        "counterexample_count": 0,
    }

    report = cross_workstream_validation_pack_audit(
        full_multivariable_alexander_normalization_certification_pack=(
            alexander_pack
        ),
    )
    preflight = completion_evidence_artifact_audit(
        alexander_pack,
        artifact_type="full_multivariable_alexander_normalization_certification_pack",
    )

    gate_checks = {row["gate"]: row for row in report["final_completion_gate_checks"]}
    assert report["full_multivariable_alexander_normalization_certified"] is False
    assert gate_checks["full_multivariable_alexander_normalization"]["passed"] is False
    assert preflight["artifact_certified"] is False
    assert preflight["failed_checks"] == [
        "embedded_certification_report_available",
        "published_certification_report_witness_verified",
        "external_table_page_sources_match_pinned_revisions",
        "certification_report_url_http",
        "certification_report_sha256_available",
        "external_table_source_urls_available",
        "external_table_source_urls_items_nonempty_strings",
        "external_table_source_url_filenames_unique",
        "external_table_source_sha256s_available",
        "external_table_source_sha256s_items_nonempty_strings",
        "external_table_source_witness_pairs_unique",
    ]


def _verified_signed_assignment(notation: str, crossing_count: int) -> dict:
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "verified_signed_crossing_assignment",
        "claim_scope": "verified_signed_crossing_assignment",
        "notation": notation,
        "source_url": f"https://katlas.org/wiki/{notation}",
        "crossing_count": crossing_count,
        "signs": [1] * crossing_count,
        "role_orders": [[0, 1, 2, 3] for _ in range(crossing_count)],
        "source_gauss_code_match": True,
        "source_candidate_replay_valid": True,
        "candidate_replay_sha256": "a" * 64,
        "unique_assignment_certified": True,
        "invariant_table_values_verified": True,
        "invariant_table_source_urls": [
            f"https://evidence.iroll.dev/tables/{notation}"
        ],
        "invariant_table_source_sha256s": ["b" * 64],
        "orientation_validation_issue_count": 0,
    }


def _full_alexander_certification_pack() -> dict:
    global _FULL_ALEXANDER_TEST_PACK_CACHE
    if _FULL_ALEXANDER_TEST_PACK_CACHE is not None:
        return _FULL_ALEXANDER_TEST_PACK_CACHE

    pinned = full_alexander_pinned_sources()
    assignments = []
    data_witnesses = {}
    page_witnesses = []
    for notation in ("L5a1", "L6a4"):
        fixture = get_diagram_fixture(notation)
        derivation = fixture.source_pd_convention_assignment_audit()
        assignments.append(
            {
                "artifact_schema_version": 1,
                "artifact_kind": "verified_signed_crossing_assignment",
                "claim_scope": "verified_signed_crossing_assignment",
                "notation": notation,
                "source_url": (
                    f"https://katlas.org/wiki/Data:{notation}/PD_Presentation"
                ),
                "crossing_count": len(derivation["signs"]),
                "signs": derivation["signs"],
                "role_orders": derivation["role_orders"],
                "source_gauss_code_match": True,
                "source_candidate_replay_valid": True,
                "candidate_replay_sha256": "a" * 64,
                "unique_assignment_certified": True,
                "invariant_table_values_verified": True,
                "invariant_table_source_urls": [
                    f"https://katlas.org/wiki/{notation}"
                ],
                "invariant_table_source_sha256s": ["b" * 64],
                "orientation_validation_issue_count": 0,
            }
        )
        data = pinned[notation]["data"]
        data_witnesses[notation] = {
            "title": data["title"],
            "revision_id": data["revision_id"],
            "url": data["url"],
            "expected_sha256": data["sha256"],
            "actual_sha256": data["sha256"],
            "byte_count": len(data["expected_math_source"].encode("utf-8")),
            "fetched": True,
            "sha256_verified": True,
            "error": None,
            "_content": data["expected_math_source"],
        }
        page = pinned[notation]["page"]
        page_witnesses.append(
            {
                "notation": notation,
                "title": page["title"],
                "revision_id": page["revision_id"],
                "url": page["url"],
                "expected_sha256": page["sha256"],
                "actual_sha256": page["sha256"],
                "byte_count": 128,
                "fetched": True,
                "sha256_verified": True,
                "error": None,
            }
        )

    report = full_multivariable_alexander_normalization_certification_report(
        verified_signed_crossing_assignments=assignments,
        source_witnesses=data_witnesses,
    )
    report_audit = (
        full_multivariable_alexander_normalization_certification_report_audit(report)
    )
    raw_sha256 = serialized_certification_report_sha256(report)
    canonical_sha256 = canonical_json_sha256(report)
    report_url = "https://evidence.iroll.dev/certification/full-alexander.json"
    report_byte_count = len(
        (json.dumps(report, indent=2, sort_keys=True) + "\n").encode("utf-8")
    )
    _FULL_ALEXANDER_TEST_PACK_CACHE = {
        "artifact_schema_version": 1,
        "artifact_kind": (
            "full_multivariable_alexander_normalization_certification_pack"
        ),
        "claim_scope": "full_multivariable_alexander_normalization",
        "full_multivariable_alexander_normalization_certified": True,
        "signed_pd_wirtinger_fox_certified": True,
        "admissible_minor_normalization_certified": True,
        "all_admissible_minors_consistent": True,
        "external_table_normalization_certified": True,
        "counterexample_count": 0,
        "certification_report_url": report_url,
        "certification_report_sha256": raw_sha256,
        "certification_report_raw_sha256": raw_sha256,
        "certification_report_canonical_sha256": canonical_sha256,
        "certification_report_published_witness": {
            "title": (
                "iroll full multivariable Alexander certification report"
            ),
            "revision_id": 0,
            "url": report_url,
            "expected_sha256": raw_sha256,
            "actual_sha256": raw_sha256,
            "byte_count": report_byte_count,
            "fetched": True,
            "sha256_verified": True,
            "error": None,
        },
        "certification_report_published_json_matches": True,
        "certification_report_published_canonical_sha256": canonical_sha256,
        "certification_report": report,
        "certification_report_replay_audit": report_audit,
        "external_table_source_urls": [
            pinned[notation]["page"]["url"] for notation in ("L5a1", "L6a4")
        ],
        "external_table_source_sha256s": [
            pinned[notation]["page"]["sha256"]
            for notation in ("L5a1", "L6a4")
        ],
        "external_table_source_witnesses": page_witnesses,
        "template_placeholder": False,
        "completion_claimed": True,
    }
    return _FULL_ALEXANDER_TEST_PACK_CACHE


def test_cross_workstream_validation_pack_accepts_full_alexander_pack() -> None:
    alexander_pack = _full_alexander_certification_pack()

    report = cross_workstream_validation_pack_audit(
        full_multivariable_alexander_normalization_certification_pack=(
            alexander_pack
        ),
    )
    preflight = completion_evidence_artifact_audit(
        alexander_pack,
        artifact_type=(
            "full_multivariable_alexander_normalization_certification_pack"
        ),
    )

    gate_checks = {row["gate"]: row for row in report["final_completion_gate_checks"]}
    assert report["final_completion_ready"] is False
    assert report["full_multivariable_alexander_normalization_certified"] is True
    assert "full_multivariable_alexander_normalization_not_certified" not in report[
        "final_completion_blocker_code_counts"
    ]
    assert gate_checks["full_multivariable_alexander_normalization"]["passed"] is True
    assert preflight["artifact_certified"] is True
    assert preflight["failed_checks"] == []


def test_cross_workstream_validation_pack_accepts_verified_signed_assignments() -> None:
    report = cross_workstream_validation_pack_audit(
        verified_signed_crossing_assignments=[
            _verified_signed_assignment("L5a1", 5),
            _verified_signed_assignment("L6a4", 6),
        ],
    )

    assert report["signed_diagram_fixture_registration_complete"] is True
    assert report["unsigned_required_fixture_count"] == 0
    assert report["signed_fixture_blockers"] == []
    assert report["final_completion_blocker_count"] == 5
    assert "signed_pd_not_registered" not in report[
        "final_completion_blocker_code_counts"
    ]
    rows = {row["notation"]: row for row in report["fixtures"]}
    assert rows["L5a1"]["has_signed_pd"] is True
    assert rows["L5a1"]["verified_signed_crossing_assignment_available"] is True
    assert rows["L6a4"]["registration_status"] == (
        "verified_signed_crossing_assignment_pack"
    )
    gate_checks = {row["gate"]: row for row in report["final_completion_gate_checks"]}
    assert gate_checks["signed_diagram_fixture_registration"]["passed"] is True
    assert [
        row["notation"]
        for row in gate_checks["signed_diagram_fixture_registration"][
            "retained_evidence"
        ]
    ] == ["L5a1", "L6a4"]


def test_cross_workstream_validation_pack_all_strong_evidence_reaches_ready() -> None:
    production_pack = {
        "artifact_schema_version": 1,
        "artifact_kind": "imgui_production_renderer_framebuffer_pack",
        "claim_scope": "production_imgui_renderer_framebuffer_verification",
        "real_graphics_backend_framebuffer_verified": True,
        "screenshot_verified": True,
        "graphics_backend_name": "Direct3D11",
        "framebuffer_width": 128,
        "framebuffer_height": 64,
        "screenshot_url": "https://evidence.iroll.dev/production-imgui.png",
        "screenshot_sha256": "a" * 64,
        "render_frame_count": 2,
        "framebuffer_touched": 1,
        "estimated_nonzero_pixels": 8192,
        "passed": True,
    }
    release_manifest = {
        "artifact_schema_version": 1,
        "artifact_kind": "signed_release_publication_manifest",
        "claim_scope": "signed_release_publication",
        "signed_release_artifacts_published": True,
        "publication_claimed": True,
        "platform_index_publication_claimed": True,
        "published_artifact_count": 2,
        "signature_count": 2,
        "package_index_url": "https://evidence.iroll.dev/releases/0.1.0",
        "artifact_urls": [
            "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0-py3-none-any.whl",
            "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0.tar.gz",
        ],
        "artifact_sha256s": ["a" * 64, "b" * 64],
        "signature_urls": [
            "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0-py3-none-any.whl.sig",
            "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0.tar.gz.sig",
        ],
        "signature_sha256s": ["c" * 64, "d" * 64],
    }
    homfly_pack = _full_homfly_certification_pack()
    alexander_pack = _full_alexander_certification_pack()

    report = cross_workstream_validation_pack_audit(
        verified_signed_crossing_assignments=[
            _verified_signed_assignment("L5a1", 5),
            _verified_signed_assignment("L6a4", 6),
        ],
        production_imgui_renderer_framebuffer_pack=production_pack,
        signed_release_publication_manifest=release_manifest,
        full_homfly_pt_evaluation_certification_pack=homfly_pack,
        full_multivariable_alexander_normalization_certification_pack=(
            alexander_pack
        ),
    )

    assert report["final_completion_ready"] is True
    assert report["final_completion_blocker_count"] == 0
    assert report["final_completion_blocker_code_counts"] == {}
    assert report["final_completion_passed_gate_count"] == (
        report["final_completion_gate_count"]
    )
    assert report["final_completion_required_check_consistency"]["matched"] is True
    assert (
        report["final_completion_required_check_consistency"][
            "mismatched_required_check_count"
        ]
        == 0
    )
    assert report["final_completion_non_claim_gate_consistency"]["matched"] is True
    assert (
        report["final_completion_non_claim_gate_consistency"][
            "mismatched_non_claim_field_count"
        ]
        == 0
    )
    assert (
        report["final_completion_completion_gate_evidence_consistency"]["matched"]
        is True
    )
    assert (
        report["final_completion_completion_gate_evidence_consistency"][
            "mismatched_gate_count"
        ]
        == 0
    )


def test_cross_workstream_validation_pack_audit_reports_missing_required_fixture() -> None:
    report = cross_workstream_validation_pack_audit(
        required_notations=["0_1", "missing-fixture"],
    )

    assert report["registered_required_diagram_fixture_count"] == 1
    assert report["missing_required_diagram_fixture_notations"] == ["missing-fixture"]
    assert report["required_diagram_fixture_metadata_complete"] is False
    assert report["metadata_blocker_count"] == 1
    assert report["metadata_blockers"][0]["code"] == "required_fixture_missing"


def test_cross_workstream_validation_pack_fixture_row_rejects_non_http_source_url() -> None:
    fixture = DiagramFixture(
        notation="Xftp",
        name="invalid source URL fixture",
        kind="link",
        component_count=1,
        pd_code=(),
        signs=(),
        expected_jones="1",
        expected_homfly="1",
        expected_multivariable_alexander="1",
        source="External Table",
        source_url="ftp://example.test/Xftp",
        convention_notes=("synthetic URL-shape regression",),
    )

    row = _cross_workstream_validation_pack_fixture_row(fixture)

    assert row["source_url_required"] is True
    assert row["source_url_scheme"] == "ftp"
    assert row["source_url_domain"] == "example.test"
    assert row["source_url_http_or_https"] is False
    assert row["metadata_checks"]["source_url_available_when_applicable"] is True
    assert (
        row["metadata_checks"]["source_url_http_or_https_when_applicable"]
        is False
    )
    assert row["metadata_complete"] is False
    assert row["metadata_blockers"] == [
        {
            "notation": "Xftp",
            "code": "source_url_http_or_https_when_applicable",
            "reason": "required validation-pack fixture metadata is missing",
        }
    ]


def test_unsigned_borromean_source_invariant_candidates_converge_for_alexander() -> None:
    fixture = get_diagram_fixture("L6a4")

    diagnostics = fixture.source_invariant_candidate_diagnostics(
        max_orientation_samples=64,
        max_candidates=8,
        compute_homfly=False,
    )

    assert diagnostics["method"] == (
        "diagram_fixture_source_invariant_candidate_diagnostics"
    )
    assert diagnostics["skipped"] is False
    assert diagnostics["gauss_code_match_required"] is True
    assert diagnostics["target_pairwise_linking"] == [0.0, 0.0, 0.0]
    assert diagnostics["link_table_entry"]["notation"] == "L6a4"
    assert diagnostics["matching_candidate_count"] == 8
    assert diagnostics["returned_candidate_count"] == 8
    assert diagnostics["candidate_groups"][0]["count"] == 8

    convergence = diagnostics["candidate_convergence"]
    assert convergence["method"] == (
        "diagram_fixture_source_invariant_candidate_convergence"
    )
    assert convergence["complete_candidate_set"] is True
    assert convergence["stable_invariants"] == [
        "jones",
        "multivariable_alexander",
    ]
    assert convergence["invariants"]["jones"]["unique_values"] == [
        "-t^-3 + 3t^-2 - 2t^-1 + 4 - 2t + 3t^2 - t^3",
    ]
    assert convergence["invariants"]["multivariable_alexander"]["unique_values"] == [
        "1 - t3 - t2 + t2*t3 - t1 + t1*t3 + t1*t2 - t1*t2*t3",
    ]
    assert convergence["invariants"]["homfly"]["computed_candidate_count"] == 0


def test_unsigned_borromean_source_table_audit_matches_jones_and_alexander() -> None:
    fixture = get_diagram_fixture("L6a4")

    audit = fixture.source_table_invariant_audit(max_candidates=8)

    assert audit["method"] == "diagram_fixture_source_table_invariant_audit"
    assert audit["notation"] == "L6a4"
    assert audit["source"] == "Knot Atlas"
    assert audit["source_url"] == "https://katlas.org/wiki/L6a4"
    assert audit["has_signed_pd"] is False
    assert audit["registered_fixture_invariant_claim"] is False
    assert audit["complete_candidate_set"] is True
    assert audit["matched_source_table_invariants"] == [
        "jones",
        "multivariable_alexander_numerator",
    ]
    assert audit["uncomputed_source_table_invariants"] == ["homfly"]
    assert audit["uncomputed_source_table_invariant_count"] == 1
    assert audit["mismatched_source_table_invariants"] == []
    assert audit["mismatched_source_table_invariant_count"] == 0
    assert audit["unstable_source_table_invariants"] == []
    assert audit["unstable_source_table_invariant_count"] == 0
    assert audit["source_table_registration_ready"] is False
    assert audit["source_table_registration_blockers"] == [
        "fixture_signs_not_registered",
        "registered_fixture_invariant_claim_disabled",
        "source_table_values_uncomputed",
        "source_compatible_sign_pattern_not_unique",
    ]
    assert audit["source_table_registration_blocker_count"] == 4
    assert audit["source_table_registration_blocker_details"][
        "source_table_values_uncomputed"
    ] == ["homfly"]
    convergence_summary = audit["source_table_candidate_convergence_summary"]
    assert convergence_summary["method"] == (
        "diagram_fixture_source_table_candidate_convergence_summary"
    )
    assert convergence_summary["complete_candidate_set"] is True
    assert convergence_summary["partial_source_table_convergence_certified"] is True
    assert convergence_summary["full_source_table_convergence_certified"] is False
    assert convergence_summary["certified_invariants"] == [
        "jones",
        "multivariable_alexander_numerator",
    ]
    assert convergence_summary["certified_invariant_count"] == 2
    assert convergence_summary["uncertified_invariants"] == ["homfly"]
    assert convergence_summary["uncertified_invariant_count"] == 1
    assert convergence_summary["source_value_seen_invariants"] == [
        "jones",
        "multivariable_alexander_numerator",
    ]
    assert convergence_summary["source_value_seen_invariant_count"] == 2
    assert convergence_summary["source_value_seen_but_uncertified_invariants"] == []
    assert convergence_summary[
        "source_value_seen_but_uncertified_invariant_count"
    ] == 0
    assert audit["source_table_candidate_convergence_partial_certified"] is True
    assert audit["source_table_candidate_convergence_full_certified"] is False
    assert audit["source_table_candidate_convergence_certified_invariant_count"] == 2
    assert audit["source_table_candidate_convergence_uncertified_invariant_count"] == 1
    assert audit[
        "source_table_candidate_convergence_source_value_seen_invariant_count"
    ] == 2
    assert (
        audit[
            "source_table_candidate_convergence_source_value_seen_but_uncertified_invariant_count"
        ]
        == 0
    )

    jones = audit["comparisons"]["jones"]
    assert jones["source_value"] == (
        "-t^-3 + 3t^-2 - 2t^-1 + 4 - 2t + 3t^2 - t^3"
    )
    assert jones["source_value_seen"] is True
    assert jones["complete_candidate_source_match"] is True
    assert jones["source_match_resolution_status"] == "complete_source_match"
    assert jones["source_match_resolution_status_code"] == 3
    assert jones["candidate_unique_value_count"] == 1
    assert jones["missing_candidate_count"] == 0

    alexander = audit["comparisons"]["multivariable_alexander_numerator"]
    assert alexander["source_value"] == (
        "1 - t3 - t2 + t2*t3 - t1 + t1*t3 + t1*t2 - t1*t2*t3"
    )
    assert alexander["source_value_seen"] is True
    assert alexander["complete_candidate_source_match"] is True
    assert alexander["source_match_resolution_status"] == "complete_source_match"
    assert alexander["source_match_resolution_status_code"] == 3
    assert alexander["candidate_unique_value_count"] == 1
    assert alexander["skipped_candidate_count"] == 0

    homfly = audit["comparisons"]["homfly"]
    assert homfly["computed_candidate_count"] == 0
    assert homfly["source_match_resolution_status"] == "not_computed"
    assert homfly["source_match_resolution_status_code"] == 2
    assert homfly["source_value_variant_resolution_status"] == "not_computed"
    assert homfly["source_value_variant_resolution_status_code"] == 2

    assert audit["source_table_candidate_count"] == 8
    assert audit["source_table_computed_source_compatible_candidate_count"] == 8
    assert audit["source_table_complete_source_compatible_candidate_count"] == 0
    assert audit["source_table_top_candidate_count"] == 8
    assert audit["source_table_top_candidate_unique_sign_pattern_count"] == 8
    assert audit["source_table_max_matched_source_value_count"] == 2
    assert audit["source_table_max_matched_candidate_count"] == 8
    assert audit["source_table_max_matched_candidate_unique_sign_pattern_count"] == 8
    assert audit["source_table_homfly_candidate_unique_value_count"] == 0
    assert audit["source_table_homfly_candidate_unit_normalized_value_count"] == 0

    match_summary = audit["candidate_source_table_match_summary"]
    assert match_summary["source_value_names"] == [
        "jones",
        "homfly",
        "multivariable_alexander_numerator",
    ]
    assert match_summary["candidate_count"] == 8
    assert match_summary["computed_source_compatible_candidate_count"] == 8
    assert match_summary["complete_source_compatible_candidate_count"] == 0
    assert match_summary["max_matched_source_value_count"] == 2
    assert match_summary["max_matched_candidate_count"] == 8
    assert match_summary["max_matched_candidate_unique_sign_pattern_count"] == 8
    assert match_summary["top_candidate_count"] == 8
    assert match_summary["top_candidate_unique_sign_pattern_count"] == 8
    assert match_summary["top_candidate_unique_sign_patterns"] == [
        [-1, -1, -1, 1, 1, 1],
        [-1, -1, 1, 1, 1, -1],
        [-1, 1, -1, -1, 1, 1],
        [-1, 1, 1, -1, 1, -1],
        [1, -1, -1, 1, -1, 1],
        [1, -1, 1, 1, -1, -1],
        [1, 1, -1, -1, -1, 1],
        [1, 1, 1, -1, -1, -1],
    ]
    assert match_summary["top_candidates"][0]["signs"] == [-1, -1, -1, 1, 1, 1]


def test_unsigned_borromean_source_table_audit_keeps_homfly_gap_visible() -> None:
    fixture = get_diagram_fixture("L6a4")

    audit = fixture.source_table_invariant_audit(
        max_candidates=8,
        compute_homfly=True,
        homfly_max_depth=8,
        homfly_max_nodes=4096,
        alexander_max_minors=256,
    )

    assert audit["complete_candidate_set"] is True
    assert audit["registered_fixture_invariant_claim"] is False
    assert audit["matched_source_table_invariants"] == [
        "jones",
        "multivariable_alexander_numerator",
    ]
    assert audit["uncomputed_source_table_invariants"] == []
    assert audit["uncomputed_source_table_invariant_count"] == 0
    assert audit["mismatched_source_table_invariants"] == ["homfly"]
    assert audit["mismatched_source_table_invariant_count"] == 1
    assert audit["unstable_source_table_invariants"] == []
    assert audit["unstable_source_table_invariant_count"] == 0
    assert audit["source_table_registration_ready"] is False
    assert audit["source_table_registration_blockers"] == [
        "fixture_signs_not_registered",
        "registered_fixture_invariant_claim_disabled",
        "source_table_values_mismatched",
        "source_compatible_sign_pattern_not_unique",
    ]
    assert audit["source_table_registration_blocker_count"] == 4
    assert audit["source_table_registration_blocker_details"][
        "source_table_values_mismatched"
    ] == ["homfly"]

    homfly = audit["comparisons"]["homfly"]
    assert homfly["source_value"] == (
        "-a^2*z^2 - a^-2*z^2 + a^2*z^-2 + a^-2*z^-2 + z^4 + 2z^2 - 2z^-2"
    )
    assert homfly["computed_candidate_count"] == 8
    assert homfly["missing_candidate_count"] == 0
    assert homfly["skipped_candidate_count"] == 0
    assert homfly["candidate_unique_value_count"] == 3
    assert homfly["source_value_seen"] is False
    assert homfly["complete_candidate_source_match"] is False
    assert homfly["returned_candidate_source_match"] is False
    assert homfly["source_match_resolution_status"] == "source_missed_with_candidates"
    assert homfly["source_match_resolution_status_code"] == 8
    assert homfly["source_value_variant_count"] == 8
    assert [
        variant["name"] for variant in homfly["source_value_variants"]
    ] == [
        "identity",
        "invert_a",
        "negate_z",
        "mirror_invert_a_negate_z",
        "invert_z",
        "invert_a_invert_z",
        "negate_z_invert_z",
        "mirror_invert_a_negate_z_invert_z",
    ]
    assert homfly["source_value_seen_variant_names"] == [
        "identity",
        "invert_a",
        "negate_z",
        "mirror_invert_a_negate_z",
    ]
    assert homfly["source_value_seen_variant_count"] == 4
    assert homfly["source_value_any_variant_seen"] is True
    assert homfly["source_value_seen_after_unit_normalization"] is True
    assert homfly["source_value_unit_normalized_variant_count"] == 8
    assert homfly["source_value_seen_unit_normalized_variant_names"] == [
        "identity",
        "invert_a",
        "negate_z",
        "mirror_invert_a_negate_z",
    ]
    assert homfly["source_value_seen_unit_normalized_variant_count"] == 4
    assert homfly["source_value_any_unit_normalized_variant_seen"] is True
    assert homfly["source_value_variant_resolution_status"] == "source_variant_seen"
    assert homfly["source_value_variant_resolution_status_code"] == 4
    assert homfly["candidate_unit_normalized_value_count"] == 3
    assert audit["source_table_homfly_candidate_unique_value_count"] == 3
    assert audit["source_table_homfly_candidate_unit_normalized_value_count"] == 3
    assert [
        variant["name"]
        for variant in homfly["source_value_variants"]
        if variant["source_value_seen"]
    ] == ["identity", "invert_a", "negate_z", "mirror_invert_a_negate_z"]
    assert [
        variant["name"]
        for variant in homfly["source_value_variants"]
        if variant["source_value_seen_after_unit_normalization"]
    ] == ["identity", "invert_a", "negate_z", "mirror_invert_a_negate_z"]
    assert homfly["notes"] == [
        "normalized source value was not seen among candidate values",
        "a normalized source convention variant was seen among candidate values",
        "a source convention variant matched after Laurent-unit normalization",
    ]

    convergence_homfly = audit["candidate_diagnostics"]["candidate_convergence"][
        "invariants"
    ]["homfly"]
    assert convergence_homfly["computed_candidate_count"] == 8
    assert convergence_homfly["stable_across_complete_candidates"] is False
    assert convergence_homfly["stable_across_returned_candidates"] is False
    assert convergence_homfly["unique_value_count"] == 3

    assert audit["source_table_candidate_count"] == 8
    assert audit["source_table_computed_source_compatible_candidate_count"] == 0
    assert audit["source_table_complete_source_compatible_candidate_count"] == 0
    assert audit["source_table_top_candidate_count"] == 0
    assert audit["source_table_top_candidate_unique_sign_pattern_count"] == 0
    assert audit["source_table_max_matched_source_value_count"] == 2
    assert audit["source_table_max_matched_candidate_count"] == 8
    assert audit["source_table_max_matched_candidate_unique_sign_pattern_count"] == 8

    match_summary = audit["candidate_source_table_match_summary"]
    assert match_summary["source_value_names"] == [
        "jones",
        "homfly",
        "multivariable_alexander_numerator",
    ]
    assert match_summary["candidate_count"] == 8
    assert match_summary["computed_source_compatible_candidate_count"] == 0
    assert match_summary["complete_source_compatible_candidate_count"] == 0
    assert match_summary["max_matched_source_value_count"] == 2
    assert match_summary["max_matched_candidate_count"] == 8
    assert match_summary["max_matched_candidate_unique_sign_pattern_count"] == 8
    assert match_summary["top_candidate_count"] == 0


def test_signed_standard_fixtures_match_jones_convention() -> None:
    for notation in ["0_1", "L2a1", "3_1", "4_1"]:
        fixture = get_diagram_fixture(notation)
        diagram = fixture.diagram()

        assert fixture.has_signed_pd is True
        assert diagram.to_dict() == PlanarDiagram.from_dict(diagram.to_dict()).to_dict()
        assert jones_polynomial_from_pd(diagram) == fixture.expected_jones
