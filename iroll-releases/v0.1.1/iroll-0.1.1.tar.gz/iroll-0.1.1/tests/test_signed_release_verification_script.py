from __future__ import annotations

import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

import pytest


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "verify_signed_release_publication.ps1"


def test_signed_release_verifier_covers_remote_bytes_and_ed25519() -> None:
    source = SCRIPT.read_text(encoding="utf-8")

    for token in [
        "signed_release_publication_verification_report",
        "manifest_strict_json_validated",
        "object_pairs_hook=reject_duplicate_keys",
        "duplicate JSON object property",
        "parse_constant=reject_nonstandard_constant",
        "ReportPath",
        "report_output_written",
        "UTF8Encoding",
        "package_index_url",
        "artifact_urls",
        "artifact_sha256s",
        "signature_urls",
        "signature_sha256s",
        "signature_algorithm",
        "public_key_url",
        "public_key_sha256",
        "package_index_sha256",
        "published_ed25519_public_key_verified",
        "package_index_sha256_verified",
        "Invoke-WebRequest",
        "-PassThru",
        "RequireHtmlContentType",
        "package_index_content_type_verified",
        "application/vnd.pypi.simple.v1+html",
        "text/html",
        "sha256=",
        '"$artifactFilename.sig"',
        "pkeyutl",
        "-verify",
        "-pubin",
        "-rawin",
        "--no-deps",
        "--no-index",
        "--find-links",
        "--only-binary=:all:",
        "Remove-Item -Recurse -Force",
    ]:
        assert token in source

    assert "pkeyutl -sign" not in source
    assert "PRIVATE KEY" not in source
    assert 'pip_find_links_source = $packageIndexUri.AbsoluteUri' in source
    assert "--find-links $packageIndexUri.AbsoluteUri" in source
    assert re.search(r"(?im)^\s*\$host\s*=", source) is None


@pytest.mark.skipif(sys.platform != "win32", reason="PowerShell verifier is Windows tooling")
def test_signed_release_verifier_failure_is_machine_readable_json() -> None:
    powershell = shutil.which("powershell")
    if powershell is None:
        pytest.skip("Windows PowerShell is not installed")

    result = subprocess.run(
        [
            powershell,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(SCRIPT),
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8-sig",
    )

    payload = json.loads(result.stdout)
    assert result.returncode != 0
    assert result.stderr == ""
    assert payload["artifact_kind"] == (
        "signed_release_publication_verification_report"
    )
    assert payload["verification_succeeded"] is False
    assert payload["failed_check"] == "input_validation"
    assert payload["failure_message"] == "ManifestPath is required"
    assert payload["ci_exit_code"] == 1


@pytest.mark.skipif(sys.platform != "win32", reason="PowerShell verifier is Windows tooling")
def test_signed_release_verifier_rejects_duplicate_json_properties(
    tmp_path: Path,
) -> None:
    powershell = shutil.which("powershell")
    if powershell is None:
        pytest.skip("Windows PowerShell is not installed")

    manifest = tmp_path / "duplicate-property-manifest.json"
    manifest.write_text(
        '{"completion_claimed":false,"completion_claimed":true}',
        encoding="utf-8",
    )
    public_key = tmp_path / "nonempty-placeholder.pem"
    public_key.write_text("strict JSON validation runs first\n", encoding="utf-8")

    result = subprocess.run(
        [
            powershell,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(SCRIPT),
            "-ManifestPath",
            str(manifest),
            "-PublicKeyPath",
            str(public_key),
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8-sig",
    )

    payload = json.loads(result.stdout)
    assert result.returncode != 0
    assert payload["verification_succeeded"] is False
    assert payload["failed_check"] == "manifest_strict_json"
    assert "duplicate JSON object property" in payload["failure_message"]
    assert payload["ci_exit_code"] == 1
