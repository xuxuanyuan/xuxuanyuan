from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest

from iroll import Link3D, Polyline3D, Ribbon3D
from iroll.reports import (
    analysis_summary_from_acceptance_report,
    assert_valid_report,
    contact_overlays_from_report,
    fixture_comparisons_from_acceptance_report,
    geometry_components_from_report,
    imgui_analysis_payload_from_acceptance_reports,
    imgui_fixture_comparison_payload_from_acceptance_reports,
    imgui_geometry_payload_from_report,
    imgui_host_payload_from_acceptance_reports,
    imgui_invariant_status_payload_from_acceptance_reports,
    imgui_invariant_status_payload_from_reports,
    imgui_kernel_backend_status_payload_from_backend_report,
    imgui_link_classification_summary_payload_from_report,
    imgui_signed_pd_payload_from_acceptance_reports,
    infer_report_kind,
    invariant_status_from_acceptance_report,
    invariant_status_from_alexander_improved_result,
    invariant_status_from_pd_report,
    kernel_backend_statuses_from_backend_report,
    projected_crossings_from_report,
    signed_pd_payloads_from_acceptance_report,
    validate_report,
)
from iroll.reports.imgui import (
    _source_table_homfly_variant_resolution_status,
    _source_table_homfly_variant_resolution_status_code,
    _source_table_source_match_resolution_status,
    _source_table_source_match_resolution_status_code,
)
from iroll.topology import (
    analyze_curve,
    analyze_link,
    analyze_ribbon,
    cross_workstream_validation_pack_audit,
    get_diagram_fixture,
    homfly_fixture_acceptance_report,
    homfly_small_diagram_coverage_report,
    multivariable_alexander_fixture_acceptance_report,
    multivariable_alexander_signed_pd_coverage_report,
)
from iroll.topology.pd_fixtures import (
    _source_table_homfly_variant_resolution_status_code as _fixture_homfly_status_code,
    _source_table_source_match_resolution_status_code as _fixture_match_status_code,
)
from tests.fixtures import circle_points, hopf_link_points


_BLOCKER_COUNT_KEYS = (
    "certification_blocker_count",
    "homfly_completion_blocker_count",
    "admissible_minor_normalization_blocker_count",
    "full_alexander_completion_blocker_count",
)

_COMPACT_HOST_EVIDENCE_KEYS = (
    "certification_blocker_detail_count",
    "homfly_completion_blocker_detail_count",
    "frontier_witness_summary_count",
    "frontier_witness_summary_truncated",
    "frontier_witness_summary_reason_count",
    "frontier_witness_summary_recursive_path_prefix_count",
    "frontier_witness_summary_source_kind_count",
    "frontier_witness_summary_branch_count",
    "frontier_witness_summary_min_depth",
    "frontier_witness_summary_max_depth",
    "frontier_witness_summary_min_branch_depth",
    "frontier_witness_summary_max_branch_depth",
    "frontier_witness_summary_pressure_total_frontier_count",
    "frontier_witness_summary_pressure_visible_witness_count",
    "frontier_witness_summary_pressure_missing_frontier_count",
    "frontier_witness_summary_pressure_all_frontiers_have_visible_witness",
    "frontier_witness_summary_pressure_reason_count",
    "homfly_completion_blocker_provenance_matched",
    "homfly_completion_blocker_provenance_non_claim_matched",
    "homfly_completion_blocker_provenance_gate_pressure_matched",
    "homfly_completion_blocker_provenance_frontier_pressure_matched",
    "homfly_completion_blocker_provenance_frontier_witness_matched",
    "homfly_completion_blocker_provenance_terminal_audit_matched",
    "homfly_completion_blocker_provenance_source_field_count",
    "failed_division_witness_count",
    "quotient_gcd_uncertainty_present",
    "quotient_polynomial_witness_count",
    "quotient_polynomial_witness_truncated",
    "normalization_class_witness_count",
    "admissible_minor_normalization_blocker_reason_count",
    "admissible_minor_normalization_blocker_witness_available_count",
    "admissible_minor_normalization_blocker_missing_witness_reason_count",
    "admissible_minor_normalization_blocker_witness_source_count",
    "admissible_minor_normalization_blocker_witness_source_available_count",
    "admissible_minor_normalization_blocker_witness_source_missing_count",
    "admissible_minor_normalization_gate_count",
    "admissible_minor_normalization_gate_passed_count",
    "admissible_minor_normalization_gate_failed_count",
    "admissible_minor_normalization_gate_summary_consistent",
    "admissible_minor_normalization_failed_gate_blocker_count",
    "admissible_minor_normalization_failed_gate_blocker_provenance_consistent",
    "admissible_minor_normalization_failed_gate_blocker_provenance_row_count",
    "admissible_minor_normalization_failed_gate_blocker_provenance_gate_count",
    "admissible_minor_normalization_failed_gate_blocker_provenance_attribution_count",
    "admissible_minor_normalization_failed_gate_blocker_provenance_reason_count",
    "admissible_minor_normalization_failed_gate_blocker_provenance_source_available_count",
    "admissible_minor_normalization_failed_gate_blocker_provenance_source_missing_count",
    "admissible_minor_normalization_failed_gate_blocker_provenance_missing_source_count",
    "admissible_minor_normalization_failed_gate_blocker_provenance_inconsistent_source_count",
)

_SOURCE_TABLE_WITNESS_KEYS = (
    "source_table_alexander_source_divisibility_failed_candidate_witness_count",
    "source_table_alexander_source_divisibility_failed_candidate_witness_truncated",
)

_CURRENT_HOST_FIELD_KEYS = (
    _BLOCKER_COUNT_KEYS + _COMPACT_HOST_EVIDENCE_KEYS + _SOURCE_TABLE_WITNESS_KEYS
)

_CURRENT_HOST_NOTE_TOKENS = (
    "blocker_detail_count=",
    "first_certification_blocker_detail_",
    "first_homfly_completion_blocker_detail_",
    "frontier_witness_summary=",
    "recursive_path_prefix_count=",
    "source_kind_count=",
    "branch_count=",
    "frontier_witness_pressure=",
    "homfly_completion_blocker_provenance=",
    "alexander_witness_evidence=",
    "admissible_minor_normalization_blocker_witness_summary=",
    "admissible_minor_normalization_gate_summary=",
    "admissible_minor_normalization_gate_provenance=",
)

_CURRENT_BACKEND_STATUS_KEYS = (
    "owned_string_contract_schema_version",
    "owned_string_contract_abi_version",
    "owned_string_contract_version_length",
    "owned_string_contract_free_required",
    "owned_string_contract_free_accepts_zero_initialized",
    "owned_string_contract_borrowed_across_calls",
    "invariant_result_handles_native_result_handles_complete",
    "invariant_result_handles_complete_result_handle_abi",
    "invariant_result_handles_release_grade_result_handles",
    "invariant_result_handles_readiness_provenance_present",
    "invariant_result_handles_ready_for_native_result_handles",
    "invariant_result_handles_readiness_blocked_by_required_gates",
    "invariant_result_handles_readiness_provenance_note_length",
)

_CURRENT_BACKEND_PAYLOAD_KEYS = (
    "kernel_backend_invariant_result_handles_native_result_handles_complete_count",
    "kernel_backend_invariant_result_handles_complete_result_handle_abi_count",
    "kernel_backend_invariant_result_handles_release_grade_result_handles_count",
    "kernel_backend_invariant_result_handles_readiness_provenance_present_count",
    "kernel_backend_invariant_result_handles_ready_for_native_result_handles_count",
    "kernel_backend_invariant_result_handles_readiness_blocked_by_required_gates_count",
    "kernel_backend_invariant_result_handles_readiness_provenance_note_length_max",
)


def _sample_with_current_blocker_count_fields(
    sample: dict[str, object],
    generated: dict[str, object],
) -> dict[str, object]:
    sample = json.loads(json.dumps(sample))
    for section, prefix, rows_key in (
        ("analysis", "analysis", "analysis_summaries"),
        ("invariants", "invariant", "invariant_statuses"),
    ):
        sample_section = sample.get(section)
        generated_section = generated.get(section)
        if not isinstance(sample_section, dict) or not isinstance(
            generated_section,
            dict,
        ):
            continue
        for key in _CURRENT_HOST_FIELD_KEYS:
            aggregate_key = f"{prefix}_{key}"
            if aggregate_key in generated_section:
                sample_section.setdefault(
                    aggregate_key,
                    generated_section[aggregate_key],
                )
            if aggregate_key in generated:
                sample.setdefault(aggregate_key, generated[aggregate_key])
        sample_rows = sample_section.get(rows_key)
        generated_rows = generated_section.get(rows_key)
        if not isinstance(sample_rows, list) or not isinstance(generated_rows, list):
            continue
        for sample_row, generated_row in zip(sample_rows, generated_rows):
            if not isinstance(sample_row, dict) or not isinstance(
                generated_row,
                dict,
            ):
                continue
            for key in _CURRENT_HOST_FIELD_KEYS:
                if key in generated_row:
                    sample_row.setdefault(key, generated_row[key])
            sample_notes = sample_row.get("notes")
            generated_notes = generated_row.get("notes")
            if isinstance(sample_notes, str) and isinstance(generated_notes, str):
                if any(
                    token in generated_notes and token not in sample_notes
                    for token in _CURRENT_HOST_NOTE_TOKENS
                ):
                    sample_row["notes"] = generated_notes
    sample_backends = sample.get("kernel_backends")
    generated_backends = generated.get("kernel_backends")
    if isinstance(sample_backends, dict) and isinstance(generated_backends, dict):
        for key in _CURRENT_BACKEND_PAYLOAD_KEYS:
            if key in generated_backends:
                sample_backends.setdefault(key, generated_backends[key])
        sample_rows = sample_backends.get("kernel_backend_statuses")
        generated_rows = generated_backends.get("kernel_backend_statuses")
        if isinstance(sample_rows, list) and isinstance(generated_rows, list):
            for sample_row, generated_row in zip(sample_rows, generated_rows):
                if not isinstance(sample_row, dict) or not isinstance(
                    generated_row,
                    dict,
                ):
                    continue
                for key in _CURRENT_BACKEND_STATUS_KEYS:
                    if key in generated_row:
                        sample_row.setdefault(key, generated_row[key])
    return sample


def test_curve_report_matches_lightweight_schema() -> None:
    curve = Polyline3D(circle_points(count=64), closed=True)
    report = analyze_curve(curve, direction=[0.0, 0.0, 1.0], backend="numpy")

    assert infer_report_kind(report) == "curve"
    assert len(report["geometry"]["points"]) == 64
    assert len(report["geometry"]["components"][0]["points"]) == 64
    assert validate_report(report) == []
    assert_valid_report(report, kind="curve")


def test_link_report_matches_lightweight_schema() -> None:
    first, second = hopf_link_points(count=128)
    link = Link3D([Polyline3D(first, closed=True), Polyline3D(second, closed=True)])
    report = analyze_link(link, direction=[0.3, 0.5, 1.0], backend="numpy")

    assert infer_report_kind(report) == "link"
    assert report["geometry"]["component_count"] == 2
    assert [len(component["points"]) for component in report["geometry"]["components"]] == [
        128,
        128,
    ]
    assert validate_report(report) == []
    assert_valid_report(report, kind="link")


def test_link_report_exposes_pairwise_zero_candidate_summary_fields() -> None:
    first = circle_points(count=96)
    second = circle_points(count=96).copy()
    second[:, 0] += 1.5
    second[:, 1] += 1.5
    link = Link3D([Polyline3D(first, closed=True), Polyline3D(second, closed=True)])

    report = analyze_link(link, direction=[0.0, 0.0, 1.0], backend="numpy")

    classification = report["topology"]["classification"]
    assert classification["link_type"] == "pairwise_unlink_candidate"
    summary = classification["table_candidate_summary"]
    assert "whitehead_link" in summary["nontrivial_link_types"]
    assert "L5a1" in summary["nontrivial_notations"]
    assert summary["source_table_nontrivial_candidate_count"] >= 1
    assert "L5a1" in summary["source_table_nontrivial_candidate_notations"]
    assert summary["source_table_distinguishing_evidence_available"] is True
    assert summary["stronger_invariants_required"] is True
    assert summary["source_table_source_match_resolution_status_count"] == 3
    assert set(summary["source_table_source_match_resolution_statuses"]) == {
        "L5a1:jones:source_seen_with_incomplete_candidates",
        "L5a1:homfly:not_computed",
        "L5a1:multivariable_alexander_numerator:source_seen_with_incomplete_candidates",
    }
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min"
        ]
        == 25
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max"
        ]
        == 25
    )
    assert validate_report(report) == []
    assert_valid_report(report, kind="link")
    json.dumps(report, allow_nan=False)


def test_validate_report_rejects_non_finite_numbers_as_strict_json() -> None:
    report = {
        "input": {},
        "topology": {"writhe": float("nan")},
        "warnings": [],
        "runtime": {},
        "version": "test",
    }

    issues = validate_report(report)

    strict_json_issues = [
        issue for issue in issues if "strict JSON serializable" in issue.message
    ]
    assert len(strict_json_issues) == 1
    assert strict_json_issues[0].path == "$"
    assert "Out of range float values" in strict_json_issues[0].message


def test_link_report_exposes_borromean_pairwise_zero_candidate_summary() -> None:
    first = circle_points(count=96)
    second = circle_points(count=96).copy()
    third = circle_points(count=96).copy()
    second[:, 0] += 2.0
    third[:, 1] += 2.0
    link = Link3D(
        [
            Polyline3D(first, closed=True),
            Polyline3D(second, closed=True),
            Polyline3D(third, closed=True),
        ]
    )

    report = analyze_link(link, direction=[0.0, 0.0, 1.0], backend="numpy")

    classification = report["topology"]["classification"]
    assert classification["link_type"] == "pairwise_unlink_candidate"
    assert classification["component_count"] == 3
    summary = classification["table_candidate_summary"]
    assert summary["candidate_count"] == 1
    assert summary["nontrivial_candidate_count"] == 1
    assert summary["nontrivial_link_types"] == ["borromean_rings"]
    assert summary["nontrivial_notations"] == ["L6a4"]
    assert summary["source_table_nontrivial_candidate_count"] == 1
    assert summary["source_table_nontrivial_candidate_notations"] == ["L6a4"]
    assert summary["source_table_distinguishing_evidence_available"] is True
    assert summary["stronger_invariants_required"] is True
    assert "not_computed" in summary["source_table_homfly_variant_resolution_statuses"]
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 0
    )
    assert validate_report(report) == []
    assert_valid_report(report, kind="link")
    json.dumps(report, allow_nan=False)


def test_imgui_geometry_payload_exposes_pairwise_zero_classification_summary() -> None:
    first = circle_points(count=96)
    second = circle_points(count=96).copy()
    second[:, 0] += 1.5
    second[:, 1] += 1.5
    link = Link3D([Polyline3D(first, closed=True), Polyline3D(second, closed=True)])
    report = analyze_link(link, direction=[0.0, 0.0, 1.0], backend="numpy")

    payload = imgui_geometry_payload_from_report(report)

    assert payload["source_kind"] == "link"
    summary = payload["classification_summary"]
    assert summary["method"] == "imgui_classification_summary_from_report"
    assert summary["link_type"] == "pairwise_unlink_candidate"
    assert summary["source_method"] == "pairwise_linking_number"
    assert "whitehead_link" in summary["nontrivial_link_types"]
    assert "L5a1" in summary["nontrivial_notations"]
    assert summary["source_table_nontrivial_candidate_count"] >= 1
    assert "L5a1" in summary["source_table_nontrivial_candidate_notations"]
    assert summary["source_table_distinguishing_evidence_available"] is True
    assert summary["stronger_invariants_required"] is True
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max"
        ]
        == 25
    )
    assert "classification_summary is copied" in " ".join(payload["notes"])
    json.dumps(payload, allow_nan=False)


def test_imgui_link_classification_summary_payload_flattens_for_c_abi() -> None:
    first = circle_points(count=96)
    second = circle_points(count=96).copy()
    second[:, 0] += 1.5
    second[:, 1] += 1.5
    link = Link3D([Polyline3D(first, closed=True), Polyline3D(second, closed=True)])
    report = analyze_link(link, direction=[0.0, 0.0, 1.0], backend="numpy")

    payload = imgui_link_classification_summary_payload_from_report(report)

    assert payload["method"] == "imgui_link_classification_summary_payload_from_report"
    assert payload["has_link_classification_summary"] is True
    summary = payload["link_classification_summary"]
    assert summary["method"] == "imgui_classification_summary_from_report"
    assert summary["source_method"] == "pairwise_linking_number"
    assert summary["link_type"] == "pairwise_unlink_candidate"
    assert summary["component_count"] == 2
    assert summary["candidate_count"] >= 1
    assert "whitehead_link" in summary["nontrivial_link_types"]
    assert "L5a1" in summary["nontrivial_notations"]
    assert summary["source_table_nontrivial_candidate_count"] >= 1
    assert "L5a1" in summary["source_table_nontrivial_candidate_notations"]
    assert summary["source_table_distinguishing_evidence_available"] is True
    assert summary["stronger_invariants_required"] is True
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min"
        ]
        == 25
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max"
        ]
        == 25
    )
    assert "display metadata" in summary["notes"]
    json.dumps(payload, allow_nan=False)


def test_imgui_link_classification_summary_payload_flattens_borromean_candidate() -> None:
    first = circle_points(count=96)
    second = circle_points(count=96).copy()
    third = circle_points(count=96).copy()
    second[:, 0] += 2.0
    third[:, 1] += 2.0
    link = Link3D(
        [
            Polyline3D(first, closed=True),
            Polyline3D(second, closed=True),
            Polyline3D(third, closed=True),
        ]
    )
    report = analyze_link(link, direction=[0.0, 0.0, 1.0], backend="numpy")

    payload = imgui_link_classification_summary_payload_from_report(report)

    assert payload["has_link_classification_summary"] is True
    summary = payload["link_classification_summary"]
    assert summary["link_type"] == "pairwise_unlink_candidate"
    assert summary["component_count"] == 3
    assert summary["candidate_count"] == 1
    assert summary["nontrivial_candidate_count"] == 1
    assert summary["nontrivial_link_types"] == "borromean_rings"
    assert summary["nontrivial_notations"] == "L6a4"
    assert summary["source_table_nontrivial_candidate_count"] == 1
    assert summary["source_table_nontrivial_candidate_notations"] == "L6a4"
    assert summary["source_table_distinguishing_evidence_available"] is True
    assert summary["stronger_invariants_required"] is True
    assert summary["source_table_source_match_resolution_status_count"] == 3
    assert set(
        summary["source_table_source_match_resolution_statuses"].split(",")
    ) == {
        "L6a4:jones:complete_source_match",
        "L6a4:homfly:not_computed",
        "L6a4:multivariable_alexander_numerator:complete_source_match",
    }
    assert summary["source_table_homfly_variant_resolution_statuses"] == "not_computed"
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 0
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count"
        ]
        == 0
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min"
        ]
        == 0
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max"
        ]
        == 0
    )
    json.dumps(payload, allow_nan=False)


def test_ribbon_report_matches_lightweight_schema() -> None:
    x = np.linspace(0.0, 1.0, 64)
    points = np.column_stack([x, np.zeros_like(x), np.zeros_like(x)])
    angle = 2.0 * np.pi * x
    directors = np.column_stack([np.zeros_like(angle), np.cos(angle), np.sin(angle)])
    ribbon = Ribbon3D(Polyline3D(points), directors)
    report = analyze_ribbon(ribbon, backend="numpy")

    assert infer_report_kind(report) == "ribbon"
    assert len(report["geometry"]["components"][0]["points"]) == 64
    assert len(report["geometry"]["directors"]) == 64
    assert validate_report(report) == []
    assert_valid_report(report, kind="ribbon")


def test_imgui_geometry_payload_wraps_curve_report_points() -> None:
    curve = Polyline3D(circle_points(count=64), closed=True, name="circle")
    report = analyze_curve(curve, direction=[0.0, 0.0, 1.0], backend="numpy")

    components = geometry_components_from_report(report)
    payload = imgui_geometry_payload_from_report(report)

    assert len(components) == 1
    assert components[0]["name"] == "circle"
    assert components[0]["closed"] is True
    assert components[0]["point_count"] == 64
    assert payload["method"] == "imgui_geometry_payload_from_report"
    assert payload["source_kind"] == "curve"
    assert payload["component_count"] == 1
    assert payload["geometry_point_count"] == 64
    assert len(payload["flat_points"]) == 64 * 3
    assert payload["component_point_counts"] == [64]
    assert payload["component_closed"] == [1]
    assert payload["projected_crossing_count"] == 0
    assert payload["contact_count"] == 0
    json.dumps(payload, allow_nan=False)


def test_imgui_analysis_summary_exposes_alexander_zero_crossing_unlink_counts() -> None:
    report = multivariable_alexander_fixture_acceptance_report(
        notations=["0_1", "L0a1"],
    )
    summary = analysis_summary_from_acceptance_report(report)

    assert report["accepted"] is True
    assert report["fixture_count"] == 2
    assert report["comparison_checked_count"] == 2
    assert report["minor_divisibility_audit_checked_count"] == 0
    assert report["bounded_scanned_gcd_certification_applicable_count"] == 0
    assert report["zero_crossing_unlink_normalization_applicable_count"] == 2
    assert report["zero_crossing_unlink_normalization_certified_count"] == 2
    assert report["zero_crossing_unlink_normalization_uncertified_count"] == 0
    assert report["input_certification_zero_crossing_count"] == 2
    assert report["required_check_count"] == 4
    assert report["passed_check_count"] == 4

    rows = {row["notation"]: row for row in report["fixtures"]}
    assert rows["0_1"]["zero_crossing_unlink_normalization_certified"] is True
    assert rows["L0a1"]["zero_crossing_unlink_normalization_certified"] is True
    assert rows["0_1"]["bounded_scanned_gcd_certification_applicable"] is False
    assert rows["L0a1"]["wirtinger_fox_audit_applicable"] is False

    assert summary["required_check_count"] == 4
    assert summary["passed_check_count"] == 4
    assert summary["failed_check_count"] == 0
    assert summary["certification_applicable_count"] == 0
    assert summary["certification_certified_count"] == 0
    assert summary["input_certification_zero_crossing_count"] == 2
    assert summary["bounded_scanned_gcd_scanned_minor_count"] == 0
    assert summary["wirtinger_fox_relation_count"] == 0

    payload = imgui_analysis_payload_from_acceptance_reports([report])
    assert payload["analysis_required_check_count"] == 4
    assert payload["analysis_passed_check_count"] == 4
    assert payload["analysis_input_certification_zero_crossing_count"] == 2
    assert payload["analysis_bounded_scanned_gcd_scanned_minor_count"] == 0
    json.dumps(payload, allow_nan=False)

def test_imgui_analysis_summary_exposes_registered_knot_normalization_counts() -> None:
    report = multivariable_alexander_fixture_acceptance_report(notations=["3_1"])
    summary = analysis_summary_from_acceptance_report(report)

    assert report["registered_knot_admissible_normalization_applicable_count"] == 1
    assert report["registered_knot_admissible_normalization_certified_count"] == 1
    assert report["registered_knot_admissible_normalization_uncertified_count"] == 0
    assert summary["required_check_count"] == 5
    assert summary["passed_check_count"] == 5
    assert summary[
        "registered_knot_admissible_normalization_applicable_count"
    ] == 1
    assert summary[
        "registered_knot_admissible_normalization_certified_count"
    ] == 1
    assert summary[
        "registered_knot_admissible_normalization_uncertified_count"
    ] == 0

    payload = imgui_analysis_payload_from_acceptance_reports([report])
    assert payload["analysis_required_check_count"] == 5
    assert payload[
        "analysis_registered_knot_admissible_normalization_applicable_count"
    ] == 1
    assert payload[
        "analysis_registered_knot_admissible_normalization_certified_count"
    ] == 1
    assert payload[
        "analysis_registered_knot_admissible_normalization_uncertified_count"
    ] == 0
    json.dumps(payload, allow_nan=False)


def test_imgui_geometry_payload_wraps_link_crossing_overlays() -> None:
    first, second = hopf_link_points(count=128)
    link = Link3D([Polyline3D(first, closed=True), Polyline3D(second, closed=True)])
    report = analyze_link(link, direction=[0.3, 0.5, 1.0], backend="numpy")

    crossings = projected_crossings_from_report(report)
    payload = imgui_geometry_payload_from_report(report)

    assert payload["source_kind"] == "link"
    assert payload["component_count"] == 2
    assert payload["geometry_point_count"] == 256
    assert payload["component_point_counts"] == [128, 128]
    assert payload["component_closed"] == [1, 1]
    assert len(crossings) == report["topology"]["crossing_count"]
    assert payload["projected_crossing_count"] == len(crossings)
    assert payload["projected_crossing_count"] > 0
    first_crossing = payload["projected_crossings"][0]
    assert set(first_crossing) == {
        "component_a",
        "segment_a",
        "parameter_a",
        "component_b",
        "segment_b",
        "parameter_b",
        "point2d",
        "over_component",
        "over_segment",
        "sign",
    }
    assert len(first_crossing["point2d"]) == 2
    assert first_crossing["sign"] in {-1, 1}
    json.dumps(payload, allow_nan=False)


def test_imgui_geometry_sample_payload_matches_generated_hopf_link() -> None:
    first, second = hopf_link_points(count=12)
    link = Link3D(
        [
            Polyline3D(first, closed=True, name="hopf-a"),
            Polyline3D(second, closed=True, name="hopf-b"),
        ],
        name="hopf-link-sample",
    )
    report = analyze_link(link, direction=[0.3, 0.5, 1.0], backend="numpy")
    generated = imgui_geometry_payload_from_report(report)
    sample = json.loads(
        Path("examples/imgui-geometry-payload.sample.json").read_text(
            encoding="utf-8"
        )
    )

    assert sample == generated


def test_imgui_host_sample_payload_matches_generated_hopf_bundle() -> None:
    from examples.generate_imgui_host_payload import (
        build_geometry_report,
        sample_backend_report,
    )

    acceptance_reports = [
        homfly_fixture_acceptance_report(notations=["L2a1"]),
        multivariable_alexander_fixture_acceptance_report(notations=["L2a1"]),
    ]
    analysis_reports = [
        *acceptance_reports,
        homfly_small_diagram_coverage_report(),
        multivariable_alexander_signed_pd_coverage_report(),
    ]
    generated = imgui_host_payload_from_acceptance_reports(
        acceptance_reports,
        geometry_report=build_geometry_report(),
        backend_diagnostics=sample_backend_report(),
        analysis_reports=analysis_reports,
    )
    sample = json.loads(
        Path("examples/imgui-host-payload.sample.json").read_text(
            encoding="utf-8"
        )
    )
    sample = _sample_with_current_blocker_count_fields(sample, generated)

    assert sample == generated
    assert sample["method"] == "imgui_host_payload"
    assert sample["geometry"]["component_count"] == 2
    assert sample["analysis"]["analysis_summary_count"] == 4
    assert sample["analysis"]["analysis_required_check_count"] == 67
    assert sample["analysis"]["analysis_passed_check_count"] == 67
    assert sample["analysis"]["analysis_bounded_scanned_gcd_scanned_minor_count"] == 285
    assert sample["analysis"]["analysis_bounded_scanned_gcd_complete_scan_count"] == 31
    assert sample["analysis"]["analysis_bounded_scanned_gcd_quotient_gcd_certified_count"] == 31
    assert sample["analysis"]["analysis_generated_unique_evaluation_count"] == 40
    assert sample["analysis"]["analysis_generated_reused_evaluation_count"] == 20
    assert (
        sample["analysis"]["analysis_bounded_homfly_maturity_path_distinct_count"]
        == 1
    )
    assert (
        sample["analysis"]["analysis_bounded_alexander_maturity_path_distinct_count"]
        == 2
    )
    assert (
        sample["analysis"][
            "analysis_source_table_audit_registration_summary_consistency_available_count"
        ]
        == 2
    )
    assert (
        sample["analysis"][
            "analysis_source_table_audit_registration_summary_consistency_matched_count"
        ]
        == 2
    )
    assert (
        sample["analysis"][
            "analysis_source_table_audit_registration_summary_consistency_mismatch_count"
        ]
        == 0
    )
    assert (
        sample["invariants"][
            "invariant_source_table_audit_registration_summary_consistency_available_count"
        ]
        == 2
    )
    assert (
        sample["invariants"][
            "invariant_source_table_audit_registration_summary_consistency_matched_count"
        ]
        == 2
    )
    assert (
        sample["invariants"][
            "invariant_source_table_audit_registration_summary_consistency_mismatch_count"
        ]
        == 0
    )
    assert (
        sample["invariants"][
            "invariant_bounded_scanned_gcd_expected_minor_combination_count"
        ]
        == 4
    )
    assert sample["invariants"]["invariant_bounded_scanned_gcd_nonzero_minor_count"] == 4
    assert (
        sample["invariants"][
            "invariant_bounded_scanned_gcd_all_rows_have_nonzero_minor_count"
        ]
        == 1
    )
    assert (
        sample["analysis"]["analysis_bounded_scanned_gcd_complete_certified_count"]
        == sample["analysis"][
            "analysis_bounded_scanned_gcd_nonzero_minor_coverage_complete_count"
        ]
    )
    assert sample["analysis"]["analysis_wirtinger_fox_scanned_minor_count"] == 285
    assert [
        summary["name"] for summary in sample["analysis"]["analysis_summaries"]
    ] == [
        "HOMFLY fixture acceptance",
        "multi-variable Alexander fixture acceptance",
        "HOMFLY generated small-diagram coverage",
        "multi-variable Alexander generated signed-PD coverage",
    ]
    invariant_statuses = {
        status["name"]: status
        for status in sample["invariants"]["invariant_statuses"]
    }
    assert "admissible_minor_scan=expected=4" in invariant_statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert (
        invariant_statuses["multi-variable Alexander"][
            "bounded_scanned_gcd_expected_minor_combination_count"
        ]
        == 4
    )
    assert (
        invariant_statuses["multi-variable Alexander"][
            "bounded_scanned_gcd_unique_nonzero_polynomial_count"
        ]
        == 2
    )
    assert "rows_nonzero=1" in invariant_statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert "columns_nonzero=1" in invariant_statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert sample["fixture_comparisons"]["fixture_comparison_count"] == 2
    assert sample["signed_pd"]["signed_pd_diagram_count"] == 2
    assert sample["kernel_backends"]["auto_backend"] == "numpy"
    json.dumps(sample, allow_nan=False)


def test_imgui_host_sample_payload_is_scheduler_contract_fixture() -> None:
    sample = json.loads(
        Path("examples/imgui-host-payload.sample.json").read_text(
            encoding="utf-8"
        )
    )

    assert sample["method"] == "imgui_host_payload"
    for section in (
        "geometry",
        "analysis",
        "invariants",
        "fixture_comparisons",
        "signed_pd",
        "kernel_backends",
    ):
        assert section in sample
    for renderer_field in ("renderer", "framebuffer", "screenshot"):
        assert renderer_field not in sample

    analysis = sample["analysis"]
    summaries = analysis["analysis_summaries"]
    source_methods = {summary["source_method"] for summary in summaries}
    fixture_methods = {
        "homfly_fixture_acceptance_report",
        "multivariable_alexander_fixture_acceptance_report",
    }
    generated_coverage_methods = {
        "homfly_small_diagram_coverage_report",
        "multivariable_alexander_signed_pd_coverage_report",
    }

    assert analysis["analysis_summary_count"] == len(summaries)
    assert fixture_methods < source_methods
    assert generated_coverage_methods < source_methods
    assert analysis["analysis_generated_case_count"] > 0
    assert analysis["analysis_generated_case_count"] > sample["signed_pd"][
        "signed_pd_diagram_count"
    ]

    assert sample["invariants"]["invariant_status_count"] == len(
        sample["invariants"]["invariant_statuses"]
    )
    assert {
        status["name"] for status in sample["invariants"]["invariant_statuses"]
    } == {"HOMFLY-PT", "multi-variable Alexander"}
    assert sample["fixture_comparisons"]["fixture_comparison_count"] == len(
        sample["fixture_comparisons"]["fixture_comparisons"]
    )
    assert {
        row["invariant_name"]
        for row in sample["fixture_comparisons"]["fixture_comparisons"]
    } == {"HOMFLY-PT", "multi-variable Alexander"}
    assert sample["signed_pd"]["signed_pd_diagram_count"] == len(
        sample["signed_pd"]["signed_pd_diagrams"]
    )
    assert sample["signed_pd"]["signed_pd_diagram_count"] == 2

    backend_rows = sample["kernel_backends"]["kernel_backend_statuses"]
    backends = {row["name"]: row for row in backend_rows}
    assert sample["kernel_backends"]["auto_backend"] == "numpy"
    assert backends["numpy"]["available"] is True
    assert backends["rust"]["available"] is False
    assert backends["gpu"]["available"] is False


def test_imgui_host_payload_preserves_geometry_classification_summary() -> None:
    first = circle_points(count=96)
    second = circle_points(count=96).copy()
    second[:, 0] += 1.5
    second[:, 1] += 1.5
    link = Link3D([Polyline3D(first, closed=True), Polyline3D(second, closed=True)])
    geometry_report = analyze_link(link, direction=[0.0, 0.0, 1.0], backend="numpy")
    acceptance_reports = [homfly_fixture_acceptance_report(notations=["L2a1"])]

    bundle = imgui_host_payload_from_acceptance_reports(
        acceptance_reports,
        geometry_report=geometry_report,
    )

    assert bundle["method"] == "imgui_host_payload"
    summary = bundle["geometry"]["classification_summary"]
    assert summary["method"] == "imgui_classification_summary_from_report"
    assert summary["link_type"] == "pairwise_unlink_candidate"
    assert summary["stronger_invariants_required"] is True
    assert summary["source_table_distinguishing_evidence_available"] is True
    assert "whitehead_link" in summary["nontrivial_link_types"]
    assert "L5a1" in summary["source_table_nontrivial_candidate_notations"]
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max"
        ]
        == 25
    )
    link_classification = bundle["link_classification"]
    assert (
        link_classification["method"]
        == "imgui_link_classification_summary_payload_from_report"
    )
    assert link_classification["has_link_classification_summary"] is True
    native_summary = link_classification["link_classification_summary"]
    assert native_summary["link_type"] == "pairwise_unlink_candidate"
    assert "whitehead_link" in native_summary["nontrivial_link_types"]
    assert "L5a1" in native_summary["source_table_nontrivial_candidate_notations"]
    assert native_summary["source_table_distinguishing_evidence_available"] is True
    assert native_summary["stronger_invariants_required"] is True
    json.dumps(bundle, allow_nan=False)


def test_imgui_host_payload_can_append_direct_invariant_reports() -> None:
    acceptance_report = homfly_fixture_acceptance_report(notations=["0_1"])
    direct_report = {
        "method": "homfly_pd_report",
        "input": {
            "signed_pd_revision": 11,
            "auto_role_order": {
                "requested": True,
                "applied": False,
                "status": "no_strict_candidate",
                "candidate_count": 4,
                "strict_candidate_count": 0,
                "unique_strict_global_role_order": None,
                "candidate_role_orders": [],
                "notes": [
                    "no strict global role_order candidate matched the diagram",
                ],
            }
        },
        "homfly_polynomial": None,
        "skipped": True,
        "result": None,
        "notes": ["auto role order skipped"],
    }

    default_bundle = imgui_host_payload_from_acceptance_reports([acceptance_report])
    bundle = imgui_host_payload_from_acceptance_reports(
        [acceptance_report],
        invariant_reports=[acceptance_report, direct_report],
    )

    assert default_bundle["invariants"]["method"] == (
        "imgui_invariant_status_payload_from_acceptance_reports"
    )
    assert bundle["invariants"]["method"] == "imgui_invariant_status_payload_from_reports"
    assert bundle["invariants"]["invariant_status_count"] == 2
    assert bundle["invariants"]["signed_pd_revision"] == 11
    assert bundle["fixture_comparisons"]["fixture_comparison_count"] == 1
    assert bundle["signed_pd"]["signed_pd_diagram_count"] == (
        default_bundle["signed_pd"]["signed_pd_diagram_count"]
    )
    assert bundle["invariants"]["invariant_signed_pd_auto_role_order_present_count"] == 1
    assert (
        bundle["invariants"][
            "invariant_signed_pd_auto_role_order_no_strict_candidate_count"
        ]
        == 1
    )
    direct_rows = [
        status
        for status in bundle["invariants"]["invariant_statuses"]
        if status.get("signed_pd_auto_role_order_present") is True
    ]
    assert len(direct_rows) == 1
    assert direct_rows[0]["value"] == "skipped"
    assert direct_rows[0]["signed_pd_auto_role_order_status"] == "no_strict_candidate"
    assert "signed_pd_auto_role_order=status=no_strict_candidate" in direct_rows[0][
        "notes"
    ]
    json.dumps(bundle, allow_nan=False)


def test_imgui_host_payload_exposes_blocker_counts_at_root() -> None:
    homfly_evidence = {
        "method": "homfly_input_certification_evidence",
        "claim_scope": "recursive_frontier_exhaustion_for_one_signed_pd_input",
        "homfly_polynomial": "P",
        "certified_for_input": True,
        "frontier_exhausted": True,
        "terminal_contribution_audit_skipped": True,
        "frontier_count": 0,
        "frontier_reason_count": 0,
        "truncated": False,
        "certification_blockers": [],
        "homfly_completion_blockers": [
            "full_table_normalization_not_certified",
            "arbitrary_diagram_coverage_not_certified",
        ],
        "skipped": False,
        "notes": [],
    }
    alexander_evidence = {
        "method": "multivariable_alexander_input_certification_evidence",
        "claim_scope": "exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        "multivariable_alexander_polynomial": "1",
        "bounded_scanned_gcd_certified": True,
        "complete_scanned_gcd_certified": True,
        "quotient_gcd_certified": True,
        "failed_nonzero_minor_count": 0,
        "wirtinger_fox_input_chain_consistent": True,
        "certification_blockers": ["bounded_certification_scope_only"],
        "admissible_minor_normalization_blockers": [
            "bounded_admissible_minor_normalization_scope_only",
        ],
        "full_alexander_completion_blockers": [
            "full_varied_polynomial_gcd_not_certified",
            "full_invariant_not_certified",
        ],
        "skipped": False,
        "notes": [],
    }

    bundle = imgui_host_payload_from_acceptance_reports(
        [homfly_evidence, alexander_evidence],
        analysis_reports=[homfly_evidence, alexander_evidence],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )

    assert bundle["analysis"]["analysis_certification_blocker_count"] == 1
    assert bundle["analysis"]["analysis_homfly_completion_blocker_count"] == 2
    assert (
        bundle["analysis"]["analysis_admissible_minor_normalization_blocker_count"]
        == 1
    )
    assert bundle["analysis"]["analysis_full_alexander_completion_blocker_count"] == 2
    assert bundle["invariants"]["invariant_certification_blocker_count"] == 1
    assert bundle["invariants"]["invariant_homfly_completion_blocker_count"] == 2
    assert (
        bundle["invariants"]["invariant_admissible_minor_normalization_blocker_count"]
        == 1
    )
    assert bundle["invariants"]["invariant_full_alexander_completion_blocker_count"] == 2
    assert bundle["analysis_certification_blocker_count"] == 1
    assert bundle["analysis_homfly_completion_blocker_count"] == 2
    assert bundle["analysis_admissible_minor_normalization_blocker_count"] == 1
    assert bundle["analysis_full_alexander_completion_blocker_count"] == 2
    assert bundle["invariant_certification_blocker_count"] == 1
    assert bundle["invariant_homfly_completion_blocker_count"] == 2
    assert bundle["invariant_admissible_minor_normalization_blocker_count"] == 1
    assert bundle["invariant_full_alexander_completion_blocker_count"] == 2
    summaries = {
        summary["source_method"]: summary
        for summary in bundle["analysis"]["analysis_summaries"]
    }
    assert (
        "homfly_completion_blocker_count=2"
        in summaries["homfly_input_certification_evidence"]["notes"]
    )
    assert (
        "certification_blocker_count=1"
        in summaries[
            "multivariable_alexander_input_certification_evidence"
        ]["notes"]
    )
    json.dumps(bundle, allow_nan=False)


def test_imgui_host_payload_exposes_blocker_detail_and_witness_evidence() -> None:
    homfly_evidence = {
        "method": "homfly_input_certification_evidence",
        "claim_scope": "recursive_frontier_exhaustion_for_one_signed_pd_input",
        "homfly_polynomial": "P",
        "certified_for_input": False,
        "frontier_exhausted": False,
        "terminal_contribution_audit_skipped": True,
        "frontier_count": 1,
        "frontier_reason_count": 1,
        "truncated": False,
        "certification_blockers": ["frontier_not_exhausted"],
        "certification_blocker_count": 1,
        "certification_blocker_details": [
            {
                "code": "frontier_not_exhausted",
                "severity": "blocking",
                "scope": "input_certification",
            }
        ],
        "certification_blocker_detail_count": 1,
        "homfly_completion_blockers": ["full_table_normalization_not_certified"],
        "homfly_completion_blocker_count": 1,
        "homfly_completion_blocker_details": [
            {
                "code": "full_table_normalization_not_certified",
                "severity": "blocking",
                "scope": "homfly_completion",
            }
        ],
        "homfly_completion_blocker_detail_count": 1,
        "skipped": False,
        "notes": [],
    }
    alexander_evidence = {
        "method": "multivariable_alexander_input_certification_evidence",
        "claim_scope": "exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        "multivariable_alexander_polynomial": "1 + t1",
        "bounded_scanned_gcd_certified": False,
        "complete_scanned_gcd_certified": False,
        "quotient_gcd_certified": False,
        "failed_nonzero_minor_count": 1,
        "failed_division_witness_count": 1,
        "failed_division_witness_limit": 8,
        "failed_division_witnesses": [
            {
                "minor_index": 3,
                "rows": [0],
                "columns": [1],
                "minor_polynomial": "1 - t1",
                "divisible": False,
                "quotient_polynomial": None,
                "reason": "source_does_not_divide_all_inputs",
            }
        ],
        "quotient_gcd_uncertainty_evidence": {
            "method": "fox_square_minor_quotient_gcd_uncertainty_evidence",
            "status": "not_certified",
            "certified": False,
            "quotient_polynomial_witness_count": 2,
            "quotient_polynomial_witness_limit": 8,
            "quotient_polynomial_witness_truncated": False,
            "quotient_polynomial_witnesses": [
                {
                    "quotient_index": 0,
                    "quotient_polynomial": "1 - t1",
                    "quotient_term_count": 2,
                    "variable_support": ["t1"],
                },
                {
                    "quotient_index": 1,
                    "quotient_polynomial": "1 + t1",
                    "quotient_term_count": 2,
                    "variable_support": ["t1"],
                },
            ],
            "first_quotient_polynomial_witness": {
                "quotient_index": 0,
                "quotient_polynomial": "1 - t1",
                "quotient_term_count": 2,
                "variable_support": ["t1"],
            },
        },
        "admissible_minor_normalization_blocker_details": {
            "normalization_class_not_unique": {
                "normalization_class_witness_count": 2,
                "normalization_class_witnesses": [
                    {
                        "normalized_polynomial": "1 - t1",
                        "minor_count": 1,
                    },
                    {
                        "normalized_polynomial": "1 + t1",
                        "minor_count": 1,
                    },
                ],
            },
        },
        "bounded_admissible_minor_normalization_blocker_witness_summary": {
            "method": (
                "bounded_admissible_minor_normalization_blocker_witness_summary"
            ),
            "reason_count": 3,
            "witness_available_count": 1,
            "missing_witness_reasons": [
                {
                    "reason": "quotient_gcd_uncertainty_witness_missing",
                    "witness_available": False,
                },
                "normalization_representative_witness_missing",
            ],
            "missing_witness_reason_count": 2,
            "blocker_witness_sources": [
                {
                    "reason": "normalization_class_not_unique",
                    "source_kind": "normalization_class_witness",
                    "status": "available",
                    "witness_available": True,
                },
                {
                    "reason": "failed_division_witness_present",
                    "source_kind": "failed_division_witness",
                    "status": "available",
                    "witness_available": True,
                },
                {
                    "reason": "quotient_gcd_uncertainty_witness_missing",
                    "source_kind": "quotient_gcd_uncertainty_witness",
                    "status": "missing",
                    "witness_available": False,
                },
                {
                    "reason": "normalization_representative_witness_missing",
                    "source_kind": "normalization_representative_witness",
                    "status": "missing",
                    "witness_available": False,
                },
            ],
            "blocker_witness_source_count": 4,
            "blocker_witness_source_available_count": 2,
            "blocker_witness_source_missing_count": 2,
            "blocker_witness_source_counts_by_reason": [
                {
                    "reason": "normalization_class_not_unique",
                    "witness_source_count": 1,
                },
                {
                    "reason": "failed_division_witness_present",
                    "witness_source_count": 1,
                },
                {
                    "reason": "quotient_gcd_uncertainty_witness_missing",
                    "witness_source_count": 1,
                },
                {
                    "reason": "normalization_representative_witness_missing",
                    "witness_source_count": 1,
                },
            ],
            "blocker_witness_source_available_counts_by_reason": [
                {
                    "reason": "normalization_class_not_unique",
                    "witness_source_count": 1,
                },
                {
                    "reason": "failed_division_witness_present",
                    "witness_source_count": 1,
                },
            ],
            "blocker_witness_source_missing_counts_by_reason": [
                {
                    "reason": "quotient_gcd_uncertainty_witness_missing",
                    "witness_source_count": 1,
                },
                {
                    "reason": "normalization_representative_witness_missing",
                    "witness_source_count": 1,
                },
            ],
            "first_witness_source": {
                "source_kind": "normalization_class_witness",
                "status": "available",
            },
            "summary_consistency": {
                "matched": True,
                "reason_count_matched": True,
                "witness_available_count_matched": True,
                "missing_witness_reason_count_matched": True,
                "blocker_witness_source_count_matched": True,
                "blocker_witness_source_available_count_matched": True,
                "blocker_witness_source_missing_count_matched": True,
            },
        },
        "wirtinger_fox_input_chain_consistent": True,
        "full_invariant_certified": False,
        "skipped": False,
        "notes": [],
    }

    bundle = imgui_host_payload_from_acceptance_reports(
        [homfly_evidence, alexander_evidence],
        analysis_reports=[homfly_evidence, alexander_evidence],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )

    assert bundle["analysis"]["analysis_certification_blocker_detail_count"] == 1
    assert bundle["analysis"]["analysis_homfly_completion_blocker_detail_count"] == 1
    assert bundle["analysis"]["analysis_failed_division_witness_count"] == 1
    assert bundle["analysis"]["analysis_quotient_gcd_uncertainty_present"] == 1
    assert bundle["analysis"]["analysis_quotient_polynomial_witness_count"] == 2
    assert bundle["analysis"]["analysis_quotient_polynomial_witness_truncated"] == 0
    assert bundle["analysis"]["analysis_normalization_class_witness_count"] == 2
    assert (
        bundle["analysis"][
            "analysis_admissible_minor_normalization_blocker_reason_count"
        ]
        == 3
    )
    assert (
        bundle["analysis"][
            "analysis_admissible_minor_normalization_blocker_witness_available_count"
        ]
        == 1
    )
    assert (
        bundle["analysis"][
            "analysis_admissible_minor_normalization_blocker_missing_witness_reason_count"
        ]
        == 2
    )
    assert (
        bundle["analysis"][
            "analysis_admissible_minor_normalization_blocker_witness_source_count"
        ]
        == 4
    )
    assert (
        bundle["analysis"][
            "analysis_admissible_minor_normalization_blocker_witness_source_available_count"
        ]
        == 2
    )
    assert (
        bundle["analysis"][
            "analysis_admissible_minor_normalization_blocker_witness_source_missing_count"
        ]
        == 2
    )
    assert bundle["invariants"]["invariant_certification_blocker_detail_count"] == 1
    assert (
        bundle["invariants"]["invariant_homfly_completion_blocker_detail_count"]
        == 1
    )
    assert bundle["invariants"]["invariant_failed_division_witness_count"] == 1
    assert bundle["invariants"]["invariant_quotient_gcd_uncertainty_present"] == 1
    assert bundle["invariants"]["invariant_quotient_polynomial_witness_count"] == 2
    assert bundle["invariants"]["invariant_quotient_polynomial_witness_truncated"] == 0
    assert bundle["invariants"]["invariant_normalization_class_witness_count"] == 2
    assert (
        bundle["invariants"][
            "invariant_admissible_minor_normalization_blocker_reason_count"
        ]
        == 3
    )
    assert (
        bundle["invariants"][
            "invariant_admissible_minor_normalization_blocker_witness_available_count"
        ]
        == 1
    )
    assert (
        bundle["invariants"][
            "invariant_admissible_minor_normalization_blocker_missing_witness_reason_count"
        ]
        == 2
    )
    assert (
        bundle["invariants"][
            "invariant_admissible_minor_normalization_blocker_witness_source_count"
        ]
        == 4
    )
    assert (
        bundle["invariants"][
            "invariant_admissible_minor_normalization_blocker_witness_source_available_count"
        ]
        == 2
    )
    assert (
        bundle["invariants"][
            "invariant_admissible_minor_normalization_blocker_witness_source_missing_count"
        ]
        == 2
    )
    assert bundle["analysis_certification_blocker_detail_count"] == 1
    assert bundle["analysis_homfly_completion_blocker_detail_count"] == 1
    assert bundle["analysis_failed_division_witness_count"] == 1
    assert bundle["analysis_quotient_gcd_uncertainty_present"] == 1
    assert bundle["analysis_quotient_polynomial_witness_count"] == 2
    assert bundle["analysis_quotient_polynomial_witness_truncated"] == 0
    assert bundle["analysis_normalization_class_witness_count"] == 2
    assert bundle[
        "analysis_admissible_minor_normalization_blocker_reason_count"
    ] == 3
    assert bundle[
        "analysis_admissible_minor_normalization_blocker_witness_available_count"
    ] == 1
    assert bundle[
        "analysis_admissible_minor_normalization_blocker_missing_witness_reason_count"
    ] == 2
    assert bundle[
        "analysis_admissible_minor_normalization_blocker_witness_source_count"
    ] == 4
    assert bundle[
        "analysis_admissible_minor_normalization_blocker_witness_source_available_count"
    ] == 2
    assert bundle[
        "analysis_admissible_minor_normalization_blocker_witness_source_missing_count"
    ] == 2
    assert bundle["invariant_certification_blocker_detail_count"] == 1
    assert bundle["invariant_homfly_completion_blocker_detail_count"] == 1
    assert bundle["invariant_failed_division_witness_count"] == 1
    assert bundle["invariant_quotient_gcd_uncertainty_present"] == 1
    assert bundle["invariant_quotient_polynomial_witness_count"] == 2
    assert bundle["invariant_quotient_polynomial_witness_truncated"] == 0
    assert bundle["invariant_normalization_class_witness_count"] == 2
    assert bundle[
        "invariant_admissible_minor_normalization_blocker_reason_count"
    ] == 3
    assert bundle[
        "invariant_admissible_minor_normalization_blocker_witness_available_count"
    ] == 1
    assert bundle[
        "invariant_admissible_minor_normalization_blocker_missing_witness_reason_count"
    ] == 2
    assert bundle[
        "invariant_admissible_minor_normalization_blocker_witness_source_count"
    ] == 4
    assert bundle[
        "invariant_admissible_minor_normalization_blocker_witness_source_available_count"
    ] == 2
    assert bundle[
        "invariant_admissible_minor_normalization_blocker_witness_source_missing_count"
    ] == 2

    summaries = {
        summary["source_method"]: summary
        for summary in bundle["analysis"]["analysis_summaries"]
    }
    homfly_notes = summaries["homfly_input_certification_evidence"]["notes"]
    assert "certification_blocker_detail_count=1" in homfly_notes
    assert "first_certification_blocker_detail_code=frontier_not_exhausted" in homfly_notes
    assert "first_certification_blocker_detail_severity=blocking" in homfly_notes
    assert "first_certification_blocker_detail_scope=input_certification" in homfly_notes
    assert "homfly_completion_blocker_detail_count=1" in homfly_notes
    assert (
        "first_homfly_completion_blocker_detail_code="
        "full_table_normalization_not_certified"
        in homfly_notes
    )
    assert "first_homfly_completion_blocker_detail_severity=blocking" in homfly_notes
    assert "first_homfly_completion_blocker_detail_scope=homfly_completion" in homfly_notes

    alexander_summary = summaries[
        "multivariable_alexander_input_certification_evidence"
    ]
    alexander_notes = alexander_summary["notes"]
    assert "alexander_witness_evidence=failed_division_witness_count=1" in alexander_notes
    assert "quotient_gcd_uncertainty_present=1" in alexander_notes
    assert "quotient_polynomial_witness_count=2" in alexander_notes
    assert "quotient_polynomial_witness_truncated=False" in alexander_notes
    assert "first_quotient_polynomial_witness=1 - t1" in alexander_notes
    assert "first_quotient_polynomial_witness_index=0" in alexander_notes
    assert "first_quotient_polynomial_witness_terms=2" in alexander_notes
    assert "normalization_class_witness_count=2" in alexander_notes
    assert "first_failed_division_minor=3" in alexander_notes
    assert "first_normalization_class_witness=1 - t1" in alexander_notes
    assert (
        "admissible_minor_normalization_blocker_witness_summary=reason_count=3"
        in alexander_notes
    )
    assert "witness_available_count=1" in alexander_notes
    assert "missing_witness_reason_count=2" in alexander_notes
    assert "witness_source_count=4" in alexander_notes
    assert "witness_source_available_count=2" in alexander_notes
    assert "witness_source_missing_count=2" in alexander_notes
    assert "blocker_witness_sources" not in alexander_notes
    assert (
        "first_admissible_minor_normalization_blocker_witness_source_kind="
        "normalization_class_witness"
        in alexander_notes
    )
    assert (
        "first_admissible_minor_normalization_blocker_witness_source_status=available"
        in alexander_notes
    )
    assert "missing_witness_reason=quotient_gcd_uncertainty_witness_missing" in (
        alexander_notes
    )
    assert "summary_consistency_matched=True" in alexander_notes
    assert "summary_consistency_blocker_witness_source_count_matched=True" in (
        alexander_notes
    )
    assert "full_invariant_certified=False" in alexander_notes

    invariant_payload = imgui_invariant_status_payload_from_reports(
        [alexander_evidence]
    )
    assert (
        invariant_payload[
            "invariant_admissible_minor_normalization_blocker_reason_count"
        ]
        == 3
    )
    assert (
        invariant_payload[
            "invariant_admissible_minor_normalization_blocker_witness_available_count"
        ]
        == 1
    )
    assert (
        invariant_payload[
            "invariant_admissible_minor_normalization_blocker_missing_witness_reason_count"
        ]
        == 2
    )
    assert (
        invariant_payload[
            "invariant_admissible_minor_normalization_blocker_witness_source_count"
        ]
        == 4
    )
    assert (
        invariant_payload[
            "invariant_admissible_minor_normalization_blocker_witness_source_available_count"
        ]
        == 2
    )
    assert (
        invariant_payload[
            "invariant_admissible_minor_normalization_blocker_witness_source_missing_count"
        ]
        == 2
    )
    assert "blocker_witness_sources" not in alexander_summary
    invariant_status = invariant_payload["invariant_statuses"][0]
    assert "blocker_witness_sources" not in invariant_status
    json.dumps(bundle, allow_nan=False)
    json.dumps(invariant_payload, allow_nan=False)


def test_imgui_payloads_preserve_quotient_polynomial_witness_truncation_mismatch() -> None:
    report = {
        "method": "multivariable_alexander_input_certification_evidence",
        "claim_scope": "exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        "multivariable_alexander_polynomial": "1 + t1",
        "bounded_scanned_gcd_certified": False,
        "complete_scanned_gcd_certified": False,
        "quotient_gcd_certified": False,
        "failed_nonzero_minor_count": 1,
        "quotient_gcd_uncertainty_evidence": {
            "method": "fox_square_minor_quotient_gcd_uncertainty_evidence",
            "status": "not_certified",
            "certified": False,
            "quotient_polynomial_witness_count": 3,
            "quotient_polynomial_witness_limit": 2,
            "quotient_polynomial_witnesses": [
                {
                    "quotient_index": 0,
                    "quotient_polynomial": "1 - t1",
                    "quotient_term_count": 2,
                },
                {
                    "quotient_index": 1,
                    "quotient_polynomial": "1 + t1",
                    "quotient_term_count": 2,
                },
            ],
            "first_quotient_polynomial_witness": {
                "quotient_index": 0,
                "quotient_polynomial": "1 - t1",
                "quotient_term_count": 2,
            },
            "quotient_polynomial_witness_consistency": {
                "matched": False,
                "witness_count_matches_list": False,
                "witness_truncated": True,
            },
        },
        "wirtinger_fox_input_chain_consistent": True,
        "full_invariant_certified": False,
        "skipped": False,
        "notes": [],
    }
    note_tokens = [
        "quotient_gcd_uncertainty_present=1",
        "quotient_polynomial_witness_count=3",
        "quotient_polynomial_witness_truncated=True",
        "first_quotient_polynomial_witness=1 - t1",
        "first_quotient_polynomial_witness_index=0",
        "first_quotient_polynomial_witness_terms=2",
    ]

    summary = analysis_summary_from_acceptance_report(report)
    analysis_payload = imgui_analysis_payload_from_acceptance_reports([report])
    invariant_payload = imgui_invariant_status_payload_from_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [report],
        analysis_reports=[report],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )
    status = invariant_payload["invariant_statuses"][0]
    host_status = host_payload["invariants"]["invariant_statuses"][0]

    assert summary["quotient_gcd_uncertainty_present"] == 1
    assert summary["quotient_polynomial_witness_count"] == 3
    assert summary["quotient_polynomial_witness_truncated"] == 1
    assert analysis_payload["analysis_quotient_polynomial_witness_count"] == 3
    assert analysis_payload["analysis_quotient_polynomial_witness_truncated"] == 1
    assert invariant_payload["invariant_quotient_polynomial_witness_count"] == 3
    assert invariant_payload["invariant_quotient_polynomial_witness_truncated"] == 1
    assert host_payload["analysis_quotient_polynomial_witness_truncated"] == 1
    assert host_payload["invariant_quotient_polynomial_witness_truncated"] == 1
    assert status["quotient_polynomial_witness_truncated"] == 1
    assert host_status["quotient_polynomial_witness_truncated"] == 1
    for token in note_tokens:
        assert token in summary["notes"]
        assert token in status["notes"]
        assert token in host_payload["analysis"]["analysis_summaries"][0]["notes"]
        assert token in host_status["notes"]
    json.dumps(host_payload, allow_nan=False)
    json.dumps(analysis_payload, allow_nan=False)
    json.dumps(invariant_payload, allow_nan=False)

def test_imgui_payloads_flatten_alexander_gate_summary_compact_fields() -> None:
    report = {
        "method": "multivariable_alexander_input_certification_evidence",
        "claim_scope": "exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        "multivariable_alexander_polynomial": "1 + t1",
        "bounded_scanned_gcd_certified": False,
        "complete_scanned_gcd_certified": False,
        "quotient_gcd_certified": False,
        "failed_nonzero_minor_count": 1,
        "bounded_admissible_minor_normalization_gate_summary": {
            "method": "bounded_admissible_minor_normalization_gate_summary",
            "gate_checks": [
                {"gate": "exact_scanned_gcd", "passed": False},
                {"gate": "complete_scan", "passed": True},
                {"gate": "row_coverage", "passed": True},
                {"gate": "column_coverage", "passed": False},
            ],
            "gate_count": 4,
            "passed_gate_names": ["complete_scan", "row_coverage"],
            "passed_gate_count": 2,
            "failed_gate_names": ["exact_scanned_gcd", "column_coverage"],
            "failed_gate_count": 2,
            "failed_gate_blockers": [
                "candidate_not_exact_scanned_gcd",
                "nonzero_minor_coverage_incomplete",
            ],
            "failed_gate_blocker_count": 2,
            "failed_gate_blocker_provenance_consistency": {
                "method": (
                    "bounded_admissible_minor_normalization_failed_gate_blocker_provenance_consistency"
                ),
                "normalization_gate_provenance_consistent": True,
                "failed_gate_names": ["exact_scanned_gcd", "column_coverage"],
                "failed_gate_count": 2,
                "failed_gate_blocker_provenance_row_count": 2,
                "failed_gate_blocker_attribution_count": 2,
                "failed_gate_blocker_provenance_row_reason_counts": {
                    "exact_scanned_gcd_not_certified": 1,
                    "nonzero_minor_coverage_incomplete": 1,
                },
                "failed_gate_blocker_provenance_source_available_count": 2,
                "failed_gate_blocker_provenance_source_missing_count": 0,
                "failed_gate_blocker_provenance_missing_source_blockers": [],
                "failed_gate_blocker_provenance_inconsistent_source_blockers": [],
            },
            "summary_consistency": {
                "gate_blocker_summary_consistent": True,
            },
        },
        "admissible_minor_normalization_evidence": {
            "bounded_admissible_minor_normalization_gate_summary": {
                "method": "bounded_admissible_minor_normalization_gate_summary",
                "gate_count": 99,
                "passed_gate_count": 99,
                "failed_gate_count": 0,
                "failed_gate_blocker_count": 0,
                "summary_consistency": {
                    "gate_blocker_summary_consistent": False,
                },
            },
        },
        "admissible_minor_normalization_blockers": [
            "candidate_not_exact_scanned_gcd",
            "nonzero_minor_coverage_incomplete",
        ],
        "admissible_minor_normalization_blocker_count": 2,
        "wirtinger_fox_input_chain_consistent": True,
        "full_invariant_certified": False,
        "skipped": False,
        "notes": [],
    }
    expected = {
        "admissible_minor_normalization_gate_count": 4,
        "admissible_minor_normalization_gate_passed_count": 2,
        "admissible_minor_normalization_gate_failed_count": 2,
        "admissible_minor_normalization_gate_summary_consistent": 1,
        "admissible_minor_normalization_failed_gate_blocker_count": 2,
        "admissible_minor_normalization_failed_gate_blocker_provenance_consistent": 1,
        "admissible_minor_normalization_failed_gate_blocker_provenance_row_count": 2,
        "admissible_minor_normalization_failed_gate_blocker_provenance_gate_count": 2,
        "admissible_minor_normalization_failed_gate_blocker_provenance_attribution_count": 2,
        "admissible_minor_normalization_failed_gate_blocker_provenance_reason_count": 2,
        "admissible_minor_normalization_failed_gate_blocker_provenance_source_available_count": 2,
        "admissible_minor_normalization_failed_gate_blocker_provenance_source_missing_count": 0,
        "admissible_minor_normalization_failed_gate_blocker_provenance_missing_source_count": 0,
        "admissible_minor_normalization_failed_gate_blocker_provenance_inconsistent_source_count": 0,
    }

    summary = analysis_summary_from_acceptance_report(report)
    for key, value in expected.items():
        assert summary[key] == value
    assert "admissible_minor_normalization_gate_summary=gates=4" in summary["notes"]
    assert "passed=2" in summary["notes"]
    assert "failed=2" in summary["notes"]
    assert "consistent=True" in summary["notes"]
    assert "admissible_minor_normalization_gate_provenance=consistent=True" in (
        summary["notes"]
    )
    assert "rows=2" in summary["notes"]
    assert "source_available=2" in summary["notes"]

    analysis_payload = imgui_analysis_payload_from_acceptance_reports([report])
    invariant_payload = imgui_invariant_status_payload_from_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [report],
        analysis_reports=[report],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )
    status = invariant_payload["invariant_statuses"][0]
    host_status = host_payload["invariants"]["invariant_statuses"][0]
    for key, value in expected.items():
        assert analysis_payload[f"analysis_{key}"] == value
        assert invariant_payload[f"invariant_{key}"] == value
        assert host_payload["analysis"][f"analysis_{key}"] == value
        assert host_payload["invariants"][f"invariant_{key}"] == value
        assert host_payload[f"analysis_{key}"] == value
        assert host_payload[f"invariant_{key}"] == value
        assert status[key] == value
        assert host_status[key] == value

    legacy_report = json.loads(json.dumps(report))
    legacy_report.pop("bounded_admissible_minor_normalization_gate_summary")
    legacy_report["admissible_minor_normalization_evidence"] = {}
    legacy_report["admissible_minor_normalization_blockers"] = [
        "candidate_not_exact_scanned_gcd",
        "nonzero_minor_coverage_incomplete",
    ]
    legacy_report["admissible_minor_normalization_blocker_count"] = 2
    legacy_summary = analysis_summary_from_acceptance_report(legacy_report)
    legacy_invariant = imgui_invariant_status_payload_from_reports([legacy_report])
    legacy_host = imgui_host_payload_from_acceptance_reports(
        [legacy_report],
        analysis_reports=[legacy_report],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )
    for key in expected:
        assert legacy_summary[key] == 0
        assert legacy_invariant[f"invariant_{key}"] == 0
        assert legacy_host[f"analysis_{key}"] == 0
        assert legacy_host[f"invariant_{key}"] == 0
    assert "admissible_minor_normalization_gate_summary=" not in (
        legacy_summary["notes"]
    )
    json.dumps(analysis_payload, allow_nan=False)
    json.dumps(invariant_payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)
    json.dumps(legacy_invariant, allow_nan=False)
    json.dumps(legacy_host, allow_nan=False)

def test_imgui_payloads_preserve_alexander_gate_provenance_mismatch() -> None:
    report = {
        "method": "multivariable_alexander_input_certification_evidence",
        "claim_scope": "exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        "multivariable_alexander_polynomial": "1 + t1",
        "bounded_scanned_gcd_certified": False,
        "complete_scanned_gcd_certified": False,
        "quotient_gcd_certified": False,
        "failed_nonzero_minor_count": 1,
        "bounded_admissible_minor_normalization_gate_summary": {
            "method": "bounded_admissible_minor_normalization_gate_summary",
            "gate_checks": [
                {"gate": "exact_scanned_gcd", "passed": False},
                {"gate": "complete_scan", "passed": True},
            ],
            "gate_count": 2,
            "passed_gate_names": ["complete_scan"],
            "passed_gate_count": 1,
            "failed_gate_names": ["exact_scanned_gcd"],
            "failed_gate_count": 1,
            "failed_gate_blockers": ["candidate_not_exact_scanned_gcd"],
            "failed_gate_blocker_count": 1,
            "failed_gate_blocker_provenance_consistency": {
                "method": (
                    "bounded_admissible_minor_normalization_failed_gate_blocker_provenance_consistency"
                ),
                "normalization_gate_provenance_consistent": False,
                "failed_gate_names": ["exact_scanned_gcd"],
                "failed_gate_count": 1,
                "failed_gate_blocker_provenance_row_count": 1,
                "failed_gate_blocker_attribution_count": 1,
                "failed_gate_blocker_provenance_row_reason_counts": {
                    "exact_scanned_gcd_not_certified": 1,
                },
                "failed_gate_blocker_provenance_source_available_count": 0,
                "failed_gate_blocker_provenance_source_missing_count": 1,
                "failed_gate_blocker_provenance_missing_source_blockers": [
                    "candidate_not_exact_scanned_gcd",
                ],
                "failed_gate_blocker_provenance_inconsistent_source_blockers": [
                    "nonzero_minor_coverage_incomplete",
                ],
            },
            "summary_consistency": {
                "gate_blocker_summary_consistent": False,
            },
        },
        "admissible_minor_normalization_blockers": [
            "candidate_not_exact_scanned_gcd",
        ],
        "admissible_minor_normalization_blocker_count": 1,
        "wirtinger_fox_input_chain_consistent": True,
        "full_invariant_certified": False,
        "skipped": False,
        "notes": [],
    }
    expected = {
        "admissible_minor_normalization_gate_count": 2,
        "admissible_minor_normalization_gate_passed_count": 1,
        "admissible_minor_normalization_gate_failed_count": 1,
        "admissible_minor_normalization_gate_summary_consistent": 0,
        "admissible_minor_normalization_failed_gate_blocker_count": 1,
        "admissible_minor_normalization_failed_gate_blocker_provenance_consistent": 0,
        "admissible_minor_normalization_failed_gate_blocker_provenance_row_count": 1,
        "admissible_minor_normalization_failed_gate_blocker_provenance_gate_count": 1,
        "admissible_minor_normalization_failed_gate_blocker_provenance_attribution_count": 1,
        "admissible_minor_normalization_failed_gate_blocker_provenance_reason_count": 1,
        "admissible_minor_normalization_failed_gate_blocker_provenance_source_available_count": 0,
        "admissible_minor_normalization_failed_gate_blocker_provenance_source_missing_count": 1,
        "admissible_minor_normalization_failed_gate_blocker_provenance_missing_source_count": 1,
        "admissible_minor_normalization_failed_gate_blocker_provenance_inconsistent_source_count": 1,
    }
    note_token = (
        "admissible_minor_normalization_gate_provenance=consistent=False; "
        "rows=1; gates=1; attributions=1; reasons=1; "
        "source_available=0; source_missing=1; missing_sources=1; "
        "inconsistent_sources=1"
    )

    summary = analysis_summary_from_acceptance_report(report)
    analysis_payload = imgui_analysis_payload_from_acceptance_reports([report])
    invariant_payload = imgui_invariant_status_payload_from_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [report],
        analysis_reports=[report],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )
    status = invariant_payload["invariant_statuses"][0]
    host_status = host_payload["invariants"]["invariant_statuses"][0]

    for key, value in expected.items():
        assert summary[key] == value
        assert analysis_payload[f"analysis_{key}"] == value
        assert invariant_payload[f"invariant_{key}"] == value
        assert host_payload["analysis"][f"analysis_{key}"] == value
        assert host_payload["invariants"][f"invariant_{key}"] == value
        assert host_payload[f"analysis_{key}"] == value
        assert host_payload[f"invariant_{key}"] == value
        assert status[key] == value
        assert host_status[key] == value
    assert note_token in summary["notes"]
    assert note_token in status["notes"]
    assert note_token in host_payload["analysis"]["analysis_summaries"][0]["notes"]
    assert note_token in host_status["notes"]
    json.dumps(host_payload, allow_nan=False)
    json.dumps(analysis_payload, allow_nan=False)
    json.dumps(invariant_payload, allow_nan=False)

def test_imgui_payloads_aggregate_multiple_alexander_blocker_witness_rows() -> None:
    def alexander_evidence(
        *,
        polynomial: str,
        reason_count: int,
        witness_available_count: int,
        missing_witness_reason_count: int,
        witness_source_count: int,
        witness_source_available_count: int,
        witness_source_missing_count: int,
        first_source_kind: str,
        missing_reason: str,
    ) -> dict[str, object]:
        return {
            "method": "multivariable_alexander_input_certification_evidence",
            "claim_scope": "exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
            "multivariable_alexander_polynomial": polynomial,
            "bounded_scanned_gcd_certified": False,
            "complete_scanned_gcd_certified": False,
            "quotient_gcd_certified": False,
            "failed_nonzero_minor_count": 1,
            "bounded_admissible_minor_normalization_blocker_witness_summary": {
                "method": (
                    "bounded_admissible_minor_normalization_blocker_witness_summary"
                ),
                "reason_count": reason_count,
                "witness_available_count": witness_available_count,
                "missing_witness_reasons": [
                    {
                        "reason": missing_reason,
                        "witness_available": False,
                    },
                ],
                "missing_witness_reason_count": missing_witness_reason_count,
                "blocker_witness_source_count": witness_source_count,
                "blocker_witness_source_available_count": (
                    witness_source_available_count
                ),
                "blocker_witness_source_missing_count": witness_source_missing_count,
                "first_witness_source": {
                    "source_kind": first_source_kind,
                    "status": "available",
                },
                "summary_consistency": {
                    "matched": True,
                    "reason_count_matched": True,
                    "witness_available_count_matched": True,
                    "missing_witness_reason_count_matched": True,
                    "blocker_witness_source_count_matched": True,
                    "blocker_witness_source_available_count_matched": True,
                    "blocker_witness_source_missing_count_matched": True,
                },
            },
            "wirtinger_fox_input_chain_consistent": True,
            "full_invariant_certified": False,
            "skipped": False,
            "notes": [],
        }

    reports = [
        alexander_evidence(
            polynomial="1 + t1",
            reason_count=3,
            witness_available_count=1,
            missing_witness_reason_count=2,
            witness_source_count=4,
            witness_source_available_count=2,
            witness_source_missing_count=2,
            first_source_kind="normalization_class_witness",
            missing_reason="quotient_gcd_uncertainty_witness_missing",
        ),
        alexander_evidence(
            polynomial="1 + t2",
            reason_count=5,
            witness_available_count=2,
            missing_witness_reason_count=1,
            witness_source_count=6,
            witness_source_available_count=3,
            witness_source_missing_count=3,
            first_source_kind="failed_division_witness",
            missing_reason="normalization_representative_witness_missing",
        ),
    ]
    compact_expected = {
        "admissible_minor_normalization_blocker_reason_count": 8,
        "admissible_minor_normalization_blocker_witness_available_count": 3,
        "admissible_minor_normalization_blocker_missing_witness_reason_count": 3,
        "admissible_minor_normalization_blocker_witness_source_count": 10,
        "admissible_minor_normalization_blocker_witness_source_available_count": 5,
        "admissible_minor_normalization_blocker_witness_source_missing_count": 5,
    }

    analysis = imgui_analysis_payload_from_acceptance_reports(reports)
    invariants = imgui_invariant_status_payload_from_reports(reports)
    bundle = imgui_host_payload_from_acceptance_reports(
        reports,
        analysis_reports=reports,
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )

    analysis_rows = analysis["analysis_summaries"]
    invariant_rows = invariants["invariant_statuses"]
    assert [
        row["admissible_minor_normalization_blocker_reason_count"]
        for row in analysis_rows
    ] == [3, 5]
    assert [
        row["admissible_minor_normalization_blocker_witness_available_count"]
        for row in analysis_rows
    ] == [1, 2]
    assert [
        row["admissible_minor_normalization_blocker_missing_witness_reason_count"]
        for row in analysis_rows
    ] == [2, 1]
    assert [
        row["admissible_minor_normalization_blocker_witness_source_count"]
        for row in analysis_rows
    ] == [4, 6]
    assert [
        row[
            "admissible_minor_normalization_blocker_witness_source_available_count"
        ]
        for row in analysis_rows
    ] == [2, 3]
    assert [
        row[
            "admissible_minor_normalization_blocker_witness_source_missing_count"
        ]
        for row in analysis_rows
    ] == [2, 3]
    assert [
        row["admissible_minor_normalization_blocker_reason_count"]
        for row in invariant_rows
    ] == [3, 5]
    assert [
        row["admissible_minor_normalization_blocker_witness_available_count"]
        for row in invariant_rows
    ] == [1, 2]
    assert [
        row["admissible_minor_normalization_blocker_missing_witness_reason_count"]
        for row in invariant_rows
    ] == [2, 1]
    assert [
        row["admissible_minor_normalization_blocker_witness_source_count"]
        for row in invariant_rows
    ] == [4, 6]
    assert [
        row[
            "admissible_minor_normalization_blocker_witness_source_available_count"
        ]
        for row in invariant_rows
    ] == [2, 3]
    assert [
        row[
            "admissible_minor_normalization_blocker_witness_source_missing_count"
        ]
        for row in invariant_rows
    ] == [2, 3]

    for key, value in compact_expected.items():
        assert analysis[f"analysis_{key}"] == value
        assert invariants[f"invariant_{key}"] == value
        assert bundle["analysis"][f"analysis_{key}"] == value
        assert bundle["invariants"][f"invariant_{key}"] == value
        assert bundle[f"analysis_{key}"] == value
        assert bundle[f"invariant_{key}"] == value

    first_notes = analysis_rows[0]["notes"]
    assert "summary_consistency_matched=True" in first_notes
    assert "summary_consistency_reason_count_matched=True" in first_notes
    assert "witness_source_count=4" in first_notes
    assert "witness_source_available_count=2" in first_notes
    assert "witness_source_missing_count=2" in first_notes
    assert "summary_consistency_blocker_witness_source_count_matched=True" in (
        first_notes
    )
    assert "blocker_witness_sources" not in first_notes
    assert (
        "first_admissible_minor_normalization_blocker_witness_source_kind="
        "normalization_class_witness"
        in first_notes
    )
    assert (
        "missing_witness_reason=quotient_gcd_uncertainty_witness_missing"
        in first_notes
    )
    json.dumps(bundle, allow_nan=False)


def test_imgui_alexander_blocker_witness_summary_consistency_mismatch_is_host_visible() -> None:
    report = {
        "method": "multivariable_alexander_input_certification_evidence",
        "claim_scope": "exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        "multivariable_alexander_polynomial": "1 + t1",
        "bounded_scanned_gcd_certified": False,
        "complete_scanned_gcd_certified": False,
        "quotient_gcd_certified": False,
        "failed_nonzero_minor_count": 1,
        "bounded_admissible_minor_normalization_blocker_witness_summary": {
            "method": (
                "bounded_admissible_minor_normalization_blocker_witness_summary"
            ),
            "reason_count": 4,
            "witness_available_count": 0,
            "missing_witness_reasons": [
                "scan_incomplete_witness_missing",
                "row_column_coverage_witness_missing",
                "quotient_gcd_uncertainty_witness_missing",
            ],
            "missing_witness_reason_count": 3,
            "blocker_witness_sources": [
                {
                    "reason": "scan_incomplete",
                    "source_kind": "minor_locator",
                    "status": "missing",
                    "witness_available": False,
                },
                {
                    "reason": "quotient_uncertainty",
                    "source_kind": "quotient_polynomial_witness",
                    "status": "missing",
                    "witness_available": False,
                },
            ],
            "blocker_witness_source_count": 2,
            "blocker_witness_source_available_count": 0,
            "blocker_witness_source_missing_count": 2,
            "first_witness_source": {
                "source_kind": "no_reusable_locator_witness",
                "status": "missing",
            },
            "summary_consistency": {
                "status": "stale",
                "matched": False,
                "reason_count_matched": False,
                "witness_available_count_matched": False,
                "missing_witness_reason_count_matched": False,
                "blocker_witness_source_count_matched": False,
                "blocker_witness_source_available_count_matched": False,
                "blocker_witness_source_missing_count_matched": False,
            },
        },
        "wirtinger_fox_input_chain_consistent": True,
        "full_invariant_certified": False,
        "skipped": False,
        "notes": [],
    }
    expected = {
        "admissible_minor_normalization_blocker_reason_count": 4,
        "admissible_minor_normalization_blocker_witness_available_count": 0,
        "admissible_minor_normalization_blocker_missing_witness_reason_count": 3,
        "admissible_minor_normalization_blocker_witness_source_count": 2,
        "admissible_minor_normalization_blocker_witness_source_available_count": 0,
        "admissible_minor_normalization_blocker_witness_source_missing_count": 2,
    }
    note_tokens = [
        "admissible_minor_normalization_blocker_witness_summary=reason_count=4",
        "witness_available_count=0",
        "missing_witness_reason_count=3",
        "witness_source_count=2",
        "witness_source_available_count=0",
        "witness_source_missing_count=2",
        "summary_consistency_status=stale",
        "summary_consistency_matched=False",
        "summary_consistency_reason_count_matched=False",
        "summary_consistency_blocker_witness_source_count_matched=False",
    ]

    analysis_payload = imgui_analysis_payload_from_acceptance_reports([report])
    invariant_payload = imgui_invariant_status_payload_from_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [report],
        analysis_reports=[report],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )
    summary = analysis_payload["analysis_summaries"][0]
    status = invariant_payload["invariant_statuses"][0]
    host_summary = host_payload["analysis"]["analysis_summaries"][0]
    host_status = host_payload["invariants"]["invariant_statuses"][0]

    for key, value in expected.items():
        assert summary[key] == value
        assert status[key] == value
        assert analysis_payload[f"analysis_{key}"] == value
        assert invariant_payload[f"invariant_{key}"] == value
        assert host_payload["analysis"][f"analysis_{key}"] == value
        assert host_payload["invariants"][f"invariant_{key}"] == value

    for notes in (
        summary["notes"],
        status["notes"],
        host_summary["notes"],
        host_status["notes"],
    ):
        for token in note_tokens:
            assert token in notes
        assert "blocker_witness_sources" not in notes
    json.dumps(host_payload, allow_nan=False)
    json.dumps(analysis_payload, allow_nan=False)
    json.dumps(invariant_payload, allow_nan=False)

def test_imgui_host_payload_defaults_missing_detail_and_witness_evidence_to_zero() -> None:
    homfly_evidence = {
        "method": "homfly_input_certification_evidence",
        "claim_scope": "recursive_frontier_exhaustion_for_one_signed_pd_input",
        "homfly_polynomial": "P",
        "certified_for_input": True,
        "frontier_exhausted": True,
        "terminal_contribution_audit_skipped": True,
        "frontier_count": 0,
        "frontier_reason_count": 0,
        "truncated": False,
        "certification_blockers": [],
        "certification_blocker_count": 0,
        "homfly_completion_blockers": ["full_table_normalization_not_certified"],
        "homfly_completion_blocker_count": 1,
        "skipped": False,
        "notes": [],
    }
    alexander_evidence = {
        "method": "multivariable_alexander_input_certification_evidence",
        "claim_scope": "exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        "multivariable_alexander_polynomial": "1",
        "bounded_scanned_gcd_certified": True,
        "complete_scanned_gcd_certified": True,
        "quotient_gcd_certified": True,
        "failed_nonzero_minor_count": 0,
        "wirtinger_fox_input_chain_consistent": True,
        "full_invariant_certified": False,
        "skipped": False,
        "notes": [],
    }

    bundle = imgui_host_payload_from_acceptance_reports(
        [homfly_evidence, alexander_evidence],
        analysis_reports=[homfly_evidence, alexander_evidence],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )

    for prefix in ("analysis", "invariant"):
        section = bundle["analysis"] if prefix == "analysis" else bundle["invariants"]
        assert section[f"{prefix}_certification_blocker_detail_count"] == 0
        assert section[f"{prefix}_homfly_completion_blocker_detail_count"] == 0
        for key in (
            "homfly_reduction_contribution_count",
            "homfly_reduction_contribution_witness_count",
            "homfly_reduction_contribution_witness_limit",
            "homfly_reduction_contribution_witness_truncated_count",
            "homfly_reduction_contribution_parsed_count",
            "homfly_reduction_contribution_unparsed_count",
            "homfly_reduction_contribution_consistency_matched_count",
            "homfly_reduction_contribution_consistency_mismatch_count",
        ):
            assert section[f"{prefix}_{key}"] == 0
            assert bundle[f"{prefix}_{key}"] == 0
        assert section[f"{prefix}_failed_division_witness_count"] == 0
        assert section[f"{prefix}_quotient_gcd_uncertainty_present"] == 0
        assert section[f"{prefix}_quotient_polynomial_witness_count"] == 0
        assert section[f"{prefix}_quotient_polynomial_witness_truncated"] == 0
        assert section[f"{prefix}_normalization_class_witness_count"] == 0
        assert (
            section[
                f"{prefix}_admissible_minor_normalization_blocker_reason_count"
            ]
            == 0
        )
        assert (
            section[
                f"{prefix}_admissible_minor_normalization_blocker_witness_available_count"
            ]
            == 0
        )
        assert (
            section[
                f"{prefix}_admissible_minor_normalization_blocker_missing_witness_reason_count"
            ]
            == 0
        )
        assert (
            section[
                f"{prefix}_admissible_minor_normalization_blocker_witness_source_count"
            ]
            == 0
        )
        assert (
            section[
                f"{prefix}_admissible_minor_normalization_blocker_witness_source_available_count"
            ]
            == 0
        )
        assert (
            section[
                f"{prefix}_admissible_minor_normalization_blocker_witness_source_missing_count"
            ]
            == 0
        )
        assert bundle[f"{prefix}_certification_blocker_detail_count"] == 0
        assert bundle[f"{prefix}_homfly_completion_blocker_detail_count"] == 0
        assert bundle[f"{prefix}_failed_division_witness_count"] == 0
        assert bundle[f"{prefix}_quotient_gcd_uncertainty_present"] == 0
        assert bundle[f"{prefix}_quotient_polynomial_witness_count"] == 0
        assert bundle[f"{prefix}_quotient_polynomial_witness_truncated"] == 0
        assert bundle[f"{prefix}_normalization_class_witness_count"] == 0
        assert (
            bundle[
                f"{prefix}_admissible_minor_normalization_blocker_reason_count"
            ]
            == 0
        )
        assert (
            bundle[
                f"{prefix}_admissible_minor_normalization_blocker_witness_available_count"
            ]
            == 0
        )
        assert (
            bundle[
                f"{prefix}_admissible_minor_normalization_blocker_missing_witness_reason_count"
            ]
            == 0
        )
        assert (
            bundle[
                f"{prefix}_admissible_minor_normalization_blocker_witness_source_count"
            ]
            == 0
        )
        assert (
            bundle[
                f"{prefix}_admissible_minor_normalization_blocker_witness_source_available_count"
            ]
            == 0
        )
        assert (
            bundle[
                f"{prefix}_admissible_minor_normalization_blocker_witness_source_missing_count"
            ]
            == 0
        )

    summary_notes = " ".join(
        summary["notes"] for summary in bundle["analysis"]["analysis_summaries"]
    )
    assert "first_homfly_completion_blocker_detail_code" not in summary_notes
    assert "alexander_witness_evidence=" not in summary_notes
    assert "admissible_minor_normalization_blocker_witness_summary=" not in (
        summary_notes
    )
    json.dumps(bundle, allow_nan=False)


def test_imgui_blocker_witness_summary_does_not_infer_from_legacy_witness_lists() -> None:
    alexander_evidence = {
        "method": "multivariable_alexander_input_certification_evidence",
        "claim_scope": "exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        "multivariable_alexander_polynomial": "1 + t1",
        "bounded_scanned_gcd_certified": False,
        "complete_scanned_gcd_certified": False,
        "quotient_gcd_certified": False,
        "failed_nonzero_minor_count": 1,
        "failed_division_witness_count": 1,
        "failed_division_witness_limit": 8,
        "failed_division_witnesses": [
            {
                "minor_index": 7,
                "rows": [1],
                "columns": [0],
                "minor_polynomial": "1 - t2",
                "divisible": False,
                "quotient_polynomial": None,
                "reason": "source_does_not_divide_all_inputs",
            }
        ],
        "admissible_minor_normalization_blocker_details": {
            "normalization_class_not_unique": {
                "normalization_class_witness_count": 2,
                "normalization_class_witnesses": [
                    {
                        "normalized_polynomial": "1 - t1",
                        "minor_count": 1,
                    },
                    {
                        "normalized_polynomial": "1 + t1",
                        "minor_count": 1,
                    },
                ],
            },
        },
        "wirtinger_fox_input_chain_consistent": True,
        "full_invariant_certified": False,
        "skipped": False,
        "notes": [],
    }

    bundle = imgui_host_payload_from_acceptance_reports(
        [alexander_evidence],
        analysis_reports=[alexander_evidence],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )

    compact_keys = (
        "admissible_minor_normalization_blocker_reason_count",
        "admissible_minor_normalization_blocker_witness_available_count",
        "admissible_minor_normalization_blocker_missing_witness_reason_count",
        "admissible_minor_normalization_blocker_witness_source_count",
        "admissible_minor_normalization_blocker_witness_source_available_count",
        "admissible_minor_normalization_blocker_witness_source_missing_count",
    )
    summary = bundle["analysis"]["analysis_summaries"][0]
    status = bundle["invariants"]["invariant_statuses"][0]
    for key in compact_keys:
        assert summary[key] == 0
        assert status[key] == 0
        assert bundle["analysis"][f"analysis_{key}"] == 0
        assert bundle["invariants"][f"invariant_{key}"] == 0
        assert bundle[f"analysis_{key}"] == 0
        assert bundle[f"invariant_{key}"] == 0
    assert summary["failed_division_witness_count"] == 1
    assert status["failed_division_witness_count"] == 1
    assert bundle["analysis"]["analysis_failed_division_witness_count"] == 1
    assert bundle["invariants"]["invariant_failed_division_witness_count"] == 1
    assert summary["normalization_class_witness_count"] == 2
    assert status["normalization_class_witness_count"] == 2
    assert "first_normalization_class_witness=1 - t1" in summary["notes"]
    assert "admissible_minor_normalization_blocker_witness_summary=" not in (
        summary["notes"]
    )
    assert "first_admissible_minor_normalization_blocker_witness_source" not in (
        summary["notes"]
    )
    assert "blocker_witness_sources" not in summary["notes"]
    assert "admissible_minor_normalization_blocker_witness_summary=" not in (
        status["notes"]
    )
    assert "first_admissible_minor_normalization_blocker_witness_source" not in (
        status["notes"]
    )
    assert "blocker_witness_sources" not in status["notes"]
    json.dumps(bundle, allow_nan=False)


def test_imgui_geometry_payload_wraps_ribbon_centerline() -> None:
    x = np.linspace(0.0, 1.0, 16)
    points = np.column_stack([x, np.zeros_like(x), np.zeros_like(x)])
    directors = np.column_stack([np.zeros_like(x), np.ones_like(x), np.zeros_like(x)])
    ribbon = Ribbon3D(Polyline3D(points), directors, name="ribbon")
    report = analyze_ribbon(ribbon, backend="numpy")

    payload = imgui_geometry_payload_from_report(report)

    assert payload["source_kind"] == "ribbon"
    assert payload["report_name"] == "ribbon"
    assert payload["component_count"] == 1
    assert payload["components"][0]["name"] == "ribbon"
    assert payload["geometry_point_count"] == 16
    assert payload["component_closed"] == [0]
    assert len(report["geometry"]["directors"]) == 16
    json.dumps(payload, allow_nan=False)


def test_imgui_geometry_payload_wraps_contact_overlays() -> None:
    report = {
        "input": {"name": "contact-demo", "closed": False, "point_count": 2},
        "geometry": {
            "components": [
                {
                    "name": "contact-demo",
                    "closed": False,
                    "points": [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]],
                }
            ],
        },
        "topology": {
            "crossings": [],
            "contacts": {
                "threshold": 0.1,
                "contacts": [
                    {
                        "component_a": 0,
                        "segment_a": 0,
                        "parameter_a": 0.5,
                        "component_b": 0,
                        "segment_b": 1,
                        "parameter_b": 0.25,
                        "distance": 0.025,
                        "point3d_a": [0.5, 0.0, 0.0],
                        "point3d_b": [0.5, 0.025, 0.0],
                    }
                ],
            },
        },
    }

    contacts = contact_overlays_from_report(report)
    payload = imgui_geometry_payload_from_report(report)

    assert contacts == [
        {
            "component_a": 0,
            "segment_a": 0,
            "parameter_a": 0.5,
            "component_b": 0,
            "segment_b": 1,
            "parameter_b": 0.25,
            "distance": 0.025,
            "point3d_a": [0.5, 0.0, 0.0],
            "point3d_b": [0.5, 0.025, 0.0],
        }
    ]
    assert payload["contact_count"] == 1
    assert payload["contacts"] == contacts
    json.dumps(payload, allow_nan=False)


def test_invalid_report_returns_readable_schema_issues() -> None:
    issues = validate_report({"input": {"closed": True}})

    paths = {issue.path for issue in issues}

    assert "$.topology" in paths
    assert "$.warnings" in paths
    assert "$.version" in paths


def test_assert_valid_report_raises_on_wrong_kind() -> None:
    report = analyze_curve(
        Polyline3D(circle_points(count=64), closed=True),
        direction=[0.0, 0.0, 1.0],
        backend="numpy",
    )

    with pytest.raises(ValueError, match="component_count"):
        assert_valid_report(report, kind="link")


def test_imgui_analysis_summary_payload_wraps_cross_workstream_validation_pack_audit() -> None:
    report = cross_workstream_validation_pack_audit()

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])

    assert summary["name"] == "cross-workstream validation-pack audit"
    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert summary["claim_scope"] == "final_completion_checklist_metadata_audit"
    assert summary["accepted"] is False
    assert summary["certified"] is False
    assert summary["required_check_count"] == 3
    assert summary["passed_check_count"] == 1
    assert summary["failed_check_count"] == 2
    assert summary["validation_pack_audit_available_count"] == 1
    assert summary["required_diagram_fixture_count"] == 7
    assert summary["registered_required_diagram_fixture_count"] == 7
    assert summary["required_diagram_fixture_metadata_complete"] is True
    assert summary["required_diagram_fixture_metadata_complete_count"] == 1
    assert summary["metadata_blocker_count"] == 0
    assert summary["signed_diagram_fixture_registration_complete"] is False
    assert summary["signed_diagram_fixture_registration_complete_count"] == 0
    assert summary["unsigned_required_fixture_count"] == 2
    assert summary["open_non_diagram_requirement_count"] == 1
    assert summary["final_completion_gate_count"] == 7
    assert summary["final_completion_passed_gate_count"] == 1
    assert summary["final_completion_failed_gate_count"] == 6
    assert summary["final_completion_blocker_count"] == 7
    assert summary["final_completion_blocker_code_count"] == 6
    assert (
        summary[
            "final_completion_blocker_completion_evidence_artifact_filename_reference_count"
        ]
        == 9
    )
    assert (
        summary[
            "final_completion_blocker_completion_evidence_artifact_filename_unique_count"
        ]
        == 6
    )
    assert (
        summary[
            "final_completion_failed_gate_completion_evidence_artifact_filename_reference_count"
        ]
        == 7
    )
    assert (
        summary[
            "final_completion_failed_gate_completion_evidence_artifact_filename_unique_count"
        ]
        == 6
    )
    assert summary["final_completion_ready"] is False
    assert summary["final_completion_ready_count"] == 0
    assert report["fixture_source_url_shape_summary"]["claim_scope"] == (
        "validation_pack_fixture_source_url_shape_summary"
    )
    assert summary["validation_pack_fixture_source_url_fixture_row_count"] == 7
    assert summary["validation_pack_fixture_source_url_row_count"] == 3
    assert summary["validation_pack_fixture_source_url_external_row_count"] == 3
    assert summary["validation_pack_fixture_source_url_required_count"] == 3
    assert summary["validation_pack_fixture_source_url_http_or_https_count"] == 3
    assert (
        summary[
            "validation_pack_fixture_source_url_requirement_satisfied_count"
        ]
        == 3
    )
    assert summary["validation_pack_fixture_source_url_scheme_entry_count"] == 1
    assert summary["validation_pack_fixture_source_url_domain_entry_count"] == 1
    assert summary["validation_pack_fixture_source_url_scheme_count_total"] == 3
    assert summary["validation_pack_fixture_source_url_domain_count_total"] == 3
    assert (
        summary[
            "validation_pack_fixture_source_url_http_or_https_count_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "validation_pack_fixture_source_url_requirement_satisfied_count_matched_count"
        ]
        == 1
    )
    assert summary["validation_pack_fixture_source_url_shape_matched_count"] == 1
    assert "fixture_source_urls=rows=3; required=3" in summary["notes"]
    assert "http_or_https=3; requirement_satisfied=3" in summary["notes"]
    assert report["fixture_known_limitations_summary"]["claim_scope"] == (
        "validation_pack_fixture_known_limitations_summary"
    )
    assert summary["validation_pack_fixture_known_limitations_fixture_row_count"] == 7
    assert summary["validation_pack_fixture_known_limitations_available_count"] == 7
    assert summary["validation_pack_fixture_known_limitations_unavailable_count"] == 0
    assert summary["validation_pack_fixture_known_limitations_note_count_total"] == 34
    assert (
        summary[
            "validation_pack_fixture_known_limitations_requirement_satisfied_count"
        ]
        == 7
    )
    assert (
        summary[
            "validation_pack_fixture_known_limitations_requirement_satisfied_count_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "validation_pack_fixture_known_limitations_unavailable_count_matched_count"
        ]
        == 1
    )
    assert summary["validation_pack_fixture_known_limitations_matched_count"] == 1
    assert "fixture_known_limitations=rows=7; available=7" in summary["notes"]
    assert "notes=34; requirement_satisfied=7; matched=true" in summary["notes"]
    code_consistency = report["final_completion_blocker_code_consistency"]
    assert code_consistency["claim_scope"] == (
        "validation_pack_final_completion_blocker_code_consistency"
    )
    assert code_consistency["blocker_count"] == 7
    assert code_consistency["code_count"] == 6
    assert code_consistency["top_level_code_count"] == 6
    assert code_consistency["code_count_total"] == 7
    assert code_consistency["code_count_total_matches_blocker_count"] is True
    assert code_consistency["unique_code_count_matches_top_level"] is True
    assert code_consistency["codes_match_top_level"] is True
    assert code_consistency["signature_matches_counts"] is True
    assert code_consistency["all_blockers_have_code"] is True
    assert code_consistency["matched"] is True
    assert code_consistency["signature"] == report[
        "final_completion_blocker_signature"
    ]
    code_summary = {
        row["blocker_code"]: row
        for row in report["final_completion_blocker_code_summary"]
    }
    assert code_summary["signed_pd_not_registered"]["blocker_count"] == 2
    assert code_summary["signed_pd_not_registered"]["blocker_kinds"] == [
        "signed_fixture"
    ]
    code_detail = report[
        "final_completion_blocker_code_summary_detail_consistency"
    ]
    assert code_detail["claim_scope"] == (
        "validation_pack_final_completion_blocker_code_summary_detail_consistency"
    )
    assert code_detail["summary_row_count"] == 6
    assert code_detail["code_count"] == 6
    assert code_detail["checked_blocker_code_count"] == 6
    assert code_detail["blocker_count"] == 7
    assert code_detail["blocker_kind_reference_count"] == 6
    assert code_detail["blocker_label_reference_count"] == 7
    assert code_detail["missing_artifact_reference_count"] == 6
    assert code_detail["unique_missing_artifact_count"] == 5
    assert code_detail["summary_blocker_count_total"] == 7
    assert code_detail["blocker_count_matched_count"] == 6
    assert code_detail["blocker_kinds_matched_count"] == 6
    assert code_detail["blocker_labels_matched_count"] == 6
    assert code_detail["missing_artifacts_matched_count"] == 6
    assert code_detail["mismatched_summary_row_count"] == 0
    assert code_detail["matched"] is True
    kind_summary = {
        row["blocker_kind"]: row
        for row in report["final_completion_blocker_kind_summary"]
    }
    assert kind_summary["signed_fixture"]["blocker_count"] == 2
    assert kind_summary["non_diagram_requirement"]["blocker_count"] == 1
    assert kind_summary["completion_gate"]["blocker_count"] == 4
    kind_consistency = report["final_completion_blocker_kind_consistency"]
    assert kind_consistency["claim_scope"] == (
        "validation_pack_final_completion_blocker_kind_consistency"
    )
    assert kind_consistency["blocker_count"] == 7
    assert kind_consistency["summary_row_count"] == 3
    assert kind_consistency["summary_blocker_count"] == 7
    assert kind_consistency["kind_count"] == 3
    assert kind_consistency["kind_count_total"] == 7
    assert kind_consistency["kind_counts"] == {
        "completion_gate": 4,
        "non_diagram_requirement": 1,
        "signed_fixture": 2,
    }
    assert kind_consistency["all_blockers_have_kind"] is True
    assert kind_consistency["kind_count_total_matches_blocker_count"] is True
    assert kind_consistency["unique_kind_count_matches_summary"] is True
    assert kind_consistency["matched"] is True
    kind_detail = report[
        "final_completion_blocker_kind_summary_detail_consistency"
    ]
    assert kind_detail["claim_scope"] == (
        "validation_pack_final_completion_blocker_kind_summary_detail_consistency"
    )
    assert kind_detail["summary_row_count"] == 3
    assert kind_detail["kind_count"] == 3
    assert kind_detail["checked_blocker_kind_count"] == 3
    assert kind_detail["blocker_count"] == 7
    assert kind_detail["blocker_code_reference_count"] == 6
    assert kind_detail["missing_artifact_reference_count"] == 6
    assert kind_detail["unique_missing_artifact_count"] == 5
    assert kind_detail["summary_blocker_count_total"] == 7
    assert kind_detail["blocker_count_matched_count"] == 3
    assert kind_detail["blocker_codes_matched_count"] == 3
    assert kind_detail["missing_artifacts_matched_count"] == 3
    assert kind_detail["mismatched_summary_row_count"] == 0
    assert kind_detail["all_blocker_counts_matched"] is True
    assert kind_detail["all_blocker_codes_matched"] is True
    assert kind_detail["all_missing_artifacts_matched"] is True
    assert kind_detail["matched"] is True
    gate_summary = {
        row["gate"]: row
        for row in report["final_completion_open_gate_blocker_summary"]
    }
    assert gate_summary["signed_diagram_fixture_registration"]["blocker_count"] == 2
    assert gate_summary["non_diagram_requirements"]["blocker_count"] == 1
    assert gate_summary["non_diagram_requirements"]["retained_evidence_count"] == 2
    gate_summary_consistency = report[
        "final_completion_open_gate_blocker_summary_consistency"
    ]
    assert gate_summary_consistency["failed_gate_count"] == 6
    assert gate_summary_consistency["summary_gate_count"] == 6
    assert gate_summary_consistency["blocker_count"] == 7
    assert gate_summary_consistency["summary_blocker_count"] == 7
    assert gate_summary_consistency["gate_sets_matched"] is True
    assert gate_summary_consistency["blocker_count_matched"] is True
    assert gate_summary_consistency["all_blockers_have_gate"] is True
    gate_summary_detail = report[
        "final_completion_open_gate_blocker_summary_detail_consistency"
    ]
    assert gate_summary_detail["claim_scope"] == (
        "validation_pack_final_completion_open_gate_blocker_summary_detail_consistency"
    )
    assert gate_summary_detail["summary_gate_count"] == 6
    assert gate_summary_detail["checked_gate_count"] == 6
    assert gate_summary_detail["blocker_count"] == 7
    assert gate_summary_detail["blocker_code_reference_count"] == 6
    assert gate_summary_detail["missing_artifact_reference_count"] == 6
    assert gate_summary_detail["unique_missing_artifact_count"] == 5
    assert gate_summary_detail["retained_evidence_reference_count"] == 10
    assert gate_summary_detail["summary_blocker_count_total"] == 7
    assert gate_summary_detail["blocker_count_matched_count"] == 6
    assert gate_summary_detail["blocker_codes_matched_count"] == 6
    assert gate_summary_detail["missing_artifacts_matched_count"] == 6
    assert gate_summary_detail["retained_evidence_count_matched_count"] == 6
    assert gate_summary_detail["mismatched_summary_row_count"] == 0
    assert gate_summary_detail["all_blocker_counts_matched"] is True
    assert gate_summary_detail["all_blocker_codes_matched"] is True
    assert gate_summary_detail["all_missing_artifacts_matched"] is True
    assert gate_summary_detail["all_retained_evidence_counts_matched"] is True
    assert gate_summary_detail["matched"] is True
    gate_blocker_consistency = report[
        "final_completion_gate_blocker_consistency"
    ]
    assert gate_blocker_consistency["claim_scope"] == (
        "validation_pack_final_completion_gate_blocker_consistency"
    )
    assert gate_blocker_consistency["gate_check_count"] == 7
    assert gate_blocker_consistency["summary_gate_count"] == 6
    assert gate_blocker_consistency["checked_gate_count"] == 7
    assert gate_blocker_consistency["matched_gate_count"] == 7
    assert gate_blocker_consistency["mismatched_gate_count"] == 0
    assert gate_blocker_consistency["blocker_count_matched_gate_count"] == 7
    assert gate_blocker_consistency["blocker_codes_matched_gate_count"] == 7
    assert gate_blocker_consistency["all_gate_blocker_counts_matched"] is True
    assert gate_blocker_consistency["all_gate_blocker_codes_matched"] is True
    assert gate_blocker_consistency["matched"] is True
    gate_blocker_rows = {
        row["gate"]: row for row in gate_blocker_consistency["gate_rows"]
    }
    assert gate_blocker_rows["required_diagram_fixture_metadata"][
        "summary_blocker_count"
    ] == 0
    assert gate_blocker_rows["required_diagram_fixture_metadata"][
        "summary_blocker_codes"
    ] == []
    assert gate_blocker_rows["signed_diagram_fixture_registration"][
        "gate_blocker_count"
    ] == 2
    assert gate_blocker_rows["signed_diagram_fixture_registration"][
        "summary_blocker_count"
    ] == 2
    assert gate_blocker_rows["signed_diagram_fixture_registration"][
        "blocker_codes_matched"
    ] is True
    required_check_consistency = report[
        "final_completion_required_check_consistency"
    ]
    assert required_check_consistency["claim_scope"] == (
        "validation_pack_final_completion_required_check_consistency"
    )
    assert report["required_check_count"] == 3
    assert report["passed_check_count"] == 1
    assert report["failed_check_count"] == 2
    assert required_check_consistency["required_check_count"] == 3
    assert required_check_consistency["passed_required_check_count"] == 1
    assert required_check_consistency["failed_required_check_count"] == 2
    assert required_check_consistency["mismatched_required_check_count"] == 2
    assert required_check_consistency["metadata_check_passed"] is True
    assert required_check_consistency["signed_fixture_check_passed"] is False
    assert required_check_consistency["non_diagram_check_passed"] is False
    assert (
        required_check_consistency[
            "final_completion_ready_matches_required_checks"
        ]
        is True
    )
    assert required_check_consistency["all_required_checks_matched"] is False
    assert required_check_consistency["matched"] is False
    required_check_rows = {
        row["check"]: row for row in required_check_consistency["rows"]
    }
    assert required_check_rows["required_diagram_fixture_metadata"]["passed"] is True
    assert (
        required_check_rows["signed_diagram_fixture_registration"]["blocker_count"]
        == 2
    )
    assert required_check_rows["non_diagram_requirements"]["blocker_count"] == 1
    required_fixture_metadata = report[
        "final_completion_required_diagram_fixture_metadata_consistency"
    ]
    assert required_fixture_metadata["claim_scope"] == (
        "validation_pack_final_completion_required_diagram_fixture_metadata_consistency"
    )
    assert required_fixture_metadata["required_fixture_count"] == 7
    assert required_fixture_metadata["registered_fixture_count"] == 7
    assert required_fixture_metadata["missing_fixture_count"] == 0
    assert required_fixture_metadata["metadata_complete_fixture_count"] == 7
    assert required_fixture_metadata["metadata_incomplete_fixture_count"] == 0
    assert required_fixture_metadata["mismatched_fixture_count"] == 0
    assert required_fixture_metadata["metadata_blocker_count"] == 0
    assert required_fixture_metadata["gate_passed"] is True
    assert required_fixture_metadata["gate_blocker_count"] == 0
    assert required_fixture_metadata["gate_blocker_codes"] == []
    assert required_fixture_metadata["all_required_fixtures_registered"] is True
    assert required_fixture_metadata["all_fixture_metadata_complete"] is True
    assert required_fixture_metadata["gate_passed_matches_metadata_complete"] is True
    assert required_fixture_metadata["gate_blocker_count_matched"] is True
    assert required_fixture_metadata["matched"] is True
    assert [row["notation"] for row in required_fixture_metadata["rows"]] == [
        "0_1",
        "3_1",
        "4_1",
        "L0a1",
        "L2a1",
        "L5a1",
        "L6a4",
    ]
    signed_fixture_consistency = report[
        "final_completion_signed_fixture_consistency"
    ]
    assert signed_fixture_consistency["claim_scope"] == (
        "validation_pack_final_completion_signed_fixture_consistency"
    )
    assert signed_fixture_consistency["signed_fixture_blocker_count"] == 2
    assert signed_fixture_consistency["final_blocker_count"] == 2
    assert signed_fixture_consistency["matched_fixture_count"] == 2
    assert signed_fixture_consistency["mismatched_fixture_count"] == 0
    assert signed_fixture_consistency["source_url_present_count"] == 2
    assert signed_fixture_consistency["unsigned_non_claim_preserved_count"] == 2
    assert signed_fixture_consistency["source_table_metadata_available_count"] == 2
    assert signed_fixture_consistency["missing_artifact_matched_count"] == 2
    assert signed_fixture_consistency["evidence_fields_matched_count"] == 2
    assert signed_fixture_consistency["source_candidate_evidence_available_count"] == 2
    assert signed_fixture_consistency["source_candidate_not_unique_count"] == 2
    assert signed_fixture_consistency["source_candidate_replay_all_valid_count"] == 2
    assert (
        signed_fixture_consistency[
            "source_candidate_matching_candidate_count_total"
        ]
        == 32
    )
    assert (
        signed_fixture_consistency[
            "source_candidate_unique_sign_pattern_count_total"
        ]
        == 20
    )
    assert (
        signed_fixture_consistency[
            "all_signed_fixture_blockers_have_final_blockers"
        ]
        is True
    )
    assert signed_fixture_consistency["all_unsigned_non_claims_preserved"] is True
    assert signed_fixture_consistency["all_source_table_metadata_available"] is True
    assert signed_fixture_consistency["matched"] is True
    signed_fixture_rows = {
        row["notation"]: row for row in signed_fixture_consistency["rows"]
    }
    assert signed_fixture_rows["L5a1"]["source_url"] == (
        "https://katlas.org/wiki/L5a1"
    )
    assert signed_fixture_rows["L5a1"]["source_candidate_matching_candidate_count"] == 24
    assert signed_fixture_rows["L5a1"]["source_candidate_unique_sign_pattern_count"] == 12
    assert (
        signed_fixture_rows["L5a1"]["source_candidate_registration_blocker_code"]
        == "source_candidate_not_unique"
    )
    assert signed_fixture_rows["L6a4"]["blocker_code"] == "signed_pd_not_registered"
    assert signed_fixture_rows["L6a4"]["source_candidate_matching_candidate_count"] == 8
    assert signed_fixture_rows["L6a4"]["source_candidate_unique_sign_pattern_count"] == 8
    non_diagram_consistency = report[
        "final_completion_non_diagram_requirement_consistency"
    ]
    assert non_diagram_consistency["claim_scope"] == (
        "validation_pack_final_completion_non_diagram_requirement_consistency"
    )
    assert non_diagram_consistency["requirement_count"] == 6
    assert non_diagram_consistency["open_requirement_count"] == 1
    assert non_diagram_consistency["blocker_count"] == 1
    assert non_diagram_consistency["matched_requirement_count"] == 1
    assert non_diagram_consistency["mismatched_requirement_count"] == 0
    assert non_diagram_consistency["retained_evidence_reference_count"] == 2
    assert non_diagram_consistency["retained_evidence_id_count"] == 2
    assert (
        non_diagram_consistency[
            "retained_evidence_reference_count_matches_top_level"
        ]
        is True
    )
    assert (
        non_diagram_consistency["retained_evidence_id_count_matches_top_level"]
        is True
    )
    assert non_diagram_consistency["missing_artifact_matched_count"] == 1
    assert non_diagram_consistency["evidence_fields_matched_count"] == 1
    assert non_diagram_consistency["retained_evidence_count_matched_count"] == 1
    assert non_diagram_consistency["retained_evidence_ids_matched_count"] == 1
    assert non_diagram_consistency["completion_claimed_false_count"] == 1
    assert non_diagram_consistency["all_open_requirements_have_blockers"] is True
    assert non_diagram_consistency["all_blockers_have_open_requirements"] is True
    assert non_diagram_consistency["all_missing_artifacts_matched"] is True
    assert non_diagram_consistency["all_evidence_fields_matched"] is True
    assert non_diagram_consistency["all_retained_evidence_counts_matched"] is True
    assert non_diagram_consistency["all_retained_evidence_ids_matched"] is True
    assert non_diagram_consistency["all_completion_claims_false"] is True
    assert non_diagram_consistency["matched"] is True
    non_diagram_rows = {
        row["requirement"]: row for row in non_diagram_consistency["rows"]
    }
    assert "noisy sampled curves" not in non_diagram_rows
    assert "high-point-count performance curves" not in non_diagram_rows
    assert non_diagram_rows["native ImGui screenshot/framebuffer fixtures"][
        "retained_evidence_count"
    ] == 2
    assert non_diagram_rows["native ImGui screenshot/framebuffer fixtures"][
        "blocker_code"
    ] == "native_imgui_screenshot_framebuffer_fixtures_partial"
    non_claim_gate_consistency = report[
        "final_completion_non_claim_gate_consistency"
    ]
    assert non_claim_gate_consistency["claim_scope"] == (
        "validation_pack_final_completion_non_claim_gate_consistency"
    )
    assert non_claim_gate_consistency["non_claim_field_count"] == 4
    assert non_claim_gate_consistency["false_non_claim_field_count"] == 4
    assert non_claim_gate_consistency["completion_gate_check_count"] == 4
    assert non_claim_gate_consistency["completion_gate_blocker_count"] == 4
    assert non_claim_gate_consistency["missing_artifact_reference_count"] == 4
    assert non_claim_gate_consistency["unique_missing_artifact_count"] == 4
    assert non_claim_gate_consistency["matched_non_claim_field_count"] == 4
    assert non_claim_gate_consistency["mismatched_non_claim_field_count"] == 0
    assert non_claim_gate_consistency["all_non_claim_fields_false"] is True
    assert non_claim_gate_consistency["all_false_fields_have_failed_gate"] is True
    assert (
        non_claim_gate_consistency["all_false_fields_have_completion_gate_blocker"]
        is True
    )
    assert non_claim_gate_consistency["all_false_fields_have_missing_artifact"] is True
    assert non_claim_gate_consistency["matched"] is True
    completion_gate_evidence = report[
        "final_completion_completion_gate_evidence_consistency"
    ]
    assert completion_gate_evidence["claim_scope"] == (
        "validation_pack_final_completion_completion_gate_evidence_consistency"
    )
    assert completion_gate_evidence["gate_count"] == 4
    assert completion_gate_evidence["gate_check_count"] == 4
    assert completion_gate_evidence["completion_gate_blocker_count"] == 4
    assert completion_gate_evidence["failed_gate_count"] == 4
    assert completion_gate_evidence["top_level_false_count"] == 4
    assert completion_gate_evidence["blocker_code_matched_count"] == 4
    assert completion_gate_evidence["gate_code_matched_count"] == 4
    assert completion_gate_evidence["required_evidence_matched_count"] == 4
    assert completion_gate_evidence["current_evidence_matched_count"] == 4
    assert completion_gate_evidence["missing_artifact_matched_count"] == 4
    assert completion_gate_evidence["missing_artifact_id_matched_count"] == 4
    assert completion_gate_evidence["retained_evidence_reference_count"] == 8
    assert completion_gate_evidence["retained_evidence_id_count"] == 8
    assert completion_gate_evidence["retained_evidence_ids_matched_count"] == 4
    assert completion_gate_evidence["mismatched_gate_count"] == 0
    assert completion_gate_evidence["all_evidence_fields_matched"] is True
    assert completion_gate_evidence["matched"] is True
    retained_non_claim = report["retained_evidence_non_claim_consistency"]
    assert retained_non_claim["claim_scope"] == (
        "validation_pack_retained_evidence_non_claim_consistency"
    )
    assert retained_non_claim["entry_count"] == 10
    assert retained_non_claim["evidence_id_count"] == 8
    assert retained_non_claim["completion_claimed_count"] == 0
    assert retained_non_claim["release_grade_speedup_claimed_count"] == 0
    assert retained_non_claim[
        "real_graphics_backend_framebuffer_verified_count"
    ] == 0
    assert retained_non_claim["screenshot_verified_count"] == 0
    assert retained_non_claim["all_non_claimed"] is True
    assert retained_non_claim["entry_count_matches_top_level"] is True
    assert retained_non_claim["evidence_id_count_matches_top_level"] is True
    assert retained_non_claim["completion_claimed_count_matches_top_level"] is True
    assert (
        retained_non_claim[
            "release_grade_speedup_claimed_count_matches_top_level"
        ]
        is True
    )
    assert retained_non_claim["matched"] is True
    artifact_file_consistency = report[
        "retained_evidence_artifact_file_consistency"
    ]
    assert artifact_file_consistency["claim_scope"] == (
        "validation_pack_retained_evidence_artifact_file_consistency"
    )
    assert artifact_file_consistency["entry_count"] == 10
    assert artifact_file_consistency["artifact_evidence_count"] == 2
    assert artifact_file_consistency["non_artifact_evidence_count"] == 8
    assert artifact_file_consistency["artifact_file_reference_count"] == 6
    assert artifact_file_consistency["unique_artifact_file_count"] == 6
    assert artifact_file_consistency["raw_file_count"] == 2
    assert artifact_file_consistency["analysis_file_count"] == 2
    assert artifact_file_consistency["host_file_count"] == 2
    assert artifact_file_consistency[
        "complete_raw_analysis_host_group_count"
    ] == 2
    assert artifact_file_consistency["incomplete_artifact_group_count"] == 0
    assert artifact_file_consistency["raw_analysis_host_file_counts_matched"] is True
    assert artifact_file_consistency["all_artifact_evidence_groups_complete"] is True
    assert artifact_file_consistency["all_artifact_files_unique"] is True
    assert artifact_file_consistency["matched"] is True
    blocker_links = report["final_completion_blocker_evidence_links"]
    assert len(blocker_links) == report["final_completion_blocker_count"]
    assert (
        sum(1 for link in blocker_links if link["retained_evidence_count"] > 0)
        == 5
    )
    assert (
        sum(link["retained_evidence_count"] for link in blocker_links)
        == report["retained_evidence_count"]
    )
    blocker_link_consistency = report[
        "final_completion_blocker_evidence_link_consistency"
    ]
    assert blocker_link_consistency["blocker_count"] == 7
    assert blocker_link_consistency["linked_blocker_count"] == 5
    assert blocker_link_consistency["unlinked_blocker_count"] == 2
    assert blocker_link_consistency["retained_evidence_reference_count"] == 10
    assert blocker_link_consistency["retained_evidence_id_count"] == 8
    assert (
        blocker_link_consistency[
            "retained_evidence_reference_count_matches_top_level"
        ]
        is True
    )
    assert blocker_link_consistency["retained_evidence_id_count_matches_top_level"] is True
    assert (
        blocker_link_consistency[
            "retained_evidence_non_claim_consistency_matches_top_level"
        ]
        is True
    )
    assert blocker_link_consistency["blocker_label_present_count"] == 7
    assert blocker_link_consistency["blocker_code_present_count"] == 7
    assert blocker_link_consistency["missing_artifact_present_count"] == 7
    assert blocker_link_consistency["required_evidence_present_count"] == 7
    assert blocker_link_consistency["current_evidence_present_count"] == 7
    assert blocker_link_consistency["all_blockers_have_machine_audit_fields"] is True
    assert blocker_link_consistency["matched"] is True
    link_kind_summary = {
        row["blocker_kind"]: row
        for row in report["final_completion_blocker_evidence_link_kind_summary"]
    }
    assert link_kind_summary["non_diagram_requirement"]["linked_blocker_count"] == 1
    assert link_kind_summary["non_diagram_requirement"][
        "retained_evidence_reference_count"
    ] == 2
    assert link_kind_summary["completion_gate"]["linked_blocker_count"] == 4
    assert link_kind_summary["completion_gate"]["unlinked_blocker_count"] == 0
    assert link_kind_summary["completion_gate"][
        "retained_evidence_reference_count"
    ] == 8
    link_kind_detail = report[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency"
    ]
    assert link_kind_detail["summary_row_count"] == 3
    assert link_kind_detail["checked_blocker_kind_count"] == 3
    assert link_kind_detail["blocker_count"] == 7
    assert link_kind_detail["linked_blocker_count"] == 5
    assert link_kind_detail["unlinked_blocker_count"] == 2
    assert link_kind_detail["retained_evidence_reference_count"] == 10
    assert link_kind_detail["retained_evidence_id_count"] == 8
    assert link_kind_detail["retained_evidence_non_claimed_link_count"] == 7
    assert link_kind_detail["blocker_count_matched_count"] == 3
    assert link_kind_detail["linked_blocker_count_matched_count"] == 3
    assert link_kind_detail["unlinked_blocker_count_matched_count"] == 3
    assert link_kind_detail["retained_evidence_reference_count_matched_count"] == 3
    assert link_kind_detail["retained_evidence_ids_matched_count"] == 3
    assert link_kind_detail["retained_evidence_non_claim_counts_matched_count"] == 3
    assert link_kind_detail["mismatched_summary_row_count"] == 0
    assert link_kind_detail["matched"] is True
    missing_artifact_summary = {
        row["missing_artifact"]: row
        for row in report["final_completion_missing_artifact_summary"]
    }
    assert len(missing_artifact_summary) == 5
    assert missing_artifact_summary["verified_signed_crossing_assignment"][
        "blocker_count"
    ] == 2
    assert missing_artifact_summary["production_imgui_renderer_framebuffer_pack"][
        "blocker_count"
    ] == 2
    missing_artifact_consistency = report[
        "final_completion_missing_artifact_summary_consistency"
    ]
    assert missing_artifact_consistency["reference_count"] == 7
    assert missing_artifact_consistency["unique_missing_artifact_count"] == 5
    assert missing_artifact_consistency["summary_row_count"] == 5
    assert missing_artifact_consistency["references_match_blocker_count"] is True
    assert (
        missing_artifact_consistency[
            "summary_row_count_matches_unique_missing_artifacts"
        ]
        is True
    )
    assert missing_artifact_consistency["matched"] is True
    missing_artifact_detail = report[
        "final_completion_missing_artifact_summary_detail_consistency"
    ]
    assert missing_artifact_detail["claim_scope"] == (
        "validation_pack_final_completion_missing_artifact_summary_detail_consistency"
    )
    assert missing_artifact_detail["summary_row_count"] == 5
    assert missing_artifact_detail["unique_missing_artifact_count"] == 5
    assert missing_artifact_detail["blocker_count"] == 7
    assert missing_artifact_detail["blocker_code_reference_count"] == 6
    assert missing_artifact_detail["blocker_label_reference_count"] == 7
    assert missing_artifact_detail["blocker_count_matched_count"] == 5
    assert missing_artifact_detail["blocker_codes_matched_count"] == 5
    assert missing_artifact_detail["blocker_labels_matched_count"] == 5
    assert missing_artifact_detail["mismatched_summary_row_count"] == 0
    assert missing_artifact_detail["all_blocker_counts_matched"] is True
    assert missing_artifact_detail["all_blocker_codes_matched"] is True
    assert missing_artifact_detail["all_blocker_labels_matched"] is True
    assert missing_artifact_detail["matched"] is True
    evidence_field_summary = {
        row["blocker_kind"]: row
        for row in report["final_completion_blocker_evidence_field_summary"]
    }
    assert evidence_field_summary["signed_fixture"]["blocker_count"] == 2
    assert evidence_field_summary["non_diagram_requirement"]["blocker_count"] == 1
    assert evidence_field_summary["completion_gate"]["blocker_count"] == 4
    assert len(report["final_completion_blocker_evidence_field_rows"]) == 7
    evidence_field_consistency = report[
        "final_completion_blocker_evidence_field_consistency"
    ]
    assert evidence_field_consistency["summary_row_count"] == 3
    assert evidence_field_consistency["missing_artifact_present_count"] == 7
    assert evidence_field_consistency["required_evidence_present_count"] == 7
    assert evidence_field_consistency["current_evidence_present_count"] == 7
    assert evidence_field_consistency["all_evidence_fields_present_count"] == 7
    assert evidence_field_consistency["matched"] is True
    evidence_field_detail = report[
        "final_completion_blocker_evidence_field_summary_detail_consistency"
    ]
    assert evidence_field_detail["claim_scope"] == (
        "validation_pack_final_completion_blocker_evidence_field_summary_detail_consistency"
    )
    assert evidence_field_detail["summary_row_count"] == 3
    assert evidence_field_detail["checked_blocker_kind_count"] == 3
    assert evidence_field_detail["blocker_count"] == 7
    assert evidence_field_detail["missing_artifact_present_count"] == 7
    assert evidence_field_detail["required_evidence_present_count"] == 7
    assert evidence_field_detail["current_evidence_present_count"] == 7
    assert evidence_field_detail["all_evidence_fields_present_count"] == 7
    assert evidence_field_detail["blocker_count_matched_count"] == 3
    assert evidence_field_detail["missing_artifact_present_count_matched_count"] == 3
    assert evidence_field_detail["required_evidence_present_count_matched_count"] == 3
    assert evidence_field_detail["current_evidence_present_count_matched_count"] == 3
    assert evidence_field_detail["all_evidence_fields_present_count_matched_count"] == 3
    assert evidence_field_detail["mismatched_summary_row_count"] == 0
    assert evidence_field_detail["all_blocker_counts_matched"] is True
    assert evidence_field_detail["all_evidence_field_counts_matched"] is True
    assert evidence_field_detail["matched"] is True
    assert summary["production_imgui_renderer_verified"] is False
    assert summary["production_imgui_renderer_verified_count"] == 0
    assert (
        "validation_pack=fixtures=7/7; unsigned=2; "
        "open_non_diagram=1; final_blockers=7; "
        "blocker_signature="
    ) in summary["notes"]
    assert "signed_pd_not_registered:2" in summary["notes"]
    assert "missing_artifacts=" in summary["notes"]
    assert "full_homfly_pt_evaluation_certification_pack" in summary["notes"]
    assert "production_imgui_renderer_framebuffer_pack" in summary["notes"]
    assert "signed_release_publication_manifest" in summary["notes"]
    assert "completion_evidence_targets=" in summary["notes"]
    assert "verified_signed_crossing_assignment.L5a1.json" in summary["notes"]
    assert "signed_release_publication_manifest.json" in summary["notes"]
    assert "open_evidence=" in summary["notes"]
    assert "L5a1{missing_artifact=verified_signed_crossing_assignment" in summary[
        "notes"
    ]
    assert "fixture remains unsigned and unregistered" in summary["notes"]
    assert "required=" in summary["notes"]
    assert "current=" in summary["notes"]
    assert "repository test-stub framebuffer" in summary["notes"]
    assert "retained_evidence=" in summary["notes"]
    assert "numpy_benchmark_matrix_local_profiling" not in summary["notes"]
    assert "imgui_test_stub_framebuffer_smoke_retained_pack" in summary["notes"]
    assert "completion_claimed=false" in summary["notes"]
    assert (
        "retained_evidence_kinds=ci_retained_artifact:6|repository_test:4"
        in summary["notes"]
    )
    assert "retained_evidence_consistency=entries=10; ids=8" in summary["notes"]
    assert "completion_claimed=0" in summary["notes"]
    assert "all_non_claimed=true" in summary["notes"]
    assert "retained_evidence_non_claim=entries=10; ids=8" in summary["notes"]
    assert "completion=0; release_speedup=0" in summary["notes"]
    assert "real_backend=0; screenshot=0; matched=true" in summary["notes"]
    assert (
        "retained_evidence_artifact_files=entries=10; artifact_entries=2"
        in summary["notes"]
    )
    assert "non_artifact=8; refs=6; unique=6" in summary["notes"]
    assert "raw=2; analysis=2; host=2" in summary["notes"]
    assert "complete_groups=2; incomplete_groups=0" in summary["notes"]
    assert "file_types_matched=true; groups_complete=true" in summary["notes"]
    assert "blocker_code_consistency=codes=6; total=7" in summary["notes"]
    assert "signature_matched=true; all_have_code=true" in summary["notes"]
    assert "blocker_code_summary_detail=rows=6; codes=6" in summary["notes"]
    assert "blockers=7; kinds=6; labels=7" in summary["notes"]
    assert "missing_refs=6; unique_missing=5" in summary["notes"]
    assert "kinds_matched=6; labels_matched=6" in summary["notes"]
    assert "blocker_kind_consistency=kinds=3; total=7" in summary["notes"]
    assert "signed=2; non_diagram=1; completion=4" in summary["notes"]
    assert "blocker_kind_summary_detail=rows=3; kinds=3" in summary["notes"]
    assert "blockers=7; codes=6; missing_refs=6; unique_missing=5" in summary[
        "notes"
    ]
    assert "count_matched=3; codes_matched=3" in summary["notes"]
    assert "missing_artifacts_matched=3; mismatched=0" in summary["notes"]
    assert "open_gate_blocker_summary=failed_gates=6; summary_gates=6" in summary[
        "notes"
    ]
    assert "blockers=7; summary_blockers=7" in summary["notes"]
    assert "gate_sets_matched=true" in summary["notes"]
    assert "blocker_count_matched=true" in summary["notes"]
    assert "all_blockers_have_gate=true" in summary["notes"]
    assert (
        "open_gate_blocker_summary_detail=gates=6; blockers=7"
        in summary["notes"]
    )
    assert "codes=6; missing_refs=6; unique_missing=5" in summary["notes"]
    assert "retained=10; count_matched=6" in summary["notes"]
    assert "missing_artifacts_matched=6; retained_matched=6" in summary["notes"]
    assert "blocker_evidence_links=linked=5; unlinked=2" in summary["notes"]
    assert "evidence_refs=10" in summary["notes"]
    assert "refs_matched=true" in summary["notes"]
    assert "ids_matched=true" in summary["notes"]
    assert "non_claim_matched=true" in summary["notes"]
    assert "labels=7; codes=7; missing=7; required=7; current=7" in summary[
        "notes"
    ]
    assert (
        "blocker_evidence_link_kind_detail=rows=3; blockers=7"
        in summary["notes"]
    )
    assert "linked=5; unlinked=2; refs=10; ids=8" in summary["notes"]
    assert "non_claimed_links=7; blocker_matched=3" in summary["notes"]
    assert "non_claim_matched=3; mismatched=0; matched=true" in summary["notes"]
    assert "gate_blocker_consistency=checked=7" in summary["notes"]
    assert "count_matched=7; codes_matched=7; mismatched=0" in summary["notes"]
    assert "required_check_consistency=required=3; passed=1" in summary[
        "notes"
    ]
    assert "failed=2; mismatched=2" in summary["notes"]
    assert "final_ready_matched=true" in summary["notes"]
    assert (
        "required_fixture_metadata_consistency=required=7; registered=7"
        in summary["notes"]
    )
    assert "missing=0; metadata_complete=7" in summary["notes"]
    assert (
        "metadata_incomplete=0; blockers=0; gate_passed=true"
        in summary["notes"]
    )
    assert "signed_fixture_consistency=blockers=2; final_blockers=2" in summary[
        "notes"
    ]
    assert "unsigned_non_claims=2; source_table_metadata=2" in summary["notes"]
    assert "source_candidate_matches=32" in summary["notes"]
    assert "source_candidate_unique_signs=20" in summary["notes"]
    assert (
        "non_diagram_requirement_consistency=requirements=6; open=1"
        in summary["notes"]
    )
    assert "blockers=1; evidence_refs=2" in summary["notes"]
    assert "evidence_ids=2" in summary["notes"]
    assert "refs_top_level_matched=true" in summary["notes"]
    assert "ids_top_level_matched=true" in summary["notes"]
    assert "non_claim_gate_consistency=fields=4; false=4" in summary["notes"]
    assert "gates=4; blockers=4; missing_artifacts=4" in summary["notes"]
    assert (
        "completion_gate_evidence_consistency=gates=4; gate_checks=4"
        in summary["notes"]
    )
    assert "blockers=4; failed=4; false=4; codes=4" in summary["notes"]
    assert (
        "required=4; current=4; missing_artifacts=4; missing_artifact_ids=4; retained_evidence=8; retained_evidence_ids=8; retained_evidence_matched=4; mismatched=0"
        in summary["notes"]
    )
    assert "missing_artifact_summary=refs=7; unique=5; rows=5" in summary[
        "notes"
    ]
    assert "rows_matched=true" in summary["notes"]
    assert (
        "missing_artifact_summary_detail=rows=5; unique=5; blockers=7"
        in summary["notes"]
    )
    assert "codes=6; labels=7; count_matched=5" in summary["notes"]
    assert "codes_matched=5; labels_matched=5; mismatched=0" in summary["notes"]
    assert "blocker_evidence_fields=summary_rows=3" in summary["notes"]
    assert "missing_artifact=7; required=7; current=7; all_present=7" in summary[
        "notes"
    ]
    assert (
        "blocker_evidence_field_summary_detail=rows=3; blockers=7"
        in summary["notes"]
    )
    assert "count_matched=3; missing_matched=3" in summary["notes"]
    assert "required_matched=3; current_matched=3" in summary["notes"]
    assert "all_present_matched=3; mismatched=0" in summary["notes"]
    assert payload["analysis_validation_pack_audit_available_count"] == 1
    assert payload["analysis_required_diagram_fixture_count"] == 7
    assert payload["analysis_unsigned_required_fixture_count"] == 2
    assert payload["analysis_open_non_diagram_requirement_count"] == 1
    assert payload["analysis_final_completion_gate_count"] == 7
    assert payload["analysis_final_completion_passed_gate_count"] == 1
    assert payload["analysis_final_completion_failed_gate_count"] == 6
    assert payload["analysis_final_completion_blocker_count"] == 7
    assert payload["analysis_final_completion_blocker_code_count"] == 6
    assert (
        payload[
            "analysis_final_completion_blocker_completion_evidence_artifact_filename_reference_count"
        ]
        == 9
    )
    assert (
        payload[
            "analysis_final_completion_blocker_completion_evidence_artifact_filename_unique_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_failed_gate_completion_evidence_artifact_filename_reference_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_failed_gate_completion_evidence_artifact_filename_unique_count"
        ]
        == 6
    )
    assert payload["analysis_final_completion_ready_count"] == 0
    assert payload["analysis_validation_pack_fixture_source_url_fixture_row_count"] == 7
    assert payload["analysis_validation_pack_fixture_source_url_row_count"] == 3
    assert payload["analysis_validation_pack_fixture_source_url_external_row_count"] == 3
    assert payload["analysis_validation_pack_fixture_source_url_required_count"] == 3
    assert (
        payload["analysis_validation_pack_fixture_source_url_http_or_https_count"]
        == 3
    )
    assert (
        payload[
            "analysis_validation_pack_fixture_source_url_requirement_satisfied_count"
        ]
        == 3
    )
    assert (
        payload[
            "analysis_validation_pack_fixture_source_url_scheme_count_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_validation_pack_fixture_source_url_domain_count_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_validation_pack_fixture_source_url_shape_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_blocker_code_consistency_code_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_blocker_code_consistency_code_total"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_code_consistency_total_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_blocker_code_consistency_unique_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_blocker_code_consistency_signature_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_blocker_code_consistency_all_have_code_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_blocker_code_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_blocker_code_summary_detail_consistency_row_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_blocker_code_summary_detail_consistency_code_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_blocker_code_summary_detail_consistency_blocker_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_code_summary_detail_consistency_kind_reference_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_blocker_code_summary_detail_consistency_label_reference_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_code_summary_detail_consistency_missing_artifact_reference_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_blocker_code_summary_detail_consistency_unique_missing_artifact_count"
        ]
        == 5
    )
    assert (
        payload[
            "analysis_final_completion_blocker_code_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload["analysis_final_completion_blocker_kind_summary_row_count"]
        == 3
    )
    assert (
        payload["analysis_final_completion_blocker_kind_summary_blocker_count"]
        == 7
    )
    assert payload["analysis_final_completion_blocker_kind_signed_fixture_count"] == 2
    assert (
        payload[
            "analysis_final_completion_blocker_kind_non_diagram_requirement_count"
        ]
        == 1
    )
    assert payload["analysis_final_completion_blocker_kind_completion_gate_count"] == 4
    assert (
        payload[
            "analysis_final_completion_blocker_kind_consistency_blocker_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_consistency_kind_count"
        ]
        == 3
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_consistency_kind_total"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_consistency_total_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_consistency_unique_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_all_have_kind_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_row_count"
        ]
        == 3
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_kind_count"
        ]
        == 3
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_blocker_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_code_reference_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_missing_artifact_reference_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_unique_missing_artifact_count"
        ]
        == 5
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_blocker_count_matched_count"
        ]
        == 3
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_codes_matched_count"
        ]
        == 3
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_missing_artifacts_matched_count"
        ]
        == 3
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_gate_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_blocker_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_code_reference_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_missing_artifact_reference_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_unique_missing_artifact_count"
        ]
        == 5
    )
    assert (
        payload[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_retained_evidence_reference_count"
            ]
            == 10
    )
    assert (
        payload[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_blocker_count_matched_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_codes_matched_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_missing_artifacts_matched_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_retained_evidence_matched_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert payload["analysis_retained_evidence_count"] == 10
    assert payload["analysis_retained_evidence_id_count"] == 8
    assert payload["analysis_retained_evidence_completion_claimed_count"] == 0
    assert (
        payload[
            "analysis_retained_evidence_release_grade_speedup_claimed_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_retained_evidence_real_graphics_backend_framebuffer_verified_count"
        ]
        == 0
    )
    assert payload["analysis_retained_evidence_screenshot_verified_count"] == 0
    assert payload["analysis_retained_evidence_all_non_claimed_count"] == 1
    assert payload["analysis_retained_evidence_non_claim_consistency_entry_count"] == 10
    assert (
        payload["analysis_retained_evidence_non_claim_consistency_evidence_id_count"]
        == 8
    )
    assert (
        payload[
            "analysis_retained_evidence_non_claim_consistency_completion_claimed_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_retained_evidence_non_claim_consistency_release_grade_speedup_claimed_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_retained_evidence_non_claim_consistency_real_backend_claimed_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_retained_evidence_non_claim_consistency_screenshot_verified_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_retained_evidence_non_claim_consistency_all_non_claimed_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_retained_evidence_non_claim_consistency_entry_top_level_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_retained_evidence_non_claim_consistency_id_top_level_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_retained_evidence_non_claim_consistency_completion_top_level_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_retained_evidence_non_claim_consistency_release_speedup_top_level_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_retained_evidence_non_claim_consistency_real_backend_top_level_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_retained_evidence_non_claim_consistency_screenshot_top_level_matched_count"
        ]
        == 1
    )
    assert (
        payload["analysis_retained_evidence_non_claim_consistency_matched_count"]
        == 1
    )
    assert payload["analysis_retained_evidence_artifact_file_consistency_entry_count"] == 10
    assert (
        payload[
            "analysis_retained_evidence_artifact_file_consistency_artifact_evidence_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_retained_evidence_artifact_file_consistency_non_artifact_evidence_count"
        ]
        == 8
    )
    assert (
        payload[
            "analysis_retained_evidence_artifact_file_consistency_file_reference_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_retained_evidence_artifact_file_consistency_unique_file_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_retained_evidence_artifact_file_consistency_raw_file_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_retained_evidence_artifact_file_consistency_analysis_file_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_retained_evidence_artifact_file_consistency_host_file_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_retained_evidence_artifact_file_consistency_complete_raw_analysis_host_group_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_retained_evidence_artifact_file_consistency_incomplete_group_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_retained_evidence_artifact_file_consistency_reference_count_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_retained_evidence_artifact_file_consistency_file_type_counts_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_retained_evidence_artifact_file_consistency_all_groups_complete_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_retained_evidence_artifact_file_consistency_all_files_unique_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_retained_evidence_artifact_file_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_linked_blocker_count"
        ]
        == 5
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_unlinked_blocker_count"
        ]
        == 2
    )
    assert (
        payload["analysis_final_completion_blocker_evidence_reference_count"]
        == 10
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_link_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_label_present_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_code_present_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_missing_artifact_present_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_required_evidence_present_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_current_evidence_present_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_row_count"
        ]
        == 3
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_blocker_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_linked_count"
        ]
        == 5
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_unlinked_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_reference_count"
        ]
        == 10
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_id_count"
        ]
        == 8
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_non_claimed_link_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert payload["analysis_final_completion_missing_artifact_reference_count"] == 7
    assert payload["analysis_final_completion_missing_artifact_unique_count"] == 5
    assert (
        payload[
            "analysis_final_completion_missing_artifact_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_row_count"
        ]
        == 5
    )
    assert (
        payload[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_unique_count"
        ]
        == 5
    )
    assert (
        payload[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_blocker_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_code_reference_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_label_reference_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_blocker_count_matched_count"
        ]
        == 5
    )
    assert (
        payload[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_codes_matched_count"
        ]
        == 5
    )
    assert (
        payload[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_labels_matched_count"
        ]
        == 5
    )
    assert (
        payload[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_field_summary_row_count"
        ]
        == 3
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_field_all_present_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_field_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_row_count"
        ]
        == 3
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_blocker_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_missing_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_required_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_current_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_all_present_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_blocker_count_matched_count"
        ]
        == 3
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_missing_matched_count"
        ]
        == 3
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_required_matched_count"
        ]
        == 3
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_current_matched_count"
        ]
        == 3
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_all_present_matched_count"
        ]
        == 3
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_gate_blocker_consistency_checked_gate_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_gate_blocker_consistency_mismatched_gate_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_final_completion_gate_blocker_count_matched_gate_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_gate_blocker_codes_matched_gate_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_gate_blocker_consistency_matched_count"
        ]
        == 1
    )
    assert payload["analysis_final_completion_required_check_count"] == 3
    assert payload["analysis_final_completion_required_check_passed_count"] == 1
    assert payload["analysis_final_completion_required_check_failed_count"] == 2
    assert (
        payload[
            "analysis_final_completion_required_check_mismatched_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_final_completion_required_check_final_ready_matched_count"
        ]
        == 1
    )
    assert (
        payload["analysis_final_completion_required_check_all_matched_count"]
        == 0
    )
    assert (
        payload[
            "analysis_final_completion_required_check_consistency_matched_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_required_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_registered_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_missing_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_metadata_complete_count"
        ]
        == 7
    )
    assert (
        payload[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_metadata_incomplete_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_metadata_blocker_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_gate_passed_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_gate_blocker_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_signed_fixture_consistency_blocker_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_final_completion_signed_fixture_consistency_final_blocker_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_final_completion_signed_fixture_consistency_unsigned_non_claim_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_final_completion_signed_fixture_consistency_source_table_metadata_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_final_completion_signed_fixture_consistency_source_candidate_evidence_available_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_final_completion_signed_fixture_consistency_source_candidate_not_unique_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_final_completion_signed_fixture_consistency_source_candidate_replay_all_valid_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_final_completion_signed_fixture_consistency_source_candidate_matching_candidate_count_total"
        ]
        == 32
    )
    assert (
        payload[
            "analysis_final_completion_signed_fixture_consistency_source_candidate_unique_sign_pattern_count_total"
        ]
        == 20
    )
    assert (
        payload[
            "analysis_final_completion_signed_fixture_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_final_completion_signed_fixture_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_non_diagram_requirement_consistency_requirement_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_final_completion_non_diagram_requirement_consistency_open_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_non_diagram_requirement_consistency_blocker_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_non_diagram_requirement_consistency_retained_evidence_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_final_completion_non_diagram_requirement_consistency_retained_evidence_id_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_final_completion_non_diagram_requirement_consistency_retained_evidence_reference_top_level_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_non_diagram_requirement_consistency_retained_evidence_id_top_level_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_non_diagram_requirement_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_final_completion_non_diagram_requirement_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_non_claim_gate_consistency_field_count"
        ]
        == 4
    )
    assert (
        payload[
            "analysis_final_completion_non_claim_gate_consistency_false_count"
        ]
        == 4
    )
    assert (
        payload[
            "analysis_final_completion_non_claim_gate_consistency_gate_count"
        ]
        == 4
    )
    assert (
        payload[
            "analysis_final_completion_non_claim_gate_consistency_blocker_count"
        ]
        == 4
    )
    assert (
        payload[
            "analysis_final_completion_non_claim_gate_consistency_missing_artifact_count"
        ]
        == 4
    )
    assert (
        payload[
            "analysis_final_completion_non_claim_gate_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_final_completion_completion_gate_evidence_consistency_gate_count"
        ]
        == 4
    )
    assert (
        payload[
            "analysis_final_completion_completion_gate_evidence_consistency_gate_check_count"
        ]
        == 4
    )
    assert (
        payload[
            "analysis_final_completion_completion_gate_evidence_consistency_blocker_count"
        ]
        == 4
    )
    assert (
        payload[
            "analysis_final_completion_completion_gate_evidence_consistency_failed_gate_count"
        ]
        == 4
    )
    assert (
        payload[
            "analysis_final_completion_completion_gate_evidence_consistency_top_level_false_count"
        ]
        == 4
    )
    assert (
        payload[
            "analysis_final_completion_completion_gate_evidence_consistency_code_matched_count"
        ]
        == 4
    )
    assert (
        payload[
            "analysis_final_completion_completion_gate_evidence_consistency_required_evidence_matched_count"
        ]
        == 4
    )
    assert (
        payload[
            "analysis_final_completion_completion_gate_evidence_consistency_current_evidence_matched_count"
        ]
        == 4
    )
    assert (
        payload[
            "analysis_final_completion_completion_gate_evidence_consistency_missing_artifact_matched_count"
        ]
        == 4
    )
    assert (
        payload[
            "analysis_final_completion_completion_gate_evidence_consistency_missing_artifact_id_matched_count"
        ]
        == 4
    )
    assert (
        payload[
            "analysis_final_completion_completion_gate_evidence_consistency_retained_evidence_count"
        ]
        == 8
    )
    assert (
        payload[
            "analysis_final_completion_completion_gate_evidence_consistency_retained_evidence_id_count"
        ]
        == 8
    )
    assert (
        payload[
            "analysis_final_completion_completion_gate_evidence_consistency_retained_evidence_ids_matched_count"
        ]
        == 4
    )
    assert (
        payload[
            "analysis_final_completion_completion_gate_evidence_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_final_completion_completion_gate_evidence_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_final_completion_non_claim_gate_consistency_matched_count"
        ]
        == 1
    )
    assert payload["analysis_required_check_count"] == 3
    assert payload["analysis_passed_check_count"] == 1
    assert payload["analysis_failed_check_count"] == 2
    json.dumps(payload, allow_nan=False)


def _validate_table_source_metadata_report(*, ready: bool = True) -> dict:
    issue_count = 0 if ready else 1
    blocker_count = 0 if ready else 1
    return {
        "record_count": 2,
        "valid": ready,
        "issues": []
        if ready
        else [
            {
                "path": "$[1].convention",
                "message": "expected convention 'iroll-test', got 'source-table'",
            }
        ],
        "source_metadata_summary": {
            "claim_scope": "table_source_metadata_scan",
            "expected_convention": "iroll-test",
            "record_count": 2,
            "source_count": 2,
            "source_value_counts": {
                "Knot Atlas": 1,
                "KnotInfo": 1,
            },
            "source_value_rows": {
                "Knot Atlas": ["$[0]"],
                "KnotInfo": ["$[1]"],
            },
            "source_url_count": 2,
            "source_url_scheme_counts": {"https": 2},
            "source_url_scheme_rows": {"https": ["$[0]", "$[1]"]},
            "source_url_domain_counts": {
                "katlas.org": 1,
                "knotinfo.math.indiana.edu": 1,
            },
            "source_url_domain_rows": {
                "katlas.org": ["$[0]"],
                "knotinfo.math.indiana.edu": ["$[1]"],
            },
            "valid_source_url_count": 2,
            "invalid_source_url_count": 0,
            "source_url_missing_scheme_count": 0,
            "source_url_missing_domain_count": 0,
            "missing_source_count": 0,
            "missing_source_url_count": 0,
            "source_url_without_source_count": 0,
            "all_records_have_source": True,
            "all_source_records_have_source_url": True,
            "all_source_urls_have_source": True,
            "all_source_urls_are_http_or_https": True,
            "known_limitations_count": 1,
            "known_limitations_rows": ["$[0]"],
            "convention_metadata_without_name_count": 1,
            "convention_metadata_without_name_rows": ["$[0]"],
            "convention_mismatch_count": blocker_count,
            "convention_mismatch_rows": []
            if ready
            else [
                {
                    "row": "$[1]",
                    "path": "$[1].convention",
                    "expected_convention": "iroll-test",
                    "observed_convention": "source-table",
                }
            ],
            "all_conventions_match_expected": ready,
            "provenance_review_ready": ready,
            "provenance_blocker_count": blocker_count,
            "provenance_blocker_codes": [] if ready else ["convention_mismatch"],
            "summary_consistency": {
                "matched": True,
                "source_url_issue_code_total": 0,
                "source_completeness_row_count": 2,
                "source_completeness_row_count_matched": True,
                "source_completeness_source_count_matched": True,
                "source_completeness_source_url_count_matched": True,
                "source_completeness_invalid_url_count_matched": True,
            },
            "provenance_blocker_summary_consistency": {"matched": True},
            "table_correctness_certified": False,
            "external_source_verified": False,
        },
    }

def test_imgui_payloads_preserve_validation_pack_known_limitations_mismatch() -> None:
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "required_diagram_fixture_metadata_complete": True,
        "signed_diagram_fixture_registration_complete": False,
        "open_non_diagram_requirement_count": 1,
        "final_completion_ready": False,
        "fixture_known_limitations_summary": {
            "claim_scope": "validation_pack_fixture_known_limitations_summary",
            "fixture_row_count": 7,
            "known_limitations_available_count": 6,
            "known_limitations_unavailable_count": 1,
            "known_limitations_note_count_total": 31,
            "known_limitations_requirement_satisfied_count": 6,
            "known_limitations_requirement_satisfied_count_matched": False,
            "known_limitations_unavailable_count_matched": False,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    assert summary["validation_pack_fixture_known_limitations_fixture_row_count"] == 7
    assert summary["validation_pack_fixture_known_limitations_available_count"] == 6
    assert summary["validation_pack_fixture_known_limitations_unavailable_count"] == 1
    assert summary["validation_pack_fixture_known_limitations_note_count_total"] == 31
    assert (
        summary[
            "validation_pack_fixture_known_limitations_requirement_satisfied_count"
        ]
        == 6
    )
    assert (
        summary[
            "validation_pack_fixture_known_limitations_requirement_satisfied_count_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "validation_pack_fixture_known_limitations_unavailable_count_matched_count"
        ]
        == 0
    )
    assert summary["validation_pack_fixture_known_limitations_matched_count"] == 0
    assert (
        "fixture_known_limitations=rows=7; available=6; unavailable=1; "
        "notes=31; requirement_satisfied=6; matched=false"
    ) in summary["notes"]

    payload = imgui_analysis_payload_from_acceptance_reports([report])
    assert (
        payload["analysis_validation_pack_fixture_known_limitations_fixture_row_count"]
        == 7
    )
    assert (
        payload["analysis_validation_pack_fixture_known_limitations_available_count"]
        == 6
    )
    assert (
        payload[
            "analysis_validation_pack_fixture_known_limitations_unavailable_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_validation_pack_fixture_known_limitations_requirement_satisfied_count"
        ]
        == 6
    )
    assert (
        payload["analysis_validation_pack_fixture_known_limitations_matched_count"]
        == 0
    )
    assert "matched=false" in payload["analysis_summaries"][0]["notes"]

    host_payload = imgui_host_payload_from_acceptance_reports([report])
    host_analysis = host_payload["analysis"]
    assert (
        host_analysis[
            "analysis_validation_pack_fixture_known_limitations_available_count"
        ]
        == 6
    )
    assert (
        host_analysis[
            "analysis_validation_pack_fixture_known_limitations_matched_count"
        ]
        == 0
    )
    assert "matched=false" in host_analysis["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_payloads_preserve_validation_pack_fixture_source_url_shape_mismatch() -> None:
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "required_diagram_fixture_metadata_complete": True,
        "signed_diagram_fixture_registration_complete": False,
        "open_non_diagram_requirement_count": 1,
        "final_completion_ready": False,
        "fixture_source_url_shape_summary": {
            "claim_scope": "validation_pack_fixture_source_url_shape_summary",
            "fixture_row_count": 7,
            "source_url_row_count": 3,
            "external_source_url_row_count": 3,
            "source_url_required_count": 3,
            "source_url_http_or_https_count": 2,
            "source_url_requirement_satisfied_count": 2,
            "source_url_scheme_counts": {"https": 2, "ftp": 1},
            "source_url_domain_counts": {
                "katlas.org": 1,
                "knotinfo.math.indiana.edu": 1,
            },
            "source_url_scheme_count_total": 3,
            "source_url_domain_count_total": 2,
            "source_url_scheme_count_matched": True,
            "source_url_domain_count_matched": False,
            "source_url_http_or_https_count_matched": False,
            "source_url_requirement_satisfied_count_matched": False,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports([report])

    assert summary["validation_pack_fixture_source_url_fixture_row_count"] == 7
    assert summary["validation_pack_fixture_source_url_row_count"] == 3
    assert summary["validation_pack_fixture_source_url_external_row_count"] == 3
    assert summary["validation_pack_fixture_source_url_required_count"] == 3
    assert summary["validation_pack_fixture_source_url_http_or_https_count"] == 2
    assert (
        summary["validation_pack_fixture_source_url_requirement_satisfied_count"]
        == 2
    )
    assert summary["validation_pack_fixture_source_url_scheme_count_total"] == 3
    assert summary["validation_pack_fixture_source_url_domain_count_total"] == 2
    assert (
        summary[
            "validation_pack_fixture_source_url_scheme_count_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "validation_pack_fixture_source_url_domain_count_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "validation_pack_fixture_source_url_http_or_https_count_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "validation_pack_fixture_source_url_requirement_satisfied_count_matched_count"
        ]
        == 0
    )
    assert summary["validation_pack_fixture_source_url_shape_matched_count"] == 0
    assert (
        "fixture_source_urls=rows=3; required=3; http_or_https=2; "
        "requirement_satisfied=2; schemes=3; domains=2; matched=false"
    ) in summary["notes"]

    assert payload["analysis_validation_pack_fixture_source_url_row_count"] == 3
    assert (
        payload[
            "analysis_validation_pack_fixture_source_url_http_or_https_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_validation_pack_fixture_source_url_requirement_satisfied_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_validation_pack_fixture_source_url_shape_matched_count"
        ]
        == 0
    )
    assert "matched=false" in payload["analysis_summaries"][0]["notes"]

    host_analysis = host_payload["analysis"]
    assert host_analysis["analysis_validation_pack_fixture_source_url_row_count"] == 3
    assert (
        host_analysis[
            "analysis_validation_pack_fixture_source_url_http_or_https_count"
        ]
        == 2
    )
    assert (
        host_analysis[
            "analysis_validation_pack_fixture_source_url_requirement_satisfied_count"
        ]
        == 2
    )
    assert (
        host_analysis[
            "analysis_validation_pack_fixture_source_url_shape_matched_count"
        ]
        == 0
    )
    assert "matched=false" in host_analysis["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_payloads_preserve_validation_pack_retained_artifact_file_consistency_mismatch() -> None:
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "required_diagram_fixture_metadata_complete": True,
        "signed_diagram_fixture_registration_complete": False,
        "open_non_diagram_requirement_count": 1,
        "final_completion_ready": False,
        "retained_evidence_artifact_file_consistency": {
            "claim_scope": "validation_pack_retained_evidence_artifact_file_consistency",
            "entry_count": 5,
            "artifact_evidence_count": 3,
            "non_artifact_evidence_count": 2,
            "artifact_file_reference_count": 8,
            "unique_artifact_file_count": 7,
            "raw_file_count": 3,
            "analysis_file_count": 2,
            "host_file_count": 3,
            "complete_raw_analysis_host_group_count": 2,
            "incomplete_artifact_group_count": 1,
            "artifact_file_reference_count_matches_groups": False,
            "raw_analysis_host_file_counts_matched": False,
            "all_artifact_evidence_groups_complete": False,
            "all_artifact_files_unique": False,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert summary["retained_evidence_artifact_file_consistency_entry_count"] == 5
    assert (
        summary[
            "retained_evidence_artifact_file_consistency_file_reference_count"
        ]
        == 8
    )
    assert summary["retained_evidence_artifact_file_consistency_unique_file_count"] == 7
    assert summary["retained_evidence_artifact_file_consistency_raw_file_count"] == 3
    assert summary["retained_evidence_artifact_file_consistency_analysis_file_count"] == 2
    assert summary["retained_evidence_artifact_file_consistency_host_file_count"] == 3
    assert (
        summary[
            "retained_evidence_artifact_file_consistency_complete_raw_analysis_host_group_count"
        ]
        == 2
    )
    assert (
        summary[
            "retained_evidence_artifact_file_consistency_incomplete_group_count"
        ]
        == 1
    )
    assert (
        summary[
            "retained_evidence_artifact_file_consistency_reference_count_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "retained_evidence_artifact_file_consistency_file_type_counts_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "retained_evidence_artifact_file_consistency_all_groups_complete_count"
        ]
        == 0
    )
    assert (
        summary[
            "retained_evidence_artifact_file_consistency_all_files_unique_count"
        ]
        == 0
    )
    assert summary["retained_evidence_artifact_file_consistency_matched_count"] == 0
    assert (
        "retained_evidence_artifact_files=entries=5; artifact_entries=3; "
        "non_artifact=2; refs=8; unique=7"
    ) in summary["notes"]
    assert "raw=3; analysis=2; host=3" in summary["notes"]
    assert "complete_groups=2; incomplete_groups=1" in summary["notes"]
    assert (
        "refs_matched=false; file_types_matched=false; groups_complete=false; "
        "files_unique=false; matched=false"
    ) in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert (
            root[
                "analysis_retained_evidence_artifact_file_consistency_file_reference_count"
            ]
            == 8
        )
        assert (
            root[
                "analysis_retained_evidence_artifact_file_consistency_unique_file_count"
            ]
            == 7
        )
        assert (
            root[
                "analysis_retained_evidence_artifact_file_consistency_reference_count_matched_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_retained_evidence_artifact_file_consistency_file_type_counts_matched_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_retained_evidence_artifact_file_consistency_all_groups_complete_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_retained_evidence_artifact_file_consistency_all_files_unique_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_retained_evidence_artifact_file_consistency_matched_count"
            ]
            == 0
        )
        assert "matched=false" in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_payloads_preserve_validation_pack_retained_evidence_non_claim_consistency_mismatch() -> None:
    note_token = (
        "retained_evidence_non_claim=entries=5; ids=3; completion=1; "
        "release_speedup=1; real_backend=1; screenshot=1; matched=false"
    )
    assert note_token == "retained_evidence_non_claim=entries=5; ids=3; completion=1; release_speedup=1; real_backend=1; screenshot=1; matched=false"  # noqa: E501
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "retained_evidence_non_claim_consistency": {
            "claim_scope": "validation_pack_retained_evidence_non_claim_consistency",
            "entry_count": 5,
            "evidence_id_count": 3,
            "completion_claimed_count": 1,
            "release_grade_speedup_claimed_count": 1,
            "real_graphics_backend_framebuffer_verified_count": 1,
            "screenshot_verified_count": 1,
            "all_non_claimed": False,
            "entry_count_matches_top_level": False,
            "evidence_id_count_matches_top_level": False,
            "completion_claimed_count_matches_top_level": False,
            "release_grade_speedup_claimed_count_matches_top_level": False,
            "real_graphics_backend_framebuffer_verified_count_matches_top_level": False,
            "screenshot_verified_count_matches_top_level": False,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert summary["retained_evidence_non_claim_consistency_entry_count"] == 5
    assert summary["retained_evidence_non_claim_consistency_evidence_id_count"] == 3
    assert (
        summary[
            "retained_evidence_non_claim_consistency_completion_claimed_count"
        ]
        == 1
    )
    assert (
        summary[
            "retained_evidence_non_claim_consistency_release_grade_speedup_claimed_count"
        ]
        == 1
    )
    assert (
        summary[
            "retained_evidence_non_claim_consistency_real_backend_claimed_count"
        ]
        == 1
    )
    assert (
        summary[
            "retained_evidence_non_claim_consistency_screenshot_verified_count"
        ]
        == 1
    )
    assert summary["retained_evidence_non_claim_consistency_all_non_claimed_count"] == 0
    assert (
        summary[
            "retained_evidence_non_claim_consistency_entry_top_level_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "retained_evidence_non_claim_consistency_id_top_level_matched_count"
        ]
        == 0
    )
    assert (
        summary["retained_evidence_non_claim_consistency_matched_count"]
        == 0
    )
    assert note_token in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert root["analysis_retained_evidence_non_claim_consistency_entry_count"] == 5
        assert (
            root["analysis_retained_evidence_non_claim_consistency_evidence_id_count"]
            == 3
        )
        assert (
            root[
                "analysis_retained_evidence_non_claim_consistency_completion_claimed_count"
            ]
            == 1
        )
        assert (
            root[
                "analysis_retained_evidence_non_claim_consistency_all_non_claimed_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_retained_evidence_non_claim_consistency_matched_count"
            ]
            == 0
        )
        assert note_token in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_payloads_preserve_validation_pack_missing_artifact_summary_consistency_mismatch() -> None:
    note_token = (
        "missing_artifact_summary=refs=8; unique=6; rows=7; "
        "refs_matched=false; rows_matched=false; matched=false"
    )
    assert note_token == "missing_artifact_summary=refs=8; unique=6; rows=7; refs_matched=false; rows_matched=false; matched=false"  # noqa: E501
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "required_diagram_fixture_metadata_complete": True,
        "signed_diagram_fixture_registration_complete": False,
        "open_non_diagram_requirement_count": 1,
        "final_completion_ready": False,
        "final_completion_missing_artifact_summary_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_"
                "missing_artifact_summary_consistency"
            ),
            "reference_count": 8,
            "unique_missing_artifact_count": 6,
            "summary_row_count": 7,
            "references_match_blocker_count": False,
            "summary_row_count_matches_unique_missing_artifacts": False,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert summary["final_completion_missing_artifact_reference_count"] == 8
    assert summary["final_completion_missing_artifact_unique_count"] == 6
    assert summary["final_completion_missing_artifact_summary_row_count"] == 7
    assert (
        summary[
            "final_completion_missing_artifact_reference_count_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "final_completion_missing_artifact_summary_row_count_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "final_completion_missing_artifact_summary_consistency_matched_count"
        ]
        == 0
    )
    assert note_token in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert root["analysis_final_completion_missing_artifact_reference_count"] == 8
        assert root["analysis_final_completion_missing_artifact_unique_count"] == 6
        assert (
            root["analysis_final_completion_missing_artifact_summary_row_count"]
            == 7
        )
        assert (
            root[
                "analysis_final_completion_missing_artifact_reference_count_matched_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_missing_artifact_summary_row_count_matched_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_missing_artifact_summary_consistency_matched_count"
            ]
            == 0
        )
        assert note_token in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_payloads_preserve_validation_pack_missing_artifact_summary_detail_mismatch() -> None:
    note_token = (
        "missing_artifact_summary_detail=rows=7; unique=7; blockers=9; "
        "codes=8; labels=8; count_matched=6; codes_matched=5; "
        "labels_matched=4; mismatched=2; matched=false"
    )
    assert note_token == "missing_artifact_summary_detail=rows=7; unique=7; blockers=9; codes=8; labels=8; count_matched=6; codes_matched=5; labels_matched=4; mismatched=2; matched=false"  # noqa: E501
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "required_diagram_fixture_metadata_complete": True,
        "signed_diagram_fixture_registration_complete": False,
        "open_non_diagram_requirement_count": 1,
        "final_completion_ready": False,
        "final_completion_missing_artifact_summary_detail_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_"
                "missing_artifact_summary_detail_consistency"
            ),
            "summary_row_count": 7,
            "unique_missing_artifact_count": 7,
            "blocker_count": 9,
            "blocker_code_reference_count": 8,
            "blocker_label_reference_count": 8,
            "blocker_count_matched_count": 6,
            "blocker_codes_matched_count": 5,
            "blocker_labels_matched_count": 4,
            "mismatched_summary_row_count": 2,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert (
        summary[
            "final_completion_missing_artifact_summary_detail_consistency_row_count"
        ]
        == 7
    )
    assert (
        summary[
            "final_completion_missing_artifact_summary_detail_consistency_label_reference_count"
        ]
        == 8
    )
    assert (
        summary[
            "final_completion_missing_artifact_summary_detail_consistency_blocker_count_matched_count"
        ]
        == 6
    )
    assert (
        summary[
            "final_completion_missing_artifact_summary_detail_consistency_codes_matched_count"
        ]
        == 5
    )
    assert (
        summary[
            "final_completion_missing_artifact_summary_detail_consistency_labels_matched_count"
        ]
        == 4
    )
    assert (
        summary[
            "final_completion_missing_artifact_summary_detail_consistency_mismatched_count"
        ]
        == 2
    )
    assert (
        summary[
            "final_completion_missing_artifact_summary_detail_consistency_matched_count"
        ]
        == 0
    )
    assert note_token in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert (
            root[
                "analysis_final_completion_missing_artifact_summary_detail_consistency_mismatched_count"
            ]
            == 2
        )
        assert (
            root[
                "analysis_final_completion_missing_artifact_summary_detail_consistency_matched_count"
            ]
            == 0
        )
        assert note_token in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_blocker_evidence_link_consistency_mismatch() -> None:
    note_token = (
        "blocker_evidence_links=linked=2; unlinked=7; evidence_refs=3; "
        "refs_matched=false; ids_matched=false; non_claim_matched=false; "
        "labels=8; codes=7; missing=6; required=5; current=4; matched=false"
    )
    assert note_token == "blocker_evidence_links=linked=2; unlinked=7; evidence_refs=3; refs_matched=false; ids_matched=false; non_claim_matched=false; labels=8; codes=7; missing=6; required=5; current=4; matched=false"  # noqa: E501
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "required_diagram_fixture_metadata_complete": True,
        "signed_diagram_fixture_registration_complete": False,
        "open_non_diagram_requirement_count": 1,
        "final_completion_ready": False,
        "final_completion_blocker_evidence_link_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_"
                "blocker_evidence_link_consistency"
            ),
            "linked_blocker_count": 2,
            "unlinked_blocker_count": 7,
            "retained_evidence_reference_count": 3,
            "retained_evidence_reference_count_matches_top_level": False,
            "retained_evidence_id_count_matches_top_level": False,
            "retained_evidence_non_claim_consistency_matches_top_level": False,
            "all_blockers_have_machine_audit_fields": False,
            "blocker_label_present_count": 8,
            "blocker_code_present_count": 7,
            "missing_artifact_present_count": 6,
            "required_evidence_present_count": 5,
            "current_evidence_present_count": 4,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert summary["final_completion_blocker_evidence_linked_blocker_count"] == 2
    assert summary["final_completion_blocker_evidence_unlinked_blocker_count"] == 7
    assert summary["final_completion_blocker_evidence_reference_count"] == 3
    assert (
        summary[
            "final_completion_blocker_evidence_reference_count_matched_count"
        ]
        == 0
    )
    assert (
        summary["final_completion_blocker_evidence_id_count_matched_count"]
        == 0
    )
    assert (
        summary["final_completion_blocker_evidence_non_claim_matched_count"]
        == 0
    )
    assert (
        summary[
            "final_completion_blocker_evidence_machine_audit_fields_present_count"
        ]
        == 0
    )
    assert summary["final_completion_blocker_evidence_label_present_count"] == 8
    assert summary["final_completion_blocker_evidence_code_present_count"] == 7
    assert (
        summary[
            "final_completion_blocker_evidence_missing_artifact_present_count"
        ]
        == 6
    )
    assert (
        summary[
            "final_completion_blocker_evidence_required_evidence_present_count"
        ]
        == 5
    )
    assert (
        summary["final_completion_blocker_evidence_current_evidence_present_count"]
        == 4
    )
    assert (
        summary["final_completion_blocker_evidence_link_consistency_matched_count"]
        == 0
    )
    assert note_token in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert root["analysis_final_completion_blocker_evidence_linked_blocker_count"] == 2
        assert (
            root["analysis_final_completion_blocker_evidence_reference_count"]
            == 3
        )
        assert (
            root[
                "analysis_final_completion_blocker_evidence_reference_count_matched_count"
            ]
            == 0
        )
        assert (
            root["analysis_final_completion_blocker_evidence_id_count_matched_count"]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_blocker_evidence_non_claim_matched_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_blocker_evidence_machine_audit_fields_present_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_blocker_evidence_link_consistency_matched_count"
            ]
            == 0
        )
        assert note_token in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_blocker_evidence_link_kind_summary_detail_mismatch() -> None:
    note_token = (
        "blocker_evidence_link_kind_detail=rows=3; blockers=9; linked=2; "
        "unlinked=7; refs=3; ids=2; non_claimed_links=8; "
        "blocker_matched=2; linked_matched=2; unlinked_matched=1; "
        "refs_matched=1; ids_matched=1; non_claim_matched=0; "
        "mismatched=2; matched=false"
    )
    assert note_token == "blocker_evidence_link_kind_detail=rows=3; blockers=9; linked=2; unlinked=7; refs=3; ids=2; non_claimed_links=8; blocker_matched=2; linked_matched=2; unlinked_matched=1; refs_matched=1; ids_matched=1; non_claim_matched=0; mismatched=2; matched=false"  # noqa: E501
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_"
                "blocker_evidence_link_kind_summary_detail_consistency"
            ),
            "summary_row_count": 3,
            "blocker_count": 9,
            "linked_blocker_count": 2,
            "unlinked_blocker_count": 7,
            "retained_evidence_reference_count": 3,
            "retained_evidence_id_count": 2,
            "retained_evidence_non_claimed_link_count": 8,
            "blocker_count_matched_count": 2,
            "linked_blocker_count_matched_count": 2,
            "unlinked_blocker_count_matched_count": 1,
            "retained_evidence_reference_count_matched_count": 1,
            "retained_evidence_ids_matched_count": 1,
            "retained_evidence_non_claim_counts_matched_count": 0,
            "mismatched_summary_row_count": 2,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert (
        summary[
            "final_completion_blocker_evidence_link_kind_summary_detail_consistency_row_count"
        ]
        == 3
    )
    assert (
        summary[
            "final_completion_blocker_evidence_link_kind_summary_detail_consistency_linked_count"
        ]
        == 2
    )
    assert (
        summary[
            "final_completion_blocker_evidence_link_kind_summary_detail_consistency_unlinked_count"
        ]
        == 7
    )
    assert (
        summary[
            "final_completion_blocker_evidence_link_kind_summary_detail_consistency_reference_count"
        ]
        == 3
    )
    assert (
        summary[
            "final_completion_blocker_evidence_link_kind_summary_detail_consistency_id_count"
        ]
        == 2
    )
    assert (
        summary[
            "final_completion_blocker_evidence_link_kind_summary_detail_consistency_non_claimed_link_count"
        ]
        == 8
    )
    assert (
        summary[
            "final_completion_blocker_evidence_link_kind_summary_detail_consistency_non_claim_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "final_completion_blocker_evidence_link_kind_summary_detail_consistency_mismatched_count"
        ]
        == 2
    )
    assert (
        summary[
            "final_completion_blocker_evidence_link_kind_summary_detail_consistency_matched_count"
        ]
        == 0
    )
    assert note_token in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert (
            root[
                "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_linked_count"
            ]
            == 2
        )
        assert (
            root[
                "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_id_count"
            ]
            == 2
        )
        assert (
            root[
                "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_non_claim_matched_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_mismatched_count"
            ]
            == 2
        )
        assert (
            root[
                "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_matched_count"
            ]
            == 0
        )
        assert note_token in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_blocker_evidence_field_consistency_mismatch() -> None:
    note_token = (
        "blocker_evidence_fields=summary_rows=3; missing_artifact=8; "
        "required=7; current=6; all_present=5; matched=false"
    )
    assert note_token == "blocker_evidence_fields=summary_rows=3; missing_artifact=8; required=7; current=6; all_present=5; matched=false"  # noqa: E501
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "final_completion_blocker_evidence_field_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_"
                "blocker_evidence_field_consistency"
            ),
            "summary_row_count": 3,
            "missing_artifact_present_count": 8,
            "required_evidence_present_count": 7,
            "current_evidence_present_count": 6,
            "all_evidence_fields_present_count": 5,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert summary["final_completion_blocker_evidence_field_summary_row_count"] == 3
    assert (
        summary[
            "final_completion_blocker_evidence_field_missing_artifact_present_count"
        ]
        == 8
    )
    assert (
        summary[
            "final_completion_blocker_evidence_field_required_evidence_present_count"
        ]
        == 7
    )
    assert (
        summary[
            "final_completion_blocker_evidence_field_current_evidence_present_count"
        ]
        == 6
    )
    assert summary["final_completion_blocker_evidence_field_all_present_count"] == 5
    assert (
        summary["final_completion_blocker_evidence_field_consistency_matched_count"]
        == 0
    )
    assert note_token in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert (
            root["analysis_final_completion_blocker_evidence_field_summary_row_count"]
            == 3
        )
        assert (
            root[
                "analysis_final_completion_blocker_evidence_field_required_evidence_present_count"
            ]
            == 7
        )
        assert (
            root[
                "analysis_final_completion_blocker_evidence_field_current_evidence_present_count"
            ]
            == 6
        )
        assert (
            root[
                "analysis_final_completion_blocker_evidence_field_consistency_matched_count"
            ]
            == 0
        )
        assert note_token in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_blocker_evidence_field_detail_mismatch() -> None:
    note_token = (
        "blocker_evidence_field_summary_detail=rows=3; blockers=9; "
        "missing_artifact=8; required=7; current=6; all_present=5; "
        "count_matched=2; missing_matched=2; required_matched=1; "
        "current_matched=1; all_present_matched=0; mismatched=2; "
        "matched=false"
    )
    assert note_token == "blocker_evidence_field_summary_detail=rows=3; blockers=9; missing_artifact=8; required=7; current=6; all_present=5; count_matched=2; missing_matched=2; required_matched=1; current_matched=1; all_present_matched=0; mismatched=2; matched=false"  # noqa: E501
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "required_diagram_fixture_metadata_complete": True,
        "signed_diagram_fixture_registration_complete": False,
        "open_non_diagram_requirement_count": 1,
        "final_completion_ready": False,
        "final_completion_blocker_evidence_field_summary_detail_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_"
                "blocker_evidence_field_summary_detail_consistency"
            ),
            "summary_row_count": 3,
            "blocker_count": 9,
            "missing_artifact_present_count": 8,
            "required_evidence_present_count": 7,
            "current_evidence_present_count": 6,
            "all_evidence_fields_present_count": 5,
            "blocker_count_matched_count": 2,
            "missing_artifact_present_count_matched_count": 2,
            "required_evidence_present_count_matched_count": 1,
            "current_evidence_present_count_matched_count": 1,
            "all_evidence_fields_present_count_matched_count": 0,
            "mismatched_summary_row_count": 2,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert (
        summary[
            "final_completion_blocker_evidence_field_summary_detail_consistency_row_count"
        ]
        == 3
    )
    assert (
        summary[
            "final_completion_blocker_evidence_field_summary_detail_consistency_missing_count"
        ]
        == 8
    )
    assert (
        summary[
            "final_completion_blocker_evidence_field_summary_detail_consistency_required_count"
        ]
        == 7
    )
    assert (
        summary[
            "final_completion_blocker_evidence_field_summary_detail_consistency_current_count"
        ]
        == 6
    )
    assert (
        summary[
            "final_completion_blocker_evidence_field_summary_detail_consistency_all_present_count"
        ]
        == 5
    )
    assert (
        summary[
            "final_completion_blocker_evidence_field_summary_detail_consistency_required_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "final_completion_blocker_evidence_field_summary_detail_consistency_all_present_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "final_completion_blocker_evidence_field_summary_detail_consistency_mismatched_count"
        ]
        == 2
    )
    assert (
        summary[
            "final_completion_blocker_evidence_field_summary_detail_consistency_matched_count"
        ]
        == 0
    )
    assert note_token in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert (
            root[
                "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_required_count"
            ]
            == 7
        )
        assert (
            root[
                "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_all_present_matched_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_mismatched_count"
            ]
            == 2
        )
        assert (
            root[
                "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_matched_count"
            ]
            == 0
        )
        assert note_token in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_blocker_code_consistency_mismatch() -> None:
    note_token = (
        "blocker_code_consistency=codes=7; total=8; total_matched=false; "
        "unique_matched=false; signature_matched=false; all_have_code=false; "
        "matched=false"
    )
    assert note_token == "blocker_code_consistency=codes=7; total=8; total_matched=false; unique_matched=false; signature_matched=false; all_have_code=false; matched=false"  # noqa: E501
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "final_completion_blocker_code_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_blocker_code_consistency"
            ),
            "code_count": 7,
            "code_count_total": 8,
            "code_count_total_matches_blocker_count": False,
            "unique_code_count_matches_top_level": False,
            "signature_matches_counts": False,
            "all_blockers_have_code": False,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert summary["final_completion_blocker_code_consistency_code_count"] == 7
    assert summary["final_completion_blocker_code_consistency_code_total"] == 8
    assert (
        summary[
            "final_completion_blocker_code_consistency_total_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "final_completion_blocker_code_consistency_unique_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "final_completion_blocker_code_consistency_signature_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "final_completion_blocker_code_consistency_all_have_code_count"
        ]
        == 0
    )
    assert summary["final_completion_blocker_code_consistency_matched_count"] == 0
    assert note_token in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert (
            root["analysis_final_completion_blocker_code_consistency_code_count"]
            == 7
        )
        assert (
            root["analysis_final_completion_blocker_code_consistency_code_total"]
            == 8
        )
        assert (
            root[
                "analysis_final_completion_blocker_code_consistency_total_matched_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_blocker_code_consistency_unique_matched_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_blocker_code_consistency_signature_matched_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_blocker_code_consistency_all_have_code_count"
            ]
            == 0
        )
        assert (
            root["analysis_final_completion_blocker_code_consistency_matched_count"]
            == 0
        )
        assert note_token in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_blocker_kind_consistency_mismatch() -> None:
    note_token = (
        "blocker_kind_consistency=kinds=3; total=8; signed=2; "
        "non_diagram=2; completion=4; rows=3; total_matched=false; "
        "unique_matched=false; all_have_kind=false; matched=false"
    )
    assert note_token == "blocker_kind_consistency=kinds=3; total=8; signed=2; non_diagram=2; completion=4; rows=3; total_matched=false; unique_matched=false; all_have_kind=false; matched=false"  # noqa: E501
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "final_completion_blocker_kind_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_blocker_kind_consistency"
            ),
            "summary_row_count": 3,
            "kind_count": 3,
            "kind_count_total": 8,
            "signed_fixture_blocker_count": 2,
            "non_diagram_requirement_blocker_count": 2,
            "completion_gate_blocker_count": 4,
            "kind_count_total_matches_blocker_count": False,
            "unique_kind_count_matches_summary": False,
            "all_blockers_have_kind": False,
            "summary_blocker_count_matches_top_level": False,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert summary["final_completion_blocker_kind_consistency_blocker_count"] == 0
    assert summary["final_completion_blocker_kind_consistency_kind_count"] == 3
    assert summary["final_completion_blocker_kind_consistency_kind_total"] == 8
    assert (
        summary["final_completion_blocker_kind_consistency_total_matched_count"]
        == 0
    )
    assert (
        summary["final_completion_blocker_kind_consistency_unique_matched_count"]
        == 0
    )
    assert summary["final_completion_blocker_kind_all_have_kind_count"] == 0
    assert (
        summary["final_completion_blocker_kind_summary_count_matched_count"]
        == 0
    )
    assert summary["final_completion_blocker_kind_consistency_matched_count"] == 0
    assert note_token in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert (
            root["analysis_final_completion_blocker_kind_consistency_kind_count"]
            == 3
        )
        assert (
            root["analysis_final_completion_blocker_kind_consistency_kind_total"]
            == 8
        )
        assert (
            root[
                "analysis_final_completion_blocker_kind_consistency_total_matched_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_blocker_kind_consistency_unique_matched_count"
            ]
            == 0
        )
        assert root["analysis_final_completion_blocker_kind_all_have_kind_count"] == 0
        assert (
            root[
                "analysis_final_completion_blocker_kind_consistency_matched_count"
            ]
            == 0
        )
        assert note_token in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_blocker_kind_summary_detail_mismatch() -> None:
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "final_completion_blocker_kind_summary_detail_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_"
                "blocker_kind_summary_detail_consistency"
            ),
            "summary_row_count": 3,
            "kind_count": 3,
            "blocker_count": 9,
            "blocker_code_reference_count": 7,
            "missing_artifact_reference_count": 7,
            "unique_missing_artifact_count": 6,
            "summary_blocker_count_total": 8,
            "blocker_count_matched_count": 2,
            "blocker_codes_matched_count": 1,
            "missing_artifacts_matched_count": 1,
            "mismatched_summary_row_count": 2,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert (
        summary[
            "final_completion_blocker_kind_summary_detail_consistency_row_count"
        ]
        == 3
    )
    assert (
        summary[
            "final_completion_blocker_kind_summary_detail_consistency_kind_count"
        ]
        == 3
    )
    assert (
        summary[
            "final_completion_blocker_kind_summary_detail_consistency_blocker_count"
        ]
        == 9
    )
    assert (
        summary[
            "final_completion_blocker_kind_summary_detail_consistency_code_reference_count"
        ]
        == 7
    )
    assert (
        summary[
            "final_completion_blocker_kind_summary_detail_consistency_missing_artifact_reference_count"
        ]
        == 7
    )
    assert (
        summary[
            "final_completion_blocker_kind_summary_detail_consistency_unique_missing_artifact_count"
        ]
        == 6
    )
    assert (
        summary[
            "final_completion_blocker_kind_summary_detail_consistency_blocker_count_matched_count"
        ]
        == 2
    )
    assert (
        summary[
            "final_completion_blocker_kind_summary_detail_consistency_codes_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "final_completion_blocker_kind_summary_detail_consistency_missing_artifacts_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "final_completion_blocker_kind_summary_detail_consistency_mismatched_count"
        ]
        == 2
    )
    assert (
        summary[
            "final_completion_blocker_kind_summary_detail_consistency_matched_count"
        ]
        == 0
    )
    assert "blocker_kind_summary_detail=rows=3; kinds=3; blockers=9; codes=7; missing_refs=7; unique_missing=6; count_matched=2; codes_matched=1; missing_artifacts_matched=1; mismatched=2; matched=false" in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert (
            root[
                "analysis_final_completion_blocker_kind_summary_detail_consistency_row_count"
            ]
            == 3
        )
        assert (
            root[
                "analysis_final_completion_blocker_kind_summary_detail_consistency_code_reference_count"
            ]
            == 7
        )
        assert (
            root[
                "analysis_final_completion_blocker_kind_summary_detail_consistency_missing_artifacts_matched_count"
            ]
            == 1
        )
        assert (
            root[
                "analysis_final_completion_blocker_kind_summary_detail_consistency_mismatched_count"
            ]
            == 2
        )
        assert (
            root[
                "analysis_final_completion_blocker_kind_summary_detail_consistency_matched_count"
            ]
            == 0
        )
        assert "blocker_kind_summary_detail=rows=3; kinds=3; blockers=9; codes=7; missing_refs=7; unique_missing=6; count_matched=2; codes_matched=1; missing_artifacts_matched=1; mismatched=2; matched=false" in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_blocker_code_summary_detail_mismatch() -> None:
    note_token = (
        "blocker_code_summary_detail=rows=8; codes=8; blockers=9; "
        "kinds=7; labels=8; missing_refs=7; unique_missing=6; "
        "count_matched=6; kinds_matched=5; labels_matched=4; "
        "missing_artifacts_matched=4; mismatched=2; matched=false"
    )
    assert note_token == "blocker_code_summary_detail=rows=8; codes=8; blockers=9; kinds=7; labels=8; missing_refs=7; unique_missing=6; count_matched=6; kinds_matched=5; labels_matched=4; missing_artifacts_matched=4; mismatched=2; matched=false"  # noqa: E501
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "final_completion_blocker_code_summary_detail_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_"
                "blocker_code_summary_detail_consistency"
            ),
            "summary_row_count": 8,
            "code_count": 8,
            "blocker_count": 9,
            "blocker_kind_reference_count": 7,
            "blocker_label_reference_count": 8,
            "missing_artifact_reference_count": 7,
            "unique_missing_artifact_count": 6,
            "summary_blocker_count_total": 8,
            "blocker_count_matched_count": 6,
            "blocker_kinds_matched_count": 5,
            "blocker_labels_matched_count": 4,
            "missing_artifacts_matched_count": 4,
            "mismatched_summary_row_count": 2,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert (
        summary[
            "final_completion_blocker_code_summary_detail_consistency_row_count"
        ]
        == 8
    )
    assert (
        summary[
            "final_completion_blocker_code_summary_detail_consistency_code_count"
        ]
        == 8
    )
    assert (
        summary[
            "final_completion_blocker_code_summary_detail_consistency_kind_reference_count"
        ]
        == 7
    )
    assert (
        summary[
            "final_completion_blocker_code_summary_detail_consistency_label_reference_count"
        ]
        == 8
    )
    assert (
        summary[
            "final_completion_blocker_code_summary_detail_consistency_missing_artifact_reference_count"
        ]
        == 7
    )
    assert (
        summary[
            "final_completion_blocker_code_summary_detail_consistency_unique_missing_artifact_count"
        ]
        == 6
    )
    assert (
        summary[
            "final_completion_blocker_code_summary_detail_consistency_blocker_count_matched_count"
        ]
        == 6
    )
    assert (
        summary[
            "final_completion_blocker_code_summary_detail_consistency_kinds_matched_count"
        ]
        == 5
    )
    assert (
        summary[
            "final_completion_blocker_code_summary_detail_consistency_labels_matched_count"
        ]
        == 4
    )
    assert (
        summary[
            "final_completion_blocker_code_summary_detail_consistency_missing_artifacts_matched_count"
        ]
        == 4
    )
    assert (
        summary[
            "final_completion_blocker_code_summary_detail_consistency_mismatched_count"
        ]
        == 2
    )
    assert (
        summary[
            "final_completion_blocker_code_summary_detail_consistency_matched_count"
        ]
        == 0
    )
    assert note_token in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert (
            root[
                "analysis_final_completion_blocker_code_summary_detail_consistency_row_count"
            ]
            == 8
        )
        assert (
            root[
                "analysis_final_completion_blocker_code_summary_detail_consistency_kind_reference_count"
            ]
            == 7
        )
        assert (
            root[
                "analysis_final_completion_blocker_code_summary_detail_consistency_labels_matched_count"
            ]
            == 4
        )
        assert (
            root[
                "analysis_final_completion_blocker_code_summary_detail_consistency_mismatched_count"
            ]
            == 2
        )
        assert (
            root[
                "analysis_final_completion_blocker_code_summary_detail_consistency_matched_count"
            ]
            == 0
        )
        assert note_token in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_open_gate_blocker_summary_consistency_mismatch() -> None:
    note_token = (
        "open_gate_blocker_summary=failed_gates=6; summary_gates=5; "
        "blockers=9; summary_blockers=8; gate_sets_matched=false; "
        "blocker_count_matched=false; all_blockers_have_gate=false"
    )
    assert note_token == "open_gate_blocker_summary=failed_gates=6; summary_gates=5; blockers=9; summary_blockers=8; gate_sets_matched=false; blocker_count_matched=false; all_blockers_have_gate=false"  # noqa: E501
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "final_completion_open_gate_blocker_summary_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_"
                "open_gate_blocker_summary_consistency"
            ),
            "failed_gate_count": 6,
            "summary_gate_count": 5,
            "blocker_count": 9,
            "summary_blocker_count": 8,
            "gate_sets_matched": False,
            "blocker_count_matched": False,
            "all_blockers_have_gate": False,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert note_token in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert note_token in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_open_gate_blocker_summary_detail_mismatch() -> None:
    note_token = (
        "open_gate_blocker_summary_detail=gates=6; blockers=9; "
        "codes=8; missing_refs=7; unique_missing=6; retained=3; "
        "count_matched=5; codes_matched=4; missing_artifacts_matched=4; "
        "retained_matched=3; mismatched=2; matched=false"
    )
    assert note_token == "open_gate_blocker_summary_detail=gates=6; blockers=9; codes=8; missing_refs=7; unique_missing=6; retained=3; count_matched=5; codes_matched=4; missing_artifacts_matched=4; retained_matched=3; mismatched=2; matched=false"  # noqa: E501
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "final_completion_open_gate_blocker_summary_detail_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_"
                "open_gate_blocker_summary_detail_consistency"
            ),
            "summary_gate_count": 6,
            "checked_gate_count": 6,
            "blocker_count": 9,
            "blocker_code_reference_count": 8,
            "missing_artifact_reference_count": 7,
            "unique_missing_artifact_count": 6,
            "retained_evidence_reference_count": 3,
            "summary_blocker_count_total": 9,
            "blocker_count_matched_count": 5,
            "blocker_codes_matched_count": 4,
            "missing_artifacts_matched_count": 4,
            "retained_evidence_count_matched_count": 3,
            "mismatched_summary_row_count": 2,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert (
        summary[
            "final_completion_open_gate_blocker_summary_detail_consistency_gate_count"
        ]
        == 6
    )
    assert (
        summary[
            "final_completion_open_gate_blocker_summary_detail_consistency_blocker_count"
        ]
        == 9
    )
    assert (
        summary[
            "final_completion_open_gate_blocker_summary_detail_consistency_missing_artifact_reference_count"
        ]
        == 7
    )
    assert (
        summary[
            "final_completion_open_gate_blocker_summary_detail_consistency_retained_evidence_reference_count"
        ]
        == 3
    )
    assert (
        summary[
            "final_completion_open_gate_blocker_summary_detail_consistency_blocker_count_matched_count"
        ]
        == 5
    )
    assert (
        summary[
            "final_completion_open_gate_blocker_summary_detail_consistency_codes_matched_count"
        ]
        == 4
    )
    assert (
        summary[
            "final_completion_open_gate_blocker_summary_detail_consistency_missing_artifacts_matched_count"
        ]
        == 4
    )
    assert (
        summary[
            "final_completion_open_gate_blocker_summary_detail_consistency_retained_evidence_matched_count"
        ]
        == 3
    )
    assert (
        summary[
            "final_completion_open_gate_blocker_summary_detail_consistency_mismatched_count"
        ]
        == 2
    )
    assert (
        summary[
            "final_completion_open_gate_blocker_summary_detail_consistency_matched_count"
        ]
        == 0
    )
    assert note_token in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert (
            root[
                "analysis_final_completion_open_gate_blocker_summary_detail_consistency_gate_count"
            ]
            == 6
        )
        assert (
            root[
                "analysis_final_completion_open_gate_blocker_summary_detail_consistency_missing_artifact_reference_count"
            ]
            == 7
        )
        assert (
            root[
                "analysis_final_completion_open_gate_blocker_summary_detail_consistency_retained_evidence_reference_count"
            ]
            == 3
        )
        assert (
            root[
                "analysis_final_completion_open_gate_blocker_summary_detail_consistency_mismatched_count"
            ]
            == 2
        )
        assert (
            root[
                "analysis_final_completion_open_gate_blocker_summary_detail_consistency_matched_count"
            ]
            == 0
        )
        assert note_token in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_required_check_consistency_mismatch() -> None:
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "required_diagram_fixture_metadata_complete": True,
        "signed_diagram_fixture_registration_complete": False,
        "open_non_diagram_requirement_count": 1,
        "final_completion_ready": False,
        "final_completion_required_check_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_required_check_consistency"
            ),
            "required_check_count": 3,
            "passed_required_check_count": 2,
            "failed_required_check_count": 1,
            "mismatched_required_check_count": 1,
            "final_completion_ready_matches_required_checks": False,
            "all_required_checks_matched": False,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert summary["final_completion_required_check_count"] == 3
    assert summary["final_completion_required_check_passed_count"] == 2
    assert summary["final_completion_required_check_failed_count"] == 1
    assert summary["final_completion_required_check_mismatched_count"] == 1
    assert (
        summary["final_completion_required_check_final_ready_matched_count"]
        == 0
    )
    assert summary["final_completion_required_check_all_matched_count"] == 0
    assert (
        summary["final_completion_required_check_consistency_matched_count"]
        == 0
    )
    assert "required_check_consistency=required=3; passed=2; failed=1; mismatched=1; final_ready_matched=false; all_matched=false; matched=false" in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert root["analysis_final_completion_required_check_count"] == 3
        assert root["analysis_final_completion_required_check_passed_count"] == 2
        assert root["analysis_final_completion_required_check_failed_count"] == 1
        assert (
            root["analysis_final_completion_required_check_mismatched_count"]
            == 1
        )
        assert (
            root[
                "analysis_final_completion_required_check_final_ready_matched_count"
            ]
            == 0
        )
        assert (
            root["analysis_final_completion_required_check_all_matched_count"]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_required_check_consistency_matched_count"
            ]
            == 0
        )
        assert "required_check_consistency=required=3; passed=2; failed=1; mismatched=1; final_ready_matched=false; all_matched=false; matched=false" in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_required_fixture_metadata_consistency_mismatch() -> None:
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "required_diagram_fixture_metadata_complete": False,
        "signed_diagram_fixture_registration_complete": False,
        "open_non_diagram_requirement_count": 1,
        "final_completion_ready": False,
        "final_completion_required_diagram_fixture_metadata_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_"
                "required_diagram_fixture_metadata_consistency"
            ),
            "required_fixture_count": 7,
            "registered_fixture_count": 6,
            "missing_fixture_count": 1,
            "metadata_complete_fixture_count": 5,
            "metadata_incomplete_fixture_count": 2,
            "metadata_blocker_count": 2,
            "gate_passed": False,
            "gate_blocker_count": 1,
            "mismatched_fixture_count": 2,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert (
        summary[
            "final_completion_required_diagram_fixture_metadata_consistency_required_count"
        ]
        == 7
    )
    assert (
        summary[
            "final_completion_required_diagram_fixture_metadata_consistency_registered_count"
        ]
        == 6
    )
    assert (
        summary[
            "final_completion_required_diagram_fixture_metadata_consistency_missing_count"
        ]
        == 1
    )
    assert (
        summary[
            "final_completion_required_diagram_fixture_metadata_consistency_metadata_complete_count"
        ]
        == 5
    )
    assert (
        summary[
            "final_completion_required_diagram_fixture_metadata_consistency_metadata_incomplete_count"
        ]
        == 2
    )
    assert (
        summary[
            "final_completion_required_diagram_fixture_metadata_consistency_metadata_blocker_count"
        ]
        == 2
    )
    assert (
        summary[
            "final_completion_required_diagram_fixture_metadata_consistency_gate_passed_count"
        ]
        == 0
    )
    assert (
        summary[
            "final_completion_required_diagram_fixture_metadata_consistency_gate_blocker_count"
        ]
        == 1
    )
    assert (
        summary[
            "final_completion_required_diagram_fixture_metadata_consistency_mismatched_count"
        ]
        == 2
    )
    assert (
        summary[
            "final_completion_required_diagram_fixture_metadata_consistency_matched_count"
        ]
        == 0
    )
    assert "required_fixture_metadata_consistency=required=7; registered=6; missing=1; metadata_complete=5; metadata_incomplete=2; blockers=2; gate_passed=false; matched=false" in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert (
            root[
                "analysis_final_completion_required_diagram_fixture_metadata_consistency_registered_count"
            ]
            == 6
        )
        assert (
            root[
                "analysis_final_completion_required_diagram_fixture_metadata_consistency_missing_count"
            ]
            == 1
        )
        assert (
            root[
                "analysis_final_completion_required_diagram_fixture_metadata_consistency_gate_passed_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_required_diagram_fixture_metadata_consistency_mismatched_count"
            ]
            == 2
        )
        assert (
            root[
                "analysis_final_completion_required_diagram_fixture_metadata_consistency_matched_count"
            ]
            == 0
        )
        assert "required_fixture_metadata_consistency=required=7; registered=6; missing=1; metadata_complete=5; metadata_incomplete=2; blockers=2; gate_passed=false; matched=false" in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_signed_fixture_consistency_mismatch() -> None:
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "required_diagram_fixture_metadata_complete": True,
        "signed_diagram_fixture_registration_complete": False,
        "open_non_diagram_requirement_count": 1,
        "final_completion_ready": False,
        "final_completion_signed_fixture_consistency": {
            "claim_scope": "validation_pack_final_completion_signed_fixture_consistency",
            "signed_fixture_blocker_count": 2,
            "final_blocker_count": 1,
            "source_url_present_count": 1,
            "unsigned_non_claim_preserved_count": 1,
            "source_table_metadata_available_count": 1,
            "missing_artifact_matched_count": 1,
            "evidence_fields_matched_count": 0,
            "source_candidate_evidence_available_count": 1,
            "source_candidate_not_unique_count": 1,
            "source_candidate_replay_all_valid_count": 1,
            "source_candidate_matching_candidate_count_total": 12,
            "source_candidate_unique_sign_pattern_count_total": 6,
            "mismatched_fixture_count": 1,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert summary["final_completion_signed_fixture_consistency_blocker_count"] == 2
    assert (
        summary["final_completion_signed_fixture_consistency_final_blocker_count"]
        == 1
    )
    assert (
        summary[
            "final_completion_signed_fixture_consistency_source_url_present_count"
        ]
        == 1
    )
    assert (
        summary[
            "final_completion_signed_fixture_consistency_unsigned_non_claim_count"
        ]
        == 1
    )
    assert (
        summary[
            "final_completion_signed_fixture_consistency_source_table_metadata_count"
        ]
        == 1
    )
    assert (
        summary[
            "final_completion_signed_fixture_consistency_evidence_fields_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "final_completion_signed_fixture_consistency_source_candidate_evidence_available_count"
        ]
        == 1
    )
    assert (
        summary[
            "final_completion_signed_fixture_consistency_source_candidate_not_unique_count"
        ]
        == 1
    )
    assert (
        summary[
            "final_completion_signed_fixture_consistency_source_candidate_replay_all_valid_count"
        ]
        == 1
    )
    assert (
        summary[
            "final_completion_signed_fixture_consistency_source_candidate_matching_candidate_count_total"
        ]
        == 12
    )
    assert (
        summary[
            "final_completion_signed_fixture_consistency_source_candidate_unique_sign_pattern_count_total"
        ]
        == 6
    )
    assert summary["final_completion_signed_fixture_consistency_mismatched_count"] == 1
    assert summary["final_completion_signed_fixture_consistency_matched_count"] == 0
    assert "signed_fixture_consistency=blockers=2; final_blockers=1; source_urls=1; unsigned_non_claims=1; source_table_metadata=1" in summary["notes"]
    assert "signed_fixture_consistency=blockers=2; final_blockers=1; source_urls=1; unsigned_non_claims=1; source_table_metadata=1; source_candidate_evidence=1; source_candidates_not_unique=1; source_candidate_replays_valid=1; source_candidate_matches=12; source_candidate_unique_signs=6; mismatched=1; matched=false" in summary["notes"]
    assert "source_candidate_matches=12; source_candidate_unique_signs=6" in summary["notes"]
    assert "mismatched=1; matched=false" in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert (
            root["analysis_final_completion_signed_fixture_consistency_blocker_count"]
            == 2
        )
        assert (
            root[
                "analysis_final_completion_signed_fixture_consistency_final_blocker_count"
            ]
            == 1
        )
        assert (
            root[
                "analysis_final_completion_signed_fixture_consistency_evidence_fields_matched_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_signed_fixture_consistency_source_candidate_evidence_available_count"
            ]
            == 1
        )
        assert (
            root[
                "analysis_final_completion_signed_fixture_consistency_source_candidate_matching_candidate_count_total"
            ]
            == 12
        )
        assert (
            root[
                "analysis_final_completion_signed_fixture_consistency_mismatched_count"
            ]
            == 1
        )
        assert (
            root["analysis_final_completion_signed_fixture_consistency_matched_count"]
            == 0
        )
        assert "source_candidate_matches=12; source_candidate_unique_signs=6" in root["analysis_summaries"][0]["notes"]
        assert "mismatched=1; matched=false" in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_non_diagram_requirement_consistency_mismatch() -> None:
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "required_diagram_fixture_metadata_complete": True,
        "signed_diagram_fixture_registration_complete": False,
        "open_non_diagram_requirement_count": 1,
        "final_completion_ready": False,
        "final_completion_non_diagram_requirement_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_non_diagram_requirement_consistency"
            ),
            "requirement_count": 6,
            "open_requirement_count": 3,
            "blocker_count": 2,
            "retained_evidence_reference_count": 3,
            "retained_evidence_id_count": 2,
            "retained_evidence_reference_count_matches_top_level": False,
            "retained_evidence_id_count_matches_top_level": False,
            "missing_artifact_matched_count": 2,
            "evidence_fields_matched_count": 1,
            "retained_evidence_matched_count": 2,
            "retained_evidence_ids_matched_count": 1,
            "completion_claim_false_count": 2,
            "mismatched_requirement_count": 2,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert (
        summary["final_completion_non_diagram_requirement_consistency_requirement_count"]
        == 6
    )
    assert summary["final_completion_non_diagram_requirement_consistency_open_count"] == 3
    assert (
        summary["final_completion_non_diagram_requirement_consistency_blocker_count"]
        == 2
    )
    assert (
        summary[
            "final_completion_non_diagram_requirement_consistency_retained_evidence_count"
        ]
        == 3
    )
    assert (
        summary[
            "final_completion_non_diagram_requirement_consistency_retained_evidence_id_count"
        ]
        == 2
    )
    assert (
        summary[
            "final_completion_non_diagram_requirement_consistency_retained_evidence_reference_top_level_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "final_completion_non_diagram_requirement_consistency_retained_evidence_id_top_level_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "final_completion_non_diagram_requirement_consistency_missing_artifact_matched_count"
        ]
        == 2
    )
    assert (
        summary[
            "final_completion_non_diagram_requirement_consistency_evidence_fields_matched_count"
        ]
        == 1
    )
    assert (
        summary["final_completion_non_diagram_requirement_consistency_mismatched_count"]
        == 2
    )
    assert (
        summary["final_completion_non_diagram_requirement_consistency_matched_count"]
        == 0
    )
    assert "non_diagram_requirement_consistency=requirements=6; open=3; blockers=2; evidence_refs=3; evidence_ids=2; missing_artifacts_matched=2; evidence_fields_matched=1; refs_top_level_matched=false; ids_top_level_matched=false; mismatched=2; matched=false" in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert (
            root[
                "analysis_final_completion_non_diagram_requirement_consistency_requirement_count"
            ]
            == 6
        )
        assert (
            root[
                "analysis_final_completion_non_diagram_requirement_consistency_blocker_count"
            ]
            == 2
        )
        assert (
            root[
                "analysis_final_completion_non_diagram_requirement_consistency_retained_evidence_reference_top_level_matched_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_non_diagram_requirement_consistency_retained_evidence_id_top_level_matched_count"
            ]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_non_diagram_requirement_consistency_mismatched_count"
            ]
            == 2
        )
        assert (
            root[
                "analysis_final_completion_non_diagram_requirement_consistency_matched_count"
            ]
            == 0
        )
        assert "non_diagram_requirement_consistency=requirements=6; open=3; blockers=2; evidence_refs=3; evidence_ids=2; missing_artifacts_matched=2; evidence_fields_matched=1; refs_top_level_matched=false; ids_top_level_matched=false; mismatched=2; matched=false" in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_non_claim_gate_consistency_mismatch() -> None:
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "final_completion_non_claim_gate_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_non_claim_gate_consistency"
            ),
            "non_claim_field_count": 4,
            "false_non_claim_field_count": 3,
            "completion_gate_check_count": 4,
            "completion_gate_blocker_count": 3,
            "missing_artifact_reference_count": 3,
            "unique_missing_artifact_count": 3,
            "matched_non_claim_field_count": 2,
            "mismatched_non_claim_field_count": 2,
            "non_claim_gate_count": 4,
            "top_level_false_count": 3,
            "gate_check_failed_count": 4,
            "blocker_code_matched_count": 2,
            "missing_artifact_matched_count": 2,
            "matched_gate_count": 2,
            "all_top_level_values_false": False,
            "all_completion_gate_blockers_present": False,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert summary["final_completion_non_claim_gate_count"] == 4
    assert summary["final_completion_non_claim_gate_top_level_false_count"] == 3
    assert summary["final_completion_non_claim_gate_check_failed_count"] == 4
    assert summary["final_completion_non_claim_gate_blocker_count"] == 3
    assert summary["final_completion_non_claim_gate_code_matched_count"] == 2
    assert (
        summary["final_completion_non_claim_gate_missing_artifact_matched_count"]
        == 2
    )
    assert summary["final_completion_non_claim_gate_matched_gate_count"] == 2
    assert summary["final_completion_non_claim_gate_all_false_count"] == 0
    assert summary["final_completion_non_claim_gate_all_blockers_present_count"] == 0
    assert summary["final_completion_non_claim_gate_consistency_matched_count"] == 0
    assert summary["final_completion_non_claim_gate_consistency_field_count"] == 4
    assert summary["final_completion_non_claim_gate_consistency_false_count"] == 3
    assert summary["final_completion_non_claim_gate_consistency_gate_count"] == 4
    assert summary["final_completion_non_claim_gate_consistency_blocker_count"] == 3
    assert (
        summary[
            "final_completion_non_claim_gate_consistency_missing_artifact_count"
        ]
        == 3
    )
    assert summary["final_completion_non_claim_gate_consistency_mismatched_count"] == 2
    assert "non_claim_gate_consistency=fields=4; false=3; gates=4; blockers=3; missing_artifacts=3; codes_matched=2; missing_artifacts_matched_count=3; matched=false" in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert root["analysis_final_completion_non_claim_gate_count"] == 4
        assert root["analysis_final_completion_non_claim_gate_top_level_false_count"] == 3
        assert root["analysis_final_completion_non_claim_gate_blocker_count"] == 3
        assert root["analysis_final_completion_non_claim_gate_all_false_count"] == 0
        assert (
            root["analysis_final_completion_non_claim_gate_all_blockers_present_count"]
            == 0
        )
        assert (
            root["analysis_final_completion_non_claim_gate_consistency_matched_count"]
            == 0
        )
        assert (
            root[
                "analysis_final_completion_non_claim_gate_consistency_mismatched_count"
            ]
            == 2
        )
        assert "non_claim_gate_consistency=fields=4; false=3; gates=4; blockers=3; missing_artifacts=3; codes_matched=2; missing_artifacts_matched_count=3; matched=false" in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_completion_gate_evidence_consistency_mismatch() -> None:
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "final_completion_completion_gate_evidence_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_"
                "completion_gate_evidence_consistency"
            ),
            "gate_count": 4,
            "gate_check_count": 4,
            "completion_gate_blocker_count": 3,
            "failed_gate_count": 4,
            "top_level_false_count": 3,
            "blocker_code_matched_count": 2,
            "required_evidence_matched_count": 2,
            "current_evidence_matched_count": 1,
            "missing_artifact_matched_count": 2,
            "mismatched_gate_count": 2,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert summary[
        "final_completion_completion_gate_evidence_consistency_gate_count"
    ] == 4
    assert summary[
        "final_completion_completion_gate_evidence_consistency_gate_check_count"
    ] == 4
    assert summary[
        "final_completion_completion_gate_evidence_consistency_blocker_count"
    ] == 3
    assert summary[
        "final_completion_completion_gate_evidence_consistency_failed_gate_count"
    ] == 4
    assert summary[
        "final_completion_completion_gate_evidence_consistency_top_level_false_count"
    ] == 3
    assert summary[
        "final_completion_completion_gate_evidence_consistency_code_matched_count"
    ] == 2
    assert summary[
        "final_completion_completion_gate_evidence_consistency_required_evidence_matched_count"
    ] == 2
    assert summary[
        "final_completion_completion_gate_evidence_consistency_current_evidence_matched_count"
    ] == 1
    assert summary[
        "final_completion_completion_gate_evidence_consistency_missing_artifact_matched_count"
    ] == 2
    assert summary[
        "final_completion_completion_gate_evidence_consistency_missing_artifact_id_matched_count"
    ] == 0
    assert summary[
        "final_completion_completion_gate_evidence_consistency_retained_evidence_count"
    ] == 0
    assert summary[
        "final_completion_completion_gate_evidence_consistency_retained_evidence_id_count"
    ] == 0
    assert summary[
        "final_completion_completion_gate_evidence_consistency_retained_evidence_ids_matched_count"
    ] == 0
    assert summary[
        "final_completion_completion_gate_evidence_consistency_mismatched_count"
    ] == 2
    assert summary[
        "final_completion_completion_gate_evidence_consistency_matched_count"
    ] == 0
    assert "completion_gate_evidence_consistency=gates=4; gate_checks=4; blockers=3; failed=4; false=3; codes=2; required=2; current=1; missing_artifacts=2; missing_artifact_ids=0; retained_evidence=0; retained_evidence_ids=0; retained_evidence_matched=0; mismatched=2; matched=false" in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert root[
            "analysis_final_completion_completion_gate_evidence_consistency_gate_count"
        ] == 4
        assert root[
            "analysis_final_completion_completion_gate_evidence_consistency_gate_check_count"
        ] == 4
        assert root[
            "analysis_final_completion_completion_gate_evidence_consistency_blocker_count"
        ] == 3
        assert root[
            "analysis_final_completion_completion_gate_evidence_consistency_failed_gate_count"
        ] == 4
        assert root[
            "analysis_final_completion_completion_gate_evidence_consistency_top_level_false_count"
        ] == 3
        assert root[
            "analysis_final_completion_completion_gate_evidence_consistency_code_matched_count"
        ] == 2
        assert root[
            "analysis_final_completion_completion_gate_evidence_consistency_required_evidence_matched_count"
        ] == 2
        assert root[
            "analysis_final_completion_completion_gate_evidence_consistency_current_evidence_matched_count"
        ] == 1
        assert root[
            "analysis_final_completion_completion_gate_evidence_consistency_missing_artifact_matched_count"
        ] == 2
        assert root[
            "analysis_final_completion_completion_gate_evidence_consistency_missing_artifact_id_matched_count"
        ] == 0
        assert root[
            "analysis_final_completion_completion_gate_evidence_consistency_mismatched_count"
        ] == 2
        assert root[
            "analysis_final_completion_completion_gate_evidence_consistency_matched_count"
        ] == 0
        assert "missing_artifact_ids=0; retained_evidence=0; retained_evidence_ids=0; retained_evidence_matched=0; mismatched=2; matched=false" in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_payloads_preserve_validation_pack_gate_blocker_consistency_mismatch() -> None:
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "final_completion_gate_blocker_consistency": {
            "claim_scope": (
                "validation_pack_final_completion_gate_blocker_consistency"
            ),
            "gate_check_count": 7,
            "summary_gate_count": 6,
            "checked_gate_count": 7,
            "matched_gate_count": 5,
            "mismatched_gate_count": 2,
            "blocker_count_matched_gate_count": 5,
            "blocker_codes_matched_gate_count": 4,
            "all_gate_blocker_counts_matched": False,
            "all_gate_blocker_codes_matched": False,
            "matched": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert summary["final_completion_gate_blocker_consistency_checked_gate_count"] == 7
    assert summary["final_completion_gate_blocker_consistency_mismatched_gate_count"] == 2
    assert summary["final_completion_gate_blocker_count_matched_gate_count"] == 5
    assert summary["final_completion_gate_blocker_codes_matched_gate_count"] == 4
    assert summary["final_completion_gate_blocker_consistency_matched_count"] == 0
    assert "gate_blocker_consistency=checked=7; count_matched=5; codes_matched=4; mismatched=2; matched=false" in summary["notes"]

    for root in (payload, host_payload["analysis"]):
        assert (
            root[
                "analysis_final_completion_gate_blocker_consistency_checked_gate_count"
            ]
            == 7
        )
        assert (
            root[
                "analysis_final_completion_gate_blocker_consistency_mismatched_gate_count"
            ]
            == 2
        )
        assert (
            root[
                "analysis_final_completion_gate_blocker_count_matched_gate_count"
            ]
            == 5
        )
        assert (
            root[
                "analysis_final_completion_gate_blocker_codes_matched_gate_count"
            ]
            == 4
        )
        assert (
            root["analysis_final_completion_gate_blocker_consistency_matched_count"]
            == 0
        )
        assert "gate_blocker_consistency=checked=7; count_matched=5; codes_matched=4; mismatched=2; matched=false" in root["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)

def test_imgui_analysis_summary_wraps_validate_table_source_metadata_report() -> None:
    report = _validate_table_source_metadata_report()

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["name"] == "validate-table source metadata"
    assert summary["source_method"] == "validate_table_source_metadata_report"
    assert summary["claim_scope"] == "table_source_metadata_scan"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 4
    assert summary["passed_check_count"] == 4
    assert summary["failed_check_count"] == 0
    assert summary["validate_table_source_metadata_artifact_count"] == 1
    assert summary["validate_table_source_metadata_valid_count"] == 1
    assert summary["validate_table_source_metadata_issue_count"] == 0
    assert summary["validate_table_source_metadata_record_count"] == 2
    assert (
        summary["validate_table_source_metadata_provenance_review_ready_count"]
        == 1
    )
    assert summary["validate_table_source_metadata_provenance_blocker_count"] == 0
    assert (
        summary[
            "validate_table_source_metadata_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "validate_table_source_metadata_blocker_summary_consistency_matched_count"
        ]
        == 1
    )
    assert summary["validate_table_source_metadata_source_count"] == 2
    assert summary["validate_table_source_metadata_source_value_label_count"] == 2
    assert (
        summary["validate_table_source_metadata_source_value_row_count_total"]
        == 2
    )
    assert summary["validate_table_source_metadata_source_url_count"] == 2
    assert summary["validate_table_source_metadata_source_url_scheme_count"] == 1
    assert summary["validate_table_source_metadata_source_url_domain_count"] == 2
    assert summary["validate_table_source_metadata_valid_source_url_count"] == 2
    assert summary["validate_table_source_metadata_invalid_source_url_count"] == 0
    assert (
        summary[
            "validate_table_source_metadata_source_url_missing_scheme_count"
        ]
        == 0
    )
    assert (
        summary[
            "validate_table_source_metadata_source_url_missing_domain_count"
        ]
        == 0
    )
    assert summary["validate_table_source_metadata_source_url_issue_code_total"] == 0
    assert summary["validate_table_source_metadata_all_records_have_source_count"] == 1
    assert (
        summary[
            "validate_table_source_metadata_all_source_records_have_source_url_count"
        ]
        == 1
    )
    assert (
        summary["validate_table_source_metadata_all_source_urls_have_source_count"]
        == 1
    )
    assert (
        summary[
            "validate_table_source_metadata_all_source_urls_are_http_or_https_count"
        ]
        == 1
    )
    assert (
        summary["validate_table_source_metadata_source_completeness_row_count"]
        == 2
    )
    assert (
        summary[
            "validate_table_source_metadata_source_completeness_row_count_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "validate_table_source_metadata_source_completeness_source_count_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "validate_table_source_metadata_source_completeness_source_url_count_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "validate_table_source_metadata_source_completeness_invalid_url_count_matched_count"
        ]
        == 1
    )
    assert summary["validate_table_source_metadata_known_limitations_count"] == 1
    assert (
        summary[
            "validate_table_source_metadata_convention_metadata_without_name_count"
        ]
        == 1
    )
    assert summary["validate_table_source_metadata_convention_mismatch_count"] == 0
    assert (
        summary[
            "validate_table_source_metadata_all_conventions_match_expected_count"
        ]
        == 1
    )
    assert (
        summary[
            "validate_table_source_metadata_all_conventions_match_expected"
        ]
        is True
    )
    assert (
        summary[
            "validate_table_source_metadata_table_correctness_certified_count"
        ]
        == 0
    )
    assert (
        summary["validate_table_source_metadata_external_source_verified_count"]
        == 0
    )
    assert (
        "validate_table_source_metadata_source_value_rows=Knot Atlas:$[0]|KnotInfo:$[1]"
        in summary["notes"]
    )
    assert (
        "validate_table_source_metadata_source_url_schemes=https:2"
        in summary["notes"]
    )
    assert (
        "validate_table_source_metadata_source_url_scheme_rows=https:$[0],$[1]"
        in summary["notes"]
    )
    assert (
        "validate_table_source_metadata_source_url_domains=katlas.org:1|knotinfo.math.indiana.edu:1"
        in summary["notes"]
    )
    assert (
        "validate_table_source_metadata_source_url_domain_rows=katlas.org:$[0]|knotinfo.math.indiana.edu:$[1]"
        in summary["notes"]
    )
    assert (
        "validate_table_source_metadata_source_completeness=rows=2; "
        "row_count_matched=true; source_count_matched=true; "
        "source_url_count_matched=true; invalid_url_count_matched=true"
        in summary["notes"]
    )
    assert (
        "validate_table_source_metadata_known_limitations_rows=$[0]"
        in summary["notes"]
    )
    assert (
        "validate_table_source_metadata_convention_metadata_without_name_rows=$[0]"
        in summary["notes"]
    )
    assert "not external table correctness" in summary["notes"]

    assert payload["analysis_validate_table_source_metadata_artifact_count"] == 1
    assert payload["analysis_validate_table_source_metadata_valid_count"] == 1
    assert payload["analysis_validate_table_source_metadata_record_count"] == 2
    assert (
        payload["analysis_validate_table_source_metadata_source_value_label_count"]
        == 2
    )
    assert (
        payload[
            "analysis_validate_table_source_metadata_source_value_row_count_total"
        ]
        == 2
    )
    assert (
        payload["analysis_validate_table_source_metadata_source_url_scheme_count"]
        == 1
    )
    assert (
        payload["analysis_validate_table_source_metadata_source_url_domain_count"]
        == 2
    )
    assert (
        payload[
            "analysis_validate_table_source_metadata_provenance_review_ready_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_validate_table_source_metadata_all_records_have_source_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_validate_table_source_metadata_all_source_records_have_source_url_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_validate_table_source_metadata_all_source_urls_have_source_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_validate_table_source_metadata_all_source_urls_are_http_or_https_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_validate_table_source_metadata_source_completeness_row_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_validate_table_source_metadata_source_completeness_row_count_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_validate_table_source_metadata_source_completeness_invalid_url_count_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_validate_table_source_metadata_table_correctness_certified_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_validate_table_source_metadata_convention_metadata_without_name_count"
        ]
        == 1
    )
    host_analysis = host_payload["analysis"]
    assert host_analysis["analysis_validate_table_source_metadata_artifact_count"] == 1
    assert host_analysis["analysis_validate_table_source_metadata_valid_count"] == 1
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_source_value_label_count"
        ]
        == 2
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_source_url_domain_count"
        ]
        == 2
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_source_url_issue_code_total"
        ]
        == 0
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_all_records_have_source_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_all_source_records_have_source_url_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_all_source_urls_have_source_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_all_source_urls_are_http_or_https_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_source_completeness_row_count"
        ]
        == 2
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_source_completeness_row_count_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_source_completeness_invalid_url_count_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_convention_metadata_without_name_count"
        ]
        == 1
    )
    host_summary = host_payload["analysis"]["analysis_summaries"][0]
    assert (
        "validate_table_source_metadata_source_value_rows=Knot Atlas:$[0]|KnotInfo:$[1]"
        in host_summary["notes"]
    )
    assert (
        "validate_table_source_metadata_source_url_domain_rows=katlas.org:$[0]|knotinfo.math.indiana.edu:$[1]"
        in host_summary["notes"]
    )
    assert (
        "validate_table_source_metadata_source_completeness=rows=2; "
        "row_count_matched=true; source_count_matched=true; "
        "source_url_count_matched=true; invalid_url_count_matched=true"
        in host_summary["notes"]
    )
    assert host_payload["invariants"]["invariant_status_count"] == 0
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_analysis_summary_marks_validate_table_convention_metadata_self_check_mismatch() -> None:
    report = _validate_table_source_metadata_report()
    summary_consistency = report["source_metadata_summary"]["summary_consistency"]
    summary_consistency["matched"] = False
    summary_consistency["convention_metadata_without_name_count_matched"] = False

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["accepted"] is False
    assert summary["passed_check_count"] == 3
    assert summary["failed_check_count"] == 1
    assert (
        summary[
            "validate_table_source_metadata_summary_consistency_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "validate_table_source_metadata_blocker_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "validate_table_source_metadata_convention_metadata_without_name_count"
        ]
        == 1
    )
    assert (
        "validate_table_source_metadata_convention_metadata_without_name_rows=$[0]"
        in summary["notes"]
    )

    assert (
        payload[
            "analysis_validate_table_source_metadata_summary_consistency_matched_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_validate_table_source_metadata_convention_metadata_without_name_count"
        ]
        == 1
    )
    assert payload["analysis_summaries"][0]["accepted"] is False

    host_analysis = host_payload["analysis"]
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_summary_consistency_matched_count"
        ]
        == 0
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_convention_metadata_without_name_count"
        ]
        == 1
    )
    summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    assert summaries["validate_table_source_metadata_report"]["accepted"] is False
    assert (
        "validate_table_source_metadata_convention_metadata_without_name_rows=$[0]"
        in summaries["validate_table_source_metadata_report"]["notes"]
    )
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_analysis_summary_marks_blocked_validate_table_source_metadata_report() -> None:
    report = _validate_table_source_metadata_report(ready=False)

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])

    assert summary["accepted"] is False
    assert summary["certified"] is False
    assert summary["required_check_count"] == 4
    assert summary["passed_check_count"] == 2
    assert summary["failed_check_count"] == 2
    assert summary["validate_table_source_metadata_valid_count"] == 0
    assert summary["validate_table_source_metadata_issue_count"] == 1
    assert (
        summary["validate_table_source_metadata_provenance_review_ready_count"]
        == 0
    )
    assert summary["validate_table_source_metadata_provenance_blocker_count"] == 1
    assert summary["validate_table_source_metadata_convention_mismatch_count"] == 1
    assert summary["validate_table_source_metadata_all_records_have_source_count"] == 1
    assert (
        summary[
            "validate_table_source_metadata_all_source_records_have_source_url_count"
        ]
        == 1
    )
    assert (
        summary["validate_table_source_metadata_all_source_urls_have_source_count"]
        == 1
    )
    assert (
        summary[
            "validate_table_source_metadata_all_source_urls_are_http_or_https_count"
        ]
        == 1
    )
    assert (
        "validate_table_source_metadata_provenance_blocker_codes=convention_mismatch"
        in summary["notes"]
    )
    assert "validate_table_source_metadata_convention_mismatch_rows=$[1]" in (
        summary["notes"]
    )
    assert (
        summary[
            "validate_table_source_metadata_all_conventions_match_expected_count"
        ]
        == 0
    )
    assert (
        summary[
            "validate_table_source_metadata_all_conventions_match_expected"
        ]
        is False
    )
    assert payload["analysis_validate_table_source_metadata_issue_count"] == 1
    assert (
        payload[
            "analysis_validate_table_source_metadata_convention_mismatch_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_validate_table_source_metadata_all_records_have_source_count"
        ]
        == 1
    )
    json.dumps(payload, allow_nan=False)

def test_imgui_analysis_summary_mirrors_validate_table_source_completeness_booleans() -> None:
    report = _validate_table_source_metadata_report()
    summary_mapping = report["source_metadata_summary"]
    summary_mapping["all_records_have_source"] = False
    summary_mapping["all_source_records_have_source_url"] = False
    summary_mapping["all_source_urls_have_source"] = False
    summary_mapping["all_source_urls_are_http_or_https"] = False

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    for field in (
        "validate_table_source_metadata_all_records_have_source_count",
        "validate_table_source_metadata_all_source_records_have_source_url_count",
        "validate_table_source_metadata_all_source_urls_have_source_count",
        "validate_table_source_metadata_all_source_urls_are_http_or_https_count",
    ):
        assert summary[field] == 0
        assert payload[f"analysis_{field}"] == 0
        assert host_payload["analysis"][f"analysis_{field}"] == 0
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_analysis_summary_mirrors_validate_table_source_completeness_row_pack_consistency() -> None:
    report = _validate_table_source_metadata_report()
    consistency = report["source_metadata_summary"]["summary_consistency"]
    consistency["source_completeness_row_count"] = 2
    consistency["source_completeness_row_count_matched"] = False
    consistency["source_completeness_source_count_matched"] = False
    consistency["source_completeness_source_url_count_matched"] = False
    consistency["source_completeness_invalid_url_count_matched"] = False

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert (
        summary["validate_table_source_metadata_source_completeness_row_count"]
        == 2
    )
    for field in (
        "validate_table_source_metadata_source_completeness_row_count_matched_count",
        "validate_table_source_metadata_source_completeness_source_count_matched_count",
        "validate_table_source_metadata_source_completeness_source_url_count_matched_count",
        "validate_table_source_metadata_source_completeness_invalid_url_count_matched_count",
    ):
        assert summary[field] == 0
        assert payload[f"analysis_{field}"] == 0
        assert host_payload["analysis"][f"analysis_{field}"] == 0
    assert (
        "validate_table_source_metadata_source_completeness=rows=2; "
        "row_count_matched=false; source_count_matched=false; "
        "source_url_count_matched=false; invalid_url_count_matched=false"
        in summary["notes"]
    )
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_analysis_summary_wraps_homfly_small_diagram_coverage_report() -> None:
    report = homfly_small_diagram_coverage_report()

    summary = analysis_summary_from_acceptance_report(report)

    assert summary["name"] == "HOMFLY generated small-diagram coverage"
    assert summary["source_method"] == "homfly_small_diagram_coverage_report"
    assert summary["claim_scope"] == "generated_small_signed_pd_frontier_exhaustion"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 30
    assert summary["passed_check_count"] == 30
    assert summary["failed_check_count"] == 0
    assert summary["certification_scope"] == report["claim_scope"]
    assert summary["certification_applicable_count"] == 30
    assert summary["certification_certified_count"] == 30
    assert summary["certification_uncertified_count"] == 0
    assert summary["input_certification_frontier_count"] == 0
    assert summary["input_certification_frontier_reason_count"] == 0
    assert summary["input_certification_truncated_count"] == 0
    assert summary["input_certification_iterative_attempt_count"] == report["attempt_count"]
    assert summary["input_certification_iterative_solved_count"] == 30
    assert summary["input_certification_iterative_max_solved_depth"] == 7
    assert summary["generated_case_count"] == report["case_count"]
    assert summary["generated_non_fixture_case_count"] == report["non_fixture_case_count"]
    assert summary["generated_source_notation_count"] == len(report["source_notation_summary"])
    assert summary["generated_source_summary_consistency_matched"] is True
    assert summary["generated_source_summary_count_totals_matched"] is True
    assert summary["generated_source_summary_distribution_totals_matched"] is True
    assert summary[
        "generated_source_summary_frontier_reason_counts_matched"
    ] is True
    assert summary[
        "generated_source_summary_source_notation_count_matches_fixture_count"
    ] is True
    assert summary["generated_branch_depth"] == report["branch_depth"]
    assert summary["generated_max_branch_depth"] == report["max_generated_branch_depth"]
    assert summary["generated_unique_diagram_count"] == report["unique_diagram_count"]
    assert summary["generated_unique_oriented_diagram_count"] == report[
        "unique_oriented_diagram_count"
    ]
    assert summary["generated_frontier_case_count"] == report["frontier_case_count"]
    assert summary["generated_fixture_normalization_metadata_count"] == 3
    assert summary["generated_fixture_normalization_expected_source_count"] == 3
    assert summary["generated_fixture_normalization_source_url_count"] == 1
    assert summary["generated_fixture_normalization_full_table_certified_count"] == 0
    assert (
        summary[
            "generated_fixture_normalization_arbitrary_diagram_certified_count"
        ]
        == 0
    )
    assert summary["generated_polynomial_variant_diagram_count"] == report[
        "polynomial_variant_diagram_count"
    ]
    assert summary["generated_oriented_polynomial_conflict_count"] == report[
        "oriented_polynomial_conflict_count"
    ]
    assert summary["generated_unique_evaluation_count"] == report[
        "unique_evaluation_count"
    ]
    assert summary["generated_reused_evaluation_count"] == report[
        "reused_evaluation_count"
    ]
    assert summary["bounded_homfly_maturity_path_certified_count"] == report[
        "bounded_homfly_maturity_path_certified_count"
    ]
    assert summary["bounded_homfly_maturity_path_distinct_count"] == report[
        "bounded_homfly_maturity_path_distinct_count"
    ]
    case_consistency = report["case_evidence_consistency"]
    assert summary["homfly_case_evidence_consistency_available_count"] == 1
    assert summary["homfly_case_evidence_consistency_matched_count"] == 1
    assert summary["homfly_case_evidence_consistency_mismatch_count"] == 0
    assert summary["homfly_case_evidence_consistency_case_count"] == (
        case_consistency["case_count"]
    )
    assert summary["homfly_case_evidence_consistency_checked_case_count"] == (
        case_consistency["checked_case_count"]
    )
    assert summary["homfly_case_evidence_consistency_missing_evidence_count"] == 0
    assert summary["homfly_case_evidence_maturity_path_counts_matched_count"] == 1
    assert (
        summary[
            "homfly_case_evidence_maturity_path_distinct_count_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "homfly_case_evidence_maturity_path_certified_count_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "bounded_homfly_maturity_path_recursive_frontier_exhausted_count"
        ]
        == report["case_count"]
    )
    assert "generated_cases=30" in summary["notes"]
    assert "non_fixture_cases=27" in summary["notes"]
    assert "branch_depth=1" in summary["notes"]
    assert "unique_diagrams=19" in summary["notes"]
    assert "unique_oriented_diagrams=20" in summary["notes"]
    assert "frontier_cases=0" in summary["notes"]
    assert "unique_evaluations=20" in summary["notes"]
    assert "reused_evaluations=10" in summary["notes"]
    assert "branch_depth_counts=0:3,1:27" in summary["notes"]
    consistency_note = (
        "source_notation_summary_consistency=matched=True; "
        "count_totals_matched=True; "
        "distribution_totals_matched=True; "
        "frontier_reason_counts_matched=True; "
        "source_notation_count_matches_fixture_count=True"
    )
    assert consistency_note in summary["notes"]
    assert "mismatch_count=0" in summary["notes"]
    assert (
        "source_notation_certified_cases=L2a1:7/7,3_1:10/10,4_1:13/13"
        in summary["notes"]
    )
    solved_depth_counts = ",".join(
        f"{row['solved_depth']}:{row['case_count']}"
        for row in report["solved_depth_counts"]
    )
    assert f"solved_depth_counts={solved_depth_counts}" in summary["notes"]
    source_solved_depth_counts = ",".join(
        f"{row['source_notation']}["
        + "|".join(
            f"{item['solved_depth']}:{item['case_count']}"
            for item in row["solved_depth_counts"]
        )
        + "]"
        for row in report["source_notation_summary"]
    )
    assert (
        f"source_notation_solved_depth_counts={source_solved_depth_counts}"
        in summary["notes"]
    )
    maturity_path_counts = ",".join(
        f"{row['bounded_homfly_maturity_path']}:{row['case_count']}"
        for row in report["bounded_homfly_maturity_path_counts"]
    )
    assert (
        f"bounded_homfly_maturity_paths={maturity_path_counts}"
        in summary["notes"]
    )
    assert "homfly_case_evidence_consistency=matched=True" in summary["notes"]
    assert "maturity_path_counts_matched=True" in summary["notes"]
    assert "oriented_polynomial_conflicts=0" in summary["notes"]
    assert "max_homfly_polynomials_per_oriented_diagram=1" in summary["notes"]
    assert (
        "fixture_normalization_metadata=rows=3; expected_sources=3; "
        "source_urls=1; full_table_certified=0; "
        "arbitrary_diagram_certified=0; metadata_consistency_matched=True"
        in summary["notes"]
    )
    assert report["unique_oriented_diagram_count"] == 20
    assert report["duplicate_diagram_case_count"] == 11
    assert report["polynomial_variant_diagram_count"] >= 0
    assert report["max_homfly_polynomial_count_per_diagram"] >= 1
    assert report["oriented_polynomial_conflict_count"] == 0
    assert report["max_homfly_polynomial_count_per_oriented_diagram"] == 1
    assert report["diagram_multiplicity_summary"]["multi_path_diagram_count"] == 4
    assert (
        report["diagram_multiplicity_summary"]["max_case_count_per_diagram"]
        == report["max_diagram_case_count"]
    )
    assert (
        report["diagram_multiplicity_summary"]["oriented_polynomial_conflict_count"]
        == report["oriented_polynomial_conflict_count"]
    )
    assert (
        report["diagram_multiplicity_summary"][
            "max_homfly_polynomial_count_per_diagram"
        ]
        == report["max_homfly_polynomial_count_per_diagram"]
    )

    payload = imgui_analysis_payload_from_acceptance_reports([report])
    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 30
    assert payload["analysis_passed_check_count"] == 30
    assert payload["analysis_failed_check_count"] == 0
    assert payload["analysis_certification_applicable_count"] == 30
    assert payload["analysis_certification_certified_count"] == 30
    assert payload["analysis_certification_uncertified_count"] == 0
    assert payload["analysis_input_certification_iterative_solved_count"] == 30
    assert payload["analysis_input_certification_frontier_reason_count"] == 0
    assert payload["analysis_generated_frontier_case_count"] == 0
    assert payload["analysis_generated_fixture_normalization_metadata_count"] == 3
    assert (
        payload["analysis_generated_fixture_normalization_expected_source_count"]
        == 3
    )
    assert payload["analysis_generated_fixture_normalization_source_url_count"] == 1
    assert (
        payload[
            "analysis_generated_fixture_normalization_full_table_certified_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_generated_fixture_normalization_arbitrary_diagram_certified_count"
        ]
        == 0
    )
    assert payload["analysis_generated_unique_evaluation_count"] == 20
    assert payload["analysis_generated_reused_evaluation_count"] == 10
    assert payload["analysis_bounded_homfly_maturity_path_certified_count"] == (
        report["bounded_homfly_maturity_path_certified_count"]
    )
    assert payload[
        "analysis_bounded_homfly_maturity_path_recursive_frontier_exhausted_count"
    ] == report["case_count"]
    assert payload["analysis_homfly_case_evidence_consistency_available_count"] == 1
    assert payload["analysis_homfly_case_evidence_consistency_matched_count"] == 1
    assert payload["analysis_homfly_case_evidence_consistency_case_count"] == (
        report["case_count"]
    )
    assert (
        payload["analysis_homfly_case_evidence_maturity_path_counts_matched_count"]
        == 1
    )
    assert payload["analysis_summaries"][0][
        "generated_source_summary_consistency_matched"
    ] is True
    assert payload["analysis_summaries"][0][
        "generated_source_summary_count_totals_matched"
    ] is True
    assert payload["analysis_summaries"][0][
        "generated_source_summary_distribution_totals_matched"
    ] is True
    assert payload["analysis_summaries"][0][
        "generated_source_summary_frontier_reason_counts_matched"
    ] is True
    assert payload["analysis_summaries"][0][
        "generated_source_summary_source_notation_count_matches_fixture_count"
    ] is True
    assert payload["analysis_generated_source_summary_consistency_matched"] is True
    assert payload["analysis_generated_source_summary_count_totals_matched"] is True
    assert (
        payload["analysis_generated_source_summary_distribution_totals_matched"]
        is True
    )
    assert (
        payload["analysis_generated_source_summary_frontier_reason_counts_matched"]
        is True
    )
    assert (
        payload[
            "analysis_generated_source_summary_source_notation_count_matches_fixture_count"
        ]
        is True
    )
    assert "generated_cases=30" in payload["analysis_summaries"][0]["notes"]
    assert "frontier_cases=0" in payload["analysis_summaries"][0]["notes"]
    assert consistency_note in payload["analysis_summaries"][0]["notes"]
    assert (
        "source_notation_certified_cases=L2a1:7/7,3_1:10/10,4_1:13/13"
        in payload["analysis_summaries"][0]["notes"]
    )
    assert "oriented_polynomial_conflicts=0" in payload["analysis_summaries"][0]["notes"]
    assert (
        "fixture_normalization_metadata=rows=3"
        in payload["analysis_summaries"][0]["notes"]
    )

    legacy_report = dict(report)
    legacy_report.pop("source_notation_summary_consistency")
    legacy_summary = analysis_summary_from_acceptance_report(legacy_report)
    for field in (
        "generated_source_summary_consistency_matched",
        "generated_source_summary_count_totals_matched",
        "generated_source_summary_distribution_totals_matched",
        "generated_source_summary_frontier_reason_counts_matched",
        "generated_source_summary_source_notation_count_matches_fixture_count",
    ):
        assert legacy_summary[field] is None
    legacy_payload = imgui_analysis_payload_from_acceptance_reports([legacy_report])
    for field in (
        "analysis_generated_source_summary_consistency_matched",
        "analysis_generated_source_summary_count_totals_matched",
        "analysis_generated_source_summary_distribution_totals_matched",
        "analysis_generated_source_summary_frontier_reason_counts_matched",
        "analysis_generated_source_summary_source_notation_count_matches_fixture_count",
    ):
        assert legacy_payload[field] is None
    assert "source_notation_summary_consistency=" not in legacy_summary["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(legacy_payload, allow_nan=False)

def test_imgui_analysis_summary_preserves_homfly_fixture_normalization_metadata_mismatch() -> None:
    report = homfly_small_diagram_coverage_report()
    consistency = report["fixture_normalization_metadata_consistency"]
    report["fixture_normalization_metadata_consistency"] = {
        **consistency,
        "matched": False,
        "mismatch_count": 1,
        "first_mismatch": {
            "kind": "fixture_normalization_metadata",
            "field": "fixture_source_url",
            "report_value": "https://example.invalid/stale-source",
            "source_value": None,
            "source_notation": "L2a1",
        },
        "mismatch_witnesses": [
            {
                "kind": "fixture_normalization_metadata",
                "field": "fixture_source_url",
                "report_value": "https://example.invalid/stale-source",
                "source_value": None,
                "source_notation": "L2a1",
            }
        ],
    }
    note_token = (
        "fixture_normalization_metadata=rows=3; expected_sources=3; "
        "source_urls=1; full_table_certified=0; "
        "arbitrary_diagram_certified=0; metadata_consistency_matched=False; "
        "metadata_mismatch_count=1; "
        "metadata_first_mismatch=fixture_normalization_metadata:fixture_source_url; "
        "metadata_first_mismatch_source=L2a1"
    )

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["generated_fixture_normalization_metadata_count"] == 3
    assert summary["generated_fixture_normalization_expected_source_count"] == 3
    assert summary["generated_fixture_normalization_source_url_count"] == 1
    assert note_token in summary["notes"]
    assert note_token in payload["analysis_summaries"][0]["notes"]
    assert note_token in host_payload["analysis"]["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_invariant_status_wraps_homfly_case_evidence_consistency() -> None:
    report = homfly_small_diagram_coverage_report()

    status = invariant_status_from_acceptance_report(report)
    payload = imgui_invariant_status_payload_from_acceptance_reports([report])

    assert status["homfly_case_evidence_consistency_available_count"] == 1
    assert status["homfly_case_evidence_consistency_matched_count"] == 1
    assert status["homfly_case_evidence_consistency_mismatch_count"] == 0
    assert status["homfly_case_evidence_consistency_case_count"] == (
        report["case_count"]
    )
    assert status["homfly_case_evidence_consistency_checked_case_count"] == (
        report["case_evidence_consistency"]["checked_case_count"]
    )
    assert status["homfly_case_evidence_consistency_missing_evidence_count"] == 0
    assert status["homfly_case_evidence_maturity_path_counts_matched_count"] == 1
    assert (
        status[
            "homfly_case_evidence_maturity_path_distinct_count_matched_count"
        ]
        == 1
    )
    assert (
        status[
            "homfly_case_evidence_maturity_path_certified_count_matched_count"
        ]
        == 1
    )
    assert "homfly_case_evidence_consistency=matched=True" in status["notes"]
    assert (
        payload["invariant_homfly_case_evidence_consistency_available_count"]
        == 1
    )
    assert (
        payload["invariant_homfly_case_evidence_consistency_matched_count"]
        == 1
    )
    assert payload["invariant_homfly_case_evidence_consistency_case_count"] == (
        report["case_count"]
    )
    assert (
        payload[
            "invariant_homfly_case_evidence_maturity_path_counts_matched_count"
        ]
        == 1
    )
    json.dumps(payload, allow_nan=False)


def test_imgui_payloads_preserve_homfly_case_evidence_consistency_mismatch() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_depth=0,
        max_nodes=128,
    )
    consistency = report["case_evidence_consistency"]
    report["case_evidence_consistency"] = {
        **consistency,
        "matched": False,
        "checked_case_count": consistency["checked_case_count"] - 1,
        "missing_evidence_count": 2,
        "bounded_homfly_maturity_path_counts_matched": False,
        "bounded_homfly_maturity_path_distinct_count_matched": False,
        "bounded_homfly_maturity_path_certified_count_matched": False,
        "mismatch_count": 2,
    }
    mutated_consistency = report["case_evidence_consistency"]
    expected = {
        "homfly_case_evidence_consistency_available_count": 1,
        "homfly_case_evidence_consistency_matched_count": 0,
        "homfly_case_evidence_consistency_mismatch_count": 1,
        "homfly_case_evidence_consistency_case_count": (
            mutated_consistency["case_count"]
        ),
        "homfly_case_evidence_consistency_checked_case_count": (
            mutated_consistency["checked_case_count"]
        ),
        "homfly_case_evidence_consistency_missing_evidence_count": 2,
        "homfly_case_evidence_maturity_path_counts_matched_count": 0,
        "homfly_case_evidence_maturity_path_distinct_count_matched_count": 0,
        "homfly_case_evidence_maturity_path_certified_count_matched_count": 0,
    }
    note_tokens = [
        "homfly_case_evidence_consistency=matched=False",
        (
            f"checked={mutated_consistency['checked_case_count']}/"
            f"{mutated_consistency['case_count']}"
        ),
        "missing=2",
        "maturity_path_counts_matched=False",
        "maturity_path_distinct_matched=False",
        "maturity_path_certified_matched=False",
        "mismatch_count=2",
    ]

    summary = analysis_summary_from_acceptance_report(report)
    analysis_payload = imgui_analysis_payload_from_acceptance_reports([report])
    invariant_payload = imgui_invariant_status_payload_from_acceptance_reports(
        [report]
    )
    host_payload = imgui_host_payload_from_acceptance_reports(
        [report],
        analysis_reports=[report],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )
    status = invariant_payload["invariant_statuses"][0]
    host_summary = host_payload["analysis"]["analysis_summaries"][0]
    host_status = host_payload["invariants"]["invariant_statuses"][0]

    for key, value in expected.items():
        assert summary[key] == value
        assert status[key] == value
        assert analysis_payload[f"analysis_{key}"] == value
        assert invariant_payload[f"invariant_{key}"] == value
        assert host_payload["analysis"][f"analysis_{key}"] == value
        assert host_payload["invariants"][f"invariant_{key}"] == value

    assert analysis_payload[
        "analysis_homfly_case_evidence_consistency_mismatch_count"
    ] == 1
    assert invariant_payload[
        "invariant_homfly_case_evidence_consistency_missing_evidence_count"
    ] == 2

    for notes in (
        summary["notes"],
        status["notes"],
        host_summary["notes"],
        host_status["notes"],
    ):
        for token in note_tokens:
            assert token in notes
    json.dumps(host_payload, allow_nan=False)
    json.dumps(analysis_payload, allow_nan=False)
    json.dumps(invariant_payload, allow_nan=False)

def test_imgui_analysis_summary_exposes_homfly_source_summary_mismatch_witness() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_depth=0,
        max_nodes=128,
    )
    report["source_notation_summary_consistency"] = {
        **report["source_notation_summary_consistency"],
        "matched": False,
        "count_totals_matched": False,
        "mismatch_count": 1,
        "first_mismatch": {
            "kind": "count_total",
            "field": "case_count",
            "tags": ["count"],
            "report_value": report["case_count"] + 1,
            "source_value": report["case_count"],
        },
    }

    summary = analysis_summary_from_acceptance_report(report)

    assert summary["generated_source_summary_consistency_matched"] is False
    assert "source_notation_summary_consistency=matched=False" in summary["notes"]
    assert "count_totals_matched=False" in summary["notes"]
    assert "mismatch_count=1" in summary["notes"]
    assert "first_mismatch=count_total:case_count" in summary["notes"]
    assert "first_mismatch_tags=count" in summary["notes"]


def test_imgui_payloads_preserve_generated_source_summary_consistency_mismatch() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_depth=0,
        max_nodes=128,
    )
    report["source_notation_summary_consistency"] = {
        **report["source_notation_summary_consistency"],
        "matched": False,
        "count_totals_matched": False,
        "mismatch_count": 1,
        "first_mismatch": {
            "kind": "count_total",
            "field": "case_count",
            "tags": ["count"],
            "report_value": report["case_count"] + 1,
            "source_value": report["case_count"],
        },
    }
    clean_alexander = multivariable_alexander_signed_pd_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_minors=64,
    )

    payload = imgui_analysis_payload_from_acceptance_reports(
        [report, clean_alexander]
    )
    host_payload = imgui_host_payload_from_acceptance_reports(
        [clean_alexander],
        analysis_reports=[report, clean_alexander],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )
    summary = payload["analysis_summaries"][0]
    host_summary = host_payload["analysis"]["analysis_summaries"][0]

    assert summary["generated_source_summary_consistency_matched"] is False
    assert summary["generated_source_summary_count_totals_matched"] is False
    assert payload["analysis_generated_source_summary_consistency_matched"] is False
    assert payload["analysis_generated_source_summary_count_totals_matched"] is False
    assert (
        payload["analysis_generated_source_summary_distribution_totals_matched"]
        is True
    )
    assert (
        host_payload["analysis"]["analysis_generated_source_summary_consistency_matched"]
        is False
    )
    assert (
        host_payload["analysis"][
            "analysis_generated_source_summary_count_totals_matched"
        ]
        is False
    )
    for notes in (summary["notes"], host_summary["notes"]):
        assert "source_notation_summary_consistency=matched=False" in notes
        assert "count_totals_matched=False" in notes
        assert "mismatch_count=1" in notes
        assert "first_mismatch=count_total:case_count" in notes
        assert "first_mismatch_tags=count" in notes
    json.dumps(host_payload, allow_nan=False)
    json.dumps(payload, allow_nan=False)

def test_imgui_analysis_summary_wraps_homfly_frontier_case_count() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_depth=0,
        max_nodes=128,
    )

    summary = analysis_summary_from_acceptance_report(report)

    assert report["frontier_count"] == 6
    assert report["frontier_case_count"] == 6
    assert summary["required_check_count"] == 7
    assert summary["passed_check_count"] == 1
    assert summary["failed_check_count"] == 6
    assert summary["certification_applicable_count"] == 7
    assert summary["certification_certified_count"] == 1
    assert summary["certification_uncertified_count"] == 6
    assert summary["input_certification_frontier_count"] == 6
    assert summary["input_certification_frontier_reason_count"] == 1
    assert summary["generated_frontier_case_count"] == 6
    assert "frontier_cases=6" in summary["notes"]
    assert "branch_depth_counts=0:1,1:6" in summary["notes"]
    assert "frontier_reason_counts=max_depth:6/6" in summary["notes"]
    assert "frontier_branch_depth_counts=0:1,1:5" in summary["notes"]
    assert "unique_evaluations=5" in summary["notes"]
    assert "reused_evaluations=2" in summary["notes"]


def test_imgui_analysis_summary_wraps_homfly_max_node_frontier_reason() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_depth=8,
        max_nodes=1,
    )

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])

    assert report["frontier_case_count"] == 6
    assert report["frontier_reasons"] == ["max_nodes"]
    assert report["frontier_reason_counts"] == [
        {"frontier_reason": "max_nodes", "case_count": 6, "frontier_count": 12}
    ]
    assert summary["generated_frontier_case_count"] == 6
    assert summary["input_certification_frontier_reason_count"] == 1
    assert "frontier_reason_counts=max_nodes:6/12" in summary["notes"]
    assert (
        "truncated_source_kind_counts=fixture_root:1,one_step_skein_branch:5"
        in summary["notes"]
    )
    assert payload["analysis_generated_frontier_case_count"] == 6
    assert payload["analysis_input_certification_frontier_reason_count"] == 1
    assert "frontier_reason_counts=max_nodes:6/12" in payload[
        "analysis_summaries"
    ][0]["notes"]
    assert (
        "truncated_source_kind_counts=fixture_root:1,one_step_skein_branch:5"
        in payload["analysis_summaries"][0]["notes"]
    )
    json.dumps(payload, allow_nan=False)

def test_imgui_analysis_summary_flattens_homfly_frontier_witness_summary() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_depth=0,
        max_nodes=128,
    )

    summary = analysis_summary_from_acceptance_report(report)
    witness_summary = report["frontier_witness_summary"]
    compact_count_keys = (
        "recursive_path_prefix_count",
        "source_kind_count",
        "branch_count",
    )

    assert witness_summary["witness_count"] == 6
    assert witness_summary["reason_counts"] == [
        {"reason": "max_depth", "witness_count": 6}
    ]
    for summary_key in compact_count_keys:
        rows_key = (
            summary_key.removesuffix("_count") + "_counts"
        )
        assert witness_summary[summary_key] == len(witness_summary[rows_key])
    assert summary["frontier_witness_summary_count"] == witness_summary[
        "witness_count"
    ]
    assert summary["frontier_witness_summary_truncated"] == 0
    assert summary["frontier_witness_summary_reason_count"] == len(
        witness_summary["reason_counts"]
    )
    for summary_key in compact_count_keys:
        row_key = f"frontier_witness_summary_{summary_key}"
        assert summary[row_key] == witness_summary[summary_key]
    assert summary["frontier_witness_summary_min_depth"] == witness_summary[
        "min_depth"
    ]
    assert summary["frontier_witness_summary_max_depth"] == witness_summary[
        "max_depth"
    ]
    assert summary["frontier_witness_summary_min_branch_depth"] == witness_summary[
        "min_branch_depth"
    ]
    assert summary["frontier_witness_summary_max_branch_depth"] == witness_summary[
        "max_branch_depth"
    ]
    pressure = witness_summary["run_cap_frontier_pressure"]
    pressure_expected = {
        "frontier_witness_summary_pressure_total_frontier_count": pressure[
            "frontier_count"
        ],
        "frontier_witness_summary_pressure_visible_witness_count": pressure[
            "witness_count"
        ],
        "frontier_witness_summary_pressure_missing_frontier_count": pressure[
            "unwitnessed_frontier_count"
        ],
        "frontier_witness_summary_pressure_all_frontiers_have_visible_witness": (
            1 if pressure["all_frontier_witnessed"] else 0
        ),
        "frontier_witness_summary_pressure_reason_count": pressure["reason_count"],
    }
    for key, value in pressure_expected.items():
        assert summary[key] == value
    assert "frontier_witness_summary=witnesses=6" in summary["notes"]
    assert "reasons=1" in summary["notes"]
    assert "recursive_path_prefix_count=" in summary["notes"]
    assert "source_kind_count=" in summary["notes"]
    assert "branch_count=" in summary["notes"]
    assert "depth=0..0" in summary["notes"]
    assert "frontier_witness_pressure=total_frontiers=6" in summary["notes"]
    assert "visible_witnesses=6" in summary["notes"]
    assert "missing_frontiers=0" in summary["notes"]
    assert "all_visible=True" in summary["notes"]

    payload = imgui_analysis_payload_from_acceptance_reports([report])
    assert payload["analysis_frontier_witness_summary_count"] == 6
    assert payload["analysis_frontier_witness_summary_truncated"] == 0
    assert payload["analysis_frontier_witness_summary_reason_count"] == 1
    for summary_key in compact_count_keys:
        row_key = f"frontier_witness_summary_{summary_key}"
        aggregate_key = f"analysis_{row_key}"
        assert payload[aggregate_key] == witness_summary[summary_key]
    assert payload["analysis_frontier_witness_summary_min_depth"] == 0
    assert payload["analysis_frontier_witness_summary_max_depth"] == 0
    assert payload["analysis_frontier_witness_summary_min_branch_depth"] == (
        witness_summary["min_branch_depth"]
    )
    assert payload["analysis_frontier_witness_summary_max_branch_depth"] == (
        witness_summary["max_branch_depth"]
    )
    for key, value in pressure_expected.items():
        assert payload[f"analysis_{key}"] == value

    multi_payload = imgui_analysis_payload_from_acceptance_reports(
        [report, report]
    )
    invariant_payload = imgui_invariant_status_payload_from_acceptance_reports(
        [report, report]
    )
    host_payload = imgui_host_payload_from_acceptance_reports(
        [report, report],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )
    statuses = invariant_payload["invariant_statuses"]
    assert statuses[0]["frontier_witness_summary_source_kind_count"] == (
        witness_summary["source_kind_count"]
    )
    for key, value in pressure_expected.items():
        assert statuses[0][key] == value
    for summary_key in compact_count_keys:
        row_key = f"frontier_witness_summary_{summary_key}"
        expected_total = witness_summary[summary_key] * 2
        assert multi_payload[f"analysis_{row_key}"] == (
            expected_total
        )
        assert invariant_payload[f"invariant_{row_key}"] == (
            expected_total
        )
        assert host_payload["analysis"][f"analysis_{row_key}"] == expected_total
        assert host_payload["invariants"][f"invariant_{row_key}"] == expected_total
        assert host_payload[f"analysis_{row_key}"] == expected_total
        assert host_payload[f"invariant_{row_key}"] == expected_total
    for key, value in pressure_expected.items():
        expected_total = value * 2
        assert multi_payload[f"analysis_{key}"] == expected_total
        assert invariant_payload[f"invariant_{key}"] == expected_total
        assert host_payload["analysis"][f"analysis_{key}"] == expected_total
        assert host_payload["invariants"][f"invariant_{key}"] == expected_total
        assert host_payload[f"analysis_{key}"] == expected_total
        assert host_payload[f"invariant_{key}"] == expected_total

    legacy_report = dict(report)
    legacy_report.pop("frontier_witness_summary")
    legacy_report["frontier_witnesses"] = [
        {
            "reason": "legacy-only",
            "source_kind": "legacy",
            "branch": "L",
            "recursive_path": ["root", "left"],
        }
    ]
    legacy_summary = analysis_summary_from_acceptance_report(legacy_report)
    for key in (
        "frontier_witness_summary_count",
        "frontier_witness_summary_truncated",
        "frontier_witness_summary_reason_count",
        "frontier_witness_summary_recursive_path_prefix_count",
        "frontier_witness_summary_source_kind_count",
        "frontier_witness_summary_branch_count",
        "frontier_witness_summary_min_depth",
        "frontier_witness_summary_max_depth",
        "frontier_witness_summary_min_branch_depth",
        "frontier_witness_summary_max_branch_depth",
        "frontier_witness_summary_pressure_total_frontier_count",
        "frontier_witness_summary_pressure_visible_witness_count",
        "frontier_witness_summary_pressure_missing_frontier_count",
        "frontier_witness_summary_pressure_all_frontiers_have_visible_witness",
        "frontier_witness_summary_pressure_reason_count",
    ):
        assert legacy_summary[key] == 0
    assert "frontier_witness_summary=" not in legacy_summary["notes"]
    assert "frontier_witness_pressure=" not in legacy_summary["notes"]
    legacy_payload = imgui_analysis_payload_from_acceptance_reports([legacy_report])
    for key in (
        "analysis_frontier_witness_summary_count",
        "analysis_frontier_witness_summary_truncated",
        "analysis_frontier_witness_summary_reason_count",
        "analysis_frontier_witness_summary_recursive_path_prefix_count",
        "analysis_frontier_witness_summary_source_kind_count",
        "analysis_frontier_witness_summary_branch_count",
        "analysis_frontier_witness_summary_min_depth",
        "analysis_frontier_witness_summary_max_depth",
        "analysis_frontier_witness_summary_min_branch_depth",
        "analysis_frontier_witness_summary_max_branch_depth",
        "analysis_frontier_witness_summary_pressure_total_frontier_count",
        "analysis_frontier_witness_summary_pressure_visible_witness_count",
        "analysis_frontier_witness_summary_pressure_missing_frontier_count",
        "analysis_frontier_witness_summary_pressure_all_frontiers_have_visible_witness",
        "analysis_frontier_witness_summary_pressure_reason_count",
    ):
        assert legacy_payload[key] == 0
    legacy_invariant_payload = (
        imgui_invariant_status_payload_from_acceptance_reports([legacy_report])
    )
    legacy_host_payload = imgui_host_payload_from_acceptance_reports(
        [legacy_report],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )
    for key in (
        "frontier_witness_summary_recursive_path_prefix_count",
        "frontier_witness_summary_source_kind_count",
        "frontier_witness_summary_branch_count",
        "frontier_witness_summary_pressure_total_frontier_count",
        "frontier_witness_summary_pressure_visible_witness_count",
        "frontier_witness_summary_pressure_missing_frontier_count",
        "frontier_witness_summary_pressure_all_frontiers_have_visible_witness",
        "frontier_witness_summary_pressure_reason_count",
    ):
        assert legacy_invariant_payload[f"invariant_{key}"] == 0
        assert legacy_host_payload[f"analysis_{key}"] == 0
        assert legacy_host_payload[f"invariant_{key}"] == 0
    json.dumps(multi_payload, allow_nan=False)
    json.dumps(invariant_payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)
    json.dumps(legacy_invariant_payload, allow_nan=False)
    json.dumps(legacy_host_payload, allow_nan=False)
    json.dumps(payload, allow_nan=False)
    json.dumps(legacy_payload, allow_nan=False)

def test_imgui_payloads_flatten_homfly_completion_blocker_provenance() -> None:
    provenance = {
        "method": "homfly_completion_blocker_provenance",
        "claim_scope": "bounded_non_claim_completion_blocker_provenance",
        "matched": True,
        "completion_blocker_code": "arbitrary_diagram_coverage_not_certified",
        "completion_blocked": True,
        "arbitrary_diagram_coverage_certified": False,
        "non_claim_matched": True,
        "gate_pressure_consistency_matched": True,
        "frontier_pressure_counts_matched": True,
        "frontier_witness_consistency_matched": True,
        "terminal_audit_consistency_matched": True,
        "source_fields": [
            "arbitrary_diagram_completion_gate.blocked",
            "arbitrary_diagram_completion_gate.gate_pressure_consistency",
            "arbitrary_diagram_completion_gate.frontier_witnesses",
        ],
    }
    report = {
        "method": "homfly_input_certification_evidence",
        "claim_scope": "recursive_frontier_exhaustion_for_one_signed_pd_input",
        "homfly_polynomial": "P",
        "certified_for_input": False,
        "frontier_exhausted": False,
        "terminal_contribution_audit_skipped": True,
        "frontier_count": 1,
        "frontier_reason_count": 1,
        "arbitrary_diagram_completion_gate": {
            "completion_blocker_provenance": provenance,
        },
        "homfly_completion_blockers": [
            "arbitrary_diagram_coverage_not_certified",
        ],
        "homfly_completion_blocker_count": 1,
        "homfly_completion_blocker_details": [
            {
                "code": "arbitrary_diagram_coverage_not_certified",
                "severity": "blocking",
                "scope": "homfly_completion",
                "provenance": provenance,
            }
        ],
        "homfly_completion_blocker_detail_count": 1,
        "skipped": False,
        "notes": [],
    }
    expected = {
        "homfly_completion_blocker_provenance_matched": 1,
        "homfly_completion_blocker_provenance_non_claim_matched": 1,
        "homfly_completion_blocker_provenance_gate_pressure_matched": 1,
        "homfly_completion_blocker_provenance_frontier_pressure_matched": 1,
        "homfly_completion_blocker_provenance_frontier_witness_matched": 1,
        "homfly_completion_blocker_provenance_terminal_audit_matched": 1,
        "homfly_completion_blocker_provenance_source_field_count": 3,
    }

    summary = analysis_summary_from_acceptance_report(report)
    invariant_payload = imgui_invariant_status_payload_from_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [report],
        analysis_reports=[report],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )
    status = invariant_payload["invariant_statuses"][0]
    host_status = host_payload["invariants"]["invariant_statuses"][0]
    for key, value in expected.items():
        assert summary[key] == value
        assert invariant_payload[f"invariant_{key}"] == value
        assert host_payload["analysis"][f"analysis_{key}"] == value
        assert host_payload["invariants"][f"invariant_{key}"] == value
        assert host_payload[f"analysis_{key}"] == value
        assert host_payload[f"invariant_{key}"] == value
        assert status[key] == value
        assert host_status[key] == value
    assert "homfly_completion_blocker_provenance=matched=True" in summary["notes"]
    assert "non_claim=True" in summary["notes"]
    assert "source_fields=3" in summary["notes"]
    assert (
        "blocker=arbitrary_diagram_coverage_not_certified"
        in summary["notes"]
    )

    legacy_report = json.loads(json.dumps(report))
    legacy_report.pop("arbitrary_diagram_completion_gate")
    legacy_report["homfly_completion_blocker_details"][0].pop("provenance")
    legacy_summary = analysis_summary_from_acceptance_report(legacy_report)
    for key in expected:
        assert legacy_summary[key] == 0
    assert "homfly_completion_blocker_provenance=" not in legacy_summary["notes"]
    json.dumps(invariant_payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_payloads_preserve_homfly_completion_blocker_provenance_mismatch() -> None:
    provenance = {
        "method": "homfly_completion_blocker_provenance",
        "claim_scope": "bounded_non_claim_completion_blocker_provenance",
        "matched": False,
        "completion_blocker_code": "arbitrary_diagram_coverage_not_certified",
        "completion_blocked": True,
        "arbitrary_diagram_coverage_certified": False,
        "non_claim_matched": False,
        "gate_pressure_consistency_matched": False,
        "frontier_pressure_counts_matched": False,
        "frontier_witness_consistency_matched": False,
        "terminal_audit_consistency_matched": False,
        "source_fields": [
            "arbitrary_diagram_completion_gate.blocked",
            "arbitrary_diagram_completion_gate.frontier_witnesses",
        ],
    }
    report = {
        "method": "homfly_input_certification_evidence",
        "claim_scope": "recursive_frontier_exhaustion_for_one_signed_pd_input",
        "homfly_polynomial": "P",
        "certified_for_input": False,
        "frontier_exhausted": False,
        "terminal_contribution_audit_skipped": True,
        "frontier_count": 1,
        "frontier_reason_count": 1,
        "arbitrary_diagram_completion_gate": {
            "completion_blocker_provenance": provenance,
        },
        "homfly_completion_blockers": [
            "arbitrary_diagram_coverage_not_certified",
        ],
        "homfly_completion_blocker_count": 1,
        "homfly_completion_blocker_details": [
            {
                "code": "arbitrary_diagram_coverage_not_certified",
                "severity": "blocking",
                "scope": "homfly_completion",
                "provenance": provenance,
            }
        ],
        "homfly_completion_blocker_detail_count": 1,
        "skipped": False,
        "notes": [],
    }
    expected = {
        "homfly_completion_blocker_provenance_matched": 0,
        "homfly_completion_blocker_provenance_non_claim_matched": 0,
        "homfly_completion_blocker_provenance_gate_pressure_matched": 0,
        "homfly_completion_blocker_provenance_frontier_pressure_matched": 0,
        "homfly_completion_blocker_provenance_frontier_witness_matched": 0,
        "homfly_completion_blocker_provenance_terminal_audit_matched": 0,
        "homfly_completion_blocker_provenance_source_field_count": 2,
    }
    note_token = (
        "homfly_completion_blocker_provenance=matched=False; "
        "non_claim=False; gate_pressure=False; frontier_pressure=False; "
        "frontier_witness=False; terminal_audit=False; source_fields=2; "
        "blocker=arbitrary_diagram_coverage_not_certified"
    )

    summary = analysis_summary_from_acceptance_report(report)
    invariant_payload = imgui_invariant_status_payload_from_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [report],
        analysis_reports=[report],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )
    status = invariant_payload["invariant_statuses"][0]
    host_status = host_payload["invariants"]["invariant_statuses"][0]

    for key, value in expected.items():
        assert summary[key] == value
        assert invariant_payload[f"invariant_{key}"] == value
        assert host_payload["analysis"][f"analysis_{key}"] == value
        assert host_payload["invariants"][f"invariant_{key}"] == value
        assert host_payload[f"analysis_{key}"] == value
        assert host_payload[f"invariant_{key}"] == value
        assert status[key] == value
        assert host_status[key] == value
    assert note_token in summary["notes"]
    assert note_token in status["notes"]
    assert note_token in host_payload["analysis"]["analysis_summaries"][0]["notes"]
    assert note_token in host_status["notes"]
    json.dumps(host_payload, allow_nan=False)
    json.dumps(invariant_payload, allow_nan=False)


def test_imgui_analysis_summary_wraps_signed_pd_role_order_candidates_report() -> None:
    report = {
        "method": "signed_pd_role_order_candidates_report",
        "input": {
            "signed_pd_revision": 123,
        },
        "status": "ambiguous",
        "candidate_count": 16,
        "strict_candidate_count": 16,
        "unique_strict_global_role_order": None,
        "invariant_signatures": {
            "requested": True,
            "evaluated_candidate_count": 2,
            "skipped_candidate_count": 14,
            "homfly_signature_count": 2,
            "alexander_signature_count": 1,
            "combined_signature_count": 2,
            "homfly_certified_candidate_count": 2,
            "homfly_frontier_count": 0,
            "homfly_frontier_reason_count": 0,
            "alexander_bounded_scanned_gcd_certified_candidate_count": 2,
            "alexander_complete_scanned_gcd_certified_candidate_count": 2,
            "alexander_quotient_gcd_certified_candidate_count": 2,
            "alexander_failed_nonzero_minor_count": 0,
            "groups": [
                {
                    "homfly_polynomial": "H0",
                    "multivariable_alexander_polynomial": "1",
                    "role_orders": [[0, 1, 2, 3]],
                    "count": 1,
                },
                {
                    "homfly_polynomial": "H1",
                    "multivariable_alexander_polynomial": "1",
                    "role_orders": [[0, 1, 3, 2]],
                    "count": 1,
                },
            ],
        },
        "notes": ["multiple strict global role_order candidates matched"],
    }

    summary = analysis_summary_from_acceptance_report(report)

    assert summary["name"] == "signed-PD role-order candidates"
    assert summary["source_method"] == "signed_pd_role_order_candidates_report"
    assert summary["claim_scope"] == (
        "strict_global_signed_pd_role_order_candidate_diagnostic"
    )
    assert summary["has_source_signed_pd_revision"] is True
    assert summary["source_signed_pd_revision"] == 123
    assert summary["accepted"] is False
    assert summary["certified"] is False
    assert summary["required_check_count"] == 16
    assert summary["passed_check_count"] == 0
    assert summary["failed_check_count"] == 16
    assert summary["certification_scope"] == summary["claim_scope"]
    assert summary["certification_applicable_count"] == 16
    assert summary["certification_certified_count"] == 0
    assert summary["certification_uncertified_count"] == 16
    assert "signature_evaluated=2" in summary["notes"]
    assert "signed_pd_revision=123" in summary["notes"]
    assert "signature_resolution=partially_distinguishes_candidates" in summary["notes"]
    assert "signature_all_strict_evaluated=false" in summary["notes"]
    assert summary["role_order_signature_resolution_status"] == (
        "partially_distinguishes_candidates"
    )
    assert summary["role_order_signature_resolution_status_code"] == 5
    assert summary["role_order_signature_strict_candidate_count"] == 16
    assert summary["role_order_signature_all_strict_candidates_evaluated"] is False
    assert summary["role_order_signature_all_strict_candidates_evaluated_count"] == 0
    assert "signature_groups=2" in summary["notes"]
    assert "homfly_certified=2" in summary["notes"]
    assert "alexander_gcd_certified=2" in summary["notes"]
    assert "alexander_complete_gcd_certified=2" in summary["notes"]
    assert "alexander_failed_nonzero_minors=0" in summary["notes"]
    assert summary["role_order_signature_evaluated_candidate_count"] == 2
    assert summary["role_order_signature_skipped_candidate_count"] == 14
    assert summary["role_order_signature_group_count"] == 2
    assert summary["role_order_signature_homfly_certified_candidate_count"] == 2
    assert summary[
        "role_order_signature_alexander_bounded_scanned_gcd_certified_candidate_count"
    ] == 2
    assert summary[
        "role_order_signature_alexander_complete_scanned_gcd_certified_candidate_count"
    ] == 2
    assert summary[
        "role_order_signature_alexander_quotient_gcd_certified_candidate_count"
    ] == 2
    assert summary["role_order_signature_alexander_failed_nonzero_minor_count"] == 0

    top_level_revision_report = json.loads(json.dumps(report))
    top_level_revision_report["input"] = {}
    top_level_revision_report["signed_pd_revision"] = 124
    top_level_revision_summary = analysis_summary_from_acceptance_report(
        top_level_revision_report,
    )
    assert top_level_revision_summary["has_source_signed_pd_revision"] is True
    assert top_level_revision_summary["source_signed_pd_revision"] == 124
    assert "signed_pd_revision=124" in top_level_revision_summary["notes"]

    payload = imgui_analysis_payload_from_acceptance_reports([report])
    assert payload["analysis_summary_count"] == 1
    assert payload["source_signed_pd_revision"] == 123
    assert payload["analysis_required_check_count"] == 16
    assert payload["analysis_passed_check_count"] == 0
    assert payload["analysis_failed_check_count"] == 16
    assert payload["analysis_certification_applicable_count"] == 16
    assert payload["analysis_certification_certified_count"] == 0
    assert payload["analysis_role_order_signature_strict_candidate_count"] == 16
    assert (
        payload["analysis_role_order_signature_all_strict_candidates_evaluated_count"]
        == 0
    )
    assert payload["analysis_role_order_signature_evaluated_candidate_count"] == 2
    assert payload["analysis_role_order_signature_skipped_candidate_count"] == 14
    assert payload[
        "analysis_role_order_signature_alexander_bounded_scanned_gcd_certified_candidate_count"
    ] == 2
    assert payload[
        "analysis_role_order_signature_alexander_complete_scanned_gcd_certified_candidate_count"
    ] == 2

    conflicting_payload = imgui_analysis_payload_from_acceptance_reports(
        [report, top_level_revision_report]
    )
    assert "source_signed_pd_revision" not in conflicting_payload
    assert payload[
        "analysis_role_order_signature_alexander_failed_nonzero_minor_count"
    ] == 0
    assert payload["analysis_certification_uncertified_count"] == 16
    json.dumps(payload, allow_nan=False)
    json.dumps(conflicting_payload, allow_nan=False)

def test_imgui_analysis_summary_wraps_source_table_invariant_audit() -> None:
    report = get_diagram_fixture("L6a4").source_table_invariant_audit(
        max_candidates=8,
    )

    summary = analysis_summary_from_acceptance_report(report)

    assert summary["name"] == "source-table invariant audit"
    assert summary["source_method"] == "diagram_fixture_source_table_invariant_audit"
    assert summary["claim_scope"] == "source_table_invariant_candidate_convergence"
    assert summary["accepted"] is False
    assert summary["certified"] is False
    assert summary["required_check_count"] == 3
    assert summary["passed_check_count"] == 2
    assert summary["failed_check_count"] == 1
    assert summary["certification_scope"] == summary["claim_scope"]
    assert summary["certification_applicable_count"] == 3
    assert summary["certification_certified_count"] == 2
    assert summary["certification_uncertified_count"] == 1
    assert "matched=jones,multivariable_alexander_numerator" in summary["notes"]
    assert "uncomputed=homfly" in summary["notes"]
    assert (
        "source_match_statuses="
        "jones:complete_source_match,"
        "homfly:not_computed,"
        "multivariable_alexander_numerator:complete_source_match"
        in summary["notes"]
    )
    expected_source_match_statuses = (
        "jones:complete_source_match,"
        "homfly:not_computed,"
        "multivariable_alexander_numerator:complete_source_match"
    )
    assert (
        summary["source_table_audit_source_match_resolution_statuses"]
        == expected_source_match_statuses
    )
    assert summary["source_table_audit_source_match_resolution_status_count"] == 3
    assert "homfly_variant_status=not_computed" in summary["notes"]
    assert "source_seen=2" in summary["notes"]
    assert "source_seen_uncertified=0" in summary["notes"]
    assert "top_candidates=8" in summary["notes"]
    assert "top_unique_sign_patterns=8" in summary["notes"]
    assert "compatible_unique_sign_patterns=8" in summary["notes"]
    assert "complete_unique_sign_patterns=0" in summary["notes"]
    assert "max_matched_candidates=8" in summary["notes"]
    assert "max_matched_unique_sign_patterns=8" in summary["notes"]
    assert "max_matched_total_candidates=8" in summary["notes"]
    assert "max_matched_total_unique_sign_patterns=8" in summary["notes"]
    assert "registration_ready=false" in summary["notes"]
    assert (
        "registration_blockers="
        "fixture_signs_not_registered,"
        "registered_fixture_invariant_claim_disabled,"
        "source_table_values_uncomputed,"
        "source_compatible_sign_pattern_not_unique"
        in summary["notes"]
    )
    assert "source_url=https://katlas.org/wiki/L6a4" in summary["notes"]
    assert summary["source_table_audit_comparison_count"] == 3
    assert summary["source_table_audit_matched_invariant_count"] == 2
    assert summary["source_table_audit_uncomputed_invariant_count"] == 1
    assert summary["source_table_audit_mismatched_invariant_count"] == 0
    assert summary["source_table_audit_homfly_source_variant_count"] == 0
    assert summary["source_table_audit_homfly_source_variant_seen_count"] == 0
    assert summary["source_table_audit_homfly_source_variant_miss_count"] == 0
    assert summary["source_table_audit_homfly_candidate_unique_value_count"] == 0
    assert summary["source_table_audit_homfly_candidate_unit_normalized_value_count"] == 0
    assert summary["source_table_audit_homfly_variant_resolution_status"] == "not_computed"
    assert summary["source_table_audit_homfly_variant_resolution_status_code"] == 2
    assert (
        summary[
            "source_table_audit_homfly_source_unit_normalized_variant_count"
        ]
        == 0
    )
    assert (
        summary[
            "source_table_audit_homfly_source_unit_normalized_variant_seen_count"
        ]
        == 0
    )
    assert (
        summary[
            "source_table_audit_homfly_source_unit_normalized_variant_miss_count"
        ]
        == 0
    )
    assert summary["source_table_audit_candidate_count"] == 8
    assert summary["source_table_audit_unique_sign_pattern_count"] == 8
    assert summary["source_table_audit_computed_source_compatible_candidate_count"] == 8
    assert (
        summary[
            "source_table_audit_computed_source_compatible_unique_sign_pattern_count"
        ]
        == 8
    )
    assert summary["source_table_audit_complete_source_compatible_candidate_count"] == 0
    assert (
        summary[
            "source_table_audit_complete_source_compatible_unique_sign_pattern_count"
        ]
        == 0
    )
    assert summary["source_table_audit_top_candidate_count"] == 8
    assert summary["source_table_audit_top_unique_sign_pattern_count"] == 8
    assert summary["source_table_audit_max_matched_candidate_total_count"] == 8
    assert (
        summary[
            "source_table_audit_max_matched_candidate_total_unique_sign_pattern_count"
        ]
        == 8
    )
    assert summary["source_table_audit_max_matched_candidate_count"] == 8
    assert summary["source_table_audit_max_matched_unique_sign_pattern_count"] == 8
    assert summary["source_table_audit_registration_ready_count"] == 0
    assert summary["source_table_audit_registration_blocked_count"] == 1
    assert summary["source_table_audit_registration_blocker_count"] == 4
    assert summary["source_table_audit_registration_blockers"] == (
        "fixture_signs_not_registered,"
        "registered_fixture_invariant_claim_disabled,"
        "source_table_values_uncomputed,"
        "source_compatible_sign_pattern_not_unique"
    )
    assert summary["source_table_audit_registration_blocker_code_count"] == 4
    assert summary["source_table_audit_registration_blocker_count_signature"] == (
        "fixture_signs_not_registered:1,"
        "registered_fixture_invariant_claim_disabled:1,"
        "source_table_values_uncomputed:1,"
        "source_compatible_sign_pattern_not_unique:1"
    )
    assert (
        summary[
            "source_table_audit_candidate_convergence_partial_certified_count"
        ]
        == 1
    )
    assert (
        summary["source_table_audit_candidate_convergence_full_certified_count"]
        == 0
    )
    assert (
        summary[
            "source_table_audit_candidate_convergence_certified_invariant_count"
        ]
        == 2
    )
    assert (
        summary[
            "source_table_audit_candidate_convergence_uncertified_invariant_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_audit_candidate_convergence_source_value_seen_count"
        ]
        == 2
    )
    assert (
        summary[
            "source_table_audit_candidate_convergence_source_value_seen_but_uncertified_count"
        ]
        == 0
    )

    payload = imgui_analysis_payload_from_acceptance_reports([report])
    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 3
    assert payload["analysis_passed_check_count"] == 2
    assert payload["analysis_failed_check_count"] == 1
    assert payload["analysis_certification_applicable_count"] == 3
    assert payload["analysis_certification_certified_count"] == 2
    assert payload["analysis_certification_uncertified_count"] == 1
    assert payload["analysis_source_table_audit_comparison_count"] == 3
    assert payload["analysis_source_table_audit_matched_invariant_count"] == 2
    assert payload["analysis_source_table_audit_uncomputed_invariant_count"] == 1
    assert payload["analysis_source_table_audit_top_candidate_count"] == 8
    assert payload["analysis_source_table_audit_unique_sign_pattern_count"] == 8
    assert (
        payload[
            "analysis_source_table_audit_computed_source_compatible_unique_sign_pattern_count"
        ]
        == 8
    )
    assert (
        payload[
            "analysis_source_table_audit_complete_source_compatible_unique_sign_pattern_count"
        ]
        == 0
    )
    assert payload["analysis_source_table_audit_max_matched_candidate_total_count"] == 8
    assert (
        payload[
            "analysis_source_table_audit_max_matched_candidate_total_unique_sign_pattern_count"
        ]
        == 8
    )
    assert payload["analysis_source_table_audit_max_matched_candidate_count"] == 8
    assert payload["analysis_source_table_audit_max_matched_unique_sign_pattern_count"] == 8
    assert payload["analysis_source_table_audit_homfly_candidate_unique_value_count"] == 0
    assert payload["analysis_source_table_audit_homfly_candidate_unit_normalized_value_count"] == 0
    assert payload["analysis_source_table_audit_registration_ready_count"] == 0
    assert payload["analysis_source_table_audit_registration_blocked_count"] == 1
    assert payload["analysis_source_table_audit_registration_blocker_count"] == 4
    assert (
        payload["analysis_source_table_audit_registration_blocker_code_count"]
        == 4
    )
    assert payload["analysis_source_table_audit_source_match_resolution_status_count"] == 3
    assert (
        payload[
            "analysis_source_table_audit_candidate_convergence_partial_certified_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_source_table_audit_candidate_convergence_full_certified_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_source_table_audit_candidate_convergence_certified_invariant_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_source_table_audit_candidate_convergence_uncertified_invariant_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_source_table_audit_candidate_convergence_source_value_seen_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_source_table_audit_candidate_convergence_source_value_seen_but_uncertified_count"
        ]
        == 0
    )
    json.dumps(payload, allow_nan=False)

def test_imgui_analysis_summary_prefers_source_table_homfly_variant_status() -> None:
    report = get_diagram_fixture("L6a4").source_table_invariant_audit(
        max_candidates=8,
    )
    homfly = report["comparisons"]["homfly"]
    homfly["source_value_variant_resolution_status"] = "source_variant_seen"
    homfly["source_value_variant_resolution_status_code"] = 99

    summary = analysis_summary_from_acceptance_report(report)

    assert (
        summary["source_table_audit_homfly_variant_resolution_status"]
        == "source_variant_seen"
    )
    assert summary["source_table_audit_homfly_variant_resolution_status_code"] == 4


@pytest.mark.parametrize(
    ("comparison", "expected_status", "expected_code"),
    [
        ({"source_value_present": False}, "no_source_value", 1),
        (
            {"source_value_present": True, "computed_candidate_count": 0},
            "not_computed",
            2,
        ),
        (
            {
                "source_value_present": True,
                "computed_candidate_count": 3,
                "source_value_seen": True,
                "complete_candidate_source_match": True,
            },
            "complete_source_match",
            3,
        ),
        (
            {
                "source_value_present": True,
                "computed_candidate_count": 3,
                "source_value_seen": True,
                "returned_candidate_source_match": True,
            },
            "returned_source_match_incomplete",
            4,
        ),
        (
            {
                "source_value_present": True,
                "computed_candidate_count": 3,
                "source_value_seen": True,
                "missing_candidate_count": 1,
            },
            "source_seen_with_incomplete_candidates",
            5,
        ),
        (
            {
                "source_value_present": True,
                "computed_candidate_count": 3,
                "source_value_seen": True,
            },
            "source_seen_unstable",
            6,
        ),
        (
            {
                "source_value_present": True,
                "computed_candidate_count": 3,
                "missing_candidate_count": 1,
                "skipped_candidate_count": 2,
            },
            "candidate_values_missing_or_skipped",
            7,
        ),
        (
            {
                "source_value_present": True,
                "computed_candidate_count": 3,
                "source_value_seen": False,
            },
            "source_missed_with_candidates",
            8,
        ),
    ],
)
def test_source_table_source_match_resolution_status_vocabulary(
    comparison: dict[str, object],
    expected_status: str,
    expected_code: int,
) -> None:
    status = _source_table_source_match_resolution_status(comparison)

    assert status == expected_status
    assert _source_table_source_match_resolution_status_code(status) == expected_code
    assert _fixture_match_status_code(status) == expected_code
    assert _source_table_source_match_resolution_status_code("") == 0
    assert _fixture_match_status_code("") == 0
    assert _source_table_source_match_resolution_status_code("unknown") == 0
    assert _fixture_match_status_code("unknown") == 0


@pytest.mark.parametrize(
    ("comparison", "expected_status", "expected_code"),
    [
        ({"source_value_present": False}, "no_source_value", 1),
        (
            {"source_value_present": True, "computed_candidate_count": 0},
            "not_computed",
            2,
        ),
        (
            {
                "source_value_present": True,
                "computed_candidate_count": 3,
                "source_value_seen": True,
            },
            "source_value_seen",
            3,
        ),
        (
            {
                "source_value_present": True,
                "computed_candidate_count": 3,
                "source_value_seen_variant_count": 1,
            },
            "source_variant_seen",
            4,
        ),
        (
            {
                "source_value_present": True,
                "computed_candidate_count": 3,
                "source_value_seen_after_unit_normalization": True,
            },
            "source_value_unit_normalized_seen",
            5,
        ),
        (
            {
                "source_value_present": True,
                "computed_candidate_count": 3,
                "source_value_seen_unit_normalized_variant_count": 1,
            },
            "source_variant_unit_normalized_seen",
            6,
        ),
        (
            {
                "source_value_present": True,
                "computed_candidate_count": 3,
                "source_value_seen": False,
            },
            "source_variants_missed",
            7,
        ),
    ],
)
def test_source_table_homfly_variant_resolution_status_vocabulary(
    comparison: dict[str, object],
    expected_status: str,
    expected_code: int,
) -> None:
    status = _source_table_homfly_variant_resolution_status(comparison)

    assert status == expected_status
    assert _source_table_homfly_variant_resolution_status_code(status) == expected_code
    assert _fixture_homfly_status_code(status) == expected_code
    assert _source_table_homfly_variant_resolution_status_code("") == 0
    assert _fixture_homfly_status_code("") == 0
    assert _source_table_homfly_variant_resolution_status_code("unknown") == 0
    assert _fixture_homfly_status_code("unknown") == 0


def test_imgui_analysis_summary_prefers_source_table_top_level_classification_counts() -> None:
    report = get_diagram_fixture("L6a4").source_table_invariant_audit(
        max_candidates=8,
    )
    report["uncomputed_source_table_invariants"] = [
        "homfly",
        "synthetic_uncomputed",
    ]
    report["mismatched_source_table_invariants"] = ["synthetic_mismatch"]
    report["unstable_source_table_invariants"] = ["synthetic_unstable"]
    report["source_table_candidate_count"] = 99
    report["source_table_candidate_unique_sign_pattern_count"] = 88
    report["source_table_computed_source_compatible_candidate_count"] = 77
    report["source_table_computed_source_compatible_unique_sign_pattern_count"] = 76
    report["source_table_complete_source_compatible_candidate_count"] = 66
    report["source_table_complete_source_compatible_unique_sign_pattern_count"] = 65
    report["source_table_top_candidate_count"] = 55
    report["source_table_top_candidate_unique_sign_pattern_count"] = 44
    report["source_table_max_matched_source_value_count"] = 33
    report["source_table_max_matched_candidate_total_count"] = 32
    report["source_table_max_matched_candidate_total_unique_sign_pattern_count"] = 31
    report["source_table_max_matched_candidate_count"] = 22
    report["source_table_max_matched_candidate_unique_sign_pattern_count"] = 11

    summary = analysis_summary_from_acceptance_report(report)

    assert summary["source_table_audit_uncomputed_invariant_count"] == 2
    assert summary["source_table_audit_mismatched_invariant_count"] == 1
    assert summary["source_table_audit_unstable_invariant_count"] == 1
    assert summary["source_table_audit_candidate_count"] == 99
    assert summary["source_table_audit_unique_sign_pattern_count"] == 88
    assert summary["source_table_audit_computed_source_compatible_candidate_count"] == 77
    assert (
        summary[
            "source_table_audit_computed_source_compatible_unique_sign_pattern_count"
        ]
        == 76
    )
    assert summary["source_table_audit_complete_source_compatible_candidate_count"] == 66
    assert (
        summary[
            "source_table_audit_complete_source_compatible_unique_sign_pattern_count"
        ]
        == 65
    )
    assert summary["source_table_audit_top_candidate_count"] == 55
    assert summary["source_table_audit_top_unique_sign_pattern_count"] == 44
    assert summary["source_table_audit_max_matched_source_value_count"] == 33
    assert summary["source_table_audit_max_matched_candidate_total_count"] == 32
    assert (
        summary[
            "source_table_audit_max_matched_candidate_total_unique_sign_pattern_count"
        ]
        == 31
    )
    assert summary["source_table_audit_max_matched_candidate_count"] == 22
    assert summary["source_table_audit_max_matched_unique_sign_pattern_count"] == 11

    payload = imgui_analysis_payload_from_acceptance_reports([report])
    assert payload["analysis_source_table_audit_uncomputed_invariant_count"] == 2
    assert payload["analysis_source_table_audit_mismatched_invariant_count"] == 1
    assert payload["analysis_source_table_audit_unstable_invariant_count"] == 1
    assert payload["analysis_source_table_audit_candidate_count"] == 99
    assert payload["analysis_source_table_audit_unique_sign_pattern_count"] == 88
    assert payload["analysis_source_table_audit_top_candidate_count"] == 55
    assert payload["analysis_source_table_audit_max_matched_candidate_total_count"] == 32
    assert (
        payload[
            "analysis_source_table_audit_max_matched_candidate_total_unique_sign_pattern_count"
        ]
        == 31
    )
    assert payload["analysis_source_table_audit_max_matched_candidate_count"] == 22
    assert payload["analysis_source_table_audit_max_matched_unique_sign_pattern_count"] == 11
    json.dumps(payload, allow_nan=False)

def test_imgui_analysis_summary_infers_source_table_registration_blockers_for_older_reports() -> None:
    report = get_diagram_fixture("L6a4").source_table_invariant_audit(
        max_candidates=8,
    )
    for key in [
        "source_table_registration_ready",
        "source_table_registration_blockers",
        "source_table_registration_blocker_count",
        "source_table_registration_blocker_details",
    ]:
        report.pop(key, None)

    summary = analysis_summary_from_acceptance_report(report)

    assert "registration_ready=false" in summary["notes"]
    assert (
        "registration_blockers="
        "fixture_signs_not_registered,"
        "registered_fixture_invariant_claim_disabled,"
        "source_table_values_uncomputed,"
        "source_compatible_sign_pattern_not_unique"
        in summary["notes"]
    )
    assert summary["source_table_audit_registration_ready_count"] == 0
    assert summary["source_table_audit_registration_blocked_count"] == 1
    assert summary["source_table_audit_registration_blocker_count"] == 4
    assert summary["source_table_audit_registration_blockers"] == (
        "fixture_signs_not_registered,"
        "registered_fixture_invariant_claim_disabled,"
        "source_table_values_uncomputed,"
        "source_compatible_sign_pattern_not_unique"
    )
    assert summary["source_table_audit_registration_blocker_code_count"] == 4
    assert summary["source_table_audit_registration_blocker_count_signature"] == (
        "fixture_signs_not_registered:1,"
        "registered_fixture_invariant_claim_disabled:1,"
        "source_table_values_uncomputed:1,"
        "source_compatible_sign_pattern_not_unique:1"
    )


def test_imgui_invariant_status_payload_wraps_source_table_invariant_audit_notes() -> None:
    report = get_diagram_fixture("L6a4").source_table_invariant_audit(
        max_candidates=8,
    )

    payload = imgui_invariant_status_payload_from_reports([report])

    assert payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert payload["invariant_status_count"] == 1
    assert payload["invariant_required_check_count"] == 3
    assert payload["invariant_passed_check_count"] == 2
    assert payload["invariant_failed_check_count"] == 1
    assert payload["invariant_source_table_audit_registration_ready_count"] == 0
    assert payload["invariant_source_table_audit_registration_blocked_count"] == 1
    assert payload["invariant_source_table_audit_registration_blocker_count"] == 4
    assert payload["invariant_source_table_audit_source_match_resolution_status_count"] == 3
    assert (
        payload[
            "invariant_source_table_audit_candidate_convergence_partial_certified_count"
        ]
        == 1
    )
    assert (
        payload[
            "invariant_source_table_audit_candidate_convergence_full_certified_count"
        ]
        == 0
    )
    assert (
        payload[
            "invariant_source_table_audit_candidate_convergence_certified_invariant_count"
        ]
        == 2
    )
    assert (
        payload[
            "invariant_source_table_audit_candidate_convergence_uncertified_invariant_count"
        ]
        == 1
    )
    assert (
        payload[
            "invariant_source_table_audit_candidate_convergence_source_value_seen_count"
        ]
        == 2
    )
    assert (
        payload[
            "invariant_source_table_audit_candidate_convergence_source_value_seen_but_uncertified_count"
        ]
        == 0
    )
    status = payload["invariant_statuses"][0]
    assert status["name"] == "source-table invariant audit"
    assert status["value"] == "incomplete (2/3 checks, 1 failed)"
    assert status["skipped"] is False
    assert status["source_table_audit_registration_ready_count"] == 0
    assert status["source_table_audit_registration_blocked_count"] == 1
    assert status["source_table_audit_registration_blocker_count"] == 4
    assert status["source_table_audit_registration_blockers"] == (
        "fixture_signs_not_registered,"
        "registered_fixture_invariant_claim_disabled,"
        "source_table_values_uncomputed,"
        "source_compatible_sign_pattern_not_unique"
    )
    assert status["source_table_audit_registration_blocker_code_count"] == 4
    assert status["source_table_audit_registration_blocker_count_signature"] == (
        "fixture_signs_not_registered:1,"
        "registered_fixture_invariant_claim_disabled:1,"
        "source_table_values_uncomputed:1,"
        "source_compatible_sign_pattern_not_unique:1"
    )
    assert (
        status[
            "source_table_audit_candidate_convergence_partial_certified_count"
        ]
        == 1
    )
    assert status["source_table_audit_candidate_convergence_full_certified_count"] == 0
    assert (
        status[
            "source_table_audit_candidate_convergence_certified_invariant_count"
        ]
        == 2
    )
    assert (
        status[
            "source_table_audit_candidate_convergence_uncertified_invariant_count"
        ]
        == 1
    )
    assert (
        status[
            "source_table_audit_candidate_convergence_source_value_seen_count"
        ]
        == 2
    )
    assert (
        status[
            "source_table_audit_candidate_convergence_source_value_seen_but_uncertified_count"
        ]
        == 0
    )
    expected_source_match_statuses = (
        "jones:complete_source_match,"
        "homfly:not_computed,"
        "multivariable_alexander_numerator:complete_source_match"
    )
    assert (
        status["source_table_audit_source_match_resolution_statuses"]
        == expected_source_match_statuses
    )
    assert status["source_table_audit_source_match_resolution_status_count"] == 3
    assert "matched=jones,multivariable_alexander_numerator" in status["notes"]
    assert "uncomputed=homfly" in status["notes"]
    assert (
        "source_match_statuses="
        "jones:complete_source_match,"
        "homfly:not_computed,"
        "multivariable_alexander_numerator:complete_source_match"
        in status["notes"]
    )
    assert "homfly_variant_status=not_computed" in status["notes"]
    assert "top_candidates=8" in status["notes"]
    assert "registration_ready=false" in status["notes"]
    assert (
        "registration_blockers="
        "fixture_signs_not_registered,"
        "registered_fixture_invariant_claim_disabled,"
        "source_table_values_uncomputed,"
        "source_compatible_sign_pattern_not_unique"
        in status["notes"]
    )
    assert "source_url=https://katlas.org/wiki/L6a4" in status["notes"]

    revision_payload = imgui_invariant_status_payload_from_reports(
        [report],
        signed_pd_revision=123,
    )
    assert revision_payload["signed_pd_revision"] == 123
    json.dumps(payload, allow_nan=False)
    json.dumps(revision_payload, allow_nan=False)


def test_imgui_invariant_status_payload_promotes_common_signed_pd_revision() -> None:
    homfly_report = {
        "method": "homfly_pd_report",
        "input": {"signed_pd_revision": 17},
        "homfly_polynomial": None,
        "skipped": True,
        "result": None,
        "notes": ["synthetic HOMFLY skip"],
    }
    alexander_report = {
        "method": "multivariable_alexander_pd_report",
        "source_signed_pd_revision": 17,
        "signed_pd_revision": 17,
        "multivariable_alexander_polynomial": "1",
        "skipped": False,
        "result": {"method": "synthetic"},
        "notes": ["synthetic Alexander result"],
    }

    payload = imgui_invariant_status_payload_from_reports(
        [homfly_report, alexander_report],
    )
    conflicting_payload = imgui_invariant_status_payload_from_reports(
        [
            homfly_report,
            {
                **alexander_report,
                "signed_pd_revision": 18,
            },
        ],
    )

    assert payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert payload["signed_pd_revision"] == 17
    assert "signed_pd_revision" not in conflicting_payload
    json.dumps(conflicting_payload, allow_nan=False)
    json.dumps(payload, allow_nan=False)


def test_imgui_analysis_summary_distinguishes_source_table_homfly_mismatch() -> None:
    report = get_diagram_fixture("L6a4").source_table_invariant_audit(
        max_candidates=8,
        compute_homfly=True,
        homfly_max_depth=8,
        homfly_max_nodes=4096,
        alexander_max_minors=256,
    )

    summary = analysis_summary_from_acceptance_report(report)

    assert summary["source_method"] == "diagram_fixture_source_table_invariant_audit"
    assert summary["required_check_count"] == 3
    assert summary["passed_check_count"] == 2
    assert summary["failed_check_count"] == 1
    assert "matched=jones,multivariable_alexander_numerator" in summary["notes"]
    assert "mismatched=homfly" in summary["notes"]
    assert (
        "source_match_statuses="
        "jones:complete_source_match,"
        "homfly:source_missed_with_candidates,"
        "multivariable_alexander_numerator:complete_source_match"
        in summary["notes"]
    )
    assert summary["source_table_audit_source_match_resolution_statuses"] == (
        "jones:complete_source_match,"
        "homfly:source_missed_with_candidates,"
        "multivariable_alexander_numerator:complete_source_match"
    )
    assert summary["source_table_audit_source_match_resolution_status_count"] == 3
    assert "homfly_variant_status=source_variant_seen" in summary["notes"]
    assert "homfly_variants_seen=4/8" in summary["notes"]
    assert "homfly_unit_normalized_variants_seen=4/8" in summary["notes"]
    assert "homfly_variant_miss_witnesses" not in summary["notes"]
    assert "max_matched_candidates=8" in summary["notes"]
    assert "max_matched_unique_sign_patterns=8" in summary["notes"]
    assert (
        "registration_blockers="
        "fixture_signs_not_registered,"
        "registered_fixture_invariant_claim_disabled,"
        "source_table_values_mismatched,"
        "source_compatible_sign_pattern_not_unique"
        in summary["notes"]
    )
    assert "uncomputed=homfly" not in summary["notes"]
    assert summary["source_table_audit_matched_invariant_count"] == 2
    assert summary["source_table_audit_mismatched_invariant_count"] == 1
    assert summary["source_table_audit_uncomputed_invariant_count"] == 0
    assert summary["source_table_audit_homfly_source_variant_count"] == 8
    assert summary["source_table_audit_homfly_source_variant_seen_count"] == 4
    assert summary["source_table_audit_homfly_source_variant_miss_count"] == 4
    assert summary["source_table_audit_homfly_candidate_unique_value_count"] == 3
    assert summary["source_table_audit_homfly_candidate_unit_normalized_value_count"] == 3
    assert summary["source_table_audit_homfly_variant_miss_witness_count"] == 0
    assert summary["source_table_audit_homfly_variant_miss_witness_limit"] == 8
    assert summary["source_table_audit_homfly_variant_miss_witness_truncated"] == 0
    assert summary["source_table_audit_homfly_variant_resolution_status"] == "source_variant_seen"
    assert summary["source_table_audit_homfly_variant_resolution_status_code"] == 4
    assert summary["source_table_audit_registration_ready_count"] == 0
    assert summary["source_table_audit_registration_blocked_count"] == 1
    assert summary["source_table_audit_registration_blocker_count"] == 4
    assert (
        summary[
            "source_table_audit_homfly_source_unit_normalized_variant_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_audit_homfly_source_unit_normalized_variant_seen_count"
        ]
        == 4
    )
    assert (
        summary[
            "source_table_audit_homfly_source_unit_normalized_variant_miss_count"
        ]
        == 4
    )


def test_imgui_payloads_preserve_borromean_source_table_homfly_mismatch() -> None:
    report = get_diagram_fixture("L6a4").source_table_invariant_audit(
        max_candidates=8,
        compute_homfly=True,
        homfly_max_depth=8,
        homfly_max_nodes=4096,
        alexander_max_minors=256,
    )

    assert report["mismatched_source_table_invariants"] == ["homfly"]
    assert report["uncomputed_source_table_invariants"] == []
    homfly = report["comparisons"]["homfly"]
    assert homfly["source_match_resolution_status"] == "source_missed_with_candidates"
    assert homfly["source_value_variant_resolution_status"] == "source_variant_seen"
    assert homfly["source_value_variant_resolution_status_code"] == 4
    variant_miss_summary = homfly["source_value_variant_miss_witness_summary"]
    assert variant_miss_summary["variant_miss_witness_count"] == 0
    assert variant_miss_summary["variant_miss_witness_limit"] == 8
    assert variant_miss_summary["variant_miss_witness_truncated"] is False
    assert variant_miss_summary["first_variant_miss_witness"] is None
    assert report["source_table_homfly_variant_miss_witness_count"] == 0
    assert report["source_table_registration_ready"] is False

    analysis_payload = imgui_analysis_payload_from_acceptance_reports([report])
    summary = analysis_payload["analysis_summaries"][0]

    assert summary["source_table_audit_homfly_variant_resolution_status"] == (
        "source_variant_seen"
    )
    assert summary["source_table_audit_homfly_variant_resolution_status_code"] == 4
    assert summary["source_table_audit_source_match_resolution_statuses"] == (
        "jones:complete_source_match,"
        "homfly:source_missed_with_candidates,"
        "multivariable_alexander_numerator:complete_source_match"
    )
    assert summary["source_table_audit_mismatched_invariant_count"] == 1
    assert summary["source_table_audit_uncomputed_invariant_count"] == 0
    assert summary["source_table_audit_homfly_source_variant_count"] == 8
    assert summary["source_table_audit_homfly_source_variant_seen_count"] == 4
    assert summary["source_table_audit_homfly_source_variant_miss_count"] == 4
    assert summary["source_table_audit_homfly_candidate_unique_value_count"] == 3
    assert summary["source_table_audit_homfly_candidate_unit_normalized_value_count"] == 3
    assert summary["source_table_audit_homfly_variant_miss_witness_count"] == 0
    assert summary["source_table_audit_homfly_variant_miss_witness_limit"] == 8
    assert summary["source_table_audit_homfly_variant_miss_witness_truncated"] == 0
    assert summary["source_table_audit_registration_ready_count"] == 0
    assert summary["source_table_audit_registration_blocked_count"] == 1
    assert summary["source_table_audit_registration_blocker_count"] == 4
    assert (
        summary["source_table_audit_candidate_convergence_certified_invariant_count"]
        == 2
    )
    assert (
        summary["source_table_audit_candidate_convergence_uncertified_invariant_count"]
        == 1
    )
    assert analysis_payload["analysis_source_table_audit_mismatched_invariant_count"] == 1
    assert analysis_payload["analysis_source_table_audit_uncomputed_invariant_count"] == 0
    assert analysis_payload["analysis_source_table_audit_homfly_source_variant_count"] == 8
    assert (
        analysis_payload["analysis_source_table_audit_homfly_source_variant_seen_count"]
        == 4
    )
    assert (
        analysis_payload["analysis_source_table_audit_homfly_source_variant_miss_count"]
        == 4
    )

    assert (
        analysis_payload[
            "analysis_source_table_audit_homfly_variant_miss_witness_count"
        ]
        == 0
    )
    assert analysis_payload["analysis_source_table_audit_registration_blocker_count"] == 4

    invariant_payload = imgui_invariant_status_payload_from_reports([report])
    status = invariant_payload["invariant_statuses"][0]

    assert status["source_table_audit_homfly_variant_resolution_status"] == (
        "source_variant_seen"
    )
    assert status["source_table_audit_homfly_variant_resolution_status_code"] == 4
    assert status["source_table_audit_source_match_resolution_statuses"] == (
        "jones:complete_source_match,"
        "homfly:source_missed_with_candidates,"
        "multivariable_alexander_numerator:complete_source_match"
    )
    assert status["source_table_audit_mismatched_invariant_count"] == 1
    assert status["source_table_audit_uncomputed_invariant_count"] == 0
    assert status["source_table_audit_homfly_source_variant_count"] == 8
    assert status["source_table_audit_homfly_source_variant_seen_count"] == 4
    assert status["source_table_audit_homfly_source_variant_miss_count"] == 4
    assert status["source_table_audit_homfly_variant_miss_witness_count"] == 0
    assert status["source_table_audit_homfly_variant_miss_witness_limit"] == 8
    assert status["source_table_audit_homfly_variant_miss_witness_truncated"] == 0
    assert status["source_table_audit_registration_ready_count"] == 0
    assert status["source_table_audit_registration_blocked_count"] == 1
    assert status["source_table_audit_registration_blocker_count"] == 4
    assert (
        status["source_table_audit_candidate_convergence_certified_invariant_count"]
        == 2
    )
    assert (
        status["source_table_audit_candidate_convergence_uncertified_invariant_count"]
        == 1
    )
    assert (
        invariant_payload["invariant_source_table_audit_mismatched_invariant_count"]
        == 1
    )
    assert (
        invariant_payload["invariant_source_table_audit_uncomputed_invariant_count"]
        == 0
    )
    assert (
        invariant_payload["invariant_source_table_audit_homfly_source_variant_count"]
        == 8
    )
    assert (
        invariant_payload[
            "invariant_source_table_audit_homfly_source_variant_seen_count"
        ]
        == 4
    )
    assert (
        invariant_payload[
            "invariant_source_table_audit_homfly_source_variant_miss_count"
        ]
        == 4
    )
    assert (
        invariant_payload[
            "invariant_source_table_audit_homfly_variant_miss_witness_count"
        ]
        == 0
    )
    assert (
        invariant_payload["invariant_source_table_audit_registration_blocker_count"]
        == 4
    )
    json.dumps(analysis_payload, allow_nan=False)
    json.dumps(invariant_payload, allow_nan=False)

def test_imgui_analysis_summary_distinguishes_whitehead_homfly_gap() -> None:
    report = get_diagram_fixture("L5a1").source_table_invariant_audit(
        max_candidates=12,
        compute_homfly=True,
        homfly_max_depth=8,
        homfly_max_nodes=4096,
        alexander_max_minors=128,
    )

    summary = analysis_summary_from_acceptance_report(report)

    assert summary["source_method"] == "diagram_fixture_source_table_invariant_audit"
    assert summary["required_check_count"] == 3
    assert summary["passed_check_count"] == 0
    assert summary["failed_check_count"] == 3
    assert "matched=none" in summary["notes"]
    assert "mismatched=homfly" in summary["notes"]
    assert (
        "source_match_statuses="
        "jones:source_seen_with_incomplete_candidates,"
        "homfly:source_missed_with_candidates,"
        "multivariable_alexander_numerator:source_seen_with_incomplete_candidates"
        in summary["notes"]
    )
    assert summary["source_table_audit_source_match_resolution_statuses"] == (
        "jones:source_seen_with_incomplete_candidates,"
        "homfly:source_missed_with_candidates,"
        "multivariable_alexander_numerator:source_seen_with_incomplete_candidates"
    )
    assert summary["source_table_audit_source_match_resolution_status_count"] == 3
    assert "homfly_variant_status=source_variant_seen" in summary["notes"]
    assert "homfly_variants_seen=2/8" in summary["notes"]
    assert "homfly_unit_normalized_variants_seen=4/8" in summary["notes"]
    assert (
        "source_table_alexander_skipped_common_gcd_attempts="
        "candidates=4; not_certified=4; statuses=not_certified:4"
        in summary["notes"]
    )
    assert (
        "source_table_alexander_source_divisibility="
        "candidates=4; source_divides_all=0; source_division_failed=4; "
        "statuses=source_does_not_divide_all_inputs:4"
        in summary["notes"]
    )
    assert "candidate_indices=4,5,10,11" in summary["notes"]
    assert "first_failed_notation=L5a1" in summary["notes"]
    assert "first_failed_candidate=4" in summary["notes"]
    assert (
        "first_failed_input=2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2"
        in summary["notes"]
    )
    assert (
        summary["source_table_alexander_source_divisibility_candidate_indices"]
        == "4,5,10,11"
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_first_failed_candidate_index"
        ]
        == 4
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_first_failed_notation"
        ]
        == "L5a1"
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_first_failed_input_polynomial"
        ]
        == "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2"
    )
    assert "failed_inputs=10..10" in summary["notes"]
    assert "input_polynomials=25..25" in summary["notes"]
    assert "unique_inputs=10..10" in summary["notes"]
    assert "support_signature_evidence=4" in summary["notes"]
    assert "support_signatures=t1+t2:4" in summary["notes"]
    assert "support_signature_inputs=25..25" in summary["notes"]
    assert "direct_divisor_candidates=10" in summary["notes"]
    assert "direct_divisor_failed=10" in summary["notes"]
    assert "direct_divisor_all_failed=1" in summary["notes"]
    assert (
        "attempt_methods=integer_content,univariate_gcd,"
        "rank_one_monomial_gcd,direct_scanned_minor_divisor,"
        "bounded_multivariate_binomial_factor,"
        "bounded_multivariate_root_binomial_factor,"
        "bounded_multivariate_sparse_factor,"
        "bounded_multivariate_cofactor_factor"
        in summary["notes"]
    )
    assert "limit_variants=1" in summary["notes"]
    assert "uncomputed=jones,multivariable_alexander_numerator" in summary["notes"]
    assert "top_candidates=0" in summary["notes"]
    assert "top_unique_sign_patterns=0" in summary["notes"]
    assert "max_matched_candidates=2" in summary["notes"]
    assert "max_matched_unique_sign_patterns=1" in summary["notes"]
    assert (
        "registration_blockers="
        "fixture_signs_not_registered,"
        "registered_fixture_invariant_claim_disabled,"
        "candidate_set_incomplete,"
        "source_table_values_uncomputed,"
        "source_table_values_mismatched,"
        "source_compatible_sign_pattern_not_unique"
        in summary["notes"]
    )
    assert summary["source_table_audit_mismatched_invariant_count"] == 1
    assert summary["source_table_audit_uncomputed_invariant_count"] == 2
    assert summary["source_table_audit_top_candidate_count"] == 0
    assert summary["source_table_audit_homfly_source_variant_count"] == 8
    assert summary["source_table_audit_homfly_source_variant_seen_count"] == 2
    assert summary["source_table_audit_homfly_source_variant_miss_count"] == 6
    assert summary["source_table_audit_homfly_candidate_unique_value_count"] == 6
    assert summary["source_table_audit_homfly_candidate_unit_normalized_value_count"] == 6
    assert summary["source_table_audit_homfly_variant_resolution_status"] == "source_variant_seen"
    assert summary["source_table_audit_homfly_variant_resolution_status_code"] == 4
    assert summary["source_table_alexander_skipped_common_gcd_attempt_candidate_count"] == 4
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count"
        ]
        == 4
    )
    assert summary["source_table_alexander_skipped_common_gcd_attempt_method_count"] == 8
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_limit_variant_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count"
        ]
        == 4
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_min"
        ]
        == 10
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max"
        ]
        == 10
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 4
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min"
        ]
        == 25
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max"
        ]
        == 25
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_checked_candidate_count"
        ]
        == 4
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_source_divides_all_candidate_count"
        ]
        == 0
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_source_division_failed_candidate_count"
        ]
        == 4
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_status_variant_count"
        ]
        == 1
    )
    assert summary["source_table_audit_registration_ready_count"] == 0
    assert summary["source_table_audit_registration_blocked_count"] == 1
    assert summary["source_table_audit_registration_blocker_count"] == 6
    assert (
        summary[
            "source_table_audit_homfly_source_unit_normalized_variant_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_audit_homfly_source_unit_normalized_variant_seen_count"
        ]
        == 4
    )
    assert (
        summary[
            "source_table_audit_homfly_source_unit_normalized_variant_miss_count"
        ]
        == 4
    )


def test_imgui_analysis_summary_wraps_alexander_signed_pd_coverage_report() -> None:
    report = multivariable_alexander_signed_pd_coverage_report()
    maturity_consistency = report["bounded_alexander_maturity_path_summary_consistency"]

    summary = analysis_summary_from_acceptance_report(report)

    assert summary["name"] == "multi-variable Alexander generated signed-PD coverage"
    assert summary["source_method"] == (
        "multivariable_alexander_signed_pd_coverage_report"
    )
    assert summary["claim_scope"] == (
        "generated_small_signed_pd_wirtinger_fox_scanned_gcd_coverage"
    )
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 30
    assert summary["passed_check_count"] == 30
    assert summary["failed_check_count"] == 0
    assert summary["certification_scope"] == report["claim_scope"]
    assert summary["certification_applicable_count"] == 30
    assert summary["certification_certified_count"] == 30
    assert summary["certification_uncertified_count"] == 0
    assert summary["bounded_scanned_gcd_checked_nonzero_minor_count"] == 281
    assert summary["bounded_scanned_gcd_failed_nonzero_minor_count"] == 0
    assert summary["bounded_scanned_gcd_scanned_minor_count"] == 281
    assert summary["bounded_scanned_gcd_expected_minor_combination_count"] == 281
    assert summary["bounded_scanned_gcd_nonzero_minor_count"] == 281
    assert summary["bounded_scanned_gcd_zero_minor_count"] == 0
    assert summary["bounded_scanned_gcd_unit_minor_count"] == 101
    assert summary["bounded_scanned_gcd_unique_nonzero_polynomial_count"] == 42
    assert summary["bounded_scanned_gcd_all_rows_have_nonzero_minor_count"] == 28
    assert summary["bounded_scanned_gcd_all_columns_have_nonzero_minor_count"] == 28
    assert summary["bounded_scanned_gcd_complete_scan_count"] == 30
    assert summary[
        "bounded_scanned_gcd_nonzero_minor_coverage_complete_count"
    ] == 28
    assert summary["bounded_scanned_gcd_truncated_count"] == 0
    assert summary["bounded_scanned_gcd_quotient_gcd_certified_count"] == 30
    assert summary["bounded_scanned_gcd_complete_certified_count"] == 28
    assert summary["wirtinger_fox_scanned_minor_count"] == 281
    assert summary["wirtinger_fox_invalid_minor_reference_count"] == 0
    assert summary["wirtinger_fox_invalid_normalization_count"] == 0
    assert summary["wirtinger_fox_complete_scan_count"] == 30
    assert summary["wirtinger_fox_truncated_count"] == 0
    assert summary["generated_case_count"] == report["case_count"]
    assert summary["generated_non_fixture_case_count"] == report["non_fixture_case_count"]
    assert summary["generated_source_notation_count"] == len(report["source_notation_summary"])
    assert summary["generated_source_summary_consistency_matched"] is True
    assert summary["generated_source_summary_count_totals_matched"] is True
    assert summary["generated_source_summary_distribution_totals_matched"] is None
    assert summary[
        "generated_source_summary_frontier_reason_counts_matched"
    ] is None
    assert summary[
        "generated_source_summary_source_notation_count_matches_fixture_count"
    ] is True
    assert (
        summary[
            "bounded_alexander_maturity_path_summary_consistency_available_count"
        ]
        == 1
    )
    assert (
        summary[
            "bounded_alexander_maturity_path_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "bounded_alexander_maturity_path_summary_consistency_record_count"
        ]
        == maturity_consistency["record_count"]
    )
    assert (
        summary[
            "bounded_alexander_maturity_path_summary_consistency_path_count_total"
        ]
        == maturity_consistency["path_count_total"]
    )
    assert (
        summary[
            "bounded_alexander_maturity_path_summary_consistency_certified_count"
        ]
        == maturity_consistency["certified_count"]
    )
    assert summary["generated_branch_depth"] == report["branch_depth"]
    assert summary["generated_max_branch_depth"] == report["max_generated_branch_depth"]
    assert summary["generated_unique_diagram_count"] == report["unique_diagram_count"]
    assert summary["generated_unique_oriented_diagram_count"] == report[
        "unique_oriented_diagram_count"
    ]
    assert summary["generated_zero_crossing_unlink_case_count"] == report[
        "zero_crossing_unlink_certified_case_count"
    ]
    assert summary["generated_unique_evaluation_count"] == report[
        "nonzero_unique_evaluation_count"
    ]
    assert summary["generated_reused_evaluation_count"] == report[
        "nonzero_reused_evaluation_count"
    ]
    assert "generated_cases=30" in summary["notes"]
    assert "non_fixture_cases=27" in summary["notes"]
    assert "branch_depth=1" in summary["notes"]
    assert "unique_diagrams=19" in summary["notes"]
    assert "unique_oriented_diagrams=20" in summary["notes"]
    assert "nonzero_evaluated_cases=30" in summary["notes"]
    assert "nonzero_unique_evaluations=20" in summary["notes"]
    assert "nonzero_reused_evaluations=10" in summary["notes"]
    assert (
        "nonzero_evaluation_cache=accounted=True; "
        "reuse_observed=True; accounted_cases=30/30"
    ) in summary["notes"]
    assert (
        "nonzero_evaluation_source_accounting=totals_match_report=True; "
        "case_accounting_complete=True; evaluated_skips=0; unevaluated_skips=0"
    ) in summary["notes"]
    assert (
        "source_notation_summary_consistency=matched=True; "
        "count_totals_matched=True; "
        "source_notation_count_matches_fixture_count=True"
    ) in summary["notes"]
    assert "bounded_alexander_maturity_path_summary_consistency=matched=True" in summary["notes"]
    assert "scanned_minors=281" in summary["notes"]
    assert "expected_minor_combinations=281" in summary["notes"]
    assert "nonzero_minors=281" in summary["notes"]
    assert "unit_minors=101" in summary["notes"]
    assert "unique_nonzero_minor_polynomials=42" in summary["notes"]
    assert "all_rows_nonzero_minor_cases=28" in summary["notes"]
    assert "all_columns_nonzero_minor_cases=28" in summary["notes"]
    assert "failed_nonzero_minors=0" in summary["notes"]
    assert (
        "source_notation_accepted_cases=L2a1:7/7,3_1:10/10,4_1:13/13"
        in summary["notes"]
    )
    assert "source_notation_scanned_minors=L2a1:26" in summary["notes"]

    payload = imgui_analysis_payload_from_acceptance_reports([report])
    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 30
    assert payload["analysis_passed_check_count"] == 30
    assert payload["analysis_failed_check_count"] == 0
    assert payload["analysis_certification_applicable_count"] == 30
    assert payload["analysis_certification_certified_count"] == 30
    assert payload["analysis_certification_uncertified_count"] == 0
    assert payload["analysis_bounded_scanned_gcd_scanned_minor_count"] == 281
    assert (
        payload["analysis_bounded_scanned_gcd_expected_minor_combination_count"]
        == 281
    )
    assert payload["analysis_bounded_scanned_gcd_nonzero_minor_count"] == 281
    assert payload["analysis_bounded_scanned_gcd_zero_minor_count"] == 0
    assert payload["analysis_bounded_scanned_gcd_unit_minor_count"] == 101
    assert (
        payload["analysis_bounded_scanned_gcd_unique_nonzero_polynomial_count"]
        == 42
    )
    assert (
        payload["analysis_bounded_scanned_gcd_all_rows_have_nonzero_minor_count"]
        == 28
    )
    assert (
        payload["analysis_bounded_scanned_gcd_all_columns_have_nonzero_minor_count"]
        == 28
    )
    assert payload["analysis_wirtinger_fox_complete_scan_count"] == 30
    assert payload["analysis_generated_case_count"] == report["case_count"]
    assert payload["analysis_generated_non_fixture_case_count"] == report[
        "non_fixture_case_count"
    ]
    assert payload["analysis_generated_source_notation_count"] == len(report["source_notation_summary"])
    assert payload["analysis_generated_max_branch_depth"] == report[
        "max_generated_branch_depth"
    ]
    assert payload["analysis_generated_unique_diagram_count"] == report[
        "unique_diagram_count"
    ]
    assert payload["analysis_generated_unique_oriented_diagram_count"] == report[
        "unique_oriented_diagram_count"
    ]
    assert payload["analysis_generated_zero_crossing_unlink_case_count"] == report[
        "zero_crossing_unlink_certified_case_count"
    ]
    assert payload["analysis_generated_frontier_case_count"] == 0
    assert payload["analysis_generated_unique_evaluation_count"] == 20
    assert payload["analysis_generated_reused_evaluation_count"] == 10
    assert (
        payload[
            "analysis_bounded_alexander_maturity_path_summary_consistency_available_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_bounded_alexander_maturity_path_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_bounded_alexander_maturity_path_summary_consistency_path_count_total"
        ]
        == maturity_consistency["path_count_total"]
    )
    assert payload["analysis_summaries"][0][
        "generated_source_summary_consistency_matched"
    ] is True
    assert payload["analysis_summaries"][0][
        "generated_source_summary_count_totals_matched"
    ] is True
    assert payload["analysis_summaries"][0][
        "generated_source_summary_distribution_totals_matched"
    ] is None
    assert payload["analysis_summaries"][0][
        "generated_source_summary_frontier_reason_counts_matched"
    ] is None
    assert payload["analysis_summaries"][0][
        "generated_source_summary_source_notation_count_matches_fixture_count"
    ] is True
    assert payload["analysis_generated_source_summary_consistency_matched"] is True
    assert payload["analysis_generated_source_summary_count_totals_matched"] is True
    assert (
        payload["analysis_generated_source_summary_distribution_totals_matched"]
        is None
    )
    assert (
        payload["analysis_generated_source_summary_frontier_reason_counts_matched"]
        is None
    )
    assert (
        payload[
            "analysis_generated_source_summary_source_notation_count_matches_fixture_count"
        ]
        is True
    )
    assert "generated_cases=30" in payload["analysis_summaries"][0]["notes"]
    assert (
        "source_notation_accepted_cases=L2a1:7/7,3_1:10/10,4_1:13/13"
        in payload["analysis_summaries"][0]["notes"]
    )
    json.dumps(payload, allow_nan=False)

def test_imgui_payloads_preserve_alexander_maturity_path_summary_consistency_mismatch() -> None:
    report = multivariable_alexander_signed_pd_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_minors=64,
    )
    consistency = report["bounded_alexander_maturity_path_summary_consistency"]
    report["bounded_alexander_maturity_path_summary_consistency"] = {
        **consistency,
        "matched": False,
        "path_count_total": consistency["path_count_total"] + 1,
    }
    mutated_consistency = report[
        "bounded_alexander_maturity_path_summary_consistency"
    ]
    note_token = (
        "bounded_alexander_maturity_path_summary_consistency=matched=False"
    )

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    invariant_payload = imgui_invariant_status_payload_from_acceptance_reports(
        [report]
    )
    host_payload = imgui_host_payload_from_acceptance_reports(
        [report],
        analysis_reports=[report],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )

    assert (
        summary[
            "bounded_alexander_maturity_path_summary_consistency_available_count"
        ]
        == 1
    )
    assert (
        summary[
            "bounded_alexander_maturity_path_summary_consistency_matched_count"
        ]
        == 0
    )
    assert (
        summary[
            "bounded_alexander_maturity_path_summary_consistency_mismatch_count"
        ]
        == 1
    )
    assert (
        summary[
            "bounded_alexander_maturity_path_summary_consistency_path_count_total"
        ]
        == mutated_consistency["path_count_total"]
    )
    assert note_token in summary["notes"]
    assert (
        f"path_total={mutated_consistency['path_count_total']}/"
        f"{mutated_consistency['record_count']}"
    ) in summary["notes"]

    for container, prefix in (
        (payload, "analysis"),
        (invariant_payload, "invariant"),
        (host_payload["analysis"], "analysis"),
        (host_payload["invariants"], "invariant"),
    ):
        assert (
            container[
                f"{prefix}_bounded_alexander_maturity_path_summary_consistency_available_count"
            ]
            == 1
        )
        assert (
            container[
                f"{prefix}_bounded_alexander_maturity_path_summary_consistency_matched_count"
            ]
            == 0
        )
        assert (
            container[
                f"{prefix}_bounded_alexander_maturity_path_summary_consistency_mismatch_count"
            ]
            == 1
        )
        assert (
            container[
                f"{prefix}_bounded_alexander_maturity_path_summary_consistency_path_count_total"
            ]
            == mutated_consistency["path_count_total"]
        )

    invariant_status = invariant_payload["invariant_statuses"][0]
    host_status = host_payload["invariants"]["invariant_statuses"][0]
    for status in (invariant_status, host_status):
        assert (
            status[
                "bounded_alexander_maturity_path_summary_consistency_mismatch_count"
            ]
            == 1
        )
        assert note_token in status["notes"]
    assert note_token in payload["analysis_summaries"][0]["notes"]
    assert note_token in host_payload["analysis"]["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(invariant_payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_analysis_summary_exposes_alexander_source_summary_mismatch_witness() -> None:
    report = multivariable_alexander_signed_pd_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_minors=64,
    )
    report["source_notation_summary_consistency"] = {
        **report["source_notation_summary_consistency"],
        "matched": False,
        "count_totals_matched": False,
        "mismatch_count": 1,
        "first_mismatch": {
            "kind": "count_total",
            "field": "case_count",
            "tags": ["case", "count"],
            "report_value": report["case_count"] + 1,
            "source_value": report["case_count"],
        },
    }

    summary = analysis_summary_from_acceptance_report(report)

    assert summary["generated_source_summary_consistency_matched"] is False
    assert "source_notation_summary_consistency=matched=False" in summary["notes"]
    assert "count_totals_matched=False" in summary["notes"]
    assert "mismatch_count=1" in summary["notes"]
    assert "first_mismatch=count_total:case_count" in summary["notes"]
    assert "first_mismatch_tags=case,count" in summary["notes"]

    legacy_report = dict(report)
    legacy_report.pop("source_notation_summary_consistency")
    legacy_summary = analysis_summary_from_acceptance_report(legacy_report)
    for field in (
        "generated_source_summary_consistency_matched",
        "generated_source_summary_count_totals_matched",
        "generated_source_summary_distribution_totals_matched",
        "generated_source_summary_frontier_reason_counts_matched",
        "generated_source_summary_source_notation_count_matches_fixture_count",
    ):
        assert legacy_summary[field] is None
    legacy_payload = imgui_analysis_payload_from_acceptance_reports([legacy_report])
    for field in (
        "analysis_generated_source_summary_consistency_matched",
        "analysis_generated_source_summary_count_totals_matched",
        "analysis_generated_source_summary_distribution_totals_matched",
        "analysis_generated_source_summary_frontier_reason_counts_matched",
        "analysis_generated_source_summary_source_notation_count_matches_fixture_count",
    ):
        assert legacy_payload[field] is None
    assert "source_notation_summary_consistency=" not in legacy_summary["notes"]
    json.dumps(legacy_payload, allow_nan=False)

def test_imgui_analysis_payload_aggregates_depth_two_generated_coverage_pack() -> None:
    homfly = homfly_small_diagram_coverage_report(branch_depth=2)
    alexander = multivariable_alexander_signed_pd_coverage_report(branch_depth=2)

    payload = imgui_analysis_payload_from_acceptance_reports([homfly, alexander])

    assert payload["analysis_summary_count"] == 2
    assert alexander["accepted_case_count"] == 260
    assert alexander["uncertified_case_count"] == 4
    assert payload["analysis_required_check_count"] == 528
    assert payload["analysis_passed_check_count"] == 524
    assert payload["analysis_failed_check_count"] == 4
    assert payload["analysis_certification_applicable_count"] == 528
    assert payload["analysis_certification_certified_count"] == 524
    assert payload["analysis_certification_uncertified_count"] == 4
    assert payload["analysis_input_certification_iterative_attempt_count"] == 1146
    assert payload["analysis_input_certification_iterative_solved_count"] == 264
    assert payload["analysis_input_certification_iterative_max_solved_depth"] == 7
    assert payload["analysis_bounded_scanned_gcd_scanned_minor_count"] == 2479
    assert (
        payload["analysis_bounded_scanned_gcd_expected_minor_combination_count"]
        == alexander["expected_combination_count"]
    )
    assert payload["analysis_bounded_scanned_gcd_nonzero_minor_count"] == (
        alexander["nonzero_minor_count"]
    )
    assert payload["analysis_bounded_scanned_gcd_zero_minor_count"] == (
        alexander["zero_minor_count"]
    )
    assert payload["analysis_bounded_scanned_gcd_unit_minor_count"] == (
        alexander["unit_minor_count"]
    )
    assert (
        payload["analysis_bounded_scanned_gcd_unique_nonzero_polynomial_count"]
        == alexander["unique_nonzero_polynomial_count"]
    )
    assert (
        payload["analysis_bounded_scanned_gcd_all_rows_have_nonzero_minor_count"]
        == alexander["all_rows_have_nonzero_minor_case_count"]
    )
    assert (
        payload[
            "analysis_bounded_scanned_gcd_all_columns_have_nonzero_minor_count"
        ]
        == alexander["all_columns_have_nonzero_minor_case_count"]
    )
    assert payload["analysis_bounded_scanned_gcd_checked_nonzero_minor_count"] == 2383
    assert payload["analysis_bounded_scanned_gcd_complete_scan_count"] == 258
    assert (
        payload["analysis_bounded_scanned_gcd_nonzero_minor_coverage_complete_count"]
        == 230
    )
    assert payload["analysis_bounded_scanned_gcd_quotient_gcd_certified_count"] == 258
    assert payload["analysis_bounded_scanned_gcd_complete_certified_count"] == 230
    assert payload["analysis_bounded_alexander_maturity_path_certified_count"] == (
        alexander["accepted_case_count"]
    )
    assert payload["analysis_wirtinger_fox_scanned_minor_count"] == 2479
    assert payload["analysis_wirtinger_fox_complete_scan_count"] == 258
    assert payload["analysis_generated_case_count"] == (
        homfly["case_count"] + alexander["case_count"]
    )
    assert payload["analysis_generated_non_fixture_case_count"] == (
        homfly["non_fixture_case_count"] + alexander["non_fixture_case_count"]
    )
    assert payload["analysis_generated_source_notation_count"] == (
        len(homfly["source_notation_summary"])
        + len(alexander["source_notation_summary"])
    )
    assert payload["analysis_generated_max_branch_depth"] == 2
    assert payload["analysis_generated_unique_diagram_count"] == (
        homfly["unique_diagram_count"] + alexander["unique_diagram_count"]
    )
    assert payload["analysis_generated_unique_oriented_diagram_count"] == (
        homfly["unique_oriented_diagram_count"]
        + alexander["unique_oriented_diagram_count"]
    )
    assert payload["analysis_generated_zero_crossing_unlink_case_count"] == alexander[
        "zero_crossing_unlink_certified_case_count"
    ]
    assert payload["analysis_generated_frontier_case_count"] == homfly[
        "frontier_case_count"
    ]
    assert payload["analysis_generated_oriented_polynomial_conflict_count"] == homfly[
        "oriented_polynomial_conflict_count"
    ]
    assert payload["analysis_generated_unique_evaluation_count"] == (
        homfly["unique_evaluation_count"]
        + alexander["nonzero_unique_evaluation_count"]
    )
    assert payload["analysis_generated_reused_evaluation_count"] == (
        homfly["reused_evaluation_count"]
        + alexander["nonzero_reused_evaluation_count"]
    )
    assert payload["analysis_generated_fixture_normalization_metadata_count"] == (
        homfly["fixture_normalization_metadata"]["metadata_row_count"]
    )
    assert (
        payload["analysis_generated_fixture_normalization_expected_source_count"]
        == homfly["fixture_normalization_metadata"]["expected_homfly_source_count"]
    )
    assert (
        payload["analysis_generated_fixture_normalization_full_table_certified_count"]
        == 0
    )
    assert payload["analysis_generated_source_summary_consistency_matched"] is True
    assert payload["analysis_generated_source_summary_count_totals_matched"] is True
    assert (
        payload["analysis_generated_source_summary_distribution_totals_matched"]
        is True
    )
    assert (
        payload["analysis_generated_source_summary_frontier_reason_counts_matched"]
        is True
    )
    assert (
        payload[
            "analysis_generated_source_summary_source_notation_count_matches_fixture_count"
        ]
        is True
    )
    summaries = {row["source_method"]: row for row in payload["analysis_summaries"]}
    assert summaries["homfly_small_diagram_coverage_report"][
        "required_check_count"
    ] == 264
    assert summaries["homfly_small_diagram_coverage_report"][
        "input_certification_iterative_solved_count"
    ] == 264
    assert summaries["homfly_small_diagram_coverage_report"][
        "generated_unique_evaluation_count"
    ] == homfly["unique_evaluation_count"]
    assert summaries["homfly_small_diagram_coverage_report"][
        "generated_reused_evaluation_count"
    ] == homfly["reused_evaluation_count"]
    assert "generated_cases=264" in summaries[
        "homfly_small_diagram_coverage_report"
    ]["notes"]
    assert "branch_depth=2" in summaries[
        "homfly_small_diagram_coverage_report"
    ]["notes"]
    assert (
        "source_notation_certified_cases=L2a1:37/37,3_1:82/82,4_1:145/145"
        in summaries["homfly_small_diagram_coverage_report"]["notes"]
    )
    assert summaries["multivariable_alexander_signed_pd_coverage_report"][
        "required_check_count"
    ] == 264
    assert summaries["multivariable_alexander_signed_pd_coverage_report"][
        "passed_check_count"
    ] == 260
    assert summaries["multivariable_alexander_signed_pd_coverage_report"][
        "failed_check_count"
    ] == 4
    assert summaries["multivariable_alexander_signed_pd_coverage_report"][
        "bounded_scanned_gcd_scanned_minor_count"
    ] == 2479
    assert summaries["multivariable_alexander_signed_pd_coverage_report"][
        "generated_unique_evaluation_count"
    ] == alexander["nonzero_unique_evaluation_count"]
    assert summaries["multivariable_alexander_signed_pd_coverage_report"][
        "generated_reused_evaluation_count"
    ] == alexander["nonzero_reused_evaluation_count"]
    assert summaries["multivariable_alexander_signed_pd_coverage_report"][
        "bounded_alexander_maturity_path_certified_count"
    ] == alexander["accepted_case_count"]
    assert summaries["multivariable_alexander_signed_pd_coverage_report"][
        "bounded_alexander_maturity_path_distinct_count"
    ] >= 1
    assert (
        summaries["multivariable_alexander_signed_pd_coverage_report"][
            "bounded_alexander_maturity_path_exact_scanned_gcd_count"
        ]
        + summaries["multivariable_alexander_signed_pd_coverage_report"][
            "bounded_alexander_maturity_path_laurent_unit_normalization_consensus_count"
        ]
        + summaries["multivariable_alexander_signed_pd_coverage_report"][
            "bounded_alexander_maturity_path_zero_crossing_unlink_count"
        ]
        == alexander["accepted_case_count"]
    )
    assert summaries["multivariable_alexander_signed_pd_coverage_report"][
        "bounded_alexander_maturity_path_not_certified_count"
    ] == alexander["uncertified_case_count"]
    assert "generated_cases=264" in summaries[
        "multivariable_alexander_signed_pd_coverage_report"
    ]["notes"]
    assert "bounded_alexander_maturity_paths=" in summaries[
        "multivariable_alexander_signed_pd_coverage_report"
    ]["notes"]
    assert "scanned_minors=2479" in summaries[
        "multivariable_alexander_signed_pd_coverage_report"
    ]["notes"]
    assert (
        "source_notation_accepted_cases=L2a1:37/37,3_1:82/82,4_1:141/145"
        in summaries["multivariable_alexander_signed_pd_coverage_report"]["notes"]
    )
    assert (
        "source_notation_scanned_minors=L2a1:118,3_1:549,4_1:1812"
        in summaries["multivariable_alexander_signed_pd_coverage_report"]["notes"]
    )
    json.dumps(payload, allow_nan=False)

def test_imgui_analysis_payload_aggregates_depth_three_generated_coverage_pack() -> None:
    homfly = homfly_small_diagram_coverage_report(
        branch_depth=3,
        max_depth=12,
        max_nodes=8192,
    )
    alexander = multivariable_alexander_signed_pd_coverage_report(branch_depth=3)

    payload = imgui_analysis_payload_from_acceptance_reports([homfly, alexander])

    assert payload["analysis_summary_count"] == 2
    assert alexander["accepted_case_count"] == 2162
    assert alexander["uncertified_case_count"] == 100
    assert payload["analysis_required_check_count"] == 4524
    assert payload["analysis_passed_check_count"] == 4424
    assert payload["analysis_failed_check_count"] == 100
    assert payload["analysis_certification_applicable_count"] == 4524
    assert payload["analysis_certification_certified_count"] == 4424
    assert payload["analysis_certification_uncertified_count"] == 100
    assert payload["analysis_input_certification_iterative_attempt_count"] == 9715
    assert payload["analysis_input_certification_iterative_solved_count"] == 2262
    assert payload["analysis_input_certification_iterative_max_solved_depth"] == 7
    assert payload["analysis_bounded_scanned_gcd_scanned_minor_count"] == 21175
    assert payload["analysis_bounded_scanned_gcd_checked_nonzero_minor_count"] == 19639
    assert payload["analysis_bounded_scanned_gcd_complete_scan_count"] == 2142
    assert (
        payload["analysis_bounded_scanned_gcd_nonzero_minor_coverage_complete_count"]
        == 1866
    )
    assert payload["analysis_bounded_scanned_gcd_quotient_gcd_certified_count"] == 2142
    assert payload["analysis_bounded_scanned_gcd_complete_certified_count"] == 1866
    assert payload["analysis_wirtinger_fox_scanned_minor_count"] == 21175
    assert payload["analysis_wirtinger_fox_complete_scan_count"] == 2142
    assert payload["analysis_generated_case_count"] == (
        homfly["case_count"] + alexander["case_count"]
    )
    assert payload["analysis_generated_non_fixture_case_count"] == (
        homfly["non_fixture_case_count"] + alexander["non_fixture_case_count"]
    )
    assert payload["analysis_generated_source_notation_count"] == (
        len(homfly["source_notation_summary"])
        + len(alexander["source_notation_summary"])
    )
    assert payload["analysis_generated_max_branch_depth"] == 3
    assert payload["analysis_generated_unique_diagram_count"] == (
        homfly["unique_diagram_count"] + alexander["unique_diagram_count"]
    )
    assert payload["analysis_generated_unique_oriented_diagram_count"] == (
        homfly["unique_oriented_diagram_count"]
        + alexander["unique_oriented_diagram_count"]
    )
    assert payload["analysis_generated_zero_crossing_unlink_case_count"] == alexander[
        "zero_crossing_unlink_certified_case_count"
    ]
    assert payload["analysis_generated_oriented_polynomial_conflict_count"] == homfly[
        "oriented_polynomial_conflict_count"
    ]
    assert payload["analysis_generated_unique_evaluation_count"] == (
        homfly["unique_evaluation_count"]
        + alexander["nonzero_unique_evaluation_count"]
    )
    assert payload["analysis_generated_reused_evaluation_count"] == (
        homfly["reused_evaluation_count"]
        + alexander["nonzero_reused_evaluation_count"]
    )
    summaries = {row["source_method"]: row for row in payload["analysis_summaries"]}
    assert summaries["homfly_small_diagram_coverage_report"][
        "required_check_count"
    ] == 2262
    assert summaries["homfly_small_diagram_coverage_report"][
        "input_certification_iterative_attempt_count"
    ] == 9715
    assert summaries["homfly_small_diagram_coverage_report"][
        "input_certification_iterative_solved_count"
    ] == 2262
    assert summaries["multivariable_alexander_signed_pd_coverage_report"][
        "required_check_count"
    ] == 2262
    assert summaries["multivariable_alexander_signed_pd_coverage_report"][
        "passed_check_count"
    ] == 2162
    assert summaries["multivariable_alexander_signed_pd_coverage_report"][
        "failed_check_count"
    ] == 100
    assert summaries["multivariable_alexander_signed_pd_coverage_report"][
        "bounded_scanned_gcd_scanned_minor_count"
    ] == 21175
    assert (
        "source_notation_accepted_cases=L2a1:169/169,3_1:604/604,4_1:1389/1489"
        in summaries["multivariable_alexander_signed_pd_coverage_report"]["notes"]
    )
    json.dumps(payload, allow_nan=False)

def test_imgui_analysis_payload_wraps_acceptance_reports() -> None:
    homfly = homfly_fixture_acceptance_report(notations=["0_1"])
    alexander = multivariable_alexander_fixture_acceptance_report(notations=["L2a1"])
    alexander_maturity_consistency = alexander["bounded_alexander_maturity_path_summary_consistency"]

    payload = imgui_analysis_payload_from_acceptance_reports([homfly, alexander])

    assert payload["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert payload["analysis_summary_count"] == 2
    by_name = {summary["name"]: summary for summary in payload["analysis_summaries"]}

    homfly_summary = by_name["HOMFLY fixture acceptance"]
    assert homfly_summary["source_method"] == "homfly_fixture_acceptance_report"
    assert homfly_summary["accepted"] is True
    assert homfly_summary["certified"] is False
    assert homfly_summary["required_check_count"] == homfly["required_check_count"]
    assert homfly_summary["passed_check_count"] == homfly["passed_check_count"]
    assert homfly_summary["failed_check_count"] == homfly["failed_check_count"]
    assert homfly_summary["certification_scope"] == homfly["input_certification_scope"]
    assert homfly_summary["certification_applicable_count"] == 1
    assert homfly_summary["certification_certified_count"] == 1
    assert homfly_summary["certification_uncertified_count"] == 0
    assert homfly_summary["input_certification_recursion_node_count"] == (
        homfly["input_certification_recursion_node_count"]
    )
    assert homfly_summary["input_certification_terminal_reduction_count"] == (
        homfly["input_certification_terminal_reduction_count"]
    )
    assert homfly_summary["input_certification_frontier_count"] == 0
    assert homfly_summary["input_certification_frontier_reason_count"] == 0
    assert homfly_summary["input_certification_truncated_count"] == 0
    assert homfly_summary["input_certification_zero_crossing_count"] == 1
    assert homfly_summary["input_certification_iterative_attempt_count"] == (
        homfly["input_certification_iterative_attempt_count"]
    )
    assert homfly_summary["input_certification_iterative_solved_count"] == (
        homfly["input_certification_iterative_solved_count"]
    )
    assert homfly_summary["input_certification_iterative_max_solved_depth"] == (
        homfly["input_certification_iterative_max_solved_depth"]
    )
    assert (
        homfly_summary[
            "input_certification_terminal_contribution_audit_applicable_count"
        ]
        == homfly[
            "input_certification_terminal_contribution_audit_applicable_count"
        ]
    )
    assert homfly_summary[
        "input_certification_terminal_contribution_matched_count"
    ] == homfly["input_certification_terminal_contribution_matched_count"]
    assert homfly_summary[
        "input_certification_terminal_contribution_failed_count"
    ] == homfly["input_certification_terminal_contribution_failed_count"]
    assert homfly_summary["bounded_homfly_maturity_path_certified_count"] == (
        homfly["bounded_homfly_maturity_path_certified_count"]
    )
    assert homfly_summary["bounded_homfly_maturity_path_distinct_count"] == (
        homfly["bounded_homfly_maturity_path_distinct_count"]
    )
    assert homfly_summary[
        "bounded_homfly_maturity_path_zero_crossing_unlink_count"
    ] == 1
    assert "bounded_homfly_maturity_paths=zero_crossing_unlink_terminal:1" in (
        homfly_summary["notes"]
    )
    assert homfly_summary["bounded_scanned_gcd_scanned_minor_count"] == 0

    alexander_summary = by_name["multi-variable Alexander fixture acceptance"]
    assert alexander_summary["source_method"] == (
        "multivariable_alexander_fixture_acceptance_report"
    )
    assert alexander_summary["accepted"] is True
    assert alexander_summary["certified"] is False
    assert alexander_summary["required_check_count"] == 4
    assert alexander_summary["passed_check_count"] == 4
    assert alexander_summary["failed_check_count"] == 0
    assert alexander_summary["certification_scope"] == (
        alexander["bounded_certification_scope"]
    )
    assert alexander_summary["certification_applicable_count"] == 1
    assert alexander_summary["certification_certified_count"] == 1
    assert alexander_summary["certification_uncertified_count"] == 0
    assert alexander_summary["input_certification_frontier_count"] == 0
    assert alexander_summary["bounded_scanned_gcd_checked_nonzero_minor_count"] >= 1
    assert alexander_summary["bounded_scanned_gcd_failed_nonzero_minor_count"] == 0
    assert alexander_summary["bounded_scanned_gcd_scanned_minor_count"] >= 1
    assert alexander_summary["bounded_scanned_gcd_division_record_count"] >= 1
    assert alexander_summary["bounded_scanned_gcd_complete_scan_count"] == 1
    assert (
        alexander_summary[
            "bounded_scanned_gcd_nonzero_minor_coverage_complete_count"
        ]
        == 1
    )
    assert alexander_summary["bounded_scanned_gcd_truncated_count"] == 0
    assert alexander_summary["bounded_scanned_gcd_quotient_gcd_certified_count"] == 1
    assert alexander_summary["bounded_scanned_gcd_complete_certified_count"] == 1
    assert alexander_summary["bounded_scanned_gcd_improved_candidate_count"] == 0
    assert alexander_summary["bounded_alexander_maturity_path_certified_count"] == (
        alexander["bounded_alexander_maturity_path_certified_count"]
    )
    assert alexander_summary["bounded_alexander_maturity_path_distinct_count"] == (
        alexander["bounded_alexander_maturity_path_distinct_count"]
    )
    assert alexander_summary[
        "bounded_alexander_maturity_path_exact_scanned_gcd_count"
    ] == 1
    assert "bounded_alexander_maturity_paths=exact_scanned_gcd:1" in (
        alexander_summary["notes"]
    )
    assert alexander_summary[
        "registered_knot_admissible_normalization_applicable_count"
    ] == 0
    assert alexander_summary[
        "registered_knot_admissible_normalization_certified_count"
    ] == 0
    assert alexander_summary[
        "registered_knot_admissible_normalization_uncertified_count"
    ] == 0
    assert alexander_summary["wirtinger_fox_relation_count"] >= 1
    assert alexander_summary["wirtinger_fox_generator_count"] >= 1
    assert alexander_summary["wirtinger_fox_scanned_minor_count"] >= 1
    assert alexander_summary["wirtinger_fox_invalid_minor_reference_count"] == 0
    assert alexander_summary["wirtinger_fox_invalid_normalization_count"] == 0
    assert alexander_summary["wirtinger_fox_complete_scan_count"] == 1
    assert alexander_summary["wirtinger_fox_truncated_count"] == 0

    assert payload["analysis_required_check_count"] == (
        homfly_summary["required_check_count"]
        + alexander_summary["required_check_count"]
    )
    assert payload["analysis_passed_check_count"] == (
        homfly_summary["passed_check_count"] + alexander_summary["passed_check_count"]
    )
    assert payload["analysis_failed_check_count"] == 0
    assert payload["analysis_certification_applicable_count"] == 2
    assert payload["analysis_certification_certified_count"] == 2
    assert payload["analysis_certification_uncertified_count"] == 0
    assert payload["analysis_input_certification_zero_crossing_count"] == 1
    assert payload["analysis_input_certification_iterative_attempt_count"] == (
        homfly_summary["input_certification_iterative_attempt_count"]
    )
    assert payload["analysis_input_certification_iterative_solved_count"] == (
        homfly_summary["input_certification_iterative_solved_count"]
    )
    assert payload["analysis_input_certification_iterative_max_solved_depth"] == (
        homfly_summary["input_certification_iterative_max_solved_depth"]
    )
    assert payload[
        "analysis_input_certification_terminal_contribution_matched_count"
    ] == homfly_summary[
        "input_certification_terminal_contribution_matched_count"
    ]
    assert payload[
        "analysis_input_certification_terminal_contribution_failed_count"
    ] == 0
    assert payload["analysis_bounded_homfly_maturity_path_certified_count"] == (
        homfly_summary["bounded_homfly_maturity_path_certified_count"]
    )
    assert payload[
        "analysis_bounded_homfly_maturity_path_zero_crossing_unlink_count"
    ] == 1
    assert payload["analysis_input_certification_frontier_count"] == 0
    assert payload["analysis_input_certification_frontier_reason_count"] == 0
    assert payload["analysis_input_certification_truncated_count"] == 0
    assert payload["analysis_bounded_scanned_gcd_checked_nonzero_minor_count"] == (
        alexander_summary["bounded_scanned_gcd_checked_nonzero_minor_count"]
    )
    assert payload["analysis_bounded_scanned_gcd_failed_nonzero_minor_count"] == 0
    assert (
        payload[
            "analysis_bounded_scanned_gcd_nonzero_minor_coverage_complete_count"
        ]
        == alexander_summary[
            "bounded_scanned_gcd_nonzero_minor_coverage_complete_count"
        ]
    )
    assert payload["analysis_bounded_scanned_gcd_truncated_count"] == 0
    assert payload["analysis_bounded_scanned_gcd_quotient_gcd_certified_count"] == (
        alexander_summary["bounded_scanned_gcd_quotient_gcd_certified_count"]
    )
    assert payload["analysis_bounded_scanned_gcd_complete_certified_count"] == (
        alexander_summary["bounded_scanned_gcd_complete_certified_count"]
    )
    assert payload["analysis_bounded_scanned_gcd_improved_candidate_count"] == 0
    assert payload["analysis_bounded_alexander_maturity_path_certified_count"] == (
        alexander_summary["bounded_alexander_maturity_path_certified_count"]
    )
    assert payload[
        "analysis_bounded_alexander_maturity_path_exact_scanned_gcd_count"
    ] == 1
    assert payload[
        "analysis_registered_knot_admissible_normalization_applicable_count"
    ] == 0
    assert payload[
        "analysis_registered_knot_admissible_normalization_certified_count"
    ] == 0
    assert payload[
        "analysis_registered_knot_admissible_normalization_uncertified_count"
    ] == 0
    assert payload["analysis_wirtinger_fox_relation_count"] == (
        alexander_summary["wirtinger_fox_relation_count"]
    )
    assert payload["analysis_wirtinger_fox_invalid_minor_reference_count"] == 0
    assert payload["analysis_wirtinger_fox_invalid_normalization_count"] == 0
    assert payload["analysis_wirtinger_fox_truncated_count"] == 0
    json.dumps(payload, allow_nan=False)


def test_imgui_analysis_summary_wraps_homfly_unregistered_source_table_gap() -> None:
    report = homfly_fixture_acceptance_report(
        notations=["L6a4"],
        include_unregistered=True,
    )

    summary = analysis_summary_from_acceptance_report(report)

    assert summary["source_method"] == "homfly_fixture_acceptance_report"
    assert summary["accepted"] is False
    assert summary["source_table_audit_registration_ready_count"] == 0
    assert summary["source_table_audit_registration_blocked_count"] == 1
    assert summary["source_table_audit_registration_blocker_count"] == 4
    assert summary["source_table_audit_registration_blocker_code_count"] == 4
    assert summary["source_table_audit_registration_blockers"] == (
        "fixture_signs_not_registered,"
        "registered_fixture_invariant_claim_disabled,"
        "source_compatible_sign_pattern_not_unique,"
        "source_table_values_mismatched"
    )
    assert summary["source_table_audit_registration_blocker_count_signature"] == (
        "fixture_signs_not_registered:1,"
        "registered_fixture_invariant_claim_disabled:1,"
        "source_compatible_sign_pattern_not_unique:1,"
        "source_table_values_mismatched:1"
    )
    assert (
        summary[
            "source_table_audit_registration_summary_consistency_available_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_audit_registration_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_audit_registration_summary_consistency_mismatch_count"
        ]
        == 0
    )
    assert (
        summary["source_table_audit_registration_summary_consistency_status"]
        == "matched"
    )
    assert (
        summary[
            "source_table_audit_registration_summary_consistency_first_mismatch"
        ]
        == ""
    )
    assert (
        "source_table_registration=checked=1; ready=0; blocked=1; blockers=4"
        in summary["notes"]
    )
    assert "registration_summary_consistency=matched" in summary["notes"]
    assert "registration_summary_mismatches=0" in summary["notes"]
    assert "source_table_values_mismatched" in summary["notes"]

    status = invariant_status_from_acceptance_report(report)
    assert status["source_table_audit_registration_ready_count"] == 0
    assert status["source_table_audit_registration_blocked_count"] == 1
    assert status["source_table_audit_registration_blocker_count"] == 4
    assert status["source_table_audit_registration_blocker_code_count"] == 4
    assert status["source_table_audit_registration_blocker_count_signature"] == (
        summary["source_table_audit_registration_blocker_count_signature"]
    )
    assert (
        status[
            "source_table_audit_registration_summary_consistency_available_count"
        ]
        == 1
    )
    assert (
        status[
            "source_table_audit_registration_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        status[
            "source_table_audit_registration_summary_consistency_mismatch_count"
        ]
        == 0
    )
    assert (
        status["source_table_audit_registration_summary_consistency_status"]
        == "matched"
    )

    invariant_payload = imgui_invariant_status_payload_from_acceptance_reports(
        [report]
    )
    assert (
        invariant_payload[
            "invariant_source_table_audit_registration_summary_consistency_available_count"
        ]
        == 1
    )
    assert (
        invariant_payload[
            "invariant_source_table_audit_registration_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        invariant_payload[
            "invariant_source_table_audit_registration_summary_consistency_mismatch_count"
        ]
        == 0
    )

    payload = imgui_analysis_payload_from_acceptance_reports([report])
    assert payload["analysis_source_table_audit_registration_ready_count"] == 0
    assert payload["analysis_source_table_audit_registration_blocked_count"] == 1
    assert payload["analysis_source_table_audit_registration_blocker_count"] == 4
    assert (
        payload["analysis_source_table_audit_registration_blocker_code_count"]
        == 4
    )
    assert (
        payload[
            "analysis_source_table_audit_registration_summary_consistency_available_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_source_table_audit_registration_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_source_table_audit_registration_summary_consistency_mismatch_count"
        ]
        == 0
    )
    json.dumps(payload, allow_nan=False)
    json.dumps(invariant_payload, allow_nan=False)


def test_imgui_source_table_registration_summary_consistency_mismatch_is_host_visible() -> None:
    report = homfly_fixture_acceptance_report(
        notations=["L6a4"],
        include_unregistered=True,
    )
    consistency = report["source_table_registration_summary_consistency"]
    consistency["matched"] = False
    consistency["mismatch_count"] = 2
    consistency["first_mismatch"] = {
        "kind": "count_total",
        "field": "blocked_count",
    }

    summary = analysis_summary_from_acceptance_report(report)
    status = invariant_status_from_acceptance_report(report)
    analysis_payload = imgui_analysis_payload_from_acceptance_reports([report])
    invariant_payload = imgui_invariant_status_payload_from_acceptance_reports(
        [report]
    )
    host_payload = imgui_host_payload_from_acceptance_reports(
        [report],
        analysis_reports=[report],
    )

    for row in (summary, status):
        assert (
            row[
                "source_table_audit_registration_summary_consistency_available_count"
            ]
            == 1
        )
        assert (
            row[
                "source_table_audit_registration_summary_consistency_matched_count"
            ]
            == 0
        )
        assert (
            row[
                "source_table_audit_registration_summary_consistency_mismatch_count"
            ]
            == 2
        )
        assert (
            row["source_table_audit_registration_summary_consistency_status"]
            == "mismatched"
        )
        assert (
            row[
                "source_table_audit_registration_summary_consistency_first_mismatch"
            ]
            == "count_total:blocked_count"
        )
        assert "registration_summary_consistency=mismatched" in row["notes"]
        assert "registration_summary_mismatches=2" in row["notes"]
        assert (
            "registration_summary_first_mismatch=count_total:blocked_count"
            in row["notes"]
        )

    assert (
        analysis_payload[
            "analysis_source_table_audit_registration_summary_consistency_available_count"
        ]
        == 1
    )
    assert (
        analysis_payload[
            "analysis_source_table_audit_registration_summary_consistency_matched_count"
        ]
        == 0
    )
    assert (
        analysis_payload[
            "analysis_source_table_audit_registration_summary_consistency_mismatch_count"
        ]
        == 2
    )
    assert (
        invariant_payload[
            "invariant_source_table_audit_registration_summary_consistency_matched_count"
        ]
        == 0
    )
    assert (
        invariant_payload[
            "invariant_source_table_audit_registration_summary_consistency_mismatch_count"
        ]
        == 2
    )
    host_analysis = host_payload["analysis"]
    assert (
        host_analysis[
            "analysis_source_table_audit_registration_summary_consistency_matched_count"
        ]
        == 0
    )
    assert (
        host_analysis[
            "analysis_source_table_audit_registration_summary_consistency_mismatch_count"
        ]
        == 2
    )
    host_invariants = host_payload["invariants"]
    assert (
        host_invariants[
            "invariant_source_table_audit_registration_summary_consistency_matched_count"
        ]
        == 0
    )
    assert (
        host_invariants[
            "invariant_source_table_audit_registration_summary_consistency_mismatch_count"
        ]
        == 2
    )
    assert (
        "registration_summary_first_mismatch=count_total:blocked_count"
        in host_analysis["analysis_summaries"][0]["notes"]
    )
    assert (
        "registration_summary_first_mismatch=count_total:blocked_count"
        in host_invariants["invariant_statuses"][0]["notes"]
    )
    json.dumps(host_payload, allow_nan=False)
    json.dumps(analysis_payload, allow_nan=False)
    json.dumps(invariant_payload, allow_nan=False)

def test_imgui_analysis_summary_keeps_unregistered_fixture_gap_visible() -> None:
    report = multivariable_alexander_fixture_acceptance_report(
        notations=["L5a1"],
        include_unregistered=True,
    )

    summary = analysis_summary_from_acceptance_report(report)

    assert summary["accepted"] is False
    assert summary["required_check_count"] == 1
    assert summary["passed_check_count"] == 0
    assert summary["failed_check_count"] == 1
    assert summary["certification_scope"] == (
        "exact_scanned_fox_minor_gcd_for_registered_signed_pd_inputs"
    )
    assert summary["certification_applicable_count"] == 0
    assert summary["certification_certified_count"] == 0
    assert summary["certification_uncertified_count"] == 0
    assert summary["source_table_alexander_numerator_checked_count"] == 1
    assert summary["source_table_alexander_numerator_source_seen_count"] == 1
    assert summary["source_table_alexander_numerator_complete_match_count"] == 0
    assert summary["source_table_alexander_numerator_returned_match_count"] == 0
    assert summary["source_table_alexander_numerator_incomplete_or_unstable_count"] == 1
    assert summary["source_table_alexander_numerator_candidate_unique_value_count"] == 2
    assert summary["source_table_alexander_numerator_computed_candidate_count"] == 16
    assert summary["source_table_alexander_numerator_skipped_candidate_count"] == 8
    assert summary["source_table_alexander_numerator_missing_candidate_count"] == 8
    assert (
        summary[
            "source_table_alexander_numerator_link_normalization_checked_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_alexander_numerator_link_normalization_ready_count"
        ]
        == 0
    )
    assert (
        summary[
            "source_table_alexander_numerator_link_normalization_blocked_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_alexander_numerator_link_normalization_blocker_count"
        ]
        == 2
    )
    assert summary["source_table_alexander_skipped_common_gcd_attempt_candidate_count"] == 8
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count"
        ]
        == 8
    )
    assert summary["source_table_alexander_skipped_common_gcd_attempt_method_count"] == 8
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_limit_variant_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_min"
        ]
        == 10
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max"
        ]
        == 10
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_checked_candidate_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_source_divides_all_candidate_count"
        ]
        == 0
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_source_division_failed_candidate_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_status_variant_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_failed_candidate_witness_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_failed_candidate_witness_truncated"
        ]
        == 0
    )
    assert summary["source_table_audit_registration_ready_count"] == 0
    assert summary["source_table_audit_registration_blocked_count"] == 1
    assert summary["source_table_audit_registration_blocker_count"] == 4
    assert summary["source_table_audit_registration_blockers"] == (
        "fixture_signs_not_registered,"
        "registered_fixture_invariant_claim_disabled,"
        "source_compatible_sign_pattern_not_unique,"
        "source_table_values_uncomputed"
    )
    assert summary["source_table_audit_registration_blocker_code_count"] == 4
    assert summary["source_table_audit_registration_blocker_count_signature"] == (
        "fixture_signs_not_registered:1,"
        "registered_fixture_invariant_claim_disabled:1,"
        "source_compatible_sign_pattern_not_unique:1,"
        "source_table_values_uncomputed:1"
    )
    assert (
        summary[
            "source_table_audit_registration_summary_consistency_available_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_audit_registration_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_audit_registration_summary_consistency_mismatch_count"
        ]
        == 0
    )
    assert (
        summary["source_table_audit_registration_summary_consistency_status"]
        == "matched"
    )
    assert "source_table_alexander_numerator=checked=1" in summary["notes"]
    assert "source_seen=1" in summary["notes"]
    assert "complete_match=0" in summary["notes"]
    assert "skipped_candidates=8" in summary["notes"]
    assert (
        "source_table_alexander_link_normalization="
        "checked=1; ready=0; blocked=1; blockers=2"
        in summary["notes"]
    )
    assert (
        "source_table_alexander_skipped_common_gcd_attempts="
        "candidates=8; not_certified=8; statuses=not_certified:8"
        in summary["notes"]
    )
    assert (
        "source_table_alexander_source_divisibility="
        "candidates=8; source_divides_all=0; source_division_failed=8; "
        "statuses=source_does_not_divide_all_inputs:8"
        in summary["notes"]
    )
    assert "failed_inputs=10..10" in summary["notes"]
    assert "input_polynomials=25..25" in summary["notes"]
    assert "unique_inputs=10..10" in summary["notes"]
    assert "direct_divisor_candidates=10" in summary["notes"]
    assert "direct_divisor_failed=10" in summary["notes"]
    assert "direct_divisor_all_failed=1" in summary["notes"]
    assert "limit_variants=1" in summary["notes"]
    assert "failed_candidate_witness_count=8" in summary["notes"]
    assert "failed_candidate_witness_truncated=False" in summary["notes"]
    assert (
        "source_table_registration=checked=1; ready=0; blocked=1; blockers=4"
        in summary["notes"]
    )
    assert "registration_summary_consistency=matched" in summary["notes"]
    assert "registration_summary_mismatches=0" in summary["notes"]
    assert "registration_ready=false" in summary["notes"]
    assert "fixture_signs_not_registered" in summary["notes"]
    assert "registered_fixture_invariant_claim_disabled" in summary["notes"]
    assert "source_table_values_uncomputed" in summary["notes"]
    assert "source_compatible_sign_pattern_not_unique" in summary["notes"]
    assert "first_failed_candidate_witness_notation=L5a1" in summary["notes"]
    assert "first_failed_candidate_witness_candidate=4" in summary["notes"]
    assert (
        "first_failed_candidate_witness_status="
        "source_does_not_divide_all_inputs"
        in summary["notes"]
    )
    assert (
        "first_failed_candidate_witness_input="
        "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2"
        in summary["notes"]
    )
    assert "L5a1" in summary["notes"]

    payload = imgui_analysis_payload_from_acceptance_reports([report])
    assert payload["analysis_source_table_alexander_numerator_checked_count"] == 1
    assert payload["analysis_source_table_alexander_numerator_source_seen_count"] == 1
    assert payload["analysis_source_table_alexander_numerator_complete_match_count"] == 0
    assert payload["analysis_source_table_alexander_numerator_returned_match_count"] == 0
    assert (
        payload[
            "analysis_source_table_alexander_numerator_incomplete_or_unstable_count"
        ]
        == 1
    )
    assert (
        payload["analysis_source_table_alexander_numerator_candidate_unique_value_count"]
        == 2
    )
    assert payload["analysis_source_table_alexander_numerator_computed_candidate_count"] == 16
    assert payload["analysis_source_table_alexander_numerator_skipped_candidate_count"] == 8
    assert payload["analysis_source_table_alexander_numerator_missing_candidate_count"] == 8
    assert (
        payload[
            "analysis_source_table_alexander_numerator_link_normalization_checked_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_source_table_alexander_numerator_link_normalization_ready_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_source_table_alexander_numerator_link_normalization_blocked_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_source_table_alexander_numerator_link_normalization_blocker_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_source_table_alexander_skipped_common_gcd_attempt_candidate_count"
        ]
        == 8
    )
    assert (
        payload[
            "analysis_source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count"
        ]
        == 8
    )
    assert (
        payload["analysis_source_table_alexander_skipped_common_gcd_attempt_method_count"]
        == 8
    )
    assert (
        payload[
            "analysis_source_table_alexander_skipped_common_gcd_attempt_limit_variant_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count"
        ]
        == 8
    )
    assert (
        payload[
            "analysis_source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_min"
        ]
        == 10
    )
    assert (
        payload[
            "analysis_source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max"
        ]
        == 10
    )
    assert (
        payload[
            "analysis_source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 8
    )
    assert (
        payload[
            "analysis_source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min"
        ]
        == 25
    )
    assert (
        payload[
            "analysis_source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max"
        ]
        == 25
    )
    assert (
        payload[
            "analysis_source_table_alexander_source_divisibility_checked_candidate_count"
        ]
        == 8
    )
    assert (
        payload[
            "analysis_source_table_alexander_source_divisibility_source_divides_all_candidate_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_source_table_alexander_source_divisibility_source_division_failed_candidate_count"
        ]
        == 8
    )
    assert (
        payload[
            "analysis_source_table_alexander_source_divisibility_status_variant_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_source_table_alexander_source_divisibility_failed_candidate_witness_count"
        ]
        == 8
    )
    assert (
        payload[
            "analysis_source_table_alexander_source_divisibility_failed_candidate_witness_truncated"
        ]
        == 0
    )
    assert payload["analysis_source_table_audit_registration_ready_count"] == 0
    assert payload["analysis_source_table_audit_registration_blocked_count"] == 1
    assert payload["analysis_source_table_audit_registration_blocker_count"] == 4
    assert (
        payload["analysis_source_table_audit_registration_blocker_code_count"]
        == 4
    )
    assert (
        payload[
            "analysis_source_table_audit_registration_summary_consistency_available_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_source_table_audit_registration_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_source_table_audit_registration_summary_consistency_mismatch_count"
        ]
        == 0
    )
    json.dumps(payload, allow_nan=False)


def test_imgui_source_table_alexander_witness_flattening_infers_truncated_stale_count() -> None:
    report = {
        "method": "multivariable_alexander_fixture_acceptance_report",
        "claim_scope": "registered_fixture_acceptance_under_iroll_convention",
        "accepted": False,
        "required_check_count": 1,
        "passed_check_count": 0,
        "failed_check_count": 1,
        "source_table_multivariable_alexander_numerator_checked_count": 1,
        "source_table_multivariable_alexander_numerator_source_seen_count": 1,
        "source_table_multivariable_alexander_numerator_complete_match_count": 0,
        "source_table_multivariable_alexander_numerator_returned_match_count": 0,
        "source_table_multivariable_alexander_numerator_incomplete_or_unstable_count": 1,
        "source_table_multivariable_alexander_numerator_candidate_unique_value_count": 1,
        "source_table_multivariable_alexander_numerator_computed_candidate_count": 3,
        "source_table_multivariable_alexander_numerator_skipped_candidate_count": 0,
        "source_table_multivariable_alexander_numerator_missing_candidate_count": 0,
        "source_table_alexander_source_numerator_divisibility_summary": {
            "checked_candidate_count": 3,
            "source_divides_all_candidate_count": 0,
            "source_division_failed_candidate_count": 3,
            "status_counts": [
                {
                    "status": "source_does_not_divide_all_inputs",
                    "candidate_count": 3,
                },
            ],
            "candidate_indices": [4, 5, 10],
            "first_failed_candidate_index": 4,
            "first_failed_input_polynomial": "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2",
            "failed_candidate_witness_count": 3,
            "failed_candidate_witnesses": [
                {
                    "notation": "L5a1",
                    "candidate_index": 4,
                    "status": "source_does_not_divide_all_inputs",
                    "first_failed_input_witness": {
                        "input_polynomial": (
                            "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2"
                        ),
                    },
                },
                {
                    "notation": "L5a1",
                    "candidate_index": 5,
                    "status": "source_does_not_divide_all_inputs",
                    "input_polynomial": "1 - t1",
                },
            ],
        },
        "notes": [],
    }
    note_tokens = [
        "failed_candidate_witness_count=3",
        "failed_candidate_witness_truncated=True",
        "first_failed_candidate_witness_notation=L5a1",
        "first_failed_candidate_witness_candidate=4",
        "first_failed_candidate_witness_status=source_does_not_divide_all_inputs",
        (
            "first_failed_candidate_witness_input="
            "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2"
        ),
    ]

    summary = analysis_summary_from_acceptance_report(report)
    status = invariant_status_from_acceptance_report(report)
    analysis_payload = imgui_analysis_payload_from_acceptance_reports([report])
    status_payload = imgui_invariant_status_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [report],
        analysis_reports=[report],
    )
    host_status = host_payload["invariants"]["invariant_statuses"][0]

    assert (
        summary[
            "source_table_alexander_source_divisibility_failed_candidate_witness_count"
        ]
        == 3
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_failed_candidate_witness_truncated"
        ]
        == 1
    )
    assert (
        status[
            "source_table_alexander_source_divisibility_failed_candidate_witness_count"
        ]
        == 3
    )
    assert (
        status[
            "source_table_alexander_source_divisibility_failed_candidate_witness_truncated"
        ]
        == 1
    )
    assert (
        analysis_payload[
            "analysis_source_table_alexander_source_divisibility_failed_candidate_witness_count"
        ]
        == 3
    )
    assert (
        analysis_payload[
            "analysis_source_table_alexander_source_divisibility_failed_candidate_witness_truncated"
        ]
        == 1
    )
    assert (
        status_payload[
            "invariant_source_table_alexander_source_divisibility_failed_candidate_witness_count"
        ]
        == 3
    )
    assert (
        status_payload[
            "invariant_source_table_alexander_source_divisibility_failed_candidate_witness_truncated"
        ]
        == 1
    )
    assert (
        host_payload["analysis"][
            "analysis_source_table_alexander_source_divisibility_failed_candidate_witness_truncated"
        ]
        == 1
    )
    assert (
        host_payload["invariants"][
            "invariant_source_table_alexander_source_divisibility_failed_candidate_witness_truncated"
        ]
        == 1
    )
    for token in note_tokens:
        assert token in summary["notes"]
        assert token in status["notes"]
        assert token in host_payload["analysis"]["analysis_summaries"][0]["notes"]
        assert token in host_status["notes"]
    json.dumps(host_payload, allow_nan=False)
    json.dumps(analysis_payload, allow_nan=False)
    json.dumps(status_payload, allow_nan=False)

def test_imgui_source_table_alexander_witness_flattening_defaults_legacy_reports_to_zero() -> None:
    report = {
        "method": "multivariable_alexander_fixture_acceptance_report",
        "claim_scope": "registered_fixture_acceptance_under_iroll_convention",
        "accepted": False,
        "required_check_count": 1,
        "passed_check_count": 0,
        "failed_check_count": 1,
        "source_table_multivariable_alexander_numerator_checked_count": 1,
        "source_table_multivariable_alexander_numerator_source_seen_count": 1,
        "source_table_multivariable_alexander_numerator_complete_match_count": 0,
        "source_table_multivariable_alexander_numerator_returned_match_count": 0,
        "source_table_multivariable_alexander_numerator_incomplete_or_unstable_count": 1,
        "source_table_multivariable_alexander_numerator_candidate_unique_value_count": 1,
        "source_table_multivariable_alexander_numerator_computed_candidate_count": 2,
        "source_table_multivariable_alexander_numerator_skipped_candidate_count": 0,
        "source_table_multivariable_alexander_numerator_missing_candidate_count": 0,
        "source_table_alexander_source_numerator_divisibility_summary": {
            "checked_candidate_count": 2,
            "source_divides_all_candidate_count": 1,
            "source_division_failed_candidate_count": 1,
            "status_counts": [
                {
                    "status": "source_does_not_divide_all_inputs",
                    "candidate_count": 1,
                },
            ],
            "candidate_indices": [3],
            "first_failed_candidate_index": 3,
            "first_failed_input_polynomial": "1 - t1",
        },
        "notes": [],
    }

    summary = analysis_summary_from_acceptance_report(report)
    status = invariant_status_from_acceptance_report(report)
    analysis_payload = imgui_analysis_payload_from_acceptance_reports([report])
    status_payload = imgui_invariant_status_payload_from_acceptance_reports([report])

    assert (
        summary[
            "source_table_alexander_source_divisibility_failed_candidate_witness_count"
        ]
        == 0
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_failed_candidate_witness_truncated"
        ]
        == 0
    )
    assert (
        status[
            "source_table_alexander_source_divisibility_failed_candidate_witness_count"
        ]
        == 0
    )
    assert (
        status[
            "source_table_alexander_source_divisibility_failed_candidate_witness_truncated"
        ]
        == 0
    )
    assert (
        analysis_payload[
            "analysis_source_table_alexander_source_divisibility_failed_candidate_witness_count"
        ]
        == 0
    )
    assert (
        status_payload[
            "invariant_source_table_alexander_source_divisibility_failed_candidate_witness_count"
        ]
        == 0
    )
    assert "failed_candidate_witness_count=" not in summary["notes"]
    assert "first_failed_candidate_witness_" not in status["notes"]
    json.dumps(analysis_payload, allow_nan=False)
    json.dumps(status_payload, allow_nan=False)

def test_imgui_analysis_summary_accepts_custom_display_name() -> None:
    summary = analysis_summary_from_acceptance_report(
        {
            "method": "custom_acceptance_report",
            "claim_scope": "fixture_subset",
            "accepted": False,
            "certified": True,
            "required_check_count": 4,
            "passed_check_count": 3,
            "failed_check_count": 1,
            "notes": ["bounded fixture pack only"],
        },
        name="custom fixture gate",
    )

    expected_core = {
        "name": "custom fixture gate",
        "source_method": "custom_acceptance_report",
        "claim_scope": "fixture_subset",
        "accepted": False,
        "certified": True,
        "required_check_count": 4,
        "passed_check_count": 3,
        "failed_check_count": 1,
        "notes": "bounded fixture pack only",
    }
    for key, value in expected_core.items():
        assert summary[key] == value

    assert summary["certification_scope"] == ""
    assert summary["has_source_signed_pd_revision"] is False
    assert summary["role_order_signature_resolution_status"] == ""
    assert summary["role_order_signature_all_strict_candidates_evaluated"] is False
    default_zero_fields = [
        "bounded_alexander_maturity_path_summary_consistency_available_count",
        "bounded_alexander_maturity_path_summary_consistency_record_count",
        "bounded_alexander_maturity_path_summary_consistency_path_count_total",
        "homfly_case_evidence_consistency_available_count",
        "homfly_case_evidence_consistency_case_count",
        "wirtinger_fox_generator_component_count_total",
    ]
    for key in default_zero_fields:
        assert summary[key] == 0
    json.dumps(summary, allow_nan=False)

def test_imgui_fixture_comparison_payload_wraps_acceptance_rows() -> None:
    homfly = homfly_fixture_acceptance_report(notations=["0_1"])
    alexander = multivariable_alexander_fixture_acceptance_report(notations=["L2a1"])

    payload = imgui_fixture_comparison_payload_from_acceptance_reports(
        [homfly, alexander]
    )

    assert payload["method"] == (
        "imgui_fixture_comparison_payload_from_acceptance_reports"
    )
    assert payload["fixture_comparison_count"] == 2
    comparisons = {
        (row["fixture_name"], row["invariant_name"]): row
        for row in payload["fixture_comparisons"]
    }

    homfly_row = comparisons[("0_1", "HOMFLY-PT")]
    assert homfly_row["expected"] == "1"
    assert homfly_row["observed"] == "1"
    assert homfly_row["matched"] is True
    assert homfly_row["certified_for_input"] is True
    assert homfly_row["full_table_normalization_certified"] is False
    assert homfly_row["skipped"] is False
    assert "source" in homfly_row
    assert "source_url" in homfly_row
    assert homfly_row["required_check_count"] == 2
    assert homfly_row["passed_check_count"] == 2
    assert homfly_row["failed_check_count"] == 0

    alexander_row = comparisons[("L2a1", "multi-variable Alexander")]
    assert alexander_row["expected"] == "1"
    assert alexander_row["observed"] == "1"
    assert alexander_row["matched"] is True
    assert alexander_row["bounded_scanned_gcd_certified"] is True
    assert alexander_row["full_invariant_certified"] is False
    assert alexander_row["skipped"] is False
    assert alexander_row["required_check_count"] == 4
    assert alexander_row["passed_check_count"] == 4
    assert alexander_row["failed_check_count"] == 0

    assert payload["fixture_required_check_count"] == 6
    assert payload["fixture_passed_check_count"] == 6
    assert payload["fixture_failed_check_count"] == 0
    json.dumps(payload, allow_nan=False)


def test_imgui_fixture_comparison_keeps_skipped_fixture_source_visible() -> None:
    report = multivariable_alexander_fixture_acceptance_report(
        notations=["L5a1"],
        include_unregistered=True,
    )

    comparisons = fixture_comparisons_from_acceptance_report(report)

    assert len(comparisons) == 1
    comparison = comparisons[0]
    assert comparison["fixture_name"] == "L5a1"
    assert comparison["invariant_name"] == "multi-variable Alexander"
    assert comparison["expected"] == ""
    assert comparison["observed"] == ""
    assert comparison["matched"] is False
    assert comparison["skipped"] is True
    assert comparison["required_check_count"] == 1
    assert comparison["passed_check_count"] == 0
    assert comparison["failed_check_count"] == 1
    assert comparison["source_url"] == "https://katlas.org/wiki/L5a1"
    assert "source_url: https://katlas.org/wiki/L5a1" in comparison["notes"]


def test_imgui_invariant_status_payload_wraps_signed_pd_reports() -> None:
    source_candidate_replay = {
        "present": True,
        "claim_scope": "source_gauss_matched_signed_pd_candidate_replay",
        "source_notation": "L6a4",
        "source": "Knot Atlas",
        "source_url": "https://katlas.org/wiki/L6a4",
        "signs": [-1, -1, -1, 1, 1, 1],
        "role_orders": [[0, 1, 2, 3]] * 6,
        "pairwise_linking": [0.0, 0.0, 0.0],
        "orientation_validation_issues": [],
    }
    signed_pd_input_metadata = {
        "source_candidate_replay": source_candidate_replay,
        "auto_role_order": {
            "requested": True,
            "applied": False,
            "status": "not_needed",
            "candidate_count": 0,
            "strict_candidate_count": 0,
            "unique_strict_global_role_order": None,
            "candidate_role_orders": [],
            "notes": ["zero-crossing diagrams do not need role-order inference"],
        },
        "per_crossing_role_orders": [[1, 0, 2, 3], [0, 1, 2, 3]],
        "per_crossing_role_order_explicit": [True, False],
        "per_crossing_role_order_explicit_count": 1,
    }
    homfly_report = {
        "method": "homfly_pd_report",
        "claim_scope": "iterative_recursive_frontier_exhaustion_for_one_signed_pd_input",
        "input": signed_pd_input_metadata,
        "homfly_polynomial": "P",
        "certified_for_input": True,
        "skipped": False,
        "input_certification_evidence": {
            "frontier_count": 2,
            "frontier_exhausted": False,
            "max_crossings": 8,
            "initial_depth": 0,
            "max_depth": 4,
            "max_nodes": 128,
            "truncated": True,
            "terminal_contribution_audit_skipped": False,
            "terminal_contribution_matches_result": True,
            "bounded_homfly_maturity_path": "not_certified",
            "bounded_homfly_maturity_path_certified": False,
            "frontier_reasons": ["max_depth", "max_nodes"],
        },
        "notes": ["bounded HOMFLY row"],
    }
    alexander_report = {
        "method": "multivariable_alexander_pd_report",
        "input": signed_pd_input_metadata,
        "multivariable_alexander_polynomial": "1",
        "candidate_polynomials": ["1 - t1", "1 - t2"],
        "full_invariant_certified": False,
        "input_certification_evidence": {
            "bounded_scanned_gcd_certified": True,
            "complete_scanned_gcd_certified": True,
            "quotient_gcd_certified": True,
            "quotient_gcd_polynomial": "1",
            "quotient_gcd_method": "fox_square_minor_quotient_unit_gcd",
            "bounded_alexander_maturity_path": "exact_scanned_gcd",
            "bounded_alexander_maturity_path_certified": True,
            "checked_nonzero_minor_count": 4,
            "failed_nonzero_minor_count": 0,
            "expected_combination_count": 4,
            "nonzero_minor_count": 4,
            "zero_minor_count": 0,
            "unit_minor_count": 2,
            "unique_nonzero_polynomial_count": 2,
            "all_rows_have_nonzero_minor": True,
            "all_columns_have_nonzero_minor": True,
            "complete_combination_scan": True,
            "nonzero_minor_coverage_complete": True,
            "truncated": False,
        },
        "skipped": False,
        "notes": ["bounded Alexander row"],
    }

    homfly_status = invariant_status_from_pd_report(homfly_report)
    assert homfly_status["name"] == "HOMFLY-PT"
    assert homfly_status["value"] == "P"
    assert homfly_status["skipped"] is False
    assert homfly_status["passed_check_count"] == 1
    assert "certified_for_input=True" in homfly_status["notes"]
    assert "frontier=2; truncated=True" in homfly_status["notes"]
    assert "frontier_exhausted=False" in homfly_status["notes"]
    assert (
        "run_caps=max_crossings=8; initial_depth=0; max_depth=4; max_nodes=128"
        in homfly_status["notes"]
    )
    assert "terminal_contribution_skipped=False" in homfly_status["notes"]
    assert "terminal_contribution_matched=True" in homfly_status["notes"]
    assert "frontier_reasons=max_depth, max_nodes" in homfly_status["notes"]
    assert "source_candidate_replay=claim_scope=source_gauss_matched_signed_pd_candidate_replay" in homfly_status["notes"]
    assert "source_notation=L6a4" in homfly_status["notes"]
    assert "pairwise_linking=0.0,0.0,0.0" in homfly_status["notes"]
    assert "sign_count=6" in homfly_status["notes"]
    assert homfly_status["source_candidate_replay_present"] is True
    assert homfly_status["source_candidate_replay_claim_scope"] == (
        "source_gauss_matched_signed_pd_candidate_replay"
    )
    assert homfly_status["source_candidate_replay_source_notation"] == "L6a4"
    assert homfly_status["source_candidate_replay_pairwise_linking"] == (
        "0.0,0.0,0.0"
    )
    assert homfly_status["source_candidate_replay_sign_count"] == 6
    assert homfly_status["source_candidate_replay_role_order_count"] == 6
    assert "signed_pd_role_order_provenance=role_orders=2; explicit=1" in (
        homfly_status["notes"]
    )
    assert homfly_status["signed_pd_role_order_metadata_present"] is True
    assert homfly_status["signed_pd_role_order_count"] == 2
    assert homfly_status["signed_pd_role_order_explicit_count"] == 1
    assert homfly_status["signed_pd_auto_role_order_present"] is True
    assert homfly_status["signed_pd_auto_role_order_requested"] is True
    assert homfly_status["signed_pd_auto_role_order_applied"] is False
    assert homfly_status["signed_pd_auto_role_order_status"] == "not_needed"
    assert homfly_status["signed_pd_auto_role_order_candidate_count"] == 0
    assert homfly_status["signed_pd_auto_role_order_strict_candidate_count"] == 0
    assert "signed_pd_auto_role_order=status=not_needed; applied=False" in (
        homfly_status["notes"]
    )

    zero_alexander_status = invariant_status_from_pd_report(
        {
            "method": "multivariable_alexander_pd_report",
            "multivariable_alexander_polynomial": "1",
            "candidate_polynomials": [],
            "zero_crossing_unlink_certified": True,
            "full_invariant_certified": False,
            "skipped": False,
            "notes": ["zero-crossing terminal row"],
        }
    )
    assert zero_alexander_status["value"] == "1"
    assert "zero_crossing_unlink_certified=True" in zero_alexander_status["notes"]

    payload = imgui_invariant_status_payload_from_reports(
        [homfly_report, alexander_report]
    )
    assert payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert payload["invariant_status_count"] == 2
    statuses = {status["name"]: status for status in payload["invariant_statuses"]}
    assert statuses["HOMFLY-PT"]["value"] == "P"
    assert (
        statuses["HOMFLY-PT"][
            "bounded_homfly_maturity_path_not_certified_count"
        ]
        == 1
    )
    assert "bounded_homfly_maturity_path=not_certified" in statuses[
        "HOMFLY-PT"
    ]["notes"]
    assert statuses["multi-variable Alexander"]["value"] == "1"
    assert (
        statuses["multi-variable Alexander"][
            "bounded_alexander_maturity_path_exact_scanned_gcd_count"
        ]
        == 1
    )
    assert "bounded_alexander_maturity_path=exact_scanned_gcd" in statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert "bounded_scanned_gcd_certified=True" in statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert "complete_scanned_gcd_certified=True" in statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert "quotient_gcd=1 via fox_square_minor_quotient_unit_gcd" in statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert "source_candidate_replay=claim_scope=source_gauss_matched_signed_pd_candidate_replay" in statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert "source_url=https://katlas.org/wiki/L6a4" in statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert statuses["multi-variable Alexander"]["source_candidate_replay_present"] is True
    assert statuses["multi-variable Alexander"][
        "source_candidate_replay_source_url"
    ] == "https://katlas.org/wiki/L6a4"
    assert "signed_pd_role_order_provenance=role_orders=2; explicit=1" in (
        statuses["multi-variable Alexander"]["notes"]
    )
    assert statuses["multi-variable Alexander"][
        "signed_pd_role_order_metadata_present"
    ] is True
    assert statuses["multi-variable Alexander"]["signed_pd_role_order_count"] == 2
    assert (
        statuses["multi-variable Alexander"]["signed_pd_role_order_explicit_count"]
        == 1
    )
    assert (
        statuses["multi-variable Alexander"]["signed_pd_auto_role_order_present"]
        is True
    )
    assert (
        statuses["multi-variable Alexander"]["signed_pd_auto_role_order_requested"]
        is True
    )
    assert (
        statuses["multi-variable Alexander"]["signed_pd_auto_role_order_applied"]
        is False
    )
    assert (
        statuses["multi-variable Alexander"]["signed_pd_auto_role_order_status"]
        == "not_needed"
    )
    assert "signed_pd_auto_role_order=status=not_needed; applied=False" in statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert (
        "admissible_minor_scan=expected=4; nonzero=4; zero=0; unit=2; "
        "unique_nonzero=2; rows_nonzero=1; columns_nonzero=1; complete=True; "
        "nonzero_coverage_complete=True"
    ) in statuses["multi-variable Alexander"]["notes"]
    alexander_status = statuses["multi-variable Alexander"]
    assert alexander_status["bounded_scanned_gcd_expected_minor_combination_count"] == 4
    assert alexander_status["bounded_scanned_gcd_nonzero_minor_count"] == 4
    assert alexander_status["bounded_scanned_gcd_unit_minor_count"] == 2
    assert alexander_status["bounded_scanned_gcd_unique_nonzero_polynomial_count"] == 2
    assert alexander_status["bounded_scanned_gcd_complete_scan_count"] == 1
    assert (
        alexander_status[
            "bounded_scanned_gcd_nonzero_minor_coverage_complete_count"
        ]
        == 1
    )
    assert payload["invariant_bounded_scanned_gcd_expected_minor_combination_count"] == 4
    assert payload["invariant_bounded_scanned_gcd_nonzero_minor_count"] == 4
    assert payload["invariant_bounded_scanned_gcd_unit_minor_count"] == 2
    assert payload["invariant_bounded_homfly_maturity_path_not_certified_count"] == 1
    assert (
        payload[
            "invariant_bounded_alexander_maturity_path_exact_scanned_gcd_count"
        ]
        == 1
    )
    assert payload["invariant_source_candidate_replay_count"] == 2
    assert payload["invariant_source_candidate_replay_source_notation_count"] == 1
    assert payload["invariant_source_candidate_replay_source_notations"] == "L6a4"
    assert payload["invariant_source_candidate_replay_claim_scope_count"] == 1
    assert payload["invariant_source_candidate_replay_claim_scopes"] == (
        "source_gauss_matched_signed_pd_candidate_replay"
    )
    assert payload["invariant_source_candidate_replay_sign_count"] == 12
    assert payload["invariant_source_candidate_replay_role_order_count"] == 12
    assert payload["invariant_source_candidate_replay_orientation_issue_count"] == 0
    assert payload["invariant_signed_pd_role_order_metadata_count"] == 2
    assert payload["invariant_signed_pd_role_order_count"] == 4
    assert payload["invariant_signed_pd_role_order_explicit_count"] == 2
    assert payload["invariant_signed_pd_auto_role_order_present_count"] == 2
    assert payload["invariant_signed_pd_auto_role_order_requested_count"] == 2
    assert payload["invariant_signed_pd_auto_role_order_applied_count"] == 0
    assert payload["invariant_signed_pd_auto_role_order_not_needed_count"] == 2
    assert payload["invariant_signed_pd_auto_role_order_unique_applied_count"] == 0
    assert payload["invariant_signed_pd_auto_role_order_ambiguous_count"] == 0
    assert payload["invariant_signed_pd_auto_role_order_no_strict_candidate_count"] == 0
    assert payload["invariant_signed_pd_auto_role_order_candidate_count"] == 0
    assert payload["invariant_signed_pd_auto_role_order_strict_candidate_count"] == 0
    assert payload["invariant_required_check_count"] == 2
    assert payload["invariant_passed_check_count"] == 2
    assert payload["invariant_failed_check_count"] == 0
    json.dumps(payload, allow_nan=False)


def test_imgui_invariant_status_payload_wraps_unique_applied_auto_role_order() -> None:
    report = {
        "method": "homfly_pd_report",
        "input": {
            "signed_pd_revision": 23,
            "auto_role_order": {
                "requested": True,
                "applied": True,
                "status": "unique_applied",
                "candidate_count": 1,
                "strict_candidate_count": 1,
                "unique_strict_global_role_order": [1, 0, 2, 3],
                "candidate_role_orders": [[1, 0, 2, 3]],
                "notes": [
                    "exactly one strict global role_order candidate matched the diagram",
                    "unique strict global role_order selected for this input",
                ],
            },
        },
        "homfly_polynomial": "P",
        "certified_for_input": False,
        "skipped": False,
        "result": {"method": "synthetic_unique_auto_role_order_probe"},
        "notes": ["synthetic unique-applied auto role order report"],
    }

    status = invariant_status_from_pd_report(report)
    payload = imgui_invariant_status_payload_from_reports([report])

    assert status["name"] == "HOMFLY-PT"
    assert status["value"] == "P"
    assert status["skipped"] is False
    assert status["signed_pd_auto_role_order_present"] is True
    assert status["signed_pd_auto_role_order_requested"] is True
    assert status["signed_pd_auto_role_order_applied"] is True
    assert status["signed_pd_auto_role_order_status"] == "unique_applied"
    assert status["signed_pd_auto_role_order_candidate_count"] == 1
    assert status["signed_pd_auto_role_order_strict_candidate_count"] == 1
    assert (
        status["signed_pd_auto_role_order_unique_strict_global_role_order"]
        == "1,0,2,3"
    )
    assert (
        "signed_pd_auto_role_order="
        "status=unique_applied; applied=True; candidates=1; strict=1; "
        "unique_role_order=1,0,2,3"
        in status["notes"]
    )

    assert payload["signed_pd_revision"] == 23
    assert payload["invariant_signed_pd_auto_role_order_present_count"] == 1
    assert payload["invariant_signed_pd_auto_role_order_requested_count"] == 1
    assert payload["invariant_signed_pd_auto_role_order_applied_count"] == 1
    assert payload["invariant_signed_pd_auto_role_order_not_needed_count"] == 0
    assert payload["invariant_signed_pd_auto_role_order_unique_applied_count"] == 1
    assert payload["invariant_signed_pd_auto_role_order_ambiguous_count"] == 0
    assert payload["invariant_signed_pd_auto_role_order_no_strict_candidate_count"] == 0
    assert payload["invariant_signed_pd_auto_role_order_candidate_count"] == 1
    assert payload["invariant_signed_pd_auto_role_order_strict_candidate_count"] == 1
    json.dumps(payload, allow_nan=False)

def test_imgui_invariant_status_payload_wraps_unsupported_result_handle_report() -> None:
    report = {
        "method": "invariant_result_handle_report",
        "backend": "rust",
        "abi_version": 19,
        "result_handle_abi": "opaque_invariant_result_handle_v1",
        "report_transport_abi": "owned_string_v1",
        "handle_kind": "unsupported",
        "invariant": "alexander",
        "status": "unsupported",
        "status_code": "alexander_native_compute_handle_missing",
        "blocking_status_code": "alexander_native_compute_handle_missing",
        "blocking_gate": "alexander_native_compute_handle",
        "gate_status": "missing",
        "native_compute_handle_available": False,
        "native_computation_claimed": False,
        "result_available": False,
        "homfly_report_json": False,
        "alexander_report_json": False,
        "python_file_recompute_boundary": True,
        "current_boundary": "python_file_recompute",
        "host_action": "use_python_file_recompute_boundary",
        "handle_create_symbol": "iroll_invariant_result_handle_create_unsupported",
        "handle_report_symbol": "iroll_invariant_result_handle_report_json",
        "handle_free_symbol": "iroll_invariant_result_handle_free",
        "owned_string_free_symbol": "iroll_kernel_owned_string_free",
        "claim_scope": "unsupported_lifecycle_probe_only",
        "complete_result_handle_abi": False,
        "release_grade_result_handles": False,
    }

    payload = imgui_invariant_status_payload_from_reports([report])

    assert payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert payload["invariant_status_count"] == 1
    assert payload["invariant_required_check_count"] == 0
    assert payload["invariant_passed_check_count"] == 0
    assert payload["invariant_failed_check_count"] == 0
    status = payload["invariant_statuses"][0]
    assert status["name"] == "multi-variable Alexander native result handle"
    assert status["value"] == "skipped"
    assert status["skipped"] is True
    assert status["required_check_count"] == 0
    assert status["passed_check_count"] == 0
    assert status["failed_check_count"] == 0
    for note in (
        "status_code=alexander_native_compute_handle_missing",
        "blocking_gate=alexander_native_compute_handle",
        "gate_status=missing",
        "native_compute_handle_available=false",
        "native_computation_claimed=false",
        "result_available=false",
        "homfly_report_json=false",
        "alexander_report_json=false",
        "python_file_recompute_boundary=true",
        "current_boundary=python_file_recompute",
        "host_action=use_python_file_recompute_boundary",
        "claim_scope=unsupported_lifecycle_probe_only",
        "complete_result_handle_abi=false",
        "release_grade_result_handles=false",
        "handle_create_symbol=iroll_invariant_result_handle_create_unsupported",
        "handle_report_symbol=iroll_invariant_result_handle_report_json",
        "handle_free_symbol=iroll_invariant_result_handle_free",
        "owned_string_free_symbol=iroll_kernel_owned_string_free",
    ):
        assert note in status["notes"]
    assert "native_computation_claimed=true" not in status["notes"]
    assert "result_available=true" not in status["notes"]
    json.dumps(payload, allow_nan=False)


def test_imgui_invariant_status_payload_wraps_improved_alexander_result() -> None:
    improved_report = {
        "method": "multivariable_alexander_improve_scanned_gcd_result",
        "source_polynomial": "1 - t1",
        "improved_candidate_polynomial": "1 - t2 - t1 + t1*t2",
        "accepted": True,
        "skipped": False,
        "result": {
            "method": (
                "synthetic_nonmaximal_scanned_gcd_candidate"
                "_improved_by_scanned_quotient_gcd"
            ),
            "multivariable_alexander_polynomial": "1 - t2 - t1 + t1*t2",
        },
        "improved_audit": {
            "candidate_is_exact_scanned_gcd": True,
            "complete_scanned_gcd_certified": True,
            "quotient_gcd_certified": True,
            "quotient_gcd_polynomial": "1",
            "quotient_gcd_method": "fox_square_minor_quotient_unit_gcd",
            "checked_nonzero_minor_count": 2,
            "failed_nonzero_minor_count": 0,
            "expected_combination_count": 2,
            "nonzero_minor_count": 2,
            "zero_minor_count": 0,
            "unit_minor_count": 1,
            "unique_nonzero_polynomial_count": 1,
            "all_rows_have_nonzero_minor": True,
            "all_columns_have_nonzero_minor": True,
            "complete_combination_scan": True,
            "nonzero_minor_coverage_complete": True,
        },
        "notes": ["improved result is bounded scanned-minor evidence"],
    }

    payload = imgui_invariant_status_payload_from_reports([improved_report])

    assert payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert payload["invariant_status_count"] == 1
    assert payload["invariant_required_check_count"] == 1
    assert payload["invariant_passed_check_count"] == 1
    assert payload["invariant_failed_check_count"] == 0
    status = payload["invariant_statuses"][0]
    assert status["name"] == "multi-variable Alexander improved scanned gcd"
    assert status["value"] == "1 - t2 - t1 + t1*t2"
    assert status["skipped"] is False
    assert "source_polynomial=1 - t1" in status["notes"]
    assert "improved_candidate=1 - t2 - t1 + t1*t2" in status["notes"]
    assert "exact_scanned_gcd=True" in status["notes"]
    assert "complete_scanned_gcd_certified=True" in status["notes"]
    assert "quotient_gcd=1 via fox_square_minor_quotient_unit_gcd" in status[
        "notes"
    ]
    assert (
        "admissible_minor_scan=expected=2; nonzero=2; zero=0; unit=1; "
        "unique_nonzero=1; rows_nonzero=1; columns_nonzero=1; complete=True; "
        "nonzero_coverage_complete=True"
    ) in status["notes"]
    assert status["bounded_scanned_gcd_expected_minor_combination_count"] == 2
    assert status["bounded_scanned_gcd_nonzero_minor_count"] == 2
    assert status["bounded_scanned_gcd_unit_minor_count"] == 1
    assert status["bounded_scanned_gcd_unique_nonzero_polynomial_count"] == 1
    assert status["bounded_scanned_gcd_complete_scan_count"] == 1
    assert (
        payload["invariant_bounded_scanned_gcd_expected_minor_combination_count"]
        == 2
    )

    direct_status = invariant_status_from_alexander_improved_result(
        improved_report,
        name="promoted Alexander",
    )
    assert direct_status["name"] == "promoted Alexander"
    assert direct_status["value"] == status["value"]
    assert "improved_candidate=1 - t2 - t1 + t1*t2" in direct_status["notes"]
    json.dumps(payload, allow_nan=False)


def test_imgui_invariant_status_payload_exposes_alexander_common_gcd_attempt() -> None:
    report = {
        "method": "multivariable_alexander_pd_report",
        "multivariable_alexander_polynomial": None,
        "candidate_polynomials": ["1 + t2 + t1", "1 + 2t2 + t1"],
        "skipped": True,
        "full_invariant_certified": False,
        "result": {
            "method": "skipped",
            "common_gcd_attempt_evidence": {
                "method": "fox_square_minor_common_gcd_attempt_evidence",
                "status": "not_certified",
                "input_polynomial_count": 2,
                "unique_input_polynomial_count": 2,
                "input_term_count_min": 3,
                "input_term_count_max": 5,
                "input_term_count_signature": [
                    {"term_count": 3, "input_count": 1},
                    {"term_count": 5, "input_count": 1},
                ],
                "common_integer_content": 1,
                "candidate_methods_attempted": [
                    "integer_content",
                    "bounded_multivariate_sparse_factor",
                    "bounded_multivariate_cofactor_factor",
                ],
                "bounded_search_limits": {
                    "max_candidate_terms": 14,
                    "sparse_factor_max_candidates": 2048,
                },
                "attempt_diagnostics": {
                    "support_signature_variant_count": 1,
                    "direct_scanned_minor_divisor_summary": {
                        "candidate_count": 2,
                        "divides_all_candidate_count": 0,
                        "failed_candidate_count": 2,
                        "candidate_term_count_min": 3,
                        "candidate_term_count_max": 5,
                        "failed_input_count_min": 1,
                        "failed_input_count_max": 2,
                        "all_candidates_failed": True,
                        "first_failure": {
                            "candidate_term_count": 3,
                            "failed_input_term_count": 5,
                        },
                    },
                    "full_admissible_minor_normalization_certified": False,
                    "full_invariant_certified": False,
                },
                "full_admissible_minor_normalization_certified": False,
                "full_invariant_certified": False,
            },
        },
        "notes": ["synthetic skipped Alexander gcd result"],
    }

    payload = imgui_invariant_status_payload_from_reports([report])

    status = payload["invariant_statuses"][0]
    assert status["name"] == "multi-variable Alexander"
    assert status["value"] == "skipped"
    assert status["skipped"] is True
    assert "common_gcd_attempt=status=not_certified" in status["notes"]
    assert "input_polynomials=2" in status["notes"]
    assert "unique_input_polynomials=2" in status["notes"]
    assert "input_terms=3..5" in status["notes"]
    assert "input_term_signature=3:1,5:1" in status["notes"]
    assert "common_integer_content=1" in status["notes"]
    assert "max_candidate_terms=14" in status["notes"]
    assert "sparse_factor_max_candidates=2048" in status["notes"]
    assert "bounded_multivariate_sparse_factor" in status["notes"]
    assert "support_signature_variants=1" in status["notes"]
    assert "direct_divisor_candidates=2" in status["notes"]
    assert "direct_divisor_divides_all=0" in status["notes"]
    assert "direct_divisor_failed=2" in status["notes"]
    assert "direct_divisor_candidate_terms=3..5" in status["notes"]
    assert "direct_divisor_failed_inputs=1..2" in status["notes"]
    assert "direct_divisor_all_failed=True" in status["notes"]
    assert "direct_divisor_first_failure_candidate_terms=3" in status["notes"]
    assert "direct_divisor_first_failure_input_terms=5" in status["notes"]
    assert "quotient_terms=0..0" not in status["notes"]
    assert "candidate_terms=0" not in status["notes"]
    assert "full_admissible_minor_normalization_certified=False" in status["notes"]
    assert "full_invariant_certified=False" in status["notes"]
    assert status["alexander_common_gcd_attempt_evidence_count"] == 1
    assert status["alexander_common_gcd_proof_evidence_count"] == 0
    assert status["alexander_common_gcd_input_polynomial_count"] == 2
    assert status["alexander_common_gcd_unique_input_polynomial_count"] == 2
    assert status["alexander_common_gcd_support_signature_variant_count"] == 1
    assert status["alexander_common_gcd_direct_divisor_candidate_count"] == 2
    assert status["alexander_common_gcd_direct_divisor_failed_candidate_count"] == 2
    assert status["alexander_common_gcd_direct_divisor_all_candidates_failed_count"] == 1
    assert payload["invariant_alexander_common_gcd_attempt_evidence_count"] == 1
    assert payload["invariant_alexander_common_gcd_direct_divisor_candidate_count"] == 2
    assert payload["invariant_failed_check_count"] == 1
    json.dumps(payload, allow_nan=False)


def test_imgui_invariant_status_payload_exposes_direct_alexander_common_gcd_attempt() -> None:
    report = {
        "method": "multivariable_alexander_scanned_gcd_audit",
        "claim_scope": "bounded_scanned_fox_minor_exact_gcd",
        "multivariable_alexander_polynomial": None,
        "candidate_is_exact_scanned_gcd": False,
        "complete_scanned_gcd_certified": False,
        "quotient_gcd_certified": False,
        "checked_nonzero_minor_count": 0,
        "failed_nonzero_minor_count": 0,
        "common_gcd_attempt_evidence": {
            "method": "fox_square_minor_common_gcd_attempt_evidence",
            "status": "not_certified",
            "input_polynomial_count": 2,
            "unique_input_polynomial_count": 2,
            "input_term_count_min": 3,
            "input_term_count_max": 3,
            "input_term_count_signature": [
                {"term_count": 3, "input_count": 2},
            ],
            "common_integer_content": 1,
            "candidate_methods_attempted": [
                "integer_content",
                "bounded_multivariate_sparse_factor",
            ],
            "bounded_search_limits": {
                "max_candidate_terms": 14,
                "sparse_factor_max_candidates": 2048,
            },
            "attempt_diagnostics": {
                "support_signature_variant_count": 2,
                "direct_scanned_minor_divisor_summary": {
                    "candidate_count": 2,
                    "divides_all_candidate_count": 0,
                    "failed_candidate_count": 2,
                    "candidate_term_count_min": 3,
                    "candidate_term_count_max": 3,
                    "failed_input_count_min": 1,
                    "failed_input_count_max": 1,
                    "all_candidates_failed": True,
                    "first_failure": {
                        "candidate_term_count": 3,
                        "failed_input_term_count": 3,
                    },
                },
                "full_admissible_minor_normalization_certified": False,
                "full_invariant_certified": False,
            },
            "full_admissible_minor_normalization_certified": False,
            "full_invariant_certified": False,
        },
        "skipped": True,
        "notes": ["direct skipped scanned-gcd audit"],
    }

    status = imgui_invariant_status_payload_from_reports([report])[
        "invariant_statuses"
    ][0]

    assert status["name"] == "multi-variable Alexander scanned gcd"
    assert status["value"] == "skipped"
    assert status["skipped"] is True
    assert "common_gcd_attempt=status=not_certified" in status["notes"]
    assert "input_terms=3..3" in status["notes"]
    assert "support_signature_variants=2" in status["notes"]
    assert "direct_divisor_failed_inputs=1..1" in status["notes"]
    assert "full_admissible_minor_normalization_certified=False" in status["notes"]
    assert "bounded_multivariate_sparse_factor" in status["notes"]
    assert "claim_scope: bounded_scanned_fox_minor_exact_gcd" in status["notes"]


def test_imgui_invariant_status_payload_exposes_alexander_common_gcd_evidence() -> None:
    report = {
        "method": "multivariable_alexander_pd_report",
        "multivariable_alexander_polynomial": "1 - t1",
        "candidate_polynomials": ["1 - t1"],
        "skipped": False,
        "full_invariant_certified": False,
        "result": {
            "method": "fox_square_minor_multivariate_factor_gcd",
            "common_gcd_evidence": {
                "method": "fox_square_minor_common_gcd_evidence",
                "claim_scope": "bounded_scanned_fox_minor_common_divisor",
                "input_polynomial_count": 3,
                "unique_input_polynomial_count": 3,
                "input_term_count_min": 2,
                "input_term_count_max": 4,
                "input_term_count_signature": [
                    {"term_count": 2, "input_count": 1},
                    {"term_count": 4, "input_count": 2},
                ],
                "candidate_method": "fox_square_minor_multivariate_factor_gcd",
                "candidate_term_count": 2,
                "common_integer_content": 1,
                "divisible_input_count": 3,
                "failed_input_count": 0,
                "quotient_count": 3,
                "unique_quotient_polynomial_count": 3,
                "quotient_term_count_min": 2,
                "quotient_term_count_max": 3,
                "quotient_term_count_signature": [
                    {"term_count": 2, "quotient_count": 2},
                    {"term_count": 3, "quotient_count": 1},
                ],
                "quotient_unit_count": 0,
                "bounded_search_limits": {
                    "max_candidate_terms": 14,
                    "sparse_factor_max_candidates": 2048,
                },
                "full_admissible_minor_normalization_certified": False,
                "full_invariant_certified": False,
            },
        },
        "notes": ["synthetic bounded common-gcd evidence"],
    }

    status = imgui_invariant_status_payload_from_reports([report])[
        "invariant_statuses"
    ][0]

    assert status["name"] == "multi-variable Alexander"
    assert status["value"] == "1 - t1"
    assert status["skipped"] is False
    assert (
        "common_gcd_evidence=claim_scope=bounded_scanned_fox_minor_common_divisor"
        in status["notes"]
    )
    assert "input_terms=2..4" in status["notes"]
    assert "input_term_signature=2:1,4:2" in status["notes"]
    assert "candidate_terms=2" in status["notes"]
    assert "divisible_inputs=3" in status["notes"]
    assert "failed_inputs=0" in status["notes"]
    assert "quotients=3" in status["notes"]
    assert "unique_quotients=3" in status["notes"]
    assert "quotient_terms=2..3" in status["notes"]
    assert "quotient_term_signature=2:2,3:1" in status["notes"]
    assert "quotient_units=0" in status["notes"]
    assert "full_admissible_minor_normalization_certified=False" in status["notes"]
    assert "full_invariant_certified=False" in status["notes"]
    assert status["alexander_common_gcd_attempt_evidence_count"] == 0
    assert status["alexander_common_gcd_proof_evidence_count"] == 1
    assert status["alexander_common_gcd_input_polynomial_count"] == 3
    assert status["alexander_common_gcd_unique_input_polynomial_count"] == 3
    assert status["alexander_common_gcd_candidate_term_count"] == 2
    assert status["alexander_common_gcd_divisible_input_count"] == 3
    assert status["alexander_common_gcd_failed_input_count"] == 0
    assert status["alexander_common_gcd_quotient_count"] == 3
    assert status["alexander_common_gcd_unique_quotient_count"] == 3
    assert status["alexander_common_gcd_quotient_unit_count"] == 0
    payload = imgui_invariant_status_payload_from_reports([report])
    assert payload["invariant_alexander_common_gcd_proof_evidence_count"] == 1
    assert payload["invariant_alexander_common_gcd_quotient_count"] == 3
    json.dumps(payload, allow_nan=False)


def test_imgui_invariant_status_payload_exposes_optional_symbolic_gcd_limits() -> None:
    report = {
        "method": "multivariable_alexander_pd_report",
        "multivariable_alexander_polynomial": "1 + 2t1 + 3t2",
        "candidate_polynomials": ["1 + 2t1 + 3t2"],
        "skipped": False,
        "full_invariant_certified": False,
        "result": {
            "method": "fox_square_minor_optional_symbolic_multivariate_gcd",
            "common_gcd_evidence": {
                "method": "fox_square_minor_common_gcd_evidence",
                "claim_scope": "bounded_scanned_fox_minor_common_divisor",
                "input_polynomial_count": 2,
                "unique_input_polynomial_count": 2,
                "candidate_method": (
                    "fox_square_minor_optional_symbolic_multivariate_gcd"
                ),
                "candidate_term_count": 15,
                "common_integer_content": 1,
                "divisible_input_count": 2,
                "failed_input_count": 0,
                "quotient_count": 2,
                "unique_quotient_polynomial_count": 2,
                "quotient_unit_count": 1,
                "bounded_search_limits": {
                    "max_candidate_terms": 14,
                    "sparse_factor_max_candidates": 2048,
                    "root_binomial_max_candidates": 512,
                    "cofactor_max_candidates": 512,
                    "optional_symbolic_gcd_max_variables": 4,
                    "optional_symbolic_gcd_max_polynomials": 8,
                    "optional_symbolic_gcd_max_total_terms": 128,
                },
                "full_admissible_minor_normalization_certified": False,
                "full_invariant_certified": False,
            },
        },
        "notes": ["synthetic optional symbolic bounded common-gcd evidence"],
    }

    payload = imgui_invariant_status_payload_from_reports([report])
    status = payload["invariant_statuses"][0]

    assert status["name"] == "multi-variable Alexander"
    assert status["value"] == "1 + 2t1 + 3t2"
    assert "fox_square_minor_optional_symbolic_multivariate_gcd" in status["notes"]
    assert "optional_symbolic_gcd_max_variables=4" in status["notes"]
    assert "optional_symbolic_gcd_max_polynomials=8" in status["notes"]
    assert "optional_symbolic_gcd_max_total_terms=128" in status["notes"]
    assert "root_binomial_max_candidates=512" in status["notes"]
    assert "cofactor_max_candidates=512" in status["notes"]
    assert status["alexander_common_gcd_proof_evidence_count"] == 1
    assert status["alexander_common_gcd_candidate_term_count"] == 15
    assert status["alexander_common_gcd_quotient_unit_count"] == 1
    assert payload["invariant_alexander_common_gcd_proof_evidence_count"] == 1
    assert payload["invariant_alexander_common_gcd_candidate_term_count"] == 15
    json.dumps(payload, allow_nan=False)


def test_imgui_payloads_wrap_alexander_admissible_minor_normalization_audit() -> None:
    report = {
        "method": "multivariable_alexander_admissible_minor_normalization_audit",
        "claim_scope": (
            "bounded_scanned_fox_admissible_minor_laurent_unit_normalization"
        ),
        "multivariable_alexander_polynomial": "1 - t1",
        "normalized_representative_polynomial": "1 - t1",
        "all_nonzero_minors_laurent_unit_equivalent": True,
        "bounded_admissible_minor_normalization_certified": True,
        "checked_nonzero_minor_count": 2,
        "failed_nonzero_minor_count": 0,
        "normalization_class_count": 1,
        "largest_normalization_class_minor_count": 2,
        "representative_normalization_class_minor_count": 2,
        "nonrepresentative_normalization_class_count": 0,
        "normalization_representative_witness": {
            "minor_index": 0,
            "rows": [0],
            "columns": [0],
            "raw_polynomial": "1 - t1",
            "minor_polynomial": "1 - t1",
            "normalized_polynomial": "1 - t1",
        },
        "normalization_mismatch_witness_count": 0,
        "normalization_mismatch_witness_limit": 8,
        "normalization_mismatch_witness_truncated": False,
        "normalization_mismatch_witnesses": [],
        "admissible_minor_normalization_blockers": [],
        "admissible_minor_normalization_blocker_count": 0,
        "admissible_minor_normalization_blocker_details": {},
        "full_alexander_completion_blockers": [
            "full_admissible_minor_normalization_not_certified",
            "full_varied_polynomial_gcd_not_certified",
            "full_invariant_not_certified",
        ],
        "full_alexander_completion_blocker_count": 3,
        "full_alexander_completion_blocker_details": {
            "full_admissible_minor_normalization_not_certified": {
                "full_admissible_minor_normalization_certified": False,
                "claim_scope": (
                    "bounded_scanned_fox_admissible_minor_laurent_unit_normalization"
                ),
            },
        },
        "expected_combination_count": 2,
        "scanned_minor_count": 2,
        "nonzero_minor_count": 2,
        "zero_minor_count": 0,
        "unique_nonzero_polynomial_count": 1,
        "complete_combination_scan": True,
        "nonzero_minor_coverage_complete": True,
        "truncated": False,
        "normalization_class_counts": [
            {"normalized_polynomial": "1 - t1", "minor_count": 2},
        ],
        "skipped": False,
        "admissible_minor_summary": {
            "expected_combination_count": 2,
            "nonzero_minor_count": 2,
            "zero_minor_count": 0,
            "unit_minor_count": 0,
            "unique_nonzero_polynomial_count": 1,
            "all_rows_have_nonzero_minor": True,
            "all_columns_have_nonzero_minor": True,
            "complete_combination_scan": True,
            "nonzero_minor_coverage_complete": True,
        },
        "notes": ["bounded scanned admissible-minor normalization evidence"],
    }

    summary = analysis_summary_from_acceptance_report(report)

    assert summary["name"] == (
        "multi-variable Alexander admissible-minor normalization"
    )
    assert summary["accepted"] is True
    assert summary["required_check_count"] == 3
    assert summary["passed_check_count"] == 3
    assert summary["certification_certified_count"] == 1
    assert summary["bounded_scanned_gcd_checked_nonzero_minor_count"] == 2
    assert summary["bounded_scanned_gcd_failed_nonzero_minor_count"] == 0
    assert summary["bounded_scanned_gcd_expected_minor_combination_count"] == 2
    assert summary["bounded_scanned_gcd_scanned_minor_count"] == 2
    assert summary["bounded_scanned_gcd_nonzero_minor_count"] == 2
    assert summary["bounded_scanned_gcd_unique_nonzero_polynomial_count"] == 1
    assert summary["bounded_scanned_gcd_complete_scan_count"] == 1
    assert summary["bounded_scanned_gcd_nonzero_minor_coverage_complete_count"] == 1
    assert summary["bounded_scanned_gcd_complete_certified_count"] == 1
    assert summary["admissible_minor_normalization_checked_nonzero_minor_count"] == 2
    assert summary["admissible_minor_normalization_failed_nonzero_minor_count"] == 0
    assert summary["admissible_minor_normalization_all_equivalent_count"] == 1
    assert summary["admissible_minor_normalization_bounded_certified_count"] == 1
    assert summary["admissible_minor_normalization_complete_scan_count"] == 1
    assert (
        summary[
            "admissible_minor_normalization_nonzero_minor_coverage_complete_count"
        ]
        == 1
    )
    assert summary["admissible_minor_normalization_truncated_count"] == 0
    assert summary["admissible_minor_normalization_class_count"] == 1
    assert summary["admissible_minor_normalization_largest_class_minor_count"] == 2
    assert summary[
        "admissible_minor_normalization_representative_class_minor_count"
    ] == 2
    assert summary[
        "admissible_minor_normalization_nonrepresentative_class_count"
    ] == 0
    assert summary["certification_blocker_count"] == 0
    assert summary["homfly_completion_blocker_count"] == 0
    assert summary["admissible_minor_normalization_blocker_count"] == 0
    assert summary["full_alexander_completion_blocker_count"] == 3
    assert "admissible_minor_normalization=representative=1 - t1" in summary["notes"]
    assert "normalization_classes=1" in summary["notes"]
    assert "largest_class_minors=2" in summary["notes"]
    assert "mismatch_witnesses=0/8" in summary["notes"]
    assert "mismatch_witness_truncated=False" in summary["notes"]
    assert "representative_minor=0" in summary["notes"]
    assert "admissible_minor_normalization_blocker_count=0" in summary["notes"]
    assert "full_alexander_completion_blocker_count=3" in summary["notes"]
    assert (
        "first_full_alexander_completion_blocker="
        "full_admissible_minor_normalization_not_certified"
        in summary["notes"]
    )
    assert "full_admissible_minor_normalization_certified=False" in summary["notes"]

    analysis_payload = imgui_analysis_payload_from_acceptance_reports([report])
    assert analysis_payload["analysis_summary_count"] == 1
    assert analysis_payload["analysis_bounded_scanned_gcd_complete_certified_count"] == 1
    assert analysis_payload["analysis_bounded_scanned_gcd_scanned_minor_count"] == 2
    assert (
        analysis_payload[
            "analysis_admissible_minor_normalization_checked_nonzero_minor_count"
        ]
        == 2
    )
    assert (
        analysis_payload[
            "analysis_admissible_minor_normalization_bounded_certified_count"
        ]
        == 1
    )
    assert analysis_payload["analysis_admissible_minor_normalization_class_count"] == 1
    assert (
        analysis_payload[
            "analysis_admissible_minor_normalization_largest_class_minor_count"
        ]
        == 2
    )
    assert (
        analysis_payload[
            "analysis_admissible_minor_normalization_representative_class_minor_count"
        ]
        == 2
    )
    assert (
        analysis_payload[
            "analysis_admissible_minor_normalization_nonrepresentative_class_count"
        ]
        == 0
    )
    assert analysis_payload["analysis_certification_blocker_count"] == 0
    assert analysis_payload["analysis_homfly_completion_blocker_count"] == 0
    assert (
        analysis_payload["analysis_admissible_minor_normalization_blocker_count"]
        == 0
    )
    assert analysis_payload["analysis_full_alexander_completion_blocker_count"] == 3

    status_payload = imgui_invariant_status_payload_from_reports([report])
    status = status_payload["invariant_statuses"][0]
    assert status["name"] == (
        "multi-variable Alexander admissible-minor normalization"
    )
    assert status["value"] == "1 - t1"
    assert status["passed_check_count"] == 1
    assert "bounded_certified=True" in status["notes"]
    assert "admissible_minor_scan=expected=2" in status["notes"]
    assert status["admissible_minor_normalization_checked_nonzero_minor_count"] == 2
    assert status["admissible_minor_normalization_bounded_certified_count"] == 1
    assert status["admissible_minor_normalization_class_count"] == 1
    assert status["admissible_minor_normalization_largest_class_minor_count"] == 2
    assert status[
        "admissible_minor_normalization_representative_class_minor_count"
    ] == 2
    assert status[
        "admissible_minor_normalization_nonrepresentative_class_count"
    ] == 0
    assert status["certification_blocker_count"] == 0
    assert status["homfly_completion_blocker_count"] == 0
    assert status["admissible_minor_normalization_blocker_count"] == 0
    assert status["full_alexander_completion_blocker_count"] == 3
    assert (
        status_payload[
            "invariant_bounded_scanned_gcd_expected_minor_combination_count"
        ]
        == 2
    )
    assert (
        status_payload[
            "invariant_admissible_minor_normalization_checked_nonzero_minor_count"
        ]
        == 2
    )
    assert (
        status_payload[
            "invariant_admissible_minor_normalization_bounded_certified_count"
        ]
        == 1
    )
    assert (
        status_payload["invariant_admissible_minor_normalization_class_count"] == 1
    )
    assert (
        status_payload[
            "invariant_admissible_minor_normalization_largest_class_minor_count"
        ]
        == 2
    )
    assert (
        status_payload[
            "invariant_admissible_minor_normalization_representative_class_minor_count"
        ]
        == 2
    )
    assert (
        status_payload[
            "invariant_admissible_minor_normalization_nonrepresentative_class_count"
        ]
        == 0
    )
    assert status_payload["invariant_certification_blocker_count"] == 0
    assert status_payload["invariant_homfly_completion_blocker_count"] == 0
    assert (
        status_payload["invariant_admissible_minor_normalization_blocker_count"]
        == 0
    )
    assert status_payload["invariant_full_alexander_completion_blocker_count"] == 3
    json.dumps(analysis_payload, allow_nan=False)
    json.dumps(status_payload, allow_nan=False)

def test_imgui_invariant_status_payload_wraps_alexander_direct_audits() -> None:
    reports = [
        {
            "method": "multivariable_alexander_minor_divisibility_audit",
            "claim_scope": "bounded_scanned_fox_minor_divisibility",
            "multivariable_alexander_polynomial": "1 - t1",
            "all_nonzero_minors_divisible": True,
            "checked_nonzero_minor_count": 2,
            "failed_nonzero_minor_count": 0,
            "complete_combination_scan": True,
            "truncated": False,
            "skipped": False,
        },
        {
            "method": "multivariable_alexander_scanned_gcd_audit",
            "claim_scope": "bounded_scanned_fox_minor_exact_gcd",
            "multivariable_alexander_polynomial": "1",
            "candidate_is_exact_scanned_gcd": True,
            "complete_scanned_gcd_certified": True,
            "quotient_gcd_certified": True,
            "quotient_gcd_polynomial": "1",
            "quotient_gcd_method": "fox_square_minor_quotient_unit_gcd",
            "checked_nonzero_minor_count": 2,
            "failed_nonzero_minor_count": 0,
            "skipped": False,
        },
        {
            "method": "multivariable_alexander_input_certification_evidence",
            "claim_scope": "exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
            "multivariable_alexander_polynomial": "1",
            "bounded_scanned_gcd_certified": True,
            "complete_scanned_gcd_certified": True,
            "quotient_gcd_certified": True,
            "bounded_admissible_minor_normalization_certified": True,
            "all_nonzero_minors_laurent_unit_equivalent": True,
            "bounded_alexander_maturity_path": (
                "laurent_unit_normalization_consensus"
            ),
            "bounded_alexander_maturity_path_certified": True,
            "admissible_minor_normalized_representative_polynomial": "1",
            "admissible_minor_normalization_checked_nonzero_minor_count": 2,
            "admissible_minor_normalization_failed_nonzero_minor_count": 0,
            "failed_nonzero_minor_count": 0,
            "wirtinger_fox_input_chain_consistent": True,
            "certification_blockers": [],
            "certification_blocker_count": 0,
            "admissible_minor_normalization_blockers": [],
            "admissible_minor_normalization_blocker_count": 0,
            "full_alexander_completion_blockers": [
                "full_admissible_minor_normalization_not_certified",
                "full_varied_polynomial_gcd_not_certified",
                "full_invariant_not_certified",
            ],
            "full_alexander_completion_blocker_count": 3,
            "skipped": False,
        },
        {
            "method": "multivariable_alexander_wirtinger_fox_audit",
            "claim_scope": "input_wirtinger_presentation_and_fox_matrix_consistency",
            "presentation_valid": True,
            "fox_jacobian_valid": True,
            "fox_square_minor_scan_valid": True,
            "input_chain_consistent": True,
            "relation_count": 2,
            "generator_count": 2,
            "scanned_minor_count": 2,
            "skipped": False,
        },
    ]

    payload = imgui_invariant_status_payload_from_reports(reports)

    assert payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert payload["invariant_status_count"] == 4
    assert payload["invariant_required_check_count"] == 4
    assert payload["invariant_passed_check_count"] == 4
    statuses = {status["name"]: status for status in payload["invariant_statuses"]}
    assert statuses["multi-variable Alexander minor divisibility"]["value"] == "1 - t1"
    assert "all_nonzero_minors_divisible=True" in statuses[
        "multi-variable Alexander minor divisibility"
    ]["notes"]
    assert statuses["multi-variable Alexander scanned gcd"]["value"] == "1"
    assert "quotient_gcd=1 via fox_square_minor_quotient_unit_gcd" in statuses[
        "multi-variable Alexander scanned gcd"
    ]["notes"]
    assert statuses["multi-variable Alexander input evidence"]["value"] == "1"
    assert "bounded_scanned_gcd_certified=True" in statuses[
        "multi-variable Alexander input evidence"
    ]["notes"]
    assert "admissible_minor_normalization=representative=1" in statuses[
        "multi-variable Alexander input evidence"
    ]["notes"]
    input_status = statuses["multi-variable Alexander input evidence"]
    assert "certification_blocker_count=0" in input_status["notes"]
    assert "admissible_minor_normalization_blocker_count=0" in input_status["notes"]
    assert "full_alexander_completion_blocker_count=3" in input_status["notes"]
    assert (
        "first_full_alexander_completion_blocker="
        "full_admissible_minor_normalization_not_certified"
        in input_status["notes"]
    )
    assert input_status["admissible_minor_normalization_checked_nonzero_minor_count"] == 2
    assert input_status["admissible_minor_normalization_failed_nonzero_minor_count"] == 0
    assert input_status["admissible_minor_normalization_all_equivalent_count"] == 1
    assert input_status["admissible_minor_normalization_bounded_certified_count"] == 1
    assert (
        input_status[
            "bounded_alexander_maturity_path_laurent_unit_normalization_consensus_count"
        ]
        == 1
    )
    assert "bounded_alexander_maturity_path=laurent_unit_normalization_consensus" in (
        input_status["notes"]
    )
    assert input_status["admissible_minor_normalization_complete_scan_count"] == 0
    assert (
        input_status[
            "admissible_minor_normalization_nonzero_minor_coverage_complete_count"
        ]
        == 0
    )
    assert input_status["certification_blocker_count"] == 0
    assert input_status["homfly_completion_blocker_count"] == 0
    assert input_status["admissible_minor_normalization_blocker_count"] == 0
    assert input_status["full_alexander_completion_blocker_count"] == 3
    assert payload["invariant_admissible_minor_normalization_checked_nonzero_minor_count"] == 2
    assert payload["invariant_admissible_minor_normalization_bounded_certified_count"] == 1
    assert (
        payload[
            "invariant_bounded_alexander_maturity_path_laurent_unit_normalization_consensus_count"
        ]
        == 1
    )
    assert payload["invariant_admissible_minor_normalization_complete_scan_count"] == 0
    assert payload["invariant_certification_blocker_count"] == 0
    assert payload["invariant_homfly_completion_blocker_count"] == 0
    assert payload["invariant_admissible_minor_normalization_blocker_count"] == 0
    assert payload["invariant_full_alexander_completion_blocker_count"] == 3
    assert statuses["multi-variable Alexander Wirtinger/Fox"]["value"] == "consistent"
    assert "input_chain_consistent=True" in statuses[
        "multi-variable Alexander Wirtinger/Fox"
    ]["notes"]
    json.dumps(payload, allow_nan=False)


def test_imgui_invariant_status_payload_wraps_homfly_direct_audits() -> None:
    reports = [
        {
            "method": "homfly_input_certification_evidence",
            "claim_scope": "recursive_frontier_exhaustion_for_one_signed_pd_input",
            "homfly_polynomial": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
            "certified_for_input": True,
            "frontier_exhausted": True,
            "terminal_contribution_audit_skipped": False,
            "terminal_contribution_matches_result": True,
            "frontier_count": 0,
            "frontier_reason_count": 0,
            "frontier_reasons": [],
            "max_crossings": 8,
            "initial_depth": 0,
            "max_depth": 12,
            "max_nodes": 2048,
            "truncated": False,
            "certification_blockers": [],
            "certification_blocker_count": 0,
            "homfly_completion_blockers": [
                "full_table_normalization_not_certified",
                "arbitrary_diagram_coverage_not_certified",
            ],
            "homfly_completion_blocker_count": 2,
            "skipped": False,
        },
        {
            "method": "homfly_terminal_reduction_audit",
            "claim_scope": (
                "exact_sum_of_recorded_terminal_and_memoized_reduction_contributions"
            ),
            "homfly_polynomial": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
            "terminal_contribution_sum": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
            "matched_result": True,
            "terminal_reduction_count": 3,
            "reduction_contribution_count": 4,
            "parsed_reduction_contribution_count": 4,
            "unparsed_reduction_contribution_count": 0,
            "reduction_contribution_witness_count": 2,
            "reduction_contribution_witness_limit": 8,
            "reduction_contribution_witnesses_truncated": False,
            "first_reduction_contribution_witness": {
                "index": 0,
                "reduction_kind": "terminal",
                "contribution": "1",
            },
            "reduction_contribution_witnesses": [
                {"index": 0, "reduction_kind": "terminal", "contribution": "1"},
                {"index": 1, "reduction_kind": "memoized_subtree", "contribution": "a"},
            ],
            "reduction_contribution_witness_consistency": {
                "matched": True,
                "mismatch_count": 0,
            },
            "failed_terminal_reduction_count": 0,
            "frontier_count": 0,
            "truncated": False,
            "skipped": False,
        },
        {
            "method": "homfly_skein_identity_audit",
            "claim_scope": "local_homfly_skein_identity_for_signed_pd_input",
            "matched": True,
            "checked_crossing_count": 2,
            "crossing_count": 2,
            "crossing_audits": [],
            "truncated": False,
            "skipped": False,
        },
    ]

    payload = imgui_invariant_status_payload_from_reports(reports)

    assert payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert payload["invariant_status_count"] == 3
    assert payload["invariant_required_check_count"] == 3
    assert payload["invariant_passed_check_count"] == 3
    statuses = {status["name"]: status for status in payload["invariant_statuses"]}
    assert statuses["HOMFLY-PT input evidence"]["value"] == (
        "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z"
    )
    assert "certified_for_input=True" in statuses["HOMFLY-PT input evidence"][
        "notes"
    ]
    assert (
        "run_caps=max_crossings=8; initial_depth=0; max_depth=12; max_nodes=2048"
        in statuses["HOMFLY-PT input evidence"]["notes"]
    )
    assert "terminal_contribution_skipped=False" in statuses[
        "HOMFLY-PT input evidence"
    ]["notes"]
    assert "terminal_contribution_matched=True" in statuses[
        "HOMFLY-PT input evidence"
    ]["notes"]
    assert "certification_blocker_count=0" in statuses[
        "HOMFLY-PT input evidence"
    ]["notes"]
    assert "homfly_completion_blocker_count=2" in statuses[
        "HOMFLY-PT input evidence"
    ]["notes"]
    assert (
        "first_homfly_completion_blocker=full_table_normalization_not_certified"
        in statuses["HOMFLY-PT input evidence"]["notes"]
    )
    input_status = statuses["HOMFLY-PT input evidence"]
    assert input_status["certification_blocker_count"] == 0
    assert input_status["homfly_completion_blocker_count"] == 2
    assert input_status["admissible_minor_normalization_blocker_count"] == 0
    assert input_status["full_alexander_completion_blocker_count"] == 0
    assert payload["invariant_certification_blocker_count"] == 0
    assert payload["invariant_homfly_completion_blocker_count"] == 2
    assert payload["invariant_admissible_minor_normalization_blocker_count"] == 0
    assert payload["invariant_full_alexander_completion_blocker_count"] == 0
    assert statuses["HOMFLY-PT terminal reduction"]["value"] == (
        "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z"
    )
    terminal_status = statuses["HOMFLY-PT terminal reduction"]
    assert (
        "homfly_reduction_contribution_witnesses=witnesses=2/8"
        in terminal_status["notes"]
    )
    assert "first_kind=terminal" in terminal_status["notes"]
    assert terminal_status["homfly_reduction_contribution_count"] == 4
    assert terminal_status["homfly_reduction_contribution_witness_count"] == 2
    assert terminal_status["homfly_reduction_contribution_witness_limit"] == 8
    assert (
        terminal_status[
            "homfly_reduction_contribution_witness_truncated_count"
        ]
        == 0
    )
    assert terminal_status["homfly_reduction_contribution_parsed_count"] == 4
    assert terminal_status["homfly_reduction_contribution_unparsed_count"] == 0
    assert (
        terminal_status[
            "homfly_reduction_contribution_consistency_matched_count"
        ]
        == 1
    )
    assert (
        terminal_status[
            "homfly_reduction_contribution_consistency_mismatch_count"
        ]
        == 0
    )
    assert payload["invariant_homfly_reduction_contribution_count"] == 4
    assert payload["invariant_homfly_reduction_contribution_witness_count"] == 2
    assert payload["invariant_homfly_reduction_contribution_witness_limit"] == 8
    assert (
        payload["invariant_homfly_reduction_contribution_consistency_matched_count"]
        == 1
    )
    assert "terminal_reductions=3" in statuses["HOMFLY-PT terminal reduction"][
        "notes"
    ]
    assert statuses["HOMFLY-PT skein identity"]["value"] == "matched"
    assert "checked_crossings=2" in statuses["HOMFLY-PT skein identity"]["notes"]
    json.dumps(payload, allow_nan=False)


def test_imgui_analysis_summary_wraps_improved_alexander_result() -> None:
    improved_report = {
        "method": "multivariable_alexander_improve_scanned_gcd_result",
        "source_polynomial": "1 - t1",
        "improved_candidate_polynomial": "1 - t2 - t1 + t1*t2",
        "accepted": True,
        "skipped": False,
        "source_audit": {
            "candidate_is_exact_scanned_gcd": False,
            "improved_candidate_polynomial": "1 - t2 - t1 + t1*t2",
        },
        "result": {
            "method": (
                "synthetic_nonmaximal_scanned_gcd_candidate"
                "_improved_by_scanned_quotient_gcd"
            ),
            "multivariable_alexander_polynomial": "1 - t2 - t1 + t1*t2",
        },
        "improved_audit": {
            "candidate_is_exact_scanned_gcd": True,
            "complete_scanned_gcd_certified": True,
            "complete_combination_scan": True,
            "nonzero_minor_coverage_complete": True,
            "truncated": False,
            "quotient_gcd_certified": True,
            "quotient_gcd_polynomial": "1",
            "quotient_gcd_method": "fox_square_minor_quotient_unit_gcd",
            "checked_nonzero_minor_count": 2,
            "failed_nonzero_minor_count": 0,
            "scanned_minor_count": 2,
            "division_record_count": 2,
            "admissible_minor_summary": {
                "expected_combination_count": 2,
                "scanned_minor_count": 2,
                "nonzero_minor_count": 2,
                "zero_minor_count": 0,
                "unit_minor_count": 1,
                "unique_nonzero_polynomial_count": 1,
                "all_rows_have_nonzero_minor": True,
                "all_columns_have_nonzero_minor": True,
                "complete_combination_scan": True,
                "nonzero_minor_coverage_complete": True,
            },
        },
        "notes": ["improved result is bounded scanned-minor evidence"],
    }

    summary = analysis_summary_from_acceptance_report(improved_report)

    assert summary["name"] == "multi-variable Alexander improved scanned gcd"
    assert summary["source_method"] == (
        "multivariable_alexander_improve_scanned_gcd_result"
    )
    assert summary["claim_scope"] == "bounded_scanned_fox_minor_improved_candidate"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 4
    assert summary["passed_check_count"] == 4
    assert summary["failed_check_count"] == 0
    assert summary["certification_scope"] == (
        "bounded_scanned_fox_minor_improved_candidate"
    )
    assert summary["certification_applicable_count"] == 1
    assert summary["certification_certified_count"] == 1
    assert summary["certification_uncertified_count"] == 0
    assert summary["bounded_scanned_gcd_checked_nonzero_minor_count"] == 2
    assert summary["bounded_scanned_gcd_failed_nonzero_minor_count"] == 0
    assert summary["bounded_scanned_gcd_scanned_minor_count"] == 2
    assert summary["bounded_scanned_gcd_division_record_count"] == 2
    assert summary["bounded_scanned_gcd_expected_minor_combination_count"] == 2
    assert summary["bounded_scanned_gcd_nonzero_minor_count"] == 2
    assert summary["bounded_scanned_gcd_zero_minor_count"] == 0
    assert summary["bounded_scanned_gcd_unit_minor_count"] == 1
    assert summary["bounded_scanned_gcd_unique_nonzero_polynomial_count"] == 1
    assert summary["bounded_scanned_gcd_all_rows_have_nonzero_minor_count"] == 1
    assert summary["bounded_scanned_gcd_all_columns_have_nonzero_minor_count"] == 1
    assert summary["bounded_scanned_gcd_complete_scan_count"] == 1
    assert summary["bounded_scanned_gcd_nonzero_minor_coverage_complete_count"] == 1
    assert summary["bounded_scanned_gcd_truncated_count"] == 0
    assert summary["bounded_scanned_gcd_quotient_gcd_certified_count"] == 1
    assert summary["bounded_scanned_gcd_complete_certified_count"] == 1
    assert summary["bounded_scanned_gcd_improved_candidate_count"] == 1
    assert "source_polynomial=1 - t1" in summary["notes"]
    assert "improved_candidate=1 - t2 - t1 + t1*t2" in summary["notes"]
    assert "admissible_minor_scan=expected=2" in summary["notes"]
    assert "full_invariant_certified=False" in summary["notes"]

    payload = imgui_analysis_payload_from_acceptance_reports([improved_report])
    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 4
    assert payload["analysis_passed_check_count"] == 4
    assert payload["analysis_failed_check_count"] == 0
    assert payload["analysis_certification_applicable_count"] == 1
    assert payload["analysis_certification_certified_count"] == 1
    assert payload["analysis_certification_uncertified_count"] == 0
    assert payload["analysis_bounded_scanned_gcd_checked_nonzero_minor_count"] == 2
    assert (
        payload["analysis_bounded_scanned_gcd_expected_minor_combination_count"]
        == 2
    )
    assert payload["analysis_bounded_scanned_gcd_complete_certified_count"] == 1
    assert payload["analysis_bounded_scanned_gcd_improved_candidate_count"] == 1
    json.dumps(payload, allow_nan=False)

def test_imgui_analysis_summary_wraps_alexander_audit_reports() -> None:
    scanned_gcd_audit = {
        "method": "multivariable_alexander_scanned_gcd_audit",
        "claim_scope": "bounded_scanned_fox_minor_exact_gcd",
        "source_method": "synthetic_nonmaximal_scanned_gcd_candidate",
        "candidate_is_exact_scanned_gcd": False,
        "complete_scanned_gcd_certified": False,
        "complete_combination_scan": True,
        "nonzero_minor_coverage_complete": True,
        "truncated": False,
        "quotient_gcd_certified": True,
        "quotient_gcd_polynomial": "1 - t2",
        "quotient_gcd_method": "fox_square_minor_quotient_common_factor",
        "improved_candidate_polynomial": "1 - t2 - t1 + t1*t2",
        "checked_nonzero_minor_count": 2,
        "failed_nonzero_minor_count": 0,
        "scanned_minor_count": 2,
        "division_record_count": 2,
        "admissible_minor_summary": {
            "expected_combination_count": 2,
            "scanned_minor_count": 2,
            "nonzero_minor_count": 2,
            "zero_minor_count": 0,
            "unit_minor_count": 0,
            "unique_nonzero_polynomial_count": 2,
            "all_rows_have_nonzero_minor": True,
            "all_columns_have_nonzero_minor": True,
            "complete_combination_scan": True,
            "nonzero_minor_coverage_complete": True,
        },
        "skipped": False,
        "notes": ["candidate divides scanned minors but is not exact"],
    }
    wirtinger_fox_audit = {
        "method": "multivariable_alexander_wirtinger_fox_audit",
        "claim_scope": "input_wirtinger_presentation_and_fox_matrix_consistency",
        "source_method": "multivariable_alexander_from_pd",
        "presentation_valid": True,
        "wirtinger_relation_shape_valid": True,
        "wirtinger_relation_shape_invalid_count": 0,
        "wirtinger_relation_shape_witnesses": [],
        "wirtinger_generator_component_coverage_complete": True,
        "wirtinger_generator_component_counts": [
            {"component": 0, "generator_count": 1},
            {"component": 1, "generator_count": 1},
        ],
        "fox_jacobian_valid": True,
        "fox_square_minor_scan_valid": True,
        "input_chain_consistent": True,
        "relation_count": 2,
        "generator_count": 2,
        "scanned_minor_count": 2,
        "invalid_minor_reference_count": 0,
        "invalid_normalization_count": 0,
        "complete_combination_scan": True,
        "truncated": False,
        "skipped": False,
        "notes": ["input chain consistent"],
    }

    scanned_summary = analysis_summary_from_acceptance_report(scanned_gcd_audit)
    wirtinger_summary = analysis_summary_from_acceptance_report(wirtinger_fox_audit)

    assert scanned_summary["name"] == "multi-variable Alexander scanned gcd audit"
    assert scanned_summary["accepted"] is False
    assert scanned_summary["required_check_count"] == 3
    assert scanned_summary["passed_check_count"] == 2
    assert scanned_summary["failed_check_count"] == 1
    assert scanned_summary["certification_applicable_count"] == 1
    assert scanned_summary["certification_certified_count"] == 0
    assert scanned_summary["certification_uncertified_count"] == 1
    assert scanned_summary["bounded_scanned_gcd_checked_nonzero_minor_count"] == 2
    assert scanned_summary["bounded_scanned_gcd_expected_minor_combination_count"] == 2
    assert scanned_summary["bounded_scanned_gcd_nonzero_minor_count"] == 2
    assert scanned_summary["bounded_scanned_gcd_unique_nonzero_polynomial_count"] == 2
    assert scanned_summary["bounded_scanned_gcd_all_rows_have_nonzero_minor_count"] == 1
    assert scanned_summary["bounded_scanned_gcd_complete_scan_count"] == 1
    assert scanned_summary["bounded_scanned_gcd_quotient_gcd_certified_count"] == 1
    assert scanned_summary["bounded_scanned_gcd_improved_candidate_count"] == 1
    assert "improved_candidate=1 - t2 - t1 + t1*t2" in scanned_summary["notes"]

    assert wirtinger_summary["name"] == "multi-variable Alexander Wirtinger/Fox audit"
    assert wirtinger_summary["accepted"] is True
    assert wirtinger_summary["required_check_count"] == 3
    assert wirtinger_summary["passed_check_count"] == 3
    assert wirtinger_summary["failed_check_count"] == 0
    assert wirtinger_summary["certification_applicable_count"] == 1
    assert wirtinger_summary["certification_certified_count"] == 1
    assert wirtinger_summary["certification_uncertified_count"] == 0
    assert wirtinger_summary["wirtinger_fox_relation_count"] == 2
    assert wirtinger_summary["wirtinger_fox_generator_count"] == 2
    assert wirtinger_summary["wirtinger_fox_scanned_minor_count"] == 2
    assert wirtinger_summary["wirtinger_fox_complete_scan_count"] == 1
    assert wirtinger_summary["wirtinger_fox_relation_shape_invalid_count"] == 0
    assert wirtinger_summary["wirtinger_fox_relation_shape_witness_count"] == 0
    assert (
        wirtinger_summary[
            "wirtinger_fox_relation_shape_count_consistency_matched_count"
        ]
        == 1
    )
    assert (
        wirtinger_summary[
            "wirtinger_fox_generator_component_coverage_complete_count"
        ]
        == 1
    )
    assert wirtinger_summary["wirtinger_fox_generator_component_count_row_count"] == 2
    assert wirtinger_summary["wirtinger_fox_generator_component_count_total"] == 2
    assert (
        wirtinger_summary[
            "wirtinger_fox_generator_component_count_consistency_matched_count"
        ]
        == 1
    )
    assert "input_chain_consistent=True" in wirtinger_summary["notes"]
    assert "wirtinger_relation_shape=valid=True" in wirtinger_summary["notes"]
    assert "wirtinger_generator_components=coverage_complete=True" in (
        wirtinger_summary["notes"]
    )

    payload = imgui_analysis_payload_from_acceptance_reports(
        [scanned_gcd_audit, wirtinger_fox_audit]
    )
    assert payload["analysis_summary_count"] == 2
    assert payload["analysis_accepted_summary_count"] == 1
    assert payload["analysis_rejected_summary_count"] == 1
    assert payload["analysis_certified_summary_count"] == 0
    assert payload["analysis_uncertified_summary_count"] == 1
    assert payload["analysis_failed_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 6
    assert payload["analysis_passed_check_count"] == 5
    assert payload["analysis_failed_check_count"] == 1
    assert payload["analysis_certification_applicable_count"] == 2
    assert payload["analysis_certification_certified_count"] == 1
    assert payload["analysis_certification_uncertified_count"] == 1
    assert payload["analysis_bounded_scanned_gcd_improved_candidate_count"] == 1
    assert (
        payload["analysis_bounded_scanned_gcd_expected_minor_combination_count"]
        == 2
    )
    assert payload["analysis_wirtinger_fox_scanned_minor_count"] == 2
    assert payload["analysis_wirtinger_fox_relation_shape_witness_count"] == 0
    assert (
        payload[
            "analysis_wirtinger_fox_generator_component_coverage_complete_count"
        ]
        == 1
    )
    json.dumps(payload, allow_nan=False)

def test_imgui_analysis_summary_wraps_alexander_wirtinger_fox_invalid_witnesses() -> None:
    audit = {
        "method": "multivariable_alexander_wirtinger_fox_audit",
        "claim_scope": "input_wirtinger_presentation_and_fox_matrix_consistency",
        "source_method": "multivariable_alexander_from_pd",
        "presentation_valid": True,
        "fox_jacobian_valid": True,
        "fox_square_minor_scan_valid": False,
        "input_chain_consistent": False,
        "relation_count": 2,
        "generator_count": 2,
        "scanned_minor_count": 2,
        "invalid_minor_reference_count": 0,
        "invalid_normalization_count": 1,
        "invalid_minor_reference_witness_count": 0,
        "invalid_minor_reference_witness_limit": 8,
        "invalid_minor_reference_witness_truncated": False,
        "invalid_minor_reference_witnesses": [],
        "invalid_normalization_witness_count": 1,
        "invalid_normalization_witness_limit": 8,
        "invalid_normalization_witness_truncated": False,
        "invalid_normalization_witnesses": [
            {
                "minor_index": 0,
                "validation_kind": "normalization",
                "issue_count": 1,
                "issues": [
                    "unit_sign does not match deterministic normalization",
                ],
            },
        ],
        "complete_combination_scan": True,
        "truncated": False,
        "skipped": False,
        "notes": ["input chain has invalid normalized Fox minor evidence"],
    }

    summary = analysis_summary_from_acceptance_report(audit)

    assert summary["name"] == "multi-variable Alexander Wirtinger/Fox audit"
    assert summary["accepted"] is False
    assert summary["required_check_count"] == 3
    assert summary["passed_check_count"] == 2
    assert summary["failed_check_count"] == 1
    assert (
        "fox_minor_invalid_witnesses=reference=0/8"
        in summary["notes"]
    )
    assert "normalization=1/8" in summary["notes"]
    assert "first_invalid_normalization_minor=0" in summary["notes"]
    assert "first_invalid_normalization_issue_count=1" in summary["notes"]

    payload = imgui_invariant_status_payload_from_reports([audit])
    status = payload["invariant_statuses"][0]

    assert status["name"] == "multi-variable Alexander Wirtinger/Fox"
    assert status["value"] == "inconsistent"
    assert (
        "fox_minor_invalid_witnesses=reference=0/8"
        in status["notes"]
    )
    assert "normalization=1/8" in status["notes"]
    assert "first_invalid_normalization_minor=0" in status["notes"]
    json.dumps(payload, allow_nan=False)


def test_imgui_payloads_preserve_alexander_fox_minor_invalid_witness_truncation() -> None:
    audit = {
        "method": "multivariable_alexander_wirtinger_fox_audit",
        "claim_scope": "input_wirtinger_presentation_and_fox_matrix_consistency",
        "source_method": "multivariable_alexander_from_pd",
        "presentation_valid": True,
        "fox_jacobian_valid": True,
        "fox_square_minor_scan_valid": False,
        "input_chain_consistent": False,
        "relation_count": 2,
        "generator_count": 2,
        "scanned_minor_count": 2,
        "invalid_minor_reference_count": 2,
        "invalid_normalization_count": 1,
        "invalid_minor_reference_witness_count": 2,
        "invalid_minor_reference_witness_limit": 1,
        "invalid_minor_reference_witness_truncated": True,
        "invalid_minor_reference_witnesses": [
            {
                "minor_index": 0,
                "validation_kind": "reference",
                "issue_count": 1,
            },
        ],
        "invalid_normalization_witness_count": 1,
        "invalid_normalization_witness_limit": 1,
        "invalid_normalization_witness_truncated": True,
        "invalid_normalization_witnesses": [
            {
                "minor_index": 1,
                "validation_kind": "normalization",
                "issue_count": 2,
            },
        ],
        "complete_combination_scan": True,
        "truncated": False,
        "skipped": False,
        "notes": [],
    }
    note_token = (
        "fox_minor_invalid_witnesses=reference=2/1; "
        "reference_truncated=True; normalization=1/1; "
        "normalization_truncated=True"
    )

    analysis_payload = imgui_analysis_payload_from_acceptance_reports([audit])
    invariant_payload = imgui_invariant_status_payload_from_reports([audit])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [audit],
        analysis_reports=[audit],
        backend_diagnostics={
            "auto_backend": "numpy",
            "kernel_capabilities": [],
            "backends": {},
            "notes": "",
        },
    )
    notes = (
        analysis_payload["analysis_summaries"][0]["notes"],
        invariant_payload["invariant_statuses"][0]["notes"],
        host_payload["analysis"]["analysis_summaries"][0]["notes"],
        host_payload["invariants"]["invariant_statuses"][0]["notes"],
    )

    for row_notes in notes:
        assert note_token in row_notes
        assert "first_invalid_normalization_minor=1" in row_notes
        assert "first_invalid_normalization_issue_count=2" in row_notes
    json.dumps(host_payload, allow_nan=False)
    json.dumps(analysis_payload, allow_nan=False)
    json.dumps(invariant_payload, allow_nan=False)

def test_imgui_payloads_preserve_wirtinger_relation_shape_consistency_mismatch() -> None:
    audit = {
        "method": "multivariable_alexander_wirtinger_fox_audit",
        "claim_scope": "input_wirtinger_presentation_and_fox_matrix_consistency",
        "presentation_valid": False,
        "wirtinger_relation_shape_valid": False,
        "wirtinger_relation_shape_invalid_count": 2,
        "wirtinger_relation_shape_witness_count": 1,
        "wirtinger_relation_shape_count_consistent": False,
        "wirtinger_relation_shape_witnesses": [
            {
                "relation_index": 0,
                "issue": "unexpected_factor_count",
            }
        ],
        "wirtinger_generator_component_coverage_complete": False,
        "wirtinger_generator_component_counts": [
            {"component": 0, "generator_count": 1},
            {"component": 1, "generator_count": 1},
        ],
        "wirtinger_generator_component_count_total": 2,
        "wirtinger_generator_component_count_consistent": False,
        "fox_jacobian_valid": False,
        "fox_square_minor_scan_valid": False,
        "input_chain_consistent": False,
        "relation_count": 2,
        "generator_count": 3,
        "scanned_minor_count": 0,
        "invalid_minor_reference_count": 0,
        "invalid_normalization_count": 0,
        "complete_combination_scan": False,
        "truncated": False,
        "skipped": False,
        "notes": [],
    }
    relation_note = (
        "wirtinger_relation_shape=valid=False; invalid=2; "
        "witnesses=1; count_consistent=False"
    )
    component_note = (
        "wirtinger_generator_components=coverage_complete=False; "
        "rows=2; total_generators=2; count_consistent=False"
    )

    summary = analysis_summary_from_acceptance_report(audit)
    analysis_payload = imgui_analysis_payload_from_acceptance_reports([audit])
    invariant_payload = imgui_invariant_status_payload_from_reports([audit])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [audit],
        analysis_reports=[audit],
    )
    status = invariant_payload["invariant_statuses"][0]

    assert summary["wirtinger_fox_relation_shape_invalid_count"] == 2
    assert summary["wirtinger_fox_relation_shape_witness_count"] == 1
    assert summary["wirtinger_fox_relation_shape_count_consistency_matched_count"] == 0
    assert summary["wirtinger_fox_generator_component_coverage_complete_count"] == 0
    assert summary["wirtinger_fox_generator_component_count_row_count"] == 2
    assert summary["wirtinger_fox_generator_component_count_total"] == 2
    assert summary["wirtinger_fox_generator_component_count_consistency_matched_count"] == 0
    assert analysis_payload["analysis_wirtinger_fox_relation_shape_invalid_count"] == 2
    assert (
        analysis_payload[
            "analysis_wirtinger_fox_relation_shape_count_consistency_matched_count"
        ]
        == 0
    )
    assert (
        invariant_payload[
            "invariant_wirtinger_fox_generator_component_count_consistency_matched_count"
        ]
        == 0
    )
    assert (
        host_payload["analysis"][
            "analysis_wirtinger_fox_relation_shape_count_consistency_matched_count"
        ]
        == 0
    )
    assert (
        host_payload["invariants"][
            "invariant_wirtinger_fox_generator_component_count_consistency_matched_count"
        ]
        == 0
    )
    for token in (relation_note, component_note):
        assert token in summary["notes"]
        assert token in status["notes"]
        assert token in host_payload["analysis"]["analysis_summaries"][0]["notes"]
    json.dumps(host_payload, allow_nan=False)
    json.dumps(analysis_payload, allow_nan=False)
    json.dumps(invariant_payload, allow_nan=False)

def test_imgui_analysis_summary_wraps_alexander_minor_divisibility_audit() -> None:
    audit = {
        "method": "multivariable_alexander_minor_divisibility_audit",
        "claim_scope": "bounded_scanned_fox_minor_divisibility",
        "source_method": "synthetic_nonmaximal_scanned_gcd_candidate",
        "multivariable_alexander_polynomial": "1 - t1",
        "all_nonzero_minors_divisible": True,
        "checked_nonzero_minor_count": 2,
        "failed_nonzero_minor_count": 0,
        "division_records": [
            {"minor_index": 0, "divisible": True},
            {"minor_index": 1, "divisible": True},
        ],
        "complete_combination_scan": True,
        "truncated": False,
        "admissible_minor_summary": {
            "expected_combination_count": 2,
            "scanned_minor_count": 2,
            "nonzero_minor_count": 2,
            "zero_minor_count": 0,
            "unit_minor_count": 0,
            "unique_nonzero_polynomial_count": 1,
            "all_rows_have_nonzero_minor": True,
            "all_columns_have_nonzero_minor": True,
            "complete_combination_scan": True,
            "nonzero_minor_coverage_complete": True,
        },
        "full_invariant_certified": False,
        "skipped": False,
        "notes": ["bounded divisibility row"],
    }

    summary = analysis_summary_from_acceptance_report(audit)

    assert summary["name"] == "multi-variable Alexander minor divisibility audit"
    assert summary["source_method"] == (
        "multivariable_alexander_minor_divisibility_audit"
    )
    assert summary["claim_scope"] == "bounded_scanned_fox_minor_divisibility"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 3
    assert summary["passed_check_count"] == 3
    assert summary["failed_check_count"] == 0
    assert summary["certification_applicable_count"] == 1
    assert summary["certification_certified_count"] == 1
    assert summary["certification_uncertified_count"] == 0
    assert summary["bounded_scanned_gcd_checked_nonzero_minor_count"] == 2
    assert summary["bounded_scanned_gcd_failed_nonzero_minor_count"] == 0
    assert summary["bounded_scanned_gcd_scanned_minor_count"] == 2
    assert summary["bounded_scanned_gcd_division_record_count"] == 2
    assert summary["bounded_scanned_gcd_expected_minor_combination_count"] == 2
    assert summary["bounded_scanned_gcd_nonzero_minor_count"] == 2
    assert summary["bounded_scanned_gcd_unique_nonzero_polynomial_count"] == 1
    assert summary["bounded_scanned_gcd_complete_scan_count"] == 1
    assert summary["bounded_scanned_gcd_nonzero_minor_coverage_complete_count"] == 1
    assert "all_nonzero_minors_divisible=True" in summary["notes"]
    assert "full_invariant_certified=False" in summary["notes"]

    payload = imgui_analysis_payload_from_acceptance_reports([audit])
    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 3
    assert payload["analysis_passed_check_count"] == 3
    assert payload["analysis_bounded_scanned_gcd_division_record_count"] == 2
    json.dumps(payload, allow_nan=False)

def test_imgui_analysis_summary_wraps_alexander_input_certification_evidence() -> None:
    evidence = {
        "method": "multivariable_alexander_input_certification_evidence",
        "claim_scope": "exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        "source_method": "multivariable_alexander_from_pd",
        "multivariable_alexander_polynomial": "1",
        "variables": ["t1", "t2"],
        "candidate_polynomials": ["1 - t1", "1 - t2"],
        "bounded_scanned_gcd_certified": True,
        "candidate_is_exact_scanned_gcd": True,
        "complete_scanned_gcd_certified": True,
        "quotient_gcd_certified": True,
        "quotient_gcd_polynomial": "1",
        "quotient_gcd_method": "fox_square_minor_quotient_unit_gcd",
        "improved_candidate_polynomial": None,
        "source_common_gcd_evidence": {
            "method": "synthetic_weak_common_gcd",
            "full_admissible_minor_normalization_certified": False,
            "full_invariant_certified": False,
        },
        "scanned_gcd_improvement_evidence": {
            "method": "bounded_scanned_gcd_candidate_promotion",
            "source_polynomial": "1 - t1",
            "improved_candidate_polynomial": "1",
            "quotient_gcd_certified": True,
            "quotient_gcd_polynomial": "1",
            "quotient_gcd_method": "fox_square_minor_quotient_unit_gcd",
            "accepted": True,
            "candidate_is_exact_scanned_gcd_after_promotion": True,
            "full_admissible_minor_normalization_certified": False,
            "full_invariant_certified": False,
        },
        "scanned_gcd_promoted_candidate": True,
        "scanned_gcd_promoted_candidate_count": 1,
        "bounded_admissible_minor_normalization_certified": True,
        "all_nonzero_minors_laurent_unit_equivalent": True,
        "bounded_alexander_maturity_path": "laurent_unit_normalization_consensus",
        "bounded_alexander_maturity_path_certified": True,
        "admissible_minor_normalized_representative_polynomial": "1",
        "admissible_minor_normalization_checked_nonzero_minor_count": 2,
        "admissible_minor_normalization_failed_nonzero_minor_count": 0,
        "admissible_minor_normalization_representative_witness": {
            "minor_index": 0,
            "rows": [0],
            "columns": [0],
            "raw_polynomial": "1",
            "minor_polynomial": "1",
            "normalized_polynomial": "1",
        },
        "admissible_minor_normalization_mismatch_witness_count": 0,
        "admissible_minor_normalization_mismatch_witness_limit": 8,
        "admissible_minor_normalization_mismatch_witness_truncated": False,
        "admissible_minor_normalization_mismatch_witnesses": [],
        "checked_nonzero_minor_count": 2,
        "failed_nonzero_minor_count": 0,
        "failed_minor_count": 0,
        "division_record_count": 2,
        "expected_combination_count": 2,
        "scanned_minor_count": 2,
        "nonzero_minor_count": 2,
        "zero_minor_count": 0,
        "unit_minor_count": 2,
        "unique_nonzero_polynomial_count": 1,
        "all_rows_have_nonzero_minor": True,
        "all_columns_have_nonzero_minor": True,
        "nonzero_minor_coverage_complete": True,
        "wirtinger_fox_input_chain_consistent": True,
        "wirtinger_presentation_valid": True,
        "wirtinger_relation_shape_valid": True,
        "wirtinger_relation_shape_invalid_count": 0,
        "wirtinger_relation_shape_witness_count": 0,
        "wirtinger_relation_shape_count_consistent": True,
        "wirtinger_generator_component_coverage_complete": True,
        "wirtinger_generator_component_count_row_count": 2,
        "wirtinger_generator_component_count_total": 2,
        "wirtinger_generator_component_count_consistent": True,
        "fox_jacobian_valid": True,
        "fox_square_minor_scan_valid": True,
        "wirtinger_relation_count": 2,
        "wirtinger_generator_count": 2,
        "fox_jacobian_row_count": 2,
        "fox_jacobian_column_count": 2,
        "fox_square_minor_invalid_reference_count": 0,
        "fox_square_minor_invalid_normalization_count": 0,
        "complete_combination_scan": True,
        "truncated": False,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "skipped": False,
        "notes": [],
    }

    summary = analysis_summary_from_acceptance_report(evidence)

    assert summary["name"] == (
        "multi-variable Alexander input certification evidence"
    )
    assert summary["source_method"] == (
        "multivariable_alexander_input_certification_evidence"
    )
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 4
    assert summary["passed_check_count"] == 4
    assert summary["failed_check_count"] == 0
    assert summary["certification_applicable_count"] == 1
    assert summary["certification_certified_count"] == 1
    assert summary["certification_uncertified_count"] == 0
    assert summary["bounded_scanned_gcd_checked_nonzero_minor_count"] == 2
    assert summary["bounded_scanned_gcd_failed_nonzero_minor_count"] == 0
    assert summary["bounded_scanned_gcd_scanned_minor_count"] == 2
    assert summary["bounded_scanned_gcd_expected_minor_combination_count"] == 2
    assert summary["bounded_scanned_gcd_nonzero_minor_count"] == 2
    assert summary["bounded_scanned_gcd_zero_minor_count"] == 0
    assert summary["bounded_scanned_gcd_unit_minor_count"] == 2
    assert summary["bounded_scanned_gcd_unique_nonzero_polynomial_count"] == 1
    assert summary["bounded_scanned_gcd_all_rows_have_nonzero_minor_count"] == 1
    assert summary["bounded_scanned_gcd_all_columns_have_nonzero_minor_count"] == 1
    assert summary["bounded_scanned_gcd_complete_certified_count"] == 1
    assert summary["bounded_scanned_gcd_quotient_gcd_certified_count"] == 1
    assert summary["bounded_alexander_maturity_path_certified_count"] == 1
    assert summary["bounded_alexander_maturity_path_distinct_count"] == 1
    assert (
        summary[
            "bounded_alexander_maturity_path_laurent_unit_normalization_consensus_count"
        ]
        == 1
    )
    assert summary["wirtinger_fox_relation_count"] == 2
    assert summary["wirtinger_fox_generator_count"] == 2
    assert summary["wirtinger_fox_scanned_minor_count"] == 2
    assert summary["wirtinger_fox_relation_shape_invalid_count"] == 0
    assert summary["wirtinger_fox_relation_shape_witness_count"] == 0
    assert summary["wirtinger_fox_relation_shape_count_consistency_matched_count"] == 1
    assert summary["wirtinger_fox_generator_component_coverage_complete_count"] == 1
    assert summary["wirtinger_fox_generator_component_count_row_count"] == 2
    assert summary["wirtinger_fox_generator_component_count_total"] == 2
    assert summary["wirtinger_fox_generator_component_count_consistency_matched_count"] == 1
    assert "bounded_scanned_gcd_certified=True" in summary["notes"]
    assert "wirtinger_relation_shape=valid=True" in summary["notes"]
    assert "wirtinger_generator_components=coverage_complete=True" in summary["notes"]
    assert (
        "bounded_alexander_maturity_path=laurent_unit_normalization_consensus"
        in summary["notes"]
    )
    assert "promoted_candidate=1" in summary["notes"]
    assert "admissible_minor_normalization=representative=1" in summary["notes"]
    assert "mismatch_witnesses=0/8" in summary["notes"]
    assert "mismatch_witness_truncated=False" in summary["notes"]
    assert "full_invariant_certified=False" in summary["notes"]

    payload = imgui_analysis_payload_from_acceptance_reports([evidence])
    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 4
    assert payload["analysis_passed_check_count"] == 4
    assert payload["analysis_bounded_scanned_gcd_scanned_minor_count"] == 2
    assert (
        payload["analysis_bounded_scanned_gcd_expected_minor_combination_count"]
        == 2
    )
    assert payload["analysis_bounded_scanned_gcd_unique_nonzero_polynomial_count"] == 1
    assert payload["analysis_bounded_scanned_gcd_improved_candidate_count"] == 1
    assert payload["analysis_bounded_alexander_maturity_path_certified_count"] == 1
    assert (
        payload[
            "analysis_bounded_alexander_maturity_path_laurent_unit_normalization_consensus_count"
        ]
        == 1
    )
    assert payload["analysis_wirtinger_fox_relation_count"] == 2
    json.dumps(payload, allow_nan=False)

def test_imgui_analysis_summary_wraps_homfly_terminal_reduction_audit() -> None:
    audit = {
        "method": "homfly_terminal_reduction_audit",
        "claim_scope": (
            "exact_sum_of_recorded_terminal_and_memoized_reduction_contributions"
        ),
        "evaluation_method": "certified_iterative_recursive_homfly",
        "homfly_polynomial": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
        "terminal_contribution_sum": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
        "terminal_reduction_count": 3,
        "memoized_reduction_count": 1,
        "reduction_contribution_count": 4,
        "parsed_reduction_contribution_count": 4,
        "unparsed_reduction_contribution_count": 0,
        "reduction_contribution_witness_count": 2,
        "reduction_contribution_witness_limit": 8,
        "reduction_contribution_witnesses_truncated": False,
        "first_reduction_contribution_witness": {
            "index": 0,
            "reduction_kind": "terminal",
            "contribution": "1",
        },
        "reduction_contribution_witnesses": [
            {"index": 0, "reduction_kind": "terminal", "contribution": "1"},
            {"index": 1, "reduction_kind": "memoized_subtree", "contribution": "a"},
        ],
        "reduction_contribution_witness_consistency": {
            "matched": True,
            "mismatch_count": 0,
        },
        "failed_terminal_reduction_count": 0,
        "cache_hits": 1,
        "frontier_count": 0,
        "truncated": False,
        "matched_result": True,
        "skipped": False,
        "notes": [],
    }

    summary = analysis_summary_from_acceptance_report(audit)

    assert summary["name"] == "HOMFLY terminal reduction audit"
    assert summary["source_method"] == "homfly_terminal_reduction_audit"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 3
    assert summary["passed_check_count"] == 3
    assert summary["failed_check_count"] == 0
    assert summary["certification_applicable_count"] == 1
    assert summary["certification_certified_count"] == 1
    assert summary["certification_uncertified_count"] == 0
    assert summary["input_certification_terminal_reduction_count"] == 3
    assert (
        summary[
            "input_certification_terminal_contribution_audit_applicable_count"
        ]
        == 1
    )
    assert summary["input_certification_terminal_contribution_matched_count"] == 1
    assert summary["input_certification_terminal_contribution_failed_count"] == 0
    assert summary["homfly_reduction_contribution_count"] == 4
    assert summary["homfly_reduction_contribution_witness_count"] == 2
    assert summary["homfly_reduction_contribution_witness_limit"] == 8
    assert summary["homfly_reduction_contribution_witness_truncated_count"] == 0
    assert summary["homfly_reduction_contribution_parsed_count"] == 4
    assert summary["homfly_reduction_contribution_unparsed_count"] == 0
    assert summary["homfly_reduction_contribution_consistency_matched_count"] == 1
    assert summary["homfly_reduction_contribution_consistency_mismatch_count"] == 0
    assert "terminal_reductions=3" in summary["notes"]
    assert "memoized_reductions=1" in summary["notes"]
    assert (
        "homfly_reduction_contribution_witnesses=witnesses=2/8"
        in summary["notes"]
    )
    assert "truncated=False" in summary["notes"]
    assert "parsed=4" in summary["notes"]
    assert "unparsed=0" in summary["notes"]
    assert "first_kind=terminal" in summary["notes"]
    assert "full_table_normalization_certified=False" in summary["notes"]

    payload = imgui_analysis_payload_from_acceptance_reports([audit])
    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 3
    assert payload["analysis_passed_check_count"] == 3
    assert payload["analysis_failed_check_count"] == 0
    assert (
        payload[
            "analysis_input_certification_terminal_contribution_matched_count"
        ]
        == 1
    )
    assert payload["analysis_input_certification_terminal_reduction_count"] == 3
    assert payload["analysis_homfly_reduction_contribution_count"] == 4
    assert payload["analysis_homfly_reduction_contribution_witness_count"] == 2
    assert payload["analysis_homfly_reduction_contribution_witness_limit"] == 8
    assert (
        payload["analysis_homfly_reduction_contribution_consistency_matched_count"]
        == 1
    )
    json.dumps(payload, allow_nan=False)

def test_imgui_analysis_summary_wraps_homfly_input_certification_evidence() -> None:
    evidence = {
        "method": "homfly_input_certification_evidence",
        "claim_scope": "recursive_frontier_exhaustion_for_one_signed_pd_input",
        "evaluation_method": "certified_iterative_recursive_homfly",
        "homfly_polynomial": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
        "max_crossings": 8,
        "max_depth": 8,
        "max_nodes": 2048,
        "initial_depth": 0,
        "iterative_attempt_count": 3,
        "iterative_solved_depth": 2,
        "iterative_depth_attempts": [],
        "certified_for_input": True,
        "frontier_exhausted": True,
        "zero_crossing_certified": False,
        "full_table_normalization_certified": False,
        "arbitrary_diagram_coverage_certified": False,
        "recursion_nodes": 12,
        "cache_hits": 2,
        "terminal_reduction_count": 3,
        "memoized_reduction_count": 1,
        "reduction_contribution_count": 4,
        "parsed_reduction_contribution_count": 4,
        "unparsed_reduction_contribution_count": 0,
        "reduction_contribution_witness_count": 2,
        "reduction_contribution_witness_limit": 8,
        "reduction_contribution_witnesses_truncated": False,
        "first_reduction_contribution_witness": {
            "index": 0,
            "reduction_kind": "terminal",
            "contribution": "1",
        },
        "reduction_contribution_witnesses": [
            {"index": 0, "reduction_kind": "terminal", "contribution": "1"},
            {"index": 1, "reduction_kind": "memoized_subtree", "contribution": "a"},
        ],
        "reduction_contribution_witness_consistency": {
            "matched": True,
            "mismatch_count": 0,
        },
        "terminal_contribution_sum": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
        "terminal_contribution_matches_result": True,
        "terminal_contribution_audit_skipped": False,
        "bounded_homfly_maturity_path": (
            "recursive_switching_to_descending_frontier_exhausted"
        ),
        "bounded_homfly_maturity_path_certified": True,
        "frontier_count": 0,
        "frontier_reason_count": 0,
        "frontier_reasons": [],
        "truncated": False,
        "certification_blockers": [],
        "certification_blocker_count": 0,
        "homfly_completion_blockers": [
            "full_table_normalization_not_certified",
            "arbitrary_diagram_coverage_not_certified",
        ],
        "homfly_completion_blocker_count": 2,
        "skipped": False,
        "notes": [],
    }

    summary = analysis_summary_from_acceptance_report(evidence)

    assert summary["name"] == "HOMFLY input certification evidence"
    assert summary["source_method"] == "homfly_input_certification_evidence"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 4
    assert summary["passed_check_count"] == 4
    assert summary["failed_check_count"] == 0
    assert summary["certification_applicable_count"] == 1
    assert summary["certification_certified_count"] == 1
    assert summary["certification_uncertified_count"] == 0
    assert summary["input_certification_recursion_node_count"] == 12
    assert summary["input_certification_terminal_reduction_count"] == 3
    assert summary["input_certification_iterative_attempt_count"] == 3
    assert summary["input_certification_iterative_solved_count"] == 1
    assert summary["input_certification_iterative_max_solved_depth"] == 2
    assert (
        summary[
            "input_certification_terminal_contribution_audit_applicable_count"
        ]
        == 1
    )
    assert summary["input_certification_terminal_contribution_matched_count"] == 1
    assert summary["bounded_homfly_maturity_path_certified_count"] == 1
    assert summary["bounded_homfly_maturity_path_distinct_count"] == 1
    assert (
        summary[
            "bounded_homfly_maturity_path_recursive_frontier_exhausted_count"
        ]
        == 1
    )
    assert summary["bounded_homfly_maturity_path_zero_crossing_unlink_count"] == 0
    assert summary["homfly_reduction_contribution_count"] == 4
    assert summary["homfly_reduction_contribution_witness_count"] == 2
    assert summary["homfly_reduction_contribution_witness_limit"] == 8
    assert summary["homfly_reduction_contribution_witness_truncated_count"] == 0
    assert summary["homfly_reduction_contribution_parsed_count"] == 4
    assert summary["homfly_reduction_contribution_unparsed_count"] == 0
    assert summary["homfly_reduction_contribution_consistency_matched_count"] == 1
    assert summary["homfly_reduction_contribution_consistency_mismatch_count"] == 0
    assert summary["certification_blocker_count"] == 0
    assert summary["homfly_completion_blocker_count"] == 2
    assert summary["admissible_minor_normalization_blocker_count"] == 0
    assert summary["full_alexander_completion_blocker_count"] == 0
    assert "frontier_exhausted=True" in summary["notes"]
    assert "terminal_contribution_skipped=False" in summary["notes"]
    assert "terminal_contribution_matched=True" in summary["notes"]
    assert (
        "bounded_homfly_maturity_path="
        "recursive_switching_to_descending_frontier_exhausted"
        in summary["notes"]
    )
    assert "bounded_homfly_maturity_certified=True" in summary["notes"]
    assert (
        "homfly_reduction_contribution_witnesses=witnesses=2/8"
        in summary["notes"]
    )
    assert "first_kind=terminal" in summary["notes"]
    assert "certification_blocker_count=0" in summary["notes"]
    assert "homfly_completion_blocker_count=2" in summary["notes"]
    assert (
        "first_homfly_completion_blocker=full_table_normalization_not_certified"
        in summary["notes"]
    )
    assert "full_table_normalization_certified=False" in summary["notes"]

    payload = imgui_analysis_payload_from_acceptance_reports([evidence])
    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 4
    assert payload["analysis_passed_check_count"] == 4
    assert payload["analysis_input_certification_recursion_node_count"] == 12
    assert payload["analysis_input_certification_iterative_solved_count"] == 1
    assert payload["analysis_bounded_homfly_maturity_path_certified_count"] == 1
    assert (
        payload[
            "analysis_bounded_homfly_maturity_path_recursive_frontier_exhausted_count"
        ]
        == 1
    )
    assert payload["analysis_certification_blocker_count"] == 0
    assert payload["analysis_homfly_completion_blocker_count"] == 2
    assert payload["analysis_admissible_minor_normalization_blocker_count"] == 0
    assert payload["analysis_full_alexander_completion_blocker_count"] == 0
    assert payload["analysis_homfly_reduction_contribution_count"] == 4
    assert payload["analysis_homfly_reduction_contribution_witness_count"] == 2
    assert payload["analysis_homfly_reduction_contribution_witness_limit"] == 8
    assert (
        payload["analysis_homfly_reduction_contribution_consistency_matched_count"]
        == 1
    )
    json.dumps(payload, allow_nan=False)

def test_imgui_analysis_summary_preserves_homfly_reduction_contribution_consistency_mismatch() -> None:
    evidence = {
        "method": "homfly_input_certification_evidence",
        "claim_scope": "recursive_frontier_exhaustion_for_one_signed_pd_input",
        "evaluation_method": "certified_iterative_recursive_homfly",
        "homfly_polynomial": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
        "max_crossings": 8,
        "max_depth": 8,
        "max_nodes": 2048,
        "initial_depth": 0,
        "iterative_attempt_count": 3,
        "iterative_solved_depth": 2,
        "certified_for_input": True,
        "frontier_exhausted": True,
        "zero_crossing_certified": False,
        "full_table_normalization_certified": False,
        "arbitrary_diagram_coverage_certified": False,
        "recursion_nodes": 12,
        "cache_hits": 2,
        "terminal_reduction_count": 3,
        "memoized_reduction_count": 1,
        "reduction_contribution_count": 4,
        "parsed_reduction_contribution_count": 4,
        "unparsed_reduction_contribution_count": 0,
        "reduction_contribution_witness_count": 3,
        "reduction_contribution_witness_limit": 8,
        "reduction_contribution_witnesses_truncated": False,
        "first_reduction_contribution_witness": {
            "index": 999,
            "reduction_kind": "terminal",
            "contribution": "1",
        },
        "reduction_contribution_witnesses": [
            {"index": 0, "reduction_kind": "terminal", "contribution": "1"},
            {"index": 1, "reduction_kind": "memoized_subtree", "contribution": "a"},
        ],
        "reduction_contribution_witness_consistency": {
            "matched": False,
            "mismatch_count": 2,
            "first_mismatch": {
                "kind": "reduction_contribution_witness_count",
                "field": "reduction_contribution_witness_count",
                "report_value": 3,
                "source_value": 2,
            },
            "mismatch_witnesses": [],
        },
        "terminal_contribution_sum": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
        "terminal_contribution_matches_result": True,
        "terminal_contribution_audit_skipped": False,
        "bounded_homfly_maturity_path": (
            "recursive_switching_to_descending_frontier_exhausted"
        ),
        "bounded_homfly_maturity_path_certified": True,
        "frontier_count": 0,
        "frontier_reason_count": 0,
        "frontier_reasons": [],
        "truncated": False,
        "certification_blockers": [],
        "certification_blocker_count": 0,
        "homfly_completion_blockers": [
            "full_table_normalization_not_certified",
            "arbitrary_diagram_coverage_not_certified",
        ],
        "homfly_completion_blocker_count": 2,
        "skipped": False,
        "notes": [],
    }
    note_token = (
        "homfly_reduction_contribution_witnesses=witnesses=3/8; "
        "truncated=False; parsed=4; unparsed=0; first_kind=terminal; "
        "first_index=999; consistency_matched=False; "
        "consistency_mismatch_count=2; "
        "first_mismatch=reduction_contribution_witness_count:"
        "reduction_contribution_witness_count"
    )

    summary = analysis_summary_from_acceptance_report(evidence)
    payload = imgui_analysis_payload_from_acceptance_reports([evidence])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[evidence],
    )

    assert summary["homfly_reduction_contribution_consistency_matched_count"] == 0
    assert summary["homfly_reduction_contribution_consistency_mismatch_count"] == 2
    assert note_token in summary["notes"]
    assert (
        payload["analysis_homfly_reduction_contribution_consistency_mismatch_count"]
        == 2
    )
    assert note_token in payload["analysis_summaries"][0]["notes"]
    assert note_token in host_payload["analysis"]["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_analysis_summary_wraps_homfly_skein_identity_audit() -> None:
    audit = {
        "method": "homfly_skein_identity_audit",
        "claim_scope": "local_homfly_skein_identity_for_signed_pd_input",
        "normalization": "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1",
        "input": {
            "signed_pd_revision": 456,
        },
        "crossing_count": 2,
        "checked_crossing_count": 2,
        "max_crossings": 8,
        "max_depth": 12,
        "max_nodes": 2048,
        "matched": True,
        "skipped": False,
        "truncated": False,
        "crossing_audits": [
            {
                "crossing_index": 0,
                "matched": True,
                "skipped": False,
                "truncated": False,
                "branches": {
                    "positive": {"frontier_count": 0, "truncated": False},
                    "negative": {"frontier_count": 0, "truncated": False},
                    "smoothed": {"frontier_count": 0, "truncated": False},
                },
                "difference": "0",
                "notes": [],
            },
            {
                "crossing_index": 1,
                "matched": True,
                "skipped": False,
                "truncated": False,
                "branches": {
                    "positive": {"frontier_count": 0, "truncated": False},
                    "negative": {"frontier_count": 0, "truncated": False},
                    "smoothed": {"frontier_count": 0, "truncated": False},
                },
                "difference": "0",
                "notes": [],
            },
        ],
        "notes": [],
    }

    summary = analysis_summary_from_acceptance_report(audit)

    assert summary["name"] == "HOMFLY skein identity audit"
    assert summary["source_method"] == "homfly_skein_identity_audit"
    assert summary["has_source_signed_pd_revision"] is True
    assert summary["source_signed_pd_revision"] == 456
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 2
    assert summary["passed_check_count"] == 2
    assert summary["failed_check_count"] == 0
    assert summary["certification_applicable_count"] == 2
    assert summary["certification_certified_count"] == 2
    assert summary["certification_uncertified_count"] == 0
    assert summary["input_certification_frontier_count"] == 0
    assert summary["input_certification_truncated_count"] == 0
    assert "skein_checked=2" in summary["notes"]
    assert "signed_pd_revision=456" in summary["notes"]
    assert "skein_matched=2" in summary["notes"]
    assert "full_table_normalization_certified=False" in summary["notes"]

    payload = imgui_analysis_payload_from_acceptance_reports([audit])
    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 2
    assert payload["analysis_passed_check_count"] == 2
    assert payload["analysis_failed_check_count"] == 0
    assert payload["analysis_input_certification_frontier_count"] == 0
    json.dumps(payload, allow_nan=False)

def test_imgui_invariant_status_payload_wraps_acceptance_reports() -> None:
    homfly = homfly_fixture_acceptance_report(notations=["0_1"])
    alexander = multivariable_alexander_fixture_acceptance_report(notations=["L2a1"])
    alexander_maturity_consistency = alexander["bounded_alexander_maturity_path_summary_consistency"]

    payload = imgui_invariant_status_payload_from_acceptance_reports(
        [homfly, alexander]
    )

    assert payload["method"] == (
        "imgui_invariant_status_payload_from_acceptance_reports"
    )
    assert payload["invariant_status_count"] == 2
    assert (
        payload[
            "invariant_source_table_audit_registration_summary_consistency_available_count"
        ]
        == 2
    )
    assert (
        payload[
            "invariant_source_table_audit_registration_summary_consistency_matched_count"
        ]
        == 2
    )
    assert (
        payload[
            "invariant_source_table_audit_registration_summary_consistency_mismatch_count"
        ]
        == 0
    )
    assert (
        payload[
            "invariant_bounded_alexander_maturity_path_summary_consistency_available_count"
        ]
        == 1
    )
    assert (
        payload[
            "invariant_bounded_alexander_maturity_path_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "invariant_bounded_alexander_maturity_path_summary_consistency_path_count_total"
        ]
        == alexander_maturity_consistency["path_count_total"]
    )
    statuses = {status["name"]: status for status in payload["invariant_statuses"]}

    homfly_status = statuses["HOMFLY-PT"]
    assert homfly_status["value"] == "accepted (2/2 checks)"
    assert homfly_status["skipped"] is False
    assert homfly_status["required_check_count"] == 2
    assert homfly_status["passed_check_count"] == 2
    assert homfly_status["failed_check_count"] == 0
    assert (
        homfly_status[
            "source_table_audit_registration_summary_consistency_status"
        ]
        == "matched"
    )
    assert "claim_scope: registered_fixture_acceptance" in homfly_status["notes"]

    alexander_status = statuses["multi-variable Alexander"]
    assert alexander_status["value"] == "accepted (4/4 checks)"
    assert alexander_status["skipped"] is False
    assert alexander_status["required_check_count"] == 4
    assert alexander_status["passed_check_count"] == 4
    assert alexander_status["failed_check_count"] == 0
    assert (
        alexander_status[
            "source_table_audit_registration_summary_consistency_status"
        ]
        == "matched"
    )
    assert "admissible_minor_scan=expected=4" in alexander_status["notes"]
    assert "nonzero=4" in alexander_status["notes"]
    assert "rows_nonzero=1" in alexander_status["notes"]
    assert "columns_nonzero=1" in alexander_status["notes"]
    assert alexander_status["bounded_scanned_gcd_expected_minor_combination_count"] == 4
    assert alexander_status["bounded_scanned_gcd_nonzero_minor_count"] == 4
    assert alexander_status["bounded_scanned_gcd_unique_nonzero_polynomial_count"] == 2
    assert alexander_status["bounded_scanned_gcd_complete_scan_count"] == 1
    assert (
        alexander_status[
            "bounded_scanned_gcd_nonzero_minor_coverage_complete_count"
        ]
        == 1
    )

    assert (
        alexander_status[
            "bounded_alexander_maturity_path_summary_consistency_available_count"
        ]
        == 1
    )
    assert (
        alexander_status[
            "bounded_alexander_maturity_path_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        alexander_status[
            "bounded_alexander_maturity_path_summary_consistency_record_count"
        ]
        == alexander_maturity_consistency["record_count"]
    )
    assert (
        "bounded_alexander_maturity_path_summary_consistency=matched=True"
        in alexander_status["notes"]
    )
    assert payload["invariant_required_check_count"] == 6
    assert payload["invariant_passed_check_count"] == 6
    assert payload["invariant_failed_check_count"] == 0
    assert payload["invariant_bounded_scanned_gcd_expected_minor_combination_count"] == 4
    assert payload["invariant_bounded_scanned_gcd_nonzero_minor_count"] == 4
    json.dumps(payload, allow_nan=False)


def test_imgui_invariant_status_keeps_skipped_report_visible() -> None:
    report = multivariable_alexander_fixture_acceptance_report(
        notations=["L5a1"],
        include_unregistered=True,
    )

    status = invariant_status_from_acceptance_report(report)

    assert status["name"] == "multi-variable Alexander"
    assert status["value"] == "skipped (0/1 checks, 1 failed)"
    assert status["skipped"] is True
    assert status["required_check_count"] == 1
    assert status["passed_check_count"] == 0
    assert status["failed_check_count"] == 1
    assert status["source_table_alexander_numerator_checked_count"] == 1
    assert status["source_table_alexander_numerator_source_seen_count"] == 1
    assert status["source_table_alexander_numerator_complete_match_count"] == 0
    assert status["source_table_alexander_numerator_returned_match_count"] == 0
    assert status["source_table_alexander_numerator_incomplete_or_unstable_count"] == 1
    assert status["source_table_alexander_numerator_candidate_unique_value_count"] == 2
    assert status["source_table_alexander_numerator_computed_candidate_count"] == 16
    assert status["source_table_alexander_numerator_skipped_candidate_count"] == 8
    assert status["source_table_alexander_numerator_missing_candidate_count"] == 8
    assert (
        status[
            "source_table_alexander_numerator_link_normalization_checked_count"
        ]
        == 1
    )
    assert (
        status[
            "source_table_alexander_numerator_link_normalization_ready_count"
        ]
        == 0
    )
    assert (
        status[
            "source_table_alexander_numerator_link_normalization_blocked_count"
        ]
        == 1
    )
    assert (
        status[
            "source_table_alexander_numerator_link_normalization_blocker_count"
        ]
        == 2
    )
    assert status["source_table_alexander_skipped_common_gcd_attempt_candidate_count"] == 8
    assert (
        status[
            "source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count"
        ]
        == 8
    )
    assert status["source_table_alexander_skipped_common_gcd_attempt_method_count"] == 8
    assert (
        status[
            "source_table_alexander_skipped_common_gcd_attempt_limit_variant_count"
        ]
        == 1
    )
    assert (
        status[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count"
        ]
        == 8
    )
    assert (
        status[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_min"
        ]
        == 10
    )
    assert (
        status[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max"
        ]
        == 10
    )
    assert (
        status[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed_count"
        ]
        == 1
    )
    assert (
        status[
            "source_table_alexander_source_divisibility_checked_candidate_count"
        ]
        == 8
    )
    assert (
        status[
            "source_table_alexander_source_divisibility_source_divides_all_candidate_count"
        ]
        == 0
    )
    assert (
        status[
            "source_table_alexander_source_divisibility_source_division_failed_candidate_count"
        ]
        == 8
    )
    assert (
        status[
            "source_table_alexander_source_divisibility_status_variant_count"
        ]
        == 1
    )
    assert (
        status[
            "source_table_alexander_source_divisibility_failed_candidate_witness_count"
        ]
        == 8
    )
    assert (
        status[
            "source_table_alexander_source_divisibility_failed_candidate_witness_truncated"
        ]
        == 0
    )
    assert status["source_table_audit_registration_ready_count"] == 0
    assert status["source_table_audit_registration_blocked_count"] == 1
    assert status["source_table_audit_registration_blocker_count"] == 4
    assert status["source_table_audit_registration_blockers"] == (
        "fixture_signs_not_registered,"
        "registered_fixture_invariant_claim_disabled,"
        "source_compatible_sign_pattern_not_unique,"
        "source_table_values_uncomputed"
    )
    assert status["source_table_audit_registration_blocker_code_count"] == 4
    assert status["source_table_audit_registration_blocker_count_signature"] == (
        "fixture_signs_not_registered:1,"
        "registered_fixture_invariant_claim_disabled:1,"
        "source_compatible_sign_pattern_not_unique:1,"
        "source_table_values_uncomputed:1"
    )
    assert "claim_scope: registered_fixture_acceptance" in status["notes"]
    assert "incomplete: L5a1" in status["notes"]
    assert "source_table_alexander_numerator=checked=1" in status["notes"]
    assert "complete_match=0" in status["notes"]
    assert (
        "source_table_alexander_link_normalization="
        "checked=1; ready=0; blocked=1; blockers=2"
        in status["notes"]
    )
    assert (
        "source_table_alexander_skipped_common_gcd_attempts="
        "candidates=8; not_certified=8; statuses=not_certified:8"
        in status["notes"]
    )
    assert (
        "source_table_alexander_source_divisibility="
        "candidates=8; source_divides_all=0; source_division_failed=8; "
        "statuses=source_does_not_divide_all_inputs:8"
        in status["notes"]
    )
    assert "candidate_indices=4,5,10,11,12,13,18,19" in status["notes"]
    assert "first_failed_notation=L5a1" in status["notes"]
    assert "first_failed_candidate=4" in status["notes"]
    assert (
        "first_failed_input=2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2"
        in status["notes"]
    )
    assert "failed_candidate_witness_count=8" in status["notes"]
    assert "failed_candidate_witness_truncated=False" in status["notes"]
    assert (
        "source_table_registration=checked=1; ready=0; blocked=1; blockers=4"
        in status["notes"]
    )
    assert "registration_ready=false" in status["notes"]
    assert "fixture_signs_not_registered" in status["notes"]
    assert "registered_fixture_invariant_claim_disabled" in status["notes"]
    assert "source_table_values_uncomputed" in status["notes"]
    assert "source_compatible_sign_pattern_not_unique" in status["notes"]
    assert "first_failed_candidate_witness_notation=L5a1" in status["notes"]
    assert "first_failed_candidate_witness_candidate=4" in status["notes"]
    assert (
        "first_failed_candidate_witness_status="
        "source_does_not_divide_all_inputs"
        in status["notes"]
    )
    assert (
        "first_failed_candidate_witness_input="
        "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2"
        in status["notes"]
    )
    assert "failed_inputs=10..10" in status["notes"]
    assert "input_polynomials=25..25" in status["notes"]
    assert "unique_inputs=10..10" in status["notes"]
    assert "direct_divisor_candidates=10" in status["notes"]
    assert "direct_divisor_failed=10" in status["notes"]
    assert "direct_divisor_all_failed=1" in status["notes"]
    assert "limit_variants=1" in status["notes"]

    payload = imgui_invariant_status_payload_from_acceptance_reports([report])
    assert payload["invariant_source_table_alexander_numerator_checked_count"] == 1
    assert payload["invariant_source_table_alexander_numerator_source_seen_count"] == 1
    assert payload["invariant_source_table_alexander_numerator_complete_match_count"] == 0
    assert payload["invariant_source_table_alexander_numerator_returned_match_count"] == 0
    assert (
        payload[
            "invariant_source_table_alexander_numerator_incomplete_or_unstable_count"
        ]
        == 1
    )
    assert (
        payload["invariant_source_table_alexander_numerator_candidate_unique_value_count"]
        == 2
    )
    assert payload["invariant_source_table_alexander_numerator_computed_candidate_count"] == 16
    assert payload["invariant_source_table_alexander_numerator_skipped_candidate_count"] == 8
    assert payload["invariant_source_table_alexander_numerator_missing_candidate_count"] == 8
    assert (
        payload[
            "invariant_source_table_alexander_numerator_link_normalization_checked_count"
        ]
        == 1
    )
    assert (
        payload[
            "invariant_source_table_alexander_numerator_link_normalization_ready_count"
        ]
        == 0
    )
    assert (
        payload[
            "invariant_source_table_alexander_numerator_link_normalization_blocked_count"
        ]
        == 1
    )
    assert (
        payload[
            "invariant_source_table_alexander_numerator_link_normalization_blocker_count"
        ]
        == 2
    )
    assert (
        payload[
            "invariant_source_table_alexander_skipped_common_gcd_attempt_candidate_count"
        ]
        == 8
    )
    assert (
        payload[
            "invariant_source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count"
        ]
        == 8
    )
    assert (
        payload[
            "invariant_source_table_alexander_skipped_common_gcd_attempt_method_count"
        ]
        == 8
    )
    assert (
        payload[
            "invariant_source_table_alexander_skipped_common_gcd_attempt_limit_variant_count"
        ]
        == 1
    )
    assert (
        payload[
            "invariant_source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count"
        ]
        == 8
    )
    assert (
        payload[
            "invariant_source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_min"
        ]
        == 10
    )
    assert (
        payload[
            "invariant_source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max"
        ]
        == 10
    )
    assert (
        payload[
            "invariant_source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed_count"
        ]
        == 1
    )
    assert (
        payload[
            "invariant_source_table_alexander_source_divisibility_checked_candidate_count"
        ]
        == 8
    )
    assert (
        payload[
            "invariant_source_table_alexander_source_divisibility_source_divides_all_candidate_count"
        ]
        == 0
    )
    assert (
        payload[
            "invariant_source_table_alexander_source_divisibility_source_division_failed_candidate_count"
        ]
        == 8
    )
    assert (
        payload[
            "invariant_source_table_alexander_source_divisibility_status_variant_count"
        ]
        == 1
    )
    assert (
        payload[
            "invariant_source_table_alexander_source_divisibility_failed_candidate_witness_count"
        ]
        == 8
    )
    assert (
        payload[
            "invariant_source_table_alexander_source_divisibility_failed_candidate_witness_truncated"
        ]
        == 0
    )
    assert payload["invariant_source_table_audit_registration_ready_count"] == 0
    assert payload["invariant_source_table_audit_registration_blocked_count"] == 1
    assert payload["invariant_source_table_audit_registration_blocker_count"] == 4
    json.dumps(payload, allow_nan=False)


def test_imgui_signed_pd_payload_wraps_fixture_diagrams() -> None:
    report = homfly_fixture_acceptance_report(notations=["L2a1"])

    payload = imgui_signed_pd_payload_from_acceptance_reports([report])

    assert payload["method"] == "imgui_signed_pd_payload_from_acceptance_reports"
    assert payload["signed_pd_diagram_count"] == 1
    assert payload["signed_pd_crossing_count"] == 2
    assert payload["skipped_fixture_count"] == 0

    diagram = payload["signed_pd_diagrams"][0]
    assert diagram["fixture_name"] == "L2a1"
    assert diagram["name"] == "Hopf link"
    assert diagram["component_count"] == 2
    assert diagram["crossings"] == [
        {
            "sign": 1,
            "edge_labels": [1, 4, 2, 3],
            "role_order": [0, 1, 2, 3],
            "role_order_explicit": False,
        },
        {
            "sign": -1,
            "edge_labels": [3, 2, 4, 1],
            "role_order": [0, 1, 2, 3],
            "role_order_explicit": False,
        },
    ]
    assert "source:" in diagram["notes"]
    json.dumps(payload, allow_nan=False)


def test_imgui_signed_pd_payload_preserves_explicit_fixture_role_orders() -> None:
    report = homfly_fixture_acceptance_report(notations=["4_1"])

    payload = imgui_signed_pd_payload_from_acceptance_reports([report])

    assert payload["signed_pd_diagram_count"] == 1
    diagram = payload["signed_pd_diagrams"][0]
    assert diagram["fixture_name"] == "4_1"
    role_orders = [crossing["role_order"] for crossing in diagram["crossings"]]
    assert role_orders == [
        [0, 3, 2, 1],
        [0, 3, 2, 1],
        [0, 1, 2, 3],
        [0, 1, 2, 3],
    ]
    assert [crossing["role_order_explicit"] for crossing in diagram["crossings"]] == [
        True,
        True,
        True,
        True,
    ]
    assert "explicit orientation role orders are registered" in diagram["notes"]
    json.dumps(payload, allow_nan=False)

def test_imgui_signed_pd_payload_skips_unsigned_fixtures() -> None:
    report = multivariable_alexander_fixture_acceptance_report(
        notations=["L5a1"],
        include_unregistered=True,
    )

    payloads = signed_pd_payloads_from_acceptance_report(report)
    payload = imgui_signed_pd_payload_from_acceptance_reports([report])

    assert payloads == []
    assert payload["signed_pd_diagram_count"] == 0
    assert payload["signed_pd_crossing_count"] == 0
    assert payload["skipped_fixture_count"] == 1
    assert payload["skipped_fixtures"] == ["L5a1"]
    json.dumps(payload, allow_nan=False)


def test_imgui_kernel_backend_status_payload_wraps_backend_report() -> None:
    report = {
        "auto_backend": "rust",
        "kernel_capabilities": [
            "segment_segment_distance",
            "compute_writhe",
        ],
        "backends": {
            "numpy": {
                "available": True,
                "module": "numpy",
                "version": "2.test",
                "selected_by_auto": False,
                "explicit_only": False,
                "capabilities": {
                    "segment_segment_distance": True,
                    "compute_writhe": True,
                },
                "missing_capabilities": [],
            },
            "rust": {
                "available": True,
                "module": "iroll_kernels_rust",
                "module_origin": "native/rust",
                "selected_by_auto": True,
                "explicit_only": False,
                "capabilities": {
                    "segment_segment_distance": True,
                    "compute_writhe": False,
                },
                "missing_capabilities": ["compute_writhe"],
                "backend_info": {
                    "owned_string_reports": {
                        "result_handle_abi": "owned_string_v1",
                        "owned_string_contract": {
                            "schema_version": 1,
                            "contract_version": "rust_owned_string_v1",
                            "abi_version": 19,
                            "owner": "rust_library",
                            "data": "utf8_json_nul_terminated",
                            "length": "utf8_byte_length_excluding_trailing_nul",
                            "handle": "opaque_free_handle",
                            "free_symbol": "iroll_kernel_owned_string_free",
                            "free_required": True,
                            "free_accepts_zero_initialized": True,
                            "borrowed_across_calls": False,
                        },
                    },
                    "invariant_result_handles": {
                        "result_handle_abi": "owned_string_v1",
                        "homfly_report_json": False,
                        "alexander_report_json": False,
                        "native_computation_claimed": False,
                        "native_invariant_result_handles_complete": False,
                        "complete_result_handle_abi": False,
                        "release_grade_result_handles": False,
                        "native_invariant_result_handle_blockers": [
                            "homfly_native_compute_handle_missing",
                            "alexander_native_compute_handle_missing",
                            "native_result_compute_payload_lifecycle_incomplete",
                            "long_invariant_progress_cancel_missing",
                            "python_fixture_report_parity_missing",
                            "dear_imgui_native_invariant_status_reload_missing",
                        ],
                        "native_invariant_result_handle_blocker_count": 6,
                        "required_native_invariant_handle_gates": [
                            {
                                "gate": "homfly_native_compute_handle",
                                "status": "missing",
                                "evidence_required": "native HOMFLY parity",
                            },
                            {
                                "gate": "alexander_native_compute_handle",
                                "status": "missing",
                                "evidence_required": "native Alexander parity",
                            },
                            {
                                "gate": "result_ownership_freeing_lifecycle",
                                "status": "unsupported_handle_lifecycle_only",
                                "evidence_required": "opaque native result lifecycle",
                            },
                            {
                                "gate": "progress_cancel_for_long_invariant_computations",
                                "status": "missing",
                                "evidence_required": "long invariant progress/cancel wiring",
                            },
                            {
                                "gate": "parity_against_python_fixture_reports",
                                "status": "missing",
                                "evidence_required": "fixture report parity evidence",
                            },
                            {
                                "gate": "host_reload_into_dear_imgui_invariant_status_rows",
                                "status": "file_recompute_boundary_only",
                                "evidence_required": "native invariant-status reload",
                            },
                        ],
                        "required_native_invariant_handle_gate_count": 6,
                        "python_file_recompute_boundary": True,
                        "file_recompute_boundary": {
                            "boundary": "python_file_recompute",
                            "input_formats": [
                                "signed_pd_json",
                                "imgui_signed_pd_json",
                            ],
                            "homfly_cli_command": [
                                "iroll",
                                "homfly-pd",
                            ],
                            "alexander_cli_command": [
                                "iroll",
                                "multivariable-alexander-pd",
                            ],
                            "result_transport": [
                                "json_file",
                                "stdout_json",
                            ],
                            "host_reload_payload": (
                                "imgui-signed-pd-invariant-status-payload"
                            ),
                        },
                        "current_file_recompute_boundary": {
                            "boundary": "python_file_recompute",
                            "input_formats": [
                                "signed_pd_json",
                                "imgui_signed_pd_json",
                            ],
                            "pipeline": [
                                "signed_pd_json/imgui_signed_pd_json",
                                "iroll homfly-pd or iroll multivariable-alexander-pd",
                                "iroll imgui-signed-pd-invariant-status-payload",
                                "Dear ImGui invariant-status rows",
                            ],
                            "native_result_handle_boundary": False,
                            "host_reload_payload": (
                                "imgui-signed-pd-invariant-status-payload"
                            ),
                        },
                        "readiness_provenance_self_consistency": {
                            "schema_version": 1,
                            "readiness": "blocked",
                            "ready_for_native_result_handles": False,
                            "native_computation_claimed": False,
                            "python_file_recompute_boundary": True,
                            "native_result_handle_boundary": False,
                            "current_boundary": "python_file_recompute",
                            "host_action": "use_python_file_recompute_boundary",
                            "self_consistency": {
                                "unsupported_row_count": 2,
                                "per_invariant_link_count": 2,
                                "required_gate_blocker_link_count": 6,
                                "readiness_blocked_by_required_gates": True,
                                "native_computation_non_claim_consistent": True,
                            },
                        },
                        "readiness_provenance_note": (
                            "readiness_provenance_self_consistency=present; "
                            "readiness=blocked; "
                            "ready_for_native_result_handles=false; "
                            "current_boundary=python_file_recompute; "
                            "required_native_handle_gates_block_native_result_handle_boundary=true"
                        ),
                        "claim_scope": "capability_probe_only",
                        "status": "metadata_only",
                    },
                },
            },
            "gpu": {
                "available": False,
                "module": "iroll_kernels_gpu",
                "selected_by_auto": False,
                "explicit_only": True,
                "capabilities": {
                    "segment_segment_distance": False,
                    "compute_writhe": False,
                },
                "missing_capabilities": [
                    "segment_segment_distance",
                    "compute_writhe",
                ],
                "backend_info_error": "no CUDA device",
            },
        },
        "notes": ["GPU kernels are explicit-only"],
    }

    statuses = kernel_backend_statuses_from_backend_report(report)
    payload = imgui_kernel_backend_status_payload_from_backend_report(report)

    assert [status["name"] for status in statuses] == ["numpy", "rust", "gpu"]
    by_name = {status["name"]: status for status in statuses}
    rust_result_handles = report["backends"]["rust"]["backend_info"][
        "invariant_result_handles"
    ]
    assert rust_result_handles["native_invariant_result_handles_complete"] is False
    assert rust_result_handles["complete_result_handle_abi"] is False
    assert rust_result_handles["release_grade_result_handles"] is False
    assert rust_result_handles["native_invariant_result_handle_blocker_count"] == len(
        rust_result_handles["native_invariant_result_handle_blockers"]
    )
    assert rust_result_handles["required_native_invariant_handle_gate_count"] == len(
        rust_result_handles["required_native_invariant_handle_gates"]
    )
    assert rust_result_handles["current_file_recompute_boundary"]["boundary"] == (
        "python_file_recompute"
    )
    assert (
        rust_result_handles["current_file_recompute_boundary"][
            "native_result_handle_boundary"
        ]
        is False
    )
    assert by_name["numpy"]["display_name"] == "NumPy"
    assert by_name["numpy"]["available"] is True
    assert by_name["numpy"]["selected"] is False
    assert "2/2 capabilities" in by_name["numpy"]["capabilities"]
    assert "version: 2.test" in by_name["numpy"]["notes"]
    assert by_name["numpy"]["owned_string_contract_schema_version"] == 0
    assert by_name["numpy"]["owned_string_contract_abi_version"] == 0
    assert by_name["numpy"]["owned_string_contract_version_length"] == 0
    assert by_name["numpy"]["owned_string_contract_free_required"] is False
    assert (
        by_name["numpy"]["owned_string_contract_free_accepts_zero_initialized"]
        is False
    )
    assert by_name["numpy"]["owned_string_contract_borrowed_across_calls"] is False
    assert by_name["numpy"]["invariant_result_handles_native_result_handles_complete"] is False
    assert by_name["numpy"]["invariant_result_handles_complete_result_handle_abi"] is False
    assert by_name["numpy"]["invariant_result_handles_release_grade_result_handles"] is False
    assert (
        by_name["numpy"][
            "invariant_result_handles_readiness_provenance_present"
        ]
        is False
    )
    assert (
        by_name["numpy"][
            "invariant_result_handles_ready_for_native_result_handles"
        ]
        is False
    )
    assert (
        by_name["numpy"][
            "invariant_result_handles_readiness_blocked_by_required_gates"
        ]
        is False
    )
    assert (
        by_name["numpy"][
            "invariant_result_handles_readiness_provenance_note_length"
        ]
        == 0
    )

    assert by_name["rust"]["display_name"] == "Rust"
    assert by_name["rust"]["selected"] is True
    assert by_name["rust"]["capabilities"] == (
        "1/2 capabilities; missing: compute_writhe"
    )
    assert by_name["rust"]["owned_string_contract_schema_version"] == 1
    assert by_name["rust"]["owned_string_contract_abi_version"] == 19
    assert by_name["rust"]["owned_string_contract_version_length"] == len(
        "rust_owned_string_v1"
    )
    assert by_name["rust"]["owned_string_contract_free_required"] is True
    assert (
        by_name["rust"]["owned_string_contract_free_accepts_zero_initialized"]
        is True
    )
    assert by_name["rust"]["owned_string_contract_borrowed_across_calls"] is False
    assert by_name["rust"]["invariant_result_handles_native_result_handles_complete"] is False
    assert by_name["rust"]["invariant_result_handles_complete_result_handle_abi"] is False
    assert by_name["rust"]["invariant_result_handles_release_grade_result_handles"] is False
    assert (
        by_name["rust"][
            "invariant_result_handles_readiness_provenance_present"
        ]
        is True
    )
    assert (
        by_name["rust"][
            "invariant_result_handles_ready_for_native_result_handles"
        ]
        is False
    )
    assert (
        by_name["rust"][
            "invariant_result_handles_readiness_blocked_by_required_gates"
        ]
        is True
    )
    assert by_name["rust"][
        "invariant_result_handles_readiness_provenance_note_length"
    ] == len(rust_result_handles["readiness_provenance_note"])
    assert "origin: native/rust" in by_name["rust"]["notes"]
    assert (
        "owned_string_contract: schema_version=1, abi_version=19, "
        "contract_version_length=20, free_required=true, "
        "free_accepts_zero_initialized=true, borrowed_across_calls=false"
        in by_name["rust"]["notes"]
    )
    assert (
        "invariant_result_handles: status=metadata_only, homfly=false, "
        "alexander=false, native_claim=false, python_file_boundary=true"
        in by_name["rust"]["notes"]
    )
    assert (
        "native_invariant_result_handle_blocker_count=6; "
        "first_native_invariant_result_handle_blocker="
        "homfly_native_compute_handle_missing"
        in by_name["rust"]["notes"]
    )
    assert (
        "required_native_invariant_handle_gate_count=6"
        in by_name["rust"]["notes"]
    )
    assert (
        "file_recompute_boundary=boundary=python_file_recompute; "
        "inputs=signed_pd_json|imgui_signed_pd_json; "
        "homfly_cli=iroll homfly-pd; "
        "alexander_cli=iroll multivariable-alexander-pd; "
        "transport=json_file|stdout_json; "
        "host_reload=imgui-signed-pd-invariant-status-payload"
        in by_name["rust"]["notes"]
    )
    assert (
        "current_file_recompute_boundary=boundary=python_file_recompute; "
        "inputs=signed_pd_json|imgui_signed_pd_json; "
        "pipeline=signed_pd_json/imgui_signed_pd_json -> "
        "iroll homfly-pd or iroll multivariable-alexander-pd -> "
        "iroll imgui-signed-pd-invariant-status-payload -> "
        "Dear ImGui invariant-status rows; "
        "host_reload=imgui-signed-pd-invariant-status-payload; "
        "native_result_handle_boundary=false"
        in by_name["rust"]["notes"]
    )
    assert (
        "readiness_provenance=readiness=blocked; ready=false; "
        "host_action=use_python_file_recompute_boundary; "
        "python_file_recompute_boundary=true; "
        "native_result_handle_boundary=false; unsupported_rows=2; "
        "per_invariant_links=2; gate_blocker_links=6; "
        "blocked_by_required_gates=true; native_non_claim=true"
        in by_name["rust"]["notes"]
    )

    assert by_name["gpu"]["display_name"] == "GPU"
    assert by_name["gpu"]["available"] is False
    assert by_name["gpu"]["explicit_only"] is True
    assert by_name["gpu"]["owned_string_contract_schema_version"] == 0
    assert by_name["gpu"]["owned_string_contract_abi_version"] == 0
    assert by_name["gpu"]["owned_string_contract_version_length"] == 0
    assert by_name["gpu"]["owned_string_contract_free_required"] is False
    assert (
        by_name["gpu"]["owned_string_contract_free_accepts_zero_initialized"]
        is False
    )
    assert by_name["gpu"]["owned_string_contract_borrowed_across_calls"] is False
    assert by_name["gpu"]["invariant_result_handles_native_result_handles_complete"] is False
    assert by_name["gpu"]["invariant_result_handles_complete_result_handle_abi"] is False
    assert by_name["gpu"]["invariant_result_handles_release_grade_result_handles"] is False
    assert (
        by_name["gpu"][
            "invariant_result_handles_readiness_provenance_present"
        ]
        is False
    )
    assert (
        by_name["gpu"][
            "invariant_result_handles_ready_for_native_result_handles"
        ]
        is False
    )
    assert (
        by_name["gpu"][
            "invariant_result_handles_readiness_blocked_by_required_gates"
        ]
        is False
    )
    assert (
        by_name["gpu"][
            "invariant_result_handles_readiness_provenance_note_length"
        ]
        == 0
    )
    assert "backend_info_error: no CUDA device" in by_name["gpu"]["notes"]

    assert payload["method"] == (
        "imgui_kernel_backend_status_payload_from_backend_report"
    )
    assert payload["kernel_backend_status_count"] == 3
    assert (
        payload[
            "kernel_backend_invariant_result_handles_native_result_handles_complete_count"
        ]
        == 0
    )
    assert (
        payload[
            "kernel_backend_invariant_result_handles_complete_result_handle_abi_count"
        ]
        == 0
    )
    assert (
        payload[
            "kernel_backend_invariant_result_handles_release_grade_result_handles_count"
        ]
        == 0
    )
    assert (
        payload[
            "kernel_backend_invariant_result_handles_readiness_provenance_present_count"
        ]
        == 1
    )
    assert (
        payload[
            "kernel_backend_invariant_result_handles_ready_for_native_result_handles_count"
        ]
        == 0
    )
    assert (
        payload[
            "kernel_backend_invariant_result_handles_readiness_blocked_by_required_gates_count"
        ]
        == 1
    )
    assert (
        payload[
            "kernel_backend_invariant_result_handles_readiness_provenance_note_length_max"
        ]
        == len(rust_result_handles["readiness_provenance_note"])
    )
    assert payload["auto_backend"] == "rust"
    assert payload["notes"] == "GPU kernels are explicit-only"
    json.dumps(payload, allow_nan=False)

    legacy_report = json.loads(json.dumps(report))
    del legacy_report["backends"]["rust"]["backend_info"]["invariant_result_handles"][
        "file_recompute_boundary"
    ]
    del legacy_report["backends"]["rust"]["backend_info"]["invariant_result_handles"][
        "current_file_recompute_boundary"
    ]
    del legacy_report["backends"]["rust"]["backend_info"]["invariant_result_handles"][
        "readiness_provenance_self_consistency"
    ]
    del legacy_report["backends"]["rust"]["backend_info"]["invariant_result_handles"][
        "readiness_provenance_note"
    ]
    del legacy_report["backends"]["rust"]["backend_info"]["owned_string_reports"]
    legacy_statuses = kernel_backend_statuses_from_backend_report(legacy_report)
    legacy_by_name = {status["name"]: status for status in legacy_statuses}
    legacy_payload = imgui_kernel_backend_status_payload_from_backend_report(
        legacy_report
    )
    assert "file_recompute_boundary=" not in legacy_by_name["rust"]["notes"]
    assert "readiness_provenance=" not in legacy_by_name["rust"]["notes"]
    assert "owned_string_contract:" not in legacy_by_name["rust"]["notes"]
    assert legacy_by_name["rust"]["owned_string_contract_schema_version"] == 0
    assert legacy_by_name["rust"]["owned_string_contract_abi_version"] == 0
    assert legacy_by_name["rust"]["owned_string_contract_version_length"] == 0
    assert legacy_by_name["rust"]["owned_string_contract_free_required"] is False
    assert (
        legacy_by_name["rust"][
            "owned_string_contract_free_accepts_zero_initialized"
        ]
        is False
    )
    assert (
        legacy_by_name["rust"]["owned_string_contract_borrowed_across_calls"]
        is False
    )
    assert legacy_by_name["rust"]["invariant_result_handles_native_result_handles_complete"] is False
    assert legacy_by_name["rust"]["invariant_result_handles_complete_result_handle_abi"] is False
    assert legacy_by_name["rust"]["invariant_result_handles_release_grade_result_handles"] is False
    assert (
        legacy_by_name["rust"][
            "invariant_result_handles_readiness_provenance_present"
        ]
        is False
    )
    assert (
        legacy_by_name["rust"][
            "invariant_result_handles_ready_for_native_result_handles"
        ]
        is False
    )
    assert (
        legacy_by_name["rust"][
            "invariant_result_handles_readiness_blocked_by_required_gates"
        ]
        is False
    )
    assert (
        legacy_by_name["rust"][
            "invariant_result_handles_readiness_provenance_note_length"
        ]
        == 0
    )
    assert (
        legacy_payload[
            "kernel_backend_invariant_result_handles_native_result_handles_complete_count"
        ]
        == 0
    )
    assert (
        legacy_payload[
            "kernel_backend_invariant_result_handles_complete_result_handle_abi_count"
        ]
        == 0
    )
    assert (
        legacy_payload[
            "kernel_backend_invariant_result_handles_release_grade_result_handles_count"
        ]
        == 0
    )
    assert (
        legacy_payload[
            "kernel_backend_invariant_result_handles_readiness_provenance_present_count"
        ]
        == 0
    )
    assert (
        legacy_payload[
            "kernel_backend_invariant_result_handles_ready_for_native_result_handles_count"
        ]
        == 0
    )
    assert (
        legacy_payload[
            "kernel_backend_invariant_result_handles_readiness_blocked_by_required_gates_count"
        ]
        == 0
    )
    assert (
        legacy_payload[
            "kernel_backend_invariant_result_handles_readiness_provenance_note_length_max"
        ]
        == 0
    )
    assert (
        "invariant_result_handles: status=metadata_only, homfly=false, "
        "alexander=false, native_claim=false, python_file_boundary=true"
        in legacy_by_name["rust"]["notes"]
    )
    json.dumps(legacy_payload, allow_nan=False)


def test_imgui_kernel_backend_status_preserves_readiness_provenance_mismatch() -> None:
    report = {
        "auto_backend": "rust",
        "kernel_capabilities": [],
        "backends": {
            "rust": {
                "available": True,
                "module": "iroll_kernels_rust",
                "selected_by_auto": True,
                "explicit_only": False,
                "capabilities": {},
                "missing_capabilities": [],
                "backend_info": {
                    "invariant_result_handles": {
                        "status": "metadata_only",
                        "homfly_report_json": False,
                        "alexander_report_json": False,
                        "native_computation_claimed": False,
                        "native_invariant_result_handles_complete": False,
                        "complete_result_handle_abi": False,
                        "release_grade_result_handles": False,
                        "python_file_recompute_boundary": True,
                        "readiness_provenance_self_consistency": {
                            "schema_version": 1,
                            "readiness": "blocked",
                            "ready_for_native_result_handles": False,
                            "native_computation_claimed": False,
                            "python_file_recompute_boundary": True,
                            "native_result_handle_boundary": False,
                            "current_boundary": "python_file_recompute",
                            "host_action": "use_python_file_recompute_boundary",
                            "self_consistency": {
                                "unsupported_row_count": 1,
                                "per_invariant_link_count": 1,
                                "required_gate_blocker_link_count": 5,
                                "readiness_blocked_by_required_gates": False,
                                "native_computation_non_claim_consistent": False,
                            },
                        },
                        "readiness_provenance_note": (
                            "stale readiness provenance summary"
                        ),
                        "claim_scope": "capability_probe_only",
                    },
                },
            },
        },
        "notes": [],
    }

    statuses = kernel_backend_statuses_from_backend_report(report)
    payload = imgui_kernel_backend_status_payload_from_backend_report(report)
    rust_status = statuses[0]
    note_token = (
        "readiness_provenance=readiness=blocked; ready=false; "
        "host_action=use_python_file_recompute_boundary; "
        "python_file_recompute_boundary=true; "
        "native_result_handle_boundary=false; unsupported_rows=1; "
        "per_invariant_links=1; gate_blocker_links=5; "
        "blocked_by_required_gates=false; native_non_claim=false"
    )

    assert rust_status["invariant_result_handles_readiness_provenance_present"] is True
    assert (
        rust_status["invariant_result_handles_ready_for_native_result_handles"]
        is False
    )
    assert (
        rust_status[
            "invariant_result_handles_readiness_blocked_by_required_gates"
        ]
        is False
    )
    assert rust_status[
        "invariant_result_handles_readiness_provenance_note_length"
    ] == len("stale readiness provenance summary")
    assert note_token in rust_status["notes"]
    assert (
        payload[
            "kernel_backend_invariant_result_handles_readiness_provenance_present_count"
        ]
        == 1
    )
    assert (
        payload[
            "kernel_backend_invariant_result_handles_readiness_blocked_by_required_gates_count"
        ]
        == 0
    )
    assert (
        payload[
            "kernel_backend_invariant_result_handles_readiness_provenance_note_length_max"
        ]
        == len("stale readiness provenance summary")
    )
    assert note_token in payload["kernel_backend_statuses"][0]["notes"]
    json.dumps(payload, allow_nan=False)


def test_imgui_analysis_summary_wraps_core_benchmark_matrix_report() -> None:
    report = {
        "method": "iroll_core_benchmark_matrix",
        "point_sizes": [32],
        "backends": ["numpy", "gpu"],
        "workloads": ["crossings", "contacts"],
        "repeat": 1,
        "warmup": 0,
        "matrix_summary": {
            "method": "iroll_core_benchmark_matrix_run_summary",
            "expected_row_count": 4,
            "row_count": 4,
            "completed_count": 4,
            "skipped_count": 0,
            "failed_count": 0,
            "all_requested_rows_completed": True,
            "has_failures": False,
        },
        "completed_count": 4,
        "skipped_count": 0,
        "failed_count": 0,
        "speedup_evidence": {
            "method": "iroll_core_benchmark_speedup_evidence",
            "candidate_speedup_count": 1,
            "release_grade_speedup_claimed": False,
            "release_gate": {
                "repeat": 1,
                "minimum_repeat_for_release_claim": 3,
                "repeat_satisfied": False,
                "speedup_threshold": 1.25,
                "threshold_candidate_count": 1,
                "completed_comparison_count": 2,
                "missing_baseline_count": 0,
                "release_grade_speedup_claimed": False,
                "blocking_reasons": ["repeat_below_minimum"],
            },
        },
        "cuda_gpu_benchmark_evidence": {
            "method": "iroll_core_cuda_gpu_benchmark_evidence",
            "gate_scope": "local_gpu_benchmark_witness",
            "gpu_backend_requested": True,
            "gpu_backend_available": True,
            "cuda_runtime_observed": True,
            "gpu_requested_row_count": 2,
            "gpu_completed_row_count": 2,
            "gpu_skipped_row_count": 0,
            "gpu_failed_row_count": 0,
            "gpu_threshold_candidate_count": 1,
            "generic_speedup_gate_claimed_for_gpu": False,
            "local_gpu_speedup_threshold_met": True,
            "hosted_cuda_ci_claimed": False,
            "cuda_parity_claimed": False,
            "release_grade_gpu_speedup_claimed": False,
            "blocking_reasons": [
                "cuda_parity_not_claimed",
                "hosted_cuda_ci_not_observed",
            ],
            "blocking_reason_count": 2,
        },
        "notes": ["synthetic benchmark matrix"],
    }

    summary = analysis_summary_from_acceptance_report(report)

    assert summary["name"] == "core benchmark matrix"
    assert summary["source_method"] == "iroll_core_benchmark_matrix"
    assert (
        summary["claim_scope"]
        == "local_backend_benchmark_matrix_profiling_evidence"
    )
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 4
    assert summary["passed_check_count"] == 4
    assert summary["failed_check_count"] == 0
    assert summary["certification_applicable_count"] == 0
    assert summary["benchmark_matrix_completed_row_count"] == 4
    assert summary["benchmark_speedup_release_grade_claimed_count"] == 0
    assert summary["benchmark_cuda_gpu_completed_row_count"] == 2
    assert summary["benchmark_cuda_gpu_threshold_candidate_count"] == 1
    assert summary["benchmark_cuda_gpu_runtime_observed_count"] == 1
    assert summary["benchmark_cuda_gpu_hosted_cuda_ci_claimed_count"] == 0
    assert summary["benchmark_cuda_gpu_parity_claimed_count"] == 0
    assert summary["benchmark_cuda_gpu_release_grade_speedup_claimed_count"] == 0
    assert summary["benchmark_cuda_gpu_backend_requested"] is True
    assert summary["benchmark_cuda_gpu_cuda_runtime_observed"] is True
    assert summary["benchmark_cuda_gpu_release_grade_speedup_claimed"] is False
    assert "release_grade_speedup_claimed=false" in summary["notes"]
    assert "gate_scope=local_gpu_benchmark_witness" in summary["notes"]
    assert "hosted_cuda_ci_claimed=false" in summary["notes"]
    assert "cuda_parity_claimed=false" in summary["notes"]
    assert "release_grade_gpu_speedup_claimed=false" in summary["notes"]
    assert "not CUDA parity evidence" in summary["notes"]

    payload = imgui_analysis_payload_from_acceptance_reports([report])

    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_accepted_summary_count"] == 1
    assert payload["analysis_certified_summary_count"] == 0
    assert payload["analysis_benchmark_matrix_completed_row_count"] == 4
    assert payload["analysis_benchmark_speedup_release_grade_claimed_count"] == 0
    assert payload["analysis_benchmark_cuda_gpu_completed_row_count"] == 2
    assert (
        payload[
            "analysis_benchmark_cuda_gpu_release_grade_speedup_claimed_count"
        ]
        == 0
    )
    json.dumps(payload, allow_nan=False)


def _synthetic_gpu_smoke_artifact(
    artifact_kind: str,
    *,
    parity_checks: int,
    passed_checks: int,
    failed_checks: int,
    backend_available: bool,
    cuda_runtime_observed: bool,
    no_cuda_boundary: bool = False,
    simulated_parity_failure: bool = False,
) -> dict:
    blocking_reasons = []
    if not backend_available:
        blocking_reasons.append("gpu_backend_unavailable")
    if not cuda_runtime_observed:
        blocking_reasons.append("cuda_runtime_not_observed")
    if parity_checks != 3:
        blocking_reasons.append("required_checks_incomplete")
    if failed_checks:
        blocking_reasons.append("required_checks_failed")
    if simulated_parity_failure:
        blocking_reasons.append("simulated_parity_failure")
    gate_passed = not blocking_reasons
    dispatch_claimed = (
        parity_checks > 0 and failed_checks == 0 and not no_cuda_boundary
    )
    return {
        "artifact_schema_version": 1,
        "artifact_kind": artifact_kind,
        "execution_path": (
            "optional_gpu_unavailable"
            if no_cuda_boundary
            else "gpu_backend_parity_mismatch"
            if failed_checks
            else "gpu_backend_parity"
        ),
        "claim_scope": (
            "optional_no_cuda_boundary"
            if no_cuda_boundary
            else "gpu_dispatch_parity_smoke"
        ),
        "required_capabilities": [
            "segment_segment_distance",
            "segment_segment_distances",
            "segment_intersections_2d",
        ],
        "required_capability_count": 3,
        "parity_check_count": parity_checks,
        "passed_check_count": passed_checks,
        "failed_check_count": failed_checks,
        "check_results": [
            {"name": f"check_{index}", "matched": index < passed_checks}
            for index in range(parity_checks)
        ],
        "environment_metadata": {
            "gpu_backend_available": backend_available,
        },
        "environment_witness": {
            "schema_version": 1,
            "runtime": {
                "cuda_runtime_observed": cuda_runtime_observed,
            },
            "simulation": {
                "simulated_parity_failure": simulated_parity_failure,
            },
        },
        "evidence": {
            "gpu_dispatch_parity": dispatch_claimed,
            "no_cuda_boundary": no_cuda_boundary,
            "cuda_parity": False,
            "release_grade_speedup": False,
        },
        "gpu_release_gate": {
            "schema_version": 1,
            "gate_scope": "gpu_dispatch_parity_smoke",
            "gpu_backend_available": backend_available,
            "cuda_runtime_observed": cuda_runtime_observed,
            "required_check_count": 3,
            "parity_check_count": parity_checks,
            "passed_check_count": passed_checks,
            "failed_check_count": failed_checks,
            "required_capability_count": 3,
            "blocking_reasons": blocking_reasons,
            "blocking_reason_count": len(blocking_reasons),
            "gpu_dispatch_parity_smoke_claimed": dispatch_claimed,
            "cuda_parity_claimed": False,
            "release_grade_speedup_claimed": False,
            "gate_passed": gate_passed,
        },
        "gpu_dispatch_parity_smoke_claimed": dispatch_claimed,
        "cuda_parity_claimed": False,
        "release_grade_speedup_claimed": False,
        "note": "synthetic GPU smoke artifact",
    }


def test_imgui_analysis_summary_wraps_gpu_smoke_artifacts() -> None:
    success = _synthetic_gpu_smoke_artifact(
        "gpu_smoke_parity_result",
        parity_checks=3,
        passed_checks=3,
        failed_checks=0,
        backend_available=True,
        cuda_runtime_observed=True,
    )
    no_cuda = _synthetic_gpu_smoke_artifact(
        "gpu_smoke_unavailable_boundary",
        parity_checks=0,
        passed_checks=0,
        failed_checks=0,
        backend_available=False,
        cuda_runtime_observed=False,
        no_cuda_boundary=True,
    )
    failure = _synthetic_gpu_smoke_artifact(
        "gpu_smoke_parity_failure",
        parity_checks=1,
        passed_checks=0,
        failed_checks=1,
        backend_available=False,
        cuda_runtime_observed=False,
        simulated_parity_failure=True,
    )

    success_summary = analysis_summary_from_acceptance_report(success)
    no_cuda_summary = analysis_summary_from_acceptance_report(no_cuda)
    failure_summary = analysis_summary_from_acceptance_report(failure)

    assert success_summary["source_method"] == "gpu_smoke_parity_result"
    assert success_summary["accepted"] is True
    assert success_summary["certified"] is False
    assert success_summary["required_check_count"] == 3
    assert success_summary["passed_check_count"] == 3
    assert success_summary["gpu_smoke_dispatch_parity_claimed_count"] == 1
    assert success_summary["gpu_smoke_cuda_parity_claimed_count"] == 0
    assert success_summary["gpu_smoke_release_grade_speedup_claimed_count"] == 0
    assert success_summary["gpu_smoke_cuda_runtime_observed"] is True
    assert success_summary["gpu_smoke_required_capability_name_count"] == 3
    assert success_summary["gpu_smoke_required_capability_names"] == (
        "segment_segment_distance|"
        "segment_segment_distances|"
        "segment_intersections_2d"
    )
    assert "gpu_smoke_required_capabilities=segment_segment_distance|" in (
        success_summary["notes"]
    )
    assert "not CUDA parity evidence" in success_summary["notes"]

    assert no_cuda_summary["source_method"] == "gpu_smoke_unavailable_boundary"
    assert no_cuda_summary["accepted"] is True
    assert no_cuda_summary["required_check_count"] == 0
    assert no_cuda_summary["gpu_smoke_no_cuda_boundary_count"] == 1
    assert no_cuda_summary["gpu_smoke_cuda_runtime_observed"] is False
    assert (
        no_cuda_summary[
            "gpu_smoke_release_gate_gpu_backend_unavailable_blocker_count"
        ]
        == 1
    )
    assert (
        no_cuda_summary[
            "gpu_smoke_release_gate_cuda_runtime_not_observed_blocker_count"
        ]
        == 1
    )
    assert (
        no_cuda_summary[
            "gpu_smoke_release_gate_required_checks_incomplete_blocker_count"
        ]
        == 1
    )
    assert (
        no_cuda_summary[
            "gpu_smoke_release_gate_forced_unavailable_blocker_count"
        ]
        == 0
    )
    assert "gpu_release_gate_blockers=gpu_backend_unavailable" in no_cuda_summary[
        "notes"
    ]
    assert "gpu_release_gate_blocker_codes=" in no_cuda_summary["notes"]

    assert failure_summary["source_method"] == "gpu_smoke_parity_failure"
    assert failure_summary["accepted"] is False
    assert failure_summary["failed_check_count"] == 1
    assert failure_summary["gpu_smoke_failed_check_name_count"] == 1
    assert failure_summary["gpu_smoke_failed_check_names"] == "check_0"
    assert failure_summary["gpu_smoke_simulated_parity_failure_count"] == 1
    assert (
        failure_summary[
            "gpu_smoke_release_gate_required_checks_incomplete_blocker_count"
        ]
        == 1
    )
    assert (
        failure_summary[
            "gpu_smoke_release_gate_required_checks_failed_blocker_count"
        ]
        == 1
    )
    assert (
        failure_summary[
            "gpu_smoke_release_gate_simulated_parity_failure_blocker_count"
        ]
        == 1
    )
    assert "simulated_parity_failure" in failure_summary["notes"]
    assert "gpu_smoke_failed_check_names=check_0" in failure_summary["notes"]

    payload = imgui_analysis_payload_from_acceptance_reports(
        [success, no_cuda, failure]
    )

    assert payload["analysis_summary_count"] == 3
    assert payload["analysis_accepted_summary_count"] == 2
    assert payload["analysis_failed_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 4
    assert payload["analysis_passed_check_count"] == 3
    assert payload["analysis_failed_check_count"] == 1
    assert payload["analysis_gpu_smoke_parity_result_count"] == 1
    assert payload["analysis_gpu_smoke_unavailable_boundary_count"] == 1
    assert payload["analysis_gpu_smoke_parity_failure_count"] == 1
    assert payload["analysis_gpu_smoke_required_capability_count"] == 9
    assert payload["analysis_gpu_smoke_required_capability_name_count"] == 9
    assert payload["analysis_gpu_smoke_parity_check_count"] == 4
    assert payload["analysis_gpu_smoke_failed_check_name_count"] == 1
    assert payload["analysis_gpu_smoke_runtime_observed_count"] == 1
    assert payload["analysis_gpu_smoke_dispatch_parity_claimed_count"] == 1
    assert payload["analysis_gpu_smoke_no_cuda_boundary_count"] == 1
    assert payload["analysis_gpu_smoke_simulated_parity_failure_count"] == 1
    assert (
        payload[
            "analysis_gpu_smoke_release_gate_gpu_backend_unavailable_blocker_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_gpu_smoke_release_gate_cuda_runtime_not_observed_blocker_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_gpu_smoke_release_gate_required_checks_incomplete_blocker_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_gpu_smoke_release_gate_required_checks_failed_blocker_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_gpu_smoke_release_gate_forced_unavailable_blocker_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_gpu_smoke_release_gate_simulated_parity_failure_blocker_count"
        ]
        == 1
    )
    assert payload["analysis_gpu_smoke_cuda_parity_claimed_count"] == 0
    assert payload["analysis_gpu_smoke_release_grade_speedup_claimed_count"] == 0
    json.dumps(payload, allow_nan=False)

    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[success, no_cuda, failure],
    )
    assert host_payload["method"] == "imgui_host_payload"
    host_analysis = host_payload["analysis"]
    assert host_analysis["analysis_summary_count"] == 3
    assert host_analysis["analysis_gpu_smoke_unavailable_boundary_count"] == 1
    assert host_analysis["analysis_gpu_smoke_parity_failure_count"] == 1
    assert host_analysis["analysis_gpu_smoke_no_cuda_boundary_count"] == 1
    assert host_analysis["analysis_gpu_smoke_simulated_parity_failure_count"] == 1
    assert host_analysis["analysis_gpu_smoke_required_capability_name_count"] == 9
    assert host_analysis["analysis_gpu_smoke_failed_check_name_count"] == 1
    assert (
        host_analysis[
            "analysis_gpu_smoke_release_gate_required_checks_incomplete_blocker_count"
        ]
        == 2
    )
    assert (
        host_analysis[
            "analysis_gpu_smoke_release_gate_forced_unavailable_blocker_count"
        ]
        == 0
    )
    assert host_analysis["analysis_gpu_smoke_cuda_parity_claimed_count"] == 0
    assert (
        host_analysis["analysis_gpu_smoke_release_grade_speedup_claimed_count"]
        == 0
    )
    host_summaries = {
        summary["source_method"]: summary
        for summary in host_analysis["analysis_summaries"]
    }
    assert host_summaries["gpu_smoke_unavailable_boundary"][
        "gpu_smoke_no_cuda_boundary"
    ] is True
    assert host_summaries["gpu_smoke_parity_failure"][
        "gpu_smoke_simulated_parity_failure"
    ] is True
    assert (
        host_summaries["gpu_smoke_parity_failure"][
            "gpu_smoke_failed_check_names"
        ]
        == "check_0"
    )
    assert host_payload["invariants"]["invariant_status_count"] == 0
    json.dumps(host_payload, allow_nan=False)


def test_imgui_analysis_summary_wraps_imgui_framebuffer_smoke_artifact() -> None:
    report = {
        "artifact_schema_version": 1,
        "artifact_kind": "imgui_test_stub_framebuffer_smoke",
        "claim_scope": "repository_imgui_test_stub_draw_list_framebuffer_estimate",
        "real_graphics_backend_framebuffer_verified": False,
        "screenshot_verified": False,
        "imgui_abi_version": 117,
        "rust_c_abi_version": 19,
        "render_frame_count": 1,
        "last_render_geometry_nonempty": 1,
        "last_render_geometry_canvas_count": 2,
        "last_render_geometry_filled_rect_count": 2,
        "last_render_geometry_rect_count": 2,
        "last_render_geometry_polyline_count": 4,
        "last_render_geometry_marker_count": 2,
        "rect_filled_count": 2,
        "rect_count": 2,
        "polyline_count": 4,
        "circle_filled_count": 2,
        "text_count": 10,
        "framebuffer_touched": 1,
        "estimated_nonzero_pixels": 4096,
        "passed": True,
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["name"] == "Dear ImGui test-stub framebuffer smoke"
    assert summary["source_method"] == "imgui_test_stub_framebuffer_smoke"
    assert (
        summary["claim_scope"]
        == "repository_imgui_test_stub_draw_list_framebuffer_estimate"
    )
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 3
    assert summary["passed_check_count"] == 3
    assert summary["failed_check_count"] == 0
    assert summary["imgui_framebuffer_smoke_artifact_count"] == 1
    assert summary["imgui_framebuffer_smoke_passed_count"] == 1
    assert summary["imgui_framebuffer_smoke_real_backend_verified_count"] == 0
    assert summary["imgui_framebuffer_smoke_screenshot_verified_count"] == 0
    assert summary["imgui_framebuffer_smoke_framebuffer_touched_count"] == 1
    assert summary["imgui_framebuffer_smoke_estimated_nonzero_pixel_count"] == 4096
    assert summary["imgui_framebuffer_smoke_render_frame_count"] == 1
    assert summary["imgui_framebuffer_smoke_geometry_polyline_count"] == 4
    assert summary["imgui_framebuffer_smoke_text_count"] == 10
    assert summary["imgui_framebuffer_smoke_passed"] is True
    assert summary["imgui_framebuffer_smoke_real_backend_verified"] is False
    assert summary["imgui_framebuffer_smoke_screenshot_verified"] is False
    assert "repository_test_stub=true" in summary["notes"]
    assert "draw_list_framebuffer_estimate=true" in summary["notes"]
    assert "real_graphics_backend_framebuffer_verified=false" in summary["notes"]
    assert "screenshot_verified=false" in summary["notes"]
    assert "production_renderer_verified=false" in summary["notes"]
    assert "not production renderer screenshot/framebuffer evidence" in (
        summary["notes"]
    )

    assert payload["analysis_imgui_framebuffer_smoke_artifact_count"] == 1
    assert payload["analysis_imgui_framebuffer_smoke_passed_count"] == 1
    assert payload[
        "analysis_imgui_framebuffer_smoke_real_backend_verified_count"
    ] == 0
    assert payload["analysis_imgui_framebuffer_smoke_screenshot_verified_count"] == 0
    assert payload[
        "analysis_imgui_framebuffer_smoke_estimated_nonzero_pixel_count"
    ] == 4096
    assert payload["analysis_imgui_framebuffer_smoke_text_count"] == 10
    host_analysis = host_payload["analysis"]
    assert host_analysis["analysis_imgui_framebuffer_smoke_artifact_count"] == 1
    assert host_analysis["analysis_imgui_framebuffer_smoke_passed_count"] == 1
    assert (
        host_analysis[
            "analysis_imgui_framebuffer_smoke_real_backend_verified_count"
        ]
        == 0
    )
    assert host_payload["invariants"]["invariant_status_count"] == 0
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_analysis_summary_accepts_production_framebuffer_pack() -> None:
    report = {
        "artifact_schema_version": 1,
        "artifact_kind": "imgui_production_renderer_framebuffer_pack",
        "claim_scope": "production_imgui_renderer_framebuffer_verification",
        "real_graphics_backend_framebuffer_verified": True,
        "screenshot_verified": True,
        "imgui_abi_version": 117,
        "rust_c_abi_version": 19,
        "render_frame_count": 2,
        "last_render_geometry_nonempty": 1,
        "last_render_geometry_canvas_count": 2,
        "last_render_geometry_filled_rect_count": 2,
        "last_render_geometry_rect_count": 2,
        "last_render_geometry_polyline_count": 4,
        "last_render_geometry_marker_count": 2,
        "rect_filled_count": 2,
        "rect_count": 2,
        "polyline_count": 4,
        "circle_filled_count": 2,
        "text_count": 10,
        "framebuffer_touched": 1,
        "estimated_nonzero_pixels": 8192,
        "passed": True,
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["name"] == "Dear ImGui production renderer framebuffer pack"
    assert summary["source_method"] == "imgui_production_renderer_framebuffer_pack"
    assert summary["accepted"] is True
    assert summary["certified"] is True
    assert summary["required_check_count"] == 5
    assert summary["passed_check_count"] == 5
    assert summary["failed_check_count"] == 0
    assert (
        summary["certification_scope"]
        == "production_imgui_renderer_framebuffer_verification"
    )
    assert summary["certification_applicable_count"] == 1
    assert summary["certification_certified_count"] == 1
    assert summary["certification_uncertified_count"] == 0
    assert summary["imgui_framebuffer_smoke_real_backend_verified"] is True
    assert summary["imgui_framebuffer_smoke_screenshot_verified"] is True
    assert summary["imgui_framebuffer_smoke_framebuffer_touched"] is True
    assert "repository_test_stub=false" in summary["notes"]
    assert "draw_list_framebuffer_estimate=false" in summary["notes"]
    assert "real_graphics_backend_framebuffer_verified=true" in summary["notes"]
    assert "screenshot_verified=true" in summary["notes"]
    assert "production_renderer_verified=true" in summary["notes"]
    assert "production renderer screenshot/framebuffer verification artifact" in (
        summary["notes"]
    )

    assert payload["analysis_imgui_framebuffer_smoke_artifact_count"] == 1
    assert payload["analysis_imgui_framebuffer_smoke_passed_count"] == 1
    assert (
        payload["analysis_imgui_framebuffer_smoke_real_backend_verified_count"]
        == 1
    )
    assert payload["analysis_imgui_framebuffer_smoke_screenshot_verified_count"] == 1
    assert payload["analysis_certification_certified_count"] == 1
    host_analysis = host_payload["analysis"]
    assert (
        host_analysis[
            "analysis_imgui_framebuffer_smoke_real_backend_verified_count"
        ]
        == 1
    )
    assert host_analysis["analysis_certification_certified_count"] == 1
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_analysis_summary_wraps_imgui_source_open_request_smoke_artifact() -> None:
    report = {
        "artifact_schema_version": 1,
        "artifact_kind": "imgui_source_open_request_smoke",
        "claim_scope": "host_polled_source_open_request_contract",
        "host_action": "open_source_url",
        "opened_by_real_host": False,
        "scheme_allowed": True,
        "selected_fixture": 0,
        "selected_fixture_name": "3_1",
        "selected_fixture_source": "Knot Atlas",
        "source_url": "https://katlas.org/wiki/3_1",
        "consumed_source_url": "https://katlas.org/wiki/3_1",
        "request_consumed_by_smoke": True,
        "request_cleared_after_consumption": True,
        "final_request_pending": True,
        "selected_fixture_source_url_length": 27,
        "requested_fixture_source_url_length": 27,
        "imgui_abi_version": 117,
        "rust_c_abi_version": 19,
        "passed": True,
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["name"] == "Dear ImGui source open request smoke"
    assert summary["source_method"] == "imgui_source_open_request_smoke"
    assert summary["claim_scope"] == "host_polled_source_open_request_contract"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 4
    assert summary["passed_check_count"] == 4
    assert summary["failed_check_count"] == 0
    assert summary["imgui_source_open_request_smoke_artifact_count"] == 1
    assert summary["imgui_source_open_request_smoke_passed_count"] == 1
    assert summary["imgui_source_open_request_smoke_opened_by_real_host_count"] == 0
    assert summary["imgui_source_open_request_smoke_scheme_allowed_count"] == 1
    assert summary["imgui_source_open_request_smoke_request_consumed_count"] == 1
    assert summary["imgui_source_open_request_smoke_request_cleared_count"] == 1
    assert summary["imgui_source_open_request_smoke_final_pending_count"] == 1
    assert summary["imgui_source_open_request_smoke_source_url_length_total"] == 27
    assert summary["imgui_source_open_request_smoke_passed"] is True
    assert summary["imgui_source_open_request_smoke_opened_by_real_host"] is False
    assert summary["imgui_source_open_request_smoke_scheme_allowed"] is True
    assert summary["imgui_source_open_request_smoke_request_consumed"] is True
    assert summary["imgui_source_open_request_smoke_request_cleared"] is True
    assert summary["imgui_source_open_request_smoke_final_pending"] is True
    assert (
        summary["imgui_source_open_request_smoke_host_action"]
        == "open_source_url"
    )
    assert summary["imgui_source_open_request_smoke_selected_fixture_name"] == "3_1"
    assert (
        summary["imgui_source_open_request_smoke_selected_fixture_source"]
        == "Knot Atlas"
    )
    assert (
        summary["imgui_source_open_request_smoke_source_url"]
        == "https://katlas.org/wiki/3_1"
    )
    assert (
        summary["imgui_source_open_request_smoke_consumed_source_url"]
        == "https://katlas.org/wiki/3_1"
    )
    assert (
        summary["imgui_source_open_request_smoke_consumed_source_url_matched"]
        is True
    )
    assert "host_action=open_source_url" in summary["notes"]
    assert "opened_by_real_host=false" in summary["notes"]
    assert "scheme_allowed=true" in summary["notes"]
    assert "request_consumed_by_smoke=true" in summary["notes"]
    assert "request_cleared_after_consumption=true" in summary["notes"]
    assert "final_request_pending=true" in summary["notes"]
    assert "not production platform URL-opening evidence" in summary["notes"]

    assert payload["analysis_imgui_source_open_request_smoke_artifact_count"] == 1
    assert payload["analysis_imgui_source_open_request_smoke_passed_count"] == 1
    assert (
        payload["analysis_imgui_source_open_request_smoke_opened_by_real_host_count"]
        == 0
    )
    assert (
        payload["analysis_imgui_source_open_request_smoke_scheme_allowed_count"]
        == 1
    )
    assert (
        payload["analysis_imgui_source_open_request_smoke_request_consumed_count"]
        == 1
    )
    assert (
        payload["analysis_imgui_source_open_request_smoke_source_url_length_total"]
        == 27
    )
    host_analysis = host_payload["analysis"]
    assert host_analysis["analysis_imgui_source_open_request_smoke_artifact_count"] == 1
    assert (
        host_analysis[
            "analysis_imgui_source_open_request_smoke_opened_by_real_host_count"
        ]
        == 0
    )
    assert (
        host_analysis[
            "analysis_imgui_source_open_request_smoke_request_cleared_count"
        ]
        == 1
    )
    assert (
        host_analysis["analysis_imgui_source_open_request_smoke_final_pending_count"]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_source_open_request_smoke_source_url_length_total"
        ]
        == 27
    )
    host_summary = host_analysis["analysis_summaries"][0]
    assert (
        host_summary["imgui_source_open_request_smoke_opened_by_real_host"]
        is False
    )
    assert (
        host_summary["imgui_source_open_request_smoke_host_action"]
        == "open_source_url"
    )
    assert (
        host_summary["imgui_source_open_request_smoke_selected_fixture_name"]
        == "3_1"
    )
    assert (
        host_summary["imgui_source_open_request_smoke_source_url"]
        == "https://katlas.org/wiki/3_1"
    )
    assert (
        host_summary["imgui_source_open_request_smoke_consumed_source_url_matched"]
        is True
    )
    assert host_summary["imgui_source_open_request_smoke_request_cleared"] is True
    assert host_summary["imgui_source_open_request_smoke_final_pending"] is True
    assert (
        host_summary["imgui_source_open_request_smoke_source_url_length_total"]
        == 27
    )
    assert "opened_by_real_host=false" in host_summary["notes"]
    assert "request_cleared_after_consumption=true" in host_summary["notes"]
    assert "final_request_pending=true" in host_summary["notes"]
    assert host_payload["invariants"]["invariant_status_count"] == 0
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_analysis_summary_wraps_imgui_signed_pd_snapshot_artifact() -> None:
    report = {
        "method": "imgui_signed_pd_snapshot",
        "component_count": 2,
        "signed_pd_revision": 42,
        "valid": True,
        "validation": {
            "crossing_count": 2,
            "component_count": 2,
            "edge_label_slot_count": 8,
            "unique_edge_label_count": 4,
            "nonpositive_edge_label_count": 0,
            "labels_with_unexpected_occurrence_count": 0,
            "labels_with_invalid_flow_count": 0,
            "explicit_role_order_count": 2,
            "invalid_role_order_count": 0,
            "oriented_component_count": 2,
            "component_count_matches": True,
            "valid": True,
        },
        "crossings": [
            {
                "edge_labels": [4, 1, 2, 3],
                "sign": 1,
                "role_order": [1, 0, 2, 3],
                "role_order_explicit": True,
            },
            {
                "edge_labels": [2, 3, 4, 1],
                "sign": -1,
                "role_order": [1, 0, 2, 3],
                "role_order_explicit": True,
            },
        ],
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["name"] == "Dear ImGui signed-PD snapshot"
    assert summary["source_method"] == "imgui_signed_pd_snapshot"
    assert summary["claim_scope"] == "host_exported_imgui_signed_pd_snapshot_shape"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 6
    assert summary["passed_check_count"] == 6
    assert summary["failed_check_count"] == 0
    assert summary["has_source_signed_pd_revision"] is True
    assert summary["source_signed_pd_revision"] == 42
    assert summary["imgui_signed_pd_snapshot_artifact_count"] == 1
    assert summary["imgui_signed_pd_snapshot_valid_count"] == 1
    assert summary["imgui_signed_pd_snapshot_validation_available_count"] == 1
    assert summary["imgui_signed_pd_snapshot_component_count_matches_count"] == 1
    assert summary["imgui_signed_pd_snapshot_revision_present_count"] == 1
    assert summary["imgui_signed_pd_snapshot_crossing_count_total"] == 2
    assert summary["imgui_signed_pd_snapshot_component_count_total"] == 2
    assert summary["imgui_signed_pd_snapshot_edge_label_slot_count_total"] == 8
    assert summary["imgui_signed_pd_snapshot_unique_edge_label_count_total"] == 4
    assert summary["imgui_signed_pd_snapshot_explicit_role_order_count_total"] == 2
    assert summary["imgui_signed_pd_snapshot_invalid_role_order_count_total"] == 0
    assert summary["imgui_signed_pd_snapshot_invalid_flow_label_count_total"] == 0
    assert summary["imgui_signed_pd_snapshot_valid"] is True
    assert summary["imgui_signed_pd_snapshot_validation_available"] is True
    assert summary["imgui_signed_pd_snapshot_component_count_matches"] is True
    assert summary["imgui_signed_pd_snapshot_revision_present"] is True
    assert "component_count=2" in summary["notes"]
    assert "crossings=2" in summary["notes"]
    assert "component_count_matches=true" in summary["notes"]
    assert "invalid_role_order_count=0" in summary["notes"]
    assert "labels_with_invalid_flow_count=0" in summary["notes"]
    assert "not invariant computation evidence" in summary["notes"]
    assert "signed_pd_revision=42" in summary["notes"]

    assert payload["analysis_imgui_signed_pd_snapshot_artifact_count"] == 1
    assert payload["analysis_imgui_signed_pd_snapshot_valid_count"] == 1
    assert (
        payload["analysis_imgui_signed_pd_snapshot_component_count_matches_count"]
        == 1
    )
    assert payload["analysis_imgui_signed_pd_snapshot_crossing_count_total"] == 2
    assert payload["analysis_imgui_signed_pd_snapshot_component_count_total"] == 2
    assert payload["source_signed_pd_revision"] == 42
    host_analysis = host_payload["analysis"]
    assert host_analysis["analysis_imgui_signed_pd_snapshot_artifact_count"] == 1
    assert host_analysis["analysis_imgui_signed_pd_snapshot_valid_count"] == 1
    assert (
        host_analysis["analysis_imgui_signed_pd_snapshot_explicit_role_order_count_total"]
        == 2
    )
    assert host_payload["invariants"]["invariant_status_count"] == 0
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_analysis_summary_wraps_imgui_signed_pd_recompute_scheduler_smoke_artifact() -> None:
    report = {
        "artifact_schema_version": 1,
        "artifact_kind": "imgui_signed_pd_recompute_scheduler_smoke",
        "claim_scope": "host_owned_signed_pd_recompute_scheduler_contract",
        "imgui_abi_version": 117,
        "rust_c_abi_version": 19,
        "handoff_input_format": "imgui_signed_pd_json",
        "handoff_result_transport": "json_file",
        "homfly_cli_command": "iroll homfly-pd",
        "alexander_cli_command": "iroll multivariable-alexander-pd",
        "host_reload_payload": "imgui-signed-pd-invariant-status-payload",
        "first_revision": 1,
        "second_revision": 2,
        "first_scope": "all",
        "first_request_revision": 1,
        "first_request_snapshot_json_length": 120,
        "first_request_snapshot_fnv1a64": 11,
        "first_result_count": 2,
        "first_revision_reloaded": True,
        "stale_scope": "all",
        "stale_request_revision": 1,
        "stale_request_snapshot_json_length": 121,
        "stale_request_snapshot_fnv1a64": 12,
        "pending_request_stale": True,
        "stale_result_count": 2,
        "stale_recompute_rejected": True,
        "stale_results_rejected": True,
        "stale_error_mentions_revision_mismatch": True,
        "current_scope": "homfly",
        "current_request_revision": 2,
        "current_request_snapshot_json_length": 122,
        "current_request_snapshot_fnv1a64": 13,
        "current_result_count": 1,
        "current_revision_rows_reloaded": True,
        "current_revision_reloaded": True,
        "final_invariant_status_count": 1,
        "final_invariant_status_signed_pd_revision": 2,
        "final_signed_pd_invariant_status_stale": False,
        "final_requested_recompute_revision": 2,
        "final_requested_recompute_stale": False,
        "requested_snapshot_json_cleared": True,
        "host_queue_drained": True,
        "passed": True,
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["name"] == "Dear ImGui signed-PD recompute scheduler smoke"
    assert summary["source_method"] == "imgui_signed_pd_recompute_scheduler_smoke"
    assert summary["claim_scope"] == "host_owned_signed_pd_recompute_scheduler_contract"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 11
    assert summary["passed_check_count"] == 11
    assert summary["failed_check_count"] == 0
    assert summary["imgui_signed_pd_recompute_scheduler_smoke_artifact_count"] == 1
    assert summary["imgui_signed_pd_recompute_scheduler_smoke_passed_count"] == 1
    assert (
        summary[
            "imgui_signed_pd_recompute_scheduler_smoke_stale_recompute_rejected_count"
        ]
        == 1
    )
    assert (
        summary[
            "imgui_signed_pd_recompute_scheduler_smoke_stale_results_rejected_count"
        ]
        == 1
    )
    assert (
        summary[
            "imgui_signed_pd_recompute_scheduler_smoke_stale_error_revision_mismatch_count"
        ]
        == 1
    )
    assert (
        summary[
            "imgui_signed_pd_recompute_scheduler_smoke_current_revision_reloaded_count"
        ]
        == 1
    )
    assert (
        summary[
            "imgui_signed_pd_recompute_scheduler_smoke_current_revision_rows_reloaded_count"
        ]
        == 1
    )
    assert (
        summary[
            "imgui_signed_pd_recompute_scheduler_smoke_requested_snapshot_cleared_count"
        ]
        == 1
    )
    assert summary["imgui_signed_pd_recompute_scheduler_smoke_abi_matched_count"] == 1
    assert (
        summary["imgui_signed_pd_recompute_scheduler_smoke_handoff_complete_count"]
        == 1
    )
    assert (
        summary[
            "imgui_signed_pd_recompute_scheduler_smoke_snapshot_hash_present_count"
        ]
        == 1
    )
    assert (
        summary["imgui_signed_pd_recompute_scheduler_smoke_final_status_fresh_count"]
        == 1
    )
    assert (
        summary[
            "imgui_signed_pd_recompute_scheduler_smoke_snapshot_json_length_total"
        ]
        == 363
    )
    assert summary["imgui_signed_pd_recompute_scheduler_smoke_first_result_count_total"] == 2
    assert summary["imgui_signed_pd_recompute_scheduler_smoke_stale_result_count_total"] == 2
    assert summary["imgui_signed_pd_recompute_scheduler_smoke_current_result_count_total"] == 1
    assert summary["imgui_signed_pd_recompute_scheduler_smoke_passed"] is True
    assert (
        summary[
            "imgui_signed_pd_recompute_scheduler_smoke_stale_recompute_rejected"
        ]
        is True
    )
    assert (
        summary[
            "imgui_signed_pd_recompute_scheduler_smoke_current_revision_reloaded"
        ]
        is True
    )
    assert (
        summary[
            "imgui_signed_pd_recompute_scheduler_smoke_final_status_fresh"
        ]
        is True
    )
    assert summary["imgui_signed_pd_recompute_scheduler_smoke_first_scope"] == "all"
    assert summary["imgui_signed_pd_recompute_scheduler_smoke_stale_scope"] == "all"
    assert (
        summary["imgui_signed_pd_recompute_scheduler_smoke_current_scope"]
        == "homfly"
    )
    assert (
        summary[
            "imgui_signed_pd_recompute_scheduler_smoke_handoff_input_format"
        ]
        == "imgui_signed_pd_json"
    )
    assert (
        summary["imgui_signed_pd_recompute_scheduler_smoke_host_reload_payload"]
        == "imgui-signed-pd-invariant-status-payload"
    )
    assert summary["imgui_signed_pd_recompute_scheduler_smoke_first_revision"] == 1
    assert summary["imgui_signed_pd_recompute_scheduler_smoke_second_revision"] == 2
    assert (
        summary[
            "imgui_signed_pd_recompute_scheduler_smoke_current_request_revision"
        ]
        == 2
    )
    assert (
        summary[
            "imgui_signed_pd_recompute_scheduler_smoke_final_invariant_status_signed_pd_revision"
        ]
        == 2
    )
    assert "first_scope=all" in summary["notes"]
    assert "stale_scope=all" in summary["notes"]
    assert "current_scope=homfly" in summary["notes"]
    assert "stale_recompute_rejected=true" in summary["notes"]
    assert "current_revision_reloaded=true" in summary["notes"]
    assert "requested_snapshot_json_cleared=true" in summary["notes"]
    assert "host_queue_drained=true" in summary["notes"]
    assert "handoff_input_format=imgui_signed_pd_json" in summary["notes"]
    assert "handoff_result_transport=json_file" in summary["notes"]
    assert (
        "host_reload_payload=imgui-signed-pd-invariant-status-payload"
        in summary["notes"]
    )
    assert "native_homfly_cpp_computation_claimed=false" in summary["notes"]
    assert "production_scheduler_completion_claimed=false" in summary["notes"]
    assert "not native HOMFLY/Alexander C++ computation evidence" in summary["notes"]

    assert (
        payload["analysis_imgui_signed_pd_recompute_scheduler_smoke_artifact_count"]
        == 1
    )
    assert (
        payload["analysis_imgui_signed_pd_recompute_scheduler_smoke_passed_count"]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_stale_recompute_rejected_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_stale_results_rejected_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_stale_error_revision_mismatch_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_current_revision_reloaded_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_first_result_count_total"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_stale_result_count_total"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_snapshot_json_length_total"
        ]
        == 363
    )
    host_analysis = host_payload["analysis"]
    assert (
        host_analysis[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_artifact_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_current_result_count_total"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_stale_results_rejected_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_stale_error_revision_mismatch_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_stale_result_count_total"
        ]
        == 2
    )
    assert host_payload["invariants"]["invariant_status_count"] == 0
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_analysis_summary_wraps_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact() -> None:
    report = {
        "artifact_schema_version": 1,
        "artifact_kind": "imgui_signed_pd_thread_pool_recompute_scheduler_smoke",
        "claim_scope": "host_owned_thread_pool_signed_pd_recompute_scheduler_contract",
        "imgui_abi_version": 117,
        "rust_c_abi_version": 19,
        "handoff_input_format": "imgui_signed_pd_json",
        "handoff_result_transport": "json_file",
        "homfly_cli_command": "iroll homfly-pd",
        "alexander_cli_command": "iroll multivariable-alexander-pd",
        "host_reload_payload": "imgui-signed-pd-invariant-status-payload",
        "first_revision": 1,
        "second_revision": 2,
        "current_loaded_revision": 2,
        "stale_scope": "all",
        "stale_request_scope": "all",
        "stale_request_revision": 1,
        "stale_request_snapshot_json_length": 110,
        "stale_request_snapshot_fnv1a64": 21,
        "stale_request_queued": True,
        "stale_request_started": True,
        "stale_request_completed": True,
        "stale_result_count": 2,
        "stale_recompute_rejected": True,
        "stale_result_rejected": True,
        "current_scope": "alexander",
        "current_request_scope": "alexander",
        "current_request_revision": 2,
        "current_request_snapshot_json_length": 111,
        "current_request_snapshot_fnv1a64": 22,
        "current_request_queued": True,
        "current_request_started": True,
        "current_request_completed": True,
        "current_result_count": 1,
        "current_revision_reloaded": True,
        "requested_snapshot_json_cleared": True,
        "progress_completed": True,
        "progress_active_after_completion": False,
        "final_invariant_status_count": 1,
        "final_invariant_status_signed_pd_revision": 2,
        "final_signed_pd_invariant_status_stale": False,
        "final_requested_recompute_revision": 0,
        "final_requested_recompute_stale": False,
        "thread_pool_worker_count": 2,
        "passed": True,
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["name"] == (
        "Dear ImGui signed-PD thread-pool recompute scheduler smoke"
    )
    assert summary["source_method"] == (
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke"
    )
    assert summary["claim_scope"] == (
        "host_owned_thread_pool_signed_pd_recompute_scheduler_contract"
    )
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 16
    assert summary["passed_check_count"] == 16
    assert summary["failed_check_count"] == 0
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact_count"
        ]
        == 1
    )
    assert (
        summary["imgui_signed_pd_thread_pool_recompute_scheduler_smoke_passed_count"]
        == 1
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_recompute_rejected_count"
        ]
        == 1
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_result_rejected_count"
        ]
        == 1
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_revision_reloaded_count"
        ]
        == 1
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_handoff_complete_count"
        ]
        == 1
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_thread_pool_worker_count_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_request_lifecycle_complete_count"
        ]
        == 1
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_request_lifecycle_complete_count"
        ]
        == 1
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_snapshot_json_length_total"
        ]
        == 221
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_worker_count_total"
        ]
        == 2
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_result_count_total"
        ]
        == 2
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_final_status_fresh"
        ]
        is True
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_scope"
        ]
        == "all"
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_scope"
        ]
        == "alexander"
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_request_scope"
        ]
        == "alexander"
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_handoff_input_format"
        ]
        == "imgui_signed_pd_json"
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_host_reload_payload"
        ]
        == "imgui-signed-pd-invariant-status-payload"
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_loaded_revision"
        ]
        == 2
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_request_revision"
        ]
        == 2
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_final_invariant_status_signed_pd_revision"
        ]
        == 2
    )
    assert "thread_pool_worker_count=2" in summary["notes"]
    assert "stale_recompute_rejected=true" in summary["notes"]
    assert "current_revision_reloaded=true" in summary["notes"]
    assert "progress_completed=true" in summary["notes"]
    assert "progress_active_after_completion=false" in summary["notes"]
    assert "handoff_input_format=imgui_signed_pd_json" in summary["notes"]
    assert "not native HOMFLY/Alexander C++ computation evidence" in summary["notes"]

    assert (
        payload[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_passed_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_recompute_rejected_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_result_rejected_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_request_lifecycle_complete_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_request_lifecycle_complete_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_result_count_total"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_result_count_total"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_snapshot_json_length_total"
        ]
        == 221
    )
    host_analysis = host_payload["analysis"]
    assert (
        host_analysis[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_recompute_rejected_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_result_rejected_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_request_lifecycle_complete_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_request_lifecycle_complete_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_result_count_total"
        ]
        == 2
    )
    host_summary = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }["imgui_signed_pd_thread_pool_recompute_scheduler_smoke"]
    assert (
        host_summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_request_scope"
        ]
        == "alexander"
    )
    assert (
        host_summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_host_reload_payload"
        ]
        == "imgui-signed-pd-invariant-status-payload"
    )
    assert host_payload["invariants"]["invariant_status_count"] == 0
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def _imgui_windows_retained_artifact_groups() -> list[dict[str, object]]:
    return [
        {
            "name": "test_stub_framebuffer",
            "classification": "complete_raw_analysis_host",
            "uploaded_artifact": "iroll-imgui-test-stub-framebuffer-smoke-Windows",
            "raw_files": ["iroll-imgui-test-stub-framebuffer-smoke.json"],
            "analysis_files": [
                "iroll-imgui-test-stub-framebuffer-smoke-imgui-analysis.json"
            ],
            "host_files": ["iroll-imgui-test-stub-framebuffer-smoke-imgui-host.json"],
            "claim_scope": "repository_imgui_test_stub_draw_list_framebuffer_estimate",
        },
        {
            "name": "source_open_request",
            "classification": "complete_raw_analysis_host",
            "uploaded_artifact": "iroll-imgui-test-stub-framebuffer-smoke-Windows",
            "raw_files": ["iroll-imgui-source-open-request-smoke.json"],
            "analysis_files": [
                "iroll-imgui-source-open-request-smoke-imgui-analysis.json"
            ],
            "host_files": ["iroll-imgui-source-open-request-smoke-imgui-host.json"],
            "claim_scope": "host_polled_source_open_request_contract",
        },
        {
            "name": "signed_pd_recompute_scheduler",
            "classification": "complete_raw_analysis_host",
            "uploaded_artifact": "iroll-imgui-signed-pd-json-Windows",
            "raw_files": ["iroll-imgui-signed-pd-recompute-scheduler-smoke.json"],
            "analysis_files": [
                "iroll-imgui-signed-pd-recompute-scheduler-smoke-imgui-analysis.json"
            ],
            "host_files": [
                "iroll-imgui-signed-pd-recompute-scheduler-smoke-imgui-host.json"
            ],
            "claim_scope": "host_owned_signed_pd_recompute_scheduler_contract",
        },
        {
            "name": "signed_pd_thread_pool_recompute_scheduler",
            "classification": "complete_raw_analysis_host",
            "uploaded_artifact": "iroll-imgui-signed-pd-json-Windows",
            "raw_files": [
                "iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke.json"
            ],
            "analysis_files": [
                "iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke-imgui-analysis.json"
            ],
            "host_files": [
                "iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke-imgui-host.json"
            ],
            "claim_scope": "host_owned_thread_pool_signed_pd_recompute_scheduler_contract",
        },
        {
            "name": "signed_pd_snapshot",
            "classification": "complete_raw_analysis_host",
            "uploaded_artifact": "iroll-imgui-signed-pd-json-Windows",
            "raw_files": ["iroll-imgui-signed-pd.json"],
            "analysis_files": ["iroll-imgui-signed-pd-imgui-analysis.json"],
            "host_files": ["iroll-imgui-signed-pd-snapshot-imgui-host.json"],
            "claim_scope": "host_exported_imgui_signed_pd_snapshot_shape",
        },
        {
            "name": "signed_pd_invariant_reload",
            "classification": "invariant_status_host_only",
            "uploaded_artifact": "iroll-imgui-signed-pd-json-Windows",
            "raw_files": [
                "iroll-imgui-signed-pd.json",
                "iroll-imgui-signed-pd-homfly.json",
                "iroll-imgui-signed-pd-alexander.json",
            ],
            "invariant_status_files": ["iroll-imgui-signed-pd-invariant-status.json"],
            "host_files": ["iroll-imgui-signed-pd-imgui-host.json"],
            "claim_scope": "file_oriented_signed_pd_invariant_reload",
        },
        {
            "name": "real_kernel_loader_smoke",
            "classification": "complete_raw_analysis_host",
            "uploaded_artifact": "iroll-imgui-real-kernel-loader-smoke-Windows",
            "raw_files": ["iroll-imgui-real-kernel-loader-smoke.json"],
            "analysis_files": [
                "iroll-imgui-real-kernel-loader-smoke-imgui-analysis.json"
            ],
            "host_files": ["iroll-imgui-real-kernel-loader-smoke-imgui-host.json"],
            "claim_scope": "runtime_loader_real_rust_dynamic_library_contract",
        },
    ]


def _imgui_windows_retained_artifacts_manifest_report(
    *,
    retained_json_file_count: int = 22,
    non_claim_evidence_index: list[dict[str, object]] | None = None,
) -> dict:
    if non_claim_evidence_index is None:
        non_claim_evidence_index = [
            {
                "field": "production_renderer_verified",
                "value": False,
                "evidence_role": "retained_ci_artifact_only",
            },
            {
                "field": "production_scheduler_completion_claimed",
                "value": False,
                "evidence_role": "retained_ci_artifact_only",
            },
            {
                "field": "native_homfly_cpp_computation_claimed",
                "value": False,
                "evidence_role": "retained_ci_artifact_only",
            },
            {
                "field": "native_alexander_cpp_computation_claimed",
                "value": False,
                "evidence_role": "retained_ci_artifact_only",
            },
            {
                "field": "signed_release_artifacts_published",
                "value": False,
                "evidence_role": "retained_ci_artifact_only",
            },
        ]
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "imgui_windows_retained_artifacts_manifest",
        "claim_scope": "windows_dear_imgui_retained_artifact_manifest",
        "imgui_abi_version": 117,
        "rust_c_abi_version": 19,
        "retained_json_file_count": retained_json_file_count,
        "evidence_group_count": 7,
        "raw_analysis_host_group_count": 6,
        "invariant_status_host_group_count": 1,
        "smoke_executed_no_retained_json_count": 0,
        "production_renderer_verified": False,
        "production_scheduler_completion_claimed": False,
        "native_homfly_cpp_computation_claimed": False,
        "native_alexander_cpp_computation_claimed": False,
        "signed_release_artifacts_published": False,
        "non_claim_evidence_index": non_claim_evidence_index,
        "evidence_groups": _imgui_windows_retained_artifact_groups(),
    }


def test_imgui_analysis_summary_wraps_imgui_windows_retained_artifacts_manifest() -> None:
    report = _imgui_windows_retained_artifacts_manifest_report()

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["name"] == "Dear ImGui Windows retained artifacts manifest"
    assert summary["source_method"] == "imgui_windows_retained_artifacts_manifest"
    assert summary["claim_scope"] == "windows_dear_imgui_retained_artifact_manifest"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 9
    assert summary["passed_check_count"] == 9
    assert summary["failed_check_count"] == 0
    assert summary["imgui_windows_retained_artifacts_manifest_artifact_count"] == 1
    assert summary["imgui_windows_retained_artifacts_manifest_abi_matched_count"] == 1
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_evidence_group_count_total"
        ]
        == 7
    )
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_retained_json_file_count_total"
        ]
        == 22
    )
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_unique_retained_json_file_count_total"
        ]
        == 22
    )
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_retained_json_file_reference_count_total"
        ]
        == 23
    )
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_shared_retained_json_file_count_total"
        ]
        == 1
    )
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_retained_json_file_count_matched_count"
        ]
        == 1
    )
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_complete_raw_analysis_host_group_count_total"
        ]
        == 6
    )
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_invariant_status_host_group_count_total"
        ]
        == 1
    )
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_smoke_executed_no_retained_json_count_total"
        ]
        == 0
    )
    assert (
        summary["imgui_windows_retained_artifacts_manifest_non_claim_false_count"]
        == 5
    )
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 5
    )
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_production_renderer_verified_count"
        ]
        == 0
    )
    assert summary["imgui_windows_retained_artifacts_manifest_abi_matched"] is True
    assert (
        summary["imgui_windows_retained_artifacts_manifest_non_claims_preserved"]
        is True
    )
    assert "retained_json_files=22" in summary["notes"]
    assert "retained_json_file_references=23" in summary["notes"]
    assert "unique_retained_json_files=22" in summary["notes"]
    assert "shared_retained_json_files=1" in summary["notes"]
    assert (
        "imgui_windows_retained_artifacts_manifest_shared_files="
        "iroll-imgui-signed-pd.json"
    ) in summary["notes"]
    assert "retained_json_file_count_matched=true" in summary["notes"]
    assert "complete_raw_analysis_host_groups=6" in summary["notes"]
    assert "production_renderer_verified=false" in summary["notes"]
    assert "signed_release_artifacts_published=false" in summary["notes"]
    assert "non_claim_evidence_index_entries=5" in summary["notes"]
    assert "not release completion evidence" in summary["notes"]

    assert (
        payload["analysis_imgui_windows_retained_artifacts_manifest_artifact_count"]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_count_total"
        ]
        == 22
    )
    assert (
        payload[
            "analysis_imgui_windows_retained_artifacts_manifest_unique_retained_json_file_count_total"
        ]
        == 22
    )
    assert (
        payload[
            "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_reference_count_total"
        ]
        == 23
    )
    assert (
        payload[
            "analysis_imgui_windows_retained_artifacts_manifest_shared_retained_json_file_count_total"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_count_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 5
    )
    host_analysis = host_payload["analysis"]
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_artifact_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_reference_count_total"
        ]
        == 23
    )
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_shared_retained_json_file_count_total"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_complete_raw_analysis_host_group_count_total"
        ]
        == 6
    )
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_invariant_status_host_group_count_total"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_smoke_executed_no_retained_json_count_total"
        ]
        == 0
    )
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 5
    )
    host_summary = host_analysis["analysis_summaries"][0]
    assert "shared_retained_json_files=1" in host_summary["notes"]
    assert (
        "imgui_windows_retained_artifacts_manifest_shared_files="
        "iroll-imgui-signed-pd.json"
    ) in host_summary["notes"]
    assert "complete_raw_analysis_host_groups=6" in host_summary["notes"]
    assert "non_claim_evidence_index_entries=5" in host_summary["notes"]
    assert host_payload["invariants"]["invariant_status_count"] == 0
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_analysis_summary_preserves_imgui_windows_retained_artifacts_manifest_count_mismatch() -> None:
    report = _imgui_windows_retained_artifacts_manifest_report(
        retained_json_file_count=23,
    )

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["accepted"] is False
    assert summary["passed_check_count"] == 8
    assert summary["failed_check_count"] == 1
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_retained_json_file_count_total"
        ]
        == 23
    )
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_unique_retained_json_file_count_total"
        ]
        == 22
    )
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_retained_json_file_reference_count_total"
        ]
        == 23
    )
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_shared_retained_json_file_count_total"
        ]
        == 1
    )
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_retained_json_file_count_matched_count"
        ]
        == 0
    )
    assert "retained_json_files=23" in summary["notes"]
    assert "retained_json_file_references=23" in summary["notes"]
    assert "unique_retained_json_files=22" in summary["notes"]
    assert "shared_retained_json_files=1" in summary["notes"]
    assert "retained_json_file_count_matched=false" in summary["notes"]

    assert (
        payload[
            "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_count_total"
        ]
        == 23
    )
    assert (
        payload[
            "analysis_imgui_windows_retained_artifacts_manifest_unique_retained_json_file_count_total"
        ]
        == 22
    )
    assert (
        payload[
            "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_count_matched_count"
        ]
        == 0
    )
    host_analysis = host_payload["analysis"]
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_count_total"
        ]
        == 23
    )
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_count_matched_count"
        ]
        == 0
    )
    host_summary = host_analysis["analysis_summaries"][0]
    assert "retained_json_file_count_matched=false" in host_summary["notes"]
    assert "unique_retained_json_files=22" in host_summary["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_payloads_preserve_imgui_windows_retained_manifest_non_claim_index_mismatch() -> None:
    report = _imgui_windows_retained_artifacts_manifest_report(
        non_claim_evidence_index=[
            {
                "field": "production_renderer_verified",
                "value": False,
                "evidence_role": "retained_ci_artifact_only",
            },
            {
                "field": "production_scheduler_completion_claimed",
                "value": False,
                "evidence_role": "retained_ci_artifact_only",
            },
            {
                "field": "native_homfly_cpp_computation_claimed",
                "value": False,
                "evidence_role": "retained_ci_artifact_only",
            },
            {
                "field": "signed_release_artifacts_published",
                "value": False,
                "evidence_role": "retained_ci_artifact_only",
            },
        ],
    )

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["accepted"] is True
    assert (
        summary["imgui_windows_retained_artifacts_manifest_non_claim_false_count"]
        == 5
    )
    assert (
        summary[
            "imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 4
    )
    assert "non_claim_evidence_index_entries=4" in summary["notes"]

    assert (
        payload[
            "analysis_imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 4
    )
    host_analysis = host_payload["analysis"]
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 4
    )
    host_summary = host_analysis["analysis_summaries"][0]
    assert "non_claim_evidence_index_entries=4" in host_summary["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_analysis_summary_wraps_imgui_real_kernel_loader_smoke_artifact() -> None:
    report = {
        "artifact_schema_version": 1,
        "artifact_kind": "imgui_real_kernel_loader_smoke",
        "claim_scope": "runtime_loader_real_rust_dynamic_library_contract",
        "imgui_abi_version": 117,
        "rust_c_abi_version": 19,
        "kernel_loader_abi_version": 6,
        "passed": True,
        "dynamic_library_loaded": True,
        "api_attached_to_panel": True,
        "kernel_api_connected": True,
        "rust_kernel_available": True,
        "backend_report_bytes": 4096,
        "invariant_result_handles_report_bytes": 2048,
        "last_kernel_result_length": 512,
        "callback_thread_pool_completed": True,
        "worker_touches_imgui_context": False,
        "distance_progress_total": 3,
        "intersection_progress_total": 2,
        "distance_callback_count": 3,
        "intersection_callback_count": 2,
        "metadata_schema_version": 1,
        "metadata_contract_version": (
            "rust_c_abi_19_invariant_result_handles_lifecycle_metadata_v1"
        ),
        "required_metadata_field_count": 30,
        "required_metadata_fields_present": True,
        "readiness_provenance_present": True,
        "ready_for_native_result_handles": False,
        "readiness_blocked_by_required_gates": True,
        "native_result_handles_complete": False,
        "complete_result_handle_abi": False,
        "release_grade_result_handles": False,
        "python_file_recompute_boundary": True,
        "native_homfly_cpp_computation_claimed": False,
        "native_alexander_cpp_computation_claimed": False,
        "production_scheduler_completion_claimed": False,
        "signed_release_artifacts_published": False,
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "imgui_real_kernel_loader_smoke"
    assert summary["claim_scope"] == "runtime_loader_real_rust_dynamic_library_contract"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 11
    assert summary["passed_check_count"] == 11
    assert summary["failed_check_count"] == 0
    assert summary["imgui_real_kernel_loader_smoke_artifact_count"] == 1
    assert summary["imgui_real_kernel_loader_smoke_passed"] is True
    assert summary["imgui_real_kernel_loader_smoke_dynamic_library_loaded"] is True
    assert (
        summary["imgui_real_kernel_loader_smoke_callback_thread_pool_completed"]
        is True
    )
    assert summary["imgui_real_kernel_loader_smoke_non_claims_preserved"] is True
    assert summary["imgui_real_kernel_loader_smoke_metadata_schema_version"] == 1
    assert (
        summary["imgui_real_kernel_loader_smoke_metadata_contract_version"]
        == "rust_c_abi_19_invariant_result_handles_lifecycle_metadata_v1"
    )
    assert (
        summary["imgui_real_kernel_loader_smoke_required_metadata_fields_present"]
        is True
    )
    assert (
        summary["imgui_real_kernel_loader_smoke_readiness_provenance_present"]
        is True
    )
    assert (
        summary["imgui_real_kernel_loader_smoke_ready_for_native_result_handles"]
        is False
    )
    assert (
        summary[
            "imgui_real_kernel_loader_smoke_readiness_blocked_by_required_gates"
        ]
        is True
    )
    assert (
        summary["imgui_real_kernel_loader_smoke_python_file_recompute_boundary"]
        is True
    )
    assert summary["imgui_real_kernel_loader_smoke_backend_report_byte_count_total"] == 4096
    assert (
        summary[
            "imgui_real_kernel_loader_smoke_invariant_handles_report_byte_count_total"
        ]
        == 2048
    )
    assert summary["imgui_real_kernel_loader_smoke_required_metadata_field_count_total"] == 30
    assert "dynamic_library_loaded=true" in summary["notes"]
    assert "thread_pool_completed=true" in summary["notes"]
    assert "native_homfly_cpp_computation_claimed=false" in summary["notes"]
    assert "not native HOMFLY/Alexander C++ computation" in summary["notes"]

    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_imgui_real_kernel_loader_smoke_artifact_count"] == 1
    assert payload["analysis_imgui_real_kernel_loader_smoke_passed_count"] == 1
    assert (
        payload[
            "analysis_imgui_real_kernel_loader_smoke_callback_thread_pool_completed_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_real_kernel_loader_smoke_native_homfly_cpp_computation_claimed_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_imgui_real_kernel_loader_smoke_native_alexander_cpp_computation_claimed_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_imgui_real_kernel_loader_smoke_python_file_recompute_boundary_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_imgui_real_kernel_loader_smoke_non_claim_false_count"
        ]
        == 5
    )

    host_analysis = host_payload["analysis"]
    assert host_analysis["analysis_imgui_real_kernel_loader_smoke_artifact_count"] == 1
    assert (
        host_analysis[
            "analysis_imgui_real_kernel_loader_smoke_backend_report_byte_count_total"
        ]
        == 4096
    )
    assert (
        host_analysis[
            "analysis_imgui_real_kernel_loader_smoke_native_homfly_cpp_computation_claimed_count"
        ]
        == 0
    )
    assert (
        host_analysis[
            "analysis_imgui_real_kernel_loader_smoke_native_alexander_cpp_computation_claimed_count"
        ]
        == 0
    )
    assert (
        host_analysis[
            "analysis_imgui_real_kernel_loader_smoke_python_file_recompute_boundary_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_real_kernel_loader_smoke_non_claim_false_count"
        ]
        == 5
    )
    host_summary = host_analysis["analysis_summaries"][0]
    assert (
        host_summary["imgui_real_kernel_loader_smoke_metadata_contract_version"]
        == "rust_c_abi_19_invariant_result_handles_lifecycle_metadata_v1"
    )
    assert (
        host_summary[
            "imgui_real_kernel_loader_smoke_ready_for_native_result_handles"
        ]
        is False
    )
    assert (
        host_summary[
            "imgui_real_kernel_loader_smoke_readiness_blocked_by_required_gates"
        ]
        is True
    )
    assert (
        host_summary["imgui_real_kernel_loader_smoke_python_file_recompute_boundary"]
        is True
    )
    assert "native_homfly_cpp_computation_claimed=false" in host_summary["notes"]
    assert "not native HOMFLY/Alexander C++ computation" in host_summary["notes"]
    assert host_payload["invariants"]["invariant_status_count"] == 0
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_analysis_summary_wraps_rust_wheel_retained_manifest() -> None:
    report = {
        "artifact_schema_version": 1,
        "artifact_kind": "rust_wheel_retained_metadata_manifest",
        "claim_scope": "unsigned_ci_rust_wheel_artifact_index",
        "runner_os": "Linux",
        "github_matrix_os": "ubuntu-latest",
        "rust_c_abi_version": 19,
        "wheel_directory": "native/iroll-kernels-rust/target/wheels",
        "wheel_count": 1,
        "wheel_files": ["iroll_kernels_rust-0.1.0-cp313-cp313-linux.whl"],
        "wheel_artifact_name": "iroll-kernels-rust-wheel-ubuntu-latest",
        "unsigned_ci_artifact": True,
        "signed_release_artifacts_published": False,
        "publication_claimed": False,
        "platform_index_publication_claimed": False,
        "release_grade_speedup_claimed": False,
        "native_homfly_cpp_computation_claimed": False,
        "native_alexander_cpp_computation_claimed": False,
        "non_claim_evidence_index": [
            {
                "field": "signed_release_artifacts_published",
                "value": False,
                "evidence_role": "retained_ci_artifact_only",
            },
            {
                "field": "publication_claimed",
                "value": False,
                "evidence_role": "retained_ci_artifact_only",
            },
            {
                "field": "platform_index_publication_claimed",
                "value": False,
                "evidence_role": "retained_ci_artifact_only",
            },
            {
                "field": "release_grade_speedup_claimed",
                "value": False,
                "evidence_role": "retained_ci_artifact_only",
            },
            {
                "field": "native_homfly_cpp_computation_claimed",
                "value": False,
                "evidence_role": "retained_ci_artifact_only",
            },
            {
                "field": "native_alexander_cpp_computation_claimed",
                "value": False,
                "evidence_role": "retained_ci_artifact_only",
            },
        ],
        "release_non_claim_flags": [
            "signed_release_artifacts_published",
            "publication_claimed",
            "platform_index_publication_claimed",
            "release_grade_speedup_claimed",
            "native_homfly_cpp_computation_claimed",
            "native_alexander_cpp_computation_claimed",
        ],
        "release_non_claim_flag_count": 6,
        "release_non_claim_false_count": 6,
        "release_non_claim_all_false": True,
        "release_non_claim_consistency": {
            "claim_scope": "rust_wheel_retained_manifest_release_non_claim_consistency",
            "flag_count": 6,
            "false_count": 6,
            "all_false": True,
            "flags": [
                "signed_release_artifacts_published",
                "publication_claimed",
                "platform_index_publication_claimed",
                "release_grade_speedup_claimed",
                "native_homfly_cpp_computation_claimed",
                "native_alexander_cpp_computation_claimed",
            ],
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "rust_wheel_retained_metadata_manifest"
    assert summary["claim_scope"] == "unsigned_ci_rust_wheel_artifact_index"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 6
    assert summary["passed_check_count"] == 6
    assert summary["failed_check_count"] == 0
    assert summary["rust_wheel_retained_manifest_artifact_count"] == 1
    assert summary["rust_wheel_retained_manifest_abi_matched_count"] == 1
    assert summary["rust_wheel_retained_manifest_wheel_count_total"] == 1
    assert summary["rust_wheel_retained_manifest_wheel_file_count_total"] == 1
    assert summary["rust_wheel_retained_manifest_wheel_count_matched_count"] == 1
    assert summary["rust_wheel_retained_manifest_unsigned_ci_artifact_count"] == 1
    assert summary["rust_wheel_retained_manifest_non_claim_false_count"] == 6
    assert (
        summary[
            "rust_wheel_retained_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 6
    )
    assert summary["rust_wheel_retained_manifest_abi_matched"] is True
    assert summary["rust_wheel_retained_manifest_wheel_count_matched"] is True
    assert summary["rust_wheel_retained_manifest_non_claims_preserved"] is True
    assert "wheel_count=1" in summary["notes"]
    assert "wheel_count_matched=true" in summary["notes"]
    assert "rust_c_abi_matched=true" in summary["notes"]
    assert "unsigned_ci_artifact=true" in summary["notes"]
    assert "signed_release_artifacts_published=false" in summary["notes"]
    assert "publication_claimed=false" in summary["notes"]
    assert (
        "release_non_claim_consistency=flags=6; false=6; all_false=true"
        in summary["notes"]
    )
    assert "non_claim_evidence_index_entries=6" in summary["notes"]
    assert "not signed release publication" in summary["notes"]

    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_rust_wheel_retained_manifest_artifact_count"] == 1
    assert payload["analysis_rust_wheel_retained_manifest_abi_matched_count"] == 1
    assert payload["analysis_rust_wheel_retained_manifest_wheel_count_total"] == 1
    assert (
        payload[
            "analysis_rust_wheel_retained_manifest_wheel_count_matched_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_rust_wheel_retained_manifest_non_claim_false_count"
        ]
        == 6
    )
    assert (
        payload[
            "analysis_rust_wheel_retained_manifest_signed_release_artifacts_published_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_rust_wheel_retained_manifest_publication_claimed_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_rust_wheel_retained_manifest_platform_index_publication_claimed_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_rust_wheel_retained_manifest_release_grade_speedup_claimed_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_rust_wheel_retained_manifest_native_homfly_cpp_computation_claimed_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_rust_wheel_retained_manifest_native_alexander_cpp_computation_claimed_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_rust_wheel_retained_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 6
    )

    host_analysis = host_payload["analysis"]
    assert host_analysis["analysis_rust_wheel_retained_manifest_artifact_count"] == 1
    assert (
        host_analysis[
            "analysis_rust_wheel_retained_manifest_wheel_file_count_total"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_rust_wheel_retained_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 6
    )
    assert (
        host_analysis[
            "analysis_rust_wheel_retained_manifest_native_homfly_cpp_computation_claimed_count"
        ]
        == 0
    )
    assert host_payload["invariants"]["invariant_status_count"] == 0
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_payloads_preserve_rust_wheel_release_non_claim_consistency_mismatch() -> None:
    note_token = "release_non_claim_consistency=flags=6; false=5; all_false=false"
    report = {
        "artifact_schema_version": 1,
        "artifact_kind": "rust_wheel_retained_metadata_manifest",
        "claim_scope": "unsigned_ci_rust_wheel_artifact_index",
        "rust_c_abi_version": 19,
        "wheel_count": 1,
        "wheel_files": ["iroll_kernels_rust-0.1.0-cp313-cp313-linux.whl"],
        "wheel_artifact_name": "iroll-kernels-rust-wheel-ubuntu-latest",
        "unsigned_ci_artifact": True,
        "signed_release_artifacts_published": False,
        "publication_claimed": False,
        "platform_index_publication_claimed": False,
        "release_grade_speedup_claimed": False,
        "native_homfly_cpp_computation_claimed": False,
        "native_alexander_cpp_computation_claimed": False,
        "release_non_claim_consistency": {
            "claim_scope": "rust_wheel_retained_manifest_release_non_claim_consistency",
            "flag_count": 6,
            "false_count": 5,
            "all_false": False,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)
    payload = imgui_analysis_payload_from_acceptance_reports([report])
    host_payload = imgui_host_payload_from_acceptance_reports(
        [],
        analysis_reports=[report],
    )

    assert summary["source_method"] == "rust_wheel_retained_metadata_manifest"
    assert summary["accepted"] is True
    assert summary["rust_wheel_retained_manifest_non_claim_false_count"] == 6
    assert (
        summary[
            "rust_wheel_retained_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 0
    )
    assert note_token in summary["notes"]
    assert payload["analysis_rust_wheel_retained_manifest_non_claim_false_count"] == 6
    assert (
        payload[
            "analysis_rust_wheel_retained_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 0
    )
    assert note_token in payload["analysis_summaries"][0]["notes"]
    assert (
        host_payload["analysis"][
            "analysis_rust_wheel_retained_manifest_non_claim_false_count"
        ]
        == 6
    )
    assert (
        host_payload["analysis"][
            "analysis_rust_wheel_retained_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 0
    )
    assert note_token in host_payload["analysis"]["analysis_summaries"][0]["notes"]
    json.dumps(payload, allow_nan=False)
    json.dumps(host_payload, allow_nan=False)


def test_imgui_analysis_summary_preserves_benchmark_speedup_release_gate() -> None:
    report = {
        "method": "iroll_core_benchmark_matrix",
        "point_sizes": [128],
        "backends": ["numpy", "rust"],
        "workloads": ["contacts"],
        "repeat": 3,
        "warmup": 1,
        "matrix_summary": {
            "method": "iroll_core_benchmark_matrix_run_summary",
            "expected_row_count": 2,
            "row_count": 2,
            "completed_count": 2,
            "skipped_count": 0,
            "failed_count": 0,
            "all_requested_rows_completed": True,
            "has_failures": False,
        },
        "speedup_evidence": {
            "method": "iroll_core_benchmark_speedup_evidence",
            "candidate_speedup_count": 1,
            "release_grade_speedup_claimed": True,
            "release_gate": {
                "repeat": 3,
                "minimum_repeat_for_release_claim": 3,
                "repeat_satisfied": True,
                "speedup_threshold": 1.25,
                "threshold_candidate_count": 1,
                "completed_comparison_count": 1,
                "missing_baseline_count": 0,
                "release_grade_speedup_claimed": True,
                "blocking_reasons": [],
            },
        },
        "cuda_gpu_benchmark_evidence": {
            "method": "iroll_core_cuda_gpu_benchmark_evidence",
            "gate_scope": "local_gpu_benchmark_witness",
            "gpu_backend_requested": False,
            "gpu_backend_available": False,
            "cuda_runtime_observed": False,
            "gpu_requested_row_count": 0,
            "gpu_completed_row_count": 0,
            "gpu_skipped_row_count": 0,
            "gpu_failed_row_count": 0,
            "gpu_threshold_candidate_count": 0,
            "hosted_cuda_ci_claimed": False,
            "cuda_parity_claimed": False,
            "release_grade_gpu_speedup_claimed": False,
            "blocking_reasons": ["gpu_backend_not_requested"],
            "blocking_reason_count": 1,
        },
    }

    summary = analysis_summary_from_acceptance_report(report)

    assert summary["source_method"] == "iroll_core_benchmark_matrix"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["benchmark_speedup_release_grade_claimed"] is True
    assert summary["benchmark_speedup_release_grade_claimed_count"] == 1
    assert summary["benchmark_speedup_repeat_satisfied"] is True
    assert summary["benchmark_speedup_threshold_candidate_count"] == 1
    assert summary["benchmark_cuda_gpu_release_grade_speedup_claimed"] is False
    assert summary["benchmark_cuda_gpu_release_grade_speedup_claimed_count"] == 0
    assert "release_grade_speedup_claimed=true" in summary["notes"]
    assert "release_grade_gpu_speedup_claimed=false" in summary["notes"]
    assert "not CUDA parity evidence" in summary["notes"]

    payload = imgui_analysis_payload_from_acceptance_reports([report])

    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_benchmark_speedup_release_grade_claimed_count"] == 1
    assert (
        payload[
            "analysis_benchmark_cuda_gpu_release_grade_speedup_claimed_count"
        ]
        == 0
    )
    json.dumps(payload, allow_nan=False)
