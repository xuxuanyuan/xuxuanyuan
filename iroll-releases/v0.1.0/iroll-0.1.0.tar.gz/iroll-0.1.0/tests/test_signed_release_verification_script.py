from __future__ import annotations

import json
from pathlib import Path
import shutil
import subprocess
import sys

import pytest


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "verify_signed_release_publication.ps1"


def test_signed_release_verifier_covers_remote_bytes_and_ed25519() -> None:
    source = SCRIPT.read_text(encoding="utf-8")

    for token in [
        "signed_release_publication_verification_report",
        "package_index_url",
        "artifact_urls",
        "artifact_sha256s",
        "signature_urls",
        "signature_sha256s",
        "Invoke-WebRequest",
        "-PassThru",
        "sha256=",
        '"$artifactFilename.sig"',
        "pkeyutl",
        "-verify",
        "-pubin",
        "-rawin",
        "--no-deps",
        "--no-index",
        "--find-links",
        "--only-binary=:all:",
        "Remove-Item -Recurse -Force",
    ]:
        assert token in source

    assert "pkeyutl -sign" not in source
    assert "PRIVATE KEY" not in source


@pytest.mark.skipif(sys.platform != "win32", reason="PowerShell verifier is Windows tooling")
def test_signed_release_verifier_failure_is_machine_readable_json() -> None:
    powershell = shutil.which("powershell")
    if powershell is None:
        pytest.skip("Windows PowerShell is not installed")

    result = subprocess.run(
        [
            powershell,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(SCRIPT),
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8-sig",
    )

    payload = json.loads(result.stdout)
    assert result.returncode != 0
    assert result.stderr == ""
    assert payload["artifact_kind"] == (
        "signed_release_publication_verification_report"
    )
    assert payload["verification_succeeded"] is False
    assert payload["failed_check"] == "input_validation"
    assert payload["failure_message"] == "ManifestPath is required"
    assert payload["ci_exit_code"] == 1
