from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.skipif(sys.platform != "win32", reason="Windows cmd wrapper test")
def test_dev_cmd_wrapper_bypasses_execution_policy_for_script_mode() -> None:
    result = subprocess.run(
        [
            str(REPO_ROOT / "scripts" / "dev.cmd"),
            "-NoMsvc",
            "-Script",
            "Write-Output ok",
        ],
        cwd=REPO_ROOT,
        check=True,
        capture_output=True,
        text=True,
    )

    assert result.stdout.strip() == "ok"

@pytest.mark.skipif(sys.platform != "win32", reason="Windows cmd wrapper test")
def test_dev_cmd_wrapper_sets_repository_pythonpath() -> None:
    script = (
        "$paths = $env:PYTHONPATH -split [regex]::Escape([IO.Path]::PathSeparator); "
        "$src = (Resolve-Path 'src').Path; "
        "$gpu = (Resolve-Path 'native/iroll-kernels-gpu').Path; "
        "if (($paths -contains $src) -and ($paths -contains $gpu)) { "
        "Write-Output ok "
        "} else { "
        "throw \"repository Python paths were not added\" "
        "}"
    )
    result = subprocess.run(
        [
            str(REPO_ROOT / "scripts" / "dev.cmd"),
            "-NoMsvc",
            "-Script",
            script,
        ],
        cwd=REPO_ROOT,
        check=True,
        capture_output=True,
        text=True,
    )

    assert result.stdout.strip() == "ok"

@pytest.mark.skipif(sys.platform != "win32", reason="Windows cmd wrapper test")
def test_dev_cmd_wrapper_prefers_project_python_environment_for_imports() -> None:
    result = subprocess.run(
        [
            str(REPO_ROOT / "scripts" / "dev.cmd"),
            "-NoMsvc",
            "-Script",
            "python -c 'import iroll'",
        ],
        cwd=REPO_ROOT,
        check=True,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 0
