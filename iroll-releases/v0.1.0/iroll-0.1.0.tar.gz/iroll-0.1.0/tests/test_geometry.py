from __future__ import annotations

import numpy as np

from iroll import Polyline3D
from iroll.reports import assert_valid_report, imgui_geometry_payload_from_report
from iroll.topology import analyze_curve
from tests.fixtures import circle_points, helix_points, line_points


def test_line_length_tangent_and_curvature() -> None:
    curve = Polyline3D(line_points(20), closed=False)

    assert np.isclose(curve.arc_length(), 1.0)
    assert np.allclose(curve.tangents(), np.array([1.0, 0.0, 0.0]))
    assert np.allclose(curve.curvature(), 0.0)
    assert np.allclose(curve.torsion(), 0.0)


def test_circle_length_and_curvature() -> None:
    radius = 2.0
    curve = Polyline3D(circle_points(radius=radius, count=2048), closed=True)

    assert np.isclose(curve.arc_length(), 2.0 * np.pi * radius, rtol=1e-5)
    assert np.allclose(curve.curvature(), 1.0 / radius, rtol=1e-8, atol=1e-10)
    assert np.allclose(curve.torsion(), 0.0, atol=1e-10)


def test_helix_torsion_matches_analytic_value() -> None:
    radius = 2.0
    pitch_per_turn = 1.5
    b = pitch_per_turn / (2.0 * np.pi)
    expected_torsion = b / (radius**2 + b**2)
    curve = Polyline3D(
        helix_points(radius=radius, pitch_per_turn=pitch_per_turn, count=1200),
        closed=False,
    )

    torsion = curve.torsion()[20:-20]

    assert np.isclose(float(np.mean(torsion)), expected_torsion, rtol=0.03)


def test_resample_open_curve_preserves_endpoints() -> None:
    points = np.array(
        [
            [0.0, 0.0, 0.0],
            [0.5, 0.0, 0.0],
            [0.5, 0.5, 0.0],
            [1.0, 0.5, 0.0],
        ]
    )
    curve = Polyline3D(points)
    resampled = curve.resample_by_count(10)

    assert resampled.point_count == 10
    assert np.allclose(resampled.points[0], points[0])
    assert np.allclose(resampled.points[-1], points[-1])


def test_resample_closed_curve_remains_closed_without_duplicate_storage() -> None:
    curve = Polyline3D(circle_points(count=64), closed=True)
    resampled = curve.resample_by_count(32)

    assert resampled.closed is True
    assert resampled.point_count == 32
    assert resampled.segment_count == 32
    assert not np.allclose(resampled.points[0], resampled.points[-1])


def test_noisy_sampled_closed_curve_keeps_finite_geometry_report() -> None:
    count = 192
    theta = np.linspace(0.0, 2.0 * np.pi, count, endpoint=False)
    radial_noise = 0.015 * np.sin(11.0 * theta) + 0.006 * np.cos(17.0 * theta)
    axial_noise = 0.01 * np.sin(7.0 * theta)
    radius = 1.0 + radial_noise
    points = np.column_stack(
        [
            radius * np.cos(theta),
            radius * np.sin(theta),
            axial_noise,
        ]
    )
    curve = Polyline3D(points, closed=True, metadata={"fixture": "deterministic_noise"})

    resampled = curve.resample_by_count(96)
    curvature = resampled.curvature()
    torsion = resampled.torsion()
    report = analyze_curve(resampled, direction=[0.0, 0.0, 1.0], backend="numpy")

    assert resampled.closed is True
    assert resampled.point_count == 96
    assert np.isfinite(resampled.arc_length())
    assert 2.0 * np.pi * 0.95 < resampled.arc_length() < 2.0 * np.pi * 1.10
    assert np.all(np.isfinite(curvature))
    assert np.all(np.isfinite(torsion))
    assert report["input"]["point_count"] == 96
    assert report["geometry"]["closed"] is True
    assert report["runtime"]["requested_backend"] == "numpy"
    assert_valid_report(report, kind="curve")


def test_noisy_sampled_curve_family_matrix_keeps_finite_reports() -> None:
    cases = [
        {
            "name": "radial_circle_low_noise",
            "count": 160,
            "resample_count": 80,
            "base_radius": 1.0,
            "radial_scale": 0.012,
            "axial_scale": 0.006,
            "lobes": (5.0, 13.0, 3.0),
        },
        {
            "name": "radial_circle_medium_noise",
            "count": 224,
            "resample_count": 112,
            "base_radius": 1.35,
            "radial_scale": 0.025,
            "axial_scale": 0.018,
            "lobes": (7.0, 19.0, 11.0),
        },
        {
            "name": "oval_high_frequency_noise",
            "count": 288,
            "resample_count": 144,
            "base_radius": 0.9,
            "x_scale": 1.45,
            "y_scale": 0.72,
            "radial_scale": 0.018,
            "axial_scale": 0.012,
            "lobes": (9.0, 23.0, 17.0),
        },
    ]

    for case in cases:
        theta = np.linspace(0.0, 2.0 * np.pi, case["count"], endpoint=False)
        radial_noise = case["radial_scale"] * (
            np.sin(case["lobes"][0] * theta)
            + 0.5 * np.cos(case["lobes"][1] * theta)
        )
        radius = case["base_radius"] + radial_noise
        x_scale = case.get("x_scale", 1.0)
        y_scale = case.get("y_scale", 1.0)
        points = np.column_stack(
            [
                x_scale * radius * np.cos(theta),
                y_scale * radius * np.sin(theta),
                case["axial_scale"] * np.sin(case["lobes"][2] * theta),
            ]
        )
        curve = Polyline3D(points, closed=True, metadata={"fixture": case["name"]})
        resampled = curve.resample_by_count(case["resample_count"])
        report = analyze_curve(resampled, direction=[0.0, 0.0, 1.0], backend="numpy")

        assert resampled.closed is True
        assert resampled.point_count == case["resample_count"]
        assert np.isfinite(resampled.arc_length())
        assert np.all(np.isfinite(resampled.curvature()))
        assert np.all(np.isfinite(resampled.torsion()))
        assert report["input"]["point_count"] == case["resample_count"]
        assert report["geometry"]["closed"] is True
        assert report["runtime"]["requested_backend"] == "numpy"
        assert_valid_report(report, kind="curve")


def test_broad_noisy_sampled_curve_robustness_certification_pack() -> None:
    cases = [
        ("radial_circle_low", 192, 96, 1.0, 1.0, 1.0, 0.01, 0.004, (5.0, 11.0, 3.0)),
        ("radial_circle_high", 256, 128, 1.0, 1.0, 1.0, 0.035, 0.018, (7.0, 17.0, 9.0)),
        ("wide_oval_medium", 288, 144, 1.1, 1.55, 0.68, 0.024, 0.012, (9.0, 23.0, 13.0)),
        ("tall_oval_medium", 288, 144, 1.1, 0.72, 1.48, 0.022, 0.014, (8.0, 19.0, 15.0)),
        ("near_circle_dense", 384, 192, 0.85, 1.0, 1.0, 0.018, 0.010, (13.0, 29.0, 21.0)),
        ("large_radius_sparse", 160, 80, 1.8, 1.0, 1.0, 0.03, 0.015, (6.0, 14.0, 5.0)),
    ]

    certified_reports = []
    for name, count, resample_count, base_radius, x_scale, y_scale, radial_scale, axial_scale, lobes in cases:
        theta = np.linspace(0.0, 2.0 * np.pi, count, endpoint=False)
        radial_noise = radial_scale * (
            np.sin(lobes[0] * theta) + 0.5 * np.cos(lobes[1] * theta)
        )
        twist = 0.25 * radial_scale * np.sin((lobes[0] + lobes[2]) * theta)
        radius = base_radius + radial_noise
        points = np.column_stack(
            [
                x_scale * radius * np.cos(theta + twist),
                y_scale * radius * np.sin(theta + twist),
                axial_scale * np.sin(lobes[2] * theta),
            ]
        )
        curve = Polyline3D(
            points,
            closed=True,
            metadata={"fixture": name, "certification_pack": "broad_noisy_curve"},
        )
        resampled = curve.resample_by_count(resample_count)
        report = analyze_curve(resampled, direction=[0.2, -0.4, 1.0], backend="numpy")
        imgui_payload = imgui_geometry_payload_from_report(report)

        curvature = resampled.curvature()
        torsion = resampled.torsion()
        assert resampled.closed is True
        assert resampled.point_count == resample_count
        assert np.isfinite(resampled.arc_length())
        assert np.all(np.isfinite(curvature))
        assert np.all(np.isfinite(torsion))
        assert report["input"]["point_count"] == resample_count
        assert report["geometry"]["closed"] is True
        assert report["runtime"]["requested_backend"] == "numpy"
        assert imgui_payload["method"] == "imgui_geometry_payload_from_report"
        assert imgui_payload["geometry_point_count"] == resample_count
        assert imgui_payload["component_point_counts"] == [resample_count]
        assert imgui_payload["component_count"] == 1
        assert_valid_report(report, kind="curve")
        certified_reports.append(report)

    assert len(certified_reports) == 6
