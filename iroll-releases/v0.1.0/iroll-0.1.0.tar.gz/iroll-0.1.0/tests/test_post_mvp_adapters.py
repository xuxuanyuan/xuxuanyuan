from __future__ import annotations

import numpy as np

from iroll.adapters import (
    pdb_centerline_from_text,
    trace_afm_centerline,
    trajectory_curve_reports,
)


PDB_TEXT = """\
ATOM      1  P   DA A   1       0.000   0.000   0.000  1.00 10.00           P
ATOM      2  C4' DA A   1       0.200   0.000   0.000  1.00 10.00           C
ATOM      3  P   DA A   2       1.000   0.000   0.000  1.00 10.00           P
ATOM      4  C4' DA A   2       1.200   0.000   0.000  1.00 10.00           C
ATOM      5  P   DA B   1       9.000   0.000   0.000  1.00 10.00           P
"""


def test_pdb_centerline_from_text_extracts_chain_points() -> None:
    curve = pdb_centerline_from_text(
        PDB_TEXT,
        chain_id="A",
        atom_names=("P",),
        name="dna-a",
    )

    assert curve.name == "dna-a"
    assert curve.point_count == 2
    assert np.allclose(curve.points[:, 0], [0.0, 1.0])


def test_trajectory_curve_reports_analyze_frames() -> None:
    frames = [
        np.array([[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [2.0, 0.0, 0.0]]),
        np.array([[0.0, 0.0, 0.0], [1.0, 0.1, 0.0], [2.0, 0.0, 0.0]]),
    ]

    reports = trajectory_curve_reports(frames, backend="numpy")

    assert len(reports) == 2
    assert reports[1]["trajectory"]["frame_index"] == 1
    assert reports[0]["input"]["name"] == "frame-0"


def test_afm_trace_centerline_from_synthetic_image() -> None:
    image = np.zeros((5, 5), dtype=float)
    image[2, 1:4] = 1.0

    result = trace_afm_centerline(image, threshold=0.5, pixel_size=2.0)

    assert result.curve.point_count == 3
    assert np.allclose(result.curve.points[:, 0], [2.0, 4.0, 6.0])
    assert result.to_dict()["pixel_count"] == 3
