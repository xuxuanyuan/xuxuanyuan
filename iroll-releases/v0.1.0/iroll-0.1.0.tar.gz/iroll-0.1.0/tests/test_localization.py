from __future__ import annotations

import json

from iroll import Polyline3D
from iroll.cli import main
from iroll.topology import analyze_curve, scan_subchains
from tests.fixtures import line_points, trefoil_points
from tests.test_io_cli import workspace_tempdir


def test_scan_subchains_returns_expected_windows() -> None:
    curve = Polyline3D(line_points(count=8), name="line")

    results = scan_subchains(curve, window_points=4, step=2, max_windows=None)

    assert [(result.start, result.end) for result in results] == [(0, 4), (2, 6), (4, 8)]
    assert all(result.classification["method"] == "requires_closure" for result in results)


def test_scan_subchains_with_closure_reports_distribution() -> None:
    curve = Polyline3D(trefoil_points(count=96), closed=False)

    results = scan_subchains(
        curve,
        window_points=24,
        step=24,
        closure={"method": "direct"},
        max_windows=2,
    )

    assert len(results) == 2
    assert results[0].classification["method"] == "closure:direct"
    assert "closure" in results[0].classification


def test_analyze_curve_includes_subchain_summary_when_requested() -> None:
    curve = Polyline3D(line_points(count=8))

    report = analyze_curve(curve, subchain_window_points=4, subchain_step=2)

    assert report["topology"]["subchains"]["count"] == 3
    assert report["topology"]["subchains"]["window_points"] == 4


def test_cli_analyze_curve_subchain_scan(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "line.json"
        path.write_text(json.dumps(line_points(count=8).tolist()), encoding="utf-8")

        exit_code = main(
            [
                "analyze-curve",
                str(path),
                "--subchain-window-points",
                "4",
                "--subchain-step",
                "2",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

        assert exit_code == 0
        assert payload["topology"]["subchains"]["count"] == 3
