from __future__ import annotations

import json
from pathlib import Path

import pytest

from iroll.topology import (
    TableValidationError,
    assert_valid_link_table,
    load_knot_table_json,
    validate_knot_table,
    validate_link_table,
    validate_table_file,
)


def test_load_knot_table_json_accepts_wrapped_records(tmp_path: Path) -> None:
    path = tmp_path / "knots.json"
    path.write_text(
        json.dumps(
            {
                "knots": [
                    {
                        "notation": "8_1",
                        "knot_type": "eight_one",
                        "minimal_crossing_number": 8,
                        "determinant": 13,
                        "alexander_polynomial": "4 - 7t + 4t^2",
                        "jones_polynomial": None,
                        "homfly_polynomial": None,
                        "chiral": False,
                        "aliases": ["sample 8_1"],
                        "source": "fixture",
                        "source_url": None,
                        "convention": "iroll-test",
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    records = load_knot_table_json(path, expected_convention="iroll-test")

    assert records[0]["notation"] == "8_1"


def test_validate_knot_table_reports_duplicates() -> None:
    records = [
        {
            "notation": "3_1",
            "knot_type": "trefoil",
            "minimal_crossing_number": 3,
            "determinant": 3,
            "alexander_polynomial": "1 - t + t^2",
            "chiral": True,
        },
        {
            "notation": "3_1",
            "knot_type": "trefoil_mirror",
            "minimal_crossing_number": 3,
            "determinant": 3,
            "alexander_polynomial": "1 - t + t^2",
            "chiral": True,
        },
    ]

    issues = validate_knot_table(records)

    assert any("duplicates" in issue.message for issue in issues)


def test_validate_knot_table_reports_alias_notation_conflicts() -> None:
    records = [
        {
            "notation": "3_1",
            "knot_type": "trefoil",
            "minimal_crossing_number": 3,
            "determinant": 3,
            "alexander_polynomial": "1 - t + t^2",
            "chiral": True,
            "aliases": ["future_alias"],
        },
        {
            "notation": "future_alias",
            "knot_type": "placeholder",
            "minimal_crossing_number": 8,
            "determinant": 1,
            "alexander_polynomial": "1",
            "chiral": False,
        },
    ]

    issues = validate_knot_table(records)

    assert any("alias conflicts" in issue.message for issue in issues)


def test_validate_link_table_checks_pairwise_linking_length() -> None:
    records = [
        {
            "notation": "L6a4",
            "link_type": "borromean_rings",
            "component_count": 3,
            "minimal_crossing_number": 6,
            "pairwise_linking": [0, 0],
        }
    ]

    issues = validate_link_table(records)

    assert any("expected 3 values" in issue.message for issue in issues)


def test_validate_table_requires_convention_declaration() -> None:
    records = [
        {
            "notation": "8_1",
            "knot_type": "eight_one",
            "minimal_crossing_number": 8,
            "determinant": 13,
            "alexander_polynomial": "4 - 7t + 4t^2",
            "chiral": False,
        }
    ]

    issues = validate_knot_table(records)

    assert any(
        issue.path == "$[0].convention"
        and "expected convention or convention_metadata.name" in issue.message
        for issue in issues
    )


def test_validate_table_accepts_convention_metadata_name() -> None:
    records = [
        {
            "notation": "L2a1",
            "link_type": "hopf_link",
            "component_count": 2,
            "minimal_crossing_number": 2,
            "pairwise_linking": [1],
            "convention_metadata": {"name": "iroll-test"},
        }
    ]

    issues = validate_link_table(records, expected_convention="iroll-test")

    assert issues == []

def test_assert_valid_link_table_raises_structured_error() -> None:
    with pytest.raises(TableValidationError) as exc_info:
        assert_valid_link_table([{"notation": "bad"}])

    assert exc_info.value.issues


def test_validate_table_file_returns_json_compatible_payload(tmp_path: Path) -> None:
    path = tmp_path / "links.json"
    path.write_text(
        json.dumps(
            [
                {
                    "notation": "L2a1",
                    "link_type": "hopf_link",
                    "component_count": 2,
                    "minimal_crossing_number": 2,
                    "pairwise_linking": [1],
                    "aliases": ["Hopf link"],
                    "source": "fixture",
                    "convention": "iroll-test",
                }
            ]
        ),
        encoding="utf-8",
    )

    result = validate_table_file(path, kind="link")

    assert result["valid"] is True
    assert result["record_count"] == 1
    assert result["source_metadata_summary"] == {
        "claim_scope": "table_source_metadata_scan",
        "expected_convention": None,
        "record_count": 1,
        "source_count": 1,
        "source_rows": ["$[0]"],
        "source_value_counts": {"fixture": 1},
        "source_value_rows": {"fixture": ["$[0]"]},
        "source_url_count": 0,
        "source_url_rows": [],
        "source_with_source_url_count": 0,
        "source_with_source_url_rows": [],
        "valid_source_url_count": 0,
        "valid_source_url_rows": [],
        "source_url_missing_scheme_count": 0,
        "source_url_missing_scheme_rows": [],
        "source_url_missing_domain_count": 0,
        "source_url_missing_domain_rows": [],
        "missing_source_count": 0,
        "missing_source_rows": [],
        "missing_source_url_count": 1,
        "missing_source_url_rows": ["$[0]"],
        "source_url_without_source_count": 0,
        "source_url_without_source_rows": [],
        "invalid_source_url_count": 0,
        "invalid_source_url_rows": [],
        "source_url_scheme_counts": {},
        "source_url_scheme_rows": {},
        "source_url_domain_counts": {},
        "source_url_domain_rows": {},
        "source_url_issue_code_counts": {},
        "source_url_issue_code_rows": {},
        "source_completeness_rows": [
            {
                "row": "$[0]",
                "has_source": True,
                "has_source_url": False,
                "source_record_has_source_url": False,
                "source_url_has_source": True,
                "source_with_source_url": False,
                "source_url_http_or_https": True,
                "source_url_missing_scheme": False,
                "source_url_missing_domain": False,
                "source_url_invalid": False,
            }
        ],
        "convention_count": 1,
        "convention_rows": ["$[0]"],
        "convention_metadata_count": 0,
        "convention_metadata_rows": [],
        "convention_metadata_name_count": 0,
        "convention_metadata_name_rows": [],
        "convention_metadata_without_name_count": 0,
        "convention_metadata_without_name_rows": [],
        "convention_mismatch_count": 0,
        "convention_mismatch_rows": [],
        "known_limitations_count": 0,
        "known_limitations_rows": [],
        "provenance_review_ready": False,
        "provenance_blocker_count": 1,
        "provenance_blocker_codes": ["missing_source_url"],
        "provenance_blocker_details": [
            {
                "code": "missing_source_url",
                "severity": "blocking",
                "scope": "table_source_metadata_provenance",
                "path": "$[0].source_url",
                "row": "$[0]",
                "reason": "source record has no source_url",
            }
        ],
        "provenance_blocker_summary_consistency": {
            "method": "source_metadata_provenance_blocker_summary_consistency",
            "claim_scope": (
                "table_source_metadata_provenance_blocker_self_consistency"
            ),
            "matched": True,
            "blocker_count": 1,
            "detail_count": 1,
            "code_count": 1,
            "detail_count_matched": True,
            "unique_code_count_matched": True,
            "review_ready_matched": True,
        },
        "all_records_have_source": True,
        "all_source_records_have_source_url": False,
        "all_source_urls_have_source": True,
        "all_source_urls_are_http_or_https": True,
        "all_conventions_match_expected": True,
        "table_correctness_certified": False,
        "external_source_verified": False,
        "summary_consistency": {
            "method": "source_metadata_summary_consistency",
            "claim_scope": "table_source_metadata_summary_self_consistency",
            "matched": True,
            "record_count": 1,
            "source_count": 1,
            "source_url_count": 0,
            "source_with_source_url_count": 0,
            "valid_source_url_count": 0,
            "source_url_missing_scheme_count": 0,
            "source_url_missing_domain_count": 0,
            "source_url_issue_code_total": 0,
            "convention_count": 1,
            "convention_metadata_count": 0,
            "convention_metadata_name_count": 0,
            "convention_metadata_without_name_count": 0,
            "convention_mismatch_count": 0,
            "known_limitations_count": 0,
            "source_completeness_row_count": 1,
            "record_count_matched": True,
            "source_count_matched": True,
            "source_value_count_total_matched": True,
            "source_value_row_count_total_matched": True,
            "source_url_count_matched": True,
            "missing_source_count_matched": True,
            "missing_source_url_count_matched": True,
            "source_url_without_source_count_matched": True,
            "source_url_without_source_rows_subset_of_missing_source_rows": True,
            "invalid_source_url_count_matched": True,
            "source_url_scheme_count_total_matched": True,
            "source_url_scheme_row_count_total_matched": True,
            "source_url_domain_count_total_matched": True,
            "source_url_domain_row_count_total_matched": True,
            "source_url_issue_code_count_total_matched": True,
            "source_url_issue_code_invalid_row_coverage_matched": True,
            "convention_count_matched": True,
            "convention_metadata_count_matched": True,
            "convention_metadata_name_count_matched": True,
            "convention_mismatch_count_matched": True,
            "known_limitations_count_matched": True,
            "source_completeness_row_count_matched": True,
            "source_completeness_source_count_matched": True,
            "source_completeness_source_url_count_matched": True,
            "source_completeness_invalid_url_count_matched": True,
        },
        "notes": [
            "source metadata scan only; does not verify external table correctness",
        ],
    }


def test_validate_table_file_summarizes_source_url_domains(tmp_path: Path) -> None:
    path = tmp_path / "knots.json"
    path.write_text(
        json.dumps(
            {
                "knots": [
                    {
                        "notation": "3_1",
                        "knot_type": "trefoil",
                        "minimal_crossing_number": 3,
                        "determinant": 3,
                        "alexander_polynomial": "1 - t + t^2",
                        "chiral": True,
                        "source": "Knot Atlas",
                        "source_url": "https://katlas.org/wiki/3_1",
                        "convention_metadata": {"name": "iroll-test"},
                        "known_limitations": ["fixture only"],
                    },
                    {
                        "notation": "4_1",
                        "knot_type": "figure_eight",
                        "minimal_crossing_number": 4,
                        "determinant": 5,
                        "alexander_polynomial": "-1 + 3t - t^2",
                        "chiral": False,
                        "source": "local fixture",
                        "source_url": "fixture-only",
                        "convention": "iroll-test",
                    },
                ]
            }
        ),
        encoding="utf-8",
    )

    result = validate_table_file(path, kind="knot", expected_convention="iroll-test")

    summary = result["source_metadata_summary"]
    assert result["valid"] is True
    assert summary["source_count"] == 2
    assert summary["source_rows"] == ["$[0]", "$[1]"]
    assert summary["source_value_counts"] == {
        "Knot Atlas": 1,
        "local fixture": 1,
    }
    assert summary["source_value_rows"] == {
        "Knot Atlas": ["$[0]"],
        "local fixture": ["$[1]"],
    }
    assert summary["source_url_count"] == 2
    assert summary["source_url_rows"] == ["$[0]", "$[1]"]
    assert summary["source_with_source_url_count"] == 2
    assert summary["source_with_source_url_rows"] == ["$[0]", "$[1]"]
    assert summary["valid_source_url_count"] == 1
    assert summary["valid_source_url_rows"] == ["$[0]"]
    assert summary["source_url_missing_scheme_count"] == 1
    assert summary["source_url_missing_scheme_rows"] == ["$[1]"]
    assert summary["source_url_missing_domain_count"] == 1
    assert summary["source_url_missing_domain_rows"] == ["$[1]"]
    assert summary["source_url_scheme_counts"] == {"https": 1}
    assert summary["source_url_scheme_rows"] == {"https": ["$[0]"]}
    assert summary["source_url_domain_counts"] == {"katlas.org": 1}
    assert summary["source_url_domain_rows"] == {"katlas.org": ["$[0]"]}
    assert summary["source_url_issue_code_counts"] == {
        "missing_scheme": 1,
        "missing_domain": 1,
    }
    assert summary["source_url_issue_code_rows"] == {
        "missing_scheme": ["$[1]"],
        "missing_domain": ["$[1]"],
    }
    assert summary["invalid_source_url_count"] == 1
    assert summary["invalid_source_url_rows"] == [
        {"path": "$[1].source_url", "source_url": "fixture-only"}
    ]
    assert summary["convention_count"] == 1
    assert summary["convention_rows"] == ["$[1]"]
    assert summary["convention_metadata_count"] == 1
    assert summary["convention_metadata_rows"] == ["$[0]"]
    assert summary["convention_metadata_name_count"] == 1
    assert summary["convention_metadata_name_rows"] == ["$[0]"]
    assert summary["convention_metadata_without_name_count"] == 0
    assert summary["convention_metadata_without_name_rows"] == []
    assert summary["known_limitations_count"] == 1
    assert summary["known_limitations_rows"] == ["$[0]"]
    assert summary["provenance_review_ready"] is False
    assert summary["provenance_blocker_count"] == 1
    assert summary["provenance_blocker_codes"] == ["invalid_source_url"]
    assert summary["provenance_blocker_details"] == [
        {
            "code": "invalid_source_url",
            "severity": "blocking",
            "scope": "table_source_metadata_provenance",
            "path": "$[1].source_url",
            "row": "$[1]",
            "reason": "source_url is missing an http(s) scheme or domain",
            "source_url": "fixture-only",
            "scheme": "",
            "domain": "",
            "source_url_issue_codes": ["missing_scheme", "missing_domain"],
        }
    ]
    assert summary["provenance_blocker_summary_consistency"] == {
        "method": "source_metadata_provenance_blocker_summary_consistency",
        "claim_scope": "table_source_metadata_provenance_blocker_self_consistency",
        "matched": True,
        "blocker_count": 1,
        "detail_count": 1,
        "code_count": 1,
        "detail_count_matched": True,
        "unique_code_count_matched": True,
        "review_ready_matched": True,
    }
    assert summary["all_records_have_source"] is True
    assert summary["all_source_records_have_source_url"] is True
    assert summary["source_url_without_source_count"] == 0
    assert summary["source_url_without_source_rows"] == []
    assert summary["all_source_urls_have_source"] is True
    assert summary["all_source_urls_are_http_or_https"] is False
    assert summary["summary_consistency"]["matched"] is True
    assert summary["summary_consistency"]["source_with_source_url_count"] == 2
    assert summary["summary_consistency"]["source_value_count_total_matched"] is True
    assert (
        summary["summary_consistency"]["source_value_row_count_total_matched"]
        is True
    )
    assert summary["summary_consistency"]["valid_source_url_count"] == 1
    assert summary["summary_consistency"]["source_url_missing_scheme_count"] == 1
    assert summary["summary_consistency"]["source_url_missing_domain_count"] == 1
    assert summary["summary_consistency"]["source_url_issue_code_total"] == 2
    assert summary["summary_consistency"]["convention_count"] == 1
    assert summary["summary_consistency"]["convention_metadata_count"] == 1
    assert summary["summary_consistency"]["convention_metadata_name_count"] == 1
    assert summary["summary_consistency"]["convention_metadata_without_name_count"] == 0
    assert summary["summary_consistency"]["known_limitations_count"] == 1
    assert summary["summary_consistency"]["convention_count_matched"] is True
    assert summary["summary_consistency"]["convention_metadata_count_matched"] is True
    assert (
        summary["summary_consistency"]["convention_metadata_name_count_matched"]
        is True
    )
    assert summary["summary_consistency"]["known_limitations_count_matched"] is True
    assert summary["summary_consistency"]["missing_source_url_count_matched"] is True
    assert summary["summary_consistency"]["invalid_source_url_count_matched"] is True
    assert summary["summary_consistency"]["method"] == (
        "source_metadata_summary_consistency"
    )
    assert summary["summary_consistency"]["claim_scope"] == (
        "table_source_metadata_summary_self_consistency"
    )
    assert (
        summary["summary_consistency"]["source_url_domain_count_total_matched"]
        is True
    )
    assert (
        summary["summary_consistency"]["source_url_scheme_row_count_total_matched"]
        is True
    )
    assert (
        summary["summary_consistency"]["source_url_domain_row_count_total_matched"]
        is True
    )
    assert (
        summary["summary_consistency"]["source_url_issue_code_count_total_matched"]
        is True
    )
    assert (
        summary["summary_consistency"][
            "source_url_issue_code_invalid_row_coverage_matched"
        ]
        is True
    )
    assert summary["source_completeness_rows"] == [
        {
            "row": "$[0]",
            "has_source": True,
            "has_source_url": True,
            "source_record_has_source_url": True,
            "source_url_has_source": True,
            "source_with_source_url": True,
            "source_url_http_or_https": True,
            "source_url_missing_scheme": False,
            "source_url_missing_domain": False,
            "source_url_invalid": False,
        },
        {
            "row": "$[1]",
            "has_source": True,
            "has_source_url": True,
            "source_record_has_source_url": True,
            "source_url_has_source": True,
            "source_with_source_url": True,
            "source_url_http_or_https": False,
            "source_url_missing_scheme": True,
            "source_url_missing_domain": True,
            "source_url_invalid": True,
        },
    ]
    assert summary["summary_consistency"]["source_completeness_row_count"] == 2
    assert (
        summary["summary_consistency"]["source_completeness_row_count_matched"]
        is True
    )
    assert (
        summary["summary_consistency"]["source_completeness_source_count_matched"]
        is True
    )
    assert (
        summary[
            "summary_consistency"
        ]["source_completeness_source_url_count_matched"]
        is True
    )
    assert (
        summary[
            "summary_consistency"
        ]["source_completeness_invalid_url_count_matched"]
        is True
    )
    assert summary["external_source_verified"] is False


def test_validate_table_file_marks_unsupported_source_url_scheme(
    tmp_path: Path,
) -> None:
    path = tmp_path / "links.json"
    path.write_text(
        json.dumps(
            [
                {
                    "notation": "L2a1",
                    "link_type": "hopf_link",
                    "component_count": 2,
                    "minimal_crossing_number": 2,
                    "pairwise_linking": [1],
                    "source": "fixture",
                    "source_url": "ftp://example.org/L2a1",
                    "convention": "iroll-test",
                }
            ]
        ),
        encoding="utf-8",
    )

    result = validate_table_file(path, kind="link")

    summary = result["source_metadata_summary"]
    assert result["valid"] is True
    assert summary["provenance_blocker_codes"] == ["invalid_source_url"]
    assert summary["provenance_blocker_details"] == [
        {
            "code": "invalid_source_url",
            "severity": "blocking",
            "scope": "table_source_metadata_provenance",
            "path": "$[0].source_url",
            "row": "$[0]",
            "reason": "source_url is missing an http(s) scheme or domain",
            "source_url": "ftp://example.org/L2a1",
            "scheme": "ftp",
            "domain": "example.org",
            "source_url_issue_codes": ["unsupported_scheme"],
        }
    ]
    assert summary["source_url_issue_code_counts"] == {"unsupported_scheme": 1}
    assert summary["source_url_issue_code_rows"] == {"unsupported_scheme": ["$[0]"]}
    assert summary["source_completeness_rows"] == [
        {
            "row": "$[0]",
            "has_source": True,
            "has_source_url": True,
            "source_record_has_source_url": True,
            "source_url_has_source": True,
            "source_with_source_url": True,
            "source_url_http_or_https": False,
            "source_url_missing_scheme": False,
            "source_url_missing_domain": False,
            "source_url_invalid": True,
        },
    ]
    assert summary["summary_consistency"]["source_url_issue_code_total"] == 1
    assert (
        summary["summary_consistency"]["source_url_issue_code_count_total_matched"]
        is True
    )
    assert (
        summary["summary_consistency"][
            "source_url_issue_code_invalid_row_coverage_matched"
        ]
        is True
    )
    assert summary["summary_consistency"]["source_completeness_row_count"] == 1
    assert (
        summary["summary_consistency"]["source_completeness_row_count_matched"]
        is True
    )
    assert (
        summary["summary_consistency"]["source_completeness_source_count_matched"]
        is True
    )
    assert (
        summary[
            "summary_consistency"
        ]["source_completeness_source_url_count_matched"]
        is True
    )
    assert (
        summary[
            "summary_consistency"
        ]["source_completeness_invalid_url_count_matched"]
        is True
    )
    assert summary["provenance_blocker_summary_consistency"]["matched"] is True


@pytest.mark.parametrize(
    ("known_limitations", "expected_count", "expected_valid"),
    [
        ("", 0, False),
        ("   ", 0, False),
        ([], 0, False),
        (["", "   "], 0, False),
        ("fixture only", 1, True),
        (["fixture only", " import-only fixture "], 1, True),
    ],
)
def test_validate_table_file_counts_non_empty_known_limitations_text(
    tmp_path: Path,
    known_limitations: object,
    expected_count: int,
    expected_valid: bool,
) -> None:
    path = tmp_path / "knots.json"
    path.write_text(
        json.dumps(
            [
                {
                    "notation": "3_1",
                    "knot_type": "trefoil",
                    "minimal_crossing_number": 3,
                    "determinant": 3,
                    "alexander_polynomial": "1 - t + t^2",
                    "chiral": True,
                    "source": "fixture",
                    "convention": "iroll-test",
                    "known_limitations": known_limitations,
                }
            ]
        ),
        encoding="utf-8",
    )

    result = validate_table_file(path, kind="knot")

    summary = result["source_metadata_summary"]
    assert result["valid"] is expected_valid
    assert summary["known_limitations_count"] == expected_count
    assert summary["known_limitations_rows"] == (
        ["$[0]"] if expected_count else []
    )
    assert (
        summary["summary_consistency"]["known_limitations_count"]
        == expected_count
    )
    assert summary["summary_consistency"]["known_limitations_count_matched"] is True
    assert summary["summary_consistency"]["matched"] is True


def test_validate_table_file_flags_invalid_known_limitations_item(
    tmp_path: Path,
) -> None:
    path = tmp_path / "links.json"
    path.write_text(
        json.dumps(
            [
                {
                    "notation": "L2a1",
                    "link_type": "hopf_link",
                    "component_count": 2,
                    "minimal_crossing_number": 2,
                    "pairwise_linking": [1],
                    "source": "fixture",
                    "convention": "iroll-test",
                    "known_limitations": ["fixture only", 5],
                }
            ]
        ),
        encoding="utf-8",
    )

    result = validate_table_file(path, kind="link")

    assert result["valid"] is False
    assert result["source_metadata_summary"]["known_limitations_count"] == 1
    assert result["source_metadata_summary"]["known_limitations_rows"] == ["$[0]"]
    assert any(
        issue["path"] == "$[0].known_limitations[1]"
        and issue["message"] == "expected non-empty string"
        for issue in result["issues"]
    )


@pytest.mark.parametrize("known_limitations", ["", "   ", []])
def test_validate_table_file_flags_invalid_known_limitations_shape(
    tmp_path: Path,
    known_limitations: object,
) -> None:
    path = tmp_path / "knots.json"
    path.write_text(
        json.dumps(
            [
                {
                    "notation": "4_1",
                    "knot_type": "figure_eight",
                    "minimal_crossing_number": 4,
                    "determinant": 5,
                    "alexander_polynomial": "-1 + 3t - t^2",
                    "chiral": False,
                    "source": "fixture",
                    "convention": "iroll-test",
                    "known_limitations": known_limitations,
                }
            ]
        ),
        encoding="utf-8",
    )

    result = validate_table_file(path, kind="knot")

    assert result["valid"] is False
    assert any(
        issue["path"] == "$[0].known_limitations"
        and issue["message"]
        == "expected non-empty string or non-empty list of non-empty strings"
        for issue in result["issues"]
    )


def test_validate_table_file_flags_source_url_without_source(tmp_path: Path) -> None:
    path = tmp_path / "knots.json"
    path.write_text(
        json.dumps(
            [
                {
                    "notation": "5_1",
                    "knot_type": "cinquefoil",
                    "minimal_crossing_number": 5,
                    "determinant": 5,
                    "alexander_polynomial": "1 - t + t^2 - t^3 + t^4",
                    "chiral": True,
                    "source_url": "https://katlas.org/wiki/5_1",
                    "convention": "iroll-test",
                }
            ]
        ),
        encoding="utf-8",
    )

    result = validate_table_file(path, kind="knot")

    summary = result["source_metadata_summary"]
    assert result["valid"] is True
    assert summary["source_count"] == 0
    assert summary["source_rows"] == []
    assert summary["source_value_counts"] == {}
    assert summary["source_value_rows"] == {}
    assert summary["source_url_count"] == 1
    assert summary["source_url_rows"] == ["$[0]"]
    assert summary["source_with_source_url_count"] == 0
    assert summary["source_with_source_url_rows"] == []
    assert summary["valid_source_url_count"] == 1
    assert summary["valid_source_url_rows"] == ["$[0]"]
    assert summary["source_url_missing_scheme_count"] == 0
    assert summary["source_url_missing_scheme_rows"] == []
    assert summary["source_url_missing_domain_count"] == 0
    assert summary["source_url_missing_domain_rows"] == []
    assert summary["missing_source_count"] == 1
    assert summary["missing_source_rows"] == ["$[0]"]
    assert summary["source_url_without_source_count"] == 1
    assert summary["source_url_without_source_rows"] == ["$[0]"]
    assert summary["source_completeness_rows"] == [
        {
            "row": "$[0]",
            "has_source": False,
            "has_source_url": True,
            "source_record_has_source_url": True,
            "source_url_has_source": False,
            "source_with_source_url": False,
            "source_url_http_or_https": True,
            "source_url_missing_scheme": False,
            "source_url_missing_domain": False,
            "source_url_invalid": False,
        }
    ]
    assert summary["provenance_review_ready"] is False
    assert summary["provenance_blocker_count"] == 2
    assert summary["provenance_blocker_codes"] == [
        "missing_source",
        "source_url_without_source",
    ]
    assert summary["provenance_blocker_details"] == [
        {
            "code": "missing_source",
            "severity": "blocking",
            "scope": "table_source_metadata_provenance",
            "path": "$[0].source",
            "row": "$[0]",
            "reason": "record has no source label",
        },
        {
            "code": "source_url_without_source",
            "severity": "blocking",
            "scope": "table_source_metadata_provenance",
            "path": "$[0].source",
            "row": "$[0]",
            "reason": "source_url is present without a source label",
        },
    ]
    assert summary["provenance_blocker_summary_consistency"]["matched"] is True
    assert (
        summary["provenance_blocker_summary_consistency"]["blocker_count"] == 2
    )
    assert summary["provenance_blocker_summary_consistency"]["code_count"] == 2
    assert (
        summary["provenance_blocker_summary_consistency"]["review_ready_matched"]
        is True
    )
    assert summary["all_records_have_source"] is False
    assert summary["all_source_urls_have_source"] is False
    assert summary["all_source_urls_are_http_or_https"] is True
    assert summary["summary_consistency"]["matched"] is True
    assert summary["summary_consistency"]["source_with_source_url_count"] == 0
    assert summary["summary_consistency"]["valid_source_url_count"] == 1
    assert summary["summary_consistency"]["source_url_missing_scheme_count"] == 0
    assert summary["summary_consistency"]["source_url_missing_domain_count"] == 0
    assert summary["summary_consistency"]["source_url_without_source_count_matched"] is True
    assert (
        summary["summary_consistency"][
            "source_url_without_source_rows_subset_of_missing_source_rows"
        ]
        is True
    )
    assert summary["summary_consistency"]["source_completeness_row_count"] == 1
    assert (
        summary["summary_consistency"]["source_completeness_row_count_matched"]
        is True
    )
    assert (
        summary["summary_consistency"]["source_completeness_source_count_matched"]
        is True
    )
    assert (
        summary[
            "summary_consistency"
        ]["source_completeness_source_url_count_matched"]
        is True
    )
    assert (
        summary[
            "summary_consistency"
        ]["source_completeness_invalid_url_count_matched"]
        is True
    )


def test_validate_table_file_summarizes_convention_metadata_without_name(
    tmp_path: Path,
) -> None:
    path = tmp_path / "links.json"
    path.write_text(
        json.dumps(
            [
                {
                    "notation": "L2a1",
                    "link_type": "hopf_link",
                    "component_count": 2,
                    "minimal_crossing_number": 2,
                    "pairwise_linking": [1],
                    "source": "fixture",
                    "convention_metadata": {"notes": "missing explicit name"},
                }
            ]
        ),
        encoding="utf-8",
    )

    result = validate_table_file(path, kind="link")

    summary = result["source_metadata_summary"]
    assert result["valid"] is False
    assert summary["convention_metadata_count"] == 1
    assert summary["convention_metadata_rows"] == ["$[0]"]
    assert summary["convention_metadata_name_count"] == 0
    assert summary["convention_metadata_name_rows"] == []
    assert summary["convention_metadata_without_name_count"] == 1
    assert summary["convention_metadata_without_name_rows"] == ["$[0]"]
    assert "missing_convention" in summary["provenance_blocker_codes"]
    assert any(
        detail == {
            "code": "missing_convention",
            "severity": "blocking",
            "scope": "table_source_metadata_provenance",
            "path": "$[0].convention",
            "row": "$[0]",
            "reason": "record has no convention or convention_metadata.name",
        }
        for detail in summary["provenance_blocker_details"]
    )
    assert summary["summary_consistency"]["convention_metadata_count"] == 1
    assert summary["summary_consistency"]["convention_metadata_name_count"] == 0
    assert summary["summary_consistency"]["convention_metadata_without_name_count"] == 1
    assert summary["summary_consistency"]["convention_metadata_count_matched"] is True
    assert (
        summary["summary_consistency"]["convention_metadata_name_count_matched"]
        is True
    )
    assert any(
        issue["path"] == "$[0].convention"
        and "expected convention or convention_metadata.name" in issue["message"]
        for issue in result["issues"]
    )


def test_validate_table_file_marks_expected_convention_mismatch(
    tmp_path: Path,
) -> None:
    path = tmp_path / "links.json"
    path.write_text(
        json.dumps(
            [
                {
                    "notation": "L2a1",
                    "link_type": "hopf_link",
                    "component_count": 2,
                    "minimal_crossing_number": 2,
                    "pairwise_linking": [1],
                    "source": "fixture",
                    "source_url": "https://example.org/L2a1",
                    "convention_metadata": {"name": "source-table"},
                }
            ]
        ),
        encoding="utf-8",
    )

    result = validate_table_file(
        path,
        kind="link",
        expected_convention="iroll-test",
    )

    summary = result["source_metadata_summary"]
    assert result["valid"] is False
    assert result["issues"] == [
        {
            "path": "$[0].convention",
            "message": "expected convention 'iroll-test', got 'source-table'",
        }
    ]
    assert summary["expected_convention"] == "iroll-test"
    assert summary["convention_mismatch_count"] == 1
    assert summary["convention_mismatch_rows"] == [
        {
            "path": "$[0].convention_metadata.name",
            "row": "$[0]",
            "expected_convention": "iroll-test",
            "observed_convention": "source-table",
        }
    ]
    assert summary["provenance_review_ready"] is False
    assert summary["provenance_blocker_count"] == 1
    assert summary["provenance_blocker_codes"] == ["convention_mismatch"]
    assert summary["provenance_blocker_details"] == [
        {
            "code": "convention_mismatch",
            "severity": "blocking",
            "scope": "table_source_metadata_provenance",
            "path": "$[0].convention_metadata.name",
            "row": "$[0]",
            "reason": "record convention does not match expected convention",
            "expected_convention": "iroll-test",
            "observed_convention": "source-table",
        }
    ]
    assert summary["provenance_blocker_summary_consistency"]["matched"] is True
    assert summary["summary_consistency"]["convention_mismatch_count"] == 1
    assert summary["summary_consistency"]["convention_mismatch_count_matched"] is True
    assert summary["summary_consistency"]["matched"] is True
    assert summary["all_conventions_match_expected"] is False
    assert summary["table_correctness_certified"] is False
    assert summary["external_source_verified"] is False


def test_validate_table_source_metadata_summary_is_documented() -> None:
    root = Path(__file__).resolve().parents[1]
    report_schema = (root / "docs" / "report-schema.md").read_text(
        encoding="utf-8"
    )
    validation_doc = (root / "docs" / "validation-and-robustness.md").read_text(
        encoding="utf-8"
    )

    for text in (report_schema, validation_doc):
        assert "source_metadata_summary" in text
        assert "claim_scope=table_source_metadata_scan" in text
        assert "source_url_without_source_count" in text
        assert "all_source_urls_have_source" in text
        assert "summary_consistency" in text
        assert "source_rows" in text
        assert "source_value_counts" in text
        assert "source_value_rows" in text
        assert "source_value_count_total_matched" in text
        assert "source_value_row_count_total_matched" in text
        assert "provenance_review_ready" in text
        assert "provenance_blocker_count" in text
        assert "provenance_blocker_codes" in text
        assert "provenance_blocker_details" in text
        assert "provenance_blocker_summary_consistency" in text
        assert "table_source_metadata_provenance_blocker_self_consistency" in text
        assert "review_ready_matched" in text
        assert "expected_convention" in text
        assert "convention_mismatch" in text
        assert "convention_mismatch_count_matched" in text
        assert "all_conventions_match_expected" in text
        assert "source_url_issue_codes" in text
        assert "source_url_issue_code_counts" in text
        assert "source_url_issue_code_rows" in text
        assert "source_url_issue_code_count_total_matched" in text
        assert "source_url_issue_code_invalid_row_coverage_matched" in text
        assert "missing_scheme" in text
        assert "missing_domain" in text
        assert "unsupported_scheme" in text
        assert "missing_source_url" in text
        assert "invalid_source_url" in text
        assert "missing_convention" in text
        assert "source_url_rows" in text
        assert "source_with_source_url_count" in text
        assert "source_with_source_url_rows" in text
        assert "valid_source_url_count" in text
        assert "valid_source_url_rows" in text
        assert "source_url_scheme_rows" in text
        assert "source_url_domain_rows" in text
        assert "source_url_missing_scheme_rows" in text
        assert "source_url_missing_domain_rows" in text
        assert "source_completeness_rows" in text
        assert "source_record_has_source_url" in text
        assert "source_url_has_source" in text
        assert "source_url_http_or_https" in text
        assert "source_url_invalid" in text
        assert "source_completeness_row_count_matched" in text
        assert "source_completeness_source_count_matched" in text
        assert "source_completeness_source_url_count_matched" in text
        assert "source_completeness_invalid_url_count_matched" in text
        assert "source_url_scheme_row_count_total_matched" in text
        assert "source_url_domain_row_count_total_matched" in text
        assert "convention_rows" in text
        assert "convention_metadata_rows" in text
        assert "convention_metadata_name_rows" in text
        assert "convention_metadata_without_name_count" in text
        assert "convention_metadata_without_name_rows" in text
        assert "known_limitations_rows" in text
        assert "non-empty known-limitation text coverage" in text
        assert "non-empty list of non-empty strings" in text
        assert "validate_table_source_metadata_issue_paths=..." in text
        assert "validate_table_source_metadata_issue_messages=..." in text
        assert "table_source_metadata_summary_self_consistency" in text
        assert "table_correctness_certified=false" in text
        assert "external_source_verified=false" in text
        assert "does not" in text
    for field in [
        "analysis_validate_table_source_metadata_source_completeness_row_count",
        "analysis_validate_table_source_metadata_source_completeness_row_count_matched_count",
        "analysis_validate_table_source_metadata_source_completeness_source_count_matched_count",
        "analysis_validate_table_source_metadata_source_completeness_source_url_count_matched_count",
        "analysis_validate_table_source_metadata_source_completeness_invalid_url_count_matched_count",
    ]:
        assert field in report_schema
    assert (
        "validate_table_source_metadata_all_conventions_match_expected"
        in report_schema
    )
    assert (
        "analysis_validate_table_source_metadata_all_conventions_match_expected_count"
        in report_schema
    )
