from __future__ import annotations

import importlib.util

import numpy as np
import pytest

from iroll import Link3D, Polyline3D
from iroll.kernels import compute_gaussian_linking_number, compute_writhe
from iroll.topology import (
    analyze_curve,
    analyze_link,
    builtin_link_table,
    builtin_knot_table,
    classify_curve,
    classify_link,
    classify_curve_multi_projection,
    close_curve,
    find_curve_crossings,
    iter_closed_curves,
    linking_matrix,
    lookup_link,
    mirror_laurent_polynomial,
)
from iroll.topology.projection import project_points
from tests.fixtures import (
    circle_points,
    figure_eight_points,
    helix_points,
    hopf_link_points,
    trefoil_points,
)


def test_projection_with_explicit_direction() -> None:
    curve = Polyline3D(circle_points(count=32), closed=True)
    projection = project_points(curve.points, direction=[0.0, 0.0, 1.0])

    assert projection.points2d.shape == (32, 2)
    assert np.allclose(projection.depth, 0.0)
    assert np.allclose(projection.direction, [0.0, 0.0, 1.0])


def test_self_crossing_detection_skips_adjacent_segments() -> None:
    points = np.array(
        [
            [-1.0, -1.0, 1.0],
            [1.0, 1.0, 1.0],
            [-1.0, 1.0, -1.0],
            [1.0, -1.0, -1.0],
        ]
    )
    curve = Polyline3D(points, closed=True)
    crossings = find_curve_crossings(curve, direction=[0.0, 0.0, 1.0])

    assert len(crossings) == 1
    assert crossings[0].over_component == 0


def test_gpu_self_crossing_detection_matches_numpy_when_installed() -> None:
    if importlib.util.find_spec("iroll_kernels_gpu") is None:
        pytest.skip("GPU kernels are not installed in this environment")

    points = np.array(
        [
            [-1.0, -1.0, 1.0],
            [1.0, 1.0, 1.0],
            [-1.0, 1.0, -1.0],
            [1.0, -1.0, -1.0],
        ]
    )
    curve = Polyline3D(points, closed=True)

    numpy_crossings = find_curve_crossings(
        curve,
        direction=[0.0, 0.0, 1.0],
        backend="numpy",
    )
    gpu_crossings = find_curve_crossings(
        curve,
        direction=[0.0, 0.0, 1.0],
        backend="gpu",
    )

    assert len(gpu_crossings) == len(numpy_crossings) == 1
    assert gpu_crossings[0].component_a == numpy_crossings[0].component_a
    assert gpu_crossings[0].segment_a == numpy_crossings[0].segment_a
    assert gpu_crossings[0].component_b == numpy_crossings[0].component_b
    assert gpu_crossings[0].segment_b == numpy_crossings[0].segment_b
    assert gpu_crossings[0].over_component == numpy_crossings[0].over_component
    assert gpu_crossings[0].over_segment == numpy_crossings[0].over_segment
    assert gpu_crossings[0].sign == numpy_crossings[0].sign
    assert np.allclose(gpu_crossings[0].point2d, numpy_crossings[0].point2d)


def test_rust_self_crossing_detection_matches_numpy_when_installed() -> None:
    if importlib.util.find_spec("iroll_kernels_rust") is None:
        pytest.skip("Rust kernels are not installed in this environment")

    points = np.array(
        [
            [-1.0, -1.0, 1.0],
            [1.0, 1.0, 1.0],
            [-1.0, 1.0, -1.0],
            [1.0, -1.0, -1.0],
        ]
    )
    curve = Polyline3D(points, closed=True)

    numpy_crossings = find_curve_crossings(
        curve,
        direction=[0.0, 0.0, 1.0],
        backend="numpy",
    )
    rust_crossings = find_curve_crossings(
        curve,
        direction=[0.0, 0.0, 1.0],
        backend="rust",
    )

    assert len(rust_crossings) == len(numpy_crossings) == 1
    assert rust_crossings[0].component_a == numpy_crossings[0].component_a
    assert rust_crossings[0].segment_a == numpy_crossings[0].segment_a
    assert rust_crossings[0].component_b == numpy_crossings[0].component_b
    assert rust_crossings[0].segment_b == numpy_crossings[0].segment_b
    assert rust_crossings[0].over_component == numpy_crossings[0].over_component
    assert rust_crossings[0].over_segment == numpy_crossings[0].over_segment
    assert rust_crossings[0].sign == numpy_crossings[0].sign
    assert np.allclose(rust_crossings[0].point2d, numpy_crossings[0].point2d)


def test_hopf_linking_matrix_from_crossings() -> None:
    first, second = hopf_link_points(count=256)
    link = Link3D(
        [
            Polyline3D(first, closed=True, name="first"),
            Polyline3D(second, closed=True, name="second"),
        ]
    )

    matrix = linking_matrix(link, direction=[0.3, 0.5, 1.0])

    assert matrix.shape == (2, 2)
    assert np.allclose(np.diag(matrix), 0.0)
    assert abs(matrix[0, 1]) == 1.0


def test_gaussian_linking_number_matches_hopf_orientation_approximately() -> None:
    first, second = hopf_link_points(count=2048)
    value = compute_gaussian_linking_number(first, second)

    assert np.isclose(abs(value), 1.0, rtol=0.05)


def test_planar_circle_writhe_is_zero() -> None:
    value = compute_writhe(circle_points(count=256), closed=True)

    assert abs(value) < 1e-12


def test_mirror_curve_flips_writhe_sign() -> None:
    points = helix_points(count=256)
    mirrored = points.copy()
    mirrored[:, 0] *= -1.0

    value = compute_writhe(points, closed=False)
    mirrored_value = compute_writhe(mirrored, closed=False)

    assert np.isclose(value, -mirrored_value, rtol=1e-8, atol=1e-10)


def test_analyze_curve_returns_json_friendly_topology_report() -> None:
    curve = Polyline3D(circle_points(count=64), closed=True, name="circle")
    report = analyze_curve(curve, direction=[0.0, 0.0, 1.0])

    assert report["input"]["name"] == "circle"
    assert report["topology"]["crossing_count"] == 0
    assert report["topology"]["classification"]["knot_type"] == "unknot"


def test_analyze_link_returns_linking_matrix() -> None:
    first, second = hopf_link_points(count=128)
    link = Link3D([Polyline3D(first, closed=True), Polyline3D(second, closed=True)])
    report = analyze_link(link, direction=[0.3, 0.5, 1.0])

    assert report["input"]["component_count"] == 2
    assert abs(report["topology"]["linking_matrix"][0][1]) == 1.0
    assert report["topology"]["link_type"] == "hopf_link"
    assert report["topology"]["classification"]["link_type"] == "hopf_link"
    assert len(report["topology"]["component_reports"]) == 2


def test_classify_link_identifies_hopf_and_unlink_mvp() -> None:
    first, second = hopf_link_points(count=128)
    hopf = Link3D([Polyline3D(first, closed=True), Polyline3D(second, closed=True)])

    hopf_result = classify_link(hopf, direction=[0.3, 0.5, 1.0])

    assert hopf_result.link_type == "hopf_link"
    assert hopf_result.pairwise_linking[0]["abs_linking_number"] == 1.0
    assert all(
        report["knot_type"] == "unknot"
        for report in hopf_result.to_dict()["component_reports"]
    )
    hopf_payload = hopf_result.to_dict()
    assert hopf_payload["invariants"]["homfly"]["method"] == "signed_pd_fixture_comparison"
    assert hopf_payload["invariants"]["homfly"]["skipped"] is False
    assert (
        hopf_payload["invariants"]["multivariable_alexander"]["method"]
        == "fox_square_minor_disjoint_support_gcd"
    )
    assert (
        hopf_payload["invariants"]["multivariable_alexander"][
            "multivariable_alexander_polynomial"
        ]
        == "1"
    )

    shifted = circle_points(count=128).copy()
    shifted[:, 0] += 3.0
    unlink = Link3D(
        [
            Polyline3D(circle_points(count=128), closed=True),
            Polyline3D(shifted, closed=True),
        ]
    )

    unlink_result = classify_link(unlink, direction=[0.0, 0.0, 1.0])

    assert unlink_result.link_type == "unlink"
    assert unlink_result.method == "pairwise_linking_number+axis_aligned_split"
    assert unlink_result.split_evidence["axis"] == "x"
    assert unlink_result.pairwise_linking[0]["abs_linking_number"] == 0.0
    assert "zero pairwise linking does not prove a general unlink" in unlink_result.notes


def test_zero_pairwise_linking_without_split_evidence_is_candidate() -> None:
    first = circle_points(count=128)
    second = circle_points(count=128).copy()
    second[:, 0] += 1.5
    second[:, 1] += 1.5
    link = Link3D([Polyline3D(first, closed=True), Polyline3D(second, closed=True)])

    result = classify_link(link, direction=[0.0, 0.0, 1.0])

    assert result.link_type == "pairwise_unlink_candidate"
    assert result.split_evidence is None
    assert result.pairwise_linking[0]["abs_linking_number"] == 0.0
    assert "no simple split-link evidence was found" in result.notes
    payload = result.to_dict()
    assert {candidate["link_type"] for candidate in payload["table_candidates"]} >= {
        "unlink",
        "whitehead_link",
    }
    summary = payload["table_candidate_summary"]
    assert summary["method"] == "link_table_candidate_summary"
    assert summary["candidate_count"] == len(payload["table_candidates"])
    assert summary["nontrivial_candidate_count"] >= 1
    assert "whitehead_link" in summary["nontrivial_link_types"]
    assert "L5a1" in summary["nontrivial_notations"]
    assert summary["source_table_invariant_audit_available_count"] >= 1
    assert summary["source_table_invariant_audit_summary_count"] >= 1
    assert summary["source_table_nontrivial_candidate_count"] >= 1
    assert "L5a1" in summary["source_table_nontrivial_candidate_notations"]
    assert summary["source_table_distinguishing_evidence_available"] is True
    assert summary["stronger_invariants_required"] is True
    assert summary["source_table_registration_blocked_count"] >= 1
    assert summary["source_table_registration_blocker_count"] >= 1
    assert summary["source_table_registration_blocker_code_count"] == 4
    assert summary["source_table_registration_blocker_codes"] == [
        "fixture_signs_not_registered",
        "registered_fixture_invariant_claim_disabled",
        "source_compatible_sign_pattern_not_unique",
        "source_table_values_uncomputed",
    ]
    assert summary["source_table_registration_blocker_code_counts"] == [
        {"code": "fixture_signs_not_registered", "count": 1},
        {"code": "registered_fixture_invariant_claim_disabled", "count": 1},
        {"code": "source_compatible_sign_pattern_not_unique", "count": 1},
        {"code": "source_table_values_uncomputed", "count": 1},
    ]
    assert summary["source_table_registration_blocker_count_signature"] == (
        "fixture_signs_not_registered:1,"
        "registered_fixture_invariant_claim_disabled:1,"
        "source_compatible_sign_pattern_not_unique:1,"
        "source_table_values_uncomputed:1"
    )
    assert summary["source_table_homfly_variant_resolution_statuses"] == [
        "not_computed"
    ]
    assert summary["source_table_source_match_resolution_status_count"] == 3
    assert set(summary["source_table_source_match_resolution_statuses"]) == {
        "L5a1:jones:source_seen_with_incomplete_candidates",
        "L5a1:homfly:not_computed",
        "L5a1:multivariable_alexander_numerator:source_seen_with_incomplete_candidates",
    }
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_candidate_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_min"
        ]
        == 10
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max"
        ]
        == 10
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed_summary_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min"
        ]
        == 25
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max"
        ]
        == 25
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_checked_candidate_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_source_divides_all_candidate_count"
        ]
        == 0
    )
    assert (
        summary[
            "source_table_alexander_source_divisibility_source_division_failed_candidate_count"
        ]
        == 8
    )
    assert "whitehead_link" in summary["link_types"]
    assert "L5a1" in summary["source_table_audit_notations"]
    assert summary["ambiguous"] is True
    whitehead = next(
        candidate
        for candidate in payload["table_candidates"]
        if candidate["link_type"] == "whitehead_link"
    )
    assert whitehead["source_table_invariant_audit_available"] is True
    assert whitehead["source_table_jones_iroll_normalized"] == (
        "t^-2 - 2t^-1 + 1 - 2t + t^2 - t^3"
    )
    audit_summary = whitehead["source_table_invariant_audit_summary"]
    assert audit_summary["method"] == "diagram_fixture_source_table_invariant_audit_summary"
    assert audit_summary["registered_fixture_invariant_claim"] is False
    assert audit_summary["complete_candidate_set"] is True
    assert audit_summary["source_match_resolution_statuses"]["jones"] == (
        "source_seen_with_incomplete_candidates"
    )
    assert audit_summary["source_match_resolution_statuses"]["homfly"] == (
        "not_computed"
    )
    assert audit_summary["source_table_candidate_count"] == 24
    assert audit_summary["source_table_top_candidate_unique_sign_pattern_count"] == 6
    assert audit_summary["source_table_registration_ready"] is False
    assert "source_table_values_uncomputed" in audit_summary[
        "source_table_registration_blockers"
    ]
    assert (
        audit_summary[
            "source_table_alexander_skipped_common_gcd_attempt_candidate_count"
        ]
        == 8
    )
    assert audit_summary[
        "source_table_alexander_skipped_common_gcd_attempt_statuses"
    ] == ["not_certified"]
    assert (
        audit_summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count"
        ]
        == 8
    )
    assert (
        audit_summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_min"
        ]
        == 10
    )
    assert (
        audit_summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max"
        ]
        == 10
    )
    assert (
        audit_summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed"
        ]
        is True
    )
    assert (
        audit_summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 8
    )
    assert (
        audit_summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count"
        ]
        == 1
    )
    assert (
        audit_summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min"
        ]
        == 25
    )
    assert (
        audit_summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max"
        ]
        == 25
    )
    assert (
        audit_summary[
            "source_table_alexander_source_divisibility_checked_candidate_count"
        ]
        == 8
    )
    assert (
        audit_summary[
            "source_table_alexander_source_divisibility_source_division_failed_candidate_count"
        ]
        == 8
    )
    assert audit_summary[
        "source_table_alexander_source_divisibility_statuses"
    ] == ["source_does_not_divide_all_inputs"]
    assert whitehead["homfly_polynomial"] is None
    assert whitehead["multivariable_alexander_polynomial"] is None
    assert any("nontrivial links" in note for note in payload["notes"])


def test_three_component_zero_pairwise_candidate_exposes_borromean_source_summary() -> None:
    components = []
    for dx, dy in [(0.0, 0.0), (1.5, 1.5), (-1.5, 1.5)]:
        points = circle_points(count=96).copy()
        points[:, 0] += dx
        points[:, 1] += dy
        components.append(Polyline3D(points, closed=True))
    link = Link3D(components)

    result = classify_link(
        link,
        direction=[0.0, 0.0, 1.0],
        linking_matrix_values=np.zeros((3, 3)),
    ).to_dict()

    assert result["link_type"] == "pairwise_unlink_candidate"
    assert result["split_evidence"] is None
    assert result["table_candidate_summary"]["source_table_matched_invariant_count"] == 2
    assert result["table_candidate_summary"]["source_table_uncomputed_invariant_count"] == 1
    assert result["table_candidate_summary"]["source_table_top_candidate_count"] == 8
    assert result["table_candidate_summary"]["nontrivial_link_types"] == [
        "borromean_rings"
    ]
    assert result["table_candidate_summary"]["nontrivial_notations"] == ["L6a4"]
    assert result["table_candidate_summary"]["source_table_nontrivial_candidate_count"] == 1
    assert result["table_candidate_summary"][
        "source_table_nontrivial_candidate_notations"
    ] == ["L6a4"]
    assert (
        result["table_candidate_summary"][
            "source_table_distinguishing_evidence_available"
        ]
        is True
    )
    assert result["table_candidate_summary"]["stronger_invariants_required"] is True
    assert result["table_candidate_summary"][
        "source_table_registration_blocker_codes"
    ] == [
        "fixture_signs_not_registered",
        "registered_fixture_invariant_claim_disabled",
        "source_compatible_sign_pattern_not_unique",
        "source_table_values_uncomputed",
    ]
    assert result["table_candidate_summary"][
        "source_table_registration_blocker_code_counts"
    ] == [
        {"code": "fixture_signs_not_registered", "count": 1},
        {"code": "registered_fixture_invariant_claim_disabled", "count": 1},
        {"code": "source_compatible_sign_pattern_not_unique", "count": 1},
        {"code": "source_table_values_uncomputed", "count": 1},
    ]
    assert (
        result["table_candidate_summary"][
            "source_table_registration_blocker_count_signature"
        ]
        == "fixture_signs_not_registered:1,"
        "registered_fixture_invariant_claim_disabled:1,"
        "source_compatible_sign_pattern_not_unique:1,"
        "source_table_values_uncomputed:1"
    )
    assert (
        result["table_candidate_summary"][
            "source_table_alexander_source_divisibility_checked_candidate_count"
        ]
        == 0
    )
    assert (
        result["table_candidate_summary"][
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count"
        ]
        == 0
    )
    assert (
        result["table_candidate_summary"][
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 0
    )
    assert result["table_candidate_summary"]["source_table_audit_notations"] == ["L6a4"]
    assert (
        result["table_candidate_summary"][
            "source_table_source_match_resolution_status_count"
        ]
        == 3
    )
    assert set(
        result["table_candidate_summary"][
            "source_table_source_match_resolution_statuses"
        ]
    ) == {
        "L6a4:jones:complete_source_match",
        "L6a4:homfly:not_computed",
        "L6a4:multivariable_alexander_numerator:complete_source_match",
    }
    borromean = next(
        candidate
        for candidate in result["table_candidates"]
        if candidate["link_type"] == "borromean_rings"
    )
    audit_summary = borromean["source_table_invariant_audit_summary"]
    assert audit_summary["matched_source_table_invariants"] == [
        "jones",
        "multivariable_alexander_numerator",
    ]
    assert audit_summary["uncomputed_source_table_invariants"] == ["homfly"]
    assert audit_summary["source_match_resolution_statuses"] == {
        "jones": "complete_source_match",
        "homfly": "not_computed",
        "multivariable_alexander_numerator": "complete_source_match",
    }
    assert audit_summary["source_table_candidate_count"] == 8
    assert audit_summary["source_table_top_candidate_unique_sign_pattern_count"] == 8
    assert audit_summary["source_table_registration_ready"] is False
    assert (
        audit_summary[
            "source_table_alexander_source_divisibility_checked_candidate_count"
        ]
        == 0
    )
    assert (
        audit_summary[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count"
        ]
        == 0
    )
    assert (
        audit_summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 0
    )


def test_classify_trefoil_by_determinant() -> None:
    curve = Polyline3D(trefoil_points(), closed=True)
    result = classify_curve(curve, direction=[0.0, 0.0, 1.0])

    assert result.knot_type == "trefoil"
    assert result.notation == "3_1"
    assert result.determinant == 3
    assert result.alexander_polynomial is not None
    assert result.table_match["notation"] == "3_1"
    assert result.chirality in {"positive", "negative"}
    assert result.jones_polynomial is not None
    assert result.jones_method == "built_in_knot_table_chirality"


def test_classify_figure_eight_by_determinant() -> None:
    curve = Polyline3D(figure_eight_points(), closed=True)
    result = classify_curve(curve, direction=[0.3, 0.5, 1.0])

    assert result.knot_type == "figure_eight"
    assert result.notation == "4_1"
    assert result.determinant == 5
    assert result.alexander_polynomial is not None
    assert result.table_match["notation"] == "4_1"
    assert result.chirality == "achiral"
    assert result.jones_polynomial == "t^-2 - t^-1 + 1 - t + t^2"
    assert result.jones_method == "built_in_knot_table"


def test_mirror_trefoil_flips_chirality() -> None:
    curve = Polyline3D(trefoil_points(), closed=True)
    mirrored_points = curve.points.copy()
    mirrored_points[:, 0] *= -1.0
    mirrored = Polyline3D(mirrored_points, closed=True)

    original = classify_curve(curve, direction=[0.0, 0.0, 1.0])
    mirror = classify_curve(mirrored, direction=[0.0, 0.0, 1.0])

    assert original.knot_type == mirror.knot_type == "trefoil"
    assert {original.chirality, mirror.chirality} == {"positive", "negative"}
    assert original.jones_polynomial == mirror_laurent_polynomial(mirror.jones_polynomial)


def test_builtin_knot_table_contains_mvp_entries() -> None:
    entries = builtin_knot_table()

    assert {entry["notation"] for entry in entries} >= {
        "0_1",
        "3_1",
        "4_1",
        "5_1",
        "5_2",
        "6_1",
        "6_2",
        "6_3",
    }
    assert all("jones_polynomial" in entry for entry in entries)
    assert all("source" in entry for entry in entries)


def test_builtin_link_table_contains_post_mvp_entries() -> None:
    entries = builtin_link_table()

    assert {entry["link_type"] for entry in entries} >= {
        "hopf_link",
        "unlink",
        "whitehead_link",
        "borromean_rings",
        "solomon_link",
    }
    whitehead = lookup_link(link_type="whitehead_link")
    borromean = lookup_link(link_type="borromean_rings")
    assert whitehead.notation == "L5a1"
    assert whitehead.to_dict()["source_table_invariant_audit_available"] is True
    assert whitehead.to_dict()["source_table_homfly"] is not None
    assert whitehead.to_dict()["homfly_polynomial"] is None
    assert borromean.to_dict()["source_table_multivariable_alexander_numerator"] == (
        "1 - t3 - t2 + t2*t3 - t1 + t1*t3 + t1*t2 - t1*t2*t3"
    )
    assert borromean.to_dict()["multivariable_alexander_polynomial"] is None


def test_multi_projection_classification_reports_vote_distribution() -> None:
    curve = Polyline3D(trefoil_points(), closed=True)
    vote = classify_curve_multi_projection(curve)

    assert vote.selected.knot_type == "trefoil"
    assert vote.distribution["trefoil"] > 0.5
    assert vote.stable is True


def test_direct_closure_returns_closed_curve() -> None:
    open_curve = Polyline3D(trefoil_points()[20:-20], closed=False)
    closed_curve = close_curve(open_curve, method="direct")

    assert closed_curve.closed is True
    assert closed_curve.point_count == open_curve.point_count


def test_random_sphere_closure_is_reproducible() -> None:
    open_curve = Polyline3D(trefoil_points()[20:-20], closed=False)
    first = list(iter_closed_curves(open_curve, method="random_sphere", samples=3, seed=7))
    second = list(iter_closed_curves(open_curve, method="random_sphere", samples=3, seed=7))

    assert len(first) == 3
    assert all(curve.closed for curve in first)
    assert all(np.allclose(a.points, b.points) for a, b in zip(first, second))


def test_analyze_open_curve_with_closure_distribution() -> None:
    open_curve = Polyline3D(trefoil_points()[20:-20], closed=False, name="open-trefoil")
    report = analyze_curve(
        open_curve,
        closure={"method": "random_sphere", "samples": 5, "seed": 11},
        direction=[0.0, 0.0, 1.0],
    )

    closure = report["topology"]["closure"]

    assert closure["method"] == "random_sphere"
    assert closure["samples"] == 5
    assert sum(closure["distribution"].values()) == 1.0
    assert report["topology"]["classification"]["method"] == "closure:random_sphere"
