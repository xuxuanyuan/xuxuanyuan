from __future__ import annotations

import json
import math
from pathlib import Path
import subprocess
import sys

from iroll import Polyline3D
from iroll.reports import validate_report
from iroll.topology import analyze_curve
from iroll.viewer import render_report_html, write_report_html
from tests.fixtures import circle_points


def test_render_report_html_contains_summary_and_payload() -> None:
    report = analyze_curve(
        Polyline3D(circle_points(count=64), closed=True, name="circle"),
        direction=[0.0, 0.0, 1.0],
        backend="numpy",
    )

    html = render_report_html(report, title="Circle report")

    assert "<!doctype html>" in html
    assert "Circle report" in html
    assert "unknot" in html
    assert "report-json" in html


def test_write_report_html_creates_file(tmp_path: Path) -> None:
    report = analyze_curve(
        Polyline3D(circle_points(count=64), closed=True),
        direction=[0.0, 0.0, 1.0],
        backend="numpy",
    )

    output = write_report_html(report, tmp_path / "report.html")

    assert output.exists()
    assert "iroll report" in output.read_text(encoding="utf-8")


def test_render_report_html_rejects_non_finite_payload() -> None:
    try:
        render_report_html({"version": "0.1.0", "topology": {"writhe": math.nan}})
    except ValueError as exc:
        assert "Out of range float values" in str(exc)
    else:
        raise AssertionError("render_report_html accepted non-finite JSON")


def test_standalone_ui_viewer_and_sample_report_are_present() -> None:
    html = Path("ui/report-viewer.html").read_text(encoding="utf-8")
    report = json.loads(Path("examples/curve-report.sample.json").read_text(encoding="utf-8"))

    assert 'type="file"' in html
    assert 'id="viewer"' in html
    assert "webgl" in html.lower()
    assert validate_report(report, kind="curve") == []


def test_standalone_ui_viewer_is_report_only_without_recompute() -> None:
    html = Path("ui/report-viewer.html").read_text(encoding="utf-8")
    ui_plan = Path("docs/ui-plan.md").read_text(encoding="utf-8")

    report_only_tokens = [
        'id="file-input"',
        "JSON.parse(await file.text())",
        "extractComponents(report)",
        "summaryRows(report, components)",
        "JSON.stringify(report, null, 2)",
        "gl.drawArrays(gl.LINE_STRIP",
    ]
    for token in report_only_tokens:
        assert token in html

    forbidden_runtime_tokens = [
        "fetch(",
        "XMLHttpRequest",
        "Worker(",
        "WebSocket",
        "analyze_curve",
        "analyzeLink",
        "computeWrithe",
        "computeLinking",
        "homfly",
        "alexander",
    ]
    for token in forbidden_runtime_tokens:
        assert token not in html

    docs_tokens = [
        "does not recompute topology",
        "mutate report values",
        "loads iroll",
        "report JSON files from a file picker",
    ]
    for token in docs_tokens:
        assert token in ui_plan


def test_ui_plan_keeps_imgui_framebuffer_stub_non_claim_boundary() -> None:
    ui_plan = Path("docs/ui-plan.md").read_text(encoding="utf-8")
    fixture_source = Path("src/iroll/topology/pd_fixtures.py").read_text(
        encoding="utf-8"
    )
    status = Path("docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    required_tokens = [
        "production_imgui_renderer_framebuffer_pack",
        "Repository stub draw-list",
        "framebuffer-estimate smokes",
        "retained reviewer evidence only",
        "real graphics-backend screenshot/framebuffer verification",
        "do not",
        "close the\nproduction renderer gate",
    ]
    for token in required_tokens:
        assert token in ui_plan

    assert "production_imgui_renderer_framebuffer_pack" in fixture_source
    assert "production ImGui framebuffer verification" in status
    assert "`docs/ui-plan.md` now names" in status
    assert "not production renderer gate closure" in status


def test_static_report_viewer_entrypoints_are_documented() -> None:
    cli_source = Path("src/iroll/cli.py").read_text(encoding="utf-8")
    viewer_source = Path("src/iroll/viewer.py").read_text(encoding="utf-8")
    ui_plan = Path("docs/ui-plan.md").read_text(encoding="utf-8")
    roadmap = Path("docs/deep-completion-roadmap.md").read_text(encoding="utf-8")
    audit = Path("docs/post-mvp-completion-audit.md").read_text(encoding="utf-8")

    assert '"render-report"' in cli_source
    assert "write_report_html" in cli_source
    assert "Render a JSON report to static HTML." in cli_source

    for token in ("render_report_html", "write_report_html", "report-json"):
        assert token in viewer_source
    assert "dump_report(report)" in viewer_source

    assert "ui/report-viewer.html" in ui_plan
    assert "standalone WebGL prototype" in ui_plan
    assert "shared strict JSON report writer boundary" in ui_plan
    assert "non-finite `NaN`/`Infinity` values are rejected" in ui_plan
    for docs in (roadmap, audit):
        assert "static HTML report renderer" in docs
        assert "`iroll render-report`" in docs
        assert "standalone WebGL report-viewer prototype" in docs


def test_static_report_viewer_summary_fields_are_documented() -> None:
    viewer_source = Path("src/iroll/viewer.py").read_text(encoding="utf-8")
    ui_plan = Path("docs/ui-plan.md").read_text(encoding="utf-8")

    renderer_tokens = [
        "render_report_html",
        "Report kind:",
        "report-json",
        "_summary_lines",
    ]
    for token in renderer_tokens:
        assert token in viewer_source
        assert token in ui_plan

    summary_field_tokens = [
        "version",
        "name",
        "knot_type",
        "link_type",
        "writhe",
        "twist",
        "crossing_count",
    ]
    for token in summary_field_tokens:
        assert token in viewer_source
        assert token in ui_plan

    assert "raw JSON payload" in ui_plan


def test_imgui_geometry_sample_generator_matches_committed_payload() -> None:
    generator_source = Path("examples/generate_imgui_geometry_payload.py").read_text(
        encoding="utf-8"
    )
    sample = json.loads(
        Path("examples/imgui-geometry-payload.sample.json").read_text(
            encoding="utf-8"
        )
    )

    result = subprocess.run(
        [sys.executable, "examples/generate_imgui_geometry_payload.py"],
        text=True,
        capture_output=True,
        check=False,
    )

    assert result.returncode == 0, result.stdout + result.stderr
    assert json.loads(result.stdout) == sample
    assert "from iroll.io import dump_report" in generator_source
    assert "dump_report(payload)" in generator_source


def test_imgui_host_sample_generator_matches_committed_payload() -> None:
    generator_source = Path("examples/generate_imgui_host_payload.py").read_text(
        encoding="utf-8"
    )
    sample = json.loads(
        Path("examples/imgui-host-payload.sample.json").read_text(
            encoding="utf-8"
        )
    )

    result = subprocess.run(
        [sys.executable, "examples/generate_imgui_host_payload.py"],
        text=True,
        capture_output=True,
        check=False,
    )

    assert result.returncode == 0, result.stdout + result.stderr
    assert json.loads(result.stdout) == sample
    assert "from iroll.io import dump_report" in generator_source
    assert "dump_report(payload)" in generator_source
