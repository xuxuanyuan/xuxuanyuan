from __future__ import annotations

import numpy as np
import pytest

from iroll import Polyline3D, Ribbon3D
from iroll.topology import analyze_ribbon, compute_twist
from tests.fixtures import circle_points


def straight_ribbon_points(count: int = 200) -> tuple[np.ndarray, np.ndarray]:
    x = np.linspace(0.0, 1.0, count)
    points = np.column_stack([x, np.zeros_like(x), np.zeros_like(x)])
    return points, x


def rotating_directors(turns: float, count: int = 200) -> np.ndarray:
    _, x = straight_ribbon_points(count)
    angle = 2.0 * np.pi * turns * x
    return np.column_stack([np.zeros_like(angle), np.cos(angle), np.sin(angle)])


def test_ribbon_validates_director_shape() -> None:
    curve = Polyline3D(circle_points(count=32), closed=True)

    with pytest.raises(ValueError, match="same shape"):
        Ribbon3D(curve, np.ones((31, 3)))


def test_straight_ribbon_with_constant_director_has_zero_twist() -> None:
    points, _ = straight_ribbon_points()
    directors = np.tile([0.0, 1.0, 0.0], (len(points), 1))
    ribbon = Ribbon3D(Polyline3D(points), directors)

    assert abs(ribbon.twist()) < 1e-12


def test_straight_ribbon_with_two_director_turns_has_twist_two() -> None:
    points, _ = straight_ribbon_points()
    directors = rotating_directors(turns=2.0, count=len(points))

    value = compute_twist(points, directors, closed=False)

    assert np.isclose(value, 2.0, rtol=1e-6)


def test_analyze_ribbon_reports_twist_writhe_and_linking_estimate() -> None:
    points, _ = straight_ribbon_points()
    ribbon = Ribbon3D(
        Polyline3D(points, name="axis"),
        rotating_directors(turns=1.0, count=len(points)),
        name="one-turn",
    )
    report = analyze_ribbon(ribbon, backend="numpy")

    assert report["input"]["name"] == "one-turn"
    assert np.isclose(report["topology"]["twist"], 1.0, rtol=1e-6)
    assert np.isclose(report["topology"]["writhe"], 0.0)
    assert np.isclose(report["topology"]["linking_estimate"], 1.0, rtol=1e-6)
