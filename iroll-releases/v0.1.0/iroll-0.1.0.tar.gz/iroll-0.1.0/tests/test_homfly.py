from __future__ import annotations

from collections import Counter
from copy import deepcopy

from iroll.topology import (
    get_diagram_fixture,
    homfly_certified_evaluation_from_pd,
    homfly_fixture_acceptance_report,
    homfly_fixture_comparison,
    homfly_input_certification_evidence,
    homfly_iterative_certified_evaluation_from_pd,
    homfly_mirror_fixture_comparison,
    homfly_mirror_polynomial,
    homfly_polynomial_convention_variants,
    homfly_skein_identity_audit_from_pd,
    homfly_small_diagram_coverage_report,
)
from iroll.topology.homfly import _homfly_generated_case_evidence_consistency_record


HOMFLY_COMPLETION_BLOCKERS = [
    "full_table_normalization_not_certified",
    "arbitrary_diagram_coverage_not_certified",
]

HOMFLY_COMPLETION_BLOCKER_DETAILS = [
    {
        "code": "full_table_normalization_not_certified",
        "severity": "blocking",
        "scope": "homfly_completion",
        "reason": "external HOMFLY table normalization has not been certified",
        "cap": {"full_table_normalization_certified": False},
    },
    {
        "code": "arbitrary_diagram_coverage_not_certified",
        "severity": "blocking",
        "scope": "homfly_completion",
        "reason": (
            "generated/input-scoped evidence does not certify arbitrary signed-PD coverage"
        ),
        "cap": {"arbitrary_diagram_coverage_certified": False},
    },
]


def _assert_homfly_completion_blockers(payload: dict) -> None:
    _assert_blocker_count_fields(payload, "homfly_completion")
    assert payload["homfly_completion_blockers"] == HOMFLY_COMPLETION_BLOCKERS
    assert payload["homfly_completion_blocker_count"] == len(
        HOMFLY_COMPLETION_BLOCKERS
    )
    details = payload["homfly_completion_blocker_details"]
    assert [row["code"] for row in details] == HOMFLY_COMPLETION_BLOCKERS
    assert details[0] == HOMFLY_COMPLETION_BLOCKER_DETAILS[0]
    arbitrary_detail = details[1]
    expected_arbitrary = HOMFLY_COMPLETION_BLOCKER_DETAILS[1]
    for key, expected_value in expected_arbitrary.items():
        assert arbitrary_detail[key] == expected_value
    if "arbitrary_diagram_completion_gate" in payload:
        gate = payload["arbitrary_diagram_completion_gate"]
        assert arbitrary_detail["witness"] == gate
        assert arbitrary_detail["provenance"] == gate[
            "completion_blocker_provenance"
        ]
        _assert_homfly_completion_blocker_provenance(
            arbitrary_detail["provenance"],
            gate,
            payload,
        )
        _assert_homfly_arbitrary_completion_gate(gate)
    else:
        assert "witness" not in arbitrary_detail
        assert "provenance" not in arbitrary_detail
    assert payload["homfly_completion_blocker_detail_count"] == len(
        details
    )


def _assert_homfly_completion_blocker_provenance(
    provenance: dict,
    gate: dict,
    payload: dict | None = None,
) -> None:
    pressure_consistency = gate["gate_pressure_consistency"]
    run_cap_pressure = gate["frontier_witness_summary"][
        "run_cap_frontier_pressure"
    ]
    expected_code = "arbitrary_diagram_coverage_not_certified"

    assert provenance["method"] == "homfly_completion_blocker_provenance"
    assert provenance["claim_scope"] == (
        "bounded_non_claim_completion_blocker_provenance"
    )
    assert provenance["matched"] is True
    assert provenance["completion_blocker_code"] == expected_code
    assert provenance["completion_blocker_detail"] == {
        "code": expected_code,
        "severity": "blocking",
        "scope": "homfly_completion",
        "expected_witness_field": "arbitrary_diagram_completion_gate",
        "expected_provenance_field": "completion_blocker_provenance",
    }
    assert provenance["completion_blocked"] is True
    assert provenance["arbitrary_diagram_coverage_certified"] is False
    assert provenance["non_claim_matched"] is True
    assert provenance["gate_pressure_consistency_matched"] is True
    assert provenance["frontier_pressure_counts_matched"] is True
    assert provenance["frontier_witness_consistency_matched"] is True
    assert provenance["certification_blocker_count_matched"] is True
    assert provenance["certification_blocker_detail_count_matched"] is True
    assert provenance["terminal_audit_consistency_matched"] is True
    assert provenance["terminal_mismatch_blocker_matched"] is True
    assert provenance["frontier_pressure"] == {
        "frontier_count": gate["frontier_count"],
        "visible_witness_count": gate["frontier_witness_count"],
        "missing_witness_count": pressure_consistency["missing_witness_count"],
        "frontier_reasons": gate["frontier_reasons"],
        "frontier_blocker_reasons": pressure_consistency[
            "frontier_blocker_reasons"
        ],
        "first_witness_reason": run_cap_pressure["first_witness_reason"],
        "first_unwitnessed_reason": run_cap_pressure[
            "first_unwitnessed_reason"
        ],
        "all_frontier_witnessed": run_cap_pressure["all_frontier_witnessed"],
        "reason_count": run_cap_pressure["reason_count"],
    }
    assert provenance["frontier_witness"] == {
        "frontier_witness_count": gate["frontier_witness_count"],
        "frontier_witness_limit": gate["frontier_witness_limit"],
        "frontier_witnesses_truncated": gate[
            "frontier_witnesses_truncated"
        ],
        "first_frontier_witness": gate["first_frontier_witness"],
    }
    assert provenance["terminal_contribution_audit"] == {
        "terminal_contribution_audit_applicable": gate[
            "terminal_contribution_audit_applicable"
        ],
        "terminal_contribution_audit_skipped": gate[
            "terminal_contribution_audit_skipped"
        ],
        "terminal_contribution_matches_result": gate[
            "terminal_contribution_matches_result"
        ],
        "terminal_audit_applicability_matched": pressure_consistency[
            "terminal_audit_applicability_matched"
        ],
        "terminal_mismatch_blocker_expected": pressure_consistency[
            "terminal_mismatch_blocker_expected"
        ],
        "terminal_mismatch_blocker_present": pressure_consistency[
            "terminal_mismatch_blocker_present"
        ],
        "terminal_mismatch_blocker_matched": pressure_consistency[
            "terminal_mismatch_blocker_matched"
        ],
    }
    assert provenance["certification_blocker_codes"] == gate[
        "certification_blockers"
    ]
    assert provenance["certification_blocker_count"] == gate[
        "certification_blocker_count"
    ]
    assert provenance["certification_blocker_detail_count"] == gate[
        "certification_blocker_detail_count"
    ]
    assert provenance["source_fields"] == [
        "arbitrary_diagram_completion_gate.blocked",
        "arbitrary_diagram_completion_gate.arbitrary_diagram_coverage_certified",
        "arbitrary_diagram_completion_gate.gate_pressure_consistency",
        "arbitrary_diagram_completion_gate.frontier_witness_summary.run_cap_frontier_pressure",
        "arbitrary_diagram_completion_gate.frontier_witnesses",
        "arbitrary_diagram_completion_gate.terminal_contribution_audit_applicable",
        "arbitrary_diagram_completion_gate.terminal_contribution_matches_result",
        "arbitrary_diagram_completion_gate.certification_blockers",
    ]
    assert "without certifying arbitrary signed-PD coverage" in (
        provenance["notes"][0]
    )

    if payload is not None:
        assert expected_code in payload["homfly_completion_blockers"]
        details = [
            detail
            for detail in payload["homfly_completion_blocker_details"]
            if detail["code"] == expected_code
        ]
        assert len(details) == 1
        assert details[0]["witness"] == gate
        assert details[0]["provenance"] == provenance


def _assert_homfly_arbitrary_completion_gate(gate: dict) -> None:
    assert gate["method"] == "homfly_arbitrary_signed_pd_completion_gate"
    assert gate["claim_scope"] == "arbitrary_signed_pd_homfly_completion_gate"
    assert gate["arbitrary_diagram_coverage_certified"] is False
    assert gate["blocked"] is True
    assert gate["frontier_reason_count"] == len(gate["frontier_reasons"])
    assert gate["frontier_witness_limit"] == 8
    assert gate["frontier_witness_count"] == len(gate["frontier_witnesses"])
    assert gate["first_frontier_witness"] == (
        gate["frontier_witnesses"][0] if gate["frontier_witnesses"] else None
    )
    assert gate["frontier_witnesses_truncated"] is (
        gate["frontier_count"] > gate["frontier_witness_count"]
    )
    _assert_homfly_frontier_witness_consistency(gate)
    pressure_consistency = gate["gate_pressure_consistency"]
    assert pressure_consistency["method"] == "homfly_gate_pressure_consistency"
    assert pressure_consistency["matched"] is True
    assert pressure_consistency["frontier_count"] == gate["frontier_count"]
    assert pressure_consistency["visible_witness_count"] == gate[
        "frontier_witness_count"
    ]
    assert pressure_consistency["missing_witness_count"] == max(
        gate["frontier_count"] - gate["frontier_witness_count"],
        0,
    )
    assert pressure_consistency["summary_counts_matched"] is True
    assert pressure_consistency["pressure_counts_matched"] is True
    assert pressure_consistency["pressure_flags_matched"] is True
    assert pressure_consistency["reason_counts_matched"] is True
    assert pressure_consistency["frontier_blocker_matched"] is True
    assert pressure_consistency["frontier_blocker_reason_matched"] is True
    assert pressure_consistency["truncation_blocker_matched"] is True
    assert pressure_consistency["blocker_counts_matched"] is True
    assert pressure_consistency["blocker_detail_counts_matched"] is True
    assert pressure_consistency["evidence_consistency_matched"] is True
    assert pressure_consistency["terminal_contribution_audit_applicable"] is gate[
        "terminal_contribution_audit_applicable"
    ]
    assert pressure_consistency["terminal_contribution_audit_skipped"] is gate[
        "terminal_contribution_audit_skipped"
    ]
    assert pressure_consistency["terminal_contribution_matches_result"] is gate[
        "terminal_contribution_matches_result"
    ]
    assert pressure_consistency["terminal_audit_applicability_matched"] is True
    assert pressure_consistency["terminal_mismatch_blocker_expected"] is (
        gate["terminal_contribution_audit_applicable"] is True
        and gate["terminal_contribution_matches_result"] is False
    )
    assert pressure_consistency["terminal_mismatch_blocker_present"] is (
        "terminal_contribution_mismatch" in gate["certification_blockers"]
    )
    assert pressure_consistency["terminal_mismatch_blocker_matched"] is True
    assert pressure_consistency["terminal_audit_consistency_matched"] is True
    assert pressure_consistency["completion_blocked"] is True
    assert pressure_consistency["arbitrary_diagram_coverage_certified"] is False
    assert pressure_consistency["expected_completion_blocker"] == (
        "arbitrary_diagram_coverage_not_certified"
    )
    assert pressure_consistency["non_claim_matched"] is True
    assert pressure_consistency["completion_blocker_provenance_matched"] is True
    _assert_homfly_completion_blocker_provenance(
        gate["completion_blocker_provenance"],
        gate,
    )
    if gate["frontier_count"] == 0:
        assert pressure_consistency["frontier_blocker_reasons"] == []
    else:
        assert pressure_consistency["frontier_blocker_reasons"]
    assert gate["certification_blocker_count"] == len(
        gate["certification_blockers"]
    )
    assert sum(
        row["blocker_count"] for row in gate["certification_blocker_code_counts"]
    ) == gate["certification_blocker_count"]
    assert sum(
        row["detail_count"]
        for row in gate["certification_blocker_detail_code_counts"]
    ) == gate["certification_blocker_detail_count"]
    assert gate["convention_blocker_count"] == len(gate["convention_blockers"])
    if gate["evidence_scope"] == "generated_small_signed_pd_coverage":
        assert gate["blocker_detail_code_count_consistency_matched"] is True
    assert gate["required_for_completion"] == [
        "external_table_normalization_certificate",
        "arbitrary_signed_pd_coverage_proof",
    ]
    assert "bounded input or generated-case evidence" in gate["notes"][0]


def _assert_blocker_count_fields(payload: dict, prefix: str) -> None:
    assert payload[f"{prefix}_blocker_count"] == len(payload[f"{prefix}_blockers"])
    assert payload[f"{prefix}_blocker_detail_count"] == len(
        payload[f"{prefix}_blocker_details"]
    )
    if f"{prefix}_blocker_code_counts" in payload:
        blocker_counts = Counter(str(code) for code in payload[f"{prefix}_blockers"])
        assert payload[f"{prefix}_blocker_code_counts"] == [
            {"code": code, "blocker_count": blocker_counts[code]}
            for code in sorted(blocker_counts)
        ]
    if f"{prefix}_blocker_detail_code_counts" in payload:
        detail_counts = Counter(
            str(row["code"])
            for row in payload[f"{prefix}_blocker_details"]
            if isinstance(row, dict) and row.get("code") is not None
        )
        assert payload[f"{prefix}_blocker_detail_code_counts"] == [
            {"code": code, "detail_count": detail_counts[code]}
            for code in sorted(detail_counts)
        ]


def _assert_blocker_detail_codes(payload: dict, key: str, codes: list[str]) -> None:
    details = payload[key]
    assert [row["code"] for row in details] == codes
    assert all(row["severity"] == "blocking" for row in details)
    assert all(row["reason"] for row in details)
    assert all("cap" in row or "witness" in row for row in details)


def _assert_solved_depth_counts(summary: dict, expected_case_count: int) -> None:
    rows = summary["solved_depth_counts"]
    assert sum(row["case_count"] for row in rows) == expected_case_count
    if expected_case_count == 0:
        assert rows == []
        assert summary["max_solved_depth"] is None
        return
    depths = [row["solved_depth"] for row in rows]
    assert depths == sorted(depths)
    assert depths[-1] == summary["max_solved_depth"]
    assert all(isinstance(depth, int) for depth in depths)
    assert all(row["case_count"] > 0 for row in rows)


def _frontier_reason_counts_from_cases(cases: list[dict]) -> list[dict]:
    case_counts: Counter[str] = Counter()
    frontier_counts: Counter[str] = Counter()
    for case in cases:
        frontier_count = int(case.get("frontier_count", 0) or 0)
        for reason in case.get("frontier_reasons", []):
            value = str(reason)
            case_counts[value] += 1
            frontier_counts[value] += frontier_count
    return [
        {
            "frontier_reason": value,
            "case_count": case_counts[value],
            "frontier_count": frontier_counts[value],
        }
        for value in sorted(case_counts)
    ]


def _homfly_optional_int(value) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _homfly_witness_path(witness: dict, *fields: str) -> list[str]:
    for field in fields:
        raw_path = witness.get(field)
        if isinstance(raw_path, list):
            return [str(step) for step in raw_path]
    return []


def _witness_count_records(counter: Counter, key: str) -> list[dict]:
    return [
        {key: value, "witness_count": counter[value]}
        for value in sorted(counter)
    ]


def _witness_path_prefix_records(counter: Counter) -> list[dict]:
    return [
        {"path_prefix": list(value), "witness_count": counter[value]}
        for value in sorted(counter)
    ]


def _frontier_reason_total_map(records: list[dict] | None) -> dict[str, int]:
    totals: dict[str, int] = {}
    for record in records or []:
        reason = record.get("frontier_reason", record.get("reason"))
        if reason is None:
            continue
        value = str(reason)
        totals[value] = totals.get(value, 0) + int(
            record.get("frontier_count", 0) or 0
        )
    return totals


def _expected_run_cap_frontier_pressure(
    payload: dict,
    witnesses: list[dict],
    reason_counts: Counter[str],
) -> dict:
    frontier_count = int(payload.get("frontier_count", 0) or 0)
    witness_count = len(witnesses)
    frontier_reason_totals = _frontier_reason_total_map(
        payload.get("frontier_reason_counts")
    )
    reason_records = []
    first_unwitnessed_reason = None
    for reason in sorted(set(reason_counts) | set(frontier_reason_totals)):
        reason_frontier_count = frontier_reason_totals.get(reason)
        reason_witness_count = reason_counts.get(reason, 0)
        reason_unwitnessed_count = (
            max(reason_frontier_count - reason_witness_count, 0)
            if reason in frontier_reason_totals
            else None
        )
        reason_all_witnessed = (
            reason_unwitnessed_count == 0
            if reason_unwitnessed_count is not None
            else None
        )
        if (
            first_unwitnessed_reason is None
            and reason_unwitnessed_count is not None
            and reason_unwitnessed_count > 0
        ):
            first_unwitnessed_reason = reason
        reason_records.append(
            {
                "reason": reason,
                "frontier_count": reason_frontier_count,
                "witness_count": reason_witness_count,
                "unwitnessed_frontier_count": reason_unwitnessed_count,
                "all_frontier_witnessed": reason_all_witnessed,
            }
        )
    unwitnessed_frontier_count = max(frontier_count - witness_count, 0)
    return {
        "frontier_count": frontier_count,
        "witness_count": witness_count,
        "unwitnessed_frontier_count": unwitnessed_frontier_count,
        "all_frontier_witnessed": unwitnessed_frontier_count == 0,
        "frontier_reason_counts_available": (
            frontier_count == 0 or bool(frontier_reason_totals)
        ),
        "first_witness_reason": (
            str(witnesses[0]["reason"])
            if witnesses and witnesses[0].get("reason")
            else None
        ),
        "first_unwitnessed_reason": first_unwitnessed_reason,
        "reason_counts": reason_records,
        "reason_count": len(reason_records),
    }


def _assert_homfly_frontier_witness_summary(payload: dict) -> None:
    summary = payload["frontier_witness_summary"]
    witnesses = [
        witness
        for witness in payload.get("frontier_witnesses", []) or []
        if isinstance(witness, dict)
    ]
    reason_counts: Counter[str] = Counter()
    source_kind_counts: Counter[str] = Counter()
    branch_counts: Counter[str] = Counter()
    recursive_path_prefix_counts: Counter[tuple[str, ...]] = Counter()
    branch_path_prefix_counts: Counter[tuple[str, ...]] = Counter()
    depths: list[int] = []
    branch_depths: list[int] = []

    for witness in witnesses:
        if witness.get("reason"):
            reason_counts[str(witness["reason"])] += 1
        if witness.get("source_kind") is not None:
            source_kind_counts[str(witness["source_kind"])] += 1
        if witness.get("branch") is not None:
            branch_counts[str(witness["branch"])] += 1
        depth = _homfly_optional_int(
            witness.get("recursive_depth", witness.get("depth"))
        )
        if depth is not None:
            depths.append(depth)
        branch_depth = _homfly_optional_int(witness.get("branch_depth"))
        if branch_depth is not None:
            branch_depths.append(branch_depth)
        recursive_path = _homfly_witness_path(witness, "recursive_path", "path")
        if recursive_path:
            recursive_path_prefix_counts[tuple(recursive_path[:2])] += 1
        branch_path = _homfly_witness_path(witness, "branch_path")
        if branch_path:
            branch_path_prefix_counts[tuple(branch_path[:2])] += 1

    assert summary["method"] == "homfly_frontier_witness_summary"
    assert summary["claim_scope"] == "capped_frontier_witness_diagnostics"
    assert summary["frontier_count"] == int(payload.get("frontier_count", 0) or 0)
    assert summary["witness_count"] == len(witnesses)
    assert summary["frontier_witness_limit"] == int(
        payload.get("frontier_witness_limit", 8) or 8
    )
    assert summary["witness_summary_truncated"] is bool(
        payload.get("frontier_witnesses_truncated", False)
    )
    assert summary["reason_counts"] == _witness_count_records(
        reason_counts,
        "reason",
    )
    assert summary["reason_count"] == len(reason_counts)
    assert summary["min_depth"] == (min(depths) if depths else None)
    assert summary["max_depth"] == (max(depths) if depths else None)
    assert summary["recursive_path_prefix_counts"] == (
        _witness_path_prefix_records(recursive_path_prefix_counts)
    )
    assert summary["recursive_path_prefix_count"] == len(
        recursive_path_prefix_counts
    )
    assert summary["source_kind_counts"] == _witness_count_records(
        source_kind_counts,
        "source_kind",
    )
    assert summary["source_kind_count"] == len(source_kind_counts)
    assert summary["branch_counts"] == _witness_count_records(
        branch_counts,
        "branch",
    )
    assert summary["branch_count"] == len(branch_counts)
    assert summary["min_branch_depth"] == (
        min(branch_depths) if branch_depths else None
    )
    assert summary["max_branch_depth"] == (
        max(branch_depths) if branch_depths else None
    )
    assert summary["branch_path_prefix_counts"] == (
        _witness_path_prefix_records(branch_path_prefix_counts)
    )
    assert summary["run_cap_frontier_pressure"] == (
        _expected_run_cap_frontier_pressure(
            payload,
            witnesses,
            reason_counts,
        )
    )
    assert "capped frontier_witnesses" in summary["notes"][0]


def _assert_homfly_frontier_witness_consistency(payload: dict) -> None:
    consistency = payload["frontier_witness_consistency"]
    witnesses = payload.get("frontier_witnesses", []) or []
    expected_first = witnesses[0] if witnesses else None

    _assert_homfly_frontier_witness_summary(payload)
    assert consistency["method"] == "homfly_frontier_witness_consistency"
    assert consistency["matched"] is True
    assert consistency["frontier_count"] == int(payload.get("frontier_count", 0) or 0)
    assert consistency["frontier_witness_count"] == payload[
        "frontier_witness_count"
    ]
    assert consistency["frontier_witness_list_count"] == len(witnesses)
    assert consistency["frontier_witness_limit"] == payload[
        "frontier_witness_limit"
    ]
    assert consistency["frontier_witnesses_truncated"] is payload[
        "frontier_witnesses_truncated"
    ]
    assert consistency["expected_first_frontier_witness"] == expected_first
    assert consistency["expected_frontier_witnesses_truncated_from_count"] is (
        payload.get("frontier_count", 0) > payload["frontier_witness_count"]
    )
    assert consistency["expected_frontier_witnesses_truncated_from_list"] is (
        payload.get("frontier_count", 0) > len(witnesses)
    )
    assert consistency["witness_count_matches_list_count"] is True
    assert consistency["witness_count_within_limit"] is True
    assert consistency["witness_list_count_within_limit"] is True
    assert consistency["first_frontier_witness_matches_list"] is True
    assert consistency["truncated_matches_witness_count"] is True
    assert consistency["truncated_matches_witness_list"] is True
    assert consistency["mismatch_count"] == 0
    assert consistency["first_mismatch"] is None
    assert consistency["mismatch_witnesses"] == []


def _assert_homfly_source_summary_consistency(report: dict) -> None:
    consistency = report["source_notation_summary_consistency"]
    assert consistency["method"] == "homfly_source_notation_summary_consistency"
    assert consistency["matched"] is True
    assert consistency["source_notation_count"] == len(
        report["source_notation_summary"]
    )
    assert consistency["source_notation_count_matches_fixture_count"] is True
    assert consistency["count_totals_matched"] is True
    assert consistency["distribution_totals_matched"] is True
    assert consistency["frontier_reason_counts_matched"] is True
    assert consistency["frontier_witness_summary_matched"] is True
    assert consistency["mismatch_count"] == 0
    assert consistency["first_mismatch"] is None
    assert consistency["mismatch_witnesses"] == []
    assert consistency["source_count_totals"]["case_count"] == report["case_count"]
    assert consistency["source_count_totals"]["frontier_count"] == report[
        "frontier_count"
    ]
    assert consistency["report_count_totals"]["frontier_case_count"] == report[
        "frontier_case_count"
    ]
    assert consistency["report_frontier_reason_counts"] == report[
        "frontier_reason_counts"
    ]
    assert consistency["source_frontier_reason_counts"] == report[
        "frontier_reason_counts"
    ]
    assert consistency["report_frontier_witness_summary"] == report[
        "frontier_witness_summary"
    ]
    assert consistency["source_frontier_witness_summary"] == report[
        "frontier_witness_summary"
    ]
    assert report["frontier_reason_counts"] == _frontier_reason_counts_from_cases(
        report["cases"]
    )
    _assert_homfly_frontier_witness_consistency(report)
    for row in report["source_notation_summary"]:
        _assert_homfly_frontier_witness_consistency(row)
    for field in (
        "solved_depth_counts",
        "branch_depth_counts",
        "certified_branch_depth_counts",
        "uncertified_branch_depth_counts",
        "frontier_branch_depth_counts",
        "truncated_branch_depth_counts",
        "source_kind_counts",
        "frontier_source_kind_counts",
        "truncated_source_kind_counts",
        "branch_counts",
        "frontier_branch_counts",
        "truncated_branch_counts",
    ):
        assert consistency["distribution_matches"][field] is True
        assert consistency["report_distribution_totals"][field] == report[field]
        assert consistency["source_distribution_totals"][field] == report[field]


def _assert_homfly_case_evidence_consistency(report: dict) -> None:
    consistency = report["case_evidence_consistency"]
    assert consistency["method"] == "homfly_generated_case_evidence_consistency"
    assert consistency["matched"] is True
    assert consistency["case_count"] == report["case_count"]
    assert consistency["checked_case_count"] == report["case_count"]
    assert consistency["missing_evidence_count"] == 0
    assert all(consistency["field_matches"].values())
    assert consistency["aggregate_totals_matched"] is True
    assert all(consistency["aggregate_matches"].values())
    assert consistency["report_aggregate_totals"]["case_count"] == report[
        "case_count"
    ]
    assert consistency["report_aggregate_totals"]["frontier_count"] == report[
        "frontier_count"
    ]
    assert consistency["evidence_aggregate_totals"] == (
        consistency["report_aggregate_totals"]
    )
    assert consistency["frontier_reason_counts_matched"] is True
    assert consistency["report_frontier_reason_counts"] == report[
        "frontier_reason_counts"
    ]
    assert consistency["evidence_frontier_reason_counts"] == report[
        "frontier_reason_counts"
    ]
    assert consistency["bounded_homfly_maturity_path_counts_matched"] is True
    assert consistency["report_bounded_homfly_maturity_path_counts"] == report[
        "bounded_homfly_maturity_path_counts"
    ]
    assert consistency["evidence_bounded_homfly_maturity_path_counts"] == report[
        "bounded_homfly_maturity_path_counts"
    ]
    assert consistency["bounded_homfly_maturity_path_distinct_count_matched"] is True
    assert consistency["report_bounded_homfly_maturity_path_distinct_count"] == report[
        "bounded_homfly_maturity_path_distinct_count"
    ]
    assert consistency["evidence_bounded_homfly_maturity_path_distinct_count"] == report[
        "bounded_homfly_maturity_path_distinct_count"
    ]
    assert consistency["bounded_homfly_maturity_path_certified_count_matched"] is True
    assert consistency["report_bounded_homfly_maturity_path_certified_count"] == report[
        "bounded_homfly_maturity_path_certified_count"
    ]
    assert consistency["evidence_bounded_homfly_maturity_path_certified_count"] == report[
        "bounded_homfly_maturity_path_certified_count"
    ]
    assert consistency["completion_blocker_codes_matched"] is True
    assert consistency["completion_blocker_detail_codes_matched"] is True
    frontier_witness_consistency = consistency["frontier_witness_consistency"]
    assert frontier_witness_consistency["method"] == (
        "homfly_case_frontier_witness_consistency"
    )
    assert frontier_witness_consistency["matched"] is True
    assert frontier_witness_consistency["checked_case_count"] == report["case_count"]
    assert frontier_witness_consistency["missing_evidence_count"] == 0
    assert (
        frontier_witness_consistency[
            "case_frontier_witness_consistency_matched"
        ]
        is True
    )
    assert (
        frontier_witness_consistency[
            "evidence_frontier_witness_consistency_matched"
        ]
        is True
    )
    assert frontier_witness_consistency["mismatch_count"] == 0
    assert frontier_witness_consistency["first_mismatch"] is None
    assert frontier_witness_consistency["mismatch_witnesses"] == []
    assert consistency["frontier_witness_consistency_matched"] is True
    blocker_counts = consistency["blocker_detail_code_count_consistency"]
    assert blocker_counts["method"] == "homfly_blocker_detail_code_count_consistency"
    assert blocker_counts["matched"] is True
    assert blocker_counts["checked_case_count"] == report["case_count"]
    assert blocker_counts["missing_evidence_count"] == 0
    assert blocker_counts["top_level_completion_blocker_code_counts_matched"] is True
    assert (
        blocker_counts["top_level_completion_blocker_detail_code_counts_matched"]
        is True
    )
    assert blocker_counts["evidence_reported_code_count_fields_matched"] is True
    assert blocker_counts["case_completion_blocker_code_counts_matched"] is True
    assert (
        blocker_counts["case_completion_blocker_detail_code_counts_matched"]
        is True
    )
    assert blocker_counts["completion_blocker_code_count_totals_matched"] is True
    assert (
        blocker_counts["completion_blocker_detail_code_count_totals_matched"]
        is True
    )
    assert blocker_counts["certification_blocker_detail_code_counts_matched"] is True
    assert blocker_counts["report_completion_blocker_code_counts"] == report[
        "homfly_completion_blocker_code_counts"
    ]
    assert blocker_counts["report_completion_blocker_detail_code_counts"] == report[
        "homfly_completion_blocker_detail_code_counts"
    ]
    assert blocker_counts["stored_report_completion_blocker_code_counts"] == report[
        "homfly_completion_blocker_code_counts"
    ]
    assert blocker_counts[
        "stored_report_completion_blocker_detail_code_counts"
    ] == report["homfly_completion_blocker_detail_code_counts"]
    assert blocker_counts["expected_case_completion_blocker_code_counts"] == [
        {
            "code": row["code"],
            "blocker_count": row["blocker_count"] * report["case_count"],
        }
        for row in report["homfly_completion_blocker_code_counts"]
    ]
    assert blocker_counts["evidence_completion_blocker_code_counts"] == (
        blocker_counts["expected_case_completion_blocker_code_counts"]
    )
    assert blocker_counts["expected_case_completion_blocker_detail_code_counts"] == [
        {
            "code": row["code"],
            "detail_count": row["detail_count"] * report["case_count"],
        }
        for row in report["homfly_completion_blocker_detail_code_counts"]
    ]
    assert blocker_counts["evidence_completion_blocker_detail_code_counts"] == (
        blocker_counts["expected_case_completion_blocker_detail_code_counts"]
    )
    assert {
        row["code"]: row["blocker_count"]
        for row in blocker_counts["evidence_certification_blocker_code_counts"]
    } == {
        row["code"]: row["detail_count"]
        for row in blocker_counts[
            "evidence_certification_blocker_detail_code_counts"
        ]
    }
    assert blocker_counts[
        "case_completion_blocker_detail_code_count_mismatch_count"
    ] == 0
    assert (
        blocker_counts["case_completion_blocker_detail_code_count_mismatches"]
        == []
    )
    assert blocker_counts["mismatch_count"] == 0
    assert blocker_counts["first_mismatch"] is None
    assert blocker_counts["mismatch_witnesses"] == []
    assert consistency["mismatch_count"] == 0
    assert consistency["first_mismatch"] is None
    assert consistency["mismatch_witnesses"] == []


def test_homfly_fixture_acceptance_report_aggregates_current_evidence() -> None:
    report = homfly_fixture_acceptance_report()

    assert report["method"] == "homfly_fixture_acceptance_report"
    assert report["claim_scope"] == "registered_fixture_acceptance_under_iroll_convention"
    assert report["input_certification_scope"] == (
        "iterative_recursive_frontier_exhaustion_for_registered_signed_pd_inputs"
    )
    assert report["full_table_normalization_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False
    assert report["accepted"] is True
    assert report["fixture_count"] == 5
    assert report["accepted_count"] == 5
    assert report["incomplete_notations"] == []
    assert report["comparison_checked_count"] == 5
    assert report["comparison_matched_count"] == 5
    assert report["mirror_checked_count"] == 3
    assert report["mirror_matched_count"] == 3
    assert report["skein_checked_count"] == 5
    assert report["skein_matched_count"] == 5
    assert report["input_certification_applicable_count"] == 5
    assert report["certified_input_count"] == 5
    assert report["uncertified_input_count"] == 0
    assert report["input_certification_recursion_node_count"] > 0
    assert report["input_certification_terminal_reduction_count"] > 0
    assert report["input_certification_frontier_count"] == 0
    assert report["input_certification_truncated_count"] == 0
    assert report["input_certification_zero_crossing_count"] == 2
    assert report["bounded_homfly_maturity_path_counts"] == [
        {
            "bounded_homfly_maturity_path": (
                "recursive_switching_to_descending_frontier_exhausted"
            ),
            "fixture_count": 3,
        },
        {
            "bounded_homfly_maturity_path": "zero_crossing_unlink_terminal",
            "fixture_count": 2,
        },
    ]
    assert report["bounded_homfly_maturity_path_distinct_count"] == 2
    assert report["bounded_homfly_maturity_path_certified_count"] == 5
    assert report["input_certification_iterative_attempt_count"] >= 3
    assert report["input_certification_iterative_solved_count"] == 5
    assert report["input_certification_iterative_max_solved_depth"] >= 0
    _assert_homfly_completion_blockers(report)
    assert report["required_check_count"] == 13
    assert report["passed_check_count"] == 13
    assert report["failed_check_count"] == 0

    rows = {row["notation"]: row for row in report["fixtures"]}
    assert set(rows) == {"0_1", "L0a1", "L2a1", "3_1", "4_1"}
    assert rows["0_1"]["mirror_applicable"] is False
    assert rows["L0a1"]["mirror_applicable"] is False
    for notation in rows:
        assert rows[notation]["input_certification_applicable"] is True
        assert rows[notation]["certified_for_input"] is True
        assert rows[notation]["bounded_homfly_maturity_path_certified"] is True
        assert rows[notation]["full_table_normalization_certified"] is False
        evidence = rows[notation]["input_certification_evidence"]
        assert evidence["method"] == "homfly_input_certification_evidence"
        assert evidence["certified_for_input"] is True
        assert evidence["frontier_exhausted"] is True
        assert evidence["truncated"] is False
        assert evidence["frontier_count"] == 0
        assert evidence["iterative_solved_depth"] is not None
        assert evidence["full_table_normalization_certified"] is False
        assert evidence["arbitrary_diagram_coverage_certified"] is False
        assert evidence["certification_blockers"] == []
        assert evidence["certification_blocker_count"] == 0
        maturity_evidence = evidence["bounded_homfly_maturity_path_evidence"]
        assert maturity_evidence["method"] == "homfly_bounded_maturity_path_evidence"
        assert (
            maturity_evidence["claim_scope"]
            == "bounded_maturity_path_classification_diagnostics"
        )
        assert maturity_evidence["bounded_homfly_maturity_path"] == rows[notation][
            "bounded_homfly_maturity_path"
        ]
        assert (
            maturity_evidence["expected_bounded_homfly_maturity_path"]
            == rows[notation]["bounded_homfly_maturity_path"]
        )
        assert maturity_evidence["bounded_homfly_maturity_path_matches_expected"] is True
        assert maturity_evidence["bounded_homfly_maturity_path_certified"] is True
        if rows[notation]["bounded_homfly_maturity_path"] == "zero_crossing_unlink_terminal":
            assert maturity_evidence["zero_crossing_certified"] is True
            assert maturity_evidence["certified_for_input"] is False
        else:
            assert maturity_evidence["zero_crossing_certified"] is False
            assert maturity_evidence["certified_for_input"] is True
        assert maturity_evidence["frontier_exhausted"] is True
        assert maturity_evidence["skipped"] is False
        assert maturity_evidence["truncated"] is False
        assert maturity_evidence["frontier_count"] == 0
        assert maturity_evidence["certification_blocker_count"] == 0
        assert maturity_evidence["full_table_normalization_certified"] is False
        assert maturity_evidence["arbitrary_diagram_coverage_certified"] is False
        _assert_homfly_completion_blockers(evidence)
    assert rows["0_1"]["bounded_homfly_maturity_path"] == (
        "zero_crossing_unlink_terminal"
    )
    assert rows["0_1"]["input_certification_evidence"][
        "bounded_homfly_maturity_path"
    ] == "zero_crossing_unlink_terminal"
    assert rows["0_1"]["input_certification_evidence"][
        "zero_crossing_certified"
    ] is True
    assert rows["L0a1"]["bounded_homfly_maturity_path"] == (
        "zero_crossing_unlink_terminal"
    )
    assert rows["L0a1"]["input_certification_evidence"][
        "bounded_homfly_maturity_path"
    ] == "zero_crossing_unlink_terminal"
    assert rows["L0a1"]["input_certification_evidence"][
        "zero_crossing_certified"
    ] is True
    for notation in ("L2a1", "3_1", "4_1"):
        assert rows[notation]["comparison"]["matched"] is True
        assert rows[notation]["mirror_audit"]["matched"] is True
        assert rows[notation]["skein_identity_audit"]["matched"] is True
        assert rows[notation]["accepted"] is True
        assert rows[notation]["required_check_count"] == 3
        assert rows[notation]["passed_check_count"] == 3
        assert rows[notation]["failed_check_count"] == 0
        assert rows[notation]["bounded_homfly_maturity_path"] == (
            "recursive_switching_to_descending_frontier_exhausted"
        )
        assert rows[notation]["input_certification_evidence"][
            "bounded_homfly_maturity_path"
        ] == "recursive_switching_to_descending_frontier_exhausted"
        assert rows[notation]["input_certification_evidence"][
            "zero_crossing_certified"
        ] is False


def test_homfly_fixture_acceptance_report_keeps_unregistered_fixtures_visible() -> None:
    report = homfly_fixture_acceptance_report(include_unregistered=True)

    assert report["accepted"] is False
    assert report["fixture_count"] == 7
    assert set(report["incomplete_notations"]) == {"L5a1", "L6a4"}
    assert report["input_certification_applicable_count"] == 5
    assert report["certified_input_count"] == 5
    assert report["uncertified_input_count"] == 0
    assert report["input_certification_frontier_count"] == 0
    assert report["input_certification_truncated_count"] == 0
    assert report["input_certification_iterative_attempt_count"] >= 3
    assert report["input_certification_iterative_solved_count"] == 5
    assert report["required_check_count"] == 15
    assert report["passed_check_count"] == 13
    assert report["failed_check_count"] == 2
    assert report["source_table_invariant_audit_applicable_count"] == 2
    assert report["source_table_registration_checked_count"] == 2
    assert report["source_table_registration_ready_count"] == 0
    assert report["source_table_registration_blocked_count"] == 2
    assert report["source_table_registration_blocker_count"] == 10
    assert report["source_table_registration_blockers"] == [
        "candidate_set_incomplete",
        "fixture_signs_not_registered",
        "registered_fixture_invariant_claim_disabled",
        "source_compatible_sign_pattern_not_unique",
        "source_table_values_mismatched",
        "source_table_values_uncomputed",
    ]
    assert report["source_table_registration_blocker_counts"] == [
        {"blocker": "candidate_set_incomplete", "fixture_count": 1},
        {"blocker": "fixture_signs_not_registered", "fixture_count": 2},
        {
            "blocker": "registered_fixture_invariant_claim_disabled",
            "fixture_count": 2,
        },
        {
            "blocker": "source_compatible_sign_pattern_not_unique",
            "fixture_count": 2,
        },
        {"blocker": "source_table_values_mismatched", "fixture_count": 2},
        {"blocker": "source_table_values_uncomputed", "fixture_count": 1},
    ]
    assert report["source_table_registration_blocked_notations"] == [
        "L5a1",
        "L6a4",
    ]
    assert report["source_table_registration_ready_notations"] == []
    assert report["bounded_homfly_maturity_path_counts"] == [
        {
            "bounded_homfly_maturity_path": (
                "recursive_switching_to_descending_frontier_exhausted"
            ),
            "fixture_count": 3,
        },
        {
            "bounded_homfly_maturity_path": "source_table_diagnostic_only",
            "fixture_count": 2,
        },
        {
            "bounded_homfly_maturity_path": "zero_crossing_unlink_terminal",
            "fixture_count": 2,
        },
    ]
    assert report["bounded_homfly_maturity_path_distinct_count"] == 3
    assert report["bounded_homfly_maturity_path_certified_count"] == 5
    consistency = report["source_table_registration_summary_consistency"]
    assert consistency["method"] == (
        "homfly_source_table_registration_summary_consistency"
    )
    assert consistency["claim_scope"] == (
        "bounded_source_table_registration_summary_audit"
    )
    assert consistency["matched"] is True
    assert consistency["mismatch_count"] == 0
    assert consistency["first_mismatch"] is None
    assert consistency["mismatch_witnesses"] == []
    assert consistency["checked_count_matches_rows"] is True
    assert consistency["ready_count_matches_rows"] is True
    assert consistency["blocked_count_matches_rows"] is True
    assert consistency["blocker_count_matches_rows"] is True
    assert consistency["blocker_counts_match_rows"] is True
    assert consistency["blocked_notations_match_rows"] is True
    assert consistency["ready_notations_match_rows"] is True
    assert consistency["row_blocker_count_matches_list"] is True
    assert consistency["row_blocker_details_cover_blockers"] is True
    assert consistency["report_checked_count"] == report[
        "source_table_registration_checked_count"
    ]
    assert consistency["reported_checked_count"] == consistency["report_checked_count"]
    assert consistency["row_checked_count"] == 2
    assert consistency["report_ready_count"] == report[
        "source_table_registration_ready_count"
    ]
    assert consistency["reported_ready_count"] == consistency["report_ready_count"]
    assert consistency["row_ready_count"] == 0
    assert consistency["report_blocked_count"] == report[
        "source_table_registration_blocked_count"
    ]
    assert consistency["reported_blocked_count"] == consistency["report_blocked_count"]
    assert consistency["row_blocked_count"] == 2
    assert consistency["report_blocker_count"] == report[
        "source_table_registration_blocker_count"
    ]
    assert (
        consistency["reported_blocker_count"] == consistency["report_blocker_count"]
    )
    assert consistency["row_blocker_count"] == 10
    assert consistency["report_blocker_counts"] == report[
        "source_table_registration_blocker_counts"
    ]
    assert (
        consistency["reported_blocker_counts"] == consistency["report_blocker_counts"]
    )
    assert consistency["row_blocker_counts"] == report[
        "source_table_registration_blocker_counts"
    ]
    assert (
        consistency["reported_blocked_notations"]
        == consistency["report_blocked_notations"]
    )
    assert (
        consistency["reported_ready_notations"] == consistency["report_ready_notations"]
    )
    assert consistency["row_blocker_count_mismatches"] == []
    assert consistency["row_blocker_detail_mismatches"] == []

    rows = {row["notation"]: row for row in report["fixtures"]}
    assert rows["L5a1"]["expected_homfly"] is None
    assert rows["L5a1"]["input_certification_applicable"] is False
    assert rows["L5a1"]["certified_for_input"] is False
    assert rows["L5a1"]["bounded_homfly_maturity_path"] == (
        "source_table_diagnostic_only"
    )
    assert rows["L5a1"]["bounded_homfly_maturity_path_certified"] is False
    assert rows["L5a1"]["input_certification_evidence"]["skipped"] is True
    assert rows["L5a1"]["input_certification_evidence"][
        "certified_for_input"
    ] is False
    assert rows["L5a1"]["comparison"]["skipped"] is True
    assert rows["L5a1"]["required_check_count"] == 1
    assert rows["L5a1"]["passed_check_count"] == 0
    assert rows["L5a1"]["failed_check_count"] == 1
    assert rows["L5a1"]["source_table_invariant_audit_applicable"] is True
    assert rows["L5a1"]["source_table_registration_ready"] is False
    assert rows["L5a1"]["source_table_registration_blockers"] == [
        "fixture_signs_not_registered",
        "registered_fixture_invariant_claim_disabled",
        "candidate_set_incomplete",
        "source_table_values_uncomputed",
        "source_table_values_mismatched",
        "source_compatible_sign_pattern_not_unique",
    ]
    assert rows["L5a1"]["source_table_registration_blocker_count"] == 6
    l5_source_table_audit = rows["L5a1"]["source_table_invariant_audit"]
    assert l5_source_table_audit["method"] == (
        "diagram_fixture_source_table_invariant_audit"
    )
    assert l5_source_table_audit["mismatched_source_table_invariants"] == [
        "homfly",
    ]
    assert l5_source_table_audit["uncomputed_source_table_invariants"] == [
        "jones",
        "multivariable_alexander_numerator",
    ]
    assert l5_source_table_audit["comparisons"]["homfly"][
        "source_value_variant_resolution_status"
    ] == "source_variant_seen"
    assert l5_source_table_audit["comparisons"]["homfly"][
        "computed_candidate_count"
    ] == 8
    l5_homfly_comparison = l5_source_table_audit["comparisons"]["homfly"]
    l5_variant_miss_summary = l5_homfly_comparison[
        "source_value_variant_miss_witness_summary"
    ]
    assert l5_variant_miss_summary["method"] == (
        "source_table_homfly_variant_miss_witness_summary"
    )
    assert l5_variant_miss_summary[
        "source_value_variant_resolution_status"
    ] == "source_variant_seen"
    assert l5_homfly_comparison["source_value_seen_variant_count"] == 2
    assert l5_variant_miss_summary["variant_miss_witness_count"] == 0
    assert l5_variant_miss_summary["variant_miss_witness_limit"] == 8
    assert l5_variant_miss_summary["variant_miss_witness_truncated"] is False
    assert l5_variant_miss_summary["variant_miss_witnesses"] == []
    assert l5_variant_miss_summary["first_variant_miss_witness"] is None
    assert l5_variant_miss_summary[
        "candidate_unique_value_count"
    ] == l5_homfly_comparison["candidate_unique_value_count"]
    assert l5_source_table_audit[
        "source_table_homfly_variant_miss_witness_count"
    ] == 0
    assert l5_source_table_audit[
        "source_table_homfly_variant_miss_witness_truncated"
    ] is False
    assert "fixture does not have a signed-PD diagram" in rows["L5a1"][
        "comparison"
    ]["notes"]
    source_orientation = rows["L5a1"]["comparison"]["source_orientation_diagnostics"]
    assert source_orientation["skipped"] is False
    assert source_orientation["has_gauss_code"] is True
    assert source_orientation["gauss_code_matched"] is True
    assert source_orientation["gauss_code_orientation_diagnostics"][
        "matching_sample_count"
    ] == 2
    source_pairwise = rows["L5a1"]["comparison"][
        "source_pairwise_candidate_diagnostics"
    ]
    assert source_pairwise["skipped"] is False
    assert source_pairwise["target_pairwise_linking"] == [0.0]
    assert source_pairwise["matching_candidate_count"] == 24
    assert source_pairwise["matching_sign_summary"][
        "unique_sign_pattern_count"
    ] == 12
    assert rows["L6a4"]["expected_homfly"] is None
    assert rows["L6a4"]["input_certification_applicable"] is False
    assert rows["L6a4"]["certified_for_input"] is False
    assert rows["L6a4"]["bounded_homfly_maturity_path"] == (
        "source_table_diagnostic_only"
    )
    assert rows["L6a4"]["bounded_homfly_maturity_path_certified"] is False
    assert rows["L6a4"]["input_certification_evidence"]["skipped"] is True
    assert rows["L6a4"]["input_certification_evidence"][
        "certified_for_input"
    ] is False
    assert rows["L6a4"]["comparison"]["skipped"] is True
    assert rows["L6a4"]["required_check_count"] == 1
    assert rows["L6a4"]["passed_check_count"] == 0
    assert rows["L6a4"]["failed_check_count"] == 1
    assert rows["L6a4"]["source_table_invariant_audit_applicable"] is True
    assert rows["L6a4"]["source_table_registration_ready"] is False
    assert rows["L6a4"]["source_table_registration_blockers"] == [
        "fixture_signs_not_registered",
        "registered_fixture_invariant_claim_disabled",
        "source_table_values_mismatched",
        "source_compatible_sign_pattern_not_unique",
    ]
    assert rows["L6a4"]["source_table_registration_blocker_count"] == 4
    l6_source_table_audit = rows["L6a4"]["source_table_invariant_audit"]
    assert l6_source_table_audit["matched_source_table_invariants"] == [
        "jones",
        "multivariable_alexander_numerator",
    ]
    assert l6_source_table_audit["mismatched_source_table_invariants"] == [
        "homfly",
    ]
    assert l6_source_table_audit["uncomputed_source_table_invariants"] == []
    assert l6_source_table_audit["comparisons"]["homfly"][
        "source_value_variant_resolution_status"
    ] == "source_variant_seen"
    assert l6_source_table_audit["comparisons"]["homfly"][
        "computed_candidate_count"
    ] == 8
    l6_homfly_comparison = l6_source_table_audit["comparisons"]["homfly"]
    l6_variant_miss_summary = l6_homfly_comparison[
        "source_value_variant_miss_witness_summary"
    ]
    assert l6_variant_miss_summary["method"] == (
        "source_table_homfly_variant_miss_witness_summary"
    )
    assert l6_variant_miss_summary[
        "source_value_variant_resolution_status"
    ] == "source_variant_seen"
    assert l6_homfly_comparison["source_value_seen_variant_count"] == 4
    assert l6_variant_miss_summary["variant_miss_witness_count"] == 0
    assert l6_variant_miss_summary["variant_miss_witness_limit"] == 8
    assert l6_variant_miss_summary["variant_miss_witness_truncated"] is False
    assert l6_variant_miss_summary["variant_miss_witnesses"] == []
    assert l6_variant_miss_summary["first_variant_miss_witness"] is None
    assert l6_variant_miss_summary[
        "candidate_unique_value_count"
    ] == l6_homfly_comparison["candidate_unique_value_count"]
    assert l6_source_table_audit[
        "source_table_homfly_variant_miss_witness_count"
    ] == 0
    assert l6_source_table_audit[
        "source_table_homfly_variant_miss_witness_truncated"
    ] is False
    assert "fixture does not have a signed-PD diagram" in rows["L6a4"][
        "comparison"
    ]["notes"]
    borromean_source_orientation = rows["L6a4"]["comparison"][
        "source_orientation_diagnostics"
    ]
    assert borromean_source_orientation["skipped"] is False
    assert borromean_source_orientation["has_gauss_code"] is True
    assert borromean_source_orientation["gauss_code_matched"] is True
    assert borromean_source_orientation["gauss_code_orientation_diagnostics"][
        "matching_sample_count"
    ] == 1
    borromean_source_pairwise = rows["L6a4"]["comparison"][
        "source_pairwise_candidate_diagnostics"
    ]
    assert borromean_source_pairwise["skipped"] is False
    assert borromean_source_pairwise["target_pairwise_linking"] == [0.0, 0.0, 0.0]
    assert borromean_source_pairwise["matching_candidate_count"] == 8
    assert borromean_source_pairwise["matching_sign_summary"][
        "mirror_pair_count"
    ] == 4
    assert rows["L6a4"]["accepted"] is False


def test_homfly_small_diagram_coverage_report_certifies_generated_skein_branches() -> None:
    report = homfly_small_diagram_coverage_report()

    assert report["method"] == "homfly_small_diagram_coverage_report"
    assert report["claim_scope"] == "generated_small_signed_pd_frontier_exhaustion"
    assert report["source_notations"] == ["L2a1", "3_1", "4_1"]
    assert report["accepted"] is True
    assert report["case_count"] == 30
    assert report["non_fixture_case_count"] == 27
    assert report["unique_diagram_count"] == 19
    assert report["unique_oriented_diagram_count"] == 20
    assert report["unique_evaluation_count"] == 20
    assert report["reused_evaluation_count"] == 10
    assert report["duplicate_diagram_case_count"] == 11
    assert report["multi_path_diagram_count"] == 4
    assert report["max_diagram_case_count"] == 5
    assert report["polynomial_variant_diagram_count"] == 0
    assert report["max_homfly_polynomial_count_per_diagram"] == 1
    assert report["oriented_polynomial_conflict_count"] == 0
    assert report["max_homfly_polynomial_count_per_oriented_diagram"] == 1
    assert report["certified_case_count"] == 30
    assert sum(
        row["case_count"]
        for row in report["bounded_homfly_maturity_path_counts"]
    ) == report["case_count"]
    assert report["bounded_homfly_maturity_path_distinct_count"] == len(
        report["bounded_homfly_maturity_path_counts"]
    )
    assert report["bounded_homfly_maturity_path_certified_count"] == (
        report["certified_case_count"]
    )
    assert report["uncertified_case_count"] == 0
    assert report["skipped_case_count"] == 0
    assert report["truncated_case_count"] == 0
    assert report["frontier_count"] == 0
    assert report["frontier_case_count"] == 0
    assert report["relation_error_count"] == 0
    assert report["max_crossing_count"] == 4
    assert report["max_solved_depth"] == 7
    _assert_solved_depth_counts(report, report["certified_case_count"])
    assert report["frontier_reason_count"] == 0
    assert report["frontier_reasons"] == []
    assert report["frontier_reason_counts"] == []
    assert report["frontier_witness_count"] == 0
    assert report["frontier_witness_limit"] == 8
    assert report["frontier_witnesses_truncated"] is False
    assert report["frontier_witnesses"] == []
    assert report["first_frontier_witness"] is None
    assert report["frontier_witness_summary"]["witness_count"] == 0
    assert report["frontier_witness_summary"]["reason_counts"] == []
    assert report["frontier_witness_summary"]["reason_count"] == 0
    assert report["frontier_witness_summary"]["min_depth"] is None
    assert report["frontier_witness_summary"]["max_depth"] is None
    assert report["frontier_witness_summary"]["recursive_path_prefix_counts"] == []
    assert report["frontier_witness_summary"]["recursive_path_prefix_count"] == 0
    assert report["frontier_witness_summary"]["source_kind_counts"] == []
    assert report["frontier_witness_summary"]["source_kind_count"] == 0
    assert report["frontier_witness_summary"]["branch_counts"] == []
    assert report["frontier_witness_summary"]["branch_count"] == 0
    assert report["frontier_witness_summary"]["witness_summary_truncated"] is False
    _assert_homfly_source_summary_consistency(report)
    _assert_homfly_case_evidence_consistency(report)
    assert report["branch_depth_counts"] == [
        {"branch_depth": 0, "case_count": 3},
        {"branch_depth": 1, "case_count": 27},
    ]
    assert report["certified_branch_depth_counts"] == report["branch_depth_counts"]
    assert report["uncertified_branch_depth_counts"] == []
    assert report["frontier_branch_depth_counts"] == []
    assert report["truncated_branch_depth_counts"] == []
    assert report["source_kind_counts"] == [
        {"source_kind": "fixture_root", "case_count": 3},
        {"source_kind": "one_step_skein_branch", "case_count": 27},
    ]
    assert report["frontier_source_kind_counts"] == []
    assert report["truncated_source_kind_counts"] == []
    assert report["branch_counts"] == [
        {"branch": "negative", "case_count": 9},
        {"branch": "positive", "case_count": 9},
        {"branch": "root", "case_count": 3},
        {"branch": "smoothed", "case_count": 9},
    ]
    assert report["frontier_branch_counts"] == []
    assert report["truncated_branch_counts"] == []
    assert report["full_table_normalization_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False
    _assert_homfly_completion_blockers(report)
    gate = report["arbitrary_diagram_completion_gate"]
    assert gate["evidence_scope"] == "generated_small_signed_pd_coverage"
    assert gate["case_count"] == report["case_count"]
    assert gate["certified_case_count"] == report["certified_case_count"]
    assert gate["frontier_count"] == 0
    assert gate["frontier_case_count"] == 0
    assert gate["frontier_witnesses"] == []
    assert gate["first_frontier_witness"] is None
    assert gate["source_summary_consistency_matched"] is True
    assert gate["case_evidence_consistency_matched"] is True
    assert gate["certification_blockers"] == []
    assert gate["gate_pressure_consistency"]["visible_witness_count"] == 0
    assert gate["gate_pressure_consistency"]["missing_witness_count"] == 0
    assert gate["gate_pressure_consistency"]["frontier_blocker_reasons"] == []
    assert gate["gate_pressure_consistency"]["non_claim_matched"] is True
    metadata = report["fixture_normalization_metadata"]
    assert metadata["method"] == "homfly_fixture_normalization_metadata"
    assert metadata["claim_scope"] == "fixture_root_metadata_only"
    assert metadata["metadata_row_count"] == 3
    assert metadata["expected_homfly_source_count"] == 3
    assert metadata["source_url_count"] == 1
    assert metadata["signed_pd_fixture_count"] == 3
    assert metadata["expected_homfly_fixture_count"] == 3
    assert metadata["full_table_normalization_certified"] is False
    assert metadata["full_table_normalization_certified_count"] == 0
    assert metadata["arbitrary_diagram_coverage_certified"] is False
    assert metadata["arbitrary_diagram_coverage_certified_count"] == 0
    metadata_rows = {row["source_notation"]: row for row in metadata["rows"]}
    assert metadata_rows["L2a1"]["fixture_expected_homfly_source"] == (
        "iroll bounded recursive HOMFLY regression"
    )
    assert metadata_rows["4_1"]["fixture_source_url"] == (
        "https://katlas.org/wiki/4_1"
    )
    assert all(
        row["fixture_full_table_normalization_certified"] is False
        for row in metadata["rows"]
    )
    metadata_consistency = report["fixture_normalization_metadata_consistency"]
    assert metadata_consistency["matched"] is True
    assert metadata_consistency["metadata_row_count"] == 3
    assert metadata_consistency["source_notation_count"] == 3
    assert (
        metadata_consistency["metadata_row_count_matches_source_notation_count"]
        is True
    )
    assert metadata_consistency["missing_metadata_count"] == 0
    assert metadata_consistency["extra_metadata_count"] == 0
    assert metadata_consistency["mismatch_count"] == 0

    by_notation = Counter(case["source_notation"] for case in report["cases"])
    assert by_notation == {"L2a1": 7, "3_1": 10, "4_1": 13}
    by_source_summary = {
        row["source_notation"]: row for row in report["source_notation_summary"]
    }
    assert list(by_source_summary) == ["L2a1", "3_1", "4_1"]
    assert {
        notation: row["case_count"] for notation, row in by_source_summary.items()
    } == by_notation
    assert sum(row["case_count"] for row in by_source_summary.values()) == report[
        "case_count"
    ]
    assert sum(
        row["certified_case_count"] for row in by_source_summary.values()
    ) == report["certified_case_count"]
    assert sum(row["attempt_count"] for row in by_source_summary.values()) == report[
        "attempt_count"
    ]
    assert all(
        sum(item["case_count"] for item in row["solved_depth_counts"])
        == row["certified_case_count"]
        for row in by_source_summary.values()
    )
    assert all(
        sum(
            item["case_count"]
            for item in row["bounded_homfly_maturity_path_counts"]
        ) == row["case_count"]
        for row in by_source_summary.values()
    )
    assert sum(
        row["bounded_homfly_maturity_path_certified_count"]
        for row in by_source_summary.values()
    ) == report["bounded_homfly_maturity_path_certified_count"]
    assert all(row["accepted"] is True for row in by_source_summary.values())
    assert all(row["frontier_count"] == 0 for row in by_source_summary.values())
    assert all(row["frontier_case_count"] == 0 for row in by_source_summary.values())
    assert all(row["truncated_case_count"] == 0 for row in by_source_summary.values())
    assert by_source_summary["L2a1"]["fixture_expected_homfly_source"] == (
        "iroll bounded recursive HOMFLY regression"
    )
    assert by_source_summary["4_1"]["fixture_source"] == "Knot Atlas"
    assert by_source_summary["4_1"]["fixture_source_url"] == (
        "https://katlas.org/wiki/4_1"
    )
    assert by_source_summary["4_1"]["fixture_expected_homfly_note_count"] == 3
    assert by_source_summary["4_1"]["fixture_convention_note_count"] == 3
    assert all(
        row["fixture_normalization_claim_scope"] == "fixture_root_metadata_only"
        for row in by_source_summary.values()
    )
    assert all(
        row["fixture_arbitrary_diagram_coverage_certified"] is False
        for row in by_source_summary.values()
    )
    assert all(row["frontier_reason_counts"] == [] for row in by_source_summary.values())
    assert all(
        row["certified_branch_depth_counts"] == row["branch_depth_counts"]
        for row in by_source_summary.values()
    )
    assert all(row["frontier_branch_depth_counts"] == [] for row in by_source_summary.values())
    assert all(row["truncated_branch_depth_counts"] == [] for row in by_source_summary.values())
    assert by_source_summary["L2a1"]["branch_counts"] == [
        {"branch": "negative", "case_count": 2},
        {"branch": "positive", "case_count": 2},
        {"branch": "root", "case_count": 1},
        {"branch": "smoothed", "case_count": 2},
    ]
    by_branch = Counter(case["branch"] for case in report["cases"])
    assert by_branch == {"root": 3, "positive": 9, "negative": 9, "smoothed": 9}

    roots = {
        case["source_notation"]: case
        for case in report["cases"]
        if case["source_kind"] == "fixture_root"
    }
    assert roots["L2a1"]["homfly_polynomial"] == get_diagram_fixture("L2a1").expected_homfly
    assert roots["3_1"]["homfly_polynomial"] == get_diagram_fixture("3_1").expected_homfly
    assert roots["4_1"]["homfly_polynomial"] == get_diagram_fixture("4_1").expected_homfly

    non_fixture = [
        case for case in report["cases"] if case["source_kind"] != "fixture_root"
    ]
    assert len(non_fixture) == 27
    assert all(case["certified_for_input"] for case in non_fixture)
    assert all(case["input_certification_evidence"]["frontier_exhausted"] for case in report["cases"])
    assert all(case["frontier_count"] == 0 for case in report["cases"])
    assert all(case["frontier_reason_count"] == 0 for case in report["cases"])
    assert all(case["frontier_reasons"] == [] for case in report["cases"])
    assert all(case["frontier_witnesses"] == [] for case in report["cases"])
    assert all(case["first_frontier_witness"] is None for case in report["cases"])
    assert all(case["truncated"] is False for case in report["cases"])
    assert all(
        case["bounded_homfly_maturity_path"]
        == case["input_certification_evidence"]["bounded_homfly_maturity_path"]
        for case in report["cases"]
    )
    assert all(
        case["bounded_homfly_maturity_path_certified"]
        == case["input_certification_evidence"][
            "bounded_homfly_maturity_path_certified"
        ]
        for case in report["cases"]
    )
    assert all(case["bounded_homfly_maturity_path_certified"] for case in report["cases"])
    assert all(case["result_method"].startswith("certified_iterative") for case in report["cases"])
    assert any(case["branch"] == "smoothed" and case["crossing_count"] < 4 for case in non_fixture)
    multiplicity = report["diagram_multiplicity_summary"]
    assert multiplicity["method"] == "homfly_generated_diagram_multiplicity_summary"
    assert multiplicity["unique_diagram_count"] == report["unique_diagram_count"]
    assert multiplicity["unique_oriented_diagram_count"] == 20
    assert multiplicity["duplicate_diagram_case_count"] == 11
    assert multiplicity["multi_path_diagram_count"] == 4
    assert multiplicity["max_case_count_per_diagram"] == 5
    assert multiplicity["polynomial_variant_diagram_count"] == report["polynomial_variant_diagram_count"]
    assert multiplicity["max_homfly_polynomial_count_per_diagram"] == report["max_homfly_polynomial_count_per_diagram"]
    assert (
        multiplicity["oriented_polynomial_conflict_count"]
        == report["oriented_polynomial_conflict_count"]
    )
    assert (
        multiplicity["max_homfly_polynomial_count_per_oriented_diagram"]
        == report["max_homfly_polynomial_count_per_oriented_diagram"]
    )
    assert multiplicity["diagrams"][0]["case_count"] == 5
    assert multiplicity["diagrams"][0]["source_notations"] == ["4_1"]
    assert multiplicity["diagrams"][0]["homfly_polynomial_count"] == 1
    assert multiplicity["diagrams"][0]["certified_case_count"] == 5


def test_homfly_blocker_detail_counts_match_generated_case_evidence() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_depth=0,
        max_nodes=128,
    )

    _assert_blocker_count_fields(report, "homfly_completion")
    assert report["homfly_completion_blocker_detail_count"] == len(
        report["homfly_completion_blocker_details"]
    )

    certified_cases = []
    frontier_cases = []
    for case in report["cases"]:
        evidence = case["input_certification_evidence"]
        _assert_blocker_count_fields(evidence, "certification")
        _assert_blocker_count_fields(evidence, "homfly_completion")
        assert [row["code"] for row in evidence["certification_blocker_details"]] == (
            evidence["certification_blockers"]
        )
        if evidence["certified_for_input"]:
            certified_cases.append(evidence)
        else:
            frontier_cases.append(evidence)

    assert certified_cases
    assert frontier_cases
    assert all(
        evidence["certification_blocker_details"] == []
        for evidence in certified_cases
    )
    assert all(
        evidence["certification_blocker_detail_count"] == 0
        for evidence in certified_cases
    )
    assert all(
        evidence["certification_blocker_detail_count"]
        == len(evidence["certification_blocker_details"])
        for evidence in frontier_cases
    )

    legacy_evidence = homfly_input_certification_evidence(
        {
            "method": "legacy_homfly_result",
            "homfly_polynomial": "1",
            "certified_for_input": True,
            "skipped": False,
        }
    )
    _assert_blocker_count_fields(legacy_evidence, "certification")
    _assert_blocker_count_fields(legacy_evidence, "homfly_completion")
    assert legacy_evidence["certification_blockers"] == []
    assert legacy_evidence["certification_blocker_details"] == []
    assert legacy_evidence["certification_blocker_detail_count"] == 0


def test_homfly_case_evidence_maturity_path_counts_pinpoint_mismatch() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_depth=8,
        max_nodes=512,
    )
    mutated = deepcopy(report)
    mutated["bounded_homfly_maturity_path_counts"] = []
    mutated["bounded_homfly_maturity_path_distinct_count"] = 0
    mutated["bounded_homfly_maturity_path_certified_count"] = 0

    consistency = _homfly_generated_case_evidence_consistency_record(mutated)

    assert consistency["matched"] is False
    assert consistency["bounded_homfly_maturity_path_counts_matched"] is False
    assert (
        consistency["bounded_homfly_maturity_path_distinct_count_matched"]
        is False
    )
    assert (
        consistency["bounded_homfly_maturity_path_certified_count_matched"]
        is False
    )
    assert consistency["evidence_bounded_homfly_maturity_path_counts"] == report[
        "bounded_homfly_maturity_path_counts"
    ]
    assert consistency["evidence_bounded_homfly_maturity_path_certified_count"] == report[
        "bounded_homfly_maturity_path_certified_count"
    ]
    assert consistency["first_mismatch"]["field"] == (
        "bounded_homfly_maturity_path_counts"
    )

def test_homfly_case_evidence_blocker_detail_code_counts_pinpoint_mismatch() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_depth=0,
        max_nodes=128,
    )
    mutated = deepcopy(report)
    mismatched_case = mutated["cases"][0]
    evidence = deepcopy(mismatched_case["input_certification_evidence"])
    mismatched_case["input_certification_evidence"] = evidence
    evidence["homfly_completion_blocker_details"] = (
        evidence["homfly_completion_blocker_details"][:1]
    )
    evidence["homfly_completion_blocker_detail_count"] = 1
    evidence["homfly_completion_blocker_detail_code_counts"] = [
        {
            "code": evidence["homfly_completion_blocker_details"][0]["code"],
            "detail_count": 1,
        }
    ]

    consistency = _homfly_generated_case_evidence_consistency_record(mutated)
    blocker_counts = consistency["blocker_detail_code_count_consistency"]

    assert consistency["matched"] is False
    assert blocker_counts["matched"] is False
    assert (
        blocker_counts["case_completion_blocker_detail_code_counts_matched"]
        is False
    )
    assert (
        blocker_counts["completion_blocker_detail_code_count_totals_matched"]
        is False
    )
    assert (
        blocker_counts["case_completion_blocker_detail_code_count_mismatch_count"]
        == 1
    )
    assert blocker_counts["case_completion_blocker_detail_code_count_mismatches"][
        0
    ]["case_id"] == mismatched_case["case_id"]
    assert blocker_counts["first_mismatch"]["case_id"] == mismatched_case["case_id"]
    assert blocker_counts["first_mismatch"]["field"] == (
        "homfly_completion_blocker_detail_code_counts"
    )


def test_homfly_case_evidence_frontier_witness_consistency_pinpoints_mismatch() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_depth=0,
        max_nodes=128,
    )
    mutated = deepcopy(report)
    mismatched_case = next(
        case for case in mutated["cases"] if case["frontier_witness_count"] > 0
    )
    evidence = deepcopy(mismatched_case["input_certification_evidence"])
    mismatched_case["input_certification_evidence"] = evidence
    mismatched_case["frontier_witness_count"] += 1
    evidence["frontier_witness_count"] = mismatched_case["frontier_witness_count"]

    consistency = _homfly_generated_case_evidence_consistency_record(mutated)
    frontier_consistency = consistency["frontier_witness_consistency"]

    assert consistency["matched"] is False
    assert consistency["field_matches"]["frontier_witness_count"] is True
    assert frontier_consistency["matched"] is False
    assert (
        frontier_consistency["case_frontier_witness_consistency_matched"]
        is False
    )
    assert (
        frontier_consistency["evidence_frontier_witness_consistency_matched"]
        is False
    )
    assert frontier_consistency["first_mismatch"]["case_id"] == (
        mismatched_case["case_id"]
    )
    assert frontier_consistency["first_mismatch"]["source_notation"] == "L2a1"
    assert frontier_consistency["first_mismatch"]["field"] == (
        "frontier_witness_count"
    )
    assert frontier_consistency["first_mismatch"]["report_value"] == 2
    assert frontier_consistency["first_mismatch"]["source_value"] == 1


def test_homfly_small_diagram_coverage_reports_unexhausted_frontier_cases() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_depth=0,
        max_nodes=128,
    )

    assert report["accepted"] is False
    assert report["source_notations"] == ["L2a1"]
    assert report["case_count"] == 7
    assert report["certified_case_count"] == 1
    assert report["bounded_homfly_maturity_path_certified_count"] == 1
    assert any(
        row["bounded_homfly_maturity_path"] == "not_certified"
        and row["case_count"] == 6
        for row in report["bounded_homfly_maturity_path_counts"]
    )
    assert report["uncertified_case_count"] == 6
    assert report["skipped_case_count"] == 6
    assert report["truncated_case_count"] == 0
    assert report["frontier_count"] == 6
    assert report["frontier_case_count"] == 6
    assert report["frontier_reason_count"] == 1
    assert report["frontier_reasons"] == ["max_depth"]
    assert report["frontier_reason_counts"] == [
        {"frontier_reason": "max_depth", "case_count": 6, "frontier_count": 6},
    ]
    assert report["frontier_witness_count"] == 6
    assert report["frontier_witness_limit"] == 8
    assert report["frontier_witnesses_truncated"] is False
    assert report["first_frontier_witness"] == report["frontier_witnesses"][0]
    first_report_witness = report["first_frontier_witness"]
    assert first_report_witness["case_id"] == "L2a1:root:root"
    assert first_report_witness["source_notation"] == "L2a1"
    assert first_report_witness["branch_path"] == []
    assert first_report_witness["recursive_path"] == ["root"]
    assert first_report_witness["recursive_depth"] == 0
    assert first_report_witness["reason"] == "max_depth"
    assert first_report_witness["cap"] == {
        "max_depth": 0,
        "max_nodes": 128,
    }
    assert report["frontier_witness_summary"]["witness_count"] == 6
    assert report["frontier_witness_summary"]["reason_counts"] == [
        {"reason": "max_depth", "witness_count": 6},
    ]
    assert report["frontier_witness_summary"]["reason_count"] == 1
    assert report["frontier_witness_summary"]["min_depth"] == 0
    assert report["frontier_witness_summary"]["max_depth"] == 0
    assert report["frontier_witness_summary"]["recursive_path_prefix_counts"] == [
        {"path_prefix": ["root"], "witness_count": 6},
    ]
    assert report["frontier_witness_summary"]["recursive_path_prefix_count"] == 1
    assert report["frontier_witness_summary"]["source_kind_counts"] == [
        {"source_kind": "fixture_root", "witness_count": 1},
        {"source_kind": "one_step_skein_branch", "witness_count": 5},
    ]
    assert report["frontier_witness_summary"]["source_kind_count"] == 2
    assert report["frontier_witness_summary"]["branch_counts"] == [
        {"branch": "negative", "witness_count": 1},
        {"branch": "positive", "witness_count": 2},
        {"branch": "root", "witness_count": 1},
        {"branch": "smoothed", "witness_count": 2},
    ]
    assert report["frontier_witness_summary"]["branch_count"] == 4
    assert report["frontier_witness_summary"]["min_branch_depth"] == 0
    assert report["frontier_witness_summary"]["max_branch_depth"] == 1
    assert report["frontier_witness_summary"]["witness_summary_truncated"] is False
    max_depth_pressure = {
        "frontier_count": 6,
        "witness_count": 6,
        "unwitnessed_frontier_count": 0,
        "all_frontier_witnessed": True,
        "frontier_reason_counts_available": True,
        "first_witness_reason": "max_depth",
        "first_unwitnessed_reason": None,
        "reason_counts": [
            {
                "reason": "max_depth",
                "frontier_count": 6,
                "witness_count": 6,
                "unwitnessed_frontier_count": 0,
                "all_frontier_witnessed": True,
            },
        ],
        "reason_count": 1,
    }
    assert report["frontier_witness_summary"]["run_cap_frontier_pressure"] == (
        max_depth_pressure
    )
    _assert_homfly_source_summary_consistency(report)
    _assert_homfly_case_evidence_consistency(report)
    assert report["branch_depth_counts"] == [
        {"branch_depth": 0, "case_count": 1},
        {"branch_depth": 1, "case_count": 6},
    ]
    assert report["certified_branch_depth_counts"] == [
        {"branch_depth": 1, "case_count": 1},
    ]
    assert report["uncertified_branch_depth_counts"] == [
        {"branch_depth": 0, "case_count": 1},
        {"branch_depth": 1, "case_count": 5},
    ]
    assert report["frontier_branch_depth_counts"] == [
        {"branch_depth": 0, "case_count": 1},
        {"branch_depth": 1, "case_count": 5},
    ]
    assert report["truncated_branch_depth_counts"] == []
    assert report["frontier_source_kind_counts"] == [
        {"source_kind": "fixture_root", "case_count": 1},
        {"source_kind": "one_step_skein_branch", "case_count": 5},
    ]
    assert report["truncated_source_kind_counts"] == []
    assert report["frontier_branch_counts"] == [
        {"branch": "negative", "case_count": 1},
        {"branch": "positive", "case_count": 2},
        {"branch": "root", "case_count": 1},
        {"branch": "smoothed", "case_count": 2},
    ]
    assert report["truncated_branch_counts"] == []
    assert report["solved_depth_counts"] == [
        {"solved_depth": 0, "case_count": 1},
    ]
    assert report["full_table_normalization_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False
    _assert_homfly_completion_blockers(report)
    gate = report["arbitrary_diagram_completion_gate"]
    assert gate["frontier_exhausted"] is False
    assert gate["frontier_count"] == report["frontier_count"]
    assert gate["frontier_case_count"] == report["frontier_case_count"]
    assert gate["frontier_reasons"] == ["max_depth"]
    assert gate["frontier_reason_counts"] == report["frontier_reason_counts"]
    assert gate["frontier_witnesses"] == report["frontier_witnesses"]
    assert gate["first_frontier_witness"] == report["first_frontier_witness"]
    assert gate["frontier_witness_summary"]["run_cap_frontier_pressure"] == (
        max_depth_pressure
    )
    assert gate["certification_blockers"] == ["frontier_not_exhausted"]
    assert gate["certification_blocker_detail_count"] == 6
    pressure_consistency = gate["gate_pressure_consistency"]
    assert pressure_consistency["visible_witness_count"] == 6
    assert pressure_consistency["missing_witness_count"] == 0
    assert pressure_consistency["frontier_blocker_reasons"] == ["max_depth"]
    assert pressure_consistency["frontier_blocker_matched"] is True
    assert pressure_consistency["non_claim_matched"] is True

    frontier_cases = [
        case for case in report["cases"] if case["frontier_count"] > 0
    ]
    assert len(frontier_cases) == report["frontier_case_count"]
    assert all(case["frontier_reasons"] == ["max_depth"] for case in frontier_cases)
    assert all(case["frontier_witness_count"] == 1 for case in frontier_cases)
    assert all(
        case["first_frontier_witness"]["reason"] == "max_depth"
        for case in frontier_cases
    )
    assert all(
        case["first_frontier_witness"]["cap"] == {
            "max_depth": 0,
            "max_nodes": 128,
        }
        for case in frontier_cases
    )
    assert all(case["certified_for_input"] is False for case in frontier_cases)
    assert all(
        case["bounded_homfly_maturity_path"] == "not_certified"
        for case in frontier_cases
    )
    assert all(
        case["bounded_homfly_maturity_path_certified"] is False
        for case in frontier_cases
    )
    assert all(
        [
            row["code"]
            for row in case["input_certification_evidence"][
                "certification_blocker_details"
            ]
        ]
        == ["frontier_not_exhausted"]
        for case in frontier_cases
    )
    first_frontier_detail = frontier_cases[0]["input_certification_evidence"][
        "certification_blocker_details"
    ][0]
    assert first_frontier_detail["scope"] == "input_certification"
    assert first_frontier_detail["cap"] == {
        "max_depth": 0,
        "max_nodes": 128,
    }
    assert first_frontier_detail["witness"]["frontier_reasons"] == ["max_depth"]
    assert first_frontier_detail["witness"]["frontier_witness_count"] == 1
    assert first_frontier_detail["witness"]["first_frontier_witness"] == (
        frontier_cases[0]["first_frontier_witness"]
    )
    certified_cases = [case for case in report["cases"] if case["certified_for_input"]]
    assert [case["case_id"] for case in certified_cases] == ["L2a1:0:negative"]

    source_summary = report["source_notation_summary"][0]
    assert source_summary["source_notation"] == "L2a1"
    assert source_summary["frontier_count"] == report["frontier_count"]
    assert source_summary["frontier_case_count"] == report["frontier_case_count"]
    assert source_summary["frontier_reasons"] == ["max_depth"]
    assert source_summary["frontier_reason_counts"] == report["frontier_reason_counts"]
    assert source_summary["frontier_witnesses"] == report["frontier_witnesses"]
    assert source_summary["first_frontier_witness"] == report["first_frontier_witness"]
    assert source_summary["frontier_witness_summary"] == report[
        "frontier_witness_summary"
    ]
    assert source_summary["frontier_branch_depth_counts"] == report[
        "frontier_branch_depth_counts"
    ]
    assert source_summary["truncated_branch_depth_counts"] == []
    assert source_summary["accepted"] is False


def test_homfly_completion_blocker_provenance_links_detail_and_pressure() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_depth=0,
        max_nodes=128,
    )

    gate = report["arbitrary_diagram_completion_gate"]
    provenance = gate["completion_blocker_provenance"]
    arbitrary_detail = report["homfly_completion_blocker_details"][1]

    assert arbitrary_detail["code"] == provenance["completion_blocker_code"]
    assert arbitrary_detail["witness"] == gate
    assert arbitrary_detail["provenance"] == provenance
    assert provenance["frontier_pressure"] == {
        "frontier_count": 6,
        "visible_witness_count": 6,
        "missing_witness_count": 0,
        "frontier_reasons": ["max_depth"],
        "frontier_blocker_reasons": ["max_depth"],
        "first_witness_reason": "max_depth",
        "first_unwitnessed_reason": None,
        "all_frontier_witnessed": True,
        "reason_count": 1,
    }
    assert provenance["frontier_witness"]["first_frontier_witness"] == (
        report["first_frontier_witness"]
    )
    assert provenance["terminal_contribution_audit"] == {
        "terminal_contribution_audit_applicable": True,
        "terminal_contribution_audit_skipped": False,
        "terminal_contribution_matches_result": True,
        "terminal_audit_applicability_matched": True,
        "terminal_mismatch_blocker_expected": False,
        "terminal_mismatch_blocker_present": False,
        "terminal_mismatch_blocker_matched": True,
    }
    assert provenance["certification_blocker_codes"] == [
        "frontier_not_exhausted"
    ]
    assert gate["gate_pressure_consistency"][
        "completion_blocker_provenance_matched"
    ] is True
    assert report["arbitrary_diagram_coverage_certified"] is False


def test_homfly_small_diagram_coverage_reports_max_node_frontier_cases() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_depth=16,
        max_nodes=1,
    )

    assert report["accepted"] is False
    assert report["source_notations"] == ["L2a1"]
    assert report["case_count"] == 7
    assert report["certified_case_count"] == 1
    assert report["bounded_homfly_maturity_path_certified_count"] == 1
    assert any(
        row["bounded_homfly_maturity_path"] == "not_certified"
        and row["case_count"] == 6
        for row in report["bounded_homfly_maturity_path_counts"]
    )
    assert report["uncertified_case_count"] == 6
    assert report["skipped_case_count"] == 6
    assert report["truncated_case_count"] == 6
    assert report["frontier_count"] == 12
    assert report["frontier_case_count"] == 6
    assert report["frontier_reason_count"] == 1
    assert report["frontier_reasons"] == ["max_nodes"]
    assert report["frontier_reason_counts"] == [
        {"frontier_reason": "max_nodes", "case_count": 6, "frontier_count": 12},
    ]
    assert report["frontier_witness_count"] == 8
    assert report["frontier_witness_limit"] == 8
    assert report["frontier_witnesses_truncated"] is True
    assert report["first_frontier_witness"] == report["frontier_witnesses"][0]
    first_report_witness = report["first_frontier_witness"]
    assert first_report_witness["case_id"] == "L2a1:root:root"
    assert first_report_witness["recursive_path"] == ["root", "switch"]
    assert first_report_witness["recursive_depth"] == 1
    assert first_report_witness["reason"] == "max_nodes"
    assert first_report_witness["cap"] == {
        "max_depth": 16,
        "max_nodes": 1,
    }
    assert report["frontier_witness_summary"]["witness_count"] == 8
    assert report["frontier_witness_summary"]["reason_counts"] == [
        {"reason": "max_nodes", "witness_count": 8},
    ]
    assert report["frontier_witness_summary"]["reason_count"] == 1
    assert report["frontier_witness_summary"]["min_depth"] == 1
    assert report["frontier_witness_summary"]["max_depth"] == 1
    assert report["frontier_witness_summary"]["recursive_path_prefix_counts"] == [
        {"path_prefix": ["root", "smooth"], "witness_count": 4},
        {"path_prefix": ["root", "switch"], "witness_count": 4},
    ]
    assert report["frontier_witness_summary"]["recursive_path_prefix_count"] == 2
    assert report["frontier_witness_summary"]["source_kind_counts"] == [
        {"source_kind": "fixture_root", "witness_count": 2},
        {"source_kind": "one_step_skein_branch", "witness_count": 6},
    ]
    assert report["frontier_witness_summary"]["source_kind_count"] == 2
    assert report["frontier_witness_summary"]["branch_counts"] == [
        {"branch": "positive", "witness_count": 4},
        {"branch": "root", "witness_count": 2},
        {"branch": "smoothed", "witness_count": 2},
    ]
    assert report["frontier_witness_summary"]["branch_count"] == 3
    assert report["frontier_witness_summary"]["witness_summary_truncated"] is True
    max_nodes_pressure = {
        "frontier_count": 12,
        "witness_count": 8,
        "unwitnessed_frontier_count": 4,
        "all_frontier_witnessed": False,
        "frontier_reason_counts_available": True,
        "first_witness_reason": "max_nodes",
        "first_unwitnessed_reason": "max_nodes",
        "reason_counts": [
            {
                "reason": "max_nodes",
                "frontier_count": 12,
                "witness_count": 8,
                "unwitnessed_frontier_count": 4,
                "all_frontier_witnessed": False,
            },
        ],
        "reason_count": 1,
    }
    assert report["frontier_witness_summary"]["run_cap_frontier_pressure"] == (
        max_nodes_pressure
    )
    _assert_homfly_source_summary_consistency(report)
    _assert_homfly_case_evidence_consistency(report)
    assert report["frontier_branch_depth_counts"] == [
        {"branch_depth": 0, "case_count": 1},
        {"branch_depth": 1, "case_count": 5},
    ]
    assert report["truncated_branch_depth_counts"] == [
        {"branch_depth": 0, "case_count": 1},
        {"branch_depth": 1, "case_count": 5},
    ]
    assert report["frontier_source_kind_counts"] == [
        {"source_kind": "fixture_root", "case_count": 1},
        {"source_kind": "one_step_skein_branch", "case_count": 5},
    ]
    assert report["truncated_source_kind_counts"] == [
        {"source_kind": "fixture_root", "case_count": 1},
        {"source_kind": "one_step_skein_branch", "case_count": 5},
    ]
    assert report["frontier_branch_counts"] == [
        {"branch": "negative", "case_count": 1},
        {"branch": "positive", "case_count": 2},
        {"branch": "root", "case_count": 1},
        {"branch": "smoothed", "case_count": 2},
    ]
    assert report["truncated_branch_counts"] == report["frontier_branch_counts"]
    assert report["max_depth"] == 16
    assert report["max_nodes"] == 1
    assert report["solved_depth_counts"] == [
        {"solved_depth": 0, "case_count": 1},
    ]
    assert report["full_table_normalization_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False
    _assert_homfly_completion_blockers(report)
    gate = report["arbitrary_diagram_completion_gate"]
    assert gate["truncated"] is True
    assert gate["truncated_case_count"] == 6
    assert gate["frontier_reasons"] == ["max_nodes"]
    assert gate["frontier_reason_counts"] == report["frontier_reason_counts"]
    assert gate["frontier_witness_count"] == 8
    assert gate["frontier_witnesses_truncated"] is True
    assert gate["first_frontier_witness"] == report["first_frontier_witness"]
    assert gate["frontier_witness_summary"]["run_cap_frontier_pressure"] == (
        max_nodes_pressure
    )
    assert gate["certification_blockers"] == [
        "frontier_not_exhausted",
        "truncated_recursive_evaluation",
    ]
    assert gate["certification_blocker_detail_count"] == 12
    pressure_consistency = gate["gate_pressure_consistency"]
    assert pressure_consistency["visible_witness_count"] == 8
    assert pressure_consistency["missing_witness_count"] == 4
    assert pressure_consistency["frontier_blocker_reasons"] == ["max_nodes"]
    assert pressure_consistency["truncation_blocker_matched"] is True
    assert pressure_consistency["non_claim_matched"] is True

    frontier_cases = [
        case for case in report["cases"] if case["frontier_count"] > 0
    ]
    assert len(frontier_cases) == report["frontier_case_count"]
    assert all(case["frontier_reasons"] == ["max_nodes"] for case in frontier_cases)
    assert all(case["frontier_witness_count"] == 2 for case in frontier_cases)
    assert all(
        case["first_frontier_witness"]["reason"] == "max_nodes"
        for case in frontier_cases
    )
    assert all(
        case["first_frontier_witness"]["cap"] == {
            "max_depth": 16,
            "max_nodes": 1,
        }
        for case in frontier_cases
    )
    assert all(case["truncated"] is True for case in frontier_cases)
    assert all(case["certified_for_input"] is False for case in frontier_cases)
    assert all(
        case["bounded_homfly_maturity_path"] == "not_certified"
        for case in frontier_cases
    )
    assert all(
        case["bounded_homfly_maturity_path_certified"] is False
        for case in frontier_cases
    )
    assert all(
        [
            row["code"]
            for row in case["input_certification_evidence"][
                "certification_blocker_details"
            ]
        ]
        == ["frontier_not_exhausted", "truncated_recursive_evaluation"]
        for case in frontier_cases
    )
    first_truncated_details = frontier_cases[0]["input_certification_evidence"][
        "certification_blocker_details"
    ]
    assert first_truncated_details[0]["cap"] == {
        "max_depth": 16,
        "max_nodes": 1,
    }
    assert first_truncated_details[0]["witness"]["frontier_reasons"] == ["max_nodes"]
    assert first_truncated_details[0]["witness"]["frontier_witness_count"] == 2
    assert first_truncated_details[0]["witness"]["first_frontier_witness"] == (
        frontier_cases[0]["first_frontier_witness"]
    )
    assert first_truncated_details[1]["witness"]["truncated"] is True

    source_summary = report["source_notation_summary"][0]
    assert source_summary["frontier_count"] == report["frontier_count"]
    assert source_summary["frontier_case_count"] == report["frontier_case_count"]
    assert source_summary["truncated_case_count"] == report["truncated_case_count"]
    assert source_summary["frontier_reasons"] == ["max_nodes"]
    assert source_summary["frontier_reason_counts"] == report["frontier_reason_counts"]
    assert source_summary["frontier_witness_count"] == 8
    assert source_summary["frontier_witnesses_truncated"] is True
    assert source_summary["first_frontier_witness"] == report["first_frontier_witness"]
    assert source_summary["frontier_witness_summary"] == report[
        "frontier_witness_summary"
    ]
    assert source_summary["frontier_branch_depth_counts"] == report[
        "frontier_branch_depth_counts"
    ]
    assert source_summary["truncated_branch_depth_counts"] == report[
        "truncated_branch_depth_counts"
    ]
    assert source_summary["accepted"] is False


def test_homfly_source_summary_consistency_reports_mismatch_witnesses() -> None:
    from iroll.topology.homfly import (
        _homfly_source_notation_summary_consistency_record,
    )

    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=1,
        max_depth=0,
        max_nodes=128,
    )
    mutated = dict(report)
    mutated["fixture_count"] = report["fixture_count"] + 1
    mutated["case_count"] = report["case_count"] + 1
    mutated["truncated_branch_depth_counts"] = [
        {"branch_depth": 1, "case_count": 99},
    ]
    mutated["frontier_reason_counts"] = [
        {
            "frontier_reason": "synthetic_frontier",
            "case_count": 1,
            "frontier_count": 99,
        },
    ]

    consistency = _homfly_source_notation_summary_consistency_record(mutated)

    assert consistency["matched"] is False
    assert consistency["source_notation_count_matches_fixture_count"] is False
    assert consistency["count_totals_matched"] is False
    assert consistency["distribution_totals_matched"] is False
    assert consistency["frontier_reason_counts_matched"] is False
    assert consistency["frontier_witness_summary_matched"] is True
    assert consistency["mismatch_count"] == 4
    assert consistency["first_mismatch"] == {
        "kind": "source_notation_count",
        "field": "source_notation_count",
        "tags": ["source", "count"],
        "report_value": 2,
        "source_value": 1,
    }
    assert consistency["mismatch_witnesses"][1] == {
        "kind": "count_total",
        "field": "case_count",
        "tags": ["count"],
        "report_value": 8,
        "source_value": 7,
    }
    assert consistency["mismatch_witnesses"][2] == {
        "kind": "distribution_total",
        "field": "truncated_branch_depth_counts",
        "tags": ["truncation", "branch", "count"],
        "report_value": [{"branch_depth": 1, "case_count": 99}],
        "source_value": [],
    }
    assert consistency["mismatch_witnesses"][3] == {
        "kind": "frontier_reason_counts",
        "field": "frontier_reason_counts",
        "tags": ["frontier", "count"],
        "report_value": [
            {
                "frontier_reason": "synthetic_frontier",
                "case_count": 1,
                "frontier_count": 99,
            },
        ],
        "source_value": [
            {"frontier_reason": "max_depth", "case_count": 6, "frontier_count": 6},
        ],
    }


def test_homfly_small_diagram_coverage_report_supports_bounded_branch_depth_two() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=2,
    )

    assert report["accepted"] is True
    assert report["source_notations"] == ["L2a1"]
    assert report["branch_depth"] == 2
    assert report["max_generated_branch_depth"] == 2
    assert report["case_count"] == 37
    assert report["non_fixture_case_count"] == 36
    assert report["unique_diagram_count"] == 7
    assert report["unique_oriented_diagram_count"] == 9
    assert report["duplicate_diagram_case_count"] == 30
    assert report["multi_path_diagram_count"] == 7
    assert report["max_diagram_case_count"] == 9
    assert report["polynomial_variant_diagram_count"] == 0
    assert report["max_homfly_polynomial_count_per_diagram"] == 1
    assert report["oriented_polynomial_conflict_count"] == 0
    assert report["max_homfly_polynomial_count_per_oriented_diagram"] == 1
    assert report["certified_case_count"] == 37
    assert report["uncertified_case_count"] == 0
    assert report["relation_error_count"] == 0
    assert report["frontier_count"] == 0
    assert report["truncated_case_count"] == 0
    _assert_homfly_source_summary_consistency(report)
    _assert_solved_depth_counts(report, report["certified_case_count"])
    assert len(report["source_notation_summary"]) == 1
    source_summary = report["source_notation_summary"][0]
    assert source_summary["source_notation"] == "L2a1"
    assert source_summary["case_count"] == report["case_count"]
    assert source_summary["unique_diagram_count"] == report["unique_diagram_count"]
    assert source_summary["unique_oriented_diagram_count"] == report[
        "unique_oriented_diagram_count"
    ]
    assert source_summary["duplicate_diagram_case_count"] == report[
        "duplicate_diagram_case_count"
    ]
    _assert_solved_depth_counts(source_summary, report["certified_case_count"])
    assert source_summary["branch_depth_counts"] == [
        {"branch_depth": 0, "case_count": 1},
        {"branch_depth": 1, "case_count": 6},
        {"branch_depth": 2, "case_count": 30},
    ]
    assert source_summary["source_kind_counts"] == [
        {"source_kind": "fixture_root", "case_count": 1},
        {"source_kind": "multi_step_skein_branch", "case_count": 30},
        {"source_kind": "one_step_skein_branch", "case_count": 6},
    ]
    assert source_summary["accepted"] is True
    assert Counter(case["branch_depth"] for case in report["cases"]) == {
        0: 1,
        1: 6,
        2: 30,
    }
    assert Counter(case["source_kind"] for case in report["cases"]) == {
        "fixture_root": 1,
        "one_step_skein_branch": 6,
        "multi_step_skein_branch": 30,
    }
    depth_two = [case for case in report["cases"] if case["branch_depth"] == 2]
    assert all(case["parent_case_id"] for case in depth_two)
    assert all(len(case["branch_path"]) == 2 for case in depth_two)
    assert all(case["certified_for_input"] for case in report["cases"])
    multiplicity = report["diagram_multiplicity_summary"]
    assert multiplicity["case_count_with_diagram_key"] == 37
    assert multiplicity["unique_diagram_count"] == 7
    assert multiplicity["unique_oriented_diagram_count"] == 9
    assert multiplicity["duplicate_diagram_case_count"] == 30
    assert multiplicity["multi_path_diagram_count"] == 7
    assert multiplicity["max_case_count_per_diagram"] == 9
    assert multiplicity["polynomial_variant_diagram_count"] == report["polynomial_variant_diagram_count"]
    assert multiplicity["max_homfly_polynomial_count_per_diagram"] == report["max_homfly_polynomial_count_per_diagram"]
    assert (
        multiplicity["oriented_polynomial_conflict_count"]
        == report["oriented_polynomial_conflict_count"]
    )
    assert (
        multiplicity["max_homfly_polynomial_count_per_oriented_diagram"]
        == report["max_homfly_polynomial_count_per_oriented_diagram"]
    )
    root_group = multiplicity["diagrams"][0]
    assert root_group["case_count"] == 9
    assert "L2a1:root:root" in root_group["case_ids"]
    assert ["0:positive", "0:positive"] in root_group["branch_paths"]
    assert root_group["branch_depths"] == [0, 1, 2]
    assert root_group["homfly_polynomial_count"] == 1


def test_homfly_small_diagram_coverage_depth_two_extends_knot_fixtures() -> None:
    expected = {
        "3_1": {
            "case_count": 82,
            "unique_diagram_count": 11,
            "unique_oriented_diagram_count": 16,
            "duplicate_diagram_case_count": 71,
            "multi_path_diagram_count": 11,
            "max_diagram_case_count": 21,
            "max_solved_depth": 4,
            "polynomial_variant_diagram_count": 0,
            "max_homfly_polynomial_count_per_diagram": 1,
            "oriented_polynomial_conflict_count": 0,
            "max_homfly_polynomial_count_per_oriented_diagram": 1,
            "branch_counts": {0: 1, 1: 9, 2: 72},
        },
        "4_1": {
            "case_count": 145,
            "unique_diagram_count": 32,
            "unique_oriented_diagram_count": 39,
            "duplicate_diagram_case_count": 113,
            "multi_path_diagram_count": 30,
            "max_diagram_case_count": 23,
            "max_solved_depth": 7,
            "polynomial_variant_diagram_count": 0,
            "max_homfly_polynomial_count_per_diagram": 1,
            "oriented_polynomial_conflict_count": 0,
            "max_homfly_polynomial_count_per_oriented_diagram": 1,
            "branch_counts": {0: 1, 1: 12, 2: 132},
        },
    }

    for notation, metrics in expected.items():
        report = homfly_small_diagram_coverage_report(
            notations=[notation],
            branch_depth=2,
            max_depth=10,
            max_nodes=4096,
        )

        assert report["accepted"] is True
        assert report["source_notations"] == [notation]
        assert report["branch_depth"] == 2
        assert report["max_generated_branch_depth"] == 2
        assert report["case_count"] == metrics["case_count"]
        assert report["non_fixture_case_count"] == metrics["case_count"] - 1
        assert report["unique_diagram_count"] == metrics["unique_diagram_count"]
        assert report["unique_oriented_diagram_count"] == metrics[
            "unique_oriented_diagram_count"
        ]
        assert report["duplicate_diagram_case_count"] == metrics[
            "duplicate_diagram_case_count"
        ]
        assert report["multi_path_diagram_count"] == metrics["multi_path_diagram_count"]
        assert report["max_diagram_case_count"] == metrics["max_diagram_case_count"]
        assert report["polynomial_variant_diagram_count"] == metrics["polynomial_variant_diagram_count"]
        assert report["max_homfly_polynomial_count_per_diagram"] == metrics["max_homfly_polynomial_count_per_diagram"]
        assert (
            report["oriented_polynomial_conflict_count"]
            == metrics["oriented_polynomial_conflict_count"]
        )
        assert (
            report["max_homfly_polynomial_count_per_oriented_diagram"]
            == metrics["max_homfly_polynomial_count_per_oriented_diagram"]
        )
        assert report["max_solved_depth"] == metrics["max_solved_depth"]
        _assert_solved_depth_counts(report, metrics["case_count"])
        assert report["certified_case_count"] == metrics["case_count"]
        assert report["uncertified_case_count"] == 0
        assert report["relation_error_count"] == 0
        assert report["frontier_count"] == 0
        assert report["truncated_case_count"] == 0
        assert Counter(case["branch_depth"] for case in report["cases"]) == metrics[
            "branch_counts"
        ]
        assert all(case["certified_for_input"] for case in report["cases"])
        assert all(case["frontier_count"] == 0 for case in report["cases"])
        assert all(case["truncated"] is False for case in report["cases"])
        multiplicity = report["diagram_multiplicity_summary"]
        assert multiplicity["unique_diagram_count"] == metrics["unique_diagram_count"]
        assert multiplicity["unique_oriented_diagram_count"] == metrics[
            "unique_oriented_diagram_count"
        ]
        assert multiplicity["duplicate_diagram_case_count"] == metrics[
            "duplicate_diagram_case_count"
        ]
        assert multiplicity["multi_path_diagram_count"] == metrics[
            "multi_path_diagram_count"
        ]
        assert multiplicity["max_case_count_per_diagram"] == metrics[
            "max_diagram_case_count"
        ]
        assert multiplicity["polynomial_variant_diagram_count"] == report["polynomial_variant_diagram_count"]
        assert multiplicity["max_homfly_polynomial_count_per_diagram"] == report["max_homfly_polynomial_count_per_diagram"]
        assert (
            multiplicity["oriented_polynomial_conflict_count"]
            == report["oriented_polynomial_conflict_count"]
        )
        assert (
            multiplicity["max_homfly_polynomial_count_per_oriented_diagram"]
            == report["max_homfly_polynomial_count_per_oriented_diagram"]
        )


def test_homfly_small_diagram_coverage_depth_three_extends_generated_frontier() -> None:
    expected = {
        "L2a1": {
            "case_count": 169,
            "unique_diagram_count": 7,
            "unique_oriented_diagram_count": 9,
            "duplicate_diagram_case_count": 162,
            "multi_path_diagram_count": 7,
            "max_diagram_case_count": 35,
            "max_solved_depth": 3,
            "polynomial_variant_diagram_count": 0,
            "max_homfly_polynomial_count_per_diagram": 1,
            "oriented_polynomial_conflict_count": 0,
            "max_homfly_polynomial_count_per_oriented_diagram": 1,
            "branch_counts": {0: 1, 1: 6, 2: 30, 3: 132},
            "source_kind_counts": {
                "fixture_root": 1,
                "one_step_skein_branch": 6,
                "multi_step_skein_branch": 162,
            },
        },
        "3_1": {
            "case_count": 604,
            "unique_diagram_count": 15,
            "unique_oriented_diagram_count": 26,
            "duplicate_diagram_case_count": 589,
            "multi_path_diagram_count": 15,
            "max_diagram_case_count": 123,
            "max_solved_depth": 4,
            "polynomial_variant_diagram_count": 0,
            "max_homfly_polynomial_count_per_diagram": 1,
            "oriented_polynomial_conflict_count": 0,
            "max_homfly_polynomial_count_per_oriented_diagram": 1,
            "branch_counts": {0: 1, 1: 9, 2: 72, 3: 522},
            "source_kind_counts": {
                "fixture_root": 1,
                "one_step_skein_branch": 9,
                "multi_step_skein_branch": 594,
            },
        },
        "4_1": {
            "case_count": 1489,
            "unique_diagram_count": 68,
            "unique_oriented_diagram_count": 108,
            "duplicate_diagram_case_count": 1421,
            "multi_path_diagram_count": 68,
            "max_diagram_case_count": 111,
            "max_solved_depth": 7,
            "polynomial_variant_diagram_count": 0,
            "max_homfly_polynomial_count_per_diagram": 1,
            "oriented_polynomial_conflict_count": 0,
            "max_homfly_polynomial_count_per_oriented_diagram": 1,
            "branch_counts": {0: 1, 1: 12, 2: 132, 3: 1344},
            "source_kind_counts": {
                "fixture_root": 1,
                "one_step_skein_branch": 12,
                "multi_step_skein_branch": 1476,
            },
        },
    }

    for notation, metrics in expected.items():
        report = homfly_small_diagram_coverage_report(
            notations=[notation],
            branch_depth=3,
            max_depth=12,
            max_nodes=8192,
        )

        assert report["accepted"] is True
        assert report["source_notations"] == [notation]
        assert report["branch_depth"] == 3
        assert report["max_generated_branch_depth"] == 3
        assert report["case_count"] == metrics["case_count"]
        assert report["non_fixture_case_count"] == metrics["case_count"] - 1
        assert report["certified_case_count"] == metrics["case_count"]
        assert report["uncertified_case_count"] == 0
        assert report["skipped_case_count"] == 0
        assert report["relation_error_count"] == 0
        assert report["frontier_count"] == 0
        assert report["frontier_reason_count"] == 0
        assert report["frontier_reasons"] == []
        assert report["truncated_case_count"] == 0
        assert report["unique_diagram_count"] == metrics["unique_diagram_count"]
        assert report["unique_oriented_diagram_count"] == metrics[
            "unique_oriented_diagram_count"
        ]
        assert report["duplicate_diagram_case_count"] == metrics[
            "duplicate_diagram_case_count"
        ]
        assert report["multi_path_diagram_count"] == metrics["multi_path_diagram_count"]
        assert report["max_diagram_case_count"] == metrics["max_diagram_case_count"]
        assert report["polynomial_variant_diagram_count"] == metrics["polynomial_variant_diagram_count"]
        assert report["max_homfly_polynomial_count_per_diagram"] == metrics["max_homfly_polynomial_count_per_diagram"]
        assert (
            report["oriented_polynomial_conflict_count"]
            == metrics["oriented_polynomial_conflict_count"]
        )
        assert (
            report["max_homfly_polynomial_count_per_oriented_diagram"]
            == metrics["max_homfly_polynomial_count_per_oriented_diagram"]
        )
        assert report["max_solved_depth"] == metrics["max_solved_depth"]
        _assert_solved_depth_counts(report, metrics["case_count"])
        assert Counter(case["branch_depth"] for case in report["cases"]) == metrics[
            "branch_counts"
        ]
        assert Counter(case["source_kind"] for case in report["cases"]) == metrics[
            "source_kind_counts"
        ]
        assert all(case["certified_for_input"] for case in report["cases"])
        assert all(case["frontier_count"] == 0 for case in report["cases"])
        assert all(case["frontier_reasons"] == [] for case in report["cases"])
        assert all(case["truncated"] is False for case in report["cases"])

        depth_three = [case for case in report["cases"] if case["branch_depth"] == 3]
        assert depth_three
        assert all(case["parent_case_id"] for case in depth_three)
        assert all(len(case["branch_path"]) == 3 for case in depth_three)

        multiplicity = report["diagram_multiplicity_summary"]
        assert multiplicity["unique_diagram_count"] == metrics["unique_diagram_count"]
        assert multiplicity["unique_oriented_diagram_count"] == metrics[
            "unique_oriented_diagram_count"
        ]
        assert multiplicity["duplicate_diagram_case_count"] == metrics[
            "duplicate_diagram_case_count"
        ]
        assert multiplicity["multi_path_diagram_count"] == metrics[
            "multi_path_diagram_count"
        ]
        assert multiplicity["max_case_count_per_diagram"] == metrics[
            "max_diagram_case_count"
        ]
        assert multiplicity["polynomial_variant_diagram_count"] == report["polynomial_variant_diagram_count"]
        assert multiplicity["max_homfly_polynomial_count_per_diagram"] == report["max_homfly_polynomial_count_per_diagram"]
        assert (
            multiplicity["oriented_polynomial_conflict_count"]
            == report["oriented_polynomial_conflict_count"]
        )
        assert (
            multiplicity["max_homfly_polynomial_count_per_oriented_diagram"]
            == report["max_homfly_polynomial_count_per_oriented_diagram"]
        )
        assert report["full_table_normalization_certified"] is False
        assert report["arbitrary_diagram_coverage_certified"] is False


def test_homfly_small_diagram_coverage_depth_four_extends_generated_frontier() -> None:
    expected = {
        "L2a1": {
            "case_count": 721,
            "unique_diagram_count": 7,
            "unique_oriented_diagram_count": 9,
            "duplicate_diagram_case_count": 714,
            "multi_path_diagram_count": 7,
            "max_diagram_case_count": 155,
            "max_solved_depth": 3,
            "polynomial_variant_diagram_count": 0,
            "max_homfly_polynomial_count_per_diagram": 1,
            "oriented_polynomial_conflict_count": 0,
            "max_homfly_polynomial_count_per_oriented_diagram": 1,
            "branch_counts": {0: 1, 1: 6, 2: 30, 3: 132, 4: 552},
        },
        "3_1": {
            "case_count": 4132,
            "unique_diagram_count": 15,
            "unique_oriented_diagram_count": 29,
            "duplicate_diagram_case_count": 4117,
            "multi_path_diagram_count": 15,
            "max_diagram_case_count": 699,
            "max_solved_depth": 4,
            "polynomial_variant_diagram_count": 0,
            "max_homfly_polynomial_count_per_diagram": 1,
            "oriented_polynomial_conflict_count": 0,
            "max_homfly_polynomial_count_per_oriented_diagram": 1,
            "branch_counts": {0: 1, 1: 9, 2: 72, 3: 522, 4: 3528},
        },
        "4_1": {
            "case_count": 14329,
            "unique_diagram_count": 99,
            "unique_oriented_diagram_count": 205,
            "duplicate_diagram_case_count": 14230,
            "multi_path_diagram_count": 99,
            "max_diagram_case_count": 952,
            "max_solved_depth": 7,
            "polynomial_variant_diagram_count": 0,
            "max_homfly_polynomial_count_per_diagram": 1,
            "oriented_polynomial_conflict_count": 0,
            "max_homfly_polynomial_count_per_oriented_diagram": 1,
            "branch_counts": {0: 1, 1: 12, 2: 132, 3: 1344, 4: 12840},
        },
    }

    for notation, metrics in expected.items():
        report = homfly_small_diagram_coverage_report(
            notations=[notation],
            branch_depth=4,
            max_depth=14,
            max_nodes=32768,
        )

        assert report["accepted"] is True
        assert report["source_notations"] == [notation]
        assert report["branch_depth"] == 4
        assert report["max_generated_branch_depth"] == 4
        assert report["case_count"] == metrics["case_count"]
        assert report["certified_case_count"] == metrics["case_count"]
        assert report["uncertified_case_count"] == 0
        assert report["frontier_count"] == 0
        assert report["frontier_reason_count"] == 0
        assert report["truncated_case_count"] == 0
        assert report["unique_diagram_count"] == metrics["unique_diagram_count"]
        assert report["unique_oriented_diagram_count"] == metrics[
            "unique_oriented_diagram_count"
        ]
        assert report["duplicate_diagram_case_count"] == metrics[
            "duplicate_diagram_case_count"
        ]
        assert report["multi_path_diagram_count"] == metrics["multi_path_diagram_count"]
        assert report["max_diagram_case_count"] == metrics["max_diagram_case_count"]
        assert report["polynomial_variant_diagram_count"] == metrics["polynomial_variant_diagram_count"]
        assert report["max_homfly_polynomial_count_per_diagram"] == metrics["max_homfly_polynomial_count_per_diagram"]
        assert (
            report["oriented_polynomial_conflict_count"]
            == metrics["oriented_polynomial_conflict_count"]
        )
        assert (
            report["max_homfly_polynomial_count_per_oriented_diagram"]
            == metrics["max_homfly_polynomial_count_per_oriented_diagram"]
        )
        assert report["max_solved_depth"] == metrics["max_solved_depth"]
        _assert_solved_depth_counts(report, metrics["case_count"])
        assert Counter(case["branch_depth"] for case in report["cases"]) == metrics[
            "branch_counts"
        ]
        depth_four = [case for case in report["cases"] if case["branch_depth"] == 4]
        assert depth_four
        assert all(case["parent_case_id"] for case in depth_four)
        assert all(len(case["branch_path"]) == 4 for case in depth_four)
        assert all(case["certified_for_input"] for case in report["cases"])
        assert all(case["frontier_reasons"] == [] for case in report["cases"])
        assert all(case["truncated"] is False for case in report["cases"])
        assert report["full_table_normalization_certified"] is False
        assert report["arbitrary_diagram_coverage_certified"] is False


def test_homfly_small_diagram_coverage_depth_five_extends_hopf_frontier() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=5,
        max_depth=14,
        max_nodes=32768,
    )

    assert report["accepted"] is True
    assert report["source_notations"] == ["L2a1"]
    assert report["branch_depth"] == 5
    assert report["max_generated_branch_depth"] == 5
    assert report["case_count"] == 2977
    assert report["non_fixture_case_count"] == 2976
    assert report["certified_case_count"] == 2977
    assert report["uncertified_case_count"] == 0
    assert report["frontier_count"] == 0
    assert report["frontier_reason_count"] == 0
    assert report["truncated_case_count"] == 0
    assert report["unique_diagram_count"] == 7
    assert report["unique_oriented_diagram_count"] == 9
    assert report["duplicate_diagram_case_count"] == 2970
    assert report["multi_path_diagram_count"] == 7
    assert report["max_diagram_case_count"] == 651
    assert report["max_solved_depth"] == 3
    assert report["solved_depth_counts"] == [
        {"solved_depth": 0, "case_count": 961},
        {"solved_depth": 1, "case_count": 992},
        {"solved_depth": 2, "case_count": 683},
        {"solved_depth": 3, "case_count": 341},
    ]
    _assert_solved_depth_counts(report, report["certified_case_count"])
    assert Counter(case["branch_depth"] for case in report["cases"]) == {
        0: 1,
        1: 6,
        2: 30,
        3: 132,
        4: 552,
        5: 2256,
    }
    assert Counter(case["source_kind"] for case in report["cases"]) == {
        "fixture_root": 1,
        "one_step_skein_branch": 6,
        "multi_step_skein_branch": 2970,
    }
    source_summary = report["source_notation_summary"][0]
    assert source_summary["source_notation"] == "L2a1"
    assert source_summary["case_count"] == report["case_count"]
    assert source_summary["solved_depth_counts"] == report["solved_depth_counts"]
    assert source_summary["accepted"] is True
    assert report["full_table_normalization_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False


def test_homfly_small_diagram_coverage_depth_six_extends_hopf_frontier() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["L2a1"],
        branch_depth=6,
        max_depth=14,
        max_nodes=32768,
    )

    assert report["accepted"] is True
    assert report["source_notations"] == ["L2a1"]
    assert report["branch_depth"] == 6
    assert report["max_generated_branch_depth"] == 6
    assert report["case_count"] == 12097
    assert report["non_fixture_case_count"] == 12096
    assert report["certified_case_count"] == 12097
    assert report["uncertified_case_count"] == 0
    assert report["frontier_count"] == 0
    assert report["frontier_reason_count"] == 0
    assert report["truncated_case_count"] == 0
    assert report["unique_diagram_count"] == 7
    assert report["unique_oriented_diagram_count"] == 9
    assert report["unique_evaluation_count"] == 9
    assert report["reused_evaluation_count"] == 12088
    assert report["duplicate_diagram_case_count"] == 12090
    assert report["multi_path_diagram_count"] == 7
    assert report["max_diagram_case_count"] == 2667
    assert report["max_solved_depth"] == 3
    assert report["polynomial_variant_diagram_count"] == 0
    assert report["max_homfly_polynomial_count_per_diagram"] == 1
    assert report["oriented_polynomial_conflict_count"] == 0
    assert report["max_homfly_polynomial_count_per_oriented_diagram"] == 1
    assert report["solved_depth_counts"] == [
        {"solved_depth": 0, "case_count": 3969},
        {"solved_depth": 1, "case_count": 4032},
        {"solved_depth": 2, "case_count": 2731},
        {"solved_depth": 3, "case_count": 1365},
    ]
    _assert_solved_depth_counts(report, report["certified_case_count"])
    assert Counter(case["branch_depth"] for case in report["cases"]) == {
        0: 1,
        1: 6,
        2: 30,
        3: 132,
        4: 552,
        5: 2256,
        6: 9120,
    }
    assert Counter(case["source_kind"] for case in report["cases"]) == {
        "fixture_root": 1,
        "one_step_skein_branch": 6,
        "multi_step_skein_branch": 12090,
    }
    source_summary = report["source_notation_summary"][0]
    assert source_summary["source_notation"] == "L2a1"
    assert source_summary["case_count"] == report["case_count"]
    assert source_summary["solved_depth_counts"] == report["solved_depth_counts"]
    assert source_summary["branch_depth_counts"][-1] == {
        "branch_depth": 6,
        "case_count": 9120,
    }
    assert source_summary["accepted"] is True
    assert all(case["certified_for_input"] for case in report["cases"])
    assert all(case["frontier_count"] == 0 for case in report["cases"])
    assert all(case["truncated"] is False for case in report["cases"])
    assert report["full_table_normalization_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False


def test_homfly_small_diagram_coverage_depth_five_extends_trefoil_frontier() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["3_1"],
        branch_depth=5,
        max_depth=12,
        max_nodes=8192,
    )

    assert report["accepted"] is True
    assert report["source_notations"] == ["3_1"]
    assert report["branch_depth"] == 5
    assert report["max_generated_branch_depth"] == 5
    assert report["case_count"] == 26956
    assert report["non_fixture_case_count"] == 26955
    assert report["certified_case_count"] == 26956
    assert report["uncertified_case_count"] == 0
    assert report["frontier_count"] == 0
    assert report["frontier_reason_count"] == 0
    assert report["truncated_case_count"] == 0
    assert report["unique_diagram_count"] == 15
    assert report["unique_oriented_diagram_count"] == 29
    assert report["duplicate_diagram_case_count"] == 26941
    assert report["multi_path_diagram_count"] == 15
    assert report["max_diagram_case_count"] == 3987
    assert report["max_solved_depth"] == 4
    assert report["polynomial_variant_diagram_count"] == 0
    assert report["max_homfly_polynomial_count_per_diagram"] == 1
    assert report["oriented_polynomial_conflict_count"] == 0
    assert report["max_homfly_polynomial_count_per_oriented_diagram"] == 1
    _assert_solved_depth_counts(report, report["certified_case_count"])
    assert Counter(case["branch_depth"] for case in report["cases"]) == {
        0: 1,
        1: 9,
        2: 72,
        3: 522,
        4: 3528,
        5: 22824,
    }
    assert Counter(case["source_kind"] for case in report["cases"]) == {
        "fixture_root": 1,
        "one_step_skein_branch": 9,
        "multi_step_skein_branch": 26946,
    }
    source_summary = report["source_notation_summary"][0]
    assert source_summary["source_notation"] == "3_1"
    assert source_summary["case_count"] == report["case_count"]
    assert source_summary["solved_depth_counts"] == report["solved_depth_counts"]
    assert source_summary["branch_depth_counts"][-1] == {
        "branch_depth": 5,
        "case_count": 22824,
    }
    assert all(case["certified_for_input"] for case in report["cases"])
    assert all(case["frontier_count"] == 0 for case in report["cases"])
    assert all(case["truncated"] is False for case in report["cases"])
    assert report["full_table_normalization_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False


def test_homfly_small_diagram_coverage_depth_six_extends_trefoil_frontier() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["3_1"],
        branch_depth=6,
        max_depth=12,
        max_nodes=8192,
    )

    assert report["accepted"] is True
    assert report["source_notations"] == ["3_1"]
    assert report["branch_depth"] == 6
    assert report["max_generated_branch_depth"] == 6
    assert report["case_count"] == 170668
    assert report["non_fixture_case_count"] == 170667
    assert report["certified_case_count"] == 170668
    assert report["uncertified_case_count"] == 0
    assert report["frontier_count"] == 0
    assert report["frontier_reason_count"] == 0
    assert report["truncated_case_count"] == 0
    assert report["unique_diagram_count"] == 15
    assert report["unique_oriented_diagram_count"] == 29
    assert report["unique_evaluation_count"] == 29
    assert report["reused_evaluation_count"] == 170639
    assert report["duplicate_diagram_case_count"] == 170653
    assert report["multi_path_diagram_count"] == 15
    assert report["max_diagram_case_count"] == 22995
    assert report["max_solved_depth"] == 4
    assert report["polynomial_variant_diagram_count"] == 0
    assert report["max_homfly_polynomial_count_per_diagram"] == 1
    assert report["oriented_polynomial_conflict_count"] == 0
    assert report["max_homfly_polynomial_count_per_oriented_diagram"] == 1
    _assert_solved_depth_counts(report, report["certified_case_count"])
    assert Counter(case["branch_depth"] for case in report["cases"]) == {
        0: 1,
        1: 9,
        2: 72,
        3: 522,
        4: 3528,
        5: 22824,
        6: 143712,
    }
    assert Counter(case["source_kind"] for case in report["cases"]) == {
        "fixture_root": 1,
        "one_step_skein_branch": 9,
        "multi_step_skein_branch": 170658,
    }
    source_summary = report["source_notation_summary"][0]
    assert source_summary["source_notation"] == "3_1"
    assert source_summary["case_count"] == report["case_count"]
    assert source_summary["solved_depth_counts"] == report["solved_depth_counts"]
    assert source_summary["branch_depth_counts"][-1] == {
        "branch_depth": 6,
        "case_count": 143712,
    }
    assert all(case["certified_for_input"] for case in report["cases"])
    assert all(case["frontier_count"] == 0 for case in report["cases"])
    assert all(case["truncated"] is False for case in report["cases"])
    assert report["full_table_normalization_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False


def test_homfly_small_diagram_coverage_depth_five_extends_figure_eight_frontier() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["4_1"],
        branch_depth=5,
        max_depth=12,
        max_nodes=8192,
    )

    assert report["accepted"] is True
    assert report["source_notations"] == ["4_1"]
    assert report["branch_depth"] == 5
    assert report["max_generated_branch_depth"] == 5
    assert report["case_count"] == 131161
    assert report["non_fixture_case_count"] == 131160
    assert report["certified_case_count"] == 131161
    assert report["uncertified_case_count"] == 0
    assert report["frontier_count"] == 0
    assert report["frontier_reason_count"] == 0
    assert report["truncated_case_count"] == 0
    assert report["unique_diagram_count"] == 112
    assert report["unique_oriented_diagram_count"] == 281
    assert report["unique_evaluation_count"] == 281
    assert report["reused_evaluation_count"] == 130880
    assert report["duplicate_diagram_case_count"] == 131049
    assert report["multi_path_diagram_count"] == 112
    assert report["max_diagram_case_count"] == 7672
    assert report["max_solved_depth"] == 7
    assert report["polynomial_variant_diagram_count"] == 0
    assert report["max_homfly_polynomial_count_per_diagram"] == 1
    assert report["oriented_polynomial_conflict_count"] == 0
    assert report["max_homfly_polynomial_count_per_oriented_diagram"] == 1
    assert report["solved_depth_counts"] == [
        {"solved_depth": 0, "case_count": 10627},
        {"solved_depth": 1, "case_count": 11930},
        {"solved_depth": 2, "case_count": 15166},
        {"solved_depth": 3, "case_count": 21692},
        {"solved_depth": 4, "case_count": 22648},
        {"solved_depth": 5, "case_count": 31822},
        {"solved_depth": 6, "case_count": 13777},
        {"solved_depth": 7, "case_count": 3499},
    ]
    _assert_solved_depth_counts(report, report["certified_case_count"])
    assert Counter(case["branch_depth"] for case in report["cases"]) == {
        0: 1,
        1: 12,
        2: 132,
        3: 1344,
        4: 12840,
        5: 116832,
    }
    assert Counter(case["source_kind"] for case in report["cases"]) == {
        "fixture_root": 1,
        "one_step_skein_branch": 12,
        "multi_step_skein_branch": 131148,
    }
    source_summary = report["source_notation_summary"][0]
    assert source_summary["source_notation"] == "4_1"
    assert source_summary["case_count"] == report["case_count"]
    assert source_summary["solved_depth_counts"] == report["solved_depth_counts"]
    assert source_summary["branch_depth_counts"][-1] == {
        "branch_depth": 5,
        "case_count": 116832,
    }
    assert all(case["certified_for_input"] for case in report["cases"])
    assert all(case["frontier_count"] == 0 for case in report["cases"])
    assert all(case["truncated"] is False for case in report["cases"])
    assert report["full_table_normalization_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False


def test_homfly_small_diagram_coverage_depth_six_extends_figure_eight_frontier() -> None:
    report = homfly_small_diagram_coverage_report(
        notations=["4_1"],
        branch_depth=6,
        max_depth=12,
        max_nodes=8192,
    )

    assert report["accepted"] is True
    assert report["source_notations"] == ["4_1"]
    assert report["branch_depth"] == 6
    assert report["max_generated_branch_depth"] == 6
    assert report["case_count"] == 1157113
    assert report["non_fixture_case_count"] == 1157112
    assert report["certified_case_count"] == 1157113
    assert report["uncertified_case_count"] == 0
    assert report["frontier_count"] == 0
    assert report["frontier_case_count"] == 0
    assert report["frontier_reason_count"] == 0
    assert report["frontier_reasons"] == []
    assert report["truncated_case_count"] == 0
    assert report["unique_diagram_count"] == 115
    assert report["unique_oriented_diagram_count"] == 315
    assert report["unique_evaluation_count"] == 315
    assert report["reused_evaluation_count"] == 1156798
    assert report["duplicate_diagram_case_count"] == 1156998
    assert report["multi_path_diagram_count"] == 115
    assert report["max_diagram_case_count"] == 58320
    assert report["max_solved_depth"] == 7
    assert report["polynomial_variant_diagram_count"] == 0
    assert report["max_homfly_polynomial_count_per_diagram"] == 1
    assert report["oriented_polynomial_conflict_count"] == 0
    assert report["max_homfly_polynomial_count_per_oriented_diagram"] == 1
    assert report["solved_depth_counts"] == [
        {"solved_depth": 0, "case_count": 102259},
        {"solved_depth": 1, "case_count": 117322},
        {"solved_depth": 2, "case_count": 148222},
        {"solved_depth": 3, "case_count": 199660},
        {"solved_depth": 4, "case_count": 199762},
        {"solved_depth": 5, "case_count": 256548},
        {"solved_depth": 6, "case_count": 107633},
        {"solved_depth": 7, "case_count": 25707},
    ]
    _assert_solved_depth_counts(report, report["certified_case_count"])
    assert Counter(case["branch_depth"] for case in report["cases"]) == {
        0: 1,
        1: 12,
        2: 132,
        3: 1344,
        4: 12840,
        5: 116832,
        6: 1025952,
    }
    assert Counter(case["source_kind"] for case in report["cases"]) == {
        "fixture_root": 1,
        "one_step_skein_branch": 12,
        "multi_step_skein_branch": 1157100,
    }
    source_summary = report["source_notation_summary"][0]
    assert source_summary["source_notation"] == "4_1"
    assert source_summary["case_count"] == report["case_count"]
    assert source_summary["solved_depth_counts"] == report["solved_depth_counts"]
    assert source_summary["branch_depth_counts"][-1] == {
        "branch_depth": 6,
        "case_count": 1025952,
    }
    assert source_summary["accepted"] is True
    assert all(case["has_orientation"] for case in report["cases"])
    assert all(case["certified_for_input"] for case in report["cases"])
    assert all(case["frontier_count"] == 0 for case in report["cases"])
    assert all(case["frontier_reasons"] == [] for case in report["cases"])
    assert all(case["truncated"] is False for case in report["cases"])
    assert report["full_table_normalization_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False


def test_homfly_fixture_regression_pack_has_dedicated_entrypoint() -> None:
    for notation in ("0_1", "L0a1", "L2a1", "3_1", "4_1"):
        fixture = get_diagram_fixture(notation)
        comparison = homfly_fixture_comparison(notation)

        assert fixture.expected_homfly
        assert comparison["skipped"] is False
        assert comparison["matched"] is True
        assert comparison["observed_homfly"] == fixture.expected_homfly
        assert comparison["certified_for_input"] is True
        assert comparison["full_table_normalization_certified"] is False


def test_homfly_certified_evaluation_marks_exhausted_input_not_table_certified() -> None:
    fixture = get_diagram_fixture("3_1")
    result = homfly_certified_evaluation_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
    )

    assert result["skipped"] is False
    assert result["certified_for_input"] is True
    assert result["full_table_normalization_certified"] is False
    assert result["arbitrary_diagram_coverage_certified"] is False
    assert result["homfly_polynomial"] == fixture.expected_homfly
    assert result["recursive_evaluation"]["frontier_count"] == 0
    assert result["recursive_evaluation"]["truncated"] is False

    evidence = homfly_input_certification_evidence(result)
    assert evidence["certified_for_input"] is True
    assert evidence["frontier_exhausted"] is True
    assert evidence["zero_crossing_certified"] is False
    assert evidence["bounded_homfly_maturity_path"] == (
        "recursive_switching_to_descending_frontier_exhausted"
    )
    assert evidence["bounded_homfly_maturity_path_certified"] is True
    assert evidence["recursion_nodes"] > 0
    assert evidence["terminal_reduction_count"] > 0
    assert evidence["frontier_count"] == 0
    assert evidence["truncated"] is False
    _assert_homfly_frontier_witness_consistency(evidence)
    assert evidence["certification_blockers"] == []
    assert evidence["certification_blocker_count"] == 0
    assert evidence["certification_blocker_details"] == []
    assert evidence["certification_blocker_detail_count"] == 0
    _assert_homfly_completion_blockers(evidence)
    gate = evidence["arbitrary_diagram_completion_gate"]
    assert gate["certification_blockers"] == []
    assert gate["gate_pressure_consistency"]["visible_witness_count"] == 0
    assert gate["gate_pressure_consistency"]["missing_witness_count"] == 0
    assert gate["gate_pressure_consistency"]["frontier_blocker_reasons"] == []
    assert gate["gate_pressure_consistency"]["non_claim_matched"] is True

    mismatched_result = deepcopy(result)
    mismatched_result["recursive_evaluation"]["terminal_reductions"][0][
        "contribution"
    ] = "0"
    mismatch_evidence = homfly_input_certification_evidence(mismatched_result)
    assert mismatch_evidence["frontier_exhausted"] is True
    assert mismatch_evidence["bounded_homfly_maturity_path"] == "not_certified"
    assert mismatch_evidence["bounded_homfly_maturity_path_certified"] is False
    assert mismatch_evidence["certification_blockers"] == [
        "terminal_contribution_mismatch",
    ]
    assert mismatch_evidence["certification_blocker_count"] == 1
    _assert_blocker_detail_codes(
        mismatch_evidence,
        "certification_blocker_details",
        ["terminal_contribution_mismatch"],
    )
    assert mismatch_evidence["certification_blocker_detail_count"] == 1
    assert mismatch_evidence["certification_blocker_details"][0][
        "witness"
    ]["terminal_contribution_sum"] != mismatch_evidence[
        "certification_blocker_details"
    ][0]["witness"]["homfly_polynomial"]
    _assert_homfly_completion_blockers(mismatch_evidence)
    mismatch_gate = mismatch_evidence["arbitrary_diagram_completion_gate"]
    mismatch_pressure = mismatch_gate["gate_pressure_consistency"]
    mismatch_provenance = mismatch_gate["completion_blocker_provenance"]
    assert mismatch_gate["terminal_contribution_audit_applicable"] is True
    assert mismatch_gate["terminal_contribution_audit_skipped"] is False
    assert mismatch_gate["terminal_contribution_matches_result"] is False
    assert mismatch_pressure["terminal_mismatch_blocker_expected"] is True
    assert mismatch_pressure["terminal_mismatch_blocker_present"] is True
    assert mismatch_pressure["terminal_mismatch_blocker_matched"] is True
    assert mismatch_pressure["terminal_audit_consistency_matched"] is True
    assert mismatch_provenance["terminal_contribution_audit"] == {
        "terminal_contribution_audit_applicable": True,
        "terminal_contribution_audit_skipped": False,
        "terminal_contribution_matches_result": False,
        "terminal_audit_applicability_matched": True,
        "terminal_mismatch_blocker_expected": True,
        "terminal_mismatch_blocker_present": True,
        "terminal_mismatch_blocker_matched": True,
    }


def test_homfly_iterative_certified_evaluation_records_depth_attempts() -> None:
    fixture = get_diagram_fixture("3_1")
    result = homfly_iterative_certified_evaluation_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
        initial_depth=0,
        max_depth=8,
        max_nodes=2048,
    )

    assert result["skipped"] is False
    assert result["certified_for_input"] is True
    assert result["homfly_polynomial"] == fixture.expected_homfly
    assert result["attempt_count"] > 1
    assert result["solved_depth"] is not None
    assert result["solved_depth"] <= 8
    assert result["depth_attempts"][0]["max_depth"] == 0
    assert result["depth_attempts"][-1]["homfly_polynomial"] == fixture.expected_homfly
    assert any(
        attempt["frontier_count"] > 0 or attempt["truncated"]
        for attempt in result["depth_attempts"][:-1]
    )

    evidence = homfly_input_certification_evidence(result)
    assert evidence["certified_for_input"] is True
    assert evidence["frontier_exhausted"] is True
    assert evidence["iterative_attempt_count"] == result["attempt_count"]
    assert evidence["iterative_solved_depth"] == result["solved_depth"]
    assert evidence["iterative_depth_attempts"] == result["depth_attempts"]
    assert evidence["arbitrary_diagram_coverage_certified"] is False


def test_homfly_certified_evaluation_refuses_truncated_frontier() -> None:
    fixture = get_diagram_fixture("3_1")
    result = homfly_certified_evaluation_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
        max_nodes=1,
    )

    assert result["skipped"] is True
    assert result["certified_for_input"] is False
    assert result["homfly_polynomial"] is None
    assert result["recursive_evaluation"]["truncated"] is True
    assert result["recursive_evaluation"]["frontier_count"] > 0
    assert "max_nodes" in result["recursive_evaluation"]["frontier_reasons"]
    assert result["recursive_evaluation"]["frontier_witness_count"] > 0
    assert result["recursive_evaluation"]["first_frontier_witness"]["reason"] == (
        "max_nodes"
    )

    evidence = homfly_input_certification_evidence(result)
    assert evidence["skipped"] is True
    assert evidence["certified_for_input"] is False
    assert evidence["frontier_exhausted"] is False
    assert evidence["truncated"] is True
    assert evidence["frontier_count"] > 0
    assert "max_nodes" in evidence["frontier_reasons"]
    assert evidence["frontier_witness_count"] > 0
    assert evidence["first_frontier_witness"]["reason"] == "max_nodes"
    assert evidence["first_frontier_witness"]["cap"]["max_nodes"] == 1
    _assert_homfly_frontier_witness_consistency(evidence)
    assert evidence["certification_blockers"] == [
        "frontier_not_exhausted",
        "truncated_recursive_evaluation",
    ]
    assert evidence["certification_blocker_count"] == 2
    _assert_blocker_detail_codes(
        evidence,
        "certification_blocker_details",
        ["frontier_not_exhausted", "truncated_recursive_evaluation"],
    )
    assert evidence["certification_blocker_detail_count"] == 2
    frontier_detail, truncated_detail = evidence["certification_blocker_details"]
    assert frontier_detail["scope"] == "input_certification"
    assert frontier_detail["cap"]["max_nodes"] == 1
    assert frontier_detail["witness"]["frontier_count"] == evidence["frontier_count"]
    assert frontier_detail["witness"]["frontier_reasons"] == ["max_nodes"]
    assert frontier_detail["witness"]["frontier_witness_count"] == (
        evidence["frontier_witness_count"]
    )
    assert frontier_detail["witness"]["first_frontier_witness"] == (
        evidence["first_frontier_witness"]
    )
    assert truncated_detail["cap"]["max_nodes"] == 1
    assert truncated_detail["witness"]["truncated"] is True
    _assert_homfly_completion_blockers(evidence)


def test_homfly_input_certification_evidence_handles_missing_result() -> None:
    evidence = homfly_input_certification_evidence(None)

    assert evidence["method"] == "homfly_input_certification_evidence"
    assert evidence["skipped"] is True
    assert evidence["certified_for_input"] is False
    assert evidence["frontier_exhausted"] is False
    assert evidence["bounded_homfly_maturity_path"] == "not_certified"
    assert evidence["bounded_homfly_maturity_path_certified"] is False
    assert evidence["frontier_witness_count"] == 0
    assert evidence["frontier_witness_limit"] == 8
    assert evidence["frontier_witnesses_truncated"] is False
    assert evidence["frontier_witnesses"] == []
    assert evidence["first_frontier_witness"] is None
    _assert_homfly_frontier_witness_consistency(evidence)
    assert evidence["certification_blockers"] == ["no_homfly_result"]
    assert evidence["certification_blocker_count"] == 1
    _assert_blocker_detail_codes(
        evidence,
        "certification_blocker_details",
        ["no_homfly_result"],
    )
    assert evidence["certification_blocker_detail_count"] == 1
    assert evidence["certification_blocker_details"][0]["witness"] == {
        "result_present": False,
    }
    _assert_homfly_completion_blockers(evidence)
    assert evidence["notes"] == ["no HOMFLY result supplied"]


def test_homfly_mirror_fixture_pack_matches_polynomial_transform() -> None:
    for notation in ("L2a1", "3_1", "4_1"):
        comparison = homfly_mirror_fixture_comparison(notation)

        assert comparison["skipped"] is False
        assert comparison["matched"] is True
        assert comparison["mirror_transform_convention"] == (
            "P_mirror(a,z) = P(a^-1,-z)"
        )
        assert comparison["mirrored_homfly"] == homfly_mirror_polynomial(
            comparison["original_homfly"]
        )
        assert comparison["candidate_mirror_transforms"][0]["convention"] == (
            "invert_a_negate_z"
        )
        assert comparison["candidate_mirror_transforms"][0][
            "matched_observed_mirror"
        ] is True
        assert comparison["notes"] == []


def test_homfly_polynomial_convention_variants_include_mirror_transform() -> None:
    variants = homfly_polynomial_convention_variants("a*z + a^-1*z^2")

    assert [variant["name"] for variant in variants] == [
        "identity",
        "invert_a",
        "negate_z",
        "mirror_invert_a_negate_z",
        "invert_z",
        "invert_a_invert_z",
        "negate_z_invert_z",
        "mirror_invert_a_negate_z_invert_z",
    ]
    assert variants[0]["polynomial"] == "a^-1*z^2 + a*z"
    assert variants[1]["polynomial"] == "a^-1*z + a*z^2"
    assert variants[2]["polynomial"] == "a^-1*z^2 - a*z"
    assert variants[3]["polynomial"] == "-a^-1*z + a*z^2"
    assert variants[4]["polynomial"] == "a^-1*z^-2 + a*z^-1"
    assert variants[5]["polynomial"] == "a^-1*z^-1 + a*z^-2"
    assert variants[6]["polynomial"] == "a^-1*z^-2 - a*z^-1"
    assert variants[7]["polynomial"] == "-a^-1*z^-1 + a*z^-2"
    assert variants[3]["polynomial"] == homfly_mirror_polynomial(
        "a*z + a^-1*z^2"
    )


def test_homfly_figure_eight_registered_value_is_polynomial_mirror_invariant() -> None:
    comparison = homfly_mirror_fixture_comparison("4_1")

    assert comparison["registered_expected_homfly"] == "a^-2 - 1 - z^2 + a^2"
    assert comparison["registered_expected_mirror_homfly"] == (
        comparison["registered_expected_homfly"]
    )
    assert comparison["registered_expected_mirror_invariant"] is True
    assert comparison["matched"] is True


def test_homfly_skein_identity_audit_matches_registered_signed_fixtures() -> None:
    for notation in ("L2a1", "3_1", "4_1"):
        fixture = get_diagram_fixture(notation)
        audit = homfly_skein_identity_audit_from_pd(
            fixture.diagram(),
            orientation=fixture.orientation(),
            max_depth=12,
            max_nodes=2048,
        )

        assert audit["skipped"] is False
        assert audit["matched"] is True
        assert audit["checked_crossing_count"] == fixture.diagram().crossing_count
        assert audit["truncated"] is False
        assert all(item["matched"] for item in audit["crossing_audits"])
        assert {item["difference"] for item in audit["crossing_audits"]} == {"0"}


def test_homfly_skein_identity_audit_uses_skein_consistent_figure_eight_roles() -> None:
    fixture = get_diagram_fixture("4_1")
    audit = homfly_skein_identity_audit_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
        max_depth=12,
        max_nodes=2048,
    )

    assert audit["skipped"] is False
    assert audit["matched"] is True
    assert fixture.orientation_role_orders == (
        (0, 3, 2, 1),
        (0, 3, 2, 1),
        (0, 1, 2, 3),
        (0, 1, 2, 3),
    )
    assert fixture.orientation().oriented_component_traversals(fixture.diagram()) == (
        {"component": 0, "edges": [1, 2, 3, 4, 5, 6, 7, 8], "length": 8},
    )


def test_homfly_skein_identity_audit_handles_zero_crossing_and_orientation_gaps() -> None:
    unknot = get_diagram_fixture("0_1").diagram()
    zero = homfly_skein_identity_audit_from_pd(unknot)

    assert zero["skipped"] is False
    assert zero["matched"] is True
    assert zero["checked_crossing_count"] == 0
    assert zero["crossing_audits"] == []

    figure_eight = get_diagram_fixture("4_1").diagram()
    without_explicit_orientation = homfly_skein_identity_audit_from_pd(figure_eight)

    assert without_explicit_orientation["skipped"] is True
    assert without_explicit_orientation["matched"] is False
    assert "valid orientation metadata is required" in without_explicit_orientation["notes"][0]

def test_homfly_iterative_certified_evaluation_refuses_insufficient_depth() -> None:
    fixture = get_diagram_fixture("3_1")
    result = homfly_iterative_certified_evaluation_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
        initial_depth=0,
        max_depth=0,
        max_nodes=2048,
    )

    assert result["skipped"] is True
    assert result["certified_for_input"] is False
    assert result["homfly_polynomial"] is None
    assert result["attempt_count"] == 1
    assert result["depth_attempts"][0]["max_depth"] == 0
    assert result["depth_attempts"][0]["frontier_count"] > 0
    assert "max_depth" in result["depth_attempts"][0]["frontier_reasons"]
    assert result["frontier_reasons"] == ["max_depth"]
    assert result["frontier_reason_count"] == 1

    evidence = homfly_input_certification_evidence(result)
    assert evidence["frontier_exhausted"] is False
    assert evidence["bounded_homfly_maturity_path"] == "not_certified"
    assert evidence["bounded_homfly_maturity_path_certified"] is False
    assert evidence["iterative_attempt_count"] == 1
    assert evidence["iterative_solved_depth"] is None
    assert evidence["frontier_reasons"] == ["max_depth"]
    assert evidence["frontier_reason_count"] == 1
    assert evidence["frontier_witness_count"] == 1
    assert evidence["frontier_witnesses_truncated"] is False
    assert evidence["first_frontier_witness"]["path"] == ["root"]
    assert evidence["first_frontier_witness"]["depth"] == 0
    assert evidence["first_frontier_witness"]["reason"] == "max_depth"
    assert evidence["first_frontier_witness"]["cap"] == {
        "max_depth": 0,
        "max_nodes": 2048,
    }
    _assert_homfly_frontier_witness_consistency(evidence)
    assert evidence["certification_blockers"] == ["frontier_not_exhausted"]
    assert evidence["certification_blocker_count"] == 1
    _assert_blocker_detail_codes(
        evidence,
        "certification_blocker_details",
        ["frontier_not_exhausted"],
    )
    assert evidence["certification_blocker_detail_count"] == 1
    assert evidence["certification_blocker_details"][0]["cap"] == {
        "max_depth": 0,
        "max_nodes": 2048,
    }
    assert evidence["certification_blocker_details"][0]["witness"] == {
        "frontier_count": evidence["frontier_count"],
        "frontier_reasons": ["max_depth"],
        "frontier_exhausted": False,
        "frontier_witness_count": evidence["frontier_witness_count"],
        "first_frontier_witness": evidence["first_frontier_witness"],
    }
    _assert_homfly_completion_blockers(evidence)
    gate = evidence["arbitrary_diagram_completion_gate"]
    assert gate["arbitrary_diagram_coverage_certified"] is False
    assert gate["gate_pressure_consistency"]["visible_witness_count"] == 1
    assert gate["gate_pressure_consistency"]["missing_witness_count"] == max(
        evidence["frontier_count"] - evidence["frontier_witness_count"],
        0,
    )
    assert gate["gate_pressure_consistency"]["frontier_blocker_reasons"] == [
        "max_depth",
    ]
    assert gate["gate_pressure_consistency"]["frontier_blocker_matched"] is True
    assert gate["gate_pressure_consistency"]["non_claim_matched"] is True
