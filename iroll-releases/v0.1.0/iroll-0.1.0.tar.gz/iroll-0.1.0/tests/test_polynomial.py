from __future__ import annotations

import pytest

from iroll.topology.polynomial import (
    LaurentPolynomial,
    MultivariateLaurentPolynomial,
    parse_multivariate_laurent_polynomial,
)


def test_laurent_polynomial_arithmetic_and_formatting() -> None:
    t = LaurentPolynomial.monomial(1, 1, variable="t")
    inv_t = LaurentPolynomial.monomial(1, -1, variable="t")
    poly = (t + inv_t - LaurentPolynomial.constant(2, variable="t")) * t

    assert poly.to_dict() == {0: 1, 1: -2, 2: 1}
    assert poly.format() == "1 - 2t + t^2"


def test_laurent_polynomial_negative_power_for_unit_monomial() -> None:
    minus_t2 = LaurentPolynomial.monomial(-1, 2, variable="t")

    assert (minus_t2 ** -3).to_dict() == {-6: -1}


def test_laurent_polynomial_normalizes_up_to_unit() -> None:
    poly = LaurentPolynomial.from_dict({3: -1, 4: 2}, variable="t")

    assert poly.normalize_unit().to_dict() == {0: 1, 1: -2}


def test_laurent_polynomial_rejects_mismatched_variables() -> None:
    with pytest.raises(ValueError, match="variables"):
        LaurentPolynomial.monomial(1, 1, variable="t") + LaurentPolynomial.monomial(
            1,
            1,
            variable="q",
        )


def test_multivariate_laurent_arithmetic_shift_and_formatting() -> None:
    t1 = MultivariateLaurentPolynomial.monomial(1, (1, 0), variables=("t1", "t2"))
    t2_inv = MultivariateLaurentPolynomial.monomial(1, (0, -1), variables=("t1", "t2"))
    poly = (t1 + t2_inv).shift((-1, 1))

    assert poly.to_dict() == {(0, 1): 1, (-1, 0): 1}
    assert poly.format() == "t1^-1 + t2"


def test_multivariate_laurent_normalizes_unit() -> None:
    poly = MultivariateLaurentPolynomial.from_dict(
        {
            (2, -1): -1,
            (3, 0): 2,
        },
        variables=("x", "y"),
    )

    assert poly.normalize_unit().to_dict() == {(0, 0): 1, (1, 1): -2}


def test_multivariate_laurent_normalization_record_tracks_unit() -> None:
    poly = MultivariateLaurentPolynomial.from_dict(
        {
            (2, -1): -1,
            (3, 0): 2,
        },
        variables=("x", "y"),
    )

    normalized, record = poly.normalize_unit_with_record()

    assert normalized.to_dict() == {(0, 0): 1, (1, 1): -2}
    assert record["method"] == "deterministic_laurent_unit_normalization"
    assert record["variables"] == ["x", "y"]
    assert record["unit_sign"] == -1
    assert record["unit_exponents"] == [-2, 1]
    assert record["minimum_exponents"] == [2, -1]
    assert record["leading_coefficient_before_sign"] == -1

def test_multivariate_laurent_parser_and_exponent_mapping() -> None:
    poly = parse_multivariate_laurent_polynomial(
        "-a^-3*z^-1 + 2a^-1*z^-1 - a*z",
        variables=("a", "z"),
    )
    mirrored = poly.map_exponents(lambda exponents: (-exponents[0], exponents[1]))

    assert poly.to_dict() == {(-3, -1): -1, (-1, -1): 2, (1, 1): -1}
    assert mirrored.to_dict() == {(3, -1): -1, (1, -1): 2, (-1, 1): -1}
    assert mirrored.format() == "-a^-1*z + 2*a*z^-1 - a^3*z^-1"
