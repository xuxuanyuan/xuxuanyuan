from __future__ import annotations

import argparse
from copy import deepcopy
import json
from hashlib import sha256

import pytest

from iroll.cli import (
    _KNOT_ATLAS_PINNED_HOMFLY_SOURCES,
    _homfly_full_certification_pack_producer_command,
    _homfly_full_certification_report_command,
)
from iroll.io import dump_report
from iroll.topology import (
    PDOrientation,
    PlanarDiagram,
    get_diagram_fixture,
    homfly_complete_evaluation_from_pd,
    homfly_descending_terminal_from_pd,
)
from iroll.topology.pd_fixtures import completion_evidence_artifact_audit
from iroll.topology.homfly_certification import (
    canonical_json_sha256,
    full_homfly_pt_evaluation_certification_report_audit,
    serialized_certification_report_bytes,
    serialized_certification_report_sha256,
)
from iroll.topology.polynomial import parse_multivariate_laurent_polynomial


def _polynomial_equal(first: str, second: str) -> bool:
    return parse_multivariate_laurent_polynomial(
        first,
        variables=("a", "z"),
    ) == parse_multivariate_laurent_polynomial(
        second,
        variables=("a", "z"),
    )


@pytest.mark.parametrize("notation", ["4_1", "L5a1", "L6a4"])
def test_complete_homfly_matches_external_table_and_certifies_every_step(
    notation: str,
) -> None:
    fixture = get_diagram_fixture(notation)
    if notation in {"L5a1", "L6a4"}:
        replay = fixture.source_pd_convention_assignment_audit()["candidate_replay"]
        diagram = PlanarDiagram.from_dict(replay["diagram"])
        orientation = PDOrientation.from_dict(replay["orientation"])
        expected = fixture.source_table_homfly_iroll_normalized
    else:
        diagram = fixture.diagram()
        orientation = fixture.orientation()
        expected = fixture.expected_homfly

    result = homfly_complete_evaluation_from_pd(
        diagram,
        orientation=orientation,
    )

    assert expected is not None
    assert result["certified_for_input"] is True
    assert result["resource_cutoffs_used"] is False
    assert result["termination_measure_certified"] is True
    assert result["skein_replay_certified"] is True
    assert result["terminal_normalization_certified"] is True
    assert result["frontier_count"] == 0
    assert result["truncated"] is False
    assert _polynomial_equal(result["homfly_polynomial"], expected)
    assert all(
        tuple(row["switch_measure"]) < tuple(row["parent_measure"])
        and tuple(row["smooth_measure"]) < tuple(row["parent_measure"])
        and row["skein_replay_matched"] is True
        for row in result["transitions"]
    )


def test_descending_terminal_retains_free_circle_components() -> None:
    diagram = PlanarDiagram.from_dict(
        {
            "name": "free-circle-regression",
            "component_count": 2,
            "signed_pd_code": [{"code": [2, 1, 1, 2], "sign": 1}],
        }
    )
    orientation = PDOrientation.from_dict(
        {
            "crossings": [
                {
                    "under_in": 2,
                    "under_out": 1,
                    "over_in": 1,
                    "over_out": 2,
                }
            ],
            "edge_components": [
                {"edge": 1, "component": 0},
                {"edge": 2, "component": 0},
            ],
        }
    )

    terminal = homfly_descending_terminal_from_pd(
        diagram,
        orientation=orientation,
    )
    result = homfly_complete_evaluation_from_pd(
        diagram,
        orientation=orientation,
    )

    assert len(orientation.oriented_component_traversals(diagram)) == 1
    assert diagram.component_count == 2
    assert terminal["terminal"] is True
    assert terminal["component_count"] == 2
    assert terminal["homfly_polynomial"] == "-a^-1*z^-1 + a*z^-1"
    assert result["homfly_polynomial"] == "-a^-1*z^-1 + a*z^-1"


def _mock_pinned_fetch(monkeypatch: pytest.MonkeyPatch) -> None:
    content_by_title = {
        str(record["title"]): (
            "\n".join(str(value) for value in record["required_phrases"])
            if role == "definition"
            else str(record["expected_math_source"])
        )
        for role, record in _KNOT_ATLAS_PINNED_HOMFLY_SOURCES.items()
    }
    byte_count_by_title = {
        str(record["title"]): int(record["byte_count"])
        for record in _KNOT_ATLAS_PINNED_HOMFLY_SOURCES.values()
    }

    def fetch(url, expected_sha256, *, timeout, title=None, revision_id=None):
        content = content_by_title[str(title)]
        return {
            "title": title,
            "revision_id": revision_id,
            "url": url,
            "expected_sha256": expected_sha256,
            "actual_sha256": expected_sha256,
            "byte_count": byte_count_by_title[str(title)],
            "fetched": True,
            "sha256_verified": True,
            "error": None,
            "_content": content,
            "_bytes": content.encode("utf-8"),
        }

    monkeypatch.setattr("iroll.cli._fetch_url_sha256_witness", fetch)


def test_full_certification_report_and_published_pack_are_replayable(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path,
) -> None:
    _mock_pinned_fetch(monkeypatch)
    report = _homfly_full_certification_report_command(
        argparse.Namespace(network_timeout=1.0, fail_on_not_certified=True)
    )
    assert report.pop("_exit_code") == 0
    assert report["certified"] is True
    assert report["counterexample_count"] == 0
    assert report["report_failed_checks"] == []
    assert report["total_state_count"] == 136
    assert report["total_transition_count"] == 77

    report_path = tmp_path / "full_homfly_report.json"
    report_path.write_bytes((dump_report(report) + "\n").encode("utf-8"))
    report_bytes = report_path.read_bytes()
    report_digest = sha256(report_bytes).hexdigest()

    def fetch_published(url, expected_sha256, *, timeout, title=None, revision_id=None):
        assert expected_sha256 == report_digest
        return {
            "title": title,
            "revision_id": revision_id,
            "url": url,
            "expected_sha256": expected_sha256,
            "actual_sha256": expected_sha256,
            "byte_count": len(report_bytes),
            "fetched": True,
            "sha256_verified": True,
            "error": None,
            "_content": report_bytes.decode("utf-8"),
            "_bytes": report_bytes,
        }

    monkeypatch.setattr("iroll.cli._fetch_url_sha256_witness", fetch_published)
    pack = _homfly_full_certification_pack_producer_command(
        argparse.Namespace(
            certification_report_json=report_path,
            certification_report_url=(
                "https://raw.githubusercontent.com/xuxuanyuan/iroll-releases/"
                "pinned/full_homfly_report.json"
            ),
            network_timeout=1.0,
            fail_on_not_certified=True,
        )
    )

    assert pack.pop("_exit_code") == 0
    assert pack["full_homfly_pt_evaluation_certified"] is True
    assert canonical_json_sha256(pack["certification_report"]) == canonical_json_sha256(
        report
    )
    assert pack["certification_report_canonical_sha256"] == canonical_json_sha256(
        report
    )
    assert pack["published_report_json_matches_embedded"] is True
    assert pack["published_report_witness"]["expected_sha256"] == report_digest
    assert pack["published_report_witness"]["actual_sha256"] == report_digest
    assert pack["producer_failed_checks"] == []
    assert pack["producer_preflight_artifact_certified"] is True
    assert pack["producer_preflight_failed_checks"] == []
    audit = completion_evidence_artifact_audit(
        pack,
        artifact_type="full_homfly_pt_evaluation_certification_pack",
    )
    assert audit["artifact_certified"] is True
    assert audit["failed_checks"] == []

    def refresh_embedded_replay(variant: dict) -> None:
        embedded = variant["certification_report"]
        canonical_digest = canonical_json_sha256(embedded)
        variant["certification_report_canonical_sha256"] = canonical_digest
        variant["published_report_canonical_sha256"] = canonical_digest
        variant["published_report_json_matches_embedded"] = True
        variant["certification_report_replay_audit"] = (
            full_homfly_pt_evaluation_certification_report_audit(embedded)
        )
        raw_digest = serialized_certification_report_sha256(embedded)
        variant["certification_report_sha256"] = raw_digest
        variant["certification_report_raw_sha256"] = raw_digest
        variant["published_report_witness"]["expected_sha256"] = raw_digest
        variant["published_report_witness"]["actual_sha256"] = raw_digest
        variant["published_report_witness"]["byte_count"] = len(
            serialized_certification_report_bytes(embedded)
        )
        variant["certification_report_case_count"] = embedded.get("case_count", 0)
        variant["certification_report_total_state_count"] = embedded.get(
            "total_state_count", 0
        )
        variant["certification_report_total_transition_count"] = embedded.get(
            "total_transition_count", 0
        )
        variant["certification_report_total_terminal_count"] = embedded.get(
            "total_terminal_count", 0
        )

    adversarial_variants: dict[str, dict] = {}

    missing_embedded = deepcopy(pack)
    del missing_embedded["certification_report"]
    adversarial_variants["embedded_report_deleted"] = missing_embedded

    missing_witness = deepcopy(pack)
    del missing_witness["published_report_witness"]
    adversarial_variants["published_witness_deleted"] = missing_witness

    deleted_case = deepcopy(pack)
    deleted_case["certification_report"]["cases"].pop()
    deleted_case["certification_report"]["case_count"] -= 1
    refresh_embedded_replay(deleted_case)
    adversarial_variants["case_deleted_with_digest_refresh"] = deleted_case

    deleted_transition = deepcopy(pack)
    embedded = deleted_transition["certification_report"]
    case = next(row for row in embedded["cases"] if row["notation"] == "4_1")
    case["evaluation"]["transitions"].pop()
    case["evaluation"]["transition_count"] -= 1
    case["evaluation_sha256"] = canonical_json_sha256(case["evaluation"])
    embedded["total_transition_count"] -= 1
    refresh_embedded_replay(deleted_transition)
    adversarial_variants[
        "transition_deleted_with_counts_and_digests_refresh"
    ] = deleted_transition

    implementation_hash_tampered = deepcopy(pack)
    embedded = implementation_hash_tampered["certification_report"]
    embedded["implementation_source_sha256"] = "f" * 64
    implementation_hash_tampered[
        "certification_report_implementation_source_sha256"
    ] = "f" * 64
    refresh_embedded_replay(implementation_hash_tampered)
    adversarial_variants[
        "implementation_hash_tampered_with_digest_refresh"
    ] = implementation_hash_tampered

    implementation_bundle_tampered = deepcopy(pack)
    embedded = implementation_bundle_tampered["certification_report"]
    embedded["implementation_bundle"]["modules"][0]["source_lf_sha256"] = (
        "c" * 64
    )
    bundle_digest = canonical_json_sha256(
        embedded["implementation_bundle"]["modules"]
    )
    embedded["implementation_bundle"]["bundle_sha256"] = bundle_digest
    embedded["implementation_bundle_sha256"] = bundle_digest
    implementation_bundle_tampered[
        "certification_report_implementation_bundle_sha256"
    ] = bundle_digest
    refresh_embedded_replay(implementation_bundle_tampered)
    adversarial_variants[
        "implementation_module_bundle_tampered_with_all_digests_refresh"
    ] = implementation_bundle_tampered

    pinned_witness_tampered = deepcopy(pack)
    embedded = pinned_witness_tampered["certification_report"]
    embedded["source_witnesses"][0]["actual_sha256"] = "e" * 64
    pinned_witness_tampered["external_table_source_sha256s"][0] = "e" * 64
    refresh_embedded_replay(pinned_witness_tampered)
    adversarial_variants[
        "pinned_source_witness_tampered_with_digest_refresh"
    ] = pinned_witness_tampered

    published_witness_tampered = deepcopy(pack)
    published_witness_tampered["published_report_witness"][
        "actual_sha256"
    ] = "d" * 64
    adversarial_variants["published_witness_digest_tampered"] = (
        published_witness_tampered
    )

    published_byte_count_tampered = deepcopy(pack)
    published_byte_count_tampered["published_report_witness"]["byte_count"] = 1
    adversarial_variants["published_witness_byte_count_tampered"] = (
        published_byte_count_tampered
    )

    pinned_source_byte_count_tampered = deepcopy(pack)
    pinned_source_byte_count_tampered["certification_report"][
        "source_witnesses"
    ][0]["byte_count"] = 1
    refresh_embedded_replay(pinned_source_byte_count_tampered)
    adversarial_variants[
        "pinned_source_byte_count_tampered_with_all_digests_refresh"
    ] = pinned_source_byte_count_tampered

    synchronized_raw_digest_forgery = deepcopy(pack)
    synchronized_raw_digest_forgery["certification_report_sha256"] = "b" * 64
    synchronized_raw_digest_forgery["certification_report_raw_sha256"] = "b" * 64
    synchronized_raw_digest_forgery["published_report_witness"][
        "expected_sha256"
    ] = "b" * 64
    synchronized_raw_digest_forgery["published_report_witness"][
        "actual_sha256"
    ] = "b" * 64
    adversarial_variants[
        "raw_digest_and_witness_synchronously_forged"
    ] = synchronized_raw_digest_forgery

    for attack, variant in adversarial_variants.items():
        adversarial_audit = completion_evidence_artifact_audit(
            variant,
            artifact_type="full_homfly_pt_evaluation_certification_pack",
        )
        assert adversarial_audit["artifact_certified"] is False, attack
        assert adversarial_audit["failed_checks"], attack
