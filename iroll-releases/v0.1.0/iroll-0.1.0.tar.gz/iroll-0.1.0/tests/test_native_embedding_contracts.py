from __future__ import annotations

import json
import re
import subprocess
import shutil
import sys
from pathlib import Path

import pytest

from iroll.cli import main
from iroll.kernels import backend_report
from iroll.reports.imgui import imgui_analysis_payload_from_acceptance_reports


ROOT = Path(__file__).resolve().parents[1]


def test_deep_completion_roadmap_reflects_current_native_ui_boundaries() -> None:
    roadmap = (ROOT / "docs/deep-completion-roadmap.md").read_text(
        encoding="utf-8"
    )
    audit = (ROOT / "docs/post-mvp-completion-audit.md").read_text(
        encoding="utf-8"
    )
    ui_plan = (ROOT / "docs/ui-plan.md").read_text(encoding="utf-8")

    assert "real optional Rust kernels for segment distance" in roadmap
    assert "Rust C ABI 19 caller-owned buffer/count-fill/callback surface" in roadmap
    assert "native CI slices that build/install Rust wheels" in roadmap
    assert "- real Rust kernels" not in roadmap
    assert "- wheel build workflows" not in roadmap
    assert "PlanarDiagram crossing switch, smoothing, edge relabeling" in roadmap
    assert "bounded signed-PD skein trace generation" in roadmap
    assert "complete arbitrary signed-diagram HOMFLY-PT polynomial evaluation" in roadmap
    assert "signed-PD/Wirtinger-Fox report paths for bounded inputs" in roadmap
    assert "Fox derivative, Jacobian, sparse multivariate Laurent determinant" in roadmap
    assert "full all-admissible-minor/gcd normalization layer" in roadmap
    assert "optional JSON table loading and validation helpers" in roadmap
    assert "`iroll validate-table` checks required fields" in roadmap
    assert "oriented smoothing propagation from signed oriented PD diagrams" in roadmap
    assert "descending-diagram terminal reduction under the documented" in roadmap
    assert "bounded recursive switching-to-descending evaluation" in roadmap
    assert "source_metadata_summary` provenance scan" in roadmap
    assert "explicit external-correctness non-claims" in roadmap
    assert "The original D1 foundation is complete" in roadmap
    assert "without changing Rust C ABI 19 or Dear ImGui\nABI 116" in roadmap
    assert "Start with D1" not in roadmap
    assert "source-by-source normalization and verification pass" in roadmap
    assert "native Dear ImGui panel with host-loaded geometry" in roadmap
    assert "repository stub and CMake/package consumer smokes" in roadmap
    assert "real graphics-backend screenshot/framebuffer verification" in roadmap
    assert "- diagram mutation operations" not in roadmap
    assert "- Fox derivative matrix" not in roadmap
    assert "- determinant/minor computation over Laurent polynomials" not in roadmap
    assert "- broad table import pipeline" not in roadmap
    assert "- crossing/diagram inspector" not in roadmap
    assert "optional Rust package with real segment distance" in roadmap
    assert "Rust C ABI 19 with caller-owned buffers" in roadmap
    assert "unsupported invariant result-handle lifecycle probes" in roadmap
    assert "local benchmark matrix reports and ImGui analysis/host payload bridges" in roadmap
    assert "hosted platform results, signed release artifacts" in roadmap
    assert "implemented CUDA/GPU kernels with hosted parity" in roadmap
    assert "native Dear ImGui panel source with C ABI lifecycle" in roadmap
    assert "repository Dear ImGui stub smokes" in roadmap
    assert "revision-aware stale-result rejection" in roadmap
    assert "production-host renderer/layout polish" in roadmap
    assert "bounded small-diagram coverage reports with frontier/truncation metadata" in audit
    assert "terminal-reduction and skein-identity audit report shapes" in audit
    assert "source-table invariant audit and registration-blocker evidence" in audit
    assert "ImGui analysis/invariant-status bridges for bounded HOMFLY diagnostics" in audit
    assert "signed-PD/Wirtinger-Fox bounded report paths" in audit
    assert "bounded scanned-gcd, quotient-gcd, admissible-minor normalization" in audit
    assert "source-candidate replay provenance for file-oriented HOMFLY/Alexander" in audit
    assert "release-grade all-admissible-minor/gcd" in audit
    assert "verified Whitehead/Borromean signed fixture polynomials" in audit
    assert "native Dear ImGui panel source with host-owned lifecycle/render loop" in audit
    assert "signed-PD JSON export plus revision-aware invariant reload protocol smokes" in audit
    assert "host-polled signed-PD recompute requests" in audit
    assert "dynamic Rust loader smoke through the host-owned callback/scheduler shape" in audit
    assert "optional Rust backend with real segment-distance" in audit
    assert "Rust C ABI 19 with caller-owned buffers" in audit
    assert "native CI workflow slices for Rust wheel build/install parity" in audit
    assert "ImGui host-payload artifacts for unsupported native invariant result-handle" in audit
    assert "no-CUDA and simulated parity-failure GPU smoke artifacts" in audit
    assert "actual CUDA/GPU kernels with hosted parity" in audit
    assert "production UI release readiness" in audit
    assert "- arbitrary signed-diagram HOMFLY completion beyond" in audit
    assert "external table-normalization confirmation and broader independently sourced" in audit
    assert "validate-table source metadata summaries" in audit
    assert "external\n  correctness non-claims" in audit
    assert "- oriented smoothing convention for HOMFLY" not in audit
    assert "- descending-diagram terminal reduction" not in audit
    assert "- signed-PD to Wirtinger-presentation conversion" not in audit
    assert "- signed-PD to Wirtinger-presentation conversion" not in roadmap
    assert "- all-minor/gcd and link-specific normalization layer" not in audit
    assert "- crossing/diagram inspector" not in audit
    assert "- wheel build workflows" not in audit
    assert "`ui/imgui/` is the native C++/Dear ImGui embedding path" in ui_plan
    assert "fixture source/source URL selection and source-opening requests are" in ui_plan
    assert "host-polled" in ui_plan
    assert "source-opening remains a host action" in ui_plan
    assert "does\n  not open platform UI itself" in ui_plan
    assert "host owns the Dear ImGui context, renderer" in ui_plan
    assert "C++/Dear ImGui panel source with C ABI lifecycle" in ui_plan
    assert "native 3D draw-list preview" in ui_plan
    assert "signed-PD inspector/editor state" in ui_plan
    assert "revision-aware invariant reload" in ui_plan
    assert "ordinary and thread-pool scheduler protocol trace" in ui_plan
    assert "real Dear ImGui host renderer screenshot/framebuffer verification" in ui_plan
    assert "Keep the standalone WebGL prototype" in ui_plan
    assert "- crossing/projection inspector" not in ui_plan
    assert "- signed-PD diagram panel" not in ui_plan
    assert "- fixture browser" not in ui_plan


def test_imgui_readme_keeps_host_owned_embedding_boundary() -> None:
    readme = (ROOT / "ui/imgui/README.md").read_text(encoding="utf-8")
    status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    host_owned_tokens = [
        "The panel is designed to be embedded inside a larger C++ application.",
        "OS window and graphics device",
        "Dear ImGui context",
        "frame timing",
        "docking layout",
        "shutdown order",
        "Called inside the host application's existing ImGui frame.",
        "IrollImGui_RenderPanel(context);",
    ]
    for token in host_owned_tokens:
        assert token in readme

    forbidden_tokens = [
        "iroll owns the OS window",
        "iroll owns the Dear ImGui context",
        "panel owns the main loop",
        "creates the graphics device",
        "opens platform UI",
    ]
    for token in forbidden_tokens:
        assert token not in readme

    status_tokens = [
        "Dear ImGui README host-owned embedding boundary",
        "OS window/graphics device, Dear ImGui context, frame timing, docking layout, and shutdown order",
        "inside the host application's existing ImGui frame",
    ]
    for token in status_tokens:
        assert token in status


def test_remaining_status_retained_manifest_counts_do_not_regress() -> None:
    status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    assert "22 retained JSON files" in status
    assert "6 groups as `complete_raw_analysis_host`" in status
    assert "1 group as `invariant_status_host_only`" in status
    assert "0 groups as `smoke_executed_no_retained_json`" in status
    assert "updates the Windows retained-artifacts manifest from 19/5/1 to 22" in status
    assert "nineteen retained JSON files" not in status
    assert "smoke_executed_no_retained_json_count=1" not in status
    assert "Rust C ABI 19 / Dear ImGui ABI 116 remain unchanged" in status
    assert "`native_homfly_cpp_computation_claimed=false`" in status
    assert "`native_alexander_cpp_computation_claimed=false`" in status
    assert "compares the Windows retained-artifacts manifest evidence file list" in status
    assert "22 unique retained JSON files" in status
    assert "only intentional shared evidence file" in status
    assert "non_claim_evidence_index" in status
    assert (
        "analysis_rust_wheel_retained_manifest_non_claim_evidence_index_entry_count_total=6"
        in status
    )
    assert (
        "analysis_imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total=5"
        in status
    )
    assert "release gates remain open" in status


def test_windows_retained_manifest_file_lists_match_upload_paths() -> None:
    workflow = (ROOT / ".github/workflows/native-kernels-ci.yml").read_text(
        encoding="utf-8"
    )

    manifest_start = workflow.index("$manifest = [ordered]@{")
    manifest_end = workflow.index("$manifest | ConvertTo-Json", manifest_start)
    manifest_block = workflow[manifest_start:manifest_end]
    manifest_files = set(re.findall(r"'([^']+\.json)'", manifest_block))
    assert len(manifest_files) == 22
    assert manifest_block.count("'iroll-imgui-signed-pd.json'") == 2

    def evidence_group_block(name: str) -> str:
        start = manifest_block.index(f"name = '{name}'")
        next_start = manifest_block.find("\n              [ordered]@{", start + 1)
        if next_start == -1:
            next_start = manifest_block.index("\n            )", start)
        return manifest_block[start:next_start]

    def field_files(group: str, field: str) -> list[str]:
        match = re.search(rf"{field} = @\(([^)]*)\)", group)
        assert match is not None
        return re.findall(r"'([^']+\.json)'", match.group(1))

    def assert_group_field_files(name: str, field: str, expected: list[str]) -> None:
        assert field_files(evidence_group_block(name), field) == expected

    framebuffer_group = evidence_group_block("test_stub_framebuffer")
    assert "classification = 'complete_raw_analysis_host'" in framebuffer_group
    assert (
        "claim_scope = 'repository_imgui_test_stub_draw_list_framebuffer_estimate'"
        in framebuffer_group
    )
    assert_group_field_files(
        "test_stub_framebuffer",
        "raw_files",
        ["iroll-imgui-test-stub-framebuffer-smoke.json"],
    )
    assert_group_field_files(
        "test_stub_framebuffer",
        "analysis_files",
        ["iroll-imgui-test-stub-framebuffer-smoke-imgui-analysis.json"],
    )
    assert_group_field_files(
        "test_stub_framebuffer",
        "host_files",
        ["iroll-imgui-test-stub-framebuffer-smoke-imgui-host.json"],
    )
    for non_claim in (
        "real_graphics_backend_framebuffer_verified=false",
        "screenshot_verified=false",
        "production_renderer_verified=false",
    ):
        assert non_claim in framebuffer_group

    snapshot_group = evidence_group_block("signed_pd_snapshot")
    assert "classification = 'complete_raw_analysis_host'" in snapshot_group
    assert "claim_scope = 'host_exported_imgui_signed_pd_snapshot_shape'" in (
        snapshot_group
    )
    assert_group_field_files("signed_pd_snapshot", "raw_files", ["iroll-imgui-signed-pd.json"])
    assert_group_field_files(
        "signed_pd_snapshot",
        "analysis_files",
        ["iroll-imgui-signed-pd-imgui-analysis.json"],
    )
    assert_group_field_files(
        "signed_pd_snapshot",
        "host_files",
        ["iroll-imgui-signed-pd-snapshot-imgui-host.json"],
    )
    assert "not invariant computation evidence" in snapshot_group
    assert "not native HOMFLY/Alexander C++ computation evidence" in snapshot_group

    reload_group = evidence_group_block("signed_pd_invariant_reload")
    assert "classification = 'invariant_status_host_only'" in reload_group
    assert "claim_scope = 'file_oriented_signed_pd_invariant_reload'" in reload_group
    assert_group_field_files(
        "signed_pd_invariant_reload",
        "raw_files",
        [
            "iroll-imgui-signed-pd.json",
            "iroll-imgui-signed-pd-homfly.json",
            "iroll-imgui-signed-pd-alexander.json",
        ],
    )
    assert_group_field_files(
        "signed_pd_invariant_reload",
        "invariant_status_files",
        ["iroll-imgui-signed-pd-invariant-status.json"],
    )
    assert_group_field_files(
        "signed_pd_invariant_reload",
        "host_files",
        ["iroll-imgui-signed-pd-imgui-host.json"],
    )
    assert "not native HOMFLY/Alexander C++ computation evidence" in reload_group
    assert "not signed release artifacts" in reload_group

    signed_pd_reference_groups = [
        name
        for name in ("signed_pd_snapshot", "signed_pd_invariant_reload")
        if "iroll-imgui-signed-pd.json" in field_files(
            evidence_group_block(name), "raw_files"
        )
    ]
    assert signed_pd_reference_groups == [
        "signed_pd_snapshot",
        "signed_pd_invariant_reload",
    ]

    def upload_section(name: str) -> str:
        start = workflow.index(f"- name: {name}")
        next_start = workflow.find("\n      - name:", start + 1)
        assert next_start != -1
        return workflow[start:next_start]

    upload_files: set[str] = set()
    for name in (
        "Upload Windows Dear ImGui signed-PD JSON smoke artifact",
        "Upload Windows Dear ImGui test-stub framebuffer smoke artifact",
        "Upload Windows Dear ImGui real kernel loader smoke artifact",
    ):
        upload_files.update(
            re.findall(
                r"\$\{\{ runner\.temp \}\}/([^\s]+\.json)",
                upload_section(name),
            )
        )

    assert upload_files == manifest_files

    manifest_upload_files = set(
        re.findall(
            r"\$\{\{ runner\.temp \}\}/([^\s]+\.json)",
            upload_section("Upload Windows Dear ImGui retained artifact manifest"),
        )
    )
    assert manifest_upload_files == {
        "iroll-imgui-windows-retained-artifacts-manifest.json",
        "iroll-imgui-windows-retained-artifacts-manifest-imgui-analysis.json",
        "iroll-imgui-windows-retained-artifacts-manifest-imgui-host.json",
    }


def test_native_release_ci_upload_artifacts_use_explicit_retention_days() -> None:
    workflow = (ROOT / ".github/workflows/native-kernels-ci.yml").read_text(
        encoding="utf-8"
    )
    docs = (ROOT / "docs/native-release-ci.md").read_text(encoding="utf-8")
    status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    plan = (ROOT / "docs/remaining-deep-completion-plan.md").read_text(
        encoding="utf-8"
    )

    upload_sections = re.findall(
        r"(?ms)^      - name: (Upload[^\n]+)\n"
        r"(?:(?:        if: [^\n]+\n)|(?:        shell: [^\n]+\n))*"
        r"        uses: actions/upload-artifact@v4\n"
        r"        with:\n"
        r"(.*?)(?=^      - name:|^  [A-Za-z0-9_-]+:|\Z)",
        workflow,
    )

    assert len(upload_sections) == 17
    assert workflow.count("uses: actions/upload-artifact@v4") == 17
    assert workflow.count("retention-days: 30") == 17
    for name, body in upload_sections:
        assert name.startswith("Upload ")
        assert "if-no-files-found: error" in body
        assert "retention-days: 30" in body
        assert body.index("if-no-files-found: error") < body.index(
            "retention-days: 30"
        )
    upload_section_by_name = dict(upload_sections)
    expected_retained_upload_paths = {
        "Upload validate-table source metadata artifact": [
            "validate-table-source-metadata-input.json",
            "validate-table-source-metadata.json",
            "validate-table-source-metadata-imgui-analysis.json",
            "validate-table-source-metadata-imgui-host.json",
            "validate-table-source-metadata-blocked-input.json",
            "validate-table-source-metadata-blocked.json",
            "validate-table-source-metadata-blocked-imgui-analysis.json",
            "validate-table-source-metadata-blocked-imgui-host.json",
            "validate-table-source-metadata-invalid-known-limitations-input.json",
            "validate-table-source-metadata-invalid-known-limitations.json",
            "validate-table-source-metadata-invalid-known-limitations-imgui-analysis.json",
            "validate-table-source-metadata-invalid-known-limitations-imgui-host.json",
            "validate-table-source-metadata-invalid-known-limitations-item-input.json",
            "validate-table-source-metadata-invalid-known-limitations-item.json",
            "validate-table-source-metadata-invalid-known-limitations-item-imgui-analysis.json",
            "validate-table-source-metadata-invalid-known-limitations-item-imgui-host.json",
            "validate-table-source-metadata-invalid-source-url-input.json",
            "validate-table-source-metadata-invalid-source-url.json",
            "validate-table-source-metadata-invalid-source-url-imgui-analysis.json",
            "validate-table-source-metadata-invalid-source-url-imgui-host.json",
            "validate-table-source-metadata-provenance-blockers-input.json",
            "validate-table-source-metadata-provenance-blockers.json",
            "validate-table-source-metadata-provenance-blockers-imgui-analysis.json",
            "validate-table-source-metadata-provenance-blockers-imgui-host.json",
        ],
        "Upload Windows Dear ImGui retained artifact manifest": [
            "iroll-imgui-windows-retained-artifacts-manifest.json",
            "iroll-imgui-windows-retained-artifacts-manifest-imgui-analysis.json",
            "iroll-imgui-windows-retained-artifacts-manifest-imgui-host.json",
        ],
        "Upload source-table audit artifact": [
            "source-table-l6a4-audit.json",
            "source-table-l6a4-audit-imgui-analysis.json",
            "source-table-l6a4-audit-imgui-host.json",
            "source-table-l5a1-audit.json",
            "source-table-l5a1-audit-imgui-analysis.json",
            "source-table-l5a1-audit-imgui-host.json",
        ],
        "Upload source-invariant candidate artifact": [
            "source-invariant-l6a4-candidates.json",
            "source-invariant-l6a4-candidates-imgui-analysis.json",
            "source-invariant-l6a4-candidates-imgui-host.json",
        ],
        "Upload generated coverage artifact": [
            "homfly-small-coverage-l2a1.json",
            "alexander-signed-pd-coverage-l2a1.json",
            "generated-coverage-l2a1-imgui-analysis.json",
            "generated-coverage-l2a1-imgui-host.json",
        ],
        "Upload single-input certification audit artifact": [
            "input-certification-hopf-imgui-role-order.json",
            "input-certification-homfly-pd.json",
            "input-certification-homfly-terminal-audit.json",
            "input-certification-homfly-evidence.json",
            "input-certification-alexander-pd.json",
            "input-certification-alexander-admissible-audit.json",
            "input-certification-alexander-evidence.json",
            "input-certification-imgui-analysis.json",
            "input-certification-imgui-host.json",
        ],
        "Upload no-CUDA GPU smoke artifact": [
            "gpu-smoke-no-cuda.json",
            "gpu-smoke-no-cuda-imgui-analysis.json",
            "gpu-smoke-no-cuda-imgui-host.json",
        ],
        "Upload simulated GPU parity-failure artifact": [
            "gpu-smoke-simulated-parity-failure.json",
            "gpu-smoke-simulated-parity-failure-imgui-analysis.json",
            "gpu-smoke-simulated-parity-failure-imgui-host.json",
        ],
    }
    for name, expected_paths in expected_retained_upload_paths.items():
        body = upload_section_by_name[name]
        assert "if-no-files-found: error" in body
        assert "retention-days: 30" in body
        assert body.index("if-no-files-found: error") < body.index(
            "retention-days: 30"
        )
        for path in expected_paths:
            assert path in body

    retention_note = "All `actions/upload-artifact@v4` retained/reviewer uploads set `retention-days: 30`"
    assert retention_note in docs
    assert retention_note in status
    assert retention_note in plan


def test_native_release_ci_source_open_request_retained_artifact_contract() -> None:
    workflow = (ROOT / ".github/workflows/native-kernels-ci.yml").read_text(
        encoding="utf-8"
    )
    docs = (ROOT / "docs/native-release-ci.md").read_text(encoding="utf-8")

    source_open_start = workflow.index(
        "$sourceOpenJson = Join-Path $env:RUNNER_TEMP "
        "'iroll-imgui-source-open-request-smoke.json'"
    )
    source_open_end = workflow.index(
        "$signedPdJson = Join-Path $env:RUNNER_TEMP", source_open_start
    )
    source_open_block = workflow[source_open_start:source_open_end]

    for required in [
        "iroll-imgui-source-open-request-smoke.json",
        "iroll-imgui-source-open-request-smoke-imgui-analysis.json",
        "iroll-imgui-source-open-request-smoke-imgui-host.json",
        "artifact_kind']=='imgui_source_open_request_smoke'",
        "claim_scope']=='host_polled_source_open_request_contract'",
        "host_action']=='open_source_url'",
        "opened_by_real_host'] is False",
        "selected_fixture_name']=='3_1'",
        "selected_fixture_source']=='Knot Atlas'",
        "source_url']=='https://katlas.org/wiki/3_1'",
        "consumed_source_url']==payload['source_url']",
        "request_consumed_by_smoke'] is True",
        "request_cleared_after_consumption'] is True",
        "final_request_pending'] is True",
        "selected_fixture_source_url_length']==len(payload['source_url'])",
        "requested_fixture_source_url_length']==len(payload['source_url'])",
        "imgui_abi_version']==117",
        "rust_c_abi_version']==19",
        "analysis_imgui_source_open_request_smoke_artifact_count']==1",
        "analysis_imgui_source_open_request_smoke_passed_count']==1",
        "analysis_imgui_source_open_request_smoke_opened_by_real_host_count']==0",
        "analysis_imgui_source_open_request_smoke_scheme_allowed_count']==1",
        "analysis_imgui_source_open_request_smoke_request_consumed_count']==1",
        "imgui_source_open_request_smoke_host_action']=='open_source_url'",
        "imgui_source_open_request_smoke_selected_fixture_name']=='3_1'",
        "imgui_source_open_request_smoke_selected_fixture_source']=='Knot Atlas'",
        "imgui_source_open_request_smoke_source_url']=='https://katlas.org/wiki/3_1'",
        "imgui_source_open_request_smoke_consumed_source_url']==summary['imgui_source_open_request_smoke_source_url']",
        "imgui_source_open_request_smoke_consumed_source_url_matched'] is True",
        "not production platform URL-opening evidence",
    ]:
        assert required in source_open_block

    upload_start = workflow.index(
        "- name: Upload Windows Dear ImGui test-stub framebuffer smoke artifact"
    )
    upload_end = workflow.index("\n      - name:", upload_start + 1)
    upload_block = workflow[upload_start:upload_end]
    assert "if-no-files-found: error" in upload_block
    assert (
        "${{ runner.temp }}/iroll-imgui-source-open-request-smoke.json"
        in upload_block
    )
    assert (
        "${{ runner.temp }}/iroll-imgui-source-open-request-smoke-imgui-analysis.json"
        in upload_block
    )
    assert (
        "${{ runner.temp }}/iroll-imgui-source-open-request-smoke-imgui-host.json"
        in upload_block
    )

    assert "Windows ImGui source-opening host action artifact" in docs
    assert "host-polled source navigation request" in docs
    assert "opened_by_real_host=false" in docs
    assert "does not open platform UI from the embedded panel" in docs
    assert "source-opening presentation" in docs
    assert "analysis_imgui_source_open_request_smoke_opened_by_real_host_count=0" in docs
    assert "imgui_source_open_request_smoke_selected_fixture_name=3_1" in docs
    assert (
        "imgui_source_open_request_smoke_source_url=https://katlas.org/wiki/3_1"
        in docs
    )
    assert "imgui_source_open_request_smoke_consumed_source_url_matched=true" in docs


def test_imgui_source_open_request_is_host_polled_without_platform_opener() -> None:
    panel_source = (ROOT / "ui/imgui/src/iroll_imgui_panel.cpp").read_text(
        encoding="utf-8"
    )
    panel_smoke = (
        ROOT / "ui/imgui/examples/panel_contract_smoke.cpp"
    ).read_text(encoding="utf-8")
    combined_source = panel_source + "\n" + panel_smoke

    for required in [
        "IrollImGui_RequestSelectedFixtureSourceUrl",
        "IrollImGui_GetRequestedFixtureSourceUrl",
        "IrollImGui_ClearRequestedFixtureSourceUrl",
        '\\"opened_by_real_host\\": false',
        "host_polled_source_open_request_contract",
    ]:
        assert required in combined_source

    for forbidden in [
        "ShellExecute",
        "CreateProcess",
        "xdg-open",
        "open -a",
        "std::system(",
        "Start-Process",
    ]:
        assert forbidden not in combined_source


def test_remaining_plan_and_status_preserve_current_abi_non_claim_boundary() -> None:
    plan = (ROOT / "docs/remaining-deep-completion-plan.md").read_text(
        encoding="utf-8"
    )
    status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )

    assert "the Rust C ABI version is now `19`" in plan
    assert "Current Dear ImGui ABI 117" in plan
    assert "Rust C ABI 19 and Dear ImGui ABI 117" in status
    assert "Optional table imports use `iroll validate-table`" in plan
    assert "`source_metadata_summary` provenance scan" in plan
    assert "`source_url_without_source_count`" in plan
    assert "`source_url_without_source_rows`" in plan
    assert "`all_source_urls_have_source`" in plan
    assert "`summary_consistency` self-checks" in plan
    assert "`claim_scope=table_source_metadata_summary_self_consistency`" in plan
    assert "`source_rows`" in plan
    assert "`source_value_counts`" in plan
    assert "`source_value_rows`" in plan
    assert "`source_value_count_total_matched`" in plan
    assert "`source_value_row_count_total_matched`" in plan
    assert "`source_url_rows`" in plan
    assert "`source_with_source_url_count`" in plan
    assert "`source_with_source_url_rows`" in plan
    assert "`valid_source_url_count`" in plan
    assert "`valid_source_url_rows`" in plan
    assert "`source_url_scheme_rows`" in plan
    assert "`source_url_domain_rows`" in plan
    assert "`source_url_missing_scheme_count`" in plan
    assert "`source_url_missing_scheme_rows`" in plan
    assert "`source_url_missing_domain_count`" in plan
    assert "`source_url_missing_domain_rows`" in plan
    assert "`source_url_scheme_row_count_total_matched`" in plan
    assert "`source_url_domain_row_count_total_matched`" in plan
    assert "`convention_rows`" in plan
    assert "`convention_metadata_rows`" in plan
    assert "`convention_metadata_name_rows`" in plan
    assert "`convention_metadata_without_name_count`" in plan
    assert "`convention_metadata_without_name_rows`" in plan
    assert "non-empty known-limitation text coverage" in plan
    assert "`known_limitations_rows`" in plan
    assert "`known_limitations` is optional" in plan
    assert "present it must be a non-empty string or a non-empty list of non-empty" in plan
    assert "strings, and invalid shapes are validation issues" in plan
    assert "invalid shapes are validation issues rather than provenance" in plan
    assert "`provenance_review_ready`" in plan
    assert "`provenance_blocker_count`" in plan
    assert "`provenance_blocker_codes`" in plan
    assert "`provenance_blocker_details`" in plan
    assert "`provenance_blocker_summary_consistency`" in plan
    assert "`claim_scope=table_source_metadata_provenance_blocker_self_consistency`" in plan
    assert "`review_ready_matched`" in plan
    assert "`expected_convention`" in plan
    assert "`convention_mismatch`" in plan
    assert "`convention_mismatch_count_matched`" in plan
    assert "`all_conventions_match_expected`" in plan
    assert "`source_url_issue_codes`" in plan
    assert "`source_url_issue_code_counts`" in plan
    assert "`source_url_issue_code_rows`" in plan
    assert "`source_url_issue_code_total`" in plan
    assert "`source_url_issue_code_count_total_matched`" in plan
    assert "`source_url_issue_code_invalid_row_coverage_matched`" in plan
    assert "`missing_scheme`" in plan
    assert "`missing_domain`" in plan
    assert "`unsupported_scheme`" in plan
    assert "`missing_source_url`" in plan
    assert "`invalid_source_url`" in plan
    assert "`missing_convention`" in plan
    assert "matched convention/known-limitation" in plan
    assert "`table_correctness_certified=false`" in plan
    assert "`external_source_verified=false`" in plan
    assert "IROLL_IMGUI_ABI_VERSION` is now `117`" in plan
    assert "native_computation_claimed=false" in plan
    assert "native_invariant_result_handles_complete=false" in plan
    assert "current_file_recompute_boundary.native_result_handle_boundary=false" in plan
    assert "required_boundary=python_file_recompute" in plan
    assert "without adding Rust HOMFLY/Alexander compute-handle APIs" in plan
    assert "not native HOMFLY/Alexander computation availability" in plan
    assert "not native invariant computation" in status
    assert "`source_url_without_source_count`" in status
    assert "`source_url_without_source_rows`" in status
    assert "`all_source_urls_have_source`" in status
    assert "`summary_consistency` self-checks" in status
    assert "`claim_scope=table_source_metadata_summary_self_consistency`" in status
    assert "`source_rows`" in status
    assert "`source_value_counts`" in status
    assert "`source_value_rows`" in status
    assert "`source_value_count_total_matched`" in status
    assert "`source_value_row_count_total_matched`" in status
    assert "`source_url_rows`" in status
    assert "`source_with_source_url_count`" in status
    assert "`source_with_source_url_rows`" in status
    assert "`valid_source_url_count`" in status
    assert "`valid_source_url_rows`" in status
    assert "`source_url_scheme_rows`" in status
    assert "`source_url_domain_rows`" in status
    assert "`source_url_missing_scheme_count`" in status
    assert "`source_url_missing_scheme_rows`" in status
    assert "`source_url_missing_domain_count`" in status
    assert "`source_url_missing_domain_rows`" in status
    assert "`source_url_scheme_row_count_total_matched`" in status
    assert "`source_url_domain_row_count_total_matched`" in status
    assert "`convention_rows`" in status
    assert "`convention_metadata_rows`" in status
    assert "`convention_metadata_name_rows`" in status
    assert "`convention_metadata_without_name_count`" in status
    assert "`convention_metadata_without_name_rows`" in status
    assert "non-empty known-limitation text coverage" in status
    assert "`known_limitations_rows`" in status
    assert "`known_limitations` table metadata is now shape-validated" in status
    assert "non-empty string or a non-empty list of non-empty strings" in status
    assert "without expanding table-correctness" in status
    assert "`provenance_review_ready`" in status
    assert "`provenance_blocker_count`" in status
    assert "`provenance_blocker_codes`" in status
    assert "`provenance_blocker_details`" in status
    assert "`provenance_blocker_summary_consistency`" in status
    assert "`claim_scope=table_source_metadata_provenance_blocker_self_consistency`" in status
    assert "`review_ready_matched`" in status
    assert "`expected_convention`" in status
    assert "`convention_mismatch`" in status
    assert "`convention_mismatch_count_matched`" in status
    assert "`all_conventions_match_expected`" in status
    assert "`source_url_issue_codes`" in status
    assert "`source_url_issue_code_counts`" in status
    assert "`source_url_issue_code_rows`" in status
    assert "`source_url_issue_code_total`" in status
    assert "`source_url_issue_code_count_total_matched`" in status
    assert "`source_url_issue_code_invalid_row_coverage_matched`" in status
    assert (
        "`analysis_validate_table_source_metadata_source_url_missing_scheme_count`"
        in status
    )
    assert (
        "`analysis_validate_table_source_metadata_source_url_missing_domain_count`"
        in status
    )
    assert (
        "`analysis_validate_table_source_metadata_source_url_issue_code_total`"
        in status
    )
    assert "`missing_scheme`" in status
    assert "`missing_domain`" in status
    assert "`unsupported_scheme`" in status
    assert "`missing_source_url`" in status
    assert "`invalid_source_url`" in status
    assert "`missing_convention`" in status
    assert "matched convention/known-limitation" in status
    assert "native HOMFLY/Alexander C++ computation" in status
    assert "`native_homfly_cpp_computation_claimed=false`" in status
    assert "`native_alexander_cpp_computation_claimed=false`" in status
    assert "`signed_release_artifacts_published=false`" in status
    assert "`retained_evidence_kinds=ci_retained_artifact:7|repository_test:4`" in status
    assert "`analysis_gpu_smoke_release_gate_*_blocker_count`" in status
    assert "without requiring CUDA hardware" in status
    assert "Rust kernel interface documentation now also names" in status
    assert "artifact-review host display" in status


def test_rust_kernel_c_abi_exports_core_symbols() -> None:
    header = (ROOT / "native/iroll-kernels-rust/include/iroll_kernels.h").read_text(
        encoding="utf-8"
    )
    source = (ROOT / "native/iroll-kernels-rust/src/lib.rs").read_text(
        encoding="utf-8"
    )
    rust_readme = (ROOT / "native/iroll-kernels-rust/README.md").read_text(
        encoding="utf-8"
    )

    for symbol in [
        "IROLL_KERNEL_ABI_VERSION",
        "iroll_kernel_abi_version",
        "iroll_segment_segment_distance",
        "iroll_invariant_result_handles_report_json",
        "iroll_invariant_result_handle_create_unsupported",
        "iroll_invariant_result_handle_report_json",
        "iroll_invariant_result_handle_free",
        "iroll_segment_segment_distance_report_json",
        "iroll_gaussian_linking_report_json",
        "iroll_writhe_report_json",
        "iroll_segment_contact_records_3d_report_json",
        "iroll_segment_intersection_records_2d_report_json",
        "iroll_segment_intersections_2d_report_json",
        "iroll_segment_bbox_candidate_pairs_2d_report_json",
        "iroll_segment_bbox_candidate_pairs_3d_report_json",
        "iroll_segment_segment_distances",
        "iroll_segment_segment_distances_with_callbacks",
        "IROLL_STATUS_CANCELLED",
        "IrollKernelExecutionCallbacks",
        "IrollKernelCancelCallback",
        "IrollKernelProgressCallback",
        "IrollSegmentContact3DRecord",
        "iroll_segment_contact_records_3d_count",
        "iroll_segment_contact_records_3d_count_with_callbacks",
        "iroll_segment_contact_records_3d",
        "iroll_segment_contact_records_3d_with_callbacks",
        "iroll_segment_intersections_2d",
        "iroll_segment_intersections_2d_with_callbacks",
        "IrollSegmentIntersection2DRecord",
        "iroll_segment_intersection_records_2d_count",
        "iroll_segment_intersection_records_2d_count_with_callbacks",
        "iroll_segment_intersection_records_2d",
        "iroll_segment_intersection_records_2d_with_callbacks",
        "iroll_segment_bbox_candidate_pairs_2d_count",
        "iroll_segment_bbox_candidate_pairs_2d",
        "iroll_segment_bbox_candidate_pairs_2d_count_with_callbacks",
        "iroll_segment_bbox_candidate_pairs_2d_with_callbacks",
        "iroll_segment_bbox_candidate_pairs_3d_count",
        "iroll_segment_bbox_candidate_pairs_3d",
        "iroll_segment_bbox_candidate_pairs_3d_count_with_callbacks",
        "iroll_segment_bbox_candidate_pairs_3d_with_callbacks",
        "iroll_compute_writhe",
        "iroll_compute_writhe_with_callbacks",
        "iroll_compute_gaussian_linking_number",
        "iroll_compute_gaussian_linking_number_with_callbacks",
        "iroll_kernel_backend_report_json",
        "iroll_kernel_owned_string_free",
        "IrollKernelOwnedString",
        "iroll_last_error_message",
    ]:
        assert symbol in header
        assert symbol in source

    assert "extern \"C\"" in header
    assert "IROLL_KERNEL_ABI_VERSION = 19" in header
    assert "const IROLL_KERNEL_ABI_VERSION: u32 = 19" in source
    assert "ABI 19 also includes `IrollKernelOwnedString`" in rust_readme
    assert "iroll_invariant_result_handles_report_json" in rust_readme
    assert "iroll_invariant_result_handle_create_unsupported" in rust_readme
    assert "iroll_invariant_result_handle_report_json" in rust_readme
    assert "iroll_invariant_result_handle_free" in rust_readme
    assert "native_computation_claimed=false" in rust_readme
    assert "result_available=false" in rust_readme
    assert "host_action=use_python_file_recompute_boundary" in rust_readme
    assert "not a native HOMFLY/Alexander compute payload" in rust_readme
    assert "ABI 17 also includes" not in rust_readme
    assert "IrollKernelOwnedString" in header
    assert "struct IrollKernelOwnedString" in source
    assert "typedef struct IrollInvariantResultHandle" in header
    assert "pub struct IrollInvariantResultHandle" in source
    assert (
        "iroll_invariant_result_handles_report_json(IrollKernelOwnedString* out_json)"
        in header
    )
    assert r"\"method\":\"invariant_result_handles_report\"" in source
    assert r"\"status\":\"metadata_only\"" in source
    assert r"\"claim_scope\":\"capability_probe_only\"" in source
    assert r"\"metadata_schema_version\":{}" in source
    assert (
        "INVARIANT_RESULT_HANDLE_METADATA_SCHEMA_VERSION: u32 = 1"
        in source
    )
    assert r"\"metadata_contract_version\":\"{}\"" in source
    assert "rust_c_abi_19_invariant_result_handles_lifecycle_metadata_v1" in source
    assert r"\"required_metadata_fields\":{}" in source
    assert r"\"required_metadata_field_count\":{}" in source
    assert "REQUIRED_INVARIANT_RESULT_HANDLE_METADATA_FIELDS: [&str; 30]" in source
    assert r"\"homfly_report_json\":false" in source
    assert r"\"alexander_report_json\":false" in source
    assert r"\"native_computation_claimed\":false" in source
    assert r"\"native_invariant_result_handles_complete\":false" in source
    assert r"\"native_invariant_compute_handles_status\"" in source
    assert r"\"boundary\":\"rust_c_abi_invariant_compute_handles_status\"" in source
    assert r"\"status\":\"unsupported\"" in source
    assert r"\"status_code\":\"native_invariant_compute_handles_unavailable\"" in source
    assert (
        r"\"status_reason\":\"homfly_alexander_native_compute_handles_not_implemented\""
        in source
    )
    assert r"\"compute_handle_abi\":\"not_available\"" in source
    assert r"\"result_handle_abi\":\"opaque_invariant_result_handle_v1\"" in source
    assert r"\"report_transport_abi\":\"owned_string_v1\"" in source
    assert r"\"current_boundary\":\"python_file_recompute\"" in source
    assert r"\"host_action\":\"use_python_file_recompute_boundary\"" in source
    assert r"\"tracked_invariants\"" in source
    assert r"\"per_invariant_count\":2" in source
    assert r"\"per_invariant_unavailable_count\":2" in source
    assert r"\"per_invariant_unavailable_status_codes\"" in source
    assert r"\"per_invariant\"" in source
    assert r"\"invariant\":\"homfly\"" in source
    assert r"\"invariant\":\"alexander\"" in source
    assert r"\"native_compute_handle_available\":false" in source
    assert r"\"report_json_symbol_available\":false" in source
    assert r"\"status_code\":\"homfly_native_compute_handle_missing\"" in source
    assert r"\"status_code\":\"alexander_native_compute_handle_missing\"" in source
    assert r"\"required_boundary\":\"python_file_recompute\"" in source
    assert r"\"metadata_consistency\"" in source
    assert r"\"file_recompute_boundary_matches_current\":true" in source
    assert r"\"current_boundary_matches_compute_status\":true" in source
    assert r"\"blocker_count_matches_list\":true" in source
    assert r"\"required_gate_count_matches_list\":true" in source
    assert r"\"required_metadata_field_count_matches_list\":true" in source
    assert r"\"required_metadata_fields_present\":true" in source
    assert r"\"per_invariant_status_codes_match_blockers\":true" in source
    assert (
        r"\"required_native_compute_gate_statuses_match_per_invariant\":true"
        in source
    )
    assert r"\"native_computation_non_claim_consistent\":true" in source
    assert r"\"readiness_provenance_self_consistency\"" in source
    assert r"\"readiness_provenance_note\"" in source
    assert "readiness_provenance_self_consistency=present" in source
    assert "ready_for_native_result_handles=false" in source
    assert "required_native_handle_gates_block_native_result_handle_boundary=true" in source
    assert (
        "Optional\n * readiness_provenance_self_consistency/readiness_provenance_note"
        in header
    )
    assert r"\"native_invariant_result_handle_blockers\"" in source
    assert r"\"native_invariant_result_handle_blocker_count\":6" in source
    assert r"\"homfly_native_compute_handle_missing\"" in source
    assert r"\"alexander_native_compute_handle_missing\"" in source
    assert r"\"native_result_compute_payload_lifecycle_incomplete\"" in source
    assert '"unsupported_result_handle_lifecycle_available", true' in source
    assert "iroll_invariant_result_handle_create_unsupported" in source
    assert "iroll_invariant_result_handle_report_json" in source
    assert "iroll_invariant_result_handle_free" in source
    assert r"\"long_invariant_progress_cancel_missing\"" in source
    assert r"\"python_fixture_report_parity_missing\"" in source
    assert r"\"dear_imgui_native_invariant_status_reload_missing\"" in source
    assert r"\"required_native_invariant_handle_gates\"" in source
    assert r"\"required_native_invariant_handle_gate_count\":6" in source
    for gate in [
        "homfly_native_compute_handle",
        "alexander_native_compute_handle",
        "result_ownership_freeing_lifecycle",
        "progress_cancel_for_long_invariant_computations",
        "parity_against_python_fixture_reports",
        "host_reload_into_dear_imgui_invariant_status_rows",
    ]:
        assert rf"\"gate\":\"{gate}\"" in source
    assert r"\"python_file_recompute_boundary\":true" in source
    assert r"\"file_recompute_boundary\"" in source
    assert r"\"current_file_recompute_boundary\"" in source
    assert r"\"homfly_cli_command\":\"iroll homfly-pd\"" in source
    assert (
        r"\"alexander_cli_command\":\"iroll multivariable-alexander-pd\""
        in source
    )
    assert (
        r"\"host_reload_payload\":\"imgui-signed-pd-invariant-status-payload\""
        in source
    )
    assert r"\"native_result_handle_boundary\":false" in source
    assert r"\"Dear ImGui invariant-status rows\"" in source
    assert "invariant_result_handles_report_json" in source
    assert "fn backend_info" in source
    assert "CANDIDATE_PAIR_ALGORITHM" in source
    assert "adaptive_axis_sweep_active_set" in source
    assert "select_sweep_axis_2d" in source
    assert "select_sweep_axis_3d" in source
    assert "candidate_pair_count_fill" in source
    assert "struct SweepCandidateStats" in source
    assert "#[no_mangle]" in source
    assert "#[cfg(test)]" in source
    for test_name in [
        "segment_distance_core_handles_crossing_and_parallel_segments",
        "segment_distances_core_matches_scalar_results",
        "segment_intersections_2d_core_reports_strict_hits",
        "bbox_candidate_pair_cores_skip_adjacent_segments",
        "x_sweep_candidate_pair_stats_capture_pruning_work",
        "adaptive_sweep_axis_prefers_sparse_projection_axis",
        "c_abi_segment_distance_writes_result_and_reports_errors",
        "c_abi_owned_string_result_handles_export_backend_report",
        "c_abi_owned_string_result_handles_export_segment_distance_report",
        "c_abi_owned_string_result_handles_export_gaussian_linking_report",
        "c_abi_owned_string_result_handles_export_writhe_report",
        "c_abi_owned_string_result_handles_export_contact_records_report",
        "c_abi_owned_string_result_handles_export_intersection_records_report",
        "c_abi_owned_string_result_handles_export_intersections_2d_report",
        "c_abi_owned_string_result_handles_export_candidate_pairs_2d_report",
        "c_abi_owned_string_result_handles_export_candidate_pairs_3d_report",
        "c_abi_batch_refinement_callbacks_report_progress_and_cancel",
        "c_abi_record_callbacks_report_progress_and_cancel",
        "c_abi_candidate_pairs_use_count_fill_and_buffer_errors",
        "c_abi_candidate_pairs_callbacks_report_progress_and_cancel",
        "c_abi_writhe_and_linking_callbacks_report_progress_and_cancel",
        "c_abi_record_outputs_keep_host_candidate_ids",
    ]:
        assert test_name in source
    assert "Rust segment distance kernel scaffold" not in source


def test_rust_readme_names_open_release_completion_artifacts() -> None:
    rust_readme = (ROOT / "native/iroll-kernels-rust/README.md").read_text(
        encoding="utf-8"
    )
    fixture_source = (ROOT / "src/iroll/topology/pd_fixtures.py").read_text(
        encoding="utf-8"
    )
    status = (ROOT / "docs/remaining-deep-execution-status.md").read_text(
        encoding="utf-8"
    )
    native_release_docs = (ROOT / "docs/native-release-ci.md").read_text(
        encoding="utf-8"
    )

    missing_artifact_tokens = [
        "release_grade_high_point_performance_pack",
        "signed_release_publication_manifest",
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "production_imgui_renderer_framebuffer_pack",
    ]
    for token in missing_artifact_tokens:
        assert token in rust_readme
        assert token in fixture_source
        assert token in status or token in native_release_docs

    boundary_tokens = [
        "retained unsigned wheel manifest",
        "local benchmark matrix",
        "do not publish signed artifacts",
        "do not certify",
        "release-grade speedup",
        "do not add native HOMFLY/Alexander compute handles",
        "do not close production ImGui",
        "framebuffer verification",
    ]
    for token in boundary_tokens:
        assert token in rust_readme


def test_cpp_smoke_caller_uses_rust_c_abi_without_python() -> None:
    smoke = (
        ROOT / "native/iroll-kernels-rust/examples/segment_distance_smoke.cpp"
    ).read_text(encoding="utf-8")

    assert '#include "iroll_kernels.h"' in smoke
    assert "iroll_kernel_abi_version" in smoke
    assert "iroll_kernel_backend_report_json" in smoke
    assert "iroll_kernel_owned_string_free" in smoke
    assert "owned_string_v1" in smoke
    for backend_report_guard in [
        r'std::strstr(backend_report.data, "\"python_file_recompute_boundary\":true") == nullptr',
        r'std::strstr(backend_report.data, "\"file_recompute_boundary\":{") == nullptr',
        r'std::strstr(backend_report.data, "\"boundary\":\"python_file_recompute\"") == nullptr',
        r'std::strstr(backend_report.data, "\"input_formats\":[") == nullptr',
        r'std::strstr(backend_report.data, "\"signed_pd_json\"") == nullptr',
        r'std::strstr(backend_report.data, "\"imgui_signed_pd_json\"") == nullptr',
        r'std::strstr(backend_report.data, "\"homfly_cli_command\":\"iroll homfly-pd\"") == nullptr',
        (
            r'std::strstr(backend_report.data, '
            r'"\"alexander_cli_command\":\"iroll multivariable-alexander-pd\"") '
            r"== nullptr"
        ),
        (
            r'std::strstr(backend_report.data, '
            r'"\"host_reload_payload\":\"imgui-signed-pd-invariant-status-payload\"") '
            r"== nullptr"
        ),
    ]:
        assert backend_report_guard in smoke
    assert "iroll_segment_segment_distance" in smoke
    assert "iroll_segment_segment_distance_report_json" in smoke
    assert "iroll_gaussian_linking_report_json" in smoke
    assert "iroll_writhe_report_json" in smoke
    assert "iroll_segment_contact_records_3d_report_json" in smoke
    assert "iroll_segment_intersection_records_2d_report_json" in smoke
    assert "iroll_segment_intersections_2d_report_json" in smoke
    assert "iroll_segment_bbox_candidate_pairs_2d_report_json" in smoke
    assert "iroll_segment_bbox_candidate_pairs_3d_report_json" in smoke
    assert "iroll_segment_segment_distances" in smoke
    assert "iroll_segment_segment_distances_with_callbacks" in smoke
    assert "iroll_segment_contact_records_3d_count" in smoke
    assert "iroll_segment_contact_records_3d_count_with_callbacks" in smoke
    assert "iroll_segment_contact_records_3d" in smoke
    assert "iroll_segment_contact_records_3d_with_callbacks" in smoke
    assert "iroll_segment_intersections_2d" in smoke
    assert "iroll_segment_intersections_2d_with_callbacks" in smoke
    assert "iroll_segment_intersection_records_2d_count" in smoke
    assert "iroll_segment_intersection_records_2d_count_with_callbacks" in smoke
    assert "iroll_segment_intersection_records_2d" in smoke
    assert "iroll_segment_intersection_records_2d_with_callbacks" in smoke
    assert "iroll_segment_bbox_candidate_pairs_2d" in smoke
    assert "iroll_segment_bbox_candidate_pairs_3d" in smoke
    assert "iroll_segment_bbox_candidate_pairs_2d_count_with_callbacks" in smoke
    assert "iroll_segment_bbox_candidate_pairs_2d_with_callbacks" in smoke
    assert "iroll_segment_bbox_candidate_pairs_3d_count_with_callbacks" in smoke
    assert "IROLL_STATUS_CANCELLED" in smoke
    assert "iroll_compute_writhe" in smoke
    assert "iroll_compute_writhe_with_callbacks" in smoke
    assert "iroll_compute_gaussian_linking_number" in smoke
    assert "iroll_compute_gaussian_linking_number_with_callbacks" in smoke
    assert "Python" not in smoke


def test_imgui_panel_is_host_embedded_not_main_loop_owned() -> None:
    header = (ROOT / "ui/imgui/include/iroll_imgui_panel.h").read_text(
        encoding="utf-8"
    )
    loader_header = (
        ROOT / "ui/imgui/include/iroll_imgui_kernel_loader.h"
    ).read_text(encoding="utf-8")
    source = (ROOT / "ui/imgui/src/iroll_imgui_panel.cpp").read_text(
        encoding="utf-8"
    )
    loader_source = (ROOT / "ui/imgui/src/iroll_imgui_kernel_loader.cpp").read_text(
        encoding="utf-8"
    )
    cmake = (ROOT / "ui/imgui/CMakeLists.txt").read_text(encoding="utf-8")
    readme = (ROOT / "ui/imgui/README.md").read_text(encoding="utf-8")
    imgui_stub = (ROOT / "ui/imgui/test_stubs/imgui.h").read_text(
        encoding="utf-8"
    )

    for symbol in [
        "IROLL_IMGUI_ABI_VERSION",
        "IROLL_INVARIANT_RESULT_HANDLES_STATUS_UNKNOWN",
        "IROLL_INVARIANT_RESULT_HANDLES_STATUS_UNSUPPORTED",
        "IROLL_INVARIANT_RESULT_HANDLES_STATUS_METADATA_ONLY",
        "IROLL_INVARIANT_RESULT_HANDLES_STATUS_RESULT_HANDLES_AVAILABLE",
        "IROLL_FIXTURE_SORT_LOADED_ORDER",
        "IROLL_FIXTURE_SORT_FIXTURE_NAME",
        "IROLL_FIXTURE_SORT_INVARIANT_NAME",
        "IROLL_FIXTURE_SORT_STATE",
        "IROLL_FIXTURE_SORT_SOURCE",
        "IrollImGui_ApiVersion",
        "IrollKernelApi",
        "kernel_abi_version",
        "kernel_backend_report_json",
        "invariant_result_handle_create_unsupported",
        "invariant_result_handle_report_json",
        "invariant_result_handle_free",
        "kernel_owned_string_free",
        "segment_segment_distance_report_json",
        "gaussian_linking_report_json",
        "writhe_report_json",
        "segment_contact_records_3d_report_json",
        "segment_intersection_records_2d_report_json",
        "segment_intersections_2d_report_json",
        "segment_bbox_candidate_pairs_2d_report_json",
        "segment_bbox_candidate_pairs_3d_report_json",
        "segment_segment_distances",
        "segment_segment_distances_with_callbacks",
        "segment_contact_records_3d_count",
        "segment_contact_records_3d_count_with_callbacks",
        "segment_contact_records_3d",
        "segment_contact_records_3d_with_callbacks",
        "segment_intersections_2d",
        "segment_intersections_2d_with_callbacks",
        "segment_intersection_records_2d_count",
        "segment_intersection_records_2d_count_with_callbacks",
        "segment_intersection_records_2d",
        "segment_intersection_records_2d_with_callbacks",
        "segment_bbox_candidate_pairs_2d_count",
        "segment_bbox_candidate_pairs_2d",
        "segment_bbox_candidate_pairs_2d_count_with_callbacks",
        "segment_bbox_candidate_pairs_2d_with_callbacks",
        "segment_bbox_candidate_pairs_3d_count",
        "segment_bbox_candidate_pairs_3d",
        "segment_bbox_candidate_pairs_3d_count_with_callbacks",
        "segment_bbox_candidate_pairs_3d_with_callbacks",
        "IrollImGui_CreateContext",
        "IrollImGui_DestroyContext",
        "IrollImGui_LoadReportJson",
        "IrollImGui_LoadPolyline3D",
        "IrollImGui_LoadComponents3D",
        "IrollProjectedCrossing",
        "IrollImGui_LoadProjectedCrossings",
        "IrollImGui_GetProjectedCrossing",
        "IrollImGui_UpdateProjectedCrossing",
        "IrollImGui_InsertProjectedCrossing",
        "IrollImGui_RemoveProjectedCrossing",
        "IrollContactOverlay",
        "IrollImGui_LoadContacts",
        "IrollImGui_GetContactOverlay",
        "IrollImGui_UpdateContactOverlay",
        "IrollImGui_InsertContactOverlay",
        "IrollImGui_RemoveContactOverlay",
        "IrollImGui_RequestGeometryOverlayRecompute",
        "IrollImGui_GetRequestedGeometryOverlayRecompute",
        "IrollImGui_ClearRequestedGeometryOverlayRecompute",
        "IrollImGuiGeometryPayload",
        "IrollImGui_LoadGeometryPayload",
        "IrollSignedPDCrossing",
        "selected_signed_pd_crossing",
        "IrollSignedPDValidationSummary",
        "signed_pd_valid",
        "signed_pd_unique_edge_label_count",
        "signed_pd_nonpositive_edge_label_count",
        "signed_pd_unexpected_edge_occurrence_count",
        "signed_pd_invalid_flow_count",
        "signed_pd_oriented_component_count",
        "signed_pd_component_count_matches",
        "signed_pd_revision",
        "invariant_status_signed_pd_revision",
        "signed_pd_invariant_status_stale",
        "IrollLinkClassificationSummary",
        "has_link_classification_summary",
        "link_classification_summary_link_type_length",
        "link_classification_summary_nontrivial_link_types_length",
        "link_classification_summary_nontrivial_notations_length",
        "link_classification_candidate_count",
        "link_classification_nontrivial_candidate_count",
        "link_classification_source_table_invariant_audit_available_count",
        "link_classification_source_table_invariant_audit_summary_count",
        "link_classification_source_table_nontrivial_candidate_count",
        "link_classification_source_table_nontrivial_candidate_notations_length",
        "link_classification_source_table_distinguishing_evidence_available",
        "link_classification_stronger_invariants_required",
        "link_classification_source_table_registration_ready_count",
        "link_classification_source_table_registration_blocked_count",
        "link_classification_source_table_registration_blocker_count",
        "link_classification_source_table_matched_invariant_count",
        "link_classification_source_table_uncomputed_invariant_count",
        "link_classification_source_table_mismatched_invariant_count",
        "link_classification_source_table_unstable_invariant_count",
        "link_classification_source_table_source_match_resolution_status_count",
        "link_classification_source_table_source_match_resolution_statuses_length",
        "source_table_source_match_resolution_statuses",
        "source_table_source_match_resolution_statuses_length",
        "source_table_source_match_resolution_status_count",
        "link_classification_source_table_homfly_variant_resolution_statuses_length",
        "link_classification_source_table_audit_notations_length",
        "link_classification_source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count",
        "link_classification_source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count",
        "link_classification_source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min",
        "link_classification_source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max",
        "link_classification_notes_length",
        "IrollInvariantStatus",
        "invariant_skipped_status_count",
        "invariant_failed_status_count",
        "invariant_required_check_count",
        "invariant_passed_check_count",
        "invariant_failed_check_count",
        "invariant_alexander_common_gcd_attempt_evidence_count",
        "invariant_alexander_common_gcd_proof_evidence_count",
        "invariant_alexander_common_gcd_input_polynomial_count",
        "invariant_alexander_common_gcd_unique_input_polynomial_count",
        "invariant_alexander_common_gcd_candidate_term_count",
        "invariant_alexander_common_gcd_divisible_input_count",
        "invariant_alexander_common_gcd_failed_input_count",
        "invariant_alexander_common_gcd_quotient_count",
        "invariant_alexander_common_gcd_unique_quotient_count",
        "invariant_alexander_common_gcd_quotient_unit_count",
        "invariant_alexander_common_gcd_support_signature_variant_count",
        "invariant_alexander_common_gcd_direct_divisor_candidate_count",
        "invariant_alexander_common_gcd_direct_divisor_failed_candidate_count",
        "invariant_alexander_common_gcd_direct_divisor_all_candidates_failed_count",
        "invariant_bounded_scanned_gcd_expected_minor_combination_count",
        "invariant_bounded_scanned_gcd_nonzero_minor_count",
        "invariant_bounded_scanned_gcd_zero_minor_count",
        "invariant_bounded_scanned_gcd_unit_minor_count",
        "invariant_bounded_scanned_gcd_unique_nonzero_polynomial_count",
        "invariant_bounded_scanned_gcd_all_rows_have_nonzero_minor_count",
        "invariant_bounded_scanned_gcd_all_columns_have_nonzero_minor_count",
        "invariant_bounded_scanned_gcd_complete_scan_count",
        "invariant_bounded_scanned_gcd_nonzero_minor_coverage_complete_count",
        "invariant_admissible_minor_normalization_checked_nonzero_minor_count",
        "invariant_admissible_minor_normalization_failed_nonzero_minor_count",
        "invariant_admissible_minor_normalization_all_equivalent_count",
        "invariant_admissible_minor_normalization_bounded_certified_count",
        "invariant_admissible_minor_normalization_complete_scan_count",
        "invariant_admissible_minor_normalization_nonzero_minor_coverage_complete_count",
        "invariant_admissible_minor_normalization_truncated_count",
        "invariant_admissible_minor_normalization_class_count",
        "invariant_admissible_minor_normalization_largest_class_minor_count",
        "invariant_admissible_minor_normalization_representative_class_minor_count",
        "invariant_admissible_minor_normalization_nonrepresentative_class_count",
        "invariant_source_table_alexander_numerator_checked_count",
        "invariant_source_table_alexander_numerator_source_seen_count",
        "invariant_source_table_alexander_numerator_complete_match_count",
        "invariant_source_table_alexander_numerator_returned_match_count",
        "invariant_source_table_alexander_numerator_incomplete_or_unstable_count",
        "invariant_source_table_alexander_numerator_candidate_unique_value_count",
        "invariant_source_table_alexander_numerator_computed_candidate_count",
        "invariant_source_table_alexander_numerator_skipped_candidate_count",
        "invariant_source_table_alexander_numerator_missing_candidate_count",
        "invariant_source_table_alexander_skipped_common_gcd_attempt_candidate_count",
        (
            "invariant_source_table_alexander_skipped_common_gcd_attempt_"
            "not_certified_candidate_count"
        ),
        "invariant_source_table_alexander_skipped_common_gcd_attempt_method_count",
        (
            "invariant_source_table_alexander_skipped_common_gcd_attempt_"
            "limit_variant_count"
        ),
        (
            "invariant_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_attempt_evidence_count"
        ),
        (
            "invariant_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_candidate_count_min"
        ),
        (
            "invariant_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_candidate_count_max"
        ),
        (
            "invariant_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_divides_all_candidate_count_min"
        ),
        (
            "invariant_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_divides_all_candidate_count_max"
        ),
        (
            "invariant_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_failed_candidate_count_min"
        ),
        (
            "invariant_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_failed_candidate_count_max"
        ),
        (
            "invariant_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_all_candidates_failed_count"
        ),
        (
            "invariant_source_table_alexander_skipped_common_gcd_attempt_"
            "support_signature_evidence_count"
        ),
        (
            "invariant_source_table_alexander_skipped_common_gcd_attempt_"
            "support_signature_variant_count"
        ),
        (
            "invariant_source_table_alexander_skipped_common_gcd_attempt_"
            "support_signature_input_count_min"
        ),
        (
            "invariant_source_table_alexander_skipped_common_gcd_attempt_"
            "support_signature_input_count_max"
        ),
        "invariant_source_table_alexander_source_divisibility_checked_candidate_count",
        (
            "invariant_source_table_alexander_source_divisibility_"
            "source_divides_all_candidate_count"
        ),
        (
            "invariant_source_table_alexander_source_divisibility_"
            "source_division_failed_candidate_count"
        ),
        "invariant_source_table_alexander_source_divisibility_status_variant_count",
        (
            "invariant_source_table_alexander_source_divisibility_"
            "failed_candidate_witness_count"
        ),
        (
            "invariant_source_table_alexander_source_divisibility_"
            "failed_candidate_witness_truncated"
        ),
        "invariant_source_table_audit_comparison_count",
        "invariant_source_table_audit_matched_invariant_count",
        "invariant_source_table_audit_mismatched_invariant_count",
        "invariant_source_table_audit_uncomputed_invariant_count",
        "invariant_source_table_audit_unstable_invariant_count",
        "invariant_source_table_audit_registration_ready_count",
        "invariant_source_table_audit_registration_blocked_count",
        "invariant_source_table_audit_registration_blocker_count",
        "invariant_source_table_audit_registration_blocker_code_count",
        "invariant_source_table_audit_registration_summary_consistency_available_count",
        "invariant_source_table_audit_registration_summary_consistency_matched_count",
        "invariant_source_table_audit_registration_summary_consistency_mismatch_count",
        "invariant_certification_blocker_count",
        "invariant_homfly_completion_blocker_count",
        "invariant_admissible_minor_normalization_blocker_count",
        "invariant_admissible_minor_normalization_blocker_reason_count",
        (
            "invariant_admissible_minor_normalization_blocker_"
            "witness_source_count"
        ),
        (
            "invariant_admissible_minor_normalization_blocker_"
            "witness_source_available_count"
        ),
        (
            "invariant_admissible_minor_normalization_blocker_"
            "witness_source_missing_count"
        ),
        (
            "invariant_admissible_minor_normalization_blocker_"
            "witness_available_count"
        ),
        (
            "invariant_admissible_minor_normalization_blocker_"
            "missing_witness_reason_count"
        ),
        "invariant_full_alexander_completion_blocker_count",
        "invariant_certification_blocker_detail_count",
        "invariant_homfly_completion_blocker_detail_count",
        "invariant_frontier_witness_summary_count",
        "invariant_frontier_witness_summary_reason_count",
        "invariant_frontier_witness_summary_truncated",
        "invariant_frontier_witness_summary_min_depth",
        "invariant_frontier_witness_summary_max_depth",
        "invariant_frontier_witness_summary_min_branch_depth",
        "invariant_frontier_witness_summary_max_branch_depth",
        "invariant_frontier_witness_summary_recursive_path_prefix_count",
        "invariant_frontier_witness_summary_source_kind_count",
        "invariant_frontier_witness_summary_branch_count",
        "invariant_frontier_witness_summary_pressure_total_frontier_count",
        "invariant_frontier_witness_summary_pressure_visible_witness_count",
        "invariant_frontier_witness_summary_pressure_missing_frontier_count",
        (
            "invariant_frontier_witness_summary_pressure_"
            "all_frontiers_have_visible_witness"
        ),
        "invariant_frontier_witness_summary_pressure_reason_count",
        "invariant_failed_division_witness_count",
        "invariant_quotient_gcd_uncertainty_present",
        "invariant_quotient_polynomial_witness_count",
        "invariant_quotient_polynomial_witness_truncated",
        "invariant_normalization_class_witness_count",
        "invariant_admissible_minor_normalization_gate_count",
        "invariant_admissible_minor_normalization_gate_passed_count",
        "invariant_admissible_minor_normalization_gate_failed_count",
        "invariant_admissible_minor_normalization_gate_summary_consistent",
        (
            "invariant_admissible_minor_normalization_"
            "failed_gate_blocker_count"
        ),
        "invariant_homfly_completion_blocker_provenance_matched",
        "invariant_homfly_completion_blocker_provenance_non_claim_matched",
        "invariant_homfly_completion_blocker_provenance_gate_pressure_matched",
        (
            "invariant_homfly_completion_blocker_provenance_"
            "frontier_pressure_matched"
        ),
        (
            "invariant_homfly_completion_blocker_provenance_"
            "frontier_witness_matched"
        ),
        "invariant_homfly_completion_blocker_provenance_terminal_audit_matched",
        "invariant_homfly_completion_blocker_provenance_source_field_count",
        (
            "invariant_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_consistent"
        ),
        (
            "invariant_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_row_count"
        ),
        (
            "invariant_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_gate_count"
        ),
        (
            "invariant_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_attribution_count"
        ),
        (
            "invariant_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_reason_count"
        ),
        (
            "invariant_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_source_available_count"
        ),
        (
            "invariant_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_source_missing_count"
        ),
        (
            "invariant_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_missing_source_count"
        ),
        (
            "invariant_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_inconsistent_source_count"
        ),
        "invariant_source_table_audit_source_match_resolution_status_count",
        "invariant_source_table_audit_source_match_resolution_statuses_length",
        "invariant_source_table_audit_homfly_source_variant_count",
        "invariant_source_table_audit_homfly_source_variant_seen_count",
        "invariant_source_table_audit_homfly_source_variant_miss_count",
        "invariant_source_table_audit_homfly_source_unit_normalized_variant_count",
        (
            "invariant_source_table_audit_homfly_source_"
            "unit_normalized_variant_seen_count"
        ),
        (
            "invariant_source_table_audit_homfly_source_"
            "unit_normalized_variant_miss_count"
        ),
        "invariant_source_table_audit_homfly_candidate_unique_value_count",
        (
            "invariant_source_table_audit_homfly_candidate_"
            "unit_normalized_value_count"
        ),
        "invariant_source_table_audit_homfly_variant_miss_witness_count",
        "invariant_source_table_audit_homfly_variant_miss_witness_limit",
        "invariant_source_table_audit_homfly_variant_miss_witness_truncated",
        "invariant_source_table_audit_candidate_convergence_partial_certified_count",
        "invariant_source_table_audit_candidate_convergence_full_certified_count",
        "invariant_source_table_audit_candidate_convergence_certified_invariant_count",
        "invariant_source_table_audit_candidate_convergence_uncertified_invariant_count",
        "invariant_source_table_audit_candidate_convergence_source_value_seen_count",
        (
            "invariant_source_table_audit_candidate_convergence_"
            "source_value_seen_but_uncertified_count"
        ),
        "invariant_source_table_audit_homfly_variant_resolution_status_code",
        "IrollFixtureComparison",
        "source_url_length",
        "certified_for_input",
        "full_table_normalization_certified",
        "bounded_scanned_gcd_certified",
        "full_invariant_certified",
        "IrollAnalysisSummary",
        "certification_scope_length",
        "certification_applicable_count",
        "certification_certified_count",
        "certification_uncertified_count",
        "certification_blocker_count",
        "homfly_completion_blocker_count",
        "admissible_minor_normalization_blocker_count",
        "admissible_minor_normalization_blocker_reason_count",
        "admissible_minor_normalization_blocker_witness_source_count",
        "admissible_minor_normalization_blocker_witness_source_available_count",
        "admissible_minor_normalization_blocker_witness_source_missing_count",
        "admissible_minor_normalization_blocker_witness_available_count",
        "admissible_minor_normalization_blocker_missing_witness_reason_count",
        "full_alexander_completion_blocker_count",
        "certification_blocker_detail_count",
        "homfly_completion_blocker_detail_count",
        "frontier_witness_summary_count",
        "frontier_witness_summary_reason_count",
        "frontier_witness_summary_truncated",
        "frontier_witness_summary_min_depth",
        "frontier_witness_summary_max_depth",
        "frontier_witness_summary_min_branch_depth",
        "frontier_witness_summary_max_branch_depth",
        "frontier_witness_summary_recursive_path_prefix_count",
        "frontier_witness_summary_source_kind_count",
        "frontier_witness_summary_branch_count",
        "frontier_witness_summary_pressure_total_frontier_count",
        "frontier_witness_summary_pressure_visible_witness_count",
        "frontier_witness_summary_pressure_missing_frontier_count",
        "frontier_witness_summary_pressure_all_frontiers_have_visible_witness",
        "frontier_witness_summary_pressure_reason_count",
        "failed_division_witness_count",
        "quotient_gcd_uncertainty_present",
        "quotient_polynomial_witness_count",
        "quotient_polynomial_witness_truncated",
        "normalization_class_witness_count",
        "admissible_minor_normalization_gate_count",
        "admissible_minor_normalization_gate_passed_count",
        "admissible_minor_normalization_gate_failed_count",
        "admissible_minor_normalization_gate_summary_consistent",
        "admissible_minor_normalization_failed_gate_blocker_count",
        "homfly_completion_blocker_provenance_matched",
        "homfly_completion_blocker_provenance_non_claim_matched",
        "homfly_completion_blocker_provenance_gate_pressure_matched",
        "homfly_completion_blocker_provenance_frontier_pressure_matched",
        "homfly_completion_blocker_provenance_frontier_witness_matched",
        "homfly_completion_blocker_provenance_terminal_audit_matched",
        "homfly_completion_blocker_provenance_source_field_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_consistent",
        "admissible_minor_normalization_failed_gate_blocker_provenance_row_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_gate_count",
        (
            "admissible_minor_normalization_failed_gate_blocker_provenance_"
            "attribution_count"
        ),
        "admissible_minor_normalization_failed_gate_blocker_provenance_reason_count",
        (
            "admissible_minor_normalization_failed_gate_blocker_provenance_"
            "source_available_count"
        ),
        (
            "admissible_minor_normalization_failed_gate_blocker_provenance_"
            "source_missing_count"
        ),
        (
            "admissible_minor_normalization_failed_gate_blocker_provenance_"
            "missing_source_count"
        ),
        (
            "admissible_minor_normalization_failed_gate_blocker_provenance_"
            "inconsistent_source_count"
        ),
        "has_source_signed_pd_revision",
        "source_signed_pd_revision",
        "input_certification_recursion_node_count",
        "input_certification_terminal_reduction_count",
        "input_certification_frontier_count",
        "input_certification_truncated_count",
        "input_certification_zero_crossing_count",
        "input_certification_iterative_attempt_count",
        "input_certification_iterative_solved_count",
        "input_certification_iterative_max_solved_depth",
        "input_certification_terminal_contribution_audit_applicable_count",
        "input_certification_terminal_contribution_matched_count",
        "input_certification_terminal_contribution_failed_count",
        "bounded_scanned_gcd_checked_nonzero_minor_count",
        "bounded_scanned_gcd_failed_nonzero_minor_count",
        "bounded_scanned_gcd_scanned_minor_count",
        "bounded_scanned_gcd_division_record_count",
        "bounded_scanned_gcd_complete_scan_count",
        "bounded_scanned_gcd_nonzero_minor_coverage_complete_count",
        "bounded_scanned_gcd_truncated_count",
        "bounded_scanned_gcd_quotient_gcd_certified_count",
        "bounded_scanned_gcd_complete_certified_count",
        "bounded_scanned_gcd_improved_candidate_count",
        "bounded_scanned_gcd_expected_minor_combination_count",
        "bounded_scanned_gcd_nonzero_minor_count",
        "bounded_scanned_gcd_zero_minor_count",
        "bounded_scanned_gcd_unit_minor_count",
        "bounded_scanned_gcd_unique_nonzero_polynomial_count",
        "bounded_scanned_gcd_all_rows_have_nonzero_minor_count",
        "bounded_scanned_gcd_all_columns_have_nonzero_minor_count",
        "registered_knot_admissible_normalization_applicable_count",
        "registered_knot_admissible_normalization_certified_count",
        "registered_knot_admissible_normalization_uncertified_count",
        "admissible_minor_normalization_checked_nonzero_minor_count",
        "admissible_minor_normalization_failed_nonzero_minor_count",
        "admissible_minor_normalization_all_equivalent_count",
        "admissible_minor_normalization_bounded_certified_count",
        "admissible_minor_normalization_complete_scan_count",
        "admissible_minor_normalization_nonzero_minor_coverage_complete_count",
        "admissible_minor_normalization_truncated_count",
        "admissible_minor_normalization_class_count",
        "admissible_minor_normalization_largest_class_minor_count",
        "admissible_minor_normalization_representative_class_minor_count",
        "admissible_minor_normalization_nonrepresentative_class_count",
        "source_table_alexander_numerator_checked_count",
        "source_table_alexander_numerator_source_seen_count",
        "source_table_alexander_numerator_complete_match_count",
        "source_table_alexander_numerator_returned_match_count",
        "source_table_alexander_numerator_incomplete_or_unstable_count",
        "source_table_alexander_numerator_candidate_unique_value_count",
        "source_table_alexander_numerator_computed_candidate_count",
        "source_table_alexander_numerator_skipped_candidate_count",
        "source_table_alexander_numerator_missing_candidate_count",
        "source_table_alexander_skipped_common_gcd_attempt_candidate_count",
        (
            "source_table_alexander_skipped_common_gcd_attempt_"
            "not_certified_candidate_count"
        ),
        "source_table_alexander_skipped_common_gcd_attempt_method_count",
        "source_table_alexander_skipped_common_gcd_attempt_limit_variant_count",
        (
            "source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_attempt_evidence_count"
        ),
        (
            "source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_candidate_count_min"
        ),
        (
            "source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_candidate_count_max"
        ),
        (
            "source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_divides_all_candidate_count_min"
        ),
        (
            "source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_divides_all_candidate_count_max"
        ),
        (
            "source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_failed_candidate_count_min"
        ),
        (
            "source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_failed_candidate_count_max"
        ),
        (
            "source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_all_candidates_failed_count"
        ),
        (
            "source_table_alexander_skipped_common_gcd_attempt_"
            "support_signature_evidence_count"
        ),
        (
            "source_table_alexander_skipped_common_gcd_attempt_"
            "support_signature_variant_count"
        ),
        (
            "source_table_alexander_skipped_common_gcd_attempt_"
            "support_signature_input_count_min"
        ),
        (
            "source_table_alexander_skipped_common_gcd_attempt_"
            "support_signature_input_count_max"
        ),
        "source_table_alexander_source_divisibility_checked_candidate_count",
        (
            "source_table_alexander_source_divisibility_"
            "source_divides_all_candidate_count"
        ),
        (
            "source_table_alexander_source_divisibility_"
            "source_division_failed_candidate_count"
        ),
        "source_table_alexander_source_divisibility_status_variant_count",
        (
            "source_table_alexander_source_divisibility_"
            "failed_candidate_witness_count"
        ),
        (
            "source_table_alexander_source_divisibility_"
            "failed_candidate_witness_truncated"
        ),
        "wirtinger_fox_relation_count",
        "wirtinger_fox_generator_count",
        "wirtinger_fox_scanned_minor_count",
        "wirtinger_fox_invalid_minor_reference_count",
        "wirtinger_fox_invalid_normalization_count",
        "wirtinger_fox_complete_scan_count",
        "wirtinger_fox_truncated_count",
        "generated_case_count",
        "generated_frontier_case_count",
        "generated_non_fixture_case_count",
        "generated_source_notation_count",
        "generated_branch_depth",
        "generated_max_branch_depth",
        "generated_unique_diagram_count",
        "generated_unique_oriented_diagram_count",
        "generated_zero_crossing_unlink_case_count",
        "generated_polynomial_variant_diagram_count",
        "generated_oriented_polynomial_conflict_count",
        "generated_unique_evaluation_count",
        "generated_reused_evaluation_count",
        "generated_source_summary_consistency_matched",
        "generated_source_summary_count_totals_matched",
        "generated_source_summary_distribution_totals_matched",
        "generated_source_summary_frontier_reason_counts_matched",
        "generated_source_summary_source_notation_count_matches_fixture_count",
        "role_order_signature_evaluated_candidate_count",
        "role_order_signature_resolution_status_code",
        "role_order_signature_all_strict_candidates_evaluated",
        "role_order_signature_strict_candidate_count",
        "role_order_signature_skipped_candidate_count",
        "role_order_signature_group_count",
        "role_order_signature_homfly_group_count",
        "role_order_signature_alexander_group_count",
        "role_order_signature_homfly_certified_candidate_count",
        "role_order_signature_homfly_frontier_count",
        "role_order_signature_homfly_frontier_reason_count",
        "role_order_signature_homfly_truncated_candidate_count",
        "role_order_signature_alexander_bounded_scanned_gcd_certified_candidate_count",
        "role_order_signature_alexander_complete_scanned_gcd_certified_candidate_count",
        "role_order_signature_alexander_quotient_gcd_certified_candidate_count",
        "role_order_signature_alexander_failed_nonzero_minor_count",
        "role_order_signature_alexander_truncated_candidate_count",
        "source_table_audit_comparison_count",
        "source_table_audit_matched_invariant_count",
        "source_table_audit_mismatched_invariant_count",
        "source_table_audit_uncomputed_invariant_count",
        "source_table_audit_unstable_invariant_count",
        "source_table_audit_candidate_count",
        "source_table_audit_unique_sign_pattern_count",
        "source_table_audit_computed_source_compatible_candidate_count",
        "source_table_audit_computed_source_compatible_unique_sign_pattern_count",
        "source_table_audit_complete_source_compatible_candidate_count",
        "source_table_audit_complete_source_compatible_unique_sign_pattern_count",
        "source_table_audit_top_candidate_count",
        "source_table_audit_top_unique_sign_pattern_count",
        "source_table_audit_max_matched_source_value_count",
        "source_table_audit_max_matched_candidate_total_count",
        "source_table_audit_max_matched_candidate_total_unique_sign_pattern_count",
        "source_table_audit_max_matched_candidate_count",
        "source_table_audit_max_matched_unique_sign_pattern_count",
        "source_table_audit_homfly_source_variant_count",
        "source_table_audit_homfly_source_variant_seen_count",
        "source_table_audit_homfly_source_variant_miss_count",
        "source_table_audit_homfly_source_unit_normalized_variant_count",
        "source_table_audit_homfly_source_unit_normalized_variant_seen_count",
        "source_table_audit_homfly_source_unit_normalized_variant_miss_count",
        "source_table_audit_homfly_candidate_unique_value_count",
        "source_table_audit_homfly_candidate_unit_normalized_value_count",
        "source_table_audit_homfly_variant_miss_witness_count",
        "source_table_audit_homfly_variant_miss_witness_limit",
        "source_table_audit_homfly_variant_miss_witness_truncated",
        "source_table_audit_candidate_convergence_partial_certified_count",
        "source_table_audit_candidate_convergence_full_certified_count",
        "source_table_audit_candidate_convergence_certified_invariant_count",
        "source_table_audit_candidate_convergence_uncertified_invariant_count",
        "source_table_audit_candidate_convergence_source_value_seen_count",
        (
            "source_table_audit_candidate_convergence_"
            "source_value_seen_but_uncertified_count"
        ),
        "source_table_audit_registration_ready_count",
        "source_table_audit_registration_blocked_count",
        "source_table_audit_registration_blocker_count",
        "source_table_audit_registration_blocker_code_count",
        "source_table_audit_registration_summary_consistency_available_count",
        "source_table_audit_registration_summary_consistency_matched_count",
        "source_table_audit_registration_summary_consistency_mismatch_count",
        "final_completion_blocker_completion_evidence_artifact_filename_reference_count",
        "final_completion_blocker_completion_evidence_artifact_filename_unique_count",
        "final_completion_failed_gate_completion_evidence_artifact_filename_reference_count",
        "final_completion_failed_gate_completion_evidence_artifact_filename_unique_count",
        "source_table_audit_source_match_resolution_statuses",
        "source_table_audit_source_match_resolution_statuses_length",
        "source_table_audit_source_match_resolution_status_count",
        "source_table_audit_homfly_variant_resolution_status_code",
        "required_check_count",
        "passed_check_count",
        "failed_check_count",
        "analysis_summary_count",
        "analysis_required_check_count",
        "analysis_passed_check_count",
        "analysis_failed_check_count",
        "fixture_visible_comparison_count",
        "fixture_matched_comparison_count",
        "fixture_mismatched_comparison_count",
        "fixture_skipped_comparison_count",
        "fixture_visible_matched_comparison_count",
        "fixture_visible_mismatched_comparison_count",
        "fixture_visible_skipped_comparison_count",
        "fixture_source_url_count",
        "fixture_visible_source_url_count",
        "analysis_accepted_summary_count",
        "analysis_rejected_summary_count",
        "analysis_certified_summary_count",
        "analysis_uncertified_summary_count",
        "analysis_failed_summary_count",
        "analysis_certification_applicable_count",
        "analysis_certification_certified_count",
        "analysis_certification_uncertified_count",
        "analysis_input_certification_recursion_node_count",
        "analysis_input_certification_terminal_reduction_count",
        "analysis_input_certification_frontier_count",
        "analysis_input_certification_truncated_count",
        "analysis_input_certification_zero_crossing_count",
        "analysis_input_certification_iterative_attempt_count",
        "analysis_input_certification_iterative_solved_count",
        "analysis_input_certification_iterative_max_solved_depth",
        "analysis_input_certification_terminal_contribution_audit_applicable_count",
        "analysis_input_certification_terminal_contribution_matched_count",
        "analysis_input_certification_terminal_contribution_failed_count",
        "analysis_bounded_scanned_gcd_checked_nonzero_minor_count",
        "analysis_bounded_scanned_gcd_failed_nonzero_minor_count",
        "analysis_bounded_scanned_gcd_scanned_minor_count",
        "analysis_bounded_scanned_gcd_division_record_count",
        "analysis_bounded_scanned_gcd_complete_scan_count",
        "analysis_bounded_scanned_gcd_nonzero_minor_coverage_complete_count",
        "analysis_bounded_scanned_gcd_truncated_count",
        "analysis_bounded_scanned_gcd_quotient_gcd_certified_count",
        "analysis_bounded_scanned_gcd_complete_certified_count",
        "analysis_bounded_scanned_gcd_improved_candidate_count",
        "analysis_bounded_scanned_gcd_expected_minor_combination_count",
        "analysis_bounded_scanned_gcd_nonzero_minor_count",
        "analysis_bounded_scanned_gcd_zero_minor_count",
        "analysis_bounded_scanned_gcd_unit_minor_count",
        "analysis_bounded_scanned_gcd_unique_nonzero_polynomial_count",
        "analysis_bounded_scanned_gcd_all_rows_have_nonzero_minor_count",
        "analysis_bounded_scanned_gcd_all_columns_have_nonzero_minor_count",
        "analysis_registered_knot_admissible_normalization_applicable_count",
        "analysis_registered_knot_admissible_normalization_certified_count",
        "analysis_registered_knot_admissible_normalization_uncertified_count",
        "analysis_admissible_minor_normalization_checked_nonzero_minor_count",
        "analysis_admissible_minor_normalization_failed_nonzero_minor_count",
        "analysis_admissible_minor_normalization_all_equivalent_count",
        "analysis_admissible_minor_normalization_bounded_certified_count",
        "analysis_admissible_minor_normalization_complete_scan_count",
        "analysis_admissible_minor_normalization_nonzero_minor_coverage_complete_count",
        "analysis_admissible_minor_normalization_truncated_count",
        "analysis_admissible_minor_normalization_class_count",
        "analysis_admissible_minor_normalization_largest_class_minor_count",
        "analysis_admissible_minor_normalization_representative_class_minor_count",
        "analysis_admissible_minor_normalization_nonrepresentative_class_count",
        "analysis_source_table_alexander_numerator_checked_count",
        "analysis_source_table_alexander_numerator_source_seen_count",
        "analysis_source_table_alexander_numerator_complete_match_count",
        "analysis_source_table_alexander_numerator_returned_match_count",
        "analysis_source_table_alexander_numerator_incomplete_or_unstable_count",
        "analysis_source_table_alexander_numerator_candidate_unique_value_count",
        "analysis_source_table_alexander_numerator_computed_candidate_count",
        "analysis_source_table_alexander_numerator_skipped_candidate_count",
        "analysis_source_table_alexander_numerator_missing_candidate_count",
        "analysis_source_table_alexander_skipped_common_gcd_attempt_candidate_count",
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "not_certified_candidate_count"
        ),
        "analysis_source_table_alexander_skipped_common_gcd_attempt_method_count",
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "limit_variant_count"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_attempt_evidence_count"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_candidate_count_min"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_candidate_count_max"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_divides_all_candidate_count_min"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_divides_all_candidate_count_max"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_failed_candidate_count_min"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_failed_candidate_count_max"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_all_candidates_failed_count"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "support_signature_evidence_count"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "support_signature_variant_count"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "support_signature_input_count_min"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "support_signature_input_count_max"
        ),
        "analysis_source_table_alexander_source_divisibility_checked_candidate_count",
        (
            "analysis_source_table_alexander_source_divisibility_"
            "source_divides_all_candidate_count"
        ),
        (
            "analysis_source_table_alexander_source_divisibility_"
            "source_division_failed_candidate_count"
        ),
        "analysis_source_table_alexander_source_divisibility_status_variant_count",
        (
            "analysis_source_table_alexander_source_divisibility_"
            "failed_candidate_witness_count"
        ),
        (
            "analysis_source_table_alexander_source_divisibility_"
            "failed_candidate_witness_truncated"
        ),
        "analysis_wirtinger_fox_relation_count",
        "analysis_wirtinger_fox_generator_count",
        "analysis_wirtinger_fox_scanned_minor_count",
        "analysis_wirtinger_fox_invalid_minor_reference_count",
        "analysis_wirtinger_fox_invalid_normalization_count",
        "analysis_wirtinger_fox_complete_scan_count",
        "analysis_wirtinger_fox_truncated_count",
        "analysis_generated_case_count",
        "analysis_generated_frontier_case_count",
        "analysis_generated_non_fixture_case_count",
        "analysis_generated_source_notation_count",
        "analysis_generated_max_branch_depth",
        "analysis_generated_unique_diagram_count",
        "analysis_generated_unique_oriented_diagram_count",
        "analysis_generated_zero_crossing_unlink_case_count",
        "analysis_generated_polynomial_variant_diagram_count",
        "analysis_generated_oriented_polynomial_conflict_count",
        "analysis_generated_unique_evaluation_count",
        "analysis_generated_reused_evaluation_count",
        "analysis_generated_source_summary_consistency_matched",
        "analysis_generated_source_summary_count_totals_matched",
        "analysis_generated_source_summary_distribution_totals_matched",
        "analysis_generated_source_summary_frontier_reason_counts_matched",
        "analysis_generated_source_summary_source_notation_count_matches_fixture_count",
        "analysis_role_order_signature_evaluated_candidate_count",
        "analysis_role_order_signature_all_strict_candidates_evaluated_count",
        "analysis_role_order_signature_strict_candidate_count",
        "analysis_role_order_signature_skipped_candidate_count",
        "analysis_role_order_signature_group_count",
        "analysis_role_order_signature_homfly_group_count",
        "analysis_role_order_signature_alexander_group_count",
        "analysis_role_order_signature_homfly_certified_candidate_count",
        "analysis_role_order_signature_homfly_frontier_count",
        "analysis_role_order_signature_homfly_frontier_reason_count",
        "analysis_role_order_signature_homfly_truncated_candidate_count",
        "analysis_role_order_signature_alexander_bounded_scanned_gcd_certified_candidate_count",
        "analysis_role_order_signature_alexander_complete_scanned_gcd_certified_candidate_count",
        "analysis_role_order_signature_alexander_quotient_gcd_certified_candidate_count",
        "analysis_role_order_signature_alexander_failed_nonzero_minor_count",
        "analysis_role_order_signature_alexander_truncated_candidate_count",
        "analysis_source_table_audit_comparison_count",
        "analysis_source_table_audit_matched_invariant_count",
        "analysis_source_table_audit_mismatched_invariant_count",
        "analysis_source_table_audit_uncomputed_invariant_count",
        "analysis_source_table_audit_unstable_invariant_count",
        "analysis_source_table_audit_candidate_count",
        "analysis_source_table_audit_unique_sign_pattern_count",
        "analysis_source_table_audit_computed_source_compatible_candidate_count",
        "analysis_source_table_audit_computed_source_compatible_unique_sign_pattern_count",
        "analysis_source_table_audit_complete_source_compatible_candidate_count",
        "analysis_source_table_audit_complete_source_compatible_unique_sign_pattern_count",
        "analysis_source_table_audit_top_candidate_count",
        "analysis_source_table_audit_top_unique_sign_pattern_count",
        "analysis_source_table_audit_max_matched_source_value_count",
        "analysis_source_table_audit_max_matched_candidate_total_count",
        "analysis_source_table_audit_max_matched_candidate_total_unique_sign_pattern_count",
        "analysis_source_table_audit_max_matched_candidate_count",
        "analysis_source_table_audit_max_matched_unique_sign_pattern_count",
        "analysis_source_table_audit_homfly_source_variant_count",
        "analysis_source_table_audit_homfly_source_variant_seen_count",
        "analysis_source_table_audit_homfly_source_variant_miss_count",
        "analysis_source_table_audit_homfly_source_unit_normalized_variant_count",
        "analysis_source_table_audit_homfly_source_unit_normalized_variant_seen_count",
        "analysis_source_table_audit_homfly_source_unit_normalized_variant_miss_count",
        "analysis_source_table_audit_homfly_candidate_unique_value_count",
        "analysis_source_table_audit_homfly_candidate_unit_normalized_value_count",
        "analysis_source_table_audit_homfly_variant_miss_witness_count",
        "analysis_source_table_audit_homfly_variant_miss_witness_limit",
        "analysis_source_table_audit_homfly_variant_miss_witness_truncated",
        "analysis_source_table_audit_registration_ready_count",
        "analysis_source_table_audit_registration_blocked_count",
        "analysis_source_table_audit_registration_blocker_count",
        "analysis_source_table_audit_registration_blocker_code_count",
        "analysis_source_table_audit_registration_summary_consistency_available_count",
        "analysis_source_table_audit_registration_summary_consistency_matched_count",
        "analysis_source_table_audit_registration_summary_consistency_mismatch_count",
        "analysis_final_completion_blocker_completion_evidence_artifact_filename_reference_count",
        "analysis_final_completion_blocker_completion_evidence_artifact_filename_unique_count",
        "analysis_final_completion_failed_gate_completion_evidence_artifact_filename_reference_count",
        "analysis_final_completion_failed_gate_completion_evidence_artifact_filename_unique_count",
        "analysis_source_table_audit_homfly_variant_resolution_status_code",
        "analysis_certification_blocker_count",
        "analysis_homfly_completion_blocker_count",
        "analysis_admissible_minor_normalization_blocker_count",
        "analysis_admissible_minor_normalization_blocker_reason_count",
        (
            "analysis_admissible_minor_normalization_blocker_"
            "witness_source_count"
        ),
        (
            "analysis_admissible_minor_normalization_blocker_"
            "witness_source_available_count"
        ),
        (
            "analysis_admissible_minor_normalization_blocker_"
            "witness_source_missing_count"
        ),
        (
            "analysis_admissible_minor_normalization_blocker_"
            "witness_available_count"
        ),
        (
            "analysis_admissible_minor_normalization_blocker_"
            "missing_witness_reason_count"
        ),
        "analysis_full_alexander_completion_blocker_count",
        "analysis_certification_blocker_detail_count",
        "analysis_homfly_completion_blocker_detail_count",
        "analysis_frontier_witness_summary_count",
        "analysis_frontier_witness_summary_reason_count",
        "analysis_frontier_witness_summary_truncated",
        "analysis_frontier_witness_summary_min_depth",
        "analysis_frontier_witness_summary_max_depth",
        "analysis_frontier_witness_summary_min_branch_depth",
        "analysis_frontier_witness_summary_max_branch_depth",
        "analysis_frontier_witness_summary_recursive_path_prefix_count",
        "analysis_frontier_witness_summary_source_kind_count",
        "analysis_frontier_witness_summary_branch_count",
        "analysis_frontier_witness_summary_pressure_total_frontier_count",
        "analysis_frontier_witness_summary_pressure_visible_witness_count",
        "analysis_frontier_witness_summary_pressure_missing_frontier_count",
        (
            "analysis_frontier_witness_summary_pressure_"
            "all_frontiers_have_visible_witness"
        ),
        "analysis_frontier_witness_summary_pressure_reason_count",
        "analysis_failed_division_witness_count",
        "analysis_quotient_gcd_uncertainty_present",
        "analysis_quotient_polynomial_witness_count",
        "analysis_quotient_polynomial_witness_truncated",
        "analysis_normalization_class_witness_count",
        "analysis_admissible_minor_normalization_gate_count",
        "analysis_admissible_minor_normalization_gate_passed_count",
        "analysis_admissible_minor_normalization_gate_failed_count",
        "analysis_admissible_minor_normalization_gate_summary_consistent",
        (
            "analysis_admissible_minor_normalization_"
            "failed_gate_blocker_count"
        ),
        "analysis_homfly_completion_blocker_provenance_matched",
        "analysis_homfly_completion_blocker_provenance_non_claim_matched",
        "analysis_homfly_completion_blocker_provenance_gate_pressure_matched",
        (
            "analysis_homfly_completion_blocker_provenance_"
            "frontier_pressure_matched"
        ),
        (
            "analysis_homfly_completion_blocker_provenance_"
            "frontier_witness_matched"
        ),
        "analysis_homfly_completion_blocker_provenance_terminal_audit_matched",
        "analysis_homfly_completion_blocker_provenance_source_field_count",
        (
            "analysis_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_consistent"
        ),
        (
            "analysis_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_row_count"
        ),
        (
            "analysis_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_gate_count"
        ),
        (
            "analysis_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_attribution_count"
        ),
        (
            "analysis_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_reason_count"
        ),
        (
            "analysis_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_source_available_count"
        ),
        (
            "analysis_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_source_missing_count"
        ),
        (
            "analysis_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_missing_source_count"
        ),
        (
            "analysis_admissible_minor_normalization_failed_gate_"
            "blocker_provenance_inconsistent_source_count"
        ),
        "analysis_source_table_audit_source_match_resolution_status_count",
        "analysis_source_table_audit_source_match_resolution_statuses_length",
        "analysis_source_table_audit_candidate_convergence_partial_certified_count",
        "analysis_source_table_audit_candidate_convergence_full_certified_count",
        "analysis_source_table_audit_candidate_convergence_certified_invariant_count",
        "analysis_source_table_audit_candidate_convergence_uncertified_invariant_count",
        "analysis_source_table_audit_candidate_convergence_source_value_seen_count",
        (
            "analysis_source_table_audit_candidate_convergence_"
            "source_value_seen_but_uncertified_count"
        ),
        "selected_fixture_comparison",
        "fixture_filter_length",
        "selected_fixture_source_length",
        "selected_fixture_source_url_length",
        "requested_fixture_source_url_length",
        "fixture_sort_mode",
        "requested_signed_pd_invariant_recompute_length",
        "requested_signed_pd_invariant_recompute_revision",
        "requested_signed_pd_invariant_recompute_snapshot_json_length",
        "requested_signed_pd_invariant_recompute_stale",
        "requested_geometry_overlay_recompute_length",
        "invariant_result_handles_status_code",
        "invariant_result_handles_homfly_report_json_available",
        "invariant_result_handles_alexander_report_json_available",
        "invariant_result_handles_native_computation_claimed",
        "invariant_result_handles_python_file_recompute_boundary",
        "invariant_result_handles_native_result_handles_complete",
        "invariant_result_handles_complete_result_handle_abi",
        "invariant_result_handles_release_grade_result_handles",
        "invariant_result_handles_metadata_schema_version",
        "invariant_result_handles_required_metadata_field_count",
        "invariant_result_handles_required_metadata_fields_present",
        "invariant_result_handles_metadata_contract_version_length",
        "invariant_result_handles_readiness_provenance_present",
        "invariant_result_handles_ready_for_native_result_handles",
        "invariant_result_handles_readiness_blocked_by_required_gates",
        "invariant_result_handles_readiness_provenance_note_length",
        "owned_string_contract_schema_version",
        "owned_string_contract_abi_version",
        "owned_string_contract_version_length",
        "owned_string_contract_free_required",
        "owned_string_contract_free_accepts_zero_initialized",
        "owned_string_contract_borrowed_across_calls",
        "kernel_backend_invariant_result_handles_metadata_only_count",
        "kernel_backend_invariant_result_handles_homfly_report_json_available_count",
        "kernel_backend_invariant_result_handles_alexander_report_json_available_count",
        "kernel_backend_invariant_result_handles_native_computation_claimed_count",
        "kernel_backend_invariant_result_handles_python_file_recompute_boundary_count",
        "kernel_backend_invariant_result_handles_native_result_handles_complete_count",
        "kernel_backend_invariant_result_handles_complete_result_handle_abi_count",
        "kernel_backend_invariant_result_handles_release_grade_result_handles_count",
        "kernel_backend_invariant_result_handles_metadata_schema_v1_count",
        "kernel_backend_invariant_result_handles_required_metadata_field_count_30_count",
        "kernel_backend_invariant_result_handles_required_metadata_fields_present_count",
        "kernel_backend_invariant_result_handles_metadata_contract_version_length_max",
        "kernel_backend_invariant_result_handles_readiness_provenance_present_count",
        "kernel_backend_invariant_result_handles_ready_for_native_result_handles_count",
        "kernel_backend_invariant_result_handles_readiness_blocked_by_required_gates_count",
        "kernel_backend_invariant_result_handles_readiness_provenance_note_length_max",
        "kernel_backend_owned_string_contract_schema_v1_count",
        "kernel_backend_owned_string_contract_abi_version_19_count",
        "kernel_backend_owned_string_contract_free_required_count",
        "kernel_backend_owned_string_contract_free_accepts_zero_initialized_count",
        "kernel_backend_owned_string_contract_borrowed_across_calls_count",
        "kernel_backend_owned_string_contract_version_length_max",
        "IrollKernelBackendStatus",
        "IrollKernelProgressStatus",
        "IrollPanelStats",
        "IrollImGui_LoadSignedPlanarDiagram",
        "IrollImGui_SelectSignedPDCrossing",
        "IrollImGui_SetSignedPDComponentCount",
        "IrollImGui_GetSelectedSignedPDCrossing",
        "IrollImGui_GetSignedPDCrossing",
        "IrollImGui_GetSignedPlanarDiagramInfo",
        "IrollImGui_CopySignedPlanarDiagram",
        "IrollImGui_GetSignedPlanarDiagramJson",
        "IrollImGui_UpdateSignedPDCrossing",
        "IrollImGui_InsertSignedPDCrossing",
        "IrollImGui_RemoveSignedPDCrossing",
        "IrollImGui_GetSignedPDValidationSummary",
        "IrollImGui_RequestSignedPDInvariantRecompute",
        "IrollImGui_GetRequestedSignedPDInvariantRecompute",
        "IrollImGui_GetRequestedSignedPDInvariantRecomputeRevision",
        "IrollImGui_GetRequestedSignedPDInvariantRecomputeSnapshotJson",
        "IrollImGui_GetRequestedSignedPDInvariantRecomputeStale",
        "IrollImGui_ClearRequestedSignedPDInvariantRecompute",
        "IrollImGui_LoadInvariantStatuses",
        "IrollImGui_LoadInvariantStatusesForSignedPDRevision",
        "IrollImGui_GetInvariantStatus",
        "IrollImGui_LoadFixtureComparisons",
        "IrollImGui_GetFixtureComparison",
        "IrollImGui_LoadAnalysisSummaries",
        "IrollImGui_GetAnalysisSummary",
        "IrollImGui_LoadLinkClassificationSummary",
        "IrollImGui_GetLinkClassificationSummary",
        "IrollImGui_ClearLinkClassificationSummary",
        "IrollImGui_LoadKernelBackendStatuses",
        "IrollImGui_GetKernelBackendStatus",
        "IrollImGui_SetView3D",
        "IrollImGui_GetView3D",
        "IrollImGui_SelectCrossing",
        "IrollImGui_SelectContact",
        "IrollImGui_GetSelection",
        "IrollImGui_SelectFixtureComparison",
        "IrollImGui_GetSelectedFixtureComparison",
        "IrollImGui_SetFixtureFilter",
        "IrollImGui_GetFixtureFilter",
        "IrollImGui_GetSelectedFixtureSource",
        "IrollImGui_GetSelectedFixtureSourceUrl",
        "IrollImGui_SetFixtureSortMode",
        "IrollImGui_GetFixtureSortMode",
        "IrollImGui_RequestSelectedFixtureSourceUrl",
        "IrollImGui_GetRequestedFixtureSourceUrl",
        "IrollImGui_ClearRequestedFixtureSourceUrl",
        "IrollImGui_GetPanelStats",
        "IrollImGui_ClearGeometry",
        "IrollImGui_ClearOverlays",
        "IrollImGui_ClearAnalysis",
        "IrollImGui_SetKernelApi",
        "IrollImGui_SetKernelDiagnostic",
        "IrollImGui_RequestKernelBackend",
        "IrollImGui_GetRequestedKernelBackend",
        "IrollImGui_ClearRequestedKernelBackend",
        "IrollImGui_SetKernelProgress",
        "IrollImGui_GetKernelProgress",
        "IrollImGui_RequestKernelCancel",
        "IrollImGui_GetKernelCancelRequested",
        "IrollImGui_ClearKernelCancelRequested",
        "IrollImGui_RunKernelSmoke",
        "IrollImGui_GetLastKernelResult",
        "IrollImGui_RenderPanel",
    ]:
        assert symbol in header
        assert symbol in source

    assert '#include "iroll_kernels.h"' in header
    assert "#define IROLL_IMGUI_ABI_VERSION 117" in header
    assert "invariant_result_handles_report_json" in header
    assert "IROLL_ROLE_ORDER_SIGNATURE_RESOLUTION_PARTIALLY_DISTINGUISHES" in header
    assert "IROLL_SOURCE_TABLE_HOMFLY_VARIANT_RESOLUTION_SOURCE_VARIANTS_MISSED" in header
    assert "ImGui::BeginChild" in source
    assert "ImGui::Button" in source
    assert "ImGui::GetWindowDrawList" in source
    assert "AddPolyline" in source
    assert "UiCamera3D" in source
    assert "UiRenderAudit" in source
    assert "begin_render_audit" in source
    assert "audit_geometry_polyline" in source
    for symbol in [
        "render_frame_count",
        "last_render_geometry_canvas_count",
        "last_render_geometry_filled_rect_count",
        "last_render_geometry_rect_count",
        "last_render_geometry_polyline_count",
        "last_render_geometry_marker_count",
        "last_render_geometry_text_count",
        "last_render_geometry_nonempty",
    ]:
        assert symbol in header
        assert symbol in source
    assert "IrollImGui_SetView3D" in source
    assert "IrollImGui_GetView3D" in source
    assert "IrollImGui_SelectCrossing" in source
    assert "IrollImGui_SelectContact" in source
    assert "IrollImGui_GetProjectedCrossing" in source
    assert "IrollImGui_UpdateProjectedCrossing" in source
    assert "IrollImGui_InsertProjectedCrossing" in source
    assert "IrollImGui_RemoveProjectedCrossing" in source
    assert "IrollImGui_GetContactOverlay" in source
    assert "IrollImGui_UpdateContactOverlay" in source
    assert "IrollImGui_InsertContactOverlay" in source
    assert "IrollImGui_RemoveContactOverlay" in source
    assert "Duplicate selected crossing overlay" in source
    assert "Remove selected crossing overlay" in source
    assert "Request crossing recompute" in source
    assert "Duplicate selected contact overlay" in source
    assert "Remove selected contact overlay" in source
    assert "Request contact recompute" in source
    assert "Requested geometry overlay recompute:" in source
    assert "component_point_at_segment" in source
    assert "XY Projection" in source
    assert "Run kernel smoke" in source
    assert "Kernel backends" in source
    assert "Requested backend" in source
    assert "Cancel kernel task" in source
    assert "Cancel requested" in source
    assert "3D contact API" in source
    assert "3D contact callback API" in source
    assert "batch distance callback API" in source
    assert "2D intersection API" in source
    assert "2D intersection callback API" in source
    assert "2D record API" in source
    assert "2D record callback API" in source
    assert "2D candidate API" in source
    assert "3D candidate API" in source
    assert "2D candidate callback API" in source
    assert "3D candidate callback API" in source
    assert "writhe callback API" in source
    assert "linking callback API" in source
    assert "callback progress" in source
    assert "backend_report_length" in source
    assert "UiInvariantResultHandlesMetadata" in source
    assert "UiOwnedStringContract" in source
    assert "parse_invariant_result_handles_metadata" in source
    assert "parse_owned_string_contract" in source
    assert "parse_json_object_field_text" in source
    assert "parse_json_size_field" in source
    assert "parse_json_bool_field" in source
    assert "parse_json_string_length_field" in source
    assert "last_owned_string_contract" in source
    assert "last_owned_string_contract = owned_string_contract" in source
    assert "owned_string_contract_schema_v1" in source
    assert "owned_string_contract_abi_v19" in source
    assert "owned_string_contract_version_v1" in source
    assert "owned string contract schema_version=%s" in source
    assert "free_accepts_zero_initialized=%s" in source
    assert "borrowed_across_calls=%s" in source
    assert "invariant_handles_metadata_schema_v1" in source
    assert "invariant_handles_metadata_contract_v1" in source
    assert "invariant_handles_required_metadata_field_count_30" in source
    assert "invariant_handles_required_metadata_fields_present" in source
    assert "readiness_provenance_self_consistency_present" in source
    assert "readiness_provenance_note_length" in source
    assert "invariant_result_handles_readiness_provenance_present" in header
    assert "invariant_result_handles_readiness_provenance_present" in source
    assert (
        "kernel_backend_invariant_result_handles_readiness_provenance_present_count"
        in header
    )
    assert (
        "kernel_backend_invariant_result_handles_readiness_provenance_present_count"
        in source
    )
    assert "readiness_provenance=%s" in source
    assert "ready_for_native_result_handles=%s" in source
    assert "readiness_blocked_by_required_gates=%s" in source
    assert "readiness_provenance_note=%s" in source
    assert "readiness_provenance_self_consistency=present" in header
    assert "last_invariant_result_handles_metadata = {}" in source
    assert "metadata_contract_version_length" in source
    assert "metadata_schema_version=%s" in source
    assert "metadata_contract_version=%s" in source
    assert "required_metadata_field_count=%s" in source
    assert "required_metadata_fields_present=%s" in source
    assert "native_result_handles_complete=%s" in source
    assert "complete_result_handle_abi=%s" in source
    assert "release_grade_result_handles=%s" in source
    assert "native_complete=%s" in source
    assert "complete_abi=%s" in source
    assert "release_grade=%s" in source
    assert "invariant_result_handles_native_result_handles_complete" in header
    assert "invariant_result_handles_complete_result_handle_abi" in header
    assert "invariant_result_handles_release_grade_result_handles" in header
    assert "kernel_backend_invariant_result_handles_native_result_handles_complete_count" in source
    assert "kernel_backend_invariant_result_handles_complete_result_handle_abi_count" in source
    assert "kernel_backend_invariant_result_handles_release_grade_result_handles_count" in source
    assert "invariant result-handle readiness provenance:" in source
    assert "blocked_by_required_gates=%s" in source
    assert "Projected crossings" in source
    assert "Contacts" in source
    assert "Selected contact" in source
    assert "overlay summary: crossings=%zu contacts=%zu selected_crossing=%d selected_contact=%d" in source
    assert "Selected crossing segments:" in source
    assert "Selected crossing parameters:" in source
    assert "Selected contact segments:" in source
    assert "Selected contact gap:" in source
    assert "Signed PD" in source
    assert "Signed PD validation:" in source
    assert "invalid_flow=%zu" in source
    assert "component_match=%s" in source
    assert "Signed PD revision:" in source
    assert "invariant_status=%s" in source
    assert "signed_pd_invariant_status_stale" in source
    assert "admissible-minor status scan: expected=%zu" in source
    assert "admissible-minor normalization status:" in source
    assert "source-table Alexander numerator status:" in source
    assert (
        "source-table registration status: ready=%zu, blocked=%zu, "
        "blockers=%zu, blocker_codes=%zu, consistency=%zu/%zu, mismatches=%zu"
    ) in source
    assert "signed_pd_validation_summary" in source
    assert "Select signed PD" in source
    assert "Increment signed PD component count" in source
    assert "Decrement signed PD component count" in source
    assert "Flip selected signed PD sign" in source
    assert "Cycle selected signed PD edge labels" in source
    assert "Reverse selected signed PD edge labels" in source
    assert "Cycle selected signed PD role order" in source
    assert "Reverse selected signed PD role order" in source
    assert "Reset selected signed PD role order" in source
    assert "IrollImGui_UpdateSignedPDCrossing" in source
    assert "IrollImGui_InsertSignedPDCrossing" in source
    assert "IrollImGui_RemoveSignedPDCrossing" in source
    assert "Duplicate selected signed PD crossing" in source
    assert "Remove selected signed PD crossing" in source
    assert "Request signed PD invariant recompute" in source
    assert "Requested signed PD recompute: %s @ revision %llu%s" in source
    assert "Analysis summaries" in source
    assert "scope:" in source
    assert "certification_scope:" in source
    assert "certification: %zu/%zu certified, %zu uncertified" in source
    assert "input certification evidence: nodes=%zu, terminals=%zu, frontier=%zu, truncated=%zu, zero=%zu, attempts=%zu, solved=%zu, max_depth=%zu" in source
    assert "scanned-gcd evidence: minors=%zu, checked_nonzero=%zu, failed=%zu, division=%zu, complete=%zu, nonzero_coverage_complete=%zu, truncated=%zu" in source
    assert "admissible-minor scan: expected=%zu, nonzero=%zu, zero=%zu, unit=%zu, unique_nonzero=%zu, rows_nonzero=%zu, columns_nonzero=%zu" in source
    assert "role-order signatures: strict=%zu, resolution_code=%d, all_strict=%d, evaluated=%zu" in source
    assert "alexander_complete_gcd=%zu" in source
    assert "source-table audit: comparisons=%zu" in source
    assert "homfly_variants=%zu/%zu miss=%zu" in source
    assert "Invariants" in source
    assert "[skipped]" in source
    assert "Fixture comparisons" in source
    assert "Select fixture" in source
    assert "fixture table summary: visible=%zu/%zu matched=%zu mismatch=%zu skipped=%zu" in source
    assert "visible_mismatch=%zu visible_skipped=%zu source_urls=%zu/%zu" in source
    assert "fixture row: fixture=%s | invariant=%s | state=%s | evidence=%zu/%zu failed=%zu" in source
    assert "fixture source row: source=%s | url=%s" in source
    assert "source_url:" in source
    assert "certification: input=%s, table=%s, scanned_gcd=%s, full_invariant=%s" in source
    assert "certified_for_input" in source
    assert "bounded_scanned_gcd_certified" in source
    assert "IrollImGui_SelectFixtureComparison" in source
    assert "IrollImGui_GetSelectedFixtureComparison" in source
    assert "fixture_filter:" in source
    assert "fixture_sort:" in source
    assert "Sort source" in source
    assert "Requested fixture source URL:" in source
    assert "selected fixture detail: index=%d fixture=%s invariant=%s state=%s source=%s" in source
    assert "Request source URL" in source
    assert "No fixture comparisons match the active filter." in source
    assert "fixture_comparison_matches_filter" in source
    assert "fixture_comparison_display_order" in source
    assert "IrollImGui_GetSelectedFixtureSourceUrl" in source
    assert "IrollImGui_RequestSelectedFixtureSourceUrl" in source
    assert "Analysis evidence" in source
    assert "evidence: %zu/%zu passed, %zu failed" in source
    assert "expected:" in source
    assert "observed:" in source
    assert "AddCircleFilled" in source
    assert "framebuffer_touched" in imgui_stub
    assert "estimated_nonzero_pixels" in imgui_stub
    assert "IrollTestImGui_TextCount" in imgui_stub
    assert "IrollTestImGui_MarkText" in imgui_stub
    assert "compute_writhe" in source
    assert "IrollTestImGui_ResetDrawStats" in (
        ROOT / "ui/imgui/examples/panel_contract_smoke.cpp"
    ).read_text(encoding="utf-8")
    smoke = (ROOT / "ui/imgui/examples/panel_contract_smoke.cpp").read_text(
        encoding="utf-8"
    )
    assert "IrollTestImGui_TextCount() < 10" in smoke
    worker_smoke = (
        ROOT / "ui/imgui/examples/worker_scheduler_smoke.cpp"
    ).read_text(encoding="utf-8")
    threaded_worker_smoke = (
        ROOT / "ui/imgui/examples/threaded_worker_smoke.cpp"
    ).read_text(encoding="utf-8")
    thread_pool_worker_smoke = (
        ROOT / "ui/imgui/examples/thread_pool_worker_smoke.cpp"
    ).read_text(encoding="utf-8")
    signed_pd_export_smoke = (
        ROOT / "ui/imgui/examples/signed_pd_json_export_smoke.cpp"
    ).read_text(encoding="utf-8")
    assert '\\"role_order_explicit\\":true' in signed_pd_export_smoke
    signed_pd_recompute_scheduler_smoke = (
        ROOT / "ui/imgui/examples/signed_pd_recompute_scheduler_smoke.cpp"
    ).read_text(encoding="utf-8")
    signed_pd_thread_pool_recompute_scheduler_smoke = (
        ROOT
        / "ui/imgui/examples/signed_pd_thread_pool_recompute_scheduler_smoke.cpp"
    ).read_text(encoding="utf-8")
    real_loader_smoke = (
        ROOT / "ui/imgui/examples/real_kernel_loader_smoke.cpp"
    ).read_text(encoding="utf-8")
    assert "IrollImGuiGeometryPayload geometry_payload" in smoke
    assert "IrollImGui_LoadGeometryPayload" in smoke
    assert "IrollImGui_GetProjectedCrossing" in smoke
    assert "IrollImGui_UpdateProjectedCrossing" in smoke
    assert "IrollImGui_InsertProjectedCrossing" in smoke
    assert "IrollImGui_RemoveProjectedCrossing" in smoke
    assert "IrollImGui_GetContactOverlay" in smoke
    assert "IrollImGui_UpdateContactOverlay" in smoke
    assert "IrollImGui_InsertContactOverlay" in smoke
    assert "IrollImGui_RemoveContactOverlay" in smoke
    assert "IrollImGui_RequestGeometryOverlayRecompute" in smoke
    assert "IrollImGui_GetRequestedGeometryOverlayRecompute" in smoke
    assert "IrollImGui_ClearRequestedGeometryOverlayRecompute" in smoke
    assert "IrollImGui_GetSignedPDCrossing" in smoke
    assert "IrollImGui_GetSignedPlanarDiagramInfo" in smoke
    assert "IrollImGui_CopySignedPlanarDiagram" in smoke
    assert "IrollImGui_GetSignedPlanarDiagramJson" in smoke
    assert "imgui_signed_pd_snapshot" in smoke
    assert "\\\"edge_labels\\\":[2,1,2,1]" in smoke
    assert "\\\"edge_labels\\\":[2,1,42,1]" in smoke
    assert "\\\"role_order_explicit\\\":true" in smoke
    assert "\\\"role_order_explicit\\\":false" in smoke
    assert "snapshot_revision" in smoke
    assert "edited_snapshot_revision <= initial_snapshot_revision" in smoke
    assert "IrollImGui_UpdateSignedPDCrossing" in smoke
    assert "IrollImGui_SetSignedPDComponentCount" in smoke
    assert "IrollImGui_InsertSignedPDCrossing" in smoke
    assert "IrollImGui_RemoveSignedPDCrossing" in smoke
    assert "IrollImGui_RequestSignedPDInvariantRecompute" in smoke
    assert "IrollImGui_GetRequestedSignedPDInvariantRecompute" in smoke
    assert "IrollImGui_ClearRequestedSignedPDInvariantRecompute" in smoke
    assert "IrollImGui_GetSignedPDValidationSummary" in smoke
    assert "signed_pd_validation.valid != 1" in smoke
    assert "labels_with_invalid_flow_count != 0" in smoke
    assert "oriented_component_count != 1" in smoke
    assert "oriented_component_count != 2" in smoke
    assert "stats.signed_pd_invalid_flow_count != 2" in smoke
    assert "stats.signed_pd_valid != 0" in smoke
    assert "invariant_bound_revision" in smoke
    assert "signed_pd_invariant_status_stale != 1" in smoke
    assert "stats.signed_pd_invariant_status_stale != 0" in smoke
    assert "invariant_status_signed_pd_revision" in smoke
    assert "invariant_status_count != 4" in smoke
    assert "invariant_skipped_status_count != 1" in smoke
    assert "invariant_failed_status_count != 2" in smoke
    assert "invariant_required_check_count != 12" in smoke
    assert "invariant_passed_check_count != 7" in smoke
    assert "invariant_failed_check_count != 5" in smoke
    assert "alexander_common_gcd_attempt_evidence_count = 1" in smoke
    assert "alexander_common_gcd_proof_evidence_count = 1" in smoke
    assert "alexander_common_gcd_quotient_count = 3" in smoke
    assert "invariant_alexander_common_gcd_attempt_evidence_count != 1" in smoke
    assert "invariant_alexander_common_gcd_proof_evidence_count != 1" in smoke
    assert "invariant_alexander_common_gcd_direct_divisor_candidate_count != 4" in smoke
    assert "bounded_scanned_gcd_expected_minor_combination_count = 2" in smoke
    assert "invariant_bounded_scanned_gcd_expected_minor_combination_count != 2" in smoke
    assert "invariant_bounded_scanned_gcd_nonzero_minor_count != 2" in smoke
    assert "invariant_bounded_scanned_gcd_complete_scan_count != 1" in smoke
    assert "admissible_minor_normalization_checked_nonzero_minor_count = 2" in smoke
    assert "admissible_minor_normalization_bounded_certified_count = 1" in smoke
    assert (
        "loaded_invariant_status.admissible_minor_normalization_class_count != 1"
        in smoke
    )
    assert (
        "loaded_invariant_status.admissible_minor_normalization_largest_class_minor_count !="
        in smoke
    )
    assert (
        "invariant_admissible_minor_normalization_checked_nonzero_minor_count != 2"
        in smoke
    )
    assert (
        "invariant_admissible_minor_normalization_bounded_certified_count != 1"
        in smoke
    )
    assert (
        "invariant_admissible_minor_normalization_class_count != 1"
        in smoke
    )
    assert (
        "invariant_admissible_minor_normalization_largest_class_minor_count != 2"
        in smoke
    )
    assert "source_table_status.source_table_audit_comparison_count = 3" in smoke
    assert (
        "source_table_status.source_table_audit_mismatched_invariant_count = 1"
        in smoke
    )
    assert (
        "source_table_status.source_table_audit_uncomputed_invariant_count = 2"
        in smoke
    )
    assert (
        "source_table_status.source_table_audit_homfly_source_variant_miss_count = 8"
        in smoke
    )
    assert (
        "source_table_audit_homfly_source_unit_normalized_variant_miss_count"
        in smoke
    )
    assert (
        "source_table_audit_homfly_candidate_unit_normalized_value_count"
        in smoke
    )
    assert (
        "source_table_status.source_table_audit_homfly_variant_miss_witness_count"
        in smoke
    )
    assert "source_table_audit_homfly_variant_miss_witness_limit" in smoke
    assert "source_table_audit_homfly_variant_miss_witness_truncated" in smoke
    assert "source_table_status.source_table_audit_registration_blocked_count = 1" in smoke
    assert (
        "source_table_status.source_table_audit_registration_blocker_code_count = 5"
        in smoke
    )
    assert (
        "source_table_status.source_table_audit_registration_summary_consistency_available_count = 1"
        in smoke
    )
    assert (
        "source_table_status.source_table_audit_registration_summary_consistency_matched_count = 1"
        in smoke
    )
    assert (
        "source_table_status.source_table_audit_registration_summary_consistency_mismatch_count = 0"
        in smoke
    )
    assert (
        "source_table_status.source_table_audit_homfly_variant_resolution_status_code ="
        in smoke
    )
    assert "source_match_statuses" in smoke
    assert "source_table_audit_source_match_resolution_status_count = 3" in smoke
    assert "source_table_audit_source_match_resolution_status_count != 3" in smoke
    assert "source_table_audit_source_match_resolution_statuses_length" in smoke
    assert "source_table_status.source_table_alexander_numerator_checked_count = 1" in smoke
    assert "source_table_status.source_table_alexander_numerator_computed_candidate_count = 16" in smoke
    assert (
        "source_table_status"
        ".source_table_alexander_skipped_common_gcd_attempt_candidate_count = 8"
        in smoke
    )
    assert (
        "source_table_status\n        "
        ".source_table_alexander_skipped_common_gcd_attempt_"
        "direct_divisor_attempt_evidence_count = 8"
        in smoke
    )
    assert (
        "source_table_status\n        "
        ".source_table_alexander_skipped_common_gcd_attempt_"
        "direct_divisor_failed_candidate_count_max = 10"
        in smoke
    )
    assert (
        "source_table_status\n        "
        ".source_table_alexander_skipped_common_gcd_attempt_"
        "direct_divisor_all_candidates_failed_count = 1"
        in smoke
    )
    assert (
        "source_table_status\n        "
        ".source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_evidence_count = 8"
        in smoke
    )
    assert (
        "source_table_status\n        "
        ".source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_variant_count = 1"
        in smoke
    )
    assert (
        "source_table_status\n        "
        ".source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_input_count_min = 25"
        in smoke
    )
    assert (
        "source_table_status\n        "
        ".source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_input_count_max = 25"
        in smoke
    )
    assert (
        "source_table_status"
        ".source_table_alexander_source_divisibility_checked_candidate_count = 8"
        in smoke
    )
    assert "source_table_status.certification_blocker_count = 7" in smoke
    assert "source_table_status.homfly_completion_blocker_count = 11" in smoke
    assert (
        "source_table_status.admissible_minor_normalization_blocker_count = 13"
        in smoke
    )
    assert (
        "source_table_status.admissible_minor_normalization_blocker_reason_count = 9"
        in smoke
    )
    assert (
        "source_table_status\n        "
        ".admissible_minor_normalization_blocker_witness_available_count = 7"
        in smoke
    )
    assert (
        "source_table_status\n        "
        ".admissible_minor_normalization_blocker_witness_source_count = 12"
        in smoke
    )
    assert (
        "source_table_status\n        "
        ".admissible_minor_normalization_blocker_witness_source_available_count = 8"
        in smoke
    )
    assert (
        "source_table_status\n        "
        ".admissible_minor_normalization_blocker_witness_source_missing_count = 4"
        in smoke
    )
    assert (
        "source_table_status\n        "
        ".admissible_minor_normalization_blocker_missing_witness_reason_count = 3"
        in smoke
    )
    assert "source_table_status.full_alexander_completion_blocker_count = 17" in smoke
    assert "source_table_status.certification_blocker_detail_count = 7" in smoke
    assert (
        "source_table_status.homfly_completion_blocker_detail_count = 11"
        in smoke
    )
    assert "source_table_status.failed_division_witness_count = 19" in smoke
    assert "source_table_status.quotient_gcd_uncertainty_present = 1" in smoke
    assert "source_table_status.normalization_class_witness_count = 23" in smoke
    assert "source_table_status.admissible_minor_normalization_gate_count = 6" in smoke
    assert (
        "source_table_status.admissible_minor_normalization_gate_summary_consistent ="
        in smoke
    )
    assert (
        "source_table_status\n        "
        ".admissible_minor_normalization_failed_gate_blocker_count = 3"
        in smoke
    )
    assert (
        "source_table_status"
        "\n        "
        ".source_table_alexander_source_divisibility_source_division_failed_candidate_count = 8"
        in smoke
    )
    assert (
        "source_table_status\n        "
        ".source_table_alexander_source_divisibility_"
        "failed_candidate_witness_count = 31"
        in smoke
    )
    assert (
        "source_table_status\n        "
        ".source_table_alexander_source_divisibility_"
        "failed_candidate_witness_truncated = 1"
        in smoke
    )
    assert "source_table_status.quotient_polynomial_witness_count = 29" in smoke
    assert "source_table_status.quotient_polynomial_witness_truncated = 1" in smoke
    assert "homfly_direct.frontier_witness_summary_count = 4" in smoke
    assert "homfly_direct.frontier_witness_summary_reason_count = 2" in smoke
    assert "homfly_direct.frontier_witness_summary_truncated = 1" in smoke
    assert "homfly_direct.frontier_witness_summary_min_depth = 2" in smoke
    assert "homfly_direct.frontier_witness_summary_max_depth = 5" in smoke
    assert "homfly_direct.frontier_witness_summary_min_branch_depth = 1" in smoke
    assert "homfly_direct.frontier_witness_summary_max_branch_depth = 4" in smoke
    assert (
        "homfly_direct.frontier_witness_summary_recursive_path_prefix_count = 2"
        in smoke
    )
    assert "homfly_direct.frontier_witness_summary_source_kind_count = 2" in smoke
    assert "homfly_direct.frontier_witness_summary_branch_count = 4" in smoke
    assert (
        "homfly_direct.frontier_witness_summary_pressure_total_frontier_count = 6"
        in smoke
    )
    assert (
        "homfly_direct.frontier_witness_summary_pressure_visible_witness_count = 4"
        in smoke
    )
    assert (
        "homfly_direct.frontier_witness_summary_pressure_missing_frontier_count = 2"
        in smoke
    )
    assert (
        "homfly_direct\n        "
        ".frontier_witness_summary_pressure_all_frontiers_have_visible_witness ="
        in smoke
    )
    assert "homfly_direct.frontier_witness_summary_pressure_reason_count = 2" in smoke
    assert "homfly_direct.homfly_completion_blocker_provenance_matched = 1" in smoke
    assert (
        "homfly_direct.homfly_completion_blocker_provenance_source_field_count = 8"
        in smoke
    )
    assert (
        "homfly_generated_summary.homfly_completion_blocker_provenance_matched = 1"
        in smoke
    )
    assert (
        "source_table_status\n        "
        ".admissible_minor_normalization_failed_gate_blocker_provenance_row_count ="
        in smoke
    )
    assert (
        "source_table_summary\n        "
        ".admissible_minor_normalization_failed_gate_blocker_provenance_row_count ="
        in smoke
    )
    assert "loaded_invariant_status.quotient_polynomial_witness_count != 0" in smoke
    assert "loaded_invariant_status.quotient_polynomial_witness_truncated != 0" in smoke
    assert "loaded_invariant_status.frontier_witness_summary_count != 0" in smoke
    assert "loaded_invariant_status.frontier_witness_summary_count != 4" in smoke
    assert "loaded_invariant_status.frontier_witness_summary_max_branch_depth != 4" in smoke
    assert (
        "loaded_invariant_status\n                "
        ".frontier_witness_summary_recursive_path_prefix_count != 2"
        in smoke
    )
    assert (
        "loaded_invariant_status\n                "
        ".source_table_alexander_source_divisibility_"
        "failed_candidate_witness_count !=\n            0"
        in smoke
    )
    assert "loaded_invariant_status.source_table_alexander_numerator_checked_count != 1" in smoke
    assert (
        "loaded_invariant_status.source_table_alexander_numerator_computed_candidate_count != 16"
        in smoke
    )
    assert (
        "loaded_invariant_status.source_table_audit_mismatched_invariant_count != 1"
        in smoke
    )
    assert (
        "loaded_invariant_status.source_table_audit_uncomputed_invariant_count != 2"
        in smoke
    )
    assert (
        "loaded_invariant_status.source_table_audit_homfly_source_variant_count != 8"
        in smoke
    )
    assert (
        "loaded_invariant_status"
        "\n                "
        ".source_table_audit_homfly_source_unit_normalized_variant_miss_count != 8"
        in smoke
    )
    assert (
        "loaded_invariant_status"
        ".source_table_audit_homfly_variant_resolution_status_code !="
        in smoke
    )
    assert (
        "loaded_invariant_status\n                "
        ".source_table_audit_homfly_variant_miss_witness_count != 6"
        in smoke
    )
    assert (
        "loaded_invariant_status\n                "
        ".source_table_audit_homfly_variant_miss_witness_limit != 8"
        in smoke
    )
    assert (
        "loaded_invariant_status\n                "
        ".source_table_audit_homfly_variant_miss_witness_truncated != 1"
        in smoke
    )
    assert "loaded_invariant_status.source_table_audit_registration_blocker_count != 6" in smoke
    assert (
        "loaded_invariant_status.source_table_audit_registration_blocker_code_count != 5"
        in smoke
    )
    assert (
        "loaded_invariant_status"
        "\n                "
        ".source_table_audit_registration_summary_consistency_available_count !="
        in smoke
    )
    assert (
        "loaded_invariant_status"
        "\n                "
        ".source_table_audit_registration_summary_consistency_matched_count !="
        in smoke
    )
    assert (
        "loaded_invariant_status"
        "\n                "
        ".source_table_audit_registration_summary_consistency_mismatch_count !="
        in smoke
    )
    assert "loaded_invariant_status.certification_blocker_count != 7" in smoke
    assert "loaded_invariant_status.homfly_completion_blocker_count != 11" in smoke
    assert (
        "loaded_invariant_status.admissible_minor_normalization_blocker_count != 13"
        in smoke
    )
    assert (
        "loaded_invariant_status\n                "
        ".admissible_minor_normalization_blocker_reason_count != 9"
        in smoke
    )
    assert (
        "loaded_invariant_status\n                "
        ".admissible_minor_normalization_blocker_witness_available_count !=\n"
        "            7"
        in smoke
    )
    assert (
        "loaded_invariant_status\n                "
        ".admissible_minor_normalization_blocker_witness_source_count != 12"
        in smoke
    )
    assert (
        "loaded_invariant_status\n                "
        ".admissible_minor_normalization_blocker_witness_source_available_count != 8"
        in smoke
    )
    assert (
        "loaded_invariant_status\n                "
        ".admissible_minor_normalization_blocker_witness_source_missing_count != 4"
        in smoke
    )
    assert (
        "loaded_invariant_status\n                "
        ".admissible_minor_normalization_blocker_missing_witness_reason_count !=\n"
        "            3"
        in smoke
    )
    assert "loaded_invariant_status.full_alexander_completion_blocker_count != 17" in smoke
    assert "loaded_invariant_status.certification_blocker_detail_count != 7" in smoke
    assert (
        "loaded_invariant_status.homfly_completion_blocker_detail_count != 11"
        in smoke
    )
    assert "loaded_invariant_status.failed_division_witness_count != 19" in smoke
    assert "loaded_invariant_status.quotient_gcd_uncertainty_present != 1" in smoke
    assert "loaded_invariant_status.quotient_polynomial_witness_count != 29" in smoke
    assert "loaded_invariant_status.quotient_polynomial_witness_truncated != 1" in smoke
    assert (
        "loaded_invariant_status.normalization_class_witness_count != 23"
        in smoke
    )
    assert "loaded_invariant_status.admissible_minor_normalization_gate_count !=" in smoke
    assert (
        "loaded_invariant_status\n                "
        ".admissible_minor_normalization_failed_gate_blocker_count != 3"
        in smoke
    )
    assert "invariant_source_table_alexander_numerator_checked_count != 1" in smoke
    assert "invariant_source_table_alexander_numerator_source_seen_count != 1" in smoke
    assert (
        "invariant_source_table_alexander_numerator_incomplete_or_unstable_count != 1"
        in smoke
    )
    assert "invariant_source_table_alexander_numerator_computed_candidate_count != 16" in smoke
    assert "invariant_source_table_alexander_numerator_skipped_candidate_count != 8" in smoke
    assert "invariant_source_table_alexander_numerator_missing_candidate_count != 8" in smoke
    assert (
        "invariant_homfly_completion_blocker_provenance_source_field_count !="
        in smoke
    )
    assert (
        "invariant_admissible_minor_normalization_failed_gate_blocker_provenance_row_count !="
        in smoke
    )
    assert (
        "analysis_homfly_completion_blocker_provenance_source_field_count !="
        in smoke
    )
    assert (
        "analysis_admissible_minor_normalization_failed_gate_blocker_provenance_row_count !="
        in smoke
    )
    assert (
        "invariant_source_table_alexander_skipped_common_gcd_attempt_candidate_count != 8"
        in smoke
    )
    assert (
        "invariant_source_table_alexander_skipped_common_gcd_attempt_method_count != 8"
        in smoke
    )
    assert (
        "invariant_source_table_alexander_skipped_common_gcd_attempt_limit_variant_count != 1"
        in smoke
    )
    assert (
        "invariant_source_table_alexander_skipped_common_gcd_attempt_"
        "direct_divisor_attempt_evidence_count != 8"
        in smoke
    )
    assert (
        "invariant_source_table_alexander_skipped_common_gcd_attempt_"
        "direct_divisor_failed_candidate_count_max != 10"
        in smoke
    )
    assert (
        "invariant_source_table_alexander_skipped_common_gcd_attempt_"
        "direct_divisor_all_candidates_failed_count != 1"
        in smoke
    )
    assert (
        "invariant_source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_evidence_count != 8"
        in smoke
    )
    assert (
        "invariant_source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_variant_count != 1"
        in smoke
    )
    assert (
        "invariant_source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_input_count_min != 25"
        in smoke
    )
    assert (
        "invariant_source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_input_count_max != 25"
        in smoke
    )
    assert (
        "invariant_source_table_alexander_source_divisibility_checked_candidate_count != 8"
        in smoke
    )
    assert (
        "invariant_source_table_alexander_source_divisibility_status_variant_count != 1"
        in smoke
    )
    assert (
        "invariant_source_table_alexander_source_divisibility_"
        "failed_candidate_witness_count != 31"
        in smoke
    )
    assert (
        "invariant_source_table_alexander_source_divisibility_"
        "failed_candidate_witness_truncated != 1"
        in smoke
    )
    assert "invariant_source_table_audit_mismatched_invariant_count != 1" in smoke
    assert "invariant_source_table_audit_uncomputed_invariant_count != 2" in smoke
    assert "invariant_source_table_audit_homfly_source_variant_miss_count != 8" in smoke
    assert (
        "invariant_source_table_audit_homfly_source_unit_normalized_variant_miss_count != 8"
        in smoke
    )
    assert (
        "invariant_source_table_audit_homfly_candidate_unit_normalized_value_count != 6"
        in smoke
    )
    assert (
        "invariant_source_table_audit_homfly_variant_miss_witness_count != 6"
        in smoke
    )
    assert (
        "invariant_source_table_audit_homfly_variant_miss_witness_limit != 8"
        in smoke
    )
    assert (
        "invariant_source_table_audit_homfly_variant_miss_witness_truncated != 1"
        in smoke
    )
    assert "invariant_source_table_audit_registration_blocked_count != 1" in smoke
    assert "invariant_source_table_audit_registration_blocker_count != 6" in smoke
    assert "invariant_source_table_audit_registration_blocker_code_count != 5" in smoke
    assert (
        "invariant_source_table_audit_registration_summary_consistency_available_count != 1"
        in smoke
    )
    assert (
        "invariant_source_table_audit_registration_summary_consistency_matched_count != 1"
        in smoke
    )
    assert (
        "invariant_source_table_audit_registration_summary_consistency_mismatch_count != 0"
        in smoke
    )
    assert "invariant_certification_blocker_count != 7" in smoke
    assert "invariant_homfly_completion_blocker_count != 11" in smoke
    assert "invariant_admissible_minor_normalization_blocker_count != 13" in smoke
    assert "invariant_admissible_minor_normalization_blocker_reason_count != 9" in smoke
    assert (
        "invariant_admissible_minor_normalization_blocker_witness_source_count != 12"
        in smoke
    )
    assert (
        "invariant_admissible_minor_normalization_blocker_witness_source_available_count !="
        in smoke
    )
    assert (
        "invariant_admissible_minor_normalization_blocker_witness_source_missing_count != 4"
        in smoke
    )
    assert (
        "invariant_admissible_minor_normalization_blocker_witness_available_count != 7"
        in smoke
    )
    assert (
        "invariant_admissible_minor_normalization_blocker_missing_witness_reason_count != 3"
        in smoke
    )
    assert "invariant_full_alexander_completion_blocker_count != 17" in smoke
    assert "invariant_certification_blocker_detail_count != 7" in smoke
    assert "invariant_homfly_completion_blocker_detail_count != 11" in smoke
    assert "invariant_frontier_witness_summary_count != 4" in smoke
    assert "invariant_frontier_witness_summary_reason_count != 2" in smoke
    assert "invariant_frontier_witness_summary_truncated != 1" in smoke
    assert "invariant_frontier_witness_summary_min_depth != 2" in smoke
    assert "invariant_frontier_witness_summary_max_depth != 5" in smoke
    assert "invariant_frontier_witness_summary_min_branch_depth != 1" in smoke
    assert "invariant_frontier_witness_summary_max_branch_depth != 4" in smoke
    assert "invariant_frontier_witness_summary_recursive_path_prefix_count != 2" in smoke
    assert "invariant_frontier_witness_summary_source_kind_count != 2" in smoke
    assert "invariant_frontier_witness_summary_branch_count != 4" in smoke
    assert (
        "invariant_frontier_witness_summary_pressure_total_frontier_count !="
        in smoke
    )
    assert (
        "invariant_frontier_witness_summary_pressure_visible_witness_count !="
        in smoke
    )
    assert (
        "invariant_frontier_witness_summary_pressure_missing_frontier_count !="
        in smoke
    )
    assert (
        "invariant_frontier_witness_summary_pressure_all_frontiers_have_visible_witness !="
        in smoke
    )
    assert "invariant_frontier_witness_summary_pressure_reason_count !=" in smoke
    assert "invariant_failed_division_witness_count != 19" in smoke
    assert "invariant_quotient_gcd_uncertainty_present != 1" in smoke
    assert "invariant_quotient_polynomial_witness_count != 29" in smoke
    assert "invariant_quotient_polynomial_witness_truncated != 1" in smoke
    assert "invariant_normalization_class_witness_count != 23" in smoke
    assert "invariant_admissible_minor_normalization_gate_count != 10" in smoke
    assert (
        "invariant_admissible_minor_normalization_gate_passed_count !="
        in smoke
    )
    assert (
        "invariant_admissible_minor_normalization_gate_summary_consistent !="
        in smoke
    )
    assert (
        "invariant_source_table_audit_candidate_convergence_uncertified_invariant_count !="
        in smoke
    )
    assert (
        "invariant_source_table_audit_source_match_resolution_status_count != 3"
        in smoke
    )
    assert (
        "invariant_source_table_audit_source_match_resolution_statuses_length !="
        in smoke
    )
    assert (
        "invariant_source_table_audit_homfly_variant_resolution_status_code !="
        in smoke
    )
    assert "HOMFLY-PT input evidence" in smoke
    assert "terminal_contribution_matches_result=True" in smoke
    assert "multi-variable Alexander minor divisibility" in smoke
    assert "quotient_gcd_certified=True" in smoke
    assert "stats.requested_geometry_overlay_recompute_length" in smoke
    assert "stats.requested_signed_pd_invariant_recompute_length" in smoke
    assert "stats.requested_signed_pd_invariant_recompute_revision" in smoke
    assert "stats.requested_signed_pd_invariant_recompute_snapshot_json_length" in smoke
    assert "stats.requested_signed_pd_invariant_recompute_stale" in smoke
    assert "IrollImGui_LoadLinkClassificationSummary" in smoke
    assert "IrollImGui_GetLinkClassificationSummary" in smoke
    assert "pairwise_unlink_candidate" in smoke
    assert "whitehead_link,borromean_rings" in smoke
    assert "link_classification_candidate_count != 4" in smoke
    assert "link_classification_nontrivial_candidate_count != 2" in smoke
    assert (
        "link_classification_source_table_distinguishing_evidence_available != 1"
        in smoke
    )
    assert "link_classification_stronger_invariants_required != 1" in smoke
    assert "link_classification_source_table_registration_blocker_count != 3" in smoke
    assert "link_classification_source_table_mismatched_invariant_count != 1" in smoke
    assert "link_classification_source_match_statuses" in smoke
    assert "source_table_source_match_resolution_status_count = 6" in smoke
    assert "source_table_source_match_resolution_status_count != 6" in smoke
    assert (
        "link_classification_source_table_source_match_resolution_status_count !="
        in smoke
    )
    assert (
        "link_classification_source_table_source_match_resolution_statuses_length !="
        in smoke
    )
    assert (
        ".source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_evidence_count =\n        8"
        in smoke
    )
    assert (
        ".source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_variant_count =\n        1"
        in smoke
    )
    assert (
        ".source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_input_count_min =\n        25"
        in smoke
    )
    assert (
        ".source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_input_count_max =\n        25"
        in smoke
    )
    assert (
        ".source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_evidence_count !="
        in smoke
    )
    assert (
        ".source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_variant_count !="
        in smoke
    )
    assert (
        "link_classification_source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_evidence_count !="
        in smoke
    )
    assert (
        "link_classification_source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_input_count_max !="
        in smoke
    )
    assert "selected_signed_pd_crossing" in smoke
    assert "IrollImGui_LoadAnalysisSummaries" in smoke
    assert "has_source_signed_pd_revision = 1" in smoke
    assert "source_signed_pd_revision = 42" in smoke
    assert "certification_applicable_count = 5" in smoke
    assert "certification_certified_count = 5" in smoke
    assert "input_certification_recursion_node_count = 21" in smoke
    assert "input_certification_iterative_attempt_count = 9" in smoke
    assert "input_certification_iterative_solved_count = 5" in smoke
    assert "input_certification_iterative_max_solved_depth = 4" in smoke
    assert "bounded_scanned_gcd_checked_nonzero_minor_count = 4" in smoke
    assert "bounded_scanned_gcd_nonzero_minor_coverage_complete_count = 1" in smoke
    assert "bounded_scanned_gcd_quotient_gcd_certified_count = 3" in smoke
    assert "bounded_scanned_gcd_complete_certified_count = 1" in smoke
    assert "bounded_scanned_gcd_improved_candidate_count = 1" in smoke
    assert "bounded_scanned_gcd_expected_minor_combination_count = 4" in smoke
    assert "bounded_scanned_gcd_nonzero_minor_count = 4" in smoke
    assert "bounded_scanned_gcd_unique_nonzero_polynomial_count = 2" in smoke
    assert "bounded_scanned_gcd_all_rows_have_nonzero_minor_count = 1" in smoke
    assert "bounded_scanned_gcd_all_columns_have_nonzero_minor_count = 1" in smoke
    assert "registered_knot_admissible_normalization_applicable_count = 2" in smoke
    assert "registered_knot_admissible_normalization_certified_count = 2" in smoke
    assert "wirtinger_fox_relation_count = 3" in smoke
    assert "wirtinger_fox_scanned_minor_count = 9" in smoke
    assert "wirtinger_fox_invalid_normalization_count = 0" in smoke
    assert "HOMFLY generated small-diagram coverage" in smoke
    assert "generated_small_signed_pd_frontier_exhaustion" in smoke
    assert "input_certification_iterative_attempt_count = 132" in smoke
    assert "input_certification_iterative_solved_count = 30" in smoke
    assert "input_certification_iterative_max_solved_depth = 7" in smoke
    assert "multi-variable Alexander generated signed-PD coverage" in smoke
    assert "generated_small_signed_pd_wirtinger_fox_scanned_gcd_coverage" in smoke
    assert "required_check_count = 30" in smoke
    assert "certification_applicable_count = 30" in smoke
    assert "certification_certified_count = 30" in smoke
    assert "bounded_scanned_gcd_checked_nonzero_minor_count = 281" in smoke
    assert "bounded_scanned_gcd_scanned_minor_count = 281" in smoke
    assert "bounded_scanned_gcd_complete_scan_count = 30" in smoke
    assert "bounded_scanned_gcd_nonzero_minor_coverage_complete_count = 28" in smoke
    assert "bounded_scanned_gcd_quotient_gcd_certified_count = 30" in smoke
    assert "bounded_scanned_gcd_complete_certified_count = 28" in smoke
    assert "bounded_scanned_gcd_expected_minor_combination_count = 330" in smoke
    assert "bounded_scanned_gcd_nonzero_minor_count = 281" in smoke
    assert "bounded_scanned_gcd_zero_minor_count = 49" in smoke
    assert "bounded_scanned_gcd_unit_minor_count = 3" in smoke
    assert "bounded_scanned_gcd_unique_nonzero_polynomial_count = 17" in smoke
    assert "bounded_scanned_gcd_all_rows_have_nonzero_minor_count = 28" in smoke
    assert "bounded_scanned_gcd_all_columns_have_nonzero_minor_count = 28" in smoke
    assert "wirtinger_fox_scanned_minor_count = 281" in smoke
    assert "wirtinger_fox_invalid_normalization_count = 0" in smoke
    assert "wirtinger_fox_complete_scan_count = 30" in smoke
    assert "multi-variable Alexander improved scanned gcd" in smoke
    assert "bounded_scanned_fox_minor_improved_candidate" in smoke
    assert "source_polynomial=1 - t1" in smoke
    assert "improved_candidate=1 - t2 - t1 + t1*t2" in smoke
    assert (
        "loaded_analysis_summary.admissible_minor_normalization_checked_nonzero_minor_count != 2"
        in smoke
    )
    assert (
        "loaded_analysis_summary.admissible_minor_normalization_bounded_certified_count != 1"
        in smoke
    )
    assert (
        "loaded_analysis_summary.admissible_minor_normalization_class_count != 1"
        in smoke
    )
    assert (
        "loaded_analysis_summary.admissible_minor_normalization_largest_class_minor_count !="
        in smoke
    )
    assert "IrollImGui_SelectFixtureComparison" in smoke
    assert "IrollImGui_GetSelectedFixtureComparison" in smoke
    assert "IrollImGui_SetFixtureFilter" in smoke
    assert "IrollImGui_GetFixtureFilter" in smoke
    assert "IrollImGui_GetSelectedFixtureSource" in smoke
    assert "IrollImGui_GetSelectedFixtureSourceUrl" in smoke
    assert "IrollImGui_SetFixtureSortMode" in smoke
    assert "IrollImGui_GetFixtureSortMode" in smoke
    assert "IrollImGui_RequestSelectedFixtureSourceUrl" in smoke
    assert "IrollImGui_GetRequestedFixtureSourceUrl" in smoke
    assert "IrollImGui_ClearRequestedFixtureSourceUrl" in smoke
    assert "write_source_open_request_smoke_json" in smoke
    assert "imgui_source_open_request_smoke" in smoke
    assert "host_polled_source_open_request_contract" in smoke
    assert "request_consumed_by_smoke" in smoke
    assert "request_cleared_after_consumption" in smoke
    assert "final_request_pending" in smoke
    assert "requested_fixture_source_url" in smoke
    assert "fixture_source_url" in smoke
    assert "certified_for_input = 1" in smoke
    assert "bounded_scanned_gcd_certified = 1" in smoke
    assert "IrollImGui_LoadKernelBackendStatuses" in smoke
    assert "IROLL_INVARIANT_RESULT_HANDLES_STATUS_METADATA_ONLY" in smoke
    assert "invariant_result_handles_status_code" in smoke
    assert "invariant_result_handles_homfly_report_json_available = 0" in smoke
    assert "invariant_result_handles_alexander_report_json_available = 0" in smoke
    assert "invariant_result_handles_native_computation_claimed = 0" in smoke
    assert "invariant_result_handles_python_file_recompute_boundary = 1" in smoke
    assert "invariant_result_handles_native_result_handles_complete = 0" in smoke
    assert "invariant_result_handles_complete_result_handle_abi = 0" in smoke
    assert "invariant_result_handles_release_grade_result_handles = 0" in smoke
    assert "invariant_result_handles_metadata_schema_version = 1" in smoke
    assert "invariant_result_handles_required_metadata_field_count = 30" in smoke
    assert "invariant_result_handles_required_metadata_fields_present = 1" in smoke
    assert (
        "invariant_result_handles_metadata_contract_version_length ="
        in smoke
    )
    assert "invariant_result_handles_readiness_provenance_present = 1" in smoke
    assert "invariant_result_handles_ready_for_native_result_handles = 0" in smoke
    assert "invariant_result_handles_readiness_blocked_by_required_gates" in smoke
    assert "invariant_result_handles_readiness_provenance_note_length" in smoke
    assert "owned_string_contract_schema_version = 1" in smoke
    assert "owned_string_contract_abi_version = 19" in smoke
    assert "owned_string_contract_version_length =" in smoke
    assert "owned_string_contract_free_required = 1" in smoke
    assert "owned_string_contract_free_accepts_zero_initialized = 1" in smoke
    assert "owned_string_contract_borrowed_across_calls = 0" in smoke
    assert "loaded_legacy_backend" in smoke
    assert "loaded_legacy_backend.invariant_result_handles_metadata_schema_version != 0" in smoke
    assert (
        "loaded_legacy_backend.invariant_result_handles_required_metadata_field_count != 0"
        in smoke
    )
    assert (
        "loaded_legacy_backend.invariant_result_handles_required_metadata_fields_present !="
        in smoke
    )
    assert "loaded_legacy_backend.invariant_result_handles_native_result_handles_complete != 0" in smoke
    assert "loaded_legacy_backend.invariant_result_handles_complete_result_handle_abi != 0" in smoke
    assert "loaded_legacy_backend.invariant_result_handles_release_grade_result_handles != 0" in smoke
    assert (
        "loaded_legacy_backend.invariant_result_handles_metadata_contract_version_length !="
        in smoke
    )
    assert "loaded_legacy_backend.owned_string_contract_schema_version != 0" in smoke
    assert "loaded_legacy_backend.owned_string_contract_abi_version != 0" in smoke
    assert "loaded_legacy_backend.owned_string_contract_version_length != 0" in smoke
    assert "loaded_legacy_backend.owned_string_contract_free_required != 0" in smoke
    assert (
        "loaded_legacy_backend.owned_string_contract_free_accepts_zero_initialized !="
        in smoke
    )
    assert (
        "loaded_legacy_backend.owned_string_contract_borrowed_across_calls !="
        in smoke
    )
    assert "backend_rust_notes" in smoke
    for backend_note in [
        "native_invariant_compute_handles_status: status=unsupported",
        "metadata_schema_version=1",
        "metadata_contract_version=rust_c_abi_19_invariant_result_handles_lifecycle_metadata_v1",
        "required_metadata_field_count=30",
        "required_metadata_fields_present=true",
        "status_code=native_invariant_compute_handles_unavailable",
        "host_action=use_python_file_recompute_boundary",
        "homfly_native_compute_handle_available=false",
        "alexander_native_compute_handle_available=false",
        "native_result_handle_boundary=false",
    ]:
        assert backend_note in smoke
    assert "kernel_backend_invariant_result_handles_metadata_only_count != 1" in smoke
    assert (
        "kernel_backend_invariant_result_handles_metadata_only_count = 0" in source
    )
    assert (
        "kernel_backend_invariant_result_handles_metadata_schema_v1_count = 0"
        in source
    )
    assert (
        "kernel_backend_invariant_result_handles_native_result_handles_complete_count = 0"
        in source
    )
    assert (
        "kernel_backend_invariant_result_handles_complete_result_handle_abi_count = 0"
        in source
    )
    assert (
        "kernel_backend_invariant_result_handles_release_grade_result_handles_count = 0"
        in source
    )
    assert (
        "kernel_backend_invariant_result_handles_required_metadata_field_count_30_count ="
        in source
    )
    assert (
        "kernel_backend_invariant_result_handles_required_metadata_fields_present_count ="
        in source
    )
    assert (
        "kernel_backend_invariant_result_handles_metadata_contract_version_length_max ="
        in source
    )
    assert "kernel_backend_owned_string_contract_schema_v1_count = 0" in source
    assert (
        "kernel_backend_owned_string_contract_abi_version_19_count = 0"
        in source
    )
    assert (
        "kernel_backend_owned_string_contract_free_required_count = 0"
        in source
    )
    assert (
        "kernel_backend_owned_string_contract_free_accepts_zero_initialized_count = 0"
        in source
    )
    assert (
        "kernel_backend_owned_string_contract_borrowed_across_calls_count = 0"
        in source
    )
    assert (
        "kernel_backend_owned_string_contract_version_length_max = 0"
        in source
    )
    assert (
        "kernel_backend_invariant_result_handles_python_file_recompute_boundary_count ="
        in source
    )
    assert (
        "kernel_backend_invariant_result_handles_homfly_report_json_available_count != 0"
        in smoke
    )
    assert (
        "kernel_backend_invariant_result_handles_alexander_report_json_available_count != 0"
        in smoke
    )
    assert (
        "kernel_backend_invariant_result_handles_native_computation_claimed_count != 0"
        in smoke
    )
    assert (
        "kernel_backend_invariant_result_handles_python_file_recompute_boundary_count != 1"
        in smoke
    )
    assert "kernel_backend_invariant_result_handles_native_result_handles_complete_count != 0" in smoke
    assert "kernel_backend_invariant_result_handles_complete_result_handle_abi_count != 0" in smoke
    assert "kernel_backend_invariant_result_handles_release_grade_result_handles_count != 0" in smoke
    assert "kernel_backend_invariant_result_handles_metadata_schema_v1_count != 1" in smoke
    assert (
        "kernel_backend_invariant_result_handles_required_metadata_field_count_30_count !="
        in smoke
    )
    assert (
        "kernel_backend_invariant_result_handles_required_metadata_fields_present_count !="
        in smoke
    )
    assert (
        "kernel_backend_invariant_result_handles_metadata_contract_version_length_max !="
        in smoke
    )
    assert (
        "kernel_backend_invariant_result_handles_readiness_provenance_present_count !="
        in smoke
    )
    assert (
        "kernel_backend_invariant_result_handles_readiness_blocked_by_required_gates_count !="
        in smoke
    )
    assert (
        "kernel_backend_invariant_result_handles_readiness_provenance_note_length_max !="
        in smoke
    )
    assert "kernel_backend_owned_string_contract_schema_v1_count != 1" in smoke
    assert "kernel_backend_owned_string_contract_abi_version_19_count != 1" in smoke
    assert "kernel_backend_owned_string_contract_free_required_count != 1" in smoke
    assert (
        "kernel_backend_owned_string_contract_free_accepts_zero_initialized_count !="
        in smoke
    )
    assert "kernel_backend_owned_string_contract_borrowed_across_calls_count != 0" in smoke
    assert "kernel_backend_owned_string_contract_version_length_max !=" in smoke
    backend_aggregate_index = smoke.index(
        "kernel_backend_invariant_result_handles_metadata_only_count != 1"
    )
    backend_reset_index = smoke.index(
        "IrollImGui_LoadKernelBackendStatuses(context, nullptr, 0)"
    )
    backend_reset_smoke = smoke[backend_reset_index:]
    assert backend_aggregate_index < backend_reset_index
    assert smoke.count("IrollImGui_GetPanelStats(context, &stats)") >= 2
    assert "stats.kernel_backend_status_count != 0" in backend_reset_smoke
    for reset_guard in [
        "kernel_backend_invariant_result_handles_metadata_only_count != 0",
        "kernel_backend_invariant_result_handles_homfly_report_json_available_count != 0",
        "kernel_backend_invariant_result_handles_alexander_report_json_available_count != 0",
        "kernel_backend_invariant_result_handles_native_computation_claimed_count != 0",
        "kernel_backend_invariant_result_handles_python_file_recompute_boundary_count != 0",
        "kernel_backend_invariant_result_handles_native_result_handles_complete_count != 0",
        "kernel_backend_invariant_result_handles_complete_result_handle_abi_count != 0",
        "kernel_backend_invariant_result_handles_release_grade_result_handles_count != 0",
        "kernel_backend_invariant_result_handles_metadata_schema_v1_count != 0",
        "kernel_backend_invariant_result_handles_required_metadata_field_count_30_count !=",
        "kernel_backend_invariant_result_handles_required_metadata_fields_present_count !=",
        "kernel_backend_invariant_result_handles_metadata_contract_version_length_max !=",
        "kernel_backend_invariant_result_handles_readiness_provenance_present_count !=",
        "kernel_backend_invariant_result_handles_ready_for_native_result_handles_count !=",
        "kernel_backend_invariant_result_handles_readiness_blocked_by_required_gates_count !=",
        "kernel_backend_invariant_result_handles_readiness_provenance_note_length_max !=",
        "kernel_backend_owned_string_contract_schema_v1_count != 0",
        "kernel_backend_owned_string_contract_abi_version_19_count != 0",
        "kernel_backend_owned_string_contract_free_required_count != 0",
        "kernel_backend_owned_string_contract_free_accepts_zero_initialized_count !=",
        "kernel_backend_owned_string_contract_borrowed_across_calls_count != 0",
        "kernel_backend_owned_string_contract_version_length_max !=",
    ]:
        assert reset_guard in backend_reset_smoke
    assert "invariant result handles:" in source
    assert "invariant result-handle metadata:" in source
    assert "owned-string contract:" in source
    assert "version_length=%zu" in source
    assert "free_required=%s" in source
    assert "free_accepts_zero_initialized=%s" in source
    assert "borrowed_across_calls=%s" in source
    assert "required_fields=%zu" in source
    assert "contract_length=%zu" in source
    assert "native_computation_claimed=%s" in source
    assert "python_file_boundary=%s" in source
    for diagnostic_path_token in [
        "native_invariant_compute_handles_status",
        "status_code=%s",
        "host_action=%s",
        "homfly_native_compute_handle_available=%s",
        "alexander_native_compute_handle_available=%s",
        "native_result_handle_boundary=%s",
        "native_result_handles_complete=%s",
        "complete_result_handle_abi=%s",
        "release_grade_result_handles=%s",
        "readiness_provenance=%s",
        "readiness=%s",
        "ready_for_native_result_handles=%s",
        "readiness_blocked_by_required_gates=%s",
        "readiness_provenance_note=%s",
    ]:
        assert diagnostic_path_token in source
    assert "mock_segment_segment_distances_with_callbacks" in smoke
    assert "mock_segment_contact_records_3d_count_with_callbacks" in smoke
    assert "mock_segment_contact_records_3d_with_callbacks" in smoke
    assert "mock_segment_intersections_2d_with_callbacks" in smoke
    assert "mock_segment_intersection_records_2d_count_with_callbacks" in smoke
    assert "mock_segment_intersection_records_2d_with_callbacks" in smoke
    assert "mock_candidate_pairs_2d_count_with_callbacks" in smoke
    assert "mock_candidate_pairs_2d_with_callbacks" in smoke
    assert "mock_candidate_pairs_3d_count_with_callbacks" in smoke
    assert "mock_candidate_pairs_3d_with_callbacks" in smoke
    assert "mock_compute_writhe_with_callbacks" in smoke
    assert "mock_compute_gaussian_linking_number_with_callbacks" in smoke
    assert "mock_kernel_backend_report_json" in smoke
    assert "mock_invariant_result_handles_report_json" in smoke
    assert "api.invariant_result_handles_report_json" in smoke
    assert "api_without_invariant_handles_probe" in smoke
    assert (
        "api_without_invariant_handles_probe.invariant_result_handles_report_json = nullptr"
        in smoke
    )
    assert "kernel_result_without_probe" in smoke
    assert "invariant result-handle report bytes 0" in smoke
    assert "invariant result-handle report bytes %zu" in source
    assert "invariant_handles_report_length" in source
    assert "probe_metadata_stats" in smoke
    assert (
        "probe_metadata_stats.invariant_result_handles_metadata_schema_version != 1"
        in smoke
    )
    assert (
        "probe_metadata_stats.invariant_result_handles_required_metadata_field_count !="
        in smoke
    )
    assert (
        "probe_metadata_stats.invariant_result_handles_required_metadata_fields_present !="
        in smoke
    )
    assert "probe_metadata_stats.invariant_result_handles_native_result_handles_complete != 0" in smoke
    assert "probe_metadata_stats.invariant_result_handles_complete_result_handle_abi != 0" in smoke
    assert "probe_metadata_stats.invariant_result_handles_release_grade_result_handles != 0" in smoke
    assert (
        "probe_metadata_stats.invariant_result_handles_metadata_contract_version_length !="
        in smoke
    )
    assert "probe_metadata_stats.owned_string_contract_schema_version != 1" in smoke
    assert "probe_metadata_stats.owned_string_contract_abi_version != 19" in smoke
    assert "probe_metadata_stats.owned_string_contract_version_length !=" in smoke
    assert "probe_metadata_stats.owned_string_contract_free_required != 1" in smoke
    assert (
        "probe_metadata_stats.owned_string_contract_free_accepts_zero_initialized != 1"
        in smoke
    )
    assert "probe_metadata_stats.owned_string_contract_borrowed_across_calls != 0" in smoke
    assert "missing_probe_metadata_stats" in smoke
    assert (
        "missing_probe_metadata_stats.invariant_result_handles_metadata_schema_version !="
        in smoke
    )
    assert (
        "invariant_result_handles_required_metadata_field_count != 0"
        in smoke
    )
    assert (
        "invariant_result_handles_required_metadata_fields_present != 0"
        in smoke
    )
    assert "invariant_result_handles_native_result_handles_complete != 0" in smoke
    assert "invariant_result_handles_complete_result_handle_abi != 0" in smoke
    assert "invariant_result_handles_release_grade_result_handles != 0" in smoke
    assert (
        "invariant_result_handles_metadata_contract_version_length != 0"
        in smoke
    )
    assert "\\\"metadata_schema_version\\\":1" in smoke
    assert "\\\"owned_string_contract\\\":{\\\"schema_version\\\":1" in smoke
    assert (
        "\\\"contract_version\\\":\\\"rust_owned_string_v1\\\""
        in smoke
    )
    assert "\\\"abi_version\\\":19" in smoke
    assert "\\\"free_required\\\":true" in smoke
    assert "\\\"free_accepts_zero_initialized\\\":true" in smoke
    assert "\\\"borrowed_across_calls\\\":false" in smoke
    assert (
        "\\\"metadata_contract_version\\\":"
        "\\\"rust_c_abi_19_invariant_result_handles_lifecycle_metadata_v1\\\""
        in smoke
    )
    assert "\\\"required_metadata_fields\\\":[" in smoke
    assert "\\\"required_metadata_field_count\\\":30" in smoke
    assert "\\\"required_metadata_fields_present\\\":true" in smoke
    assert "\\\"status\\\":\\\"metadata_only\\\"" in smoke
    assert "\\\"homfly_report_json\\\":false" in smoke
    assert "\\\"alexander_report_json\\\":false" in smoke
    assert "\\\"native_computation_claimed\\\":false" in smoke
    assert "\\\"native_invariant_result_handles_complete\\\":false" in smoke
    assert "\\\"complete_result_handle_abi\\\":false" in smoke
    assert "\\\"release_grade_result_handles\\\":false" in smoke
    assert "\\\"native_invariant_compute_handles_status\\\"" in smoke
    assert (
        "\\\"status_code\\\":\\\"native_invariant_compute_handles_unavailable\\\""
        in smoke
    )
    assert "\\\"host_action\\\":\\\"use_python_file_recompute_boundary\\\"" in smoke
    assert "\\\"per_invariant\\\"" in smoke
    assert "\\\"status_code\\\":\\\"homfly_native_compute_handle_missing\\\"" in smoke
    assert "\\\"status_code\\\":\\\"alexander_native_compute_handle_missing\\\"" in smoke
    assert "\\\"native_compute_handle_available\\\":false" in smoke
    assert "\\\"python_file_recompute_boundary\\\":true" in smoke
    assert "\\\"native_result_handle_boundary\\\":false" in smoke
    for kernel_result_token in [
        "kernel_result_with_probe",
        "owned string contract schema_version=1",
        "abi_version=19",
        "contract_version=rust_owned_string_v1",
        "free_required=true",
        "free_accepts_zero_initialized=true",
        "borrowed_across_calls=false",
        "invariant compute handles status unsupported",
        "status_code=native_invariant_compute_handles_unavailable",
        "host_action=use_python_file_recompute_boundary",
        "homfly_native_compute_handle_available=false",
        "alexander_native_compute_handle_available=false",
        "native_result_handle_boundary=false",
        "native_result_handles_complete=false",
        "complete_result_handle_abi=false",
        "release_grade_result_handles=false",
        "metadata_schema_version=1",
        "metadata_contract_version=rust_c_abi_19_invariant_result_handles_lifecycle_metadata_v1",
        "required_metadata_field_count=30",
        "required_metadata_fields_present=true",
    ]:
        assert kernel_result_token in smoke
    assert "\\\"file_recompute_boundary\\\"" in smoke
    assert "\\\"homfly_cli_command\\\":\\\"iroll homfly-pd\\\"" in smoke
    assert (
        "\\\"alexander_cli_command\\\":\\\"iroll multivariable-alexander-pd\\\""
        in smoke
    )
    assert (
        "\\\"host_reload_payload\\\":\\\"imgui-signed-pd-invariant-status-payload\\\""
        in smoke
    )
    assert "mock_segment_segment_distance_report_json" in smoke
    assert "mock_gaussian_linking_report_json" in smoke
    assert "mock_writhe_report_json" in smoke
    assert "mock_segment_contact_records_3d_report_json" in smoke
    assert "mock_segment_intersection_records_2d_report_json" in smoke
    assert "mock_segment_intersections_2d_report_json" in smoke
    assert "mock_segment_bbox_candidate_pairs_2d_report_json" in smoke
    assert "mock_segment_bbox_candidate_pairs_3d_report_json" in smoke
    assert "mock_kernel_owned_string_free" in smoke
    assert "IrollImGui_RequestKernelBackend" in smoke
    assert "IrollImGui_GetRequestedKernelBackend" in smoke
    assert "IrollImGui_SetKernelProgress" in smoke
    assert "IrollImGui_RequestKernelCancel" in smoke
    assert "IrollImGui_GetKernelCancelRequested" in smoke
    assert "IrollPanelStats stats" in smoke
    assert "IrollImGui_GetPanelStats" in smoke
    assert "analysis_summary_count" in smoke
    assert "stats.fixture_visible_comparison_count != 1" in smoke
    assert "stats.fixture_skipped_comparison_count != 1" in smoke
    assert "stats.fixture_visible_source_url_count != 1" in smoke
    assert "stats.analysis_summary_count != 6" in smoke
    assert "stats.analysis_required_check_count != 111" in smoke
    assert "stats.analysis_passed_check_count != 85" in smoke
    assert "stats.analysis_failed_check_count != 26" in smoke
    assert "source-table invariant audit" in smoke
    assert "top_unique_sign_patterns=0" in smoke
    assert "max_matched_candidates=2" in smoke
    assert "max_matched_unique_sign_patterns=1" in smoke
    assert "analysis_required_check_count" in smoke
    assert "analysis_certification_applicable_count" in smoke
    assert "analysis_certification_certified_count" in smoke
    assert "stats.analysis_certification_applicable_count != 85" in smoke
    assert "stats.analysis_certification_certified_count != 66" in smoke
    assert "stats.analysis_certification_uncertified_count != 19" in smoke
    assert "analysis_input_certification_recursion_node_count" in smoke
    assert "analysis_input_certification_iterative_attempt_count" in smoke
    assert "analysis_input_certification_iterative_solved_count" in smoke
    assert "analysis_input_certification_iterative_max_solved_depth" in smoke
    assert "stats.analysis_input_certification_iterative_attempt_count != 141" in smoke
    assert "stats.analysis_input_certification_iterative_solved_count != 35" in smoke
    assert "stats.analysis_input_certification_iterative_max_solved_depth != 7" in smoke
    assert "analysis_input_certification_terminal_contribution_matched_count" in smoke
    assert "analysis_bounded_scanned_gcd_checked_nonzero_minor_count" in smoke
    assert "stats.analysis_bounded_scanned_gcd_checked_nonzero_minor_count != 287" in smoke
    assert "analysis_bounded_scanned_gcd_nonzero_minor_coverage_complete_count" in smoke
    assert "stats.analysis_bounded_scanned_gcd_nonzero_minor_coverage_complete_count != 30" in smoke
    assert "analysis_bounded_scanned_gcd_quotient_gcd_certified_count" in smoke
    assert "stats.analysis_bounded_scanned_gcd_quotient_gcd_certified_count != 34" in smoke
    assert "analysis_bounded_scanned_gcd_complete_certified_count" in smoke
    assert "stats.analysis_bounded_scanned_gcd_complete_certified_count != 30" in smoke
    assert "analysis_bounded_scanned_gcd_improved_candidate_count" in smoke
    assert "stats.analysis_bounded_scanned_gcd_improved_candidate_count != 2" in smoke
    assert "analysis_bounded_scanned_gcd_expected_minor_combination_count" in smoke
    assert (
        "stats.analysis_bounded_scanned_gcd_expected_minor_combination_count != 336"
        in smoke
    )
    assert "analysis_bounded_scanned_gcd_nonzero_minor_count" in smoke
    assert "stats.analysis_bounded_scanned_gcd_nonzero_minor_count != 287" in smoke
    assert "analysis_bounded_scanned_gcd_zero_minor_count" in smoke
    assert "stats.analysis_bounded_scanned_gcd_zero_minor_count != 49" in smoke
    assert "analysis_bounded_scanned_gcd_unit_minor_count" in smoke
    assert "stats.analysis_bounded_scanned_gcd_unit_minor_count != 3" in smoke
    assert "analysis_bounded_scanned_gcd_unique_nonzero_polynomial_count" in smoke
    assert (
        "stats.analysis_bounded_scanned_gcd_unique_nonzero_polynomial_count != 21"
        in smoke
    )
    assert "analysis_bounded_scanned_gcd_all_rows_have_nonzero_minor_count" in smoke
    assert (
        "stats.analysis_bounded_scanned_gcd_all_rows_have_nonzero_minor_count != 30"
        in smoke
    )
    assert "analysis_bounded_scanned_gcd_all_columns_have_nonzero_minor_count" in smoke
    assert (
        "stats.analysis_bounded_scanned_gcd_all_columns_have_nonzero_minor_count != 30"
        in smoke
    )
    assert "analysis_registered_knot_admissible_normalization_applicable_count" in smoke
    assert "analysis_registered_knot_admissible_normalization_certified_count" in smoke
    assert "registered knot normalization" in source
    assert "admissible-minor normalization:" in source
    assert "analysis_admissible_minor_normalization_checked_nonzero_minor_count" in smoke
    assert (
        "stats.analysis_admissible_minor_normalization_checked_nonzero_minor_count != 2"
        in smoke
    )
    assert (
        "stats.analysis_admissible_minor_normalization_bounded_certified_count != 1"
        in smoke
    )
    assert (
        "stats.analysis_admissible_minor_normalization_class_count != 1"
        in smoke
    )
    assert (
        "stats.analysis_admissible_minor_normalization_largest_class_minor_count != 2"
        in smoke
    )
    assert "source_table_alexander_numerator_checked_count = 1" in smoke
    assert "source_table_alexander_numerator_source_seen_count = 1" in smoke
    assert "source_table_alexander_numerator_incomplete_or_unstable_count = 1" in smoke
    assert "source_table_alexander_numerator_candidate_unique_value_count = 2" in smoke
    assert "source_table_alexander_numerator_computed_candidate_count = 16" in smoke
    assert "source_table_alexander_numerator_skipped_candidate_count = 8" in smoke
    assert "source_table_alexander_numerator_missing_candidate_count = 8" in smoke
    assert "source_table_alexander_skipped_common_gcd_attempt_candidate_count = 8" in smoke
    assert (
        "source_table_alexander_skipped_common_gcd_attempt_"
        "not_certified_candidate_count = 8"
        in smoke
    )
    assert "source_table_alexander_skipped_common_gcd_attempt_method_count = 8" in smoke
    assert (
        "source_table_alexander_skipped_common_gcd_attempt_limit_variant_count = 1"
        in smoke
    )
    assert (
        "source_table_alexander_skipped_common_gcd_attempt_"
        "direct_divisor_attempt_evidence_count = 8"
        in smoke
    )
    assert (
        "source_table_alexander_skipped_common_gcd_attempt_"
        "direct_divisor_candidate_count_min = 10"
        in smoke
    )
    assert (
        "source_table_alexander_skipped_common_gcd_attempt_"
        "direct_divisor_failed_candidate_count_max = 10"
        in smoke
    )
    assert (
        "source_table_alexander_skipped_common_gcd_attempt_"
        "direct_divisor_all_candidates_failed_count = 1"
        in smoke
    )
    assert (
        "source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_evidence_count = 8"
        in smoke
    )
    assert (
        "source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_variant_count = 1"
        in smoke
    )
    assert (
        "source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_input_count_min = 25"
        in smoke
    )
    assert (
        "source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_input_count_max = 25"
        in smoke
    )
    assert (
        "source_table_alexander_source_divisibility_checked_candidate_count = 8"
        in smoke
    )
    assert (
        "source_table_alexander_source_divisibility_source_division_failed_candidate_count = 8"
        in smoke
    )
    assert (
        "source_table_alexander_source_divisibility_"
        "failed_candidate_witness_count = 5"
        in smoke
    )
    assert (
        "source_table_alexander_source_divisibility_"
        "failed_candidate_witness_truncated = 1"
        in smoke
    )
    assert "analysis_source_table_alexander_numerator_checked_count" in smoke
    assert "analysis_source_table_alexander_numerator_checked_count != 1" in smoke
    assert "analysis_source_table_alexander_numerator_source_seen_count != 1" in smoke
    assert (
        "analysis_source_table_alexander_numerator_incomplete_or_unstable_count != 1"
        in smoke
    )
    assert (
        "analysis_source_table_alexander_numerator_candidate_unique_value_count != 2"
        in smoke
    )
    assert "analysis_source_table_alexander_numerator_computed_candidate_count != 16" in smoke
    assert "analysis_source_table_alexander_numerator_skipped_candidate_count != 8" in smoke
    assert "analysis_source_table_alexander_numerator_missing_candidate_count != 8" in smoke
    assert (
        "analysis_source_table_alexander_skipped_common_gcd_attempt_candidate_count != 8"
        in smoke
    )
    assert (
        "analysis_source_table_alexander_skipped_common_gcd_attempt_method_count != 8"
        in smoke
    )
    assert (
        "analysis_source_table_alexander_skipped_common_gcd_attempt_limit_variant_count != 1"
        in smoke
    )
    assert (
        "analysis_source_table_alexander_skipped_common_gcd_attempt_"
        "direct_divisor_attempt_evidence_count != 8"
        in smoke
    )
    assert (
        "analysis_source_table_alexander_skipped_common_gcd_attempt_"
        "direct_divisor_failed_candidate_count_max != 10"
        in smoke
    )
    assert (
        "analysis_source_table_alexander_skipped_common_gcd_attempt_"
        "direct_divisor_all_candidates_failed_count != 1"
        in smoke
    )
    assert (
        "analysis_source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_evidence_count != 8"
        in smoke
    )
    assert (
        "analysis_source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_variant_count != 1"
        in smoke
    )
    assert (
        "analysis_source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_input_count_min != 25"
        in smoke
    )
    assert (
        "analysis_source_table_alexander_skipped_common_gcd_attempt_"
        "support_signature_input_count_max != 25"
        in smoke
    )
    assert (
        "analysis_source_table_alexander_source_divisibility_checked_candidate_count != 8"
        in smoke
    )
    assert (
        "analysis_source_table_alexander_source_divisibility_status_variant_count != 1"
        in smoke
    )
    assert (
        "analysis_source_table_alexander_source_divisibility_"
        "failed_candidate_witness_count != 5"
        in smoke
    )
    assert (
        "analysis_source_table_alexander_source_divisibility_"
        "failed_candidate_witness_truncated != 1"
        in smoke
    )
    assert "source-table Alexander numerator:" in source
    assert "source-table Alexander skipped common-gcd attempts:" in source
    assert "source-table Alexander skipped common-gcd attempt status:" in source
    assert "source-table Alexander direct-divisor attempts:" in source
    assert "source-table Alexander direct-divisor status:" in source
    assert "source-table Alexander support signatures:" in source
    assert "source-table Alexander support-signature status:" in source
    assert "source-table Alexander source divisibility:" in source
    assert "source-table Alexander source-divisibility status:" in source
    assert "analysis_wirtinger_fox_relation_count" in smoke
    assert "stats.analysis_wirtinger_fox_scanned_minor_count != 290" in smoke
    assert "stats.analysis_wirtinger_fox_invalid_normalization_count != 0" in smoke
    assert "stats.analysis_wirtinger_fox_complete_scan_count != 31" in smoke
    assert "generated_case_count = 30" in smoke
    assert "generated_frontier_case_count = 4" in smoke
    assert "generated_source_notation_count = 3" in smoke
    assert "generated_unique_oriented_diagram_count = 20" in smoke
    assert "generated_unique_evaluation_count = 20" in smoke
    assert "generated_reused_evaluation_count = 10" in smoke
    assert "generated_source_summary_consistency_matched = 1" in smoke
    assert "generated_source_summary_count_totals_matched = 1" in smoke
    assert "generated_source_summary_distribution_totals_matched = 1" in smoke
    assert "generated_source_summary_frontier_reason_counts_matched = 1" in smoke
    assert (
        "generated_source_summary_source_notation_count_matches_fixture_count = 1"
        in smoke
    )
    assert "inconsistent_summary.generated_source_summary_consistency_matched = 0" in smoke
    assert (
        "inconsistent_summary.generated_source_summary_count_totals_matched = 0"
        in smoke
    )
    assert (
        "inconsistent_summary.generated_source_summary_distribution_totals_matched = 0"
        in smoke
    )
    assert (
        "inconsistent_summary.generated_source_summary_frontier_reason_counts_matched = 0"
        in smoke
    )
    assert (
        "inconsistent_summary.generated_source_summary_source_notation_count_matches_fixture_count = 0"
        in smoke
    )
    assert "analysis_generated_case_count" in smoke
    assert "analysis_generated_case_count != 60" in smoke
    assert "analysis_generated_frontier_case_count" in smoke
    assert "analysis_generated_frontier_case_count != 4" in smoke
    assert "analysis_generated_source_notation_count != 6" in smoke
    assert "analysis_generated_unique_oriented_diagram_count != 40" in smoke
    assert "analysis_generated_max_branch_depth != 1" in smoke
    assert "analysis_generated_unique_evaluation_count != 40" in smoke
    assert "analysis_generated_reused_evaluation_count != 20" in smoke
    assert "analysis_generated_source_summary_consistency_matched != 1" in smoke
    assert "analysis_generated_source_summary_count_totals_matched != 1" in smoke
    assert (
        "analysis_generated_source_summary_distribution_totals_matched != 1"
        in smoke
    )
    assert (
        "analysis_generated_source_summary_frontier_reason_counts_matched != 1"
        in smoke
    )
    assert (
        "analysis_generated_source_summary_source_notation_count_matches_fixture_count !="
        in smoke
    )
    assert (
        "inconsistent_analysis_stats"
        "\n                .analysis_generated_source_summary_consistency_matched != 0"
        in smoke
    )
    assert (
        "analysis_generated_source_summary_source_notation_count_matches_fixture_count ="
        in source
    )
    assert "generated coverage:" in source
    assert "generated source summary consistency:" in source
    assert "source_notations_match_fixture=%s" in source
    assert "frontier_cases=%zu" in source
    assert "unique_evaluations=%zu" in source
    assert "reused_evaluations=%zu" in source
    assert "resolution_code=%d" in source
    assert "signed-PD role-order candidates" in smoke
    assert "role_order_signature_strict_candidate_count = 16" in smoke
    assert "role_order_signature_resolution_status_code" in smoke
    assert "IROLL_ROLE_ORDER_SIGNATURE_RESOLUTION_PARTIALLY_DISTINGUISHES" in smoke
    assert "role_order_signature_evaluated_candidate_count = 2" in smoke
    assert "analysis_role_order_signature_strict_candidate_count" in smoke
    assert "analysis_role_order_signature_strict_candidate_count != 16" in smoke
    assert "analysis_role_order_signature_all_strict_candidates_evaluated_count" in smoke
    assert "analysis_role_order_signature_all_strict_candidates_evaluated_count != 0" in smoke
    assert "analysis_role_order_signature_evaluated_candidate_count" in smoke
    assert "analysis_role_order_signature_evaluated_candidate_count != 2" in smoke
    assert (
        "analysis_role_order_signature_alexander_complete_scanned_gcd_certified_candidate_count"
        in smoke
    )
    assert (
        "analysis_role_order_signature_alexander_complete_scanned_gcd_certified_candidate_count !="
        in smoke
    )
    assert "source_table_audit_comparison_count = 3" in smoke
    assert "analysis_source_table_audit_comparison_count" in smoke
    assert "analysis_source_table_audit_comparison_count != 3" in smoke
    assert "source_table_audit_unique_sign_pattern_count = 6" in smoke
    assert "source_table_audit_max_matched_candidate_total_count = 2" in smoke
    assert "source_table_audit_homfly_candidate_unique_value_count = 6" in smoke
    assert "source_table_audit_homfly_candidate_unit_normalized_value_count = 6" in smoke
    assert "source_table_audit_homfly_variant_miss_witness_count = 6" in smoke
    assert "source_table_audit_homfly_variant_miss_witness_limit = 8" in smoke
    assert "source_table_audit_homfly_variant_miss_witness_truncated = 1" in smoke
    assert "source_table_audit_candidate_convergence_uncertified_invariant_count = 3" in smoke
    assert "source_table_audit_candidate_convergence_source_value_seen_count" in smoke
    assert "source_table_audit_candidate_convergence_source_value_seen_but_uncertified_count" in smoke
    assert "source-table convergence status:" in source
    assert "source_table_audit_registration_blocked_count = 1" in smoke
    assert "source_table_audit_registration_blocker_code_count = 5" in smoke
    assert "source_table_audit_registration_summary_consistency_available_count = 1" in smoke
    assert "source_table_audit_registration_summary_consistency_matched_count = 0" in smoke
    assert "source_table_audit_registration_summary_consistency_mismatch_count = 2" in smoke
    assert "source_table_audit_registration_blocker_count = 6" in smoke
    assert "source_table_summary.certification_blocker_count = 4" in smoke
    assert "source_table_summary.homfly_completion_blocker_count = 5" in smoke
    assert (
        "source_table_summary.admissible_minor_normalization_blocker_count = 2"
        in smoke
    )
    assert (
        "source_table_summary.admissible_minor_normalization_blocker_reason_count = 6"
        in smoke
    )
    assert (
        "source_table_summary\n        "
        ".admissible_minor_normalization_blocker_witness_available_count = 4"
        in smoke
    )
    assert (
        "source_table_summary\n        "
        ".admissible_minor_normalization_blocker_witness_source_count = 8"
        in smoke
    )
    assert (
        "source_table_summary\n        "
        ".admissible_minor_normalization_blocker_witness_source_available_count = 5"
        in smoke
    )
    assert (
        "source_table_summary\n        "
        ".admissible_minor_normalization_blocker_witness_source_missing_count = 3"
        in smoke
    )
    assert (
        "source_table_summary\n        "
        ".admissible_minor_normalization_blocker_missing_witness_reason_count = 2"
        in smoke
    )
    assert "source_table_summary.full_alexander_completion_blocker_count = 3" in smoke
    assert "source_table_summary.certification_blocker_detail_count = 4" in smoke
    assert (
        "source_table_summary.homfly_completion_blocker_detail_count = 5"
        in smoke
    )
    assert "source_table_summary.failed_division_witness_count = 7" in smoke
    assert "source_table_summary.quotient_gcd_uncertainty_present = 1" in smoke
    assert "source_table_summary.quotient_polynomial_witness_count = 3" in smoke
    assert "source_table_summary.quotient_polynomial_witness_truncated = 1" in smoke
    assert "source_table_summary.admissible_minor_normalization_gate_count = 5" in smoke
    assert (
        "source_table_summary\n        "
        ".admissible_minor_normalization_gate_summary_consistent = 1"
        in smoke
    )
    assert (
        "source_table_summary\n        "
        ".admissible_minor_normalization_failed_gate_blocker_count = 2"
        in smoke
    )
    assert "homfly_generated_summary.frontier_witness_summary_count = 6" in smoke
    assert "homfly_generated_summary.frontier_witness_summary_reason_count = 2" in smoke
    assert "homfly_generated_summary.frontier_witness_summary_truncated = 1" in smoke
    assert "homfly_generated_summary.frontier_witness_summary_min_depth = 4" in smoke
    assert "homfly_generated_summary.frontier_witness_summary_max_depth = 6" in smoke
    assert (
        "homfly_generated_summary.frontier_witness_summary_min_branch_depth = 1"
        in smoke
    )
    assert (
        "homfly_generated_summary.frontier_witness_summary_max_branch_depth = 3"
        in smoke
    )
    assert (
        "homfly_generated_summary.frontier_witness_summary_recursive_path_prefix_count = 3"
        in smoke
    )
    assert (
        "homfly_generated_summary.frontier_witness_summary_source_kind_count = 2"
        in smoke
    )
    assert "homfly_generated_summary.frontier_witness_summary_branch_count = 5" in smoke
    assert (
        "homfly_generated_summary\n        "
        ".frontier_witness_summary_pressure_total_frontier_count = 9"
        in smoke
    )
    assert (
        "homfly_generated_summary\n        "
        ".frontier_witness_summary_pressure_visible_witness_count = 7"
        in smoke
    )
    assert (
        "homfly_generated_summary\n        "
        ".frontier_witness_summary_pressure_missing_frontier_count = 2"
        in smoke
    )
    assert "homfly_generated_summary.frontier_witness_summary_pressure_reason_count =" in smoke
    assert "source_table_summary.normalization_class_witness_count = 2" in smoke
    assert "loaded_analysis_summary.quotient_polynomial_witness_count != 0" in smoke
    assert "loaded_analysis_summary.quotient_polynomial_witness_truncated != 0" in smoke
    assert "loaded_analysis_summary.frontier_witness_summary_count != 0" in smoke
    assert "loaded_analysis_summary.frontier_witness_summary_count != 6" in smoke
    assert "loaded_analysis_summary.frontier_witness_summary_max_branch_depth != 3" in smoke
    assert (
        "loaded_analysis_summary\n                "
        ".frontier_witness_summary_recursive_path_prefix_count != 3"
        in smoke
    )
    assert (
        "loaded_analysis_summary\n                "
        ".source_table_alexander_source_divisibility_"
        "failed_candidate_witness_count !=\n            0"
        in smoke
    )
    assert "loaded_analysis_summary.certification_blocker_count != 4" in smoke
    assert "loaded_analysis_summary.homfly_completion_blocker_count != 5" in smoke
    assert (
        "loaded_analysis_summary.admissible_minor_normalization_blocker_count != 2"
        in smoke
    )
    assert (
        "loaded_analysis_summary\n                "
        ".admissible_minor_normalization_blocker_reason_count != 6"
        in smoke
    )
    assert (
        "loaded_analysis_summary\n                "
        ".admissible_minor_normalization_blocker_witness_available_count !=\n"
        "            4"
        in smoke
    )
    assert (
        "loaded_analysis_summary\n                "
        ".admissible_minor_normalization_blocker_witness_source_count != 8"
        in smoke
    )
    assert (
        "loaded_analysis_summary\n                "
        ".admissible_minor_normalization_blocker_witness_source_available_count != 5"
        in smoke
    )
    assert (
        "loaded_analysis_summary\n                "
        ".admissible_minor_normalization_blocker_witness_source_missing_count != 3"
        in smoke
    )
    assert (
        "loaded_analysis_summary\n                "
        ".admissible_minor_normalization_blocker_missing_witness_reason_count !=\n"
        "            2"
        in smoke
    )
    assert "loaded_analysis_summary.full_alexander_completion_blocker_count != 3" in smoke
    assert "loaded_analysis_summary.certification_blocker_detail_count != 4" in smoke
    assert (
        "loaded_analysis_summary.homfly_completion_blocker_detail_count != 5"
        in smoke
    )
    assert "loaded_analysis_summary.failed_division_witness_count != 7" in smoke
    assert "loaded_analysis_summary.quotient_gcd_uncertainty_present != 1" in smoke
    assert "loaded_analysis_summary.quotient_polynomial_witness_count != 3" in smoke
    assert "loaded_analysis_summary.quotient_polynomial_witness_truncated != 1" in smoke
    assert (
        "loaded_analysis_summary.source_table_audit_homfly_variant_miss_witness_count != 6"
        in smoke
    )
    assert (
        "loaded_analysis_summary.source_table_audit_homfly_variant_miss_witness_limit != 8"
        in smoke
    )
    assert (
        "loaded_analysis_summary.source_table_audit_homfly_variant_miss_witness_truncated != 1"
        in smoke
    )
    assert (
        "loaded_analysis_summary"
        "\n                "
        ".source_table_audit_registration_summary_consistency_available_count !="
        in smoke
    )
    assert (
        "loaded_analysis_summary"
        "\n                "
        ".source_table_audit_registration_summary_consistency_matched_count !="
        in smoke
    )
    assert (
        "loaded_analysis_summary"
        "\n                "
        ".source_table_audit_registration_summary_consistency_mismatch_count !="
        in smoke
    )
    assert (
        "loaded_analysis_summary"
        "\n                "
        ".final_completion_blocker_completion_evidence_artifact_filename_reference_count !="
        in smoke
    )
    assert (
        "loaded_analysis_summary"
        "\n                "
        ".final_completion_failed_gate_completion_evidence_artifact_filename_unique_count !="
        in smoke
    )
    assert "loaded_analysis_summary.normalization_class_witness_count != 2" in smoke
    assert "loaded_analysis_summary.admissible_minor_normalization_gate_count !=" in smoke
    assert (
        "loaded_analysis_summary\n                "
        ".admissible_minor_normalization_failed_gate_blocker_count != 2"
        in smoke
    )
    assert "source_table_audit_homfly_variant_resolution_status_code" in smoke
    assert "IROLL_SOURCE_TABLE_HOMFLY_VARIANT_RESOLUTION_SOURCE_VARIANTS_MISSED" in smoke
    assert "analysis_source_table_audit_unique_sign_pattern_count" in smoke
    assert "analysis_source_table_audit_unique_sign_pattern_count != 6" in smoke
    assert "analysis_source_table_audit_max_matched_candidate_total_count" in smoke
    assert "analysis_source_table_audit_max_matched_candidate_total_count != 2" in smoke
    assert "analysis_source_table_audit_homfly_source_variant_miss_count" in smoke
    assert "analysis_source_table_audit_homfly_source_variant_miss_count != 8" in smoke
    assert "analysis_source_table_audit_homfly_candidate_unique_value_count != 6" in smoke
    assert "analysis_source_table_audit_homfly_candidate_unit_normalized_value_count != 6" in smoke
    assert "analysis_source_table_audit_homfly_variant_miss_witness_count != 6" in smoke
    assert "analysis_source_table_audit_homfly_variant_miss_witness_limit != 8" in smoke
    assert "analysis_source_table_audit_homfly_variant_miss_witness_truncated != 1" in smoke
    assert (
        "analysis_source_table_audit_homfly_variant_resolution_status_code !="
        in smoke
    )
    assert (
        "analysis_source_table_audit_candidate_convergence_uncertified_invariant_count"
        in smoke
    )
    assert (
        "analysis_source_table_audit_candidate_convergence_source_value_seen_count"
        in smoke
    )
    assert (
        "analysis_source_table_audit_candidate_convergence_source_value_seen_but_uncertified_count"
        in smoke
    )
    assert "analysis_source_table_audit_registration_blocked_count != 1" in smoke
    assert "analysis_source_table_audit_registration_blocker_count != 6" in smoke
    assert "analysis_source_table_audit_registration_blocker_code_count != 5" in smoke
    assert (
        "analysis_source_table_audit_registration_summary_consistency_available_count != 1"
        in smoke
    )
    assert (
        "analysis_source_table_audit_registration_summary_consistency_matched_count != 0"
        in smoke
    )
    assert (
        "analysis_source_table_audit_registration_summary_consistency_mismatch_count != 2"
        in smoke
    )
    assert (
        "analysis_final_completion_blocker_completion_evidence_artifact_filename_reference_count != 9"
        in smoke
    )
    assert (
        "analysis_final_completion_failed_gate_completion_evidence_artifact_filename_unique_count != 6"
        in smoke
    )
    assert "analysis_certification_blocker_count != 4" in smoke
    assert "analysis_homfly_completion_blocker_count != 5" in smoke
    assert "analysis_admissible_minor_normalization_blocker_count != 2" in smoke
    assert "analysis_admissible_minor_normalization_blocker_reason_count != 6" in smoke
    assert (
        "analysis_admissible_minor_normalization_blocker_witness_source_count != 8"
        in smoke
    )
    assert (
        "analysis_admissible_minor_normalization_blocker_witness_source_available_count !="
        in smoke
    )
    assert (
        "analysis_admissible_minor_normalization_blocker_witness_source_missing_count != 3"
        in smoke
    )
    assert (
        "analysis_admissible_minor_normalization_blocker_witness_available_count != 4"
        in smoke
    )
    assert (
        "analysis_admissible_minor_normalization_blocker_missing_witness_reason_count != 2"
        in smoke
    )
    assert "analysis_full_alexander_completion_blocker_count != 3" in smoke
    assert "analysis_certification_blocker_detail_count != 4" in smoke
    assert "analysis_homfly_completion_blocker_detail_count != 5" in smoke
    assert "analysis_frontier_witness_summary_count != 6" in smoke
    assert "analysis_frontier_witness_summary_reason_count != 2" in smoke
    assert "analysis_frontier_witness_summary_truncated != 1" in smoke
    assert "analysis_frontier_witness_summary_min_depth != 4" in smoke
    assert "analysis_frontier_witness_summary_max_depth != 6" in smoke
    assert "analysis_frontier_witness_summary_min_branch_depth != 1" in smoke
    assert "analysis_frontier_witness_summary_max_branch_depth != 3" in smoke
    assert "analysis_frontier_witness_summary_recursive_path_prefix_count != 3" in smoke
    assert "analysis_frontier_witness_summary_source_kind_count != 2" in smoke
    assert "analysis_frontier_witness_summary_branch_count != 5" in smoke
    assert "analysis_frontier_witness_summary_pressure_total_frontier_count !=" in smoke
    assert "analysis_frontier_witness_summary_pressure_visible_witness_count !=" in smoke
    assert "analysis_frontier_witness_summary_pressure_missing_frontier_count !=" in smoke
    assert (
        "analysis_frontier_witness_summary_pressure_all_frontiers_have_visible_witness !="
        in smoke
    )
    assert "analysis_frontier_witness_summary_pressure_reason_count != 3" in smoke
    assert "analysis_failed_division_witness_count != 7" in smoke
    assert "analysis_quotient_gcd_uncertainty_present != 1" in smoke
    assert "analysis_quotient_polynomial_witness_count != 3" in smoke
    assert "analysis_quotient_polynomial_witness_truncated != 1" in smoke
    assert "analysis_normalization_class_witness_count != 2" in smoke
    assert "analysis_admissible_minor_normalization_gate_count != 5" in smoke
    assert "analysis_admissible_minor_normalization_gate_passed_count !=" in smoke
    assert "analysis_admissible_minor_normalization_gate_summary_consistent !=" in smoke
    assert (
        "analysis_source_table_audit_source_match_resolution_status_count != 3"
        in smoke
    )
    assert (
        "analysis_source_table_audit_source_match_resolution_statuses_length !="
        in smoke
    )
    assert (
        "analysis_source_table_audit_homfly_source_unit_normalized_variant_miss_count"
        in smoke
    )
    assert (
        "analysis_source_table_audit_homfly_source_unit_normalized_variant_miss_count != 8"
        in smoke
    )
    assert "source-table audit status:" in source
    assert (
        "homfly_values=%zu, homfly_unit_values=%zu, "
        "homfly_miss_witnesses=%zu/%zu truncated=%d, convergence_partial=%zu, "
        "convergence_full=%zu, convergence_certified=%zu, "
        "convergence_uncertified=%zu, convergence_source_seen=%zu, "
        "convergence_source_seen_uncertified=%zu, registration_ready=%zu, "
        "registration_blocked=%zu, registration_blockers=%zu, "
        "registration_blocker_codes=%zu, "
        "registration_consistency=%zu/%zu mismatches=%zu, "
        "homfly_variant_status=%d"
        in source
    )
    assert "source-table source-match statuses:" in source
    assert "maturity blockers: certification=%zu" in source
    assert "compact host triage evidence: certification_details=%zu" in source
    assert "frontier_pressure_total=%zu" in source
    assert "normalization_gates=%zu" in source
    assert "alexander_blocker_reasons=%zu" in source
    assert "alexander_blocker_witness_sources=%zu" in source
    assert "alexander_blocker_witness_source_available=%zu" in source
    assert "alexander_blocker_witness_source_missing=%zu" in source
    assert "alexander_blocker_witnesses=%zu" in source
    assert "alexander_blocker_missing_witness_reasons=%zu" in source
    assert "frontier_witnesses=%zu" in source
    assert "frontier_branch_depth=%zu..%zu" in source
    assert "quotient_gcd_uncertainty=%d" in source
    assert "quotient_polynomial_witnesses=%zu" in source
    assert "source_divisibility_failed_candidate_witnesses=%zu" in source
    assert "IrollImGui_ClearAnalysis(context);" in smoke
    assert "cleared_analysis_stats.analysis_certification_blocker_count != 0" in smoke
    assert "cleared_analysis_stats.invariant_certification_blocker_count != 0" in smoke
    assert (
        "cleared_analysis_stats\n                "
        ".analysis_admissible_minor_normalization_blocker_reason_count != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats\n                "
        ".analysis_admissible_minor_normalization_blocker_witness_source_count != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats\n                "
        ".analysis_admissible_minor_normalization_blocker_witness_source_available_count !="
        in smoke
    )
    assert (
        "cleared_analysis_stats\n                "
        ".analysis_admissible_minor_normalization_blocker_witness_source_missing_count != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats\n                "
        ".invariant_admissible_minor_normalization_blocker_reason_count != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats\n                "
        ".invariant_admissible_minor_normalization_blocker_witness_source_count != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats\n                "
        ".invariant_admissible_minor_normalization_blocker_witness_source_available_count !="
        in smoke
    )
    assert (
        "cleared_analysis_stats\n                "
        ".invariant_admissible_minor_normalization_blocker_witness_source_missing_count != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats.analysis_certification_blocker_detail_count != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats.invariant_certification_blocker_detail_count != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats.analysis_homfly_completion_blocker_detail_count != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats.analysis_frontier_witness_summary_count != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats.invariant_frontier_witness_summary_count != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats.invariant_homfly_completion_blocker_detail_count != 0"
        in smoke
    )
    assert "cleared_analysis_stats.analysis_failed_division_witness_count != 0" in smoke
    assert (
        "cleared_analysis_stats.invariant_failed_division_witness_count != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats.analysis_quotient_gcd_uncertainty_present != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats.invariant_quotient_gcd_uncertainty_present != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats.analysis_quotient_polynomial_witness_count != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats.invariant_quotient_polynomial_witness_count != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats.analysis_quotient_polynomial_witness_truncated != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats.invariant_quotient_polynomial_witness_truncated != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats\n                "
        ".analysis_source_table_alexander_source_divisibility_"
        "failed_candidate_witness_count !=\n            0"
        in smoke
    )
    assert (
        "analysis_source_table_alexander_source_divisibility_"
        "failed_candidate_witness_truncated !=\n            0"
        in smoke
    )
    assert (
        "cleared_analysis_stats\n                "
        ".invariant_source_table_alexander_source_divisibility_"
        "failed_candidate_witness_count !=\n            0"
        in smoke
    )
    assert (
        "invariant_source_table_alexander_source_divisibility_"
        "failed_candidate_witness_truncated !=\n            0"
        in smoke
    )
    assert (
        "cleared_analysis_stats.analysis_normalization_class_witness_count != 0"
        in smoke
    )
    assert (
        "cleared_analysis_stats.invariant_normalization_class_witness_count != 0"
        in smoke
    )
    assert "IrollPanelStats render_stats" in smoke
    assert "render_frame_count" in smoke
    assert "last_render_geometry_nonempty" in smoke
    assert "last_render_geometry_polyline_count" in smoke
    assert "last_render_geometry_marker_count" in smoke
    assert "IrollTestImGui_FramebufferTouched" in smoke
    assert "IrollTestImGui_EstimatedNonzeroPixelCount" in smoke
    assert "HOMFLY acceptance" in smoke
    assert "required_check_count = 3" in smoke
    for symbol in [
        "IROLL_IMGUI_KERNEL_LOADER_ABI_VERSION",
        "IrollKernelDynamicLibrary",
        "IrollKernelLoaderResult",
        "IrollKernelLoader_ApiVersion",
        "IrollKernelLoader_Open",
        "IrollKernelLoader_Close",
        "IrollKernelLoader_LoadApi",
        "IrollKernelLoader_AttachToPanel",
        "IrollKernelLoader_LastError",
    ]:
        assert symbol in loader_header
        assert symbol in loader_source

    for symbol in [
        "iroll_kernel_abi_version",
        "iroll_segment_segment_distance",
        "iroll_segment_segment_distance_report_json",
        "iroll_gaussian_linking_report_json",
        "iroll_writhe_report_json",
        "iroll_segment_contact_records_3d_report_json",
        "iroll_segment_intersection_records_2d_report_json",
        "iroll_segment_intersections_2d_report_json",
        "iroll_segment_segment_distances",
        "iroll_segment_segment_distances_with_callbacks",
        "iroll_segment_contact_records_3d_count",
        "iroll_segment_contact_records_3d_count_with_callbacks",
        "iroll_segment_contact_records_3d",
        "iroll_segment_contact_records_3d_with_callbacks",
        "iroll_segment_intersections_2d",
        "iroll_segment_intersections_2d_with_callbacks",
        "iroll_segment_intersection_records_2d_count",
        "iroll_segment_intersection_records_2d_count_with_callbacks",
        "iroll_segment_intersection_records_2d",
        "iroll_segment_intersection_records_2d_with_callbacks",
        "iroll_segment_bbox_candidate_pairs_2d_count",
        "iroll_segment_bbox_candidate_pairs_2d",
        "iroll_segment_bbox_candidate_pairs_2d_count_with_callbacks",
        "iroll_segment_bbox_candidate_pairs_2d_with_callbacks",
        "iroll_segment_bbox_candidate_pairs_3d_count",
        "iroll_segment_bbox_candidate_pairs_3d",
        "iroll_segment_bbox_candidate_pairs_3d_count_with_callbacks",
        "iroll_segment_bbox_candidate_pairs_3d_with_callbacks",
        "iroll_compute_writhe",
        "iroll_compute_writhe_with_callbacks",
        "iroll_compute_gaussian_linking_number",
        "iroll_compute_gaussian_linking_number_with_callbacks",
        "iroll_kernel_backend_report_json",
        "iroll_invariant_result_handles_report_json",
        "iroll_invariant_result_handle_create_unsupported",
        "iroll_invariant_result_handle_report_json",
        "iroll_invariant_result_handle_free",
        "iroll_kernel_owned_string_free",
        "iroll_last_error_message",
    ]:
        assert symbol in loader_source

    assert '#include "iroll_imgui_panel.h"' in loader_header
    assert "#define IROLL_IMGUI_KERNEL_LOADER_ABI_VERSION 6" in loader_header
    assert "IROLL_KERNEL_ABI_VERSION" in loader_source
    assert "LoadLibraryA" in loader_source
    assert "GetProcAddress" in loader_source
    assert "dlopen" in loader_source
    assert "dlsym" in loader_source
    assert "IrollImGui_SetKernelApi(context, &api)" in loader_source
    assert "IrollImGui_SetKernelDiagnostic" in loader_source
    assert "missing required Rust C ABI capability symbol: " in loader_source
    assert "required capability: " in loader_source
    assert '"invariant result-handle metadata probe"' in loader_source
    assert '"unsupported invariant result-handle lifecycle"' in loader_source
    assert '"unsupported invariant result-handle report"' in loader_source
    assert '"unsupported invariant result-handle free"' in loader_source
    assert (
        "loader ABI capability failure, not HOMFLY/Alexander unavailable"
        in loader_source
    )
    assert "Python" not in loader_source
    for symbol in [
        "IrollKernelLoader_Open(argv[1])",
        "IrollKernelLoader_AttachToPanel",
        "IrollImGui_RunKernelSmoke",
        "IrollImGui_GetLastKernelResult",
        "IrollImGui_GetPanelStats",
        "[output-json]",
        "output_json_path",
        "std::ofstream out",
        "\\\"artifact_kind\\\": \\\"imgui_real_kernel_loader_smoke\\\"",
        "\\\"claim_scope\\\": \\\"runtime_loader_real_rust_dynamic_library_contract\\\"",
        "\\\"kernel_loader_abi_version\\\": ",
        "\\\"dynamic_library_loaded\\\": true",
        "\\\"api_attached_to_panel\\\": true",
        "\\\"kernel_api_connected\\\": ",
        "\\\"rust_kernel_available\\\": ",
        "\\\"backend_report_bytes\\\": ",
        "\\\"invariant_result_handles_report_bytes\\\": ",
        "\\\"callback_thread_pool_completed\\\": true",
        "\\\"worker_touches_imgui_context\\\": false",
        "\\\"distance_progress_total\\\": ",
        "\\\"intersection_progress_total\\\": ",
        "\\\"distance_callback_count\\\": ",
        "\\\"intersection_callback_count\\\": ",
        "\\\"readiness_provenance_present\\\": ",
        "\\\"native_homfly_cpp_computation_claimed\\\": false",
        "\\\"native_alexander_cpp_computation_claimed\\\": false",
        "last_kernel_result_length",
        "\\\"abi_version\\\":19",
        "invariant_result_handles_report_json",
        "invariant_result_handle_create_unsupported",
        "invariant_result_handle_report_json",
        "invariant_result_handle_free",
        "IrollInvariantResultHandle* homfly_handle",
        "\\\"method\\\":\\\"invariant_result_handle_report\\\"",
        "\\\"result_handle_abi\\\":\\\"opaque_invariant_result_handle_v1\\\"",
        "\\\"report_transport_abi\\\":\\\"owned_string_v1\\\"",
        "\\\"unsupported_result_handle_lifecycle_available\\\":true",
        "\\\"handle_kind\\\":\\\"unsupported\\\"",
        "\\\"metadata_schema_version\\\":1",
        (
            "\\\"metadata_contract_version\\\":"
            "\\\"rust_c_abi_19_invariant_result_handles_lifecycle_metadata_v1\\\""
        ),
        "\\\"required_metadata_fields\\\":[",
        "\\\"required_metadata_field_count\\\":30",
        "\\\"required_metadata_fields_present\\\":true",
        "\\\"status\\\":\\\"metadata_only\\\"",
        "\\\"homfly_report_json\\\":false",
        "\\\"alexander_report_json\\\":false",
        "\\\"native_computation_claimed\\\":false",
        "\\\"native_invariant_result_handles_complete\\\":false",
        "\\\"complete_result_handle_abi\\\":false",
        "\\\"release_grade_result_handles\\\":false",
        "\\\"native_invariant_compute_handles_status\\\":{",
        "\\\"status\\\":\\\"unsupported\\\"",
        "\\\"status_code\\\":\\\"native_invariant_compute_handles_unavailable\\\"",
        "\\\"host_action\\\":\\\"use_python_file_recompute_boundary\\\"",
        "\\\"per_invariant\\\":[",
        "\\\"status_code\\\":\\\"homfly_native_compute_handle_missing\\\"",
        "\\\"status_code\\\":\\\"alexander_native_compute_handle_missing\\\"",
        "\\\"native_compute_handle_available\\\":false",
        "\\\"python_file_recompute_boundary\\\":true",
        "\\\"native_result_handle_boundary\\\":false",
        "\\\"file_recompute_boundary\\\"",
        "\\\"homfly_cli_command\\\":\\\"iroll homfly-pd\\\"",
        "\\\"alexander_cli_command\\\":\\\"iroll multivariable-alexander-pd\\\"",
        "\\\"host_reload_payload\\\":\\\"imgui-signed-pd-invariant-status-payload\\\"",
        "\\\"method\\\":\\\"segment_segment_distance_report\\\"",
        "\\\"method\\\":\\\"gaussian_linking_report\\\"",
        "\\\"method\\\":\\\"writhe_report\\\"",
        "\\\"method\\\":\\\"segment_contact_records_3d_report\\\"",
        "\\\"method\\\":\\\"segment_intersection_records_2d_report\\\"",
        "\\\"method\\\":\\\"segment_intersections_2d_report\\\"",
        "\\\"method\\\":\\\"segment_bbox_candidate_pairs_2d_report\\\"",
        "\\\"method\\\":\\\"segment_bbox_candidate_pairs_3d_report\\\"",
        "backend report bytes ",
        "invariant result-handle report bytes ",
        "invariant result-handle report bytes 0",
        "invariant compute handles status unsupported",
        "status_code=native_invariant_compute_handles_unavailable",
        "host_action=use_python_file_recompute_boundary",
        "homfly_native_compute_handle_available=false",
        "alexander_native_compute_handle_available=false",
        "native_result_handle_boundary=false",
        "native_result_handles_complete=false",
        "complete_result_handle_abi=false",
        "release_grade_result_handles=false",
        "metadata_schema_version=1",
        "metadata_contract_version=rust_c_abi_19_invariant_result_handles_lifecycle_metadata_v1",
        "required_metadata_field_count=30",
        "required_metadata_fields_present=true",
        "stats.invariant_result_handles_metadata_schema_version != 1",
        "stats.invariant_result_handles_required_metadata_field_count != 30",
        "stats.invariant_result_handles_required_metadata_fields_present != 1",
        "stats.invariant_result_handles_native_result_handles_complete != 0",
        "stats.invariant_result_handles_complete_result_handle_abi != 0",
        "stats.invariant_result_handles_release_grade_result_handles != 0",
        "stats.invariant_result_handles_metadata_contract_version_length !=",
        "kernel smoke did not publish compact invariant result-handle metadata fields",
        "distance report bytes ",
        "linking report bytes ",
        "writhe report bytes ",
        "contact report bytes ",
        "intersection record report bytes ",
        "fixed intersection report bytes ",
        "2D pair report bytes ",
        "3D pair report bytes ",
        "callback progress ",
        "callback progress 0/",
        "HostRustCallbackThreadPool",
        "RealRustThreadPoolJob",
        "run_real_rust_distance_callback_job",
        "run_real_rust_intersection_callback_job",
        "api.segment_segment_distances_with_callbacks == nullptr",
        "api.segment_intersections_2d_with_callbacks == nullptr",
        "IrollImGui_SetKernelProgress",
        "real Rust callback thread pool",
        "host-owned worker threads; Rust callbacks completed",
        "worker_touches_imgui_context=false",
        "distance_progress=3/3",
        "intersection_progress=2/2",
        "host thread-pool real Rust callback jobs did not complete",
    ]:
        assert symbol in real_loader_smoke
    assert "Python" not in real_loader_smoke
    assert "iroll_imgui_kernel_loader.cpp" in cmake
    assert "IROLL_KERNELS_INCLUDE_DIR" in cmake
    assert "IROLL_IMGUI_USE_TEST_STUB" in cmake
    assert "IROLL_IMGUI_BUILD_CONTRACT_SMOKE" in cmake
    assert "iroll_imgui_panel_contract_smoke" in cmake
    assert "CMAKE_DL_LIBS" in cmake
    assert "install(" in cmake
    assert "iroll_imgui_panelTargets" in cmake
    assert "configure_package_config_file" in cmake
    assert "write_basic_package_version_file" in cmake
    assert "EXPORT_NAME imgui_panel" in cmake
    assert "iroll_imgui_worker_scheduler_smoke" in cmake
    assert "examples/worker_scheduler_smoke.cpp" in cmake
    assert "iroll_imgui_threaded_worker_smoke" in cmake
    assert "examples/threaded_worker_smoke.cpp" in cmake
    assert "iroll_imgui_thread_pool_worker_smoke" in cmake
    assert "examples/thread_pool_worker_smoke.cpp" in cmake
    assert "iroll_imgui_signed_pd_json_export_smoke" in cmake
    assert "examples/signed_pd_json_export_smoke.cpp" in cmake
    assert "iroll_imgui_signed_pd_recompute_scheduler_smoke" in cmake
    assert "examples/signed_pd_recompute_scheduler_smoke.cpp" in cmake
    assert "iroll_imgui_signed_pd_thread_pool_recompute_scheduler_smoke" in cmake
    assert "examples/signed_pd_thread_pool_recompute_scheduler_smoke.cpp" in cmake
    assert "iroll_imgui_real_kernel_loader_smoke" in cmake
    assert "examples/real_kernel_loader_smoke.cpp" in cmake
    assert "IROLL_TEST_IMGUI_STUB_H" in imgui_stub
    assert "IrollTestImGui_ResetDrawStats" in imgui_stub
    assert "AddPolyline" in imgui_stub
    assert "host application owns" in readme
    assert "should not call Python" in readme
    assert "iroll_imgui_kernel_loader.h" in readme
    assert "dynamic Rust kernel loading" in readme
    assert "signed-PD, link classification summary, and invariant status payloads" in readme
    assert "report-level analysis summary payloads" in readme
    assert "IrollImGui_LoadAnalysisSummaries" in readme
    assert "IrollImGui_LoadLinkClassificationSummary" in readme
    assert "top-level\n`signed_pd_revision`, or `source_signed_pd_revision`" in readme
    assert "IrollLinkClassificationSummary" in readme
    assert "analysis payload root also\npromotes it as `source_signed_pd_revision`" in readme
    assert "conflicting revisions are left\nunset" in readme
    assert "source-table registration blocker code fields" in readme
    assert "source_table_registration_blocker_code_counts" in readme
    assert "source_table_registration_blocker_count_signature" in readme
    assert "no Dear ImGui ABI bump" in readme
    assert "instead of automatic classifications" in readme
    assert "fixture comparison payloads" in readme
    assert "report-derived evidence counts" in readme
    assert "required_check_count" in readme
    assert "current Rust C ABI 19 callback functions" in readme
    assert "iroll_invariant_result_handles_report_json" in readme
    assert "invariant result-handle metadata probe" in readme
    assert "required loader ABI capability failure" in readme
    assert "not as HOMFLY/Alexander unavailable" in readme
    assert "homfly_report_json=false" in readme
    assert "alexander_report_json=false" in readme
    assert "metadata-only/capability-probe-only" in readme
    assert "HOMFLY/Alexander report JSON availability is false" in readme
    assert "native computation is not claimed" in readme
    assert "HOMFLY/Alexander native computation result payloads still wait" in readme
    assert "rust-unsupported-invariant-result-handle-report --invariant homfly" in readme
    assert "--invariant alexander" in readme
    assert "imgui-invariant-status-summary-payload" in readme
    assert "zero-check" in readme
    assert "`IrollInvariantStatus` row" in readme
    assert "native_computation_claimed=false" in readme
    assert "result_available=false" in readme
    assert "current_boundary=python_file_recompute" in readme
    assert "claim_scope=unsupported_lifecycle_probe_only" in readme
    assert "source_candidate_replay_*" in readme
    assert "source_candidate_replay=..." in readme
    assert "source-Gauss candidate snapshot" in readme
    assert "without treating the unsigned fixture candidate as a registered invariant" in readme
    assert "signed_pd_auto_role_order_*" in readme
    assert "signed_pd_auto_role_order=..." in readme
    assert "invariant_signed_pd_auto_role_order_*" in readme
    assert "unique-applied" in readme
    assert "ambiguous skipped report" in readme
    assert "inferred convention" in readme
    assert "imgui-host-payload --invariant-report-json report.json" in readme
    assert "combined host bundle's invariant-status section" in readme
    assert "does not add those rows to the analysis section" in readme
    assert "unsupported native result-handle lifecycle reports" in readme
    assert "Direct report reloads through `iroll imgui-invariant-status-summary-payload`" in readme
    assert "common non-conflicting `input.signed_pd_revision`" in readme
    assert "top-level `signed_pd_revision`" in readme
    assert "conflicting revisions are intentionally left unset" in readme
    assert "ABI 110 promotes deeper HOMFLY/Alexander host triage evidence" in readme
    assert "frontier_witness_summary_pressure_total_frontier_count" in readme
    assert "admissible_minor_normalization_gate_count" in readme
    assert "not native HOMFLY/Alexander compute" in readme
    assert "not full normalization" in readme
    assert "not an arbitrary HOMFLY claim" in readme
    assert (
        "ABI 108 promotes Alexander blocker witness-source compact fields"
        in readme
    )
    assert (
        "admissible_minor_normalization_blocker_witness_source_count"
        in readme
    )
    assert (
        "admissible_minor_normalization_blocker_witness_source_available_count"
        in readme
    )
    assert (
        "admissible_minor_normalization_blocker_witness_source_missing_count"
        in readme
    )
    assert "not native Alexander compute" in readme
    assert "not full admissible-minor normalization" in readme
    assert (
        "ABI 106 promotes Alexander blocker witness summary compact fields"
        in readme
    )
    assert "admissible_minor_normalization_blocker_reason_count" in readme
    assert (
        "admissible_minor_normalization_blocker_witness_available_count"
        in readme
    )
    assert (
        "admissible_minor_normalization_blocker_missing_witness_reason_count"
        in readme
    )
    assert "not a native Alexander compute API" in readme
    assert "full admissible-minor normalization claim" in readme
    assert "ABI 107 promotes additional HOMFLY frontier witness summary compact fields" in readme
    assert "frontier_witness_summary_recursive_path_prefix_count" in readme
    assert "frontier_witness_summary_source_kind_count" in readme
    assert "frontier_witness_summary_branch_count" in readme
    assert "compact host triage evidence fields" in readme
    assert "not a native HOMFLY compute API or arbitrary signed-PD completion" in readme
    assert "ABI 105 promotes HOMFLY frontier witness summary compact fields" in readme
    assert "frontier_witness_summary_count" in readme
    assert "frontier_witness_summary_reason_count" in readme
    assert "frontier_witness_summary_max_branch_depth" in readme
    assert "compact host triage fields" in readme
    assert "does not add a native HOMFLY compute API" in readme
    assert "ABI 104 promotes Alexander compact witness fields" in readme
    assert "quotient_polynomial_witness_count" in readme
    assert "quotient_polynomial_witness_truncated" in readme
    assert (
        "source_table_alexander_source_divisibility_failed_candidate_witness_count"
        in readme
    )
    assert "nested witness payloads remain host/report JSON data" in readme
    assert "ABI 103 promotes invariant result-handle metadata schema compact fields" in readme
    assert "invariant_result_handles_metadata_schema_version" in readme
    assert "invariant_result_handles_required_metadata_field_count" in readme
    assert "invariant_result_handles_required_metadata_fields_present" in readme
    assert "invariant_result_handles_metadata_contract_version_length" in readme
    assert "Missing or older metadata stays conservative" in readme
    assert "ABI 109 promotes Rust/backend owned-string lifecycle diagnostics" in readme
    assert "backend_info.owned_string_reports.owned_string_contract" in readme
    assert "owned_string_contract_schema_version" in readme
    assert "owned_string_contract_abi_version" in readme
    assert "owned_string_contract_version_length" in readme
    assert "owned_string_contract_free_required" in readme
    assert "owned_string_contract_free_accepts_zero_initialized" in readme
    assert "owned_string_contract_borrowed_across_calls" in readme
    assert "owned-string lifecycle host diagnostics" in readme
    assert "not HOMFLY/Alexander native compute" in readme
    assert (
        "not a full production 3D engine with real graphics-backend "
        "framebuffer/screenshot verification"
        in readme
    )
    assert "Rust C ABI 17 callback functions" not in readme
    assert "ABI 17 also exposes owned-string" not in readme
    assert "find_package(iroll_imgui_panel CONFIG REQUIRED)" in readme
    assert "iroll::imgui_panel" in readme
    for symbol in [
        "HostWorkerState",
        "std::atomic<int>",
        "IrollKernelExecutionCallbacks",
        "host_worker_progress_callback",
        "host_worker_cancel_callback",
        "IrollImGui_SetKernelApi",
        "IrollImGui_SetKernelProgress",
        "IrollImGui_RequestKernelCancel",
        "IrollImGui_GetKernelCancelRequested",
        "IrollImGui_ClearKernelCancelRequested",
        "IrollImGui_GetPanelStats",
        "compute_writhe_with_callbacks",
        "segment_contact_records_3d_count_with_callbacks",
        "segment_contact_records_3d_with_callbacks",
        "run_host_worker_contact_record_job",
        "host-worker contacts",
        "segment_intersection_records_2d_count_with_callbacks",
        "segment_intersection_records_2d_with_callbacks",
        "run_host_worker_intersection_record_job",
        "host-worker intersections",
        "segment_bbox_candidate_pairs_2d_count_with_callbacks",
        "segment_bbox_candidate_pairs_2d_with_callbacks",
        "run_host_worker_candidate_pair_job",
        "host-worker candidate pairs",
        "IROLL_STATUS_CANCELLED",
        "iroll_imgui_worker_scheduler_smoke",
    ]:
        assert symbol in worker_smoke or symbol in cmake
    assert "Python" not in worker_smoke
    for symbol in [
        "ThreadedWorkerState",
        "std::thread",
        "std::atomic",
        "threaded_progress_callback",
        "threaded_cancel_callback",
        "publish_threaded_progress",
        "run_threaded_writhe_job",
        "mock_slow_candidate_pairs_2d_with_callbacks",
        "run_threaded_candidate_pair_job",
        "threaded host-worker candidate pairs",
        "IrollImGui_SetKernelProgress",
        "IrollImGui_RequestKernelCancel",
        "IrollImGui_GetKernelCancelRequested",
        "IROLL_STATUS_CANCELLED",
        "iroll_imgui_threaded_worker_smoke",
    ]:
        assert symbol in threaded_worker_smoke or symbol in cmake
    assert "Python" not in threaded_worker_smoke
    for symbol in [
        "HostThreadPool",
        "PoolJobState",
        "PoolSharedState",
        "std::condition_variable",
        "std::queue<std::function<void()>>",
        "pool_progress_callback",
        "pool_cancel_callback",
        "mock_thread_pool_native_work",
        "run_pool_job",
        "thread-pool host scheduler",
        "IrollImGui_SetKernelProgress",
        "IrollImGui_GetKernelProgress",
        "IrollImGui_RequestKernelCancel",
        "IrollImGui_GetKernelCancelRequested",
        "IrollImGui_ClearKernelCancelRequested",
        "IROLL_STATUS_CANCELLED",
        "max_active_worker_count",
        "iroll_imgui_thread_pool_worker_smoke",
    ]:
        assert symbol in thread_pool_worker_smoke or symbol in cmake
    assert "Python" not in thread_pool_worker_smoke
    for symbol in [
        "IrollImGui_LoadSignedPlanarDiagram",
        "IrollImGui_SetSignedPDComponentCount",
        "IrollImGui_InsertSignedPDCrossing",
        "IrollImGui_GetSignedPDValidationSummary",
        "IrollImGui_GetSignedPlanarDiagramInfo",
        "IrollImGui_GetSignedPlanarDiagramJson",
        "std::ofstream",
        "\\\"validation\\\":{",
        "\\\"unique_edge_label_count\\\":4",
        "\\\"labels_with_invalid_flow_count\\\":0",
        "\\\"component_count_matches\\\":true",
        "\\\"edge_labels\\\":[4,1,2,3]",
        "\\\"edge_labels\\\":[2,3,4,1]",
        "iroll_imgui_signed_pd_json_export_smoke",
    ]:
        assert symbol in signed_pd_export_smoke or symbol in cmake
    assert "Python" not in signed_pd_export_smoke
    for symbol in [
        "HostInvariantScheduler",
        "HostInvariantJob",
        "std::ofstream",
        "std::queue",
        "host-owned invariant scheduler",
        "host_file_recompute_handoff_note",
        "notes_contain_file_handoff_metadata",
        "invariant_status_compact_evidence_matches",
        "IrollImGui_RequestSignedPDInvariantRecompute",
        "IrollImGui_GetRequestedSignedPDInvariantRecompute",
        "IrollImGui_GetRequestedSignedPDInvariantRecomputeRevision",
        "IrollImGui_GetRequestedSignedPDInvariantRecomputeSnapshotJson",
        "IrollImGui_GetRequestedSignedPDInvariantRecomputeStale",
        "IrollImGui_ClearRequestedSignedPDInvariantRecompute",
        "IrollImGui_LoadInvariantStatuses",
        "IrollImGui_LoadInvariantStatusesForSignedPDRevision",
        "IrollImGui_GetInvariantStatus",
        "write_scheduler_trace_json",
        "imgui_signed_pd_recompute_scheduler_smoke",
        "host_owned_signed_pd_recompute_scheduler_contract",
        "stale_recompute_rejected",
        "current_revision_reloaded",
        "requested_snapshot_json_cleared",
        "handoff_input_format",
        "handoff_result_transport",
        "stale_request_snapshot_fnv1a64",
        "current_request_snapshot_fnv1a64",
        "artifact_schema_version",
        "artifact_kind",
        "claim_scope",
        "load_results_for_revision",
        "signed-PD revision does not match",
        "IrollImGui_LastError",
        "revision_json_fragment",
        "input_format=imgui_signed_pd_json",
        "signed_pd_json_bytes=",
        "result_transport=json_file",
        "host_reload_payload=imgui-signed-pd-invariant-status-payload",
        "homfly_cli_command=iroll homfly-pd",
        "alexander_cli_command=iroll multivariable-alexander-pd",
        "certification_blocker_detail_count = 0",
        "homfly_completion_blocker_detail_count = 0",
        "admissible_minor_normalization_blocker_reason_count = 0",
        "admissible_minor_normalization_blocker_witness_source_count = 0",
        "admissible_minor_normalization_blocker_witness_source_available_count = 0",
        "admissible_minor_normalization_blocker_witness_source_missing_count = 0",
        "admissible_minor_normalization_blocker_witness_available_count = 0",
        "admissible_minor_normalization_blocker_missing_witness_reason_count = 0",
        "frontier_witness_summary_count = 0",
        "frontier_witness_summary_reason_count = 0",
        "frontier_witness_summary_truncated = 0",
        "frontier_witness_summary_min_depth = 0",
        "frontier_witness_summary_max_depth = 0",
        "frontier_witness_summary_min_branch_depth = 0",
        "frontier_witness_summary_max_branch_depth = 0",
        "frontier_witness_summary_recursive_path_prefix_count = 0",
        "frontier_witness_summary_source_kind_count = 0",
        "frontier_witness_summary_branch_count = 0",
        "frontier_witness_summary_pressure_total_frontier_count = 0",
        "frontier_witness_summary_pressure_visible_witness_count = 0",
        "frontier_witness_summary_pressure_missing_frontier_count = 0",
        "frontier_witness_summary_pressure_all_frontiers_have_visible_witness",
        "frontier_witness_summary_pressure_reason_count = 0",
        "failed_division_witness_count = 0",
        "quotient_gcd_uncertainty_present = 0",
        "quotient_polynomial_witness_count = 0",
        "quotient_polynomial_witness_truncated = 0",
        "source_table_alexander_source_divisibility_failed_candidate_witness_count",
        "source_table_alexander_source_divisibility_failed_candidate_witness_truncated",
        "normalization_class_witness_count = 0",
        "admissible_minor_normalization_gate_count = 0",
        "admissible_minor_normalization_gate_passed_count = 0",
        "admissible_minor_normalization_gate_failed_count = 0",
        "admissible_minor_normalization_gate_summary_consistent = 0",
        "admissible_minor_normalization_failed_gate_blocker_count = 0",
        "stats.invariant_certification_blocker_detail_count != 7",
        "stats.invariant_homfly_completion_blocker_detail_count != 3",
        "stats.invariant_admissible_minor_normalization_blocker_reason_count != 3",
        "stats.invariant_admissible_minor_normalization_blocker_witness_source_count != 5",
        (
            "invariant_admissible_minor_normalization_blocker_"
            "witness_source_available_count !="
        ),
        (
            "invariant_admissible_minor_normalization_blocker_"
            "witness_source_missing_count != 1"
        ),
        (
            "stats.invariant_admissible_minor_normalization_blocker_"
            "witness_available_count != 2"
        ),
        (
            "invariant_admissible_minor_normalization_blocker_"
            "missing_witness_reason_count != 1"
        ),
        "stats.invariant_frontier_witness_summary_count != 4",
        "stats.invariant_frontier_witness_summary_reason_count != 2",
        "stats.invariant_frontier_witness_summary_truncated != 1",
        "stats.invariant_frontier_witness_summary_min_depth != 2",
        "stats.invariant_frontier_witness_summary_max_depth != 5",
        "stats.invariant_frontier_witness_summary_min_branch_depth != 1",
        "stats.invariant_frontier_witness_summary_max_branch_depth != 4",
        "stats.invariant_frontier_witness_summary_recursive_path_prefix_count != 2",
        "stats.invariant_frontier_witness_summary_source_kind_count != 2",
        "stats.invariant_frontier_witness_summary_branch_count != 4",
        "stats.invariant_frontier_witness_summary_pressure_total_frontier_count !=",
        "stats.invariant_frontier_witness_summary_pressure_visible_witness_count !=",
        "stats.invariant_frontier_witness_summary_pressure_missing_frontier_count !=",
        "stats.invariant_frontier_witness_summary_pressure_all_frontiers_have_visible_witness !=",
        "stats.invariant_frontier_witness_summary_pressure_reason_count != 2",
        "stats.invariant_failed_division_witness_count != 7",
        "stats.invariant_quotient_gcd_uncertainty_present != 1",
        "stats.invariant_quotient_polynomial_witness_count != 29",
        "stats.invariant_quotient_polynomial_witness_truncated != 1",
        "invariant_source_table_alexander_source_divisibility_failed_candidate_witness_count !=",
        "invariant_source_table_alexander_source_divisibility_failed_candidate_witness_truncated !=",
        "stats.invariant_normalization_class_witness_count != 11",
        "stats.invariant_admissible_minor_normalization_gate_count != 7",
        "stats.invariant_admissible_minor_normalization_gate_passed_count !=",
        "stats.invariant_admissible_minor_normalization_gate_summary_consistent !=",
        "stats.invariant_certification_blocker_detail_count != 2",
        "stats.invariant_frontier_witness_summary_count != 4",
        "stats.invariant_frontier_witness_summary_recursive_path_prefix_count != 2",
        "stats.invariant_frontier_witness_summary_pressure_total_frontier_count !=",
        "stats.invariant_admissible_minor_normalization_blocker_reason_count != 0",
        "stats.invariant_admissible_minor_normalization_blocker_witness_source_count != 0",
        "invariant_admissible_minor_normalization_blocker_witness_source_available_count !=\n            0",
        "invariant_admissible_minor_normalization_blocker_witness_source_missing_count != 0",
        "stats.invariant_failed_division_witness_count != 0",
        "stats.invariant_quotient_gcd_uncertainty_present != 0",
        "stats.invariant_quotient_polynomial_witness_count != 0",
        "stats.invariant_quotient_polynomial_witness_truncated != 0",
        "stats.invariant_admissible_minor_normalization_gate_count != 0",
        "mock-homfly-revision-",
        '"homfly"',
        "IrollImGui_GetPanelStats",
        "requested_signed_pd_invariant_recompute_revision",
        "requested_signed_pd_invariant_recompute_snapshot_json_length",
        "requested_signed_pd_invariant_recompute_stale",
        "export_requested_signed_pd_json",
        "queued_scope",
        "queued_json",
        "stale_scope",
        "stale_json",
        "stale_results",
        "\\\"sign\\\":1,\\\"edge_labels\\\":[4,1,2,3]",
        "\\\"sign\\\":-1,\\\"edge_labels\\\":[4,1,2,3]",
        "signed_pd_invariant_status_stale != 1",
        "stats.invariant_status_signed_pd_revision",
        "iroll_imgui_signed_pd_recompute_scheduler_smoke",
    ]:
        assert symbol in signed_pd_recompute_scheduler_smoke or symbol in cmake
    assert "Python" not in signed_pd_recompute_scheduler_smoke
    for symbol in [
        "HostThreadPool",
        "ScheduledInvariantWork",
        "std::ofstream",
        "std::condition_variable",
        "std::queue<std::function<void()>>",
        'std::string input_format = "imgui_signed_pd_json"',
        'std::string homfly_cli_command = "iroll homfly-pd"',
        'std::string alexander_cli_command = "iroll multivariable-alexander-pd"',
        'std::string result_transport = "json_file"',
        "imgui-signed-pd-invariant-status-payload",
        "recompute_handoff_metadata",
        "notes_include_recompute_handoff_metadata",
        "notes_include_worker_result_metadata",
        "invariant_status_compact_evidence_matches",
        "run_thread_pool_invariant_job",
        "publish_invariant_progress",
        "thread-pool invariant scheduler",
        "worker-owned result",
        "IrollImGui_RequestSignedPDInvariantRecompute",
        "IrollImGui_GetRequestedSignedPDInvariantRecompute",
        "IrollImGui_GetRequestedSignedPDInvariantRecomputeRevision",
        "IrollImGui_GetRequestedSignedPDInvariantRecomputeSnapshotJson",
        "IrollImGui_GetRequestedSignedPDInvariantRecomputeStale",
        "IrollImGui_ClearRequestedSignedPDInvariantRecompute",
        "IrollImGui_LoadInvariantStatusesForSignedPDRevision",
        "IrollImGui_GetInvariantStatus",
        "IrollImGui_SetKernelProgress",
        "IrollImGui_GetKernelProgress",
        "write_scheduler_trace_json",
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke",
        "host_owned_thread_pool_signed_pd_recompute_scheduler_contract",
        "stale_recompute_rejected",
        "current_revision_reloaded",
        "requested_snapshot_json_cleared",
        "progress_completed",
        "progress_active_after_completion",
        "handoff_input_format",
        "handoff_result_transport",
        "stale_request_snapshot_fnv1a64",
        "current_request_snapshot_fnv1a64",
        "signed-PD revision does not match",
        "mock-thread-pool-alexander-revision-",
        "scope=",
        '"alexander"',
        "signed_pd_json_bytes=",
        '"; cli_command=" + work->homfly_cli_command',
        '"; cli_command=" + work->alexander_cli_command',
        "certification_blocker_detail_count = 0",
        "homfly_completion_blocker_detail_count = 0",
        "admissible_minor_normalization_blocker_reason_count = 0",
        "admissible_minor_normalization_blocker_witness_source_count = 0",
        "admissible_minor_normalization_blocker_witness_source_available_count = 0",
        "admissible_minor_normalization_blocker_witness_source_missing_count = 0",
        "admissible_minor_normalization_blocker_witness_available_count = 0",
        "admissible_minor_normalization_blocker_missing_witness_reason_count = 0",
        "frontier_witness_summary_count = 0",
        "frontier_witness_summary_reason_count = 0",
        "frontier_witness_summary_truncated = 0",
        "frontier_witness_summary_min_depth = 0",
        "frontier_witness_summary_max_depth = 0",
        "frontier_witness_summary_min_branch_depth = 0",
        "frontier_witness_summary_max_branch_depth = 0",
        "frontier_witness_summary_recursive_path_prefix_count = 0",
        "frontier_witness_summary_source_kind_count = 0",
        "frontier_witness_summary_branch_count = 0",
        "frontier_witness_summary_pressure_total_frontier_count = 0",
        "frontier_witness_summary_pressure_visible_witness_count = 0",
        "frontier_witness_summary_pressure_missing_frontier_count = 0",
        "frontier_witness_summary_pressure_all_frontiers_have_visible_witness",
        "frontier_witness_summary_pressure_reason_count = 0",
        "failed_division_witness_count = 0",
        "quotient_gcd_uncertainty_present = 0",
        "quotient_polynomial_witness_count = 0",
        "quotient_polynomial_witness_truncated = 0",
        "source_table_alexander_source_divisibility_failed_candidate_witness_count",
        "source_table_alexander_source_divisibility_failed_candidate_witness_truncated",
        "normalization_class_witness_count = 0",
        "admissible_minor_normalization_gate_count = 0",
        "admissible_minor_normalization_gate_passed_count = 0",
        "admissible_minor_normalization_gate_failed_count = 0",
        "admissible_minor_normalization_gate_summary_consistent = 0",
        "admissible_minor_normalization_failed_gate_blocker_count = 0",
        "stats.invariant_certification_blocker_detail_count != 5",
        "stats.invariant_homfly_completion_blocker_detail_count != 0",
        "stats.invariant_admissible_minor_normalization_blocker_reason_count != 3",
        "stats.invariant_admissible_minor_normalization_blocker_witness_source_count != 5",
        (
            "invariant_admissible_minor_normalization_blocker_"
            "witness_source_available_count !="
        ),
        (
            "invariant_admissible_minor_normalization_blocker_"
            "witness_source_missing_count != 1"
        ),
        (
            "stats.invariant_admissible_minor_normalization_blocker_"
            "witness_available_count != 2"
        ),
        (
            "invariant_admissible_minor_normalization_blocker_"
            "missing_witness_reason_count != 1"
        ),
        "stats.invariant_frontier_witness_summary_count != 0",
        "stats.invariant_frontier_witness_summary_reason_count != 0",
        "stats.invariant_frontier_witness_summary_truncated != 0",
        "stats.invariant_frontier_witness_summary_min_depth != 0",
        "stats.invariant_frontier_witness_summary_max_depth != 0",
        "stats.invariant_frontier_witness_summary_min_branch_depth != 0",
        "stats.invariant_frontier_witness_summary_max_branch_depth != 0",
        "stats.invariant_frontier_witness_summary_recursive_path_prefix_count != 0",
        "stats.invariant_frontier_witness_summary_source_kind_count != 0",
        "stats.invariant_frontier_witness_summary_branch_count != 0",
        "stats.invariant_frontier_witness_summary_pressure_total_frontier_count !=",
        "stats.invariant_frontier_witness_summary_pressure_reason_count != 0",
        "stats.invariant_failed_division_witness_count != 7",
        "stats.invariant_quotient_gcd_uncertainty_present != 1",
        "stats.invariant_quotient_polynomial_witness_count != 29",
        "stats.invariant_quotient_polynomial_witness_truncated != 1",
        "invariant_source_table_alexander_source_divisibility_failed_candidate_witness_count !=",
        "invariant_source_table_alexander_source_divisibility_failed_candidate_witness_truncated !=",
        "stats.invariant_normalization_class_witness_count != 11",
        "stats.invariant_admissible_minor_normalization_gate_count != 7",
        "stats.invariant_admissible_minor_normalization_gate_summary_consistent !=",
        "completed=",
        "requested_signed_pd_invariant_recompute_revision",
        "requested_signed_pd_invariant_recompute_snapshot_json_length",
        "requested_signed_pd_invariant_recompute_stale",
        "export_requested_signed_pd_json",
        "\\\"sign\\\":1,\\\"edge_labels\\\":[4,1,2,3]",
        "\\\"sign\\\":-1,\\\"edge_labels\\\":[4,1,2,3]",
        "iroll_imgui_signed_pd_thread_pool_recompute_scheduler_smoke",
    ]:
        assert (
            symbol in signed_pd_thread_pool_recompute_scheduler_smoke
            or symbol in cmake
        )
    assert "Python" not in signed_pd_thread_pool_recompute_scheduler_smoke


def test_imgui_production_d3d11_framebuffer_producer_uses_real_backend() -> None:
    cmake = (ROOT / "ui/imgui/CMakeLists.txt").read_text(encoding="utf-8")
    producer = (
        ROOT / "ui/imgui/examples/production_d3d11_framebuffer.cpp"
    ).read_text(encoding="utf-8")
    script = (
        ROOT / "scripts/produce_production_imgui_framebuffer_evidence.ps1"
    ).read_text(encoding="utf-8")

    for token in [
        "IROLL_IMGUI_BUILD_D3D11_PRODUCTION_EVIDENCE",
        "iroll_imgui_dx11_runtime",
        "backends/imgui_impl_dx11.cpp",
        "iroll_imgui_production_d3d11_framebuffer",
        "windowscodecs",
    ]:
        assert token in cmake
    for token in [
        "D3D11CreateDevice",
        "D3D_DRIVER_TYPE_HARDWARE",
        "ImGui_ImplDX11_Init",
        "ImGui_ImplDX11_RenderDrawData",
        "IrollImGui_RenderPanel",
        "CopyResource(staging, framebuffer)",
        "D3D11_MAP_READ",
        "GUID_ContainerFormatPng",
        "readback_pixel_count",
        "unique_color_count",
        "content_pixel_count",
        "panel_render_frame_count",
        "panel_geometry_nonempty",
        '"Dear ImGui imgui_impl_dx11 + Direct3D 11 ("',
    ]:
        assert token in producer
    assert "test_stubs" not in producer
    assert "IROLL_IMGUI_USE_TEST_STUB=OFF" in script
    assert "f5befd2d29e66809cd1110a152e375a7f1981f06" in script
    assert "screenshot_remote_fetch_verified" in script
    assert "Published screenshot bytes do not match" in script
    assert "completion-evidence-artifact-audit" in script
    assert "--fail-on-not-certified" in script
    assert "example.invalid" not in script
    assert "evidence.iroll.dev" not in script
    assert "catbox" not in script


def test_imgui_panel_contract_smoke_compiles_and_runs_with_stub_imgui(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    if sys.platform != "win32":
        pytest.skip("MSVC smoke build is only exercised on Windows")
    vcvars = Path(
        "C:/Program Files/Microsoft Visual Studio/2022/Community/VC/Auxiliary/Build/vcvars64.bat"
    )
    if not vcvars.exists():
        pytest.skip("MSVC vcvars64.bat is not installed")
    if shutil.which("cmake") is None:
        pytest.skip("CMake is not installed")
    if shutil.which("ninja") is None:
        pytest.skip("Ninja is not installed")

    build_script = tmp_path / "build_panel_contract_smoke.bat"
    build_dir = tmp_path / "build"
    install_dir = tmp_path / "install"
    consumer_dir = tmp_path / "consumer"
    consumer_build_dir = tmp_path / "consumer_build"
    exported_signed_pd = tmp_path / "imgui_signed_pd_export.json"
    framebuffer_smoke = tmp_path / "imgui_test_stub_framebuffer_smoke.json"
    source_open_smoke = tmp_path / "imgui_source_open_request_smoke.json"
    scheduler_trace = tmp_path / "imgui_signed_pd_recompute_scheduler_smoke.json"
    thread_pool_scheduler_trace = (
        tmp_path / "imgui_signed_pd_thread_pool_recompute_scheduler_smoke.json"
    )
    consumer_dir.mkdir()
    (consumer_dir / "CMakeLists.txt").write_text(
        "\n".join(
            [
                "cmake_minimum_required(VERSION 3.20)",
                "project(iroll_imgui_panel_consumer LANGUAGES CXX)",
                "find_package(iroll_imgui_panel CONFIG REQUIRED)",
                "add_executable(iroll_imgui_panel_consumer main.cpp)",
                (
                    "target_link_libraries(iroll_imgui_panel_consumer "
                    "PRIVATE iroll::imgui_panel)"
                ),
            ]
        ),
        encoding="utf-8",
    )
    (consumer_dir / "main.cpp").write_text(
        "\n".join(
            [
                '#include "iroll_imgui_kernel_loader.h"',
                "",
                "int main() {",
                "    if (IrollImGui_ApiVersion() != IROLL_IMGUI_ABI_VERSION) {",
                "        return 1;",
                "    }",
                "    if (IrollKernelLoader_ApiVersion() != IROLL_IMGUI_KERNEL_LOADER_ABI_VERSION) {",
                "        return 2;",
                "    }",
                "    IrollUiContext* context = IrollImGui_CreateContext();",
                "    if (context == nullptr) {",
                "        return 3;",
                "    }",
                "    IrollImGui_DestroyContext(context);",
                "    return 0;",
                "}",
            ]
        ),
        encoding="utf-8",
    )
    build_script.write_text(
        "\n".join(
            [
                "@echo off",
                f'call "{vcvars}" >nul',
                "if errorlevel 1 exit /b %errorlevel%",
                "set PATH=%USERPROFILE%\\.cargo\\bin;%PATH%",
                (
                    f'cargo build --release --manifest-path '
                    f'"{ROOT / "native/iroll-kernels-rust/Cargo.toml"}"'
                ),
                "if errorlevel 1 exit /b %errorlevel%",
                (
                    f'cmake -S "{ROOT / "ui/imgui"}" -B "{build_dir}" -G Ninja '
                    "-DCMAKE_BUILD_TYPE=Release "
                    "-DIROLL_IMGUI_USE_TEST_STUB=ON "
                    "-DIROLL_IMGUI_BUILD_CONTRACT_SMOKE=ON"
                ),
                "if errorlevel 1 exit /b %errorlevel%",
                f'cmake --build "{build_dir}" --config Release',
                "if errorlevel 1 exit /b %errorlevel%",
                (
                    f'"{build_dir / "iroll_imgui_panel_contract_smoke.exe"}" '
                    f'"{framebuffer_smoke}" "{source_open_smoke}"'
                ),
                "if errorlevel 1 exit /b %errorlevel%",
                f'"{build_dir / "iroll_imgui_worker_scheduler_smoke.exe"}"',
                "if errorlevel 1 exit /b %errorlevel%",
                f'"{build_dir / "iroll_imgui_threaded_worker_smoke.exe"}"',
                "if errorlevel 1 exit /b %errorlevel%",
                f'"{build_dir / "iroll_imgui_thread_pool_worker_smoke.exe"}"',
                "if errorlevel 1 exit /b %errorlevel%",
                (
                    f'"{build_dir / "iroll_imgui_signed_pd_json_export_smoke.exe"}" '
                    f'"{exported_signed_pd}"'
                ),
                "if errorlevel 1 exit /b %errorlevel%",
                (
                    f'"{build_dir / "iroll_imgui_signed_pd_recompute_scheduler_smoke.exe"}" '
                    f'"{scheduler_trace}"'
                ),
                "if errorlevel 1 exit /b %errorlevel%",
                (
                    f'"{build_dir / "iroll_imgui_signed_pd_thread_pool_recompute_scheduler_smoke.exe"}" '
                    f'"{thread_pool_scheduler_trace}"'
                ),
                "if errorlevel 1 exit /b %errorlevel%",
                (
                    f'"{build_dir / "iroll_imgui_real_kernel_loader_smoke.exe"}" '
                    f'"{ROOT / "native/iroll-kernels-rust/target/release/iroll_kernels_rust.dll"}"'
                ),
                "if errorlevel 1 exit /b %errorlevel%",
                f'cmake --install "{build_dir}" --prefix "{install_dir}"',
                "if errorlevel 1 exit /b %errorlevel%",
                (
                    f'cmake -S "{consumer_dir}" -B "{consumer_build_dir}" -G Ninja '
                    f'-DCMAKE_PREFIX_PATH="{install_dir}"'
                ),
                "if errorlevel 1 exit /b %errorlevel%",
                f'cmake --build "{consumer_build_dir}" --config Release',
                "if errorlevel 1 exit /b %errorlevel%",
                f'"{consumer_build_dir / "iroll_imgui_panel_consumer.exe"}"',
            ]
        ),
        encoding="utf-8",
    )
    build = subprocess.run(
        ["cmd", "/c", str(build_script)],
        cwd=tmp_path,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        check=False,
    )
    assert build.returncode == 0, build.stdout + build.stderr
    framebuffer_payload = json.loads(framebuffer_smoke.read_text(encoding="utf-8"))
    assert framebuffer_payload["artifact_schema_version"] == 1
    assert framebuffer_payload["artifact_kind"] == "imgui_test_stub_framebuffer_smoke"
    assert framebuffer_payload["claim_scope"] == (
        "repository_imgui_test_stub_draw_list_framebuffer_estimate"
    )
    assert framebuffer_payload["real_graphics_backend_framebuffer_verified"] is False
    assert framebuffer_payload["screenshot_verified"] is False
    assert framebuffer_payload["imgui_abi_version"] == 117
    assert framebuffer_payload["rust_c_abi_version"] == 19
    assert framebuffer_payload["render_frame_count"] == 1
    assert framebuffer_payload["last_render_geometry_nonempty"] == 1
    assert framebuffer_payload["last_render_geometry_canvas_count"] == 2
    assert framebuffer_payload["last_render_geometry_filled_rect_count"] == 2
    assert framebuffer_payload["last_render_geometry_rect_count"] == 2
    assert framebuffer_payload["last_render_geometry_polyline_count"] >= 4
    assert framebuffer_payload["last_render_geometry_marker_count"] >= 2
    assert framebuffer_payload["rect_filled_count"] >= 2
    assert framebuffer_payload["rect_count"] >= 2
    assert framebuffer_payload["polyline_count"] >= 4
    assert framebuffer_payload["circle_filled_count"] >= 2
    assert framebuffer_payload["text_count"] >= 10
    assert framebuffer_payload["framebuffer_touched"] == 1
    assert framebuffer_payload["estimated_nonzero_pixels"] > 0
    assert framebuffer_payload["passed"] is True
    source_open_payload = json.loads(source_open_smoke.read_text(encoding="utf-8"))
    assert source_open_payload["artifact_schema_version"] == 1
    assert source_open_payload["artifact_kind"] == "imgui_source_open_request_smoke"
    assert source_open_payload["claim_scope"] == (
        "host_polled_source_open_request_contract"
    )
    assert source_open_payload["host_action"] == "open_source_url"
    assert source_open_payload["opened_by_real_host"] is False
    assert source_open_payload["scheme_allowed"] is True
    assert source_open_payload["selected_fixture"] == 0
    assert source_open_payload["selected_fixture_name"] == "3_1"
    assert source_open_payload["selected_fixture_source"] == "Knot Atlas"
    assert source_open_payload["source_url"] == "https://katlas.org/wiki/3_1"
    assert source_open_payload["consumed_source_url"] == source_open_payload["source_url"]
    assert source_open_payload["request_consumed_by_smoke"] is True
    assert source_open_payload["request_cleared_after_consumption"] is True
    assert source_open_payload["final_request_pending"] is True
    assert source_open_payload["selected_fixture_source_url_length"] == len(
        source_open_payload["source_url"]
    )
    assert source_open_payload["requested_fixture_source_url_length"] == len(
        source_open_payload["source_url"]
    )
    assert source_open_payload["imgui_abi_version"] == 117
    assert source_open_payload["rust_c_abi_version"] == 19
    assert source_open_payload["passed"] is True
    scheduler_trace_payload = json.loads(scheduler_trace.read_text(encoding="utf-8"))
    assert scheduler_trace_payload["artifact_schema_version"] == 1
    assert (
        scheduler_trace_payload["artifact_kind"]
        == "imgui_signed_pd_recompute_scheduler_smoke"
    )
    assert scheduler_trace_payload["claim_scope"] == (
        "host_owned_signed_pd_recompute_scheduler_contract"
    )
    assert scheduler_trace_payload["imgui_abi_version"] == 117
    assert scheduler_trace_payload["rust_c_abi_version"] == 19
    assert scheduler_trace_payload["handoff_input_format"] == "imgui_signed_pd_json"
    assert scheduler_trace_payload["handoff_result_transport"] == "json_file"
    assert (
        scheduler_trace_payload["host_reload_payload"]
        == "imgui-signed-pd-invariant-status-payload"
    )
    assert scheduler_trace_payload["first_scope"] == "all"
    assert scheduler_trace_payload["first_result_count"] == 2
    assert scheduler_trace_payload["first_revision_reloaded"] is True
    assert scheduler_trace_payload["stale_scope"] == "all"
    assert scheduler_trace_payload["stale_result_count"] == 2
    assert scheduler_trace_payload["pending_request_stale"] is True
    assert scheduler_trace_payload["stale_recompute_rejected"] is True
    assert scheduler_trace_payload["stale_results_rejected"] is True
    assert scheduler_trace_payload["stale_error_mentions_revision_mismatch"] is True
    assert scheduler_trace_payload["current_scope"] == "homfly"
    assert scheduler_trace_payload["current_result_count"] == 1
    assert scheduler_trace_payload["current_revision_reloaded"] is True
    assert scheduler_trace_payload["current_revision_rows_reloaded"] is True
    assert scheduler_trace_payload["requested_snapshot_json_cleared"] is True
    assert scheduler_trace_payload["second_revision"] > scheduler_trace_payload[
        "first_revision"
    ]
    assert (
        scheduler_trace_payload["final_invariant_status_signed_pd_revision"]
        == scheduler_trace_payload["second_revision"]
    )
    assert scheduler_trace_payload["first_request_snapshot_json_length"] > 0
    assert scheduler_trace_payload["stale_request_snapshot_json_length"] > 0
    assert scheduler_trace_payload["current_request_snapshot_json_length"] > 0
    assert scheduler_trace_payload["passed"] is True
    scheduler_analysis = imgui_analysis_payload_from_acceptance_reports(
        [scheduler_trace_payload]
    )
    assert (
        scheduler_analysis[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_artifact_count"
        ]
        == 1
    )
    assert (
        scheduler_analysis[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_passed_count"
        ]
        == 1
    )
    assert (
        scheduler_analysis[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_handoff_complete_count"
        ]
        == 1
    )
    scheduler_summary = scheduler_analysis["analysis_summaries"][0]
    assert scheduler_summary["source_method"] == (
        "imgui_signed_pd_recompute_scheduler_smoke"
    )
    assert scheduler_summary["required_check_count"] == 11
    assert scheduler_summary["passed_check_count"] == 11
    assert scheduler_summary["accepted"] is True
    assert "not native HOMFLY/Alexander C++ computation evidence" in (
        scheduler_summary["notes"]
    )
    thread_pool_trace_payload = json.loads(
        thread_pool_scheduler_trace.read_text(encoding="utf-8")
    )
    assert thread_pool_trace_payload["artifact_schema_version"] == 1
    assert (
        thread_pool_trace_payload["artifact_kind"]
        == "imgui_signed_pd_thread_pool_recompute_scheduler_smoke"
    )
    assert thread_pool_trace_payload["claim_scope"] == (
        "host_owned_thread_pool_signed_pd_recompute_scheduler_contract"
    )
    assert thread_pool_trace_payload["imgui_abi_version"] == 117
    assert thread_pool_trace_payload["rust_c_abi_version"] == 19
    assert thread_pool_trace_payload["thread_pool_worker_count"] == 2
    assert thread_pool_trace_payload["stale_recompute_rejected"] is True
    assert thread_pool_trace_payload["stale_scope"] == "all"
    assert thread_pool_trace_payload["current_scope"] == "alexander"
    assert thread_pool_trace_payload["stale_result_count"] == 2
    assert thread_pool_trace_payload["current_result_count"] == 1
    assert thread_pool_trace_payload["current_revision_reloaded"] is True
    assert thread_pool_trace_payload["requested_snapshot_json_cleared"] is True
    assert thread_pool_trace_payload["progress_completed"] is True
    assert thread_pool_trace_payload["progress_active_after_completion"] is False
    assert thread_pool_trace_payload["handoff_input_format"] == "imgui_signed_pd_json"
    assert thread_pool_trace_payload["handoff_result_transport"] == "json_file"
    assert (
        thread_pool_trace_payload["host_reload_payload"]
        == "imgui-signed-pd-invariant-status-payload"
    )
    assert thread_pool_trace_payload["second_revision"] > thread_pool_trace_payload[
        "first_revision"
    ]
    assert (
        thread_pool_trace_payload["current_loaded_revision"]
        == thread_pool_trace_payload["second_revision"]
    )
    assert thread_pool_trace_payload["stale_request_snapshot_json_length"] > 0
    assert thread_pool_trace_payload["current_request_snapshot_json_length"] > 0
    assert thread_pool_trace_payload["passed"] is True
    thread_pool_analysis = imgui_analysis_payload_from_acceptance_reports(
        [thread_pool_trace_payload]
    )
    assert (
        thread_pool_analysis[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact_count"
        ]
        == 1
    )
    assert (
        thread_pool_analysis[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_passed_count"
        ]
        == 1
    )
    assert (
        thread_pool_analysis[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_handoff_complete_count"
        ]
        == 1
    )
    thread_pool_summary = thread_pool_analysis["analysis_summaries"][0]
    assert thread_pool_summary["source_method"] == (
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke"
    )
    assert thread_pool_summary["required_check_count"] == 16
    assert thread_pool_summary["passed_check_count"] == 16
    assert thread_pool_summary["accepted"] is True
    assert "not native HOMFLY/Alexander C++ computation evidence" in (
        thread_pool_summary["notes"]
    )
    exported_payload = json.loads(exported_signed_pd.read_text(encoding="utf-8"))
    assert exported_payload["method"] == "imgui_signed_pd_snapshot"
    assert exported_payload["component_count"] == 2
    assert exported_payload["signed_pd_revision"] > 0
    assert exported_payload["valid"] is True
    assert exported_payload["validation"] == {
        "crossing_count": 2,
        "component_count": 2,
        "edge_label_slot_count": 8,
        "unique_edge_label_count": 4,
        "nonpositive_edge_label_count": 0,
        "labels_with_unexpected_occurrence_count": 0,
        "labels_with_invalid_flow_count": 0,
        "explicit_role_order_count": 2,
        "invalid_role_order_count": 0,
        "oriented_component_count": 2,
        "component_count_matches": True,
        "valid": True,
    }
    assert exported_payload["crossings"] == [
        {
            "sign": 1,
            "edge_labels": [4, 1, 2, 3],
            "role_order": [1, 0, 2, 3],
            "role_order_explicit": True,
        },
        {
            "sign": -1,
            "edge_labels": [2, 3, 4, 1],
            "role_order": [1, 0, 2, 3],
            "role_order_explicit": True,
        },
    ]

    homfly_exit = main(
        [
            "homfly-pd",
            str(exported_signed_pd),
            "--max-depth",
            "8",
            "--max-nodes",
            "2048",
        ]
    )
    homfly = json.loads(capsys.readouterr().out)

    alexander_exit = main(
        [
            "multivariable-alexander-pd",
            str(exported_signed_pd),
            "--max-minors",
            "64",
        ]
    )
    alexander = json.loads(capsys.readouterr().out)

    status_exit = main(
        [
            "imgui-signed-pd-invariant-status-payload",
            str(exported_signed_pd),
            "--max-depth",
            "8",
            "--max-nodes",
            "2048",
        ]
    )
    status_payload = json.loads(capsys.readouterr().out)

    assert homfly_exit == 0
    assert homfly["input"]["input_shape"] == "imgui_signed_pd"
    assert homfly["input"]["role_order"] == [1, 0, 2, 3]
    assert homfly["input"]["signed_pd_revision"] == exported_payload["signed_pd_revision"]
    assert homfly["homfly_polynomial"] == "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z"
    assert homfly["skipped"] is False

    assert alexander_exit == 0
    assert alexander["input"]["input_shape"] == "imgui_signed_pd"
    assert alexander["input"]["role_order"] == [1, 0, 2, 3]
    assert alexander["input"]["signed_pd_revision"] == exported_payload["signed_pd_revision"]
    assert alexander["multivariable_alexander_polynomial"] == "1"
    assert alexander["skipped"] is False

    assert status_exit == 0
    assert status_payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert status_payload["source_signed_pd"].endswith("imgui_signed_pd_export.json")
    assert status_payload["signed_pd_revision"] == exported_payload["signed_pd_revision"]
    statuses = {status["name"]: status for status in status_payload["invariant_statuses"]}
    assert statuses["HOMFLY-PT"]["value"] == homfly["homfly_polynomial"]
    assert statuses["multi-variable Alexander"]["value"] == (
        alexander["multivariable_alexander_polynomial"]
    )
    assert status_payload["invariant_passed_check_count"] == 2


def test_optional_gpu_package_exposes_explicit_segment_distance_kernel() -> None:
    source = (
        ROOT / "native/iroll-kernels-gpu/iroll_kernels_gpu/__init__.py"
    ).read_text(encoding="utf-8")
    readme = (ROOT / "native/iroll-kernels-gpu/README.md").read_text(encoding="utf-8")
    smoke = (
        ROOT / "native/iroll-kernels-gpu/examples/gpu_smoke.py"
    ).read_text(encoding="utf-8")

    assert "import cupy as cp" in source
    assert "def segment_segment_distance" in source
    assert "def segment_segment_distances" in source
    assert "def segment_intersections_2d" in source
    assert "def segment_bbox_candidate_pairs_2d" in source
    assert "def segment_bbox_candidate_pairs_3d" in source
    assert "def compute_writhe" in source
    assert "def compute_gaussian_linking_number" in source
    assert "def backend_info" in source
    assert "cp.RawKernel" in source
    assert "raw_cuda_kernels" in source
    assert "raw_cuda_block_count_then_raw_kernel_fill" in source
    assert "iroll_bbox_candidate_pairs_2d_count_kernel" in source
    assert "iroll_bbox_candidate_pairs_3d_count_kernel" in source
    assert "_candidate_pair_count_2d_chunked" in source
    assert "cuda_runtime_version" in source
    assert "compute_capability" in source
    assert 'backend="auto"' in readme
    assert "must not select GPU automatically" in readme
    assert "imgui-analysis-summary-payload gpu-smoke-no-cuda.json" in readme
    assert "imgui-host-payload --analysis-report-json gpu-smoke-no-cuda.json" in readme
    assert "gpu-smoke-no-cuda-imgui-host.json" in readme
    assert "`analysis` section of the host bundle" in readme
    assert "backend=\"gpu\"" in smoke
    assert "backend=\"numpy\"" in smoke
    assert "--allow-unavailable" in smoke
    assert "--force-unavailable" in smoke
    assert "compute_gaussian_linking_number" in smoke
    assert "artifact_schema_version" in smoke
    assert "required_capabilities" in smoke
    assert "required_capability_count" in smoke
    assert "passed_check_count" in smoke
    assert "failed_check_count" in smoke
    assert "max_abs_error" in smoke
    assert "max_rel_error" in smoke
    assert "exact_match" in smoke
    assert "release_grade_speedup_claimed" in smoke
    assert "gpu_dispatch_parity_smoke_claimed" in smoke
    assert "cuda_parity_claimed" in smoke
    assert "artifact_kind" in smoke
    assert "execution_path" in smoke
    assert "environment_metadata" in smoke
    assert "environment_witness" in smoke
    assert "repo_source_present" in smoke
    assert "importlib_spec_present" in smoke
    assert "cuda_runtime_observed" in smoke
    assert "simulated_parity_failure" in smoke
    assert "evidence" in smoke
    assert "small GPU smoke claim is limited to GPU dispatch parity" in smoke
    assert "not CUDA parity or release-grade speedup" in smoke


def test_optional_gpu_smoke_script_runs_when_installed() -> None:
    gpu_backend = backend_report()["backends"]["gpu"]
    if not gpu_backend["available"] or "backend_info_error" in gpu_backend:
        pytest.skip("GPU kernels are not available in this environment")

    script = ROOT / "native/iroll-kernels-gpu/examples/gpu_smoke.py"
    result = subprocess.run(
        [sys.executable, str(script)],
        cwd=ROOT,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        check=False,
        timeout=120,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    payload = json.loads(result.stdout)
    assert payload["available"] is True
    assert payload["matched"] is True
    assert payload["artifact_schema_version"] == 1
    assert payload["artifact_kind"] == "gpu_smoke_parity_result"
    assert payload["execution_path"] == "gpu_backend_parity"
    assert payload["environment_metadata"] == {
        "gpu_package_optional": True,
        "gpu_backend_import_attempted": True,
        "gpu_backend_available": True,
        "forced_unavailable": False,
        "backend_info_available": True,
        "unavailable_error_type": None,
    }
    assert payload["environment_witness"]["schema_version"] == 1
    assert payload["environment_witness"]["package"]["repo_source_present"] is True
    assert payload["environment_witness"]["backend"]["import_attempted"] is True
    assert payload["environment_witness"]["backend"]["imported"] is True
    assert payload["environment_witness"]["backend"]["backend_info_observed"] is True
    assert payload["environment_witness"]["backend"]["backend_info_backend"] == "cupy"
    assert payload["environment_witness"]["runtime"]["cuda_runtime_observed"] is True
    assert payload["environment_witness"]["runtime"]["device_count_observed"] is True
    assert payload["environment_witness"]["runtime"]["device_name_observed"] is True
    assert payload["environment_witness"]["simulation"] == {
        "forced_unavailable": False,
        "simulated_parity_failure": False,
    }
    assert payload["evidence"] == {
        "gpu_dispatch_parity": True,
        "no_cuda_boundary": False,
        "cuda_parity": False,
        "release_grade_speedup": False,
    }
    assert payload["claim_scope"] == "gpu_dispatch_parity_smoke"
    assert payload["gpu_dispatch_parity_smoke_claimed"] is True
    assert payload["gpu_dispatch_parity_smoke_claimed"] == payload["evidence"][
        "gpu_dispatch_parity"
    ]
    assert payload["cuda_parity_claimed"] is False
    assert payload["required_capabilities"] == [
        "segment_segment_distance",
        "segment_segment_distances",
        "segment_intersections_2d",
        "segment_bbox_candidate_pairs_2d",
        "segment_bbox_candidate_pairs_3d",
        "compute_writhe",
        "compute_gaussian_linking_number",
    ]
    assert payload["required_capability_count"] == 7
    assert payload["required_capability_count"] == len(
        payload["required_capabilities"]
    )
    assert payload["parity_check_count"] == 7
    assert payload["passed_check_count"] == 7
    assert payload["failed_check_count"] == 0
    assert payload["release_grade_speedup_claimed"] is False
    assert {check["name"] for check in payload["check_results"]} == set(
        payload["required_capabilities"]
    )
    assert all(check["matched"] is True for check in payload["check_results"])
    for check in payload["check_results"]:
        assert check["max_abs_error"] >= 0.0
        assert check["max_rel_error"] >= 0.0
        assert isinstance(check["exact_match"], bool)
    assert payload["backend_info"]["raw_cuda_kernels"] == {
        "segment_segment_distances": True,
        "segment_intersections_2d": True,
        "segment_bbox_candidate_pairs_2d": True,
        "segment_bbox_candidate_pairs_3d": True,
        "segment_bbox_candidate_pairs_2d_count": True,
        "segment_bbox_candidate_pairs_3d_count": True,
        "segment_bbox_candidate_pairs_2d_fill": True,
        "segment_bbox_candidate_pairs_3d_fill": True,
    }
    assert payload["backend_info"]["candidate_pair_compaction"]["strategy"] == (
        "raw_cuda_block_count_then_raw_kernel_fill"
    )
    assert payload["backend_info"]["candidate_pair_compaction"]["count_pass"] == (
        "raw_cuda_block_count"
    )
    assert payload["backend_info"]["candidate_pair_compaction"][
        "count_pass_runs_on_gpu"
    ] is True
    assert payload["backend_info"]["candidate_pair_compaction"][
        "count_pass_reduces_block_counts_on_host"
    ] is True
    assert payload["backend_info"]["candidate_pair_compaction"][
        "fill_pass_allocates_accepted_pairs_only"
    ] is True
    assert set(payload["checks"]) == {
        "segment_segment_distance",
        "segment_segment_distances",
        "segment_intersections_2d",
        "segment_bbox_candidate_pairs_2d",
        "segment_bbox_candidate_pairs_3d",
        "compute_writhe",
        "compute_gaussian_linking_number",
    }


def test_optional_gpu_smoke_script_can_report_unavailable() -> None:
    script = ROOT / "native/iroll-kernels-gpu/examples/gpu_smoke.py"
    result = subprocess.run(
        [
            sys.executable,
            str(script),
            "--allow-unavailable",
            "--force-unavailable",
        ],
        cwd=ROOT,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        check=False,
        timeout=60,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    payload = json.loads(result.stdout)
    assert payload["available"] is False
    assert payload["matched"] is False
    assert payload["artifact_schema_version"] == 1
    assert payload["artifact_kind"] == "gpu_smoke_unavailable_boundary"
    assert payload["execution_path"] == "optional_gpu_unavailable"
    assert payload["environment_metadata"] == {
        "gpu_package_optional": True,
        "gpu_backend_import_attempted": False,
        "gpu_backend_available": False,
        "forced_unavailable": True,
        "backend_info_available": False,
        "unavailable_error_type": "ImportError",
    }
    assert payload["environment_witness"]["schema_version"] == 1
    assert payload["environment_witness"]["package"]["repo_source_present"] is True
    assert payload["environment_witness"]["backend"]["import_attempted"] is False
    assert payload["environment_witness"]["backend"]["imported"] is False
    assert payload["environment_witness"]["backend"]["backend_info_observed"] is False
    assert payload["environment_witness"]["runtime"]["cuda_runtime_observed"] is False
    assert payload["environment_witness"]["runtime"]["device_count_observed"] is False
    assert payload["environment_witness"]["simulation"] == {
        "forced_unavailable": True,
        "simulated_parity_failure": False,
    }
    assert payload["environment_witness"]["unavailable_error_type"] == "ImportError"
    assert payload["evidence"] == {
        "gpu_dispatch_parity": False,
        "no_cuda_boundary": True,
        "cuda_parity": False,
        "release_grade_speedup": False,
    }
    assert payload["claim_scope"] == "optional_no_cuda_boundary"
    assert payload["gpu_dispatch_parity_smoke_claimed"] is False
    assert payload["gpu_dispatch_parity_smoke_claimed"] == payload["evidence"][
        "gpu_dispatch_parity"
    ]
    assert payload["cuda_parity_claimed"] is False
    assert payload["parity_check_count"] == 0
    assert payload["passed_check_count"] == 0
    assert payload["failed_check_count"] == 0
    assert payload["check_results"] == []
    assert payload["release_grade_speedup_claimed"] is False
    assert payload["required_capabilities"] == [
        "segment_segment_distance",
        "segment_segment_distances",
        "segment_intersections_2d",
        "segment_bbox_candidate_pairs_2d",
        "segment_bbox_candidate_pairs_3d",
        "compute_writhe",
        "compute_gaussian_linking_number",
    ]
    assert payload["required_capability_count"] == 7
    assert payload["required_capability_count"] == len(
        payload["required_capabilities"]
    )
    assert "forced unavailable GPU smoke path" in payload["error"]


def test_api_examples_document_host_invariant_report_bundle() -> None:
    docs = (ROOT / "docs/api-examples.md").read_text(encoding="utf-8")

    assert "imgui_invariant_status_payload_from_reports([report])" in docs
    assert "imgui_host_payload_from_acceptance_reports" in docs
    assert "invariant_reports=[report]" in docs
    assert 'bundle["invariants"]["method"]' in docs
    assert "imgui_invariant_status_payload_from_reports" in docs
    assert 'bundle["analysis"]["analysis_summary_count"] == 0' in docs


def test_report_schema_documents_homfly_frontier_distribution_imgui_notes() -> None:
    docs = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")

    assert "frontier_reason_counts=max_nodes:6/12" in docs
    assert (
        "truncated_source_kind_counts=fixture_root:1,one_step_skein_branch:5"
        in docs
    )
    assert "host display" in docs
    assert "bounded generated small-diagram coverage" in docs
    assert "bounded_homfly_maturity_path_evidence" in docs
    assert "homfly_bounded_maturity_path_evidence" in docs
    assert "bounded_maturity_path_classification_diagnostics" in docs


def test_report_schema_documents_validation_pack_imgui_analysis_bridge() -> None:
    docs = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")

    assert "cross_workstream_validation_pack_audit" in docs
    assert "final_completion_checklist_metadata_audit" in docs
    assert "validation_pack_audit_available_count" in docs
    assert "fixture registration/open-gate counters" in docs
    assert "validation_pack=fixtures=..." in docs
    assert "final_completion_open_gate_blocker_summary" in docs
    assert "final_completion_open_gate_blocker_summary_consistency" in docs
    assert "open_gate_blocker_summary=failed_gates=..." in docs
    assert "final_completion_open_gate_blocker_summary_detail_consistency" in docs
    assert (
        "analysis_final_completion_open_gate_blocker_summary_detail_consistency_*"
        in docs
    )
    assert "open_gate_blocker_summary_detail=gates=..." in docs
    assert "final_completion_blocker_code_consistency" in docs
    assert "analysis_final_completion_blocker_code_consistency_*" in docs
    assert "blocker_code_consistency=codes=..." in docs
    assert "final_completion_blocker_code_summary" in docs
    assert (
        "analysis_final_completion_blocker_code_summary_detail_consistency_*"
        in docs
    )
    assert "blocker_code_summary_detail=rows=..." in docs
    assert "final_completion_blocker_kind_summary" in docs
    assert "final_completion_blocker_kind_consistency" in docs
    assert "final_completion_blocker_kind_summary_detail_consistency" in docs
    assert "analysis_final_completion_blocker_kind_*" in docs
    assert (
        "analysis_final_completion_blocker_kind_summary_detail_consistency_*"
        in docs
    )
    assert "blocker_kind_consistency=kinds=..." in docs
    assert "blocker_kind_summary_detail=rows=..." in docs
    assert "final_completion_required_check_consistency" in docs
    assert "analysis_final_completion_required_check_*" in docs
    assert "required_check_consistency=required=..." in docs
    assert "final_completion_required_diagram_fixture_metadata_consistency" in docs
    assert (
        "analysis_final_completion_required_diagram_fixture_metadata_consistency_*"
        in docs
    )
    assert "required_fixture_metadata_consistency=required=..." in docs
    assert "final_completion_signed_fixture_consistency" in docs
    assert "analysis_final_completion_signed_fixture_consistency_*" in docs
    assert "signed_fixture_consistency=blockers=..." in docs
    assert (
        "analysis_final_completion_signed_fixture_consistency_source_candidate_matching_candidate_count_total"
        in docs
    )
    assert "source_candidate_matches=..." in docs
    assert "final_completion_non_diagram_requirement_consistency" in docs
    assert (
        "analysis_final_completion_non_diagram_requirement_consistency_*"
        in docs
    )
    assert "non_diagram_requirement_consistency=requirements=..." in docs
    assert "final_completion_non_claim_gate_consistency" in docs
    assert "analysis_final_completion_non_claim_gate_consistency_*" in docs
    assert "non_claim_gate_consistency=fields=..." in docs
    assert "final_completion_completion_gate_evidence_consistency" in docs
    assert (
        "analysis_final_completion_completion_gate_evidence_consistency_*"
        in docs
    )
    assert "completion_gate_evidence_consistency=gates=..." in docs
    assert "analysis_retained_evidence_*" in docs
    assert "retained_evidence_non_claim_consistency" in docs
    assert "analysis_retained_evidence_non_claim_consistency_*" in docs
    assert "retained_evidence_non_claim=entries=..." in docs
    assert "retained_evidence_artifact_file_consistency" in docs
    assert "analysis_retained_evidence_artifact_file_consistency_*" in docs
    assert "retained_evidence_artifact_files=entries=..." in docs
    assert "retained_evidence_kinds=ci_retained_artifact:7|repository_test:4" in docs
    assert "final_completion_gate_blocker_consistency" in docs
    assert "analysis_final_completion_gate_blocker_*" in docs
    assert "gate_blocker_consistency=checked=..." in docs
    assert "final_completion_blocker_evidence_links" in docs
    assert "final_completion_blocker_evidence_link_consistency" in docs
    assert "analysis_final_completion_blocker_evidence_*" in docs
    assert "blocker_evidence_links=linked=..." in docs
    assert "labels=...; codes=...; missing=...; required=...; current=..." in docs
    assert "final_completion_blocker_evidence_link_kind_summary" in docs
    assert (
        "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_*"
        in docs
    )
    assert "blocker_evidence_link_kind_detail=rows=..." in docs
    assert "final_completion_missing_artifact_summary" in docs
    assert "final_completion_missing_artifact_summary_consistency" in docs
    assert "final_completion_missing_artifact_summary_detail_consistency" in docs
    assert "analysis_final_completion_missing_artifact_*" in docs
    assert (
        "analysis_final_completion_missing_artifact_summary_detail_consistency_*"
        in docs
    )
    assert "missing_artifact_summary=refs=..." in docs
    assert "missing_artifact_summary_detail=rows=..." in docs
    assert "final_completion_blocker_evidence_field_summary" in docs
    assert "final_completion_blocker_evidence_field_consistency" in docs
    assert (
        "final_completion_blocker_evidence_field_summary_detail_consistency"
        in docs
    )
    assert "analysis_final_completion_blocker_evidence_field_*" in docs
    assert (
        "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_*"
        in docs
    )
    assert "blocker_evidence_fields=summary_rows=..." in docs
    assert "blocker_evidence_field_summary_detail=rows=..." in docs
    assert "not invariant computation" in docs
    assert "final_completion_ready=false" in docs
    assert "production_imgui_renderer_verified=false" in docs


def test_report_schema_documents_imgui_framebuffer_smoke_analysis_bridge() -> None:
    docs = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")

    assert "imgui_test_stub_framebuffer_smoke" in docs
    assert "imgui-analysis-summary-payload" in docs
    assert "imgui-host-payload --analysis-report-json" in docs
    assert "imgui_framebuffer_smoke_*" in docs
    assert "analysis_imgui_framebuffer_smoke_*" in docs
    assert "repository_test_stub=true" in docs
    assert "draw_list_framebuffer_estimate=true" in docs
    assert "real_graphics_backend_framebuffer_verified=false" in docs
    assert "screenshot_verified=false" in docs
    assert "production_renderer_verified=false" in docs
    assert "not production" in docs
    assert "Dear ImGui ABI 116" in docs


def test_report_schema_documents_imgui_source_open_request_analysis_bridge() -> None:
    docs = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")

    assert "imgui_source_open_request_smoke" in docs
    assert "imgui-analysis-summary-payload" in docs
    assert "imgui-host-payload --analysis-report-json" in docs
    assert "imgui_source_open_request_smoke_*" in docs
    assert "analysis_imgui_source_open_request_smoke_*" in docs
    assert "host_action=open_source_url" in docs
    assert "opened_by_real_host=false" in docs
    assert "scheme_allowed=true" in docs
    assert "request_consumed_by_smoke=true" in docs
    assert "request_cleared_after_consumption=true" in docs
    assert "final_request_pending=true" in docs
    assert "imgui_source_open_request_smoke_selected_fixture_name=3_1" in docs
    assert "imgui_source_open_request_smoke_selected_fixture_source=Knot Atlas" in docs
    assert (
        "imgui_source_open_request_smoke_source_url=https://katlas.org/wiki/3_1"
        in docs
    )
    assert "imgui_source_open_request_smoke_consumed_source_url_matched=true" in docs
    assert "not production platform URL-opening evidence" in docs
    assert "Dear ImGui ABI 116" in docs


def test_report_schema_documents_imgui_signed_pd_scheduler_analysis_bridge() -> None:
    docs = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")

    assert "imgui_signed_pd_recompute_scheduler_smoke" in docs
    assert "host_owned_signed_pd_recompute_scheduler_contract" in docs
    assert "imgui-analysis-summary-payload" in docs
    assert "imgui-host-payload --analysis-report-json" in docs
    assert "imgui_signed_pd_recompute_scheduler_smoke_*" in docs
    assert "analysis_imgui_signed_pd_recompute_scheduler_smoke_*" in docs
    assert "stale_recompute_rejected=true" in docs
    assert "current_revision_reloaded=true" in docs
    assert "requested_snapshot_json_cleared=true" in docs
    assert "handoff_input_format=imgui_signed_pd_json" in docs
    assert "handoff_result_transport=json_file" in docs
    assert "host_reload_payload=imgui-signed-pd-invariant-status-payload" in docs
    assert "not native HOMFLY/Alexander C++ computation evidence" in docs
    assert "Dear ImGui ABI 116" in docs


def test_report_schema_documents_imgui_signed_pd_thread_pool_scheduler_analysis_bridge() -> None:
    docs = (ROOT / "docs/report-schema.md").read_text(encoding="utf-8")

    assert "imgui_signed_pd_thread_pool_recompute_scheduler_smoke" in docs
    assert "host_owned_thread_pool_signed_pd_recompute_scheduler_contract" in docs
    assert "imgui-analysis-summary-payload" in docs
    assert "imgui-host-payload --analysis-report-json" in docs
    assert "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_*" in docs
    assert "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_*" in docs
    assert "thread_pool_worker_count=2" in docs
    assert "stale_recompute_rejected=true" in docs
    assert "current_revision_reloaded=true" in docs
    assert "requested_snapshot_json_cleared=true" in docs
    assert "progress_completed=true" in docs
    assert "progress_active_after_completion=false" in docs
    assert "handoff_input_format=imgui_signed_pd_json" in docs
    assert "handoff_result_transport=json_file" in docs
    assert "host_reload_payload=imgui-signed-pd-invariant-status-payload" in docs
    assert "not native HOMFLY/Alexander C++ computation evidence" in docs
    assert "Dear ImGui ABI 116" in docs


def test_native_release_ci_workflow_covers_wheel_parity_and_optional_gpu() -> None:
    workflow = (ROOT / ".github/workflows/native-kernels-ci.yml").read_text(
        encoding="utf-8"
    )
    docs = (ROOT / "docs/native-release-ci.md").read_text(encoding="utf-8")
    rust_kernel_docs = (ROOT / "docs/rust-kernel-interface.md").read_text(
        encoding="utf-8"
    )
    report_schema_docs = (ROOT / "docs/report-schema.md").read_text(
        encoding="utf-8"
    )
    execution_status_docs = (
        ROOT / "docs/remaining-deep-execution-status.md"
    ).read_text(encoding="utf-8")

    for required in [
        "base-python",
        "rust-wheel-and-parity",
        "gpu-contract-without-cuda",
        "python -m pytest -q",
        "python benchmarks/core_bench.py --matrix",
        "--speedup-threshold 1.25",
        "--min-release-repeat 3",
        "numpy-benchmark-matrix.json",
        "Verify NumPy benchmark matrix artifact contract",
        "iroll_core_benchmark_speedup_evidence",
        'speedup["repeat"] == 1',
        'speedup["minimum_repeat_for_release_claim"] == 3',
        'speedup["speedup_threshold"] == 1.25',
        'release_gate["repeat_satisfied"] is False',
        "repeat_below_minimum",
        "release_gate",
        "release_gate[\"release_grade_speedup_claimed\"] is False",
        "gpu[\"minimum_repeat_for_release_claim\"] == 3",
        "gpu[\"repeat_satisfied\"] is False",
        'gpu["gpu_requested_row_count"] == 0',
        'gpu["release_grade_gpu_speedup_claimed"] is False',
        "Verify NumPy benchmark matrix ImGui analysis bridge",
        "python -m iroll.cli imgui-analysis-summary-payload numpy-benchmark-matrix.json",
        "numpy-benchmark-matrix-imgui-analysis.json",
        "Verify NumPy benchmark matrix ImGui host payload bridge",
        "python -m iroll.cli imgui-host-payload --analysis-report-json numpy-benchmark-matrix.json",
        "numpy-benchmark-matrix-imgui-host.json",
        "imgui_host_payload",
        'payload["analysis_benchmark_matrix_completed_row_count"] == 4',
        'payload["analysis_benchmark_matrix_failed_row_count"] == 0',
        (
            'payload["analysis_benchmark_speedup_release_grade_'
            'claimed_count"] == 0'
        ),
        'payload["analysis_benchmark_cuda_gpu_completed_row_count"] == 0',
        (
            'payload["analysis_benchmark_cuda_gpu_release_grade_'
            'speedup_claimed_count"] == 0'
        ),
        'analysis["analysis_benchmark_matrix_completed_row_count"] == 4',
        'analysis["analysis_benchmark_matrix_failed_row_count"] == 0',
        (
            'analysis["analysis_benchmark_cuda_gpu_release_grade_'
            'speedup_claimed_count"] == 0'
        ),
        "Export validation-pack audit ImGui artifacts",
        "fixture-validation-pack-audit -o validation-pack-audit.json",
        "imgui-analysis-summary-payload validation-pack-audit.json",
        "imgui-host-payload --analysis-report-json validation-pack-audit.json",
        "validation-pack-audit-imgui-analysis.json",
        "validation-pack-audit-imgui-host.json",
        "cross_workstream_validation_pack_audit",
        "analysis_validation_pack_audit_available_count",
        "analysis_unsigned_required_fixture_count",
        "analysis_open_non_diagram_requirement_count",
        'analysis["analysis_final_completion_gate_count"] == 7',
        'analysis["analysis_final_completion_failed_gate_count"] == 6',
        'analysis["analysis_final_completion_blocker_count"] == 7',
        'analysis["analysis_final_completion_ready_count"] == 0',
        'host_analysis["analysis_final_completion_gate_count"] == 7',
        'host_analysis["analysis_final_completion_failed_gate_count"] == 6',
        'host_analysis["analysis_final_completion_blocker_count"] == 7',
        'host_analysis["analysis_final_completion_ready_count"] == 0',
        "required_check_consistency=required=3; passed=1",
        "retained_evidence_artifact_files=entries=10; artifact_entries=2",
        "missing_artifact_summary_detail=rows=5; unique=5; blockers=7",
        "final_completion_gate_checks",
        "final_completion_blocker_signature",
        "signed_fixture_blockers",
        "signed_pd_not_registered",
        "source_table_unsigned_fixture_pending_sign_registration",
        "no verified signed crossing assignment",
        "native ImGui screenshot/framebuffer fixtures",
        "noisy sampled curves",
        "high-point-count performance curves",
        "full_homfly_pt_evaluation_certified",
        "full_multivariable_alexander_normalization_certified",
        "Export completion evidence CI plan artifacts",
        "completion-evidence-requirements -o completion-evidence-requirements.json",
        "completion-evidence-contracts -o completion-evidence-contracts.json",
        "completion-evidence-ci-plan -o completion-evidence-ci-plan.json",
        "completion-evidence-templates --expand-repeatable --directory completion-evidence-templates",
        "completion-evidence-directory-audit completion-evidence-templates --validate-artifacts --bundle-output completion-evidence-template-bundle.json",
        (
            "completion-evidence-review-bundle completion-evidence-review-bundle "
            "-o completion-evidence-review-bundle.json"
        ),
        (
            "completion-evidence-directory-audit completion-evidence-review-bundle "
            "-o completion-evidence-review-directory-audit.json"
        ),
        "completion-evidence-requirements.json",
        "completion-evidence-contracts.json",
        "completion-evidence-ci-plan.json",
        "completion-evidence-review-bundle.json",
        "completion-evidence-review-directory-audit.json",
        "completion-evidence-templates.json",
        "completion-evidence-template-bundle.json",
        "completion-evidence-template-directory-audit.json",
        "completion-evidence-templates/*.template.json",
        "completion-evidence-review-bundle/*.json",
        "completion-evidence-review-bundle/completion-evidence-templates/*.json",
        'requirements["required_artifact_count"] == 5',
        'requirements["final_completion_failed_gates"] == [',
        'requirements["final_completion_failed_gate_signature"] == (',
        'requirements["final_completion_blocker_code_counts"] == {',
        'requirements["final_completion_missing_artifact_count"] == 5',
        'requirements["required_missing_artifact_signature"]',
        'requirements["final_completion_missing_artifact_signature"] == requirements[',
        'requirements["producer_readiness_count"] == 6',
        'requirements["producer_readiness_blocker_occurrence_count"] == 37',
        'requirements["producer_readiness_blocker_code_counts"]',
        'requirements["producer_readiness_blocker_count_signature"]',
        'requirements["retained_evidence_count"] == 10',
        'requirements["retained_evidence_distinct_count"] == 8',
        'requirements["retained_evidence_kinds"] == [',
        'requirements["retained_evidence_repository_test_count"] == 4',
        'requirements["retained_evidence_ci_retained_artifact_count"] == 6',
        'requirements["retained_evidence_completion_claimed_count"] == 0',
        'requirements["retained_evidence_signed_release_artifacts_published_count"] == 0',
        'requirements["retained_evidence_real_graphics_backend_framebuffer_verified_count"] == 0',
        'requirements["retained_evidence_screenshot_verified_count"] == 0',
        'requirements["required_instance_labels"] == ["L5a1", "L6a4"]',
        'contracts["contract_count"] == 5',
        'contracts["required_artifact_count"] == 5',
        'contracts["required_missing_artifact_signature"] == requirements[',
        'contracts["expected_evidence_filename_count"] == 6',
        'contracts["expected_evidence_filenames"] == requirements[',
        'contracts["bundle_all_inputs_command"] == requirements[',
        'contracts["final_completion_failed_gate_signature"] == requirements[',
        'contracts["final_completion_blocker_code_counts"] == requirements[',
        'contracts["final_completion_missing_artifact_signature"] == requirements[',
        'contracts["producer_readiness_count"] == requirements[',
        'contracts["producer_readiness_blocker_occurrence_count"] == requirements[',
        'contracts["retained_evidence_distinct_count"] == requirements[',
        'contracts["retained_evidence_completion_claimed_count"] == 0',
        'contracts["contract_instance_row_count"] == 6',
        "contract_instance_rows",
        'contract_rows["production_imgui_renderer_framebuffer_pack"]',
        'contract_instance_rows[',
        "cross_workstream_completion_evidence_contracts",
        "field_rules",
        "preflight_checks",
        "field_rule_preflight_links",
        "contract_preflight_consistency_passed",
        "repeatable_instance_coverage_required",
        "required_instance_labels",
        "source_url_http",
        "screenshot_url_http",
        "sha256_hex_64",
        'plan["required_artifact_count"] == 5',
        'plan["required_missing_artifact_signature"] == requirements[',
        'plan["final_completion_failed_gate_signature"] == requirements[',
        'plan["final_completion_blocker_code_counts"] == requirements[',
        'plan["final_completion_missing_artifact_signature"] == requirements[',
        'plan["producer_readiness_blocker_occurrence_count"] == requirements[',
        'plan["producer_readiness_blocker_code_counts"] == requirements[',
        'plan["retained_evidence_distinct_count"] == requirements[',
        'plan["retained_evidence_completion_claimed_count"] == 0',
        'len(plan["artifact_preflight_commands"]) == 5',
        'len(plan["artifact_bundle_input_examples"]) == 5',
        'len(plan["artifact_template_filenames"]) == 5',
        'len(plan["artifact_command_rows"]) == 5',
        'plan["artifact_command_row_count"] == 5',
        'plan["artifact_instance_command_row_count"] == 6',
        'plan["expected_evidence_filename_count"] == 6',
        "expected_evidence_filenames",
        "bundle_all_inputs_command",
        "directory_audit_command",
        "final_validation_command",
        "artifact_preflight_commands",
        "artifact_bundle_input_examples",
        "artifact_template_filenames",
        "artifact_command_rows",
        "artifact_instance_command_rows",
        "plan_instance_rows",
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.template.json",
        "template_to_artifact_filename",
        "verified_signed_crossing_assignment.L6a4.json",
        "plan_command_rows",
        "verified-signed-crossing-assignment-readiness",
        "verified-signed-crossing-assignment-readiness.json",
        "production-imgui-renderer-framebuffer-readiness",
        "production-imgui-renderer-framebuffer-readiness.json",
        "signed-release-publication-readiness",
        "signed-release-publication-readiness.json",
        "full-homfly-pt-evaluation-readiness",
        "full-homfly-pt-evaluation-readiness.json",
        "full-multivariable-alexander-normalization-readiness",
        "full-multivariable-alexander-normalization-readiness.json",
        'plan["plan_step_count"] == 13',
        "verified_signed_crossing_assignment_readiness_report",
        "production_imgui_renderer_framebuffer_readiness_report",
        "signed_release_publication_readiness_report",
        "full_homfly_pt_evaluation_readiness_report",
        "full_multivariable_alexander_normalization_readiness_report",
        "cross_workstream_completion_evidence_review_bundle",
        "publish_review_bundle",
        "preflight_signed_assignment_readiness",
        "preflight_production_imgui_framebuffer_readiness",
        "preflight_signed_release_publication_readiness",
        "preflight_full_homfly_pt_evaluation_readiness",
        "preflight_full_multivariable_alexander_normalization_readiness",
        "readiness_all_ready",
        "readiness_blocker_codes",
        "readiness_blocker_signature",
        "retained_repository_test_count",
        "retained_registered_fixture_scope_count",
        "retained_bounded_scope_count",
        "retained_real_graphics_backend_framebuffer_verified_count",
        "retained_screenshot_verified_count",
        "retained_signed_release_artifacts_published_count",
        "retained_publication_claimed_count",
        "retained_platform_index_publication_claimed_count",
        "external_source_assignment_verified:2,",
        "estimated_nonzero_pixels,framebuffer_height,framebuffer_touched,",
        "artifact_urls,package_index_url,platform_index_publication_claimed,",
        "arbitrary_signed_pd_coverage_certified,certification_report_url,",
        "admissible_minor_normalization_certified,",
        'readiness_rows["L5a1"]["unique_sign_pattern_count"] == 12',
        'readiness_rows["L6a4"]["unique_sign_pattern_count"] == 8',
        'assignment_readiness["completion_evidence_artifact_filenames"] == [',
        'imgui_readiness["retained_stub_framebuffer_smoke_count"] == 1',
        'imgui_readiness["completion_evidence_artifact_filenames"] == [',
        'release_readiness["retained_unsigned_ci_release_manifest_count"] == 1',
        'release_readiness["completion_evidence_artifact_filenames"] == [',
        'homfly_readiness["retained_repository_test_count"] == 2',
        'homfly_readiness["completion_evidence_artifact_filenames"] == [',
        'alexander_readiness["retained_repository_test_count"] == 2',
        'alexander_readiness["completion_evidence_artifact_filenames"] == [',
        'review_bundle["artifact_kind"] == (',
        "cross_workstream_completion_evidence_review_bundle",
        'review_bundle["final_completion_failed_gate_signature"] == requirements[',
        'review_bundle["final_completion_blocker_code_counts"] == requirements[',
        'review_bundle["final_completion_missing_artifact_signature"] == requirements[',
        'review_bundle["producer_readiness_blocker_occurrence_count"] == requirements[',
        'review_bundle["producer_readiness_blocker_code_counts"] == requirements[',
        'review_bundle["artifact_command_row_count"] == 5',
        'review_bundle["artifact_instance_command_row_count"] == 6',
        'review_bundle["expected_evidence_filename_count"] == 6',
        'review_bundle["bundle_all_inputs_command"] == plan[',
        'review_bundle["generated_report_count"] == 13',
        'review_bundle["traceability_report_count"] == 10',
        "traceability_artifact_filename_signatures_by_report",
        'review_bundle["source_candidate_diagnostic_count"] == 2',
        "source-invariant-l5a1-candidates.json",
        "source-invariant-l6a4-candidates.json",
        'review_rows["completion-evidence-contracts.json"]',
        '"contract_instance_row_count"',
        '"expected_evidence_filename_signature"',
        '"template_to_artifact_filename_signature"',
        'review_rows["verified-signed-crossing-assignment-readiness.json"]',
        '"readiness_blocker_code_counts"',
        ']["unique_sign_pattern"] == 2',
        'review_rows["production-imgui-renderer-framebuffer-readiness.json"]',
        '"readiness_blocker_count"',
        "] == 9",
        '"completion_evidence_artifact_instance_row_count"',
        '"completion_evidence_final_completion_failed_gate_signature"',
        "real_graphics_backend_framebuffer_verified",
        "completion-evidence-template-directory-audit.json",
        'review_template_audit["completion_evidence_pipeline_ready"] is False',
        'review_bundle["template_directory_audit_pipeline_ready"] is False',
        'review_bundle["template_directory_audit_blocker_signature"] == (',
        "template_directory_audit_missing_instance_filenames",
        'review_directory["source_evidence_directory_kind"] == "review_bundle_handoff"',
        'review_directory["review_bundle_handoff_detected"] is True',
        'review_directory["review_bundle_not_final_evidence_directory"] is True',
        'review_directory["bundle_inputs_complete"] is False',
        'review_directory["missing_input_artifact_count"] == 6',
        'review_directory["missing_input_artifact_filenames"] == requirements[',
        'review_directory["missing_input_artifact_rows"][-1]',
        '"final_completion_failed_gates"',
        '["signed_diagram_fixture_registration"]',
        '"final_completion_blocker_labels"',
        'plan_instance_rows[("verified_signed_crossing_assignment", "L6a4")]',
        'plan_instance_rows[("production_imgui_renderer_framebuffer_pack", None)]',
        "completion_evidence_artifact_instance_rows",
        "completion_evidence_final_completion_failed_gates",
        "completion_evidence_final_completion_blocker_codes",
        'production_missing["final_completion_failed_gate_count"] == 2',
        '"native_imgui_screenshot_framebuffer_fixtures_partial"',
        '"production_imgui_renderer_not_verified"',
        'review_bundle["template_file_count"] == 6',
        'templates["required_artifact_count"] == 5',
        'templates["required_missing_artifact_signature"] == requirements[',
        'templates["expected_evidence_filename_count"] == 6',
        'templates["expected_evidence_filenames"] == requirements[',
        'templates["template_to_artifact_filenames"] == requirements[',
        'len(templates["template_to_artifact_rows"]) == 6',
        'templates["template_to_artifact_rows"][-1][',
        '"final_completion_blocker_labels"',
        "verified_signed_crossing_assignment.L6a4.json",
        'templates["bundle_all_inputs_command"] == requirements[',
        'templates["final_completion_failed_gate_signature"] == requirements[',
        'templates["final_completion_blocker_code_counts"] == requirements[',
        'templates["final_completion_missing_artifact_signature"] == requirements[',
        'templates["retained_evidence_distinct_count"] == requirements[',
        'templates["retained_evidence_completion_claimed_count"] == 0',
        'bundle["retained_evidence_distinct_count"] == requirements[',
        'bundle["retained_evidence_completion_claimed_count"] == 0',
        'bundle["expected_evidence_filename_count"] == 6',
        'bundle["expected_evidence_filenames"] == requirements[',
        'bundle["bundle_all_inputs_command"] == requirements[',
        'bundle["completion_evidence_artifact_instance_row_count"] == 6',
        'bundle["completion_evidence_artifact_filenames"] == requirements[',
        'directory["retained_evidence_distinct_count"] == requirements[',
        'directory["retained_evidence_completion_claimed_count"] == 0',
        'directory["expected_evidence_filename_count"] == 6',
        'directory["expected_evidence_filenames"] == requirements[',
        'directory["bundle_all_inputs_command"] == requirements[',
        'plan["hard_gate_steps"] == [',
        "bundle_evidence_failed_check_signature",
        "completion_evidence_pipeline_blocker_signature",
        "pipeline_failed_required_step_signature",
        'directory["artifact_preflight_failed_count"] == 6',
        'directory["artifact_preflight_field_coverage_complete"] is False',
        'directory["artifact_preflight_field_coverage_failed_count"] == 6',
        'directory["artifact_preflight_contract_coverage_complete"] is False',
        'directory["signed_assignment_notation_coverage_complete"] is False',
        "expected_instance_filenames",
        "present_instance_filenames",
        "missing_instance_filenames",
        "instance_filename_coverage_complete",
        'directory["missing_artifact_fields_by_path"]',
        'directory["completion_evidence_pipeline_blocker_count"] == 3',
        'directory["completion_evidence_pipeline_blocker_codes"] == [',
        'directory["completion_evidence_pipeline_blocker_signature"] == (',
        "required_instance_files_missing",
        "check_required_instance_files",
        'directory["pipeline_failed_required_step_count"] == 2',
        'directory["pipeline_failed_required_step_signature"] == (',
        'directory["pipeline_skipped_required_step_count"] == 0',
        'steps["preflight_discovered_artifacts"]["passed"] is False',
        "Upload validation-pack audit artifact",
        "iroll-validation-pack-audit-py${{ matrix.python-version }}",
        "Export validate-table source metadata ImGui artifacts",
        "validate-table-source-metadata-input.json",
        "validate-table-source-metadata.json",
        "validate-table-source-metadata-imgui-analysis.json",
        "validate-table-source-metadata-imgui-host.json",
        "validate-table-source-metadata-blocked-input.json",
        "validate-table-source-metadata-blocked.json",
        "validate-table-source-metadata-blocked-imgui-analysis.json",
        "validate-table-source-metadata-blocked-imgui-host.json",
        "validate-table-source-metadata-invalid-known-limitations-input.json",
        "validate-table-source-metadata-invalid-known-limitations.json",
        "validate-table-source-metadata-invalid-known-limitations-imgui-analysis.json",
        "validate-table-source-metadata-invalid-known-limitations-imgui-host.json",
        "validate-table-source-metadata-invalid-known-limitations-item-input.json",
        "validate-table-source-metadata-invalid-known-limitations-item.json",
        "validate-table-source-metadata-invalid-known-limitations-item-imgui-analysis.json",
        "validate-table-source-metadata-invalid-known-limitations-item-imgui-host.json",
        "validate-table-source-metadata-invalid-source-url-input.json",
        "validate-table-source-metadata-invalid-source-url.json",
        "validate-table-source-metadata-invalid-source-url-imgui-analysis.json",
        "validate-table-source-metadata-invalid-source-url-imgui-host.json",
        "validate-table-source-metadata-provenance-blockers-input.json",
        "validate-table-source-metadata-provenance-blockers.json",
        "validate-table-source-metadata-provenance-blockers-imgui-analysis.json",
        "validate-table-source-metadata-provenance-blockers-imgui-host.json",
        "validate-table validate-table-source-metadata-input.json",
        "validate-table validate-table-source-metadata-blocked-input.json",
        "validate-table validate-table-source-metadata-invalid-known-limitations-input.json",
        "validate-table validate-table-source-metadata-invalid-known-limitations-item-input.json",
        "validate-table validate-table-source-metadata-invalid-source-url-input.json",
        "validate-table validate-table-source-metadata-provenance-blockers-input.json",
        "--expected-convention iroll-test",
        "validate_table_source_metadata_report",
        'analysis_validate_table_source_metadata_artifact_count"] == 1',
        'analysis_validate_table_source_metadata_valid_count"] == 1',
        'analysis_validate_table_source_metadata_issue_count"] == 0',
        'analysis_validate_table_source_metadata_record_count"] == 2',
        "analysis_validate_table_source_metadata_source_value_label_count",
        "== 2",
        "analysis_validate_table_source_metadata_source_value_row_count_total",
        "analysis_validate_table_source_metadata_source_url_scheme_count",
        "== 1",
        "analysis_validate_table_source_metadata_source_url_domain_count",
        'analysis_validate_table_source_metadata_source_url_count"] == 2',
        "analysis_validate_table_source_metadata_source_url_count",
        "analysis_validate_table_source_metadata_valid_source_url_count",
        "analysis_validate_table_source_metadata_invalid_source_url_count",
        "analysis_validate_table_source_metadata_missing_source_count",
        "analysis_validate_table_source_metadata_missing_source_url_count",
        "analysis_validate_table_source_metadata_source_url_without_source_count",
        "analysis_validate_table_source_metadata_provenance_review_ready_count",
        "analysis_validate_table_source_metadata_provenance_blocker_count",
        "analysis_validate_table_source_metadata_summary_consistency_matched_count",
        "analysis_validate_table_source_metadata_blocker_summary_consistency_matched_count",
        "analysis_validate_table_source_metadata_known_limitations_count",
        "analysis_validate_table_source_metadata_convention_mismatch_count",
        "analysis_validate_table_source_metadata_table_correctness_certified_count",
        "analysis_validate_table_source_metadata_external_source_verified_count",
        "provenance_blocker_codes\"] == []",
        'provenance_blocker_codes"] == ["convention_mismatch"]',
        'provenance_blocker_codes"] == [',
        '"invalid_source_url"',
        '"missing_source"',
        '"missing_source_url"',
        '"source_url_without_source"',
        '"missing_convention"',
        'source_url_issue_code_counts"] == {',
        '"unsupported_scheme": 1',
        "table_correctness_certified",
        "external_source_verified",
        "Upload validate-table source metadata artifact",
        "iroll-validate-table-source-metadata-py${{ matrix.python-version }}",
        "Export source-table audit ImGui artifacts",
        "fixture-source-table-invariant-audit L6a4 --max-candidates 8",
        "fixture-source-table-invariant-audit L5a1 --max-candidates 24",
        "source-table-l6a4-audit.json",
        "source-table-l6a4-audit-imgui-analysis.json",
        "source-table-l6a4-audit-imgui-host.json",
        "source-table-l5a1-audit.json",
        "source-table-l5a1-audit-imgui-analysis.json",
        "source-table-l5a1-audit-imgui-host.json",
        "diagram_fixture_source_table_invariant_audit",
        "registered_fixture_invariant_claim",
        "source_table_registration_ready",
        "source_table_registration_blocker_count",
        "analysis_source_table_audit_source_match_resolution_status_count",
        (
            "source_table_audit_source_match_resolution_statuses\"] == "
            "\"jones:complete_source_match,homfly:source_missed_with_candidates,"
            "multivariable_alexander_numerator:complete_source_match\""
        ),
        (
            "source_table_audit_source_match_resolution_statuses\"] == "
            "\"jones:source_seen_with_incomplete_candidates,"
            "homfly:source_missed_with_candidates,"
            "multivariable_alexander_numerator:"
            "source_seen_with_incomplete_candidates\""
        ),
        "analysis_source_table_audit_registration_blocker_count",
        "analysis_source_table_audit_candidate_convergence_partial_certified_count",
        "analysis_source_table_audit_candidate_convergence_full_certified_count",
        "analysis_source_table_audit_candidate_convergence_certified_invariant_count",
        "analysis_source_table_audit_candidate_convergence_uncertified_invariant_count",
        "analysis_source_table_audit_candidate_convergence_source_value_seen_count",
        (
            "analysis_source_table_audit_candidate_convergence_"
            "source_value_seen_but_uncertified_count"
        ),
        "analysis_source_table_alexander_skipped_common_gcd_attempt_candidate_count",
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "support_signature_evidence_count\"] == 8"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "support_signature_variant_count\"] == 1"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "support_signature_input_count_min\"] == 25"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "support_signature_input_count_max\"] == 25"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_attempt_evidence_count\"] == 8"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_candidate_count_max\"] == 10"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_failed_candidate_count_max\"] == 10"
        ),
        (
            "analysis_source_table_alexander_skipped_common_gcd_attempt_"
            "direct_divisor_all_candidates_failed_count\"] == 1"
        ),
        "support_signatures=t1+t2:8",
        "support_signature_inputs=25..25",
        "direct_divisor_candidates=10..10",
        "direct_divisor_failed=10..10",
        "direct_divisor_all_failed=1",
        "analysis_source_table_alexander_source_divisibility_source_division_failed_candidate_count",
        "source_url=https://katlas.org/wiki/L5a1",
        "Upload source-table audit artifact",
        "iroll-source-table-invariant-audit-py${{ matrix.python-version }}",
        "Export source-invariant candidate ImGui artifacts",
        "fixture-source-invariant-candidates L6a4 --max-candidates 8",
        "source-invariant-l6a4-candidates.json",
        "source-invariant-l6a4-candidates-imgui-analysis.json",
        "source-invariant-l6a4-candidates-imgui-host.json",
        "diagram_fixture_source_invariant_candidate_diagnostics",
        "target_pairwise_linking",
        'raw["returned_candidate_count"] == 8',
        'convergence["complete_candidate_set"] is True',
        'convergence["returned_candidate_count"] == 8',
        'convergence["matching_candidate_count"] == 8',
        'convergence["invariants"]["jones"]["unique_value_count"] == 1',
        (
            'convergence["invariants"]["multivariable_alexander"]'
            '["unique_value_count"] == 1'
        ),
        'convergence["invariants"]["homfly"]["unique_value_count"] == 8',
        'replay_summary["claim_scope"] == "source_candidate_replay_self_consistency"',
        'replay_summary["checked_candidate_count"] == 8',
        'replay_summary["valid_replay_count"] == 8',
        'replay_summary["all_returned_candidates_have_valid_replay"] is True',
        'analysis["analysis_source_candidate_replay_summary_checked_candidate_count"] == 8',
        'analysis["analysis_source_candidate_replay_summary_all_valid_count"] == 1',
        'summary["source_candidate_replay_summary_checked_candidate_count"] == 8',
        'summary["source_candidate_replay_summary_all_valid_count"] == 1',
        'host["analysis"]["analysis_source_candidate_replay_summary_checked_candidate_count"] == 8',
        'summary["required_check_count"] == 1',
        'summary["failed_check_count"] == 1',
        'host_summary["failed_check_count"] == 1',
        "stable_across_complete_candidates",
        "not registered as fixture invariants",
        'assert "signed candidates are diagnostics" in host_summary["notes"]',
        "Upload source-invariant candidate artifact",
        "iroll-source-invariant-candidates-py${{ matrix.python-version }}",
        "Export generated coverage ImGui artifacts",
        "homfly-small-diagram-coverage --notation L2a1 --branch-depth 1",
        "multivariable-alexander-signed-pd-coverage --notation L2a1 --branch-depth 1",
        "homfly-small-coverage-l2a1.json",
        "alexander-signed-pd-coverage-l2a1.json",
        "generated-coverage-l2a1-imgui-analysis.json",
        "generated-coverage-l2a1-imgui-host.json",
        "homfly_small_diagram_coverage_report",
        "multivariable_alexander_signed_pd_coverage_report",
        "generated_small_signed_pd_frontier_exhaustion",
        "generated_small_signed_pd_wirtinger_fox_scanned_gcd_coverage",
        'homfly["case_count"] == 7',
        'homfly_summary["passed_check_count"] == 7',
        'homfly_summary["failed_check_count"] == 0',
        'alexander["accepted_case_count"] == 7',
        'analysis["analysis_summary_count"] == 2',
        'alexander_summary["bounded_scanned_gcd_scanned_minor_count"] == 26',
        'alexander_summary["bounded_scanned_gcd_failed_nonzero_minor_count"] == 0',
        (
            'host_summaries["homfly_small_diagram_coverage_report"]'
            '["generated_case_count"] == 7'
        ),
        (
            'host_summaries["homfly_small_diagram_coverage_report"]'
            '["passed_check_count"] == 7'
        ),
        (
            'host_summaries["homfly_small_diagram_coverage_report"]'
            '["failed_check_count"] == 0'
        ),
        (
            'host_summaries["multivariable_alexander_signed_pd_coverage_report"]'
            '["generated_case_count"] == 7'
        ),
        (
            'host_summaries["multivariable_alexander_signed_pd_coverage_report"]'
            '["bounded_scanned_gcd_failed_nonzero_minor_count"]'
        ),
        '"bounded_scanned_gcd_scanned_minor_count"',
        "== 26",
        (
            'host_summaries["multivariable_alexander_signed_pd_coverage_report"]'
            '["bounded_scanned_gcd_failed_nonzero_minor_count"] == 0'
        ),
        "arbitrary_diagram_coverage_certified",
        "full_table_normalization_certified",
        "full_invariant_certified",
        "Upload generated coverage artifact",
        "iroll-generated-coverage-l2a1-py${{ matrix.python-version }}",
        "Export single-input certification audit ImGui artifacts",
        "input-certification-hopf-imgui-role-order.json",
        "input-certification-homfly-pd.json",
        "input-certification-homfly-terminal-audit.json",
        "input-certification-homfly-evidence.json",
        "input-certification-alexander-pd.json",
        "input-certification-alexander-admissible-audit.json",
        "input-certification-alexander-evidence.json",
        "input-certification-imgui-analysis.json",
        "input-certification-imgui-host.json",
        "homfly-terminal-reduction-audit input-certification-homfly-pd.json",
        "homfly-input-certification-evidence input-certification-homfly-pd.json",
        "multivariable-alexander-pd input-certification-hopf-imgui-role-order.json",
        "multivariable-alexander-admissible-minor-normalization-audit input-certification-alexander-pd.json",
        "multivariable-alexander-input-certification-evidence input-certification-alexander-pd.json",
        "homfly_terminal_reduction_audit",
        "homfly_input_certification_evidence",
        "multivariable_alexander_input_certification_evidence",
        "multivariable_alexander_admissible_minor_normalization_audit",
        "terminal_reduction_count",
        "failed_terminal_reduction_count",
        "certified_for_input",
        "frontier_exhausted",
        "terminal_contribution_matches_result",
        "bounded_scanned_gcd_certified",
        "complete_scanned_gcd_certified",
        "quotient_gcd_certified",
        "wirtinger_fox_input_chain_consistent",
        "bounded_admissible_minor_normalization_certified",
        'alexander_audit["all_nonzero_minors_laurent_unit_equivalent"] is False',
        'alexander_audit["failed_nonzero_minor_count"] == 2',
        'alexander_audit["full_invariant_certified"] is False',
        'analysis["analysis_summary_count"] == 4',
        'analysis["analysis_required_check_count"] == 14',
        'analysis["analysis_passed_check_count"] == 12',
        'analysis["analysis_failed_check_count"] == 2',
        'host["analysis"]["analysis_summary_count"] >= 4',
        'host["analysis"]["analysis_required_check_count"]',
        '>= analysis["analysis_required_check_count"]',
        'host["analysis"]["analysis_passed_check_count"]',
        '>= analysis["analysis_passed_check_count"]',
        'host["analysis"]["analysis_failed_check_count"]',
        '>= analysis["analysis_failed_check_count"]',
        "Upload single-input certification audit artifact",
        "iroll-single-input-certification-audits-py${{ matrix.python-version }}",
        "Export signed-PD role-order candidate ImGui artifacts",
        "role-order-hopf-imgui-input.json",
        "role-order-candidates.json",
        "role-order-candidates-imgui-analysis.json",
        "role-order-candidates-imgui-host.json",
        "signed-pd-role-order-candidates role-order-hopf-imgui-input.json",
        "signed_pd_role_order_candidates_report",
        "input_shape",
        "imgui_signed_pd",
        "signed_pd_revision",
        "status",
        "ambiguous",
        'raw["strict_candidate_count"] == 16',
        "unique_strict_global_role_order",
        'signatures["evaluated_candidate_count"] == 2',
        'signatures["skipped_candidate_count"] == 14',
        'signatures["signature_resolution_status_code"] == 5',
        "partially_distinguishes_candidates",
        "signature_all_strict_evaluated=false",
        'analysis["analysis_role_order_signature_strict_candidate_count"] == 16',
        'analysis["analysis_role_order_signature_evaluated_candidate_count"] == 2',
        "analysis_role_order_signature_all_strict_candidates_evaluated_count",
        "analysis_role_order_signature_alexander_complete_scanned_gcd_certified_candidate_count",
        'summary["role_order_signature_resolution_status_code"] == 5',
        'host_summary["role_order_signature_strict_candidate_count"] == 16',
        'host_summary["role_order_signature_evaluated_candidate_count"] == 2',
        "Upload signed-PD role-order candidate artifact",
        "iroll-signed-pd-role-order-candidates-py${{ matrix.python-version }}",
        "cuda_gpu_benchmark_evidence",
        "iroll_core_cuda_gpu_benchmark_evidence",
        "local_gpu_benchmark_witness",
        "gpu_backend_not_requested",
        "hosted_cuda_ci_not_observed",
        "release_grade_gpu_speedup_claimed",
        "Upload NumPy benchmark matrix artifact",
        "iroll-numpy-benchmark-matrix-py${{ matrix.python-version }}",
        "cargo build",
        "cargo fmt --check",
        "cargo clippy --all-targets -- -D warnings",
        "cargo test",
        "python -m maturin build --release -i python",
        "Export Rust wheel retained metadata manifest",
        "rust-wheel-retained-manifest.json",
        "rust-wheel-retained-manifest-imgui-analysis.json",
        "rust-wheel-retained-manifest-imgui-host.json",
        "rust_wheel_retained_metadata_manifest",
        "unsigned_ci_rust_wheel_artifact_index",
        "rust_c_abi_version",
        "wheel_count",
        "wheel_artifact_name",
        "signed_release_artifacts_published",
        "publication_claimed",
        "platform_index_publication_claimed",
        "release_grade_speedup_claimed",
        "native_homfly_cpp_computation_claimed",
        "native_alexander_cpp_computation_claimed",
        "imgui-analysis-summary-payload native/iroll-kernels-rust/target/wheels/rust-wheel-retained-manifest.json",
        "imgui-host-payload --analysis-report-json native/iroll-kernels-rust/target/wheels/rust-wheel-retained-manifest.json",
        "analysis_rust_wheel_retained_manifest_artifact_count",
        "analysis_rust_wheel_retained_manifest_abi_matched_count",
        "analysis_rust_wheel_retained_manifest_wheel_count_total",
        "analysis_rust_wheel_retained_manifest_wheel_file_count_total",
        "analysis_rust_wheel_retained_manifest_wheel_count_matched_count",
        "analysis_rust_wheel_retained_manifest_unsigned_ci_artifact_count",
        "analysis_rust_wheel_retained_manifest_non_claim_false_count",
        "analysis_rust_wheel_retained_manifest_signed_release_artifacts_published_count",
        "analysis_rust_wheel_retained_manifest_publication_claimed_count",
        "analysis_rust_wheel_retained_manifest_platform_index_publication_claimed_count",
        "analysis_rust_wheel_retained_manifest_release_grade_speedup_claimed_count",
        "analysis_rust_wheel_retained_manifest_native_homfly_cpp_computation_claimed_count",
        "analysis_rust_wheel_retained_manifest_native_alexander_cpp_computation_claimed_count",
        "release_non_claim_consistency=flags=6; false=6; all_false=true",
        "non_claim_evidence_index",
        "analysis_rust_wheel_retained_manifest_non_claim_evidence_index_entry_count_total",
        "analysis_imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total",
        "non_claim_evidence_index_entries=6",
        "actions/upload-artifact@v4",
        "Upload Rust wheel artifact",
        "iroll-kernels-rust-wheel-${{ matrix.os }}",
        "if-no-files-found: error",
        "python -m pip install native/iroll-kernels-rust/target/wheels/*.whl",
        "tests/test_kernels.py tests/test_contacts.py tests/test_topology.py",
        "Rust unsupported invariant result-handle ImGui bridge",
        (
            "tests/test_kernels.py::"
            "test_rust_unsupported_result_handle_report_loads_as_imgui_status_when_installed"
        ),
        (
            "tests/test_reports_schema.py::"
            "test_imgui_invariant_status_payload_wraps_unsupported_result_handle_report"
        ),
        "Export Rust unsupported invariant result-handle ImGui artifact",
        "rust-unsupported-invariant-result-handle-report --invariant homfly",
        "rust-unsupported-invariant-result-handle-report --invariant alexander",
        "imgui-invariant-status-summary-payload rust-unsupported-invariant-result-handle-report.json",
        "imgui-invariant-status-summary-payload rust-unsupported-alexander-invariant-result-handle-report.json",
        "imgui-host-payload --invariant-report-json rust-unsupported-invariant-result-handle-report.json",
        "--invariant-report-json rust-unsupported-alexander-invariant-result-handle-report.json",
        "rust-unsupported-invariant-result-handle-imgui-host.json",
        "host[\"method\"] == \"imgui_host_payload\"",
        "invariants[\"invariant_status_count\"] == 2",
        "invariants[\"invariant_required_check_count\"] == 0",
        "invariants[\"invariant_passed_check_count\"] == 0",
        "invariants[\"invariant_failed_check_count\"] == 0",
        "host[\"analysis\"][\"analysis_summary_count\"] == 0",
        "multi-variable Alexander native result handle",
        "status_payload[\"invariant_required_check_count\"] == 0",
        "status_payload[\"invariant_passed_check_count\"] == 0",
        "status_payload[\"invariant_failed_check_count\"] == 0",
        "rust-unsupported-invariant-result-handle-report.json",
        "rust-unsupported-invariant-result-handle-imgui-status.json",
        "rust-unsupported-alexander-invariant-result-handle-report.json",
        "rust-unsupported-alexander-invariant-result-handle-imgui-status.json",
        "rust-unsupported-invariant-result-handle-imgui-host.json",
        "Upload Rust unsupported invariant result-handle ImGui artifact",
        "iroll-rust-unsupported-result-handle-imgui-${{ matrix.os }}",
        "Windows C ABI smoke caller",
        "Windows Dear ImGui contract smoke",
        "cargo build --release --manifest-path native/iroll-kernels-rust/Cargo.toml",
        "segment_distance_smoke.cpp",
        "iroll_imgui_panel_contract_smoke.exe",
        "$framebufferJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-test-stub-framebuffer-smoke.json'",
        "$framebufferAnalysisJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-test-stub-framebuffer-smoke-imgui-analysis.json'",
        "$framebufferHostJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-test-stub-framebuffer-smoke-imgui-host.json'",
        "iroll-imgui-test-stub-framebuffer-smoke.json",
        "iroll-imgui-test-stub-framebuffer-smoke-imgui-analysis.json",
        "iroll-imgui-test-stub-framebuffer-smoke-imgui-host.json",
        "$sourceOpenJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-source-open-request-smoke.json'",
        "$sourceOpenAnalysisJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-source-open-request-smoke-imgui-analysis.json'",
        "$sourceOpenHostJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-source-open-request-smoke-imgui-host.json'",
        "$framebufferJson $sourceOpenJson",
        "iroll-imgui-source-open-request-smoke.json",
        "iroll-imgui-source-open-request-smoke-imgui-analysis.json",
        "iroll-imgui-source-open-request-smoke-imgui-host.json",
        "artifact_schema_version']==1",
        "imgui_source_open_request_smoke",
        "host_polled_source_open_request_contract",
        "host_action']=='open_source_url'",
        "opened_by_real_host'] is False",
        "scheme_allowed'] is True",
        "selected_fixture_name']=='3_1'",
        "selected_fixture_source']=='Knot Atlas'",
        "consumed_source_url']==payload['source_url']",
        "request_consumed_by_smoke'] is True",
        "request_cleared_after_consumption'] is True",
        "final_request_pending'] is True",
        "selected_fixture_source_url_length']==len(payload['source_url'])",
        "requested_fixture_source_url_length']==len(payload['source_url'])",
        "imgui_abi_version']==117",
        "rust_c_abi_version']==19",
        "imgui-analysis-summary-payload $sourceOpenJson",
        "imgui-host-payload --analysis-report-json $sourceOpenJson",
        "analysis_imgui_source_open_request_smoke_artifact_count']==1",
        "analysis_imgui_source_open_request_smoke_passed_count']==1",
        "analysis_imgui_source_open_request_smoke_opened_by_real_host_count']==0",
        "analysis_imgui_source_open_request_smoke_scheme_allowed_count']==1",
        "analysis_imgui_source_open_request_smoke_request_consumed_count']==1",
        "imgui_source_open_request_smoke_host_action']=='open_source_url'",
        "imgui_source_open_request_smoke_selected_fixture_name']=='3_1'",
        "imgui_source_open_request_smoke_selected_fixture_source']=='Knot Atlas'",
        "imgui_source_open_request_smoke_source_url']=='https://katlas.org/wiki/3_1'",
        "imgui_source_open_request_smoke_consumed_source_url']==summary['imgui_source_open_request_smoke_source_url']",
        "imgui_source_open_request_smoke_consumed_source_url_matched'] is True",
        "imgui-analysis-summary-payload $framebufferJson",
        "imgui-host-payload --analysis-report-json $framebufferJson",
        "imgui_test_stub_framebuffer_smoke",
        "repository_imgui_test_stub_draw_list_framebuffer_estimate",
        "real_graphics_backend_framebuffer_verified",
        "screenshot_verified",
        "estimated_nonzero_pixels",
        "analysis_imgui_framebuffer_smoke_artifact_count']==1",
        "analysis_imgui_framebuffer_smoke_passed_count']==1",
        "analysis_imgui_framebuffer_smoke_real_backend_verified_count']==0",
        "analysis_imgui_framebuffer_smoke_screenshot_verified_count']==0",
        "analysis_imgui_framebuffer_smoke_render_frame_count']==1",
        "analysis_imgui_framebuffer_smoke_geometry_nonempty_count']==1",
        "analysis_imgui_framebuffer_smoke_geometry_canvas_count']==2",
        "analysis_imgui_framebuffer_smoke_geometry_filled_rect_count']==2",
        "analysis_imgui_framebuffer_smoke_geometry_rect_count']==2",
        "analysis_imgui_framebuffer_smoke_geometry_polyline_count'] >= 4",
        "analysis_imgui_framebuffer_smoke_geometry_marker_count'] >= 2",
        "analysis_imgui_framebuffer_smoke_text_count'] >= 10",
        "summary['imgui_framebuffer_smoke_render_frame_count']==1",
        "summary['imgui_framebuffer_smoke_geometry_canvas_count']==2",
        "summary['imgui_framebuffer_smoke_text_count'] >= 10",
        "Upload Windows Dear ImGui test-stub framebuffer smoke artifact",
        "iroll-imgui-test-stub-framebuffer-smoke-${{ matrix.os }}",
        "${{ runner.temp }}/iroll-imgui-source-open-request-smoke.json",
        "${{ runner.temp }}/iroll-imgui-source-open-request-smoke-imgui-analysis.json",
        "${{ runner.temp }}/iroll-imgui-source-open-request-smoke-imgui-host.json",
        "iroll_imgui_worker_scheduler_smoke.exe",
        "iroll_imgui_threaded_worker_smoke.exe",
        "iroll_imgui_thread_pool_worker_smoke.exe",
        "iroll_imgui_signed_pd_json_export_smoke.exe",
        "$signedPdSnapshotAnalysisJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-signed-pd-imgui-analysis.json'",
        "$signedPdSnapshotHostJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-signed-pd-snapshot-imgui-host.json'",
        "imgui-analysis-summary-payload $signedPdJson -o $signedPdSnapshotAnalysisJson",
        "imgui-host-payload --analysis-report-json $signedPdJson -o $signedPdSnapshotHostJson",
        "analysis_imgui_signed_pd_snapshot_artifact_count",
        "analysis_imgui_signed_pd_snapshot_valid_count",
        "analysis_imgui_signed_pd_snapshot_validation_available_count",
        "analysis_imgui_signed_pd_snapshot_component_count_matches_count",
        "analysis_imgui_signed_pd_snapshot_invalid_role_order_count_total",
        "analysis_imgui_signed_pd_snapshot_invalid_flow_label_count_total",
        "source_method']=='imgui_signed_pd_snapshot'",
        "required_check_count']==5",
        "not invariant computation evidence",
        "iroll_imgui_signed_pd_recompute_scheduler_smoke.exe",
        "$signedPdSchedulerTraceJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-signed-pd-recompute-scheduler-smoke.json'",
        "$signedPdSchedulerAnalysisJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-signed-pd-recompute-scheduler-smoke-imgui-analysis.json'",
        "$signedPdSchedulerHostJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-signed-pd-recompute-scheduler-smoke-imgui-host.json'",
        "iroll_imgui_signed_pd_recompute_scheduler_smoke.exe') $signedPdSchedulerTraceJson",
        "iroll-imgui-signed-pd-recompute-scheduler-smoke.json",
        "iroll-imgui-signed-pd-recompute-scheduler-smoke-imgui-analysis.json",
        "iroll-imgui-signed-pd-recompute-scheduler-smoke-imgui-host.json",
        "imgui_signed_pd_recompute_scheduler_smoke",
        "host_owned_signed_pd_recompute_scheduler_contract",
        "first_scope']=='all'",
        "first_result_count']==2",
        "first_revision_reloaded'] is True",
        "stale_recompute_rejected'] is True",
        "stale_error_mentions_revision_mismatch'] is True",
        "current_scope']=='homfly'",
        "current_result_count']==1",
        "imgui-analysis-summary-payload $signedPdSchedulerTraceJson",
        "imgui-host-payload --analysis-report-json $signedPdSchedulerTraceJson",
        "analysis_imgui_signed_pd_recompute_scheduler_smoke_artifact_count']==1",
        "analysis_imgui_signed_pd_recompute_scheduler_smoke_passed_count']==1",
        "analysis_imgui_signed_pd_recompute_scheduler_smoke_stale_recompute_rejected_count']==1",
        "analysis_imgui_signed_pd_recompute_scheduler_smoke_current_revision_reloaded_count']==1",
        "analysis_imgui_signed_pd_recompute_scheduler_smoke_requested_snapshot_cleared_count']==1",
        "analysis_imgui_signed_pd_recompute_scheduler_smoke_handoff_complete_count']==1",
        "required_check_count']==11",
        "not native HOMFLY/Alexander C++ computation evidence",
        "iroll_imgui_signed_pd_thread_pool_recompute_scheduler_smoke.exe",
        "$threadPoolTraceJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke.json'",
        "$threadPoolAnalysisJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke-imgui-analysis.json'",
        "$threadPoolHostJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke-imgui-host.json'",
        "iroll_imgui_signed_pd_thread_pool_recompute_scheduler_smoke.exe') $threadPoolTraceJson",
        "iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke.json",
        "iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke-imgui-analysis.json",
        "iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke-imgui-host.json",
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke",
        "host_owned_thread_pool_signed_pd_recompute_scheduler_contract",
        "thread_pool_worker_count']==2",
        "stale_recompute_rejected'] is True",
        "stale_scope']=='all'",
        "current_scope']=='alexander'",
        "current_revision_reloaded'] is True",
        "requested_snapshot_json_cleared'] is True",
        "progress_completed'] is True",
        "progress_active_after_completion'] is False",
        "handoff_input_format']=='imgui_signed_pd_json'",
        "handoff_result_transport']=='json_file'",
        "host_reload_payload']=='imgui-signed-pd-invariant-status-payload'",
        "imgui-analysis-summary-payload $threadPoolTraceJson",
        "imgui-host-payload --analysis-report-json $threadPoolTraceJson",
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact_count']==1",
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_passed_count']==1",
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_recompute_rejected_count']==1",
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_revision_reloaded_count']==1",
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_requested_snapshot_cleared_count']==1",
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_handoff_complete_count']==1",
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_worker_count_total']==2",
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_progress_completed_count']==1",
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_progress_inactive_after_completion_count']==1",
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_final_status_fresh_count']==1",
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_result_count_total']==2",
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_result_count_total']==1",
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_final_invariant_status_count_total']==1",
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_request_scope']=='alexander'",
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_host_reload_payload']=='imgui-signed-pd-invariant-status-payload'",
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_loaded_revision']==2",
        "required_check_count']==16",
        "python -m iroll.cli homfly-pd $signedPdJson",
        "python -m iroll.cli multivariable-alexander-pd $signedPdJson",
        "$signedPdHomflyJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-signed-pd-homfly.json'",
        "$signedPdAlexanderJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-signed-pd-alexander.json'",
        "homfly-pd $signedPdJson --max-depth 8 --max-nodes 2048 -o $signedPdHomflyJson",
        "multivariable-alexander-pd $signedPdJson --max-minors 64 -o $signedPdAlexanderJson",
        "$signedPdHostJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-signed-pd-imgui-host.json'",
        "imgui-host-payload --invariant-report-json $signedPdHomflyJson --invariant-report-json $signedPdAlexanderJson",
        "host['method']=='imgui_host_payload'",
        "invariants['invariant_status_count']==4",
        "host['analysis']['analysis_summary_count']==2",
        "invariants.get('signed_pd_revision') is not None",
        "iroll-imgui-signed-pd-homfly.json",
        "iroll-imgui-signed-pd-alexander.json",
        "iroll-imgui-signed-pd-imgui-host.json",
        "Upload Windows Dear ImGui signed-PD JSON smoke artifact",
        "iroll-imgui-signed-pd-json-${{ matrix.os }}",
        "${{ runner.temp }}/iroll-imgui-signed-pd.json",
        "${{ runner.temp }}/iroll-imgui-signed-pd-imgui-analysis.json",
        "${{ runner.temp }}/iroll-imgui-signed-pd-snapshot-imgui-host.json",
        "${{ runner.temp }}/iroll-imgui-signed-pd-homfly.json",
        "${{ runner.temp }}/iroll-imgui-signed-pd-alexander.json",
        "${{ runner.temp }}/iroll-imgui-signed-pd-invariant-status.json",
        "${{ runner.temp }}/iroll-imgui-signed-pd-imgui-host.json",
        "${{ runner.temp }}/iroll-imgui-signed-pd-recompute-scheduler-smoke.json",
        "${{ runner.temp }}/iroll-imgui-signed-pd-recompute-scheduler-smoke-imgui-analysis.json",
        "${{ runner.temp }}/iroll-imgui-signed-pd-recompute-scheduler-smoke-imgui-host.json",
        "${{ runner.temp }}/iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke.json",
        "${{ runner.temp }}/iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke-imgui-analysis.json",
        "${{ runner.temp }}/iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke-imgui-host.json",
        "$signedPdStatusJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-signed-pd-invariant-status.json'",
        "imgui-signed-pd-invariant-status-payload $signedPdJson --max-depth 8 --max-nodes 2048 -o $signedPdStatusJson",
        "imgui-signed-pd-invariant-status-payload",
        "iroll_imgui_real_kernel_loader_smoke.exe",
        "iroll_kernels_rust.dll",
        "$realLoaderJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-real-kernel-loader-smoke.json'",
        "iroll-imgui-real-kernel-loader-smoke.json",
        "imgui_real_kernel_loader_smoke",
        "runtime_loader_real_rust_dynamic_library_contract",
        "kernel_loader_abi_version']==6",
        "dynamic_library_loaded'] is True",
        "api_attached_to_panel'] is True",
        "callback_thread_pool_completed'] is True",
        "worker_touches_imgui_context'] is False",
        "distance_progress_total']==3",
        "intersection_progress_total']==2",
        "required_metadata_field_count']==30",
        "readiness_provenance_present'] is True",
        "$realLoaderAnalysisJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-real-kernel-loader-smoke-imgui-analysis.json'",
        "$realLoaderHostJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-real-kernel-loader-smoke-imgui-host.json'",
        "imgui-analysis-summary-payload $realLoaderJson",
        "imgui-host-payload --analysis-report-json $realLoaderJson",
        "analysis_imgui_real_kernel_loader_smoke_artifact_count",
        "analysis_imgui_real_kernel_loader_smoke_passed_count",
        "analysis_imgui_real_kernel_loader_smoke_dynamic_library_loaded_count",
        "analysis_imgui_real_kernel_loader_smoke_callback_thread_pool_completed_count",
        (
            "analysis_imgui_real_kernel_loader_smoke_native_homfly_cpp_"
            "computation_claimed_count']==0"
        ),
        "analysis_imgui_real_kernel_loader_smoke_non_claim_false_count",
        "summary['required_check_count']==11",
        "summary['passed_check_count']==11",
        (
            "analysis['analysis_imgui_real_kernel_loader_smoke_backend_report_"
            "byte_count_total'] > 0"
        ),
        (
            "analysis['analysis_imgui_real_kernel_loader_smoke_invariant_"
            "handles_report_byte_count_total'] > 0"
        ),
        (
            "analysis['analysis_imgui_real_kernel_loader_smoke_non_claim_"
            "false_count']==5"
        ),
        "$imguiManifestJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-windows-retained-artifacts-manifest.json'",
        "imgui_windows_retained_artifacts_manifest",
        "windows_dear_imgui_retained_artifact_manifest",
        "retained_json_file_count = 22",
        "evidence_group_count = 7",
        "m['evidence_group_count']==7",
        "raw_analysis_host_group_count = 6",
        "invariant_status_host_group_count = 1",
        "smoke_executed_no_retained_json_count = 0",
        "production_renderer_verified",
        "production_scheduler_completion_claimed",
        "native_homfly_cpp_computation_claimed",
        "native_alexander_cpp_computation_claimed",
        "signed_release_artifacts_published",
        "complete_raw_analysis_host",
        "invariant_status_host_only",
        "smoke_executed_no_retained_json",
        "signed_pd_snapshot",
        "signed_pd_invariant_reload",
        "real_kernel_loader_smoke",
        "$imguiManifestAnalysisJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-windows-retained-artifacts-manifest-imgui-analysis.json'",
        "$imguiManifestHostJson = Join-Path $env:RUNNER_TEMP 'iroll-imgui-windows-retained-artifacts-manifest-imgui-host.json'",
        "imgui-analysis-summary-payload $imguiManifestJson -o $imguiManifestAnalysisJson",
        "imgui-host-payload --analysis-report-json $imguiManifestJson -o $imguiManifestHostJson",
        "analysis_imgui_windows_retained_artifacts_manifest_artifact_count']==1",
        "analysis_imgui_windows_retained_artifacts_manifest_evidence_group_count_total']==7",
        "analysis_imgui_windows_retained_artifacts_manifest_reported_evidence_group_count_total']==7",
        "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_count_total']==22",
        "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_reference_count_total",
        "analysis_imgui_windows_retained_artifacts_manifest_unique_retained_json_file_count_total']==22",
        "analysis_imgui_windows_retained_artifacts_manifest_shared_retained_json_file_count_total']==1",
        "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_count_matched_count']==1",
        "analysis_imgui_windows_retained_artifacts_manifest_complete_raw_analysis_host_group_count_total']==6",
        "analysis_imgui_windows_retained_artifacts_manifest_invariant_status_host_group_count_total']==1",
        "analysis_imgui_windows_retained_artifacts_manifest_smoke_executed_no_retained_json_count_total']==0",
        "analysis_imgui_windows_retained_artifacts_manifest_non_claim_false_count']==5",
        "analysis_imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total']==5",
        "retained_json_file_references=23",
        "shared_retained_json_files=1",
        "imgui_windows_retained_artifacts_manifest_shared_files=iroll-imgui-signed-pd.json",
        "retained_json_file_count_matched=true",
        "non_claim_evidence_index_entries=5",
        "Upload Windows Dear ImGui real kernel loader smoke artifact",
        "iroll-imgui-real-kernel-loader-smoke-${{ matrix.os }}",
        "${{ runner.temp }}/iroll-imgui-real-kernel-loader-smoke.json",
        "${{ runner.temp }}/iroll-imgui-real-kernel-loader-smoke-imgui-analysis.json",
        "${{ runner.temp }}/iroll-imgui-real-kernel-loader-smoke-imgui-host.json",
        "Upload Windows Dear ImGui retained artifact manifest",
        "iroll-imgui-windows-retained-artifacts-manifest-${{ matrix.os }}",
        "${{ runner.temp }}/iroll-imgui-windows-retained-artifacts-manifest.json",
        "${{ runner.temp }}/iroll-imgui-windows-retained-artifacts-manifest-imgui-analysis.json",
        "${{ runner.temp }}/iroll-imgui-windows-retained-artifacts-manifest-imgui-host.json",
        "IROLL_IMGUI_USE_TEST_STUB=ON",
        "Run optional GPU smoke in unavailable mode",
        "gpu_smoke.py --allow-unavailable",
        "gpu-smoke-no-cuda.json",
        "Verify no-CUDA GPU smoke artifact contract",
        'payload["artifact_kind"] == "gpu_smoke_unavailable_boundary"',
        'payload["execution_path"] == "optional_gpu_unavailable"',
        'payload["environment_witness"]["backend"]["imported"] is False',
        'payload["environment_witness"]["runtime"]["cuda_runtime_observed"] is False',
        'payload["environment_witness"]["simulation"]["simulated_parity_failure"] is False',
        "Export no-CUDA GPU smoke ImGui analysis and host artifacts",
        "imgui-analysis-summary-payload gpu-smoke-no-cuda.json",
        "imgui-host-payload --analysis-report-json gpu-smoke-no-cuda.json",
        "gpu-smoke-no-cuda-imgui-analysis.json",
        "gpu-smoke-no-cuda-imgui-host.json",
        'analysis_gpu_smoke_unavailable_boundary_count"] == 1',
        'analysis_gpu_smoke_no_cuda_boundary_count"] == 1',
        'analysis_gpu_smoke_release_gate_gpu_backend_unavailable_blocker_count"] == 1',
        'analysis_gpu_smoke_release_gate_cuda_runtime_not_observed_blocker_count"] == 1',
        'analysis_gpu_smoke_release_gate_required_checks_incomplete_blocker_count"] == 1',
        'analysis_gpu_smoke_release_gate_forced_unavailable_blocker_count"] == 0',
        'analysis_gpu_smoke_required_capability_name_count"] == 3',
        'analysis_gpu_smoke_failed_check_name_count"] == 0',
        'analysis_gpu_smoke_cuda_parity_claimed_count"] == 0',
        'analysis_gpu_smoke_release_grade_speedup_claimed_count"] == 0',
        'summary["gpu_smoke_required_capability_name_count"] == 3',
        "gpu_smoke_required_capabilities=segment_segment_distance",
        "imgui_host_payload",
        "Upload no-CUDA GPU smoke artifact",
        "iroll-gpu-smoke-no-cuda",
        "Verify simulated GPU parity-failure artifact contract",
        "gpu_smoke.py --simulate-parity-failure",
        "gpu-smoke-simulated-parity-failure.json",
        "Expected simulated parity-failure smoke to exit 1",
        'payload["artifact_kind"] == "gpu_smoke_parity_failure"',
        'payload["execution_path"] == "gpu_backend_parity_mismatch"',
        'payload["environment_witness"]["simulation"]["simulated_parity_failure"] is True',
        "Export simulated GPU parity-failure ImGui analysis and host artifacts",
        "imgui-analysis-summary-payload gpu-smoke-simulated-parity-failure.json",
        "imgui-host-payload --analysis-report-json gpu-smoke-simulated-parity-failure.json",
        "gpu-smoke-simulated-parity-failure-imgui-analysis.json",
        "gpu-smoke-simulated-parity-failure-imgui-host.json",
        'analysis_gpu_smoke_parity_failure_count"] == 1',
        'analysis_gpu_smoke_simulated_parity_failure_count"] == 1',
        'analysis_gpu_smoke_release_gate_required_checks_failed_blocker_count"] == 1',
        'analysis_gpu_smoke_release_gate_simulated_parity_failure_blocker_count"] == 1',
        'analysis_gpu_smoke_required_capability_name_count"] == 3',
        'analysis_gpu_smoke_failed_check_name_count"] == 1',
        'analysis_gpu_smoke_cuda_parity_claimed_count"] == 0',
        'analysis_gpu_smoke_release_grade_speedup_claimed_count"] == 0',
        'summary["gpu_smoke_failed_check_names"] == "gpu_numpy_parity"',
        "gpu_smoke_failed_check_names=gpu_numpy_parity",
        "Upload simulated GPU parity-failure artifact",
        "iroll-gpu-smoke-simulated-parity-failure",
        "test_explicit_gpu_backend_errors_when_uninstalled",
        "test_optional_gpu_package_exposes_explicit_segment_distance_kernel",
    ]:
        assert required in workflow

    for required in [
        "iroll_imgui_signed_pd_thread_pool_recompute_scheduler_smoke.exe",
    ]:
        assert required in docs

    assert "CUDA-enabled parity jobs" in docs
    assert "unsigned CI wheel artifacts" in docs
    assert "rust-wheel-retained-manifest-imgui-analysis.json" in docs
    assert "rust-wheel-retained-manifest-imgui-host.json" in docs
    assert "analysis_rust_wheel_retained_manifest_artifact_count=1" in docs
    assert "analysis_rust_wheel_retained_manifest_abi_matched_count=1" in docs
    assert "analysis_rust_wheel_retained_manifest_wheel_count_total>=1" in docs
    assert (
        "analysis_rust_wheel_retained_manifest_wheel_file_count_total>=1"
        in docs
    )
    assert (
        "analysis_rust_wheel_retained_manifest_wheel_count_matched_count=1"
        in docs
    )
    assert (
        "analysis_rust_wheel_retained_manifest_unsigned_ci_artifact_count=1"
        in docs
    )
    assert "analysis_rust_wheel_retained_manifest_non_claim_false_count=6" in docs
    assert (
        "analysis_rust_wheel_retained_manifest_non_claim_evidence_index_entry_count_total"
        in docs
    )
    assert "non_claim_evidence_index_entries=6" in docs
    assert "rust_wheel_retained_metadata_manifest" in report_schema_docs
    assert "analysis_rust_wheel_retained_manifest_artifact_count" in report_schema_docs
    assert (
        "analysis_rust_wheel_retained_manifest_wheel_count_total"
        in report_schema_docs
    )
    assert (
        "analysis_rust_wheel_retained_manifest_wheel_file_count_total"
        in report_schema_docs
    )
    assert (
        "analysis_rust_wheel_retained_manifest_wheel_count_matched_count"
        in report_schema_docs
    )
    assert (
        "analysis_rust_wheel_retained_manifest_unsigned_ci_artifact_count"
        in report_schema_docs
    )
    assert "non_claim_evidence_index" in report_schema_docs
    assert (
        "analysis_rust_wheel_retained_manifest_non_claim_evidence_index_entry_count_total"
        in report_schema_docs
    )
    assert "non_claim_evidence_index_entries=" in report_schema_docs
    assert "not signed release publication" in report_schema_docs
    assert "Rust unsupported result-handle ImGui bridge artifacts" in docs
    assert "rust-unsupported-invariant-result-handle-report.json" in docs
    assert "rust-unsupported-invariant-result-handle-imgui-status.json" in docs
    assert "rust-unsupported-alexander-invariant-result-handle-report.json" in docs
    assert "rust-unsupported-alexander-invariant-result-handle-imgui-status.json" in docs
    assert "rust-unsupported-invariant-result-handle-imgui-host.json" in docs
    assert "iroll-rust-unsupported-result-handle-imgui" in docs
    assert "with zero required/passed/failed" in docs
    assert "invariant checks" in docs
    assert "Windows ImGui signed-PD JSON plus invariant-status reload artifacts" in docs
    assert "Windows ImGui signed-PD snapshot raw/analysis/host artifacts" in docs
    assert "iroll-imgui-signed-pd-imgui-analysis.json" in docs
    assert "iroll-imgui-signed-pd-snapshot-imgui-host.json" in docs
    assert "analysis_imgui_signed_pd_snapshot_artifact_count" in report_schema_docs
    assert "host-exported ImGui signed-PD JSON shape evidence" in report_schema_docs
    assert "Windows ImGui signed-PD scheduler trace artifacts" in docs
    assert "`iroll-imgui-signed-pd-recompute-scheduler-smoke.json`" in docs
    assert (
        "`iroll-imgui-signed-pd-recompute-scheduler-smoke-imgui-analysis.json`"
        in docs
    )
    assert "`iroll-imgui-signed-pd-recompute-scheduler-smoke-imgui-host.json`" in docs
    assert "imgui_signed_pd_recompute_scheduler_smoke" in docs
    assert "host_owned_signed_pd_recompute_scheduler_contract" in docs
    assert (
        "analysis_imgui_signed_pd_recompute_scheduler_smoke_artifact_count=1"
        in docs
    )
    assert (
        "analysis_imgui_signed_pd_recompute_scheduler_smoke_passed_count=1"
        in docs
    )
    assert (
        "analysis_imgui_signed_pd_recompute_scheduler_smoke_stale_recompute_rejected_count=1"
        in docs
    )
    assert (
        "analysis_imgui_signed_pd_recompute_scheduler_smoke_current_revision_reloaded_count=1"
        in docs
    )
    assert "`iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke.json`" in docs
    assert (
        "`iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke-imgui-analysis.json`"
        in docs
    )
    assert (
        "`iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke-imgui-host.json`"
        in docs
    )
    assert "imgui_signed_pd_thread_pool_recompute_scheduler_smoke" in docs
    assert "host_owned_thread_pool_signed_pd_recompute_scheduler_contract" in docs
    assert (
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact_count=1"
        in docs
    )
    assert (
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_passed_count=1"
        in docs
    )
    assert (
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_recompute_rejected_count=1"
        in docs
    )
    assert (
        "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_revision_reloaded_count=1"
        in docs
    )
    assert "not HOMFLY/Alexander C++ computation evidence" in docs
    assert "Windows ImGui source-opening host action artifact" in docs
    assert "Windows ImGui test-stub framebuffer smoke artifact" in docs
    assert "`iroll-imgui-test-stub-framebuffer-smoke.json`" in docs
    assert "iroll-imgui-test-stub-framebuffer-smoke-imgui-analysis.json" in docs
    assert "iroll-imgui-test-stub-framebuffer-smoke-imgui-host.json" in docs
    assert "repository_imgui_test_stub_draw_list_framebuffer_estimate" in docs
    assert "real_graphics_backend_framebuffer_verified=false" in docs
    assert "screenshot_verified=false" in docs
    assert "analysis_imgui_framebuffer_smoke_artifact_count=1" in docs
    assert "analysis_imgui_framebuffer_smoke_passed_count=1" in docs
    assert "analysis_imgui_framebuffer_smoke_real_backend_verified_count=0" in docs
    assert "analysis_imgui_framebuffer_smoke_screenshot_verified_count=0" in docs
    assert "not production renderer screenshot verification" in docs
    assert "`iroll-imgui-source-open-request-smoke.json`" in docs
    assert "`iroll-imgui-source-open-request-smoke-imgui-analysis.json`" in docs
    assert "`iroll-imgui-source-open-request-smoke-imgui-host.json`" in docs
    assert "artifact_kind=imgui_source_open_request_smoke" in docs
    assert "claim_scope=host_polled_source_open_request_contract" in docs
    assert "fixture source URL request" in docs
    assert "boundary under `artifact_kind=imgui_source_open_request_smoke`" in docs
    assert "host-polled source navigation request" in docs
    assert "does not open platform UI from the embedded panel" in docs
    assert "opened_by_real_host=false" in docs
    assert "iroll-imgui-signed-pd-imgui-analysis.json" in docs
    assert "iroll-imgui-signed-pd-snapshot-imgui-host.json" in docs
    assert 'imgui-analysis-summary-payload "$signedPdJson"' in docs
    assert 'imgui-host-payload --analysis-report-json "$signedPdJson"' in docs
    assert "`iroll-imgui-signed-pd-invariant-status.json`" in docs
    assert "numpy-benchmark-matrix-imgui-analysis.json" in docs
    assert "numpy-benchmark-matrix-imgui-host.json" in docs
    assert "validation-pack-audit.json" in docs
    assert "validation-pack-audit-imgui-analysis.json" in docs
    assert "validation-pack-audit-imgui-host.json" in docs
    assert "iroll-validation-pack-audit-py${{ matrix.python-version }}" in docs
    assert "analysis_validation_pack_audit_available_count=1" in docs
    assert "analysis_unsigned_required_fixture_count=2" in docs
    assert "analysis_open_non_diagram_requirement_count=1" in docs
    assert "final_completion_failed_gate_count=6" in docs
    assert "final_completion_blocker_count=7" in docs
    assert "final_completion_blocker_signature" in docs
    assert "analysis_final_completion_ready_count=0" in docs
    assert (
        "open_gate_blocker_summary=failed_gates=6; summary_gates=6; "
        "blockers=7; summary_blockers=7; gate_sets_matched=true; "
        "blocker_count_matched=true; all_blockers_have_gate=true"
        in docs
    )
    assert (
        "open_gate_blocker_summary_detail=gates=6; blockers=7; codes=6; "
        "missing_refs=6; unique_missing=5; retained=10; count_matched=6; "
        "codes_matched=6; missing_artifacts_matched=6; retained_matched=6; "
        "mismatched=0; matched=true"
        in docs
    )
    assert (
        "blocker_code_consistency=codes=6; total=7; total_matched=true; "
        "unique_matched=true; signature_matched=true; all_have_code=true; "
        "matched=true"
        in docs
    )
    assert (
        "blocker_code_summary_detail=rows=6; codes=6; blockers=7; "
        "kinds=6; labels=7; missing_refs=6; unique_missing=5; "
        "count_matched=6; kinds_matched=6; labels_matched=6; "
        "missing_artifacts_matched=6; mismatched=0; matched=true"
        in docs
    )
    assert (
        "blocker_kind_consistency=kinds=3; total=7; signed=2; "
        "non_diagram=1; completion=4; rows=3; total_matched=true; "
        "unique_matched=true; all_have_kind=true; matched=true"
        in docs
    )
    assert (
        "blocker_kind_summary_detail=rows=3; kinds=3; blockers=7; "
        "codes=6; missing_refs=6; unique_missing=5; count_matched=3; "
        "codes_matched=3; missing_artifacts_matched=3; mismatched=0; "
        "matched=true"
        in docs
    )
    assert (
        "required_check_consistency=required=3; passed=1; failed=2; "
        "mismatched=0; final_ready_matched=true; all_matched=true; "
        "matched=true"
        in docs
    )
    assert (
        "signed_fixture_consistency=blockers=2; final_blockers=2; "
        "source_urls=2; unsigned_non_claims=2; source_table_metadata=2; "
        "source_candidate_evidence=2; source_candidates_not_unique=2; "
        "source_candidate_replays_valid=2; source_candidate_matches=32; "
        "source_candidate_unique_signs=20; mismatched=0; matched=true"
        in docs
    )
    assert (
        "non_diagram_requirement_consistency=requirements=6; open=1; "
        "blockers=1; evidence_refs=2; evidence_ids=2; "
        "missing_artifacts_matched=1; evidence_fields_matched=1; "
        "refs_top_level_matched=true; ids_top_level_matched=true; "
        "mismatched=0; matched=true"
        in docs
    )
    assert (
        "non_claim_gate_consistency=fields=4; false=4; gates=4; "
        "blockers=4; missing_artifacts=4; codes_matched=4; "
        "missing_artifacts_matched_count=4; matched=true"
        in docs
    )
    assert (
        "completion_gate_evidence_consistency=gates=4; gate_checks=4; "
        "blockers=4; failed=4; false=4; codes=4; required=4; "
        "current=4; missing_artifacts=4; missing_artifact_ids=4; "
        "retained_evidence=8; retained_evidence_ids=8; "
        "retained_evidence_matched=4; mismatched=0; matched=true"
        in docs
    )
    assert (
        "gate_blocker_consistency=checked=7; count_matched=7; "
        "codes_matched=7; mismatched=0; matched=true"
        in docs
    )
    assert (
        "retained_evidence_artifact_files=entries=10; artifact_entries=2; "
        "non_artifact=8; refs=6; unique=6; raw=2; analysis=2; host=2; "
        "complete_groups=2; incomplete_groups=0; refs_matched=true; "
        "file_types_matched=true; groups_complete=true; files_unique=true; "
        "matched=true"
        in docs
    )
    assert (
        "blocker_evidence_links=linked=5; unlinked=2; evidence_refs=10; "
        "refs_matched=true; ids_matched=true; non_claim_matched=true; "
        "labels=7; codes=7; missing=7; required=7; current=7; matched=true"
        in docs
    )
    assert (
        "blocker_evidence_link_kind_detail=rows=3; blockers=7; linked=5; "
        "unlinked=2; refs=10; ids=8; non_claimed_links=7; "
        "blocker_matched=3; linked_matched=3; unlinked_matched=3; "
        "refs_matched=3; ids_matched=3; non_claim_matched=3; "
        "mismatched=0; matched=true"
        in docs
    )
    assert (
        "missing_artifact_summary=refs=7; unique=5; rows=5; "
        "refs_matched=true; rows_matched=true; matched=true"
        in docs
    )
    assert (
        "missing_artifact_summary_detail=rows=5; unique=5; blockers=7; "
        "codes=6; labels=7; count_matched=5; codes_matched=5; "
        "labels_matched=5; mismatched=0; matched=true"
        in docs
    )
    assert (
        "blocker_evidence_fields=summary_rows=3; missing_artifact=7; "
        "required=7; current=7; all_present=7; matched=true"
        in docs
    )
    assert (
        "blocker_evidence_field_summary_detail=rows=3; blockers=7; "
        "missing_artifact=7; required=7; current=7; all_present=7; "
        "count_matched=3; missing_matched=3; required_matched=3; "
        "current_matched=3; all_present_matched=3; mismatched=0; matched=true"
        in docs
    )
    assert "`L5a1` and `L6a4`" in docs
    assert "`code=signed_pd_not_registered`" in docs
    assert (
        "`registration_status=source_table_unsigned_fixture_pending_sign_registration`"
        in docs
    )
    assert "no verified signed crossing assignment" in docs
    assert "The only remaining non-diagram partial gate is" in docs
    assert "`noisy sampled curves`" in docs
    assert "`high-point-count performance curves`" in docs
    assert "`native ImGui screenshot/framebuffer fixtures`" in docs
    assert (
        "mirror pairs, split links, UI sample reports with geometry, "
        "`noisy sampled curves`, and `high-point-count performance curves` "
        "are available"
        in docs
    )
    assert "`full_homfly_pt_evaluation_certified=false`" in docs
    assert "`full_multivariable_alexander_normalization_certified=false`" in docs
    assert "`production_imgui_renderer_verified=false`" in docs
    assert "`release_artifacts_published=false`" in docs
    assert "validate-table-source-metadata.json" in docs
    assert "validate-table-source-metadata-imgui-analysis.json" in docs
    assert "validate-table-source-metadata-imgui-host.json" in docs
    assert "validate-table-source-metadata-blocked.json" in docs
    assert "validate-table-source-metadata-blocked-imgui-analysis.json" in docs
    assert "validate-table-source-metadata-blocked-imgui-host.json" in docs
    assert "validate-table-source-metadata-invalid-known-limitations.json" in docs
    assert (
        "validate-table-source-metadata-invalid-known-limitations-imgui-analysis.json"
        in docs
    )
    assert (
        "validate-table-source-metadata-invalid-known-limitations-imgui-host.json"
        in docs
    )
    assert (
        "validate-table-source-metadata-invalid-known-limitations-item.json"
        in docs
    )
    assert (
        "validate-table-source-metadata-invalid-known-limitations-item-imgui-analysis.json"
        in docs
    )
    assert (
        "validate-table-source-metadata-invalid-known-limitations-item-imgui-host.json"
        in docs
    )
    assert "validate-table-source-metadata-invalid-source-url.json" in docs
    assert (
        "validate-table-source-metadata-invalid-source-url-imgui-analysis.json"
        in docs
    )
    assert (
        "validate-table-source-metadata-invalid-source-url-imgui-host.json"
        in docs
    )
    assert "validate-table-source-metadata-provenance-blockers.json" in docs
    assert (
        "validate-table-source-metadata-provenance-blockers-imgui-analysis.json"
        in docs
    )
    assert (
        "validate-table-source-metadata-provenance-blockers-imgui-host.json"
        in docs
    )
    assert "iroll-validate-table-source-metadata-py${{ matrix.python-version }}" in docs
    assert "analysis_validate_table_source_metadata_artifact_count=1" in docs
    assert "analysis_validate_table_source_metadata_valid_count=1" in docs
    assert "analysis_validate_table_source_metadata_record_count=2" in docs
    assert (
        "analysis_validate_table_source_metadata_provenance_review_ready_count=1"
        in docs
    )
    assert (
        "analysis_validate_table_source_metadata_table_correctness_certified_count=0"
        in docs
    )
    assert (
        "analysis_validate_table_source_metadata_external_source_verified_count=0"
        in docs
    )
    assert "`provenance_review_ready=false`" in docs
    assert "`provenance_blocker_codes=[\"convention_mismatch\"]`" in docs
    assert "`convention_mismatch_count=1`" in docs
    assert "analysis_validate_table_source_metadata_valid_count=0" in docs
    assert (
        "analysis_validate_table_source_metadata_provenance_review_ready_count=0"
        in docs
    )
    assert (
        "analysis_validate_table_source_metadata_convention_mismatch_count=1"
        in docs
    )
    assert "`path=$[0].known_limitations`" in docs
    assert "analysis_validate_table_source_metadata_issue_count=1" in docs
    assert (
        "analysis_validate_table_source_metadata_provenance_blocker_count=0"
        in docs
    )
    assert "analysis_validate_table_source_metadata_known_limitations_count=0" in docs
    assert "`path=$[0].known_limitations[1]`" in docs
    assert "analysis_validate_table_source_metadata_known_limitations_count=1" in docs
    assert "`validate_table_source_metadata_known_limitations_rows=$[0]`" in docs
    assert "metadata-shape validation failures" in docs
    assert "`validate_table_source_metadata_issue_paths=$[0].known_limitations`" in docs
    assert (
        "`validate_table_source_metadata_issue_paths=$[0].known_limitations[1]`"
        in docs
    )
    assert "`validate_table_source_metadata_issue_messages=...`" in docs
    assert "`provenance_blocker_codes=[\"invalid_source_url\"]`" in docs
    assert "`source_url_issue_code_counts={\"unsupported_scheme\":1}`" in docs
    assert "analysis_validate_table_source_metadata_invalid_source_url_count=1" in docs
    assert "analysis_validate_table_source_metadata_valid_source_url_count=0" in docs
    assert (
        "analysis_validate_table_source_metadata_source_url_missing_scheme_count"
        in docs
    )
    assert (
        "analysis_validate_table_source_metadata_source_url_missing_domain_count"
        in docs
    )
    assert "analysis_validate_table_source_metadata_source_url_issue_code_total" in docs
    assert "URL provenance blockers visible" in docs
    assert (
        "`provenance_blocker_codes=[\"missing_source\",\"missing_source_url\",\"source_url_without_source\",\"invalid_source_url\",\"missing_convention\"]`"
        in docs
    )
    assert "analysis_validate_table_source_metadata_record_count=4" in docs
    assert "analysis_validate_table_source_metadata_provenance_blocker_count=5" in docs
    assert "analysis_validate_table_source_metadata_missing_source_count=1" in docs
    assert (
        "analysis_validate_table_source_metadata_missing_source_url_count=1"
        in docs
    )
    assert (
        "analysis_validate_table_source_metadata_source_url_without_source_count=1"
        in docs
    )
    assert "validate-table source-metadata happy/blocked" in docs
    assert "source-table-l6a4-audit.json" in docs
    assert "source-table-l6a4-audit-imgui-analysis.json" in docs
    assert "source-table-l6a4-audit-imgui-host.json" in docs
    assert "source-table-l5a1-audit.json" in docs
    assert "source-table-l5a1-audit-imgui-analysis.json" in docs
    assert "source-table-l5a1-audit-imgui-host.json" in docs
    assert "iroll-source-table-invariant-audit-py${{ matrix.python-version }}" in docs
    assert "analysis_source_table_audit_source_match_resolution_status_count=3" in docs
    assert (
        "source_match_statuses=jones:complete_source_match,"
        "homfly:source_missed_with_candidates,"
        "multivariable_alexander_numerator:complete_source_match"
        in docs
    )
    assert (
        "source_match_statuses=jones:source_seen_with_incomplete_candidates,"
        "homfly:source_missed_with_candidates,"
        "multivariable_alexander_numerator:"
        "source_seen_with_incomplete_candidates"
        in docs
    )
    assert "registration_summary_consistency=mismatched" in docs
    assert (
        "registration_summary_first_mismatch=count_total:blocked_count"
        in docs
    )
    assert (
        "analysis_source_table_audit_registration_summary_consistency_mismatch_count"
        in docs
    )
    assert (
        "invariant_source_table_audit_registration_summary_consistency_mismatch_count"
        in docs
    )
    assert "analysis_source_table_audit_registration_blocker_count=4" in docs
    assert (
        "analysis_source_table_audit_candidate_convergence_partial_certified_count=1"
        in docs
    )
    assert (
        "analysis_source_table_audit_candidate_convergence_full_certified_count=0"
        in docs
    )
    assert (
        "analysis_source_table_audit_candidate_convergence_certified_invariant_count=2"
        in docs
    )
    assert (
        "analysis_source_table_audit_candidate_convergence_uncertified_invariant_count=1"
        in docs
    )
    assert (
        "analysis_source_table_audit_candidate_convergence_source_value_seen_count=2"
        in docs
    )
    assert (
        "analysis_source_table_audit_candidate_convergence_source_value_seen_but_uncertified_count=0"
        in docs
    )
    assert "analysis_source_table_alexander_skipped_common_gcd_attempt_candidate_count=8" in docs
    assert (
        "analysis_source_table_alexander_source_divisibility_source_division_failed_candidate_count=8"
        in docs
    )
    assert "registered_fixture_invariant_claim=false" in docs
    assert "source-invariant-l6a4-candidates.json" in docs
    assert "source-invariant-l6a4-candidates-imgui-analysis.json" in docs
    assert "source-invariant-l6a4-candidates-imgui-host.json" in docs
    assert "iroll-source-invariant-candidates-py${{ matrix.python-version }}" in docs
    assert "returned_candidate_count=8" in docs
    assert "complete_candidate_set=true" in docs
    assert "HOMFLY remains unstable" in docs
    assert "homfly-small-coverage-l2a1.json" in docs
    assert "alexander-signed-pd-coverage-l2a1.json" in docs
    assert "generated-coverage-l2a1-imgui-analysis.json" in docs
    assert "generated-coverage-l2a1-imgui-host.json" in docs
    assert "iroll-generated-coverage-l2a1-py${{ matrix.python-version }}" in docs
    assert "bounded_scanned_gcd_scanned_minor_count=26" in docs
    assert "bounded_scanned_gcd_failed_nonzero_minor_count=0" in docs
    assert "arbitrary_diagram_coverage_certified=false" in docs
    assert "full_table_normalization_certified=false" in docs
    assert "full_invariant_certified=false" in docs
    assert "input-certification-hopf-imgui-role-order.json" in docs
    assert "input-certification-homfly-pd.json" in docs
    assert "input-certification-homfly-terminal-audit.json" in docs
    assert "input-certification-homfly-evidence.json" in docs
    assert "input-certification-alexander-pd.json" in docs
    assert "input-certification-alexander-admissible-audit.json" in docs
    assert "input-certification-alexander-evidence.json" in docs
    assert "input-certification-imgui-analysis.json" in docs
    assert "input-certification-imgui-host.json" in docs
    assert (
        "iroll-single-input-certification-audits-py${{ matrix.python-version }}"
        in docs
    )
    assert "method=homfly_terminal_reduction_audit" in docs
    assert "matched_result=true" in docs
    assert "terminal_reduction_count=2" in docs
    assert "failed_terminal_reduction_count=0" in docs
    assert "certified_for_input=true" in docs
    assert "frontier_exhausted=true" in docs
    assert "terminal_contribution_matches_result=true" in docs
    assert "bounded_scanned_gcd_certified=true" in docs
    assert "complete_scanned_gcd_certified=true" in docs
    assert "quotient_gcd_certified=true" in docs
    assert "wirtinger_fox_input_chain_consistent=true" in docs
    assert "bounded_admissible_minor_normalization_certified=false" in docs
    assert "all_nonzero_minors_laurent_unit_equivalent=false" in docs
    assert "failed_nonzero_minor_count=2" in docs
    assert "one supplied Hopf-style signed-PD input" in docs
    assert "does not certify arbitrary HOMFLY" in docs
    assert "full Alexander admissible-minor normalization" in docs
    assert "native HOMFLY/Alexander C++ computation" in docs
    assert "retains a single-input certification/audit pack" in report_schema_docs
    assert "input-certification-hopf-imgui-role-order.json" in report_schema_docs
    assert (
        "iroll-single-input-certification-audits-py${{ matrix.python-version }}"
        in report_schema_docs
    )
    assert "two failed admissible-minor checks visible" in report_schema_docs
    assert "not arbitrary HOMFLY coverage" in report_schema_docs
    assert "full Alexander admissible-minor normalization" in report_schema_docs
    assert "role-order-hopf-imgui-input.json" in docs
    assert "role-order-candidates.json" in docs
    assert "role-order-candidates-imgui-analysis.json" in docs
    assert "role-order-candidates-imgui-host.json" in docs
    assert "iroll-signed-pd-role-order-candidates-py${{ matrix.python-version }}" in docs
    assert "method=signed_pd_role_order_candidates_report" in docs
    assert "input_shape=imgui_signed_pd" in docs
    assert "signed_pd_revision=42" in docs
    assert "status=ambiguous" in docs
    assert "strict_candidate_count=16" in docs
    assert "signature_resolution_status=partially_distinguishes_candidates" in docs
    assert "evaluated_candidate_count=2" in docs
    assert "skipped_candidate_count=14" in docs
    assert "analysis_role_order_signature_strict_candidate_count=16" in docs
    assert "analysis_role_order_signature_all_strict_candidates_evaluated_count=0" in docs
    assert "does not auto-select" in docs
    source_replay_tokens = [
        "source_candidate_replay_present",
        "source_candidate_replay_claim_scope",
        "source_candidate_replay_source_notation",
        "source_candidate_replay_source_url",
        "source_candidate_replay_pairwise_linking",
        "source_candidate_replay_sign_count",
        "source_candidate_replay_role_order_count",
        "source_candidate_replay_orientation_issue_count",
        "source_candidate_replay=",
    ]
    auto_role_order_tokens = [
        "signed_pd_auto_role_order_present",
        "signed_pd_auto_role_order_requested",
        "signed_pd_auto_role_order_applied",
        "signed_pd_auto_role_order_status",
        "signed_pd_auto_role_order_candidate_count",
        "signed_pd_auto_role_order_strict_candidate_count",
        "signed_pd_auto_role_order_unique_strict_global_role_order",
        "signed_pd_auto_role_order=",
    ]
    for token in source_replay_tokens + auto_role_order_tokens:
        assert token in docs
    assert "JSON hosts only" in docs
    assert "guess a convention after an ambiguous skipped report" in docs
    assert "do not register fixture signs" in docs
    assert "native HOMFLY/Alexander C++ computation" in docs
    assert "not release" in docs
    assert "completion certificates" in docs
    assert "Windows ImGui real Rust dynamic-loader raw/analysis/host artifacts" in docs
    assert "iroll-imgui-real-kernel-loader-smoke.json" in docs
    assert "iroll-imgui-real-kernel-loader-smoke-imgui-analysis.json" in docs
    assert "iroll-imgui-real-kernel-loader-smoke-imgui-host.json" in docs
    assert '$realLoaderJson = "$env:TEMP\\iroll-imgui-real-kernel-loader-smoke.json"' in docs
    assert (
        '"$PWD\\native\\iroll-kernels-rust\\target\\release\\iroll_kernels_rust.dll" "$realLoaderJson"'
        in docs
    )
    assert 'imgui-analysis-summary-payload "$realLoaderJson"' in docs
    assert 'imgui-host-payload --analysis-report-json "$realLoaderJson"' in docs
    assert "iroll-imgui-real-kernel-loader-smoke-${{ matrix.os }}" in docs
    assert "artifact_kind=imgui_real_kernel_loader_smoke" in docs
    assert "claim_scope=runtime_loader_real_rust_dynamic_library_contract" in docs
    assert "kernel_loader_abi_version=6" in docs
    assert "analysis_imgui_real_kernel_loader_smoke_artifact_count=1" in docs
    assert "analysis_imgui_real_kernel_loader_smoke_passed_count=1" in docs
    assert "analysis_imgui_real_kernel_loader_smoke_dynamic_library_loaded_count=1" in docs
    assert (
        "analysis_imgui_real_kernel_loader_smoke_callback_thread_pool_completed_count=1"
        in docs
    )
    assert "analysis_imgui_real_kernel_loader_smoke_non_claim_false_count=5" in docs
    assert "native_result_handles_complete=false" in docs
    assert "complete_result_handle_abi=false" in docs
    assert "release_grade_result_handles=false" in docs
    assert "`iroll-imgui-windows-retained-artifacts-manifest.json`" in docs
    assert "iroll-imgui-windows-retained-artifacts-manifest-${{ matrix.os }}" in docs
    assert "artifact_kind=imgui_windows_retained_artifacts_manifest" in docs
    assert "claim_scope=windows_dear_imgui_retained_artifact_manifest" in docs
    assert "`retained_json_file_count=22`" in docs
    assert "`raw_analysis_host_group_count=6`" in docs
    assert "`invariant_status_host_group_count=1`" in docs
    assert "`smoke_executed_no_retained_json_count=0`" in docs
    assert "`complete_raw_analysis_host`" in docs
    assert "`invariant_status_host_only`" in docs
    assert "`production_renderer_verified=false`" in docs
    assert "`production_scheduler_completion_claimed=false`" in docs
    assert "`native_homfly_cpp_computation_claimed=false`" in docs
    assert "`native_alexander_cpp_computation_claimed=false`" in docs
    assert "`signed_release_artifacts_published=false`" in docs
    assert "iroll-imgui-windows-retained-artifacts-manifest-imgui-analysis.json" in docs
    assert "iroll-imgui-windows-retained-artifacts-manifest-imgui-host.json" in docs
    assert (
        "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_reference_count_total=23"
        in docs
    )
    assert (
        "analysis_imgui_windows_retained_artifacts_manifest_unique_retained_json_file_count_total=22"
        in docs
    )
    assert (
        "analysis_imgui_windows_retained_artifacts_manifest_shared_retained_json_file_count_total=1"
        in docs
    )
    assert "intentional shared `iroll-imgui-signed-pd.json`" in docs
    assert (
        "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_count_matched_count=1"
        in docs
    )
    assert (
        "analysis_imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total"
        in docs
    )
    assert "non_claim_evidence_index_entries=5" in docs
    assert (
        "analysis_imgui_windows_retained_artifacts_manifest_artifact_count"
        in report_schema_docs
    )
    assert (
        "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_reference_count_total"
        in report_schema_docs
    )
    assert (
        "analysis_imgui_windows_retained_artifacts_manifest_unique_retained_json_file_count_total"
        in report_schema_docs
    )
    assert (
        "analysis_imgui_windows_retained_artifacts_manifest_shared_retained_json_file_count_total"
        in report_schema_docs
    )
    assert (
        "imgui_windows_retained_artifacts_manifest_shared_files=iroll-imgui-signed-pd.json"
        in report_schema_docs
    )
    assert (
        "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_count_matched_count"
        in report_schema_docs
    )
    assert (
        "analysis_imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total"
        in report_schema_docs
    )
    assert "imgui_real_kernel_loader_smoke" in report_schema_docs
    assert "analysis_imgui_real_kernel_loader_smoke_artifact_count" in report_schema_docs
    assert "dynamic_library_loaded=true" in report_schema_docs
    assert "thread_pool_completed=true" in report_schema_docs
    assert "not native HOMFLY/Alexander C++ computation" in report_schema_docs
    assert "retained-artifact" in report_schema_docs
    assert "discoverability and audit evidence only" in report_schema_docs
    assert "not release completion evidence" in report_schema_docs
    assert "ImGui analysis/host bridge" in docs
    assert "full ImGui host payload" in docs
    assert "host-visible benchmark summary" in docs
    assert "`iroll-imgui-signed-pd.json`" in docs
    assert "`iroll-imgui-signed-pd-invariant-status.json`" in docs
    assert "signed-PD recompute scheduler smoke" in docs
    assert "Rust C ABI 19 / current Dear ImGui ABI 117" in docs
    assert "unsupported invariant result-handle lifecycle report" in docs
    assert "method=invariant_result_handle_report" in docs
    assert "imgui_invariant_status_payload_from_reports([report])" in docs
    assert "imgui-host-payload --invariant-report-json" in docs
    assert "both skipped rows in the `invariants` section" in docs
    assert "claim_scope=unsupported_lifecycle_probe_only" in docs
    assert "cuda_gpu_benchmark_evidence" in docs
    assert "iroll_core_benchmark_matrix" in docs
    assert "benchmark_cuda_gpu_*" in docs
    assert "hosted_cuda_ci_claimed=false" in docs
    assert "release_grade_gpu_speedup_claimed=false" in docs
    assert "release-grade Rust or GPU speedups" in docs
    assert "not signed release artifacts" in docs
    assert "base install does not require Rust, GPU, C++, or Dear ImGui" in docs
    assert "shared strict JSON writer boundary" in docs
    assert "`dump_report()`" in docs
    assert "`write_report()`" in docs
    assert "reject non-finite `NaN`/`Infinity` values before writing files" in docs
    assert "`allow_nan=False`" in docs
    assert "host-loadable" in docs
    assert "`iroll validate-table` remains the optional table-import gate" in docs
    assert "`source_metadata_summary` provenance scan" in docs
    assert "`source_url_without_source_count`" in docs
    assert "`source_url_without_source_rows`" in docs
    assert "`all_source_urls_have_source`" in docs
    assert "`summary_consistency` self-checks" in docs
    assert "`claim_scope=table_source_metadata_summary_self_consistency`" in docs
    assert "`source_rows`" in docs
    assert "`source_value_counts`" in docs
    assert "`source_value_rows`" in docs
    assert "`source_value_count_total_matched`" in docs
    assert "`source_value_row_count_total_matched`" in docs
    assert "`source_url_rows`" in docs
    assert "`source_with_source_url_count`" in docs
    assert "`source_with_source_url_rows`" in docs
    assert "`valid_source_url_count`" in docs
    assert "`valid_source_url_rows`" in docs
    assert "`source_url_scheme_rows`" in docs
    assert "`source_url_domain_rows`" in docs
    assert "`source_url_missing_scheme_count`" in docs
    assert "`source_url_missing_scheme_rows`" in docs
    assert "`source_url_missing_domain_count`" in docs
    assert "`source_url_missing_domain_rows`" in docs
    assert "`source_url_scheme_row_count_total_matched`" in docs
    assert "`source_url_domain_row_count_total_matched`" in docs
    assert "`convention_rows`" in docs
    assert "`convention_metadata_rows`" in docs
    assert "`convention_metadata_name_rows`" in docs
    assert "`convention_metadata_without_name_count`" in docs
    assert "`convention_metadata_without_name_rows`" in docs
    assert "non-empty known-limitation text coverage" in docs
    assert "`known_limitations_rows`" in docs
    assert "`provenance_review_ready`" in docs
    assert "`provenance_blocker_count`" in docs
    assert "`provenance_blocker_codes`" in docs
    assert "`provenance_blocker_details`" in docs
    assert "`provenance_blocker_summary_consistency`" in docs
    assert "`claim_scope=table_source_metadata_provenance_blocker_self_consistency`" in docs
    assert "`review_ready_matched`" in docs
    assert "`expected_convention`" in docs
    assert "`convention_mismatch`" in docs
    assert "`convention_mismatch_count_matched`" in docs
    assert "`all_conventions_match_expected`" in docs
    assert "`source_url_issue_codes`" in docs
    assert "`source_url_issue_code_counts`" in docs
    assert "`source_url_issue_code_rows`" in docs
    assert "`source_url_issue_code_total`" in docs
    assert "`source_url_issue_code_count_total_matched`" in docs
    assert "`source_url_issue_code_invalid_row_coverage_matched`" in docs
    assert "`missing_scheme`" in docs
    assert "`missing_domain`" in docs
    assert (
        "validate_table_source_metadata_source_url_issue_codes=missing_domain:1|missing_scheme:1"
        in docs
    )
    assert (
        "validate_table_source_metadata_source_url_issue_code_rows=missing_domain:$[0]|missing_scheme:$[0]"
        in docs
    )
    assert (
        "analysis_validate_table_source_metadata_source_url_issue_code_total=2"
        in docs
    )
    assert "`unsupported_scheme`" in docs
    assert "`missing_source_url`" in docs
    assert "`invalid_source_url`" in docs
    assert "`missing_convention`" in docs
    assert "matched convention/known-limitation" in docs
    assert "`table_correctness_certified=false`" in docs
    assert "`external_source_verified=false`" in docs
    assert "`imgui-analysis-summary-payload`" in docs
    assert "`imgui-host-payload --analysis-report-json`" in docs
    assert "`source_method=validate_table_source_metadata_report`" in docs
    assert "`analysis_validate_table_source_metadata_*`" in docs
    assert "`analysis_validate_table_source_metadata_source_value_label_count`" in docs
    assert "`analysis_validate_table_source_metadata_source_value_label_count=2`" in docs
    assert (
        "`analysis_validate_table_source_metadata_source_value_row_count_total`"
        in docs
    )
    assert "`analysis_validate_table_source_metadata_source_url_scheme_count`" in docs
    assert "`analysis_validate_table_source_metadata_source_url_scheme_count=1`" in docs
    assert "`analysis_validate_table_source_metadata_source_url_domain_count`" in docs
    assert "`analysis_validate_table_source_metadata_source_url_domain_count=2`" in docs
    validate_table_source_completeness_row_pack_fields = [
        "analysis_validate_table_source_metadata_source_completeness_row_count",
        "analysis_validate_table_source_metadata_source_completeness_row_count_matched_count",
        "analysis_validate_table_source_metadata_source_completeness_source_count_matched_count",
        "analysis_validate_table_source_metadata_source_completeness_source_url_count_matched_count",
        "analysis_validate_table_source_metadata_source_completeness_invalid_url_count_matched_count",
    ]
    for field in validate_table_source_completeness_row_pack_fields:
        assert field in docs
        assert field in report_schema_docs
    assert (
        "`analysis_validate_table_source_metadata_source_completeness_row_count=2`"
        in docs
    )
    for field in validate_table_source_completeness_row_pack_fields[1:]:
        assert f"`{field}=1`" in docs
    validate_table_source_completeness_fields = [
        "analysis_validate_table_source_metadata_all_records_have_source_count",
        "analysis_validate_table_source_metadata_all_source_records_have_source_url_count",
        "analysis_validate_table_source_metadata_all_source_urls_have_source_count",
        "analysis_validate_table_source_metadata_all_source_urls_are_http_or_https_count",
    ]
    for field in validate_table_source_completeness_fields:
        assert f"`{field}=1`" in docs
        assert field in workflow
        assert field in report_schema_docs
    assert (
        "`validate_table_source_metadata_source_value_rows=Knot Atlas:$[0]|KnotInfo:$[1]`"
        in docs
    )
    assert (
        "`validate_table_source_metadata_source_url_domain_rows=katlas.org:$[0]|knotinfo.math.indiana.edu:$[1]`"
        in docs
    )
    assert "`validate_table_source_metadata_source_url_issue_codes=unsupported_scheme:1`" in docs
    assert "`validate_table_source_metadata_source_url_issue_code_rows=unsupported_scheme:$[0]`" in docs
    assert "`valid=true`" in docs
    assert "`analysis_validate_table_source_metadata_issue_count=0`" in docs
    assert (
        "`analysis_validate_table_source_metadata_provenance_blocker_count=1`"
        in docs
    )
    assert (
        "`validate_table_source_metadata_provenance_blocker_codes=missing_source,missing_source_url,source_url_without_source,invalid_source_url,missing_convention`"
        in docs
    )
    assert "`validate_table_source_metadata_missing_source_rows=$[0]`" in docs
    assert (
        "analysis_validate_table_source_metadata_convention_metadata_without_name_count"
        in docs
    )
    assert "not mistake import validation for external table" in docs
    assert "artifact contract evidence only, not CUDA parity evidence" in docs
    assert "expected parity-failure artifact shape" in docs
    assert "iroll-gpu-smoke-simulated-parity-failure" in docs
    assert "gpu-smoke-no-cuda-imgui-analysis.json" in docs
    assert "gpu-smoke-no-cuda-imgui-host.json" in docs
    assert "gpu-smoke-simulated-parity-failure-imgui-analysis.json" in docs
    assert "gpu-smoke-simulated-parity-failure-imgui-host.json" in docs
    assert "GPU smoke ImGui analysis/host bridge" in docs
    assert "--simulate-parity-failure" in docs
    assert "environment_witness" in docs
    assert "simulated_parity_failure=true" in docs
    assert "cuda_runtime_observed=false" in docs
    assert "gpu_dispatch_parity_smoke_claimed=false" in docs
    assert "cuda_parity_claimed=false" in docs
    assert "structured no-CUDA GPU smoke artifact" in rust_kernel_docs
    assert "claim_scope=optional_no_cuda_boundary" in rust_kernel_docs
    assert "gpu_dispatch_parity_smoke_claimed=false" in rust_kernel_docs
    assert "cuda_parity_claimed=false" in rust_kernel_docs
    assert "cuda_gpu_benchmark_evidence" in rust_kernel_docs
    assert "iroll_core_benchmark_matrix" in rust_kernel_docs
    assert "ImGui analysis/host bridge for GPU smoke artifacts" in rust_kernel_docs
    assert "imgui-host-payload --analysis-report-json" in rust_kernel_docs
    assert "analysis_gpu_smoke_*" in rust_kernel_docs
    assert "analysis_gpu_smoke_release_gate_*_blocker_count" in rust_kernel_docs
    assert "imgui-host-payload --invariant-report-json unsupported-homfly.json" in (
        rust_kernel_docs
    )
    assert "under its `invariants` section" in rust_kernel_docs
    assert "leaves analysis summaries empty" in rust_kernel_docs
    assert "hosted_cuda_ci_claimed=false" in rust_kernel_docs
    assert "release_grade_gpu_speedup_claimed=false" in rust_kernel_docs
    assert "not CUDA parity evidence" in rust_kernel_docs
    assert "not a release-grade speedup claim" in rust_kernel_docs
    assert "iroll_core_benchmark_matrix" in report_schema_docs
    assert "benchmark_matrix_*" in report_schema_docs
    assert "benchmark_speedup_*" in report_schema_docs
    assert "benchmark_cuda_gpu_*" in report_schema_docs
    assert "local_backend_benchmark_matrix_profiling_evidence" in report_schema_docs
    assert "gpu_smoke_*" in report_schema_docs
    assert "gpu_smoke_unavailable_boundary" in report_schema_docs
    assert "gpu_smoke_parity_failure" in report_schema_docs
    gpu_release_gate_blocker_fields = [
        "analysis_gpu_smoke_release_gate_gpu_backend_unavailable_blocker_count",
        "analysis_gpu_smoke_release_gate_cuda_runtime_not_observed_blocker_count",
        "analysis_gpu_smoke_release_gate_required_checks_incomplete_blocker_count",
        "analysis_gpu_smoke_release_gate_required_checks_failed_blocker_count",
        "analysis_gpu_smoke_release_gate_forced_unavailable_blocker_count",
        "analysis_gpu_smoke_release_gate_simulated_parity_failure_blocker_count",
    ]
    for field in gpu_release_gate_blocker_fields:
        assert field in workflow
        assert field in docs
        assert field in rust_kernel_docs
        assert field.removeprefix("analysis_") in report_schema_docs
    assert "retained_evidence_kinds=ci_retained_artifact" in docs
    assert (
        "validate_table_source_metadata_source_value_rows=Knot Atlas:$[0]|KnotInfo:$[1]"
        in docs
    )
    assert "validate_table_source_metadata_source_url_schemes=https:2" in docs
    assert (
        "validate_table_source_metadata_source_url_domain_rows=katlas.org:$[0]|knotinfo.math.indiana.edu:$[1]"
        in docs
    )
    assert "validate_table_source_metadata_known_limitations_rows=$[0]" in docs
    assert (
        "validate_table_source_metadata_convention_metadata_without_name_rows=$[0]"
        in docs
    )
    assert "validate_table_source_metadata_source_url_issue_codes=unsupported_scheme:1" in docs
    assert (
        "validate_table_source_metadata_source_url_issue_code_rows=unsupported_scheme:$[0]"
        in docs
    )
    assert (
        "validate_table_source_metadata_provenance_blocker_codes=missing_source,missing_source_url,source_url_without_source,invalid_source_url,missing_convention"
        in docs
    )
    assert "validate_table_source_metadata_missing_source_rows=$[0]" in docs
    assert "validate_table_source_metadata_missing_source_url_rows=$[1]" in docs
    assert (
        "validate_table_source_metadata_source_url_without_source_rows=$[0]"
        in docs
    )
    assert "validate-table-source-metadata.json" in report_schema_docs
    assert "validate-table-source-metadata-imgui-analysis.json" in report_schema_docs
    assert "validate-table-source-metadata-imgui-host.json" in report_schema_docs
    assert "validate-table-source-metadata-blocked.json" in report_schema_docs
    assert (
        "validate-table-source-metadata-blocked-imgui-analysis.json"
        in report_schema_docs
    )
    assert (
        "validate-table-source-metadata-blocked-imgui-host.json"
        in report_schema_docs
    )
    assert (
        "validate-table-source-metadata-invalid-known-limitations.json"
        in report_schema_docs
    )
    assert (
        "validate-table-source-metadata-invalid-known-limitations-imgui-analysis.json"
        in report_schema_docs
    )
    assert (
        "validate-table-source-metadata-invalid-known-limitations-imgui-host.json"
        in report_schema_docs
    )
    assert (
        "validate-table-source-metadata-invalid-known-limitations-item.json"
        in report_schema_docs
    )
    assert (
        "validate-table-source-metadata-invalid-known-limitations-item-imgui-analysis.json"
        in report_schema_docs
    )
    assert (
        "validate-table-source-metadata-invalid-known-limitations-item-imgui-host.json"
        in report_schema_docs
    )
    assert (
        "validate-table-source-metadata-invalid-source-url.json"
        in report_schema_docs
    )
    assert (
        "validate-table-source-metadata-invalid-source-url-imgui-analysis.json"
        in report_schema_docs
    )
    assert (
        "validate-table-source-metadata-invalid-source-url-imgui-host.json"
        in report_schema_docs
    )
    assert (
        "validate-table-source-metadata-provenance-blockers.json"
        in report_schema_docs
    )
    assert (
        "validate-table-source-metadata-provenance-blockers-imgui-analysis.json"
        in report_schema_docs
    )
    assert (
        "validate-table-source-metadata-provenance-blockers-imgui-host.json"
        in report_schema_docs
    )
    assert (
        "iroll-validate-table-source-metadata-py${{ matrix.python-version }}"
        in report_schema_docs
    )
    assert "analysis_validate_table_source_metadata_artifact_count=1" in (
        report_schema_docs
    )
    assert "analysis_validate_table_source_metadata_record_count=2" in (
        report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_source_value_label_count"
        in report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_source_value_row_count_total"
        in report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_source_url_scheme_count"
        in report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_source_url_domain_count"
        in report_schema_docs
    )
    assert (
        "validate_table_source_metadata_source_value_rows=..."
        in report_schema_docs
    )
    assert (
        "validate_table_source_metadata_convention_metadata_without_name_rows=..."
        in report_schema_docs
    )
    assert (
        "validate_table_source_metadata_source_url_issue_codes=..."
        in report_schema_docs
    )
    assert (
        "validate_table_source_metadata_convention_mismatch_rows=..."
        in report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_provenance_review_ready_count=1"
        in report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_table_correctness_certified_count=0"
        in report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_external_source_verified_count=0"
        in report_schema_docs
    )
    assert "convention metadata-without-name counts" in report_schema_docs
    assert (
        "analysis_validate_table_source_metadata_convention_metadata_without_name_count"
        in report_schema_docs
    )
    assert "`valid=false`" in report_schema_docs
    assert "`provenance_review_ready=false`" in report_schema_docs
    assert "`provenance_blocker_codes=[\"convention_mismatch\"]`" in (
        report_schema_docs
    )
    assert "`convention_mismatch_count=1`" in report_schema_docs
    assert "analysis_validate_table_source_metadata_valid_count=0" in (
        report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_provenance_review_ready_count=0"
        in report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_convention_mismatch_count=1"
        in report_schema_docs
    )
    assert "`path=$[0].known_limitations`" in report_schema_docs
    assert "analysis_validate_table_source_metadata_issue_count=1" in (
        report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_provenance_blocker_count=0"
        in report_schema_docs
    )
    assert "analysis_validate_table_source_metadata_known_limitations_count=0" in (
        report_schema_docs
    )
    assert "metadata-shape validation failures" in report_schema_docs
    assert (
        "`validate_table_source_metadata_issue_paths=...`"
        in report_schema_docs
    )
    assert (
        "`validate_table_source_metadata_issue_messages=...`"
        in report_schema_docs
    )
    assert "`path=$[0].known_limitations[1]`" in report_schema_docs
    assert "`known_limitations_count=1`" in report_schema_docs
    assert "`validate_table_source_metadata_known_limitations_rows=$[0]`" in (
        report_schema_docs
    )
    assert "item-level hygiene errors keep their precise" in (
        report_schema_docs
    )
    assert "precise issue path `$[0].known_limitations[1]`" in execution_status_docs
    assert "`known_limitations_count=1`" in execution_status_docs
    assert (
        "`validate_table_source_metadata_known_limitations_rows=$[0]`"
        in execution_status_docs
    )
    assert "`provenance_review_ready=true` with zero provenance blockers" in (
        execution_status_docs
    )
    assert "item-level metadata-shape evidence only" in execution_status_docs
    assert "`provenance_blocker_codes=[\"invalid_source_url\"]`" in (
        report_schema_docs
    )
    assert "`source_url_issue_code_counts={\"unsupported_scheme\":1}`" in (
        report_schema_docs
    )
    assert "analysis_validate_table_source_metadata_invalid_source_url_count=1" in (
        report_schema_docs
    )
    assert "analysis_validate_table_source_metadata_valid_source_url_count=0" in (
        report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_all_records_have_source_count=1"
        in report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_all_source_records_have_source_url_count=1"
        in report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_all_source_urls_have_source_count=1"
        in report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_all_source_urls_are_http_or_https_count=0"
        in report_schema_docs
    )
    assert "`all_source_urls_are_http_or_https=false`" in execution_status_docs
    assert (
        "`analysis_validate_table_source_metadata_all_source_urls_are_http_or_https_count=0`"
        in execution_status_docs
    )
    assert (
        "analysis_validate_table_source_metadata_source_url_missing_scheme_count"
        in report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_source_url_missing_domain_count"
        in report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_source_url_issue_code_total"
        in report_schema_docs
    )
    assert "URL provenance blockers visible" in report_schema_docs
    assert (
        "`provenance_blocker_codes=[\"missing_source\",\"missing_source_url\",\"source_url_without_source\",\"invalid_source_url\",\"missing_convention\"]`"
        in report_schema_docs
    )
    assert "analysis_validate_table_source_metadata_record_count=4" in (
        report_schema_docs
    )
    assert "analysis_validate_table_source_metadata_provenance_blocker_count=5" in (
        report_schema_docs
    )
    assert "analysis_validate_table_source_metadata_missing_source_count=1" in (
        report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_missing_source_url_count=1"
        in report_schema_docs
    )
    assert (
        "analysis_validate_table_source_metadata_source_url_without_source_count=1"
        in report_schema_docs
    )
    assert "retained optional-import reviewer evidence only" in report_schema_docs
    assert (
        "bounded_alexander_maturity_path_summary_consistency_available_count"
        in report_schema_docs
    )
    assert "report-accounting self-consistency" in report_schema_docs
    assert "wirtinger_relation_shape_valid" in report_schema_docs
    assert "over^sign under_in over^-sign under_out^-1" in report_schema_docs
    assert "generator-to-component coverage" in report_schema_docs
    assert "Rust C ABI 19 and Dear ImGui ABI 117 are unchanged" in report_schema_docs
    assert workflow.count("if-no-files-found: error") >= 5
    assert workflow.index("iroll_imgui_signed_pd_json_export_smoke.exe") < workflow.index(
        "python -m iroll.cli homfly-pd $signedPdJson"
    )
    assert workflow.index("python -m iroll.cli homfly-pd $signedPdJson") < workflow.index(
        "$signedPdStatusJson"
    )
    assert workflow.index("$signedPdStatusJson") < workflow.index(
        "Upload Windows Dear ImGui signed-PD JSON smoke artifact"
    )
