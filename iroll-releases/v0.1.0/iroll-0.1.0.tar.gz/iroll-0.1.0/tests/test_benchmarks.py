from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BENCHMARK_PATH = ROOT / "benchmarks" / "core_bench.py"


def load_core_bench():
    spec = importlib.util.spec_from_file_location("iroll_core_bench", BENCHMARK_PATH)
    assert spec is not None
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def test_core_benchmark_matrix_reports_numpy_workloads() -> None:
    bench = load_core_bench()

    result = bench.benchmark_matrix(point_sizes=(16,), backends=("numpy",), repeat=1)

    assert result["method"] == "iroll_core_benchmark_matrix"
    assert result["point_sizes"] == [16]
    assert result["backends"] == ["numpy"]
    assert result["workloads"] == ["crossings", "contacts", "writhe", "gaussian_linking"]
    assert result["completed_count"] == 4
    assert result["failed_count"] == 0
    assert all(entry["status"] == "completed" for entry in result["results"])
    assert all(entry["seconds_min"] >= 0.0 for entry in result["results"])
    assert result["backend_report"]["backends"]["numpy"]["available"] is True
    assert result["backend_contracts"]["numpy"]["available"] is True
    assert result["backend_contracts"]["numpy"]["capability_count"] == len(
        result["backend_report"]["kernel_capabilities"]
    )
    assert (
        result["backend_contracts"]["numpy"]["release_grade_acceleration_claimed"]
        is False
    )
    assert result["environment"]["python_version"]
    assert result["environment"]["platform"]

    summary = result["matrix_summary"]
    assert summary["method"] == "iroll_core_benchmark_matrix_run_summary"
    assert summary["expected_row_count"] == 4
    assert summary["row_count"] == 4
    assert summary["completed_count"] == 4
    assert summary["skipped_count"] == 0
    assert summary["failed_count"] == 0
    assert summary["status_counts"] == {"completed": 4, "skipped": 0, "failed": 0}
    assert summary["all_requested_rows_completed"] is True
    assert summary["has_failures"] is False
    assert summary["per_backend"]["numpy"]["completed_workloads"] == [
        "crossings",
        "contacts",
        "writhe",
        "gaussian_linking",
    ]
    assert summary["per_backend"]["numpy"]["completed_point_sizes"] == [16]
    assert summary["per_workload"]["crossings"]["completed_count"] == 1

    evidence = result["speedup_evidence"]
    assert evidence["method"] == "iroll_core_benchmark_speedup_evidence"
    assert evidence["baseline_backend"] == "numpy"
    assert evidence["repeat"] == 1
    assert evidence["release_grade_speedup_claimed"] is False
    assert evidence["candidate_speedup_count"] == 0
    assert len(evidence["comparisons"]) == 4
    assert all(row["status"] == "completed" for row in evidence["comparisons"])
    assert evidence["release_gate"] == {
        "repeat": 1,
        "minimum_repeat_for_release_claim": 3,
        "repeat_satisfied": False,
        "speedup_threshold": 1.25,
        "threshold_candidate_count": 0,
        "threshold_candidate_count_by_backend": {},
        "comparison_count": 4,
        "completed_comparison_count": 4,
        "missing_baseline_count": 0,
        "release_grade_speedup_claimed": False,
        "release_grade_speedup_claimed_by_backend": {},
        "blocking_reasons": [
            "repeat_below_minimum",
            "no_backend_met_speedup_threshold",
        ],
    }
    assert evidence["backend_candidate_summary"] == {}

    gpu_evidence = result["cuda_gpu_benchmark_evidence"]
    assert gpu_evidence["method"] == "iroll_core_cuda_gpu_benchmark_evidence"
    assert gpu_evidence["gate_scope"] == "local_gpu_benchmark_witness"
    assert gpu_evidence["gpu_backend_requested"] is False
    assert gpu_evidence["gpu_requested_row_count"] == 0
    assert gpu_evidence["gpu_completed_row_count"] == 0
    assert gpu_evidence["gpu_threshold_candidate_count"] == 0
    assert gpu_evidence["generic_speedup_gate_claimed_for_gpu"] is False
    assert gpu_evidence["local_gpu_speedup_threshold_met"] is False
    assert gpu_evidence["hosted_cuda_ci_claimed"] is False
    assert gpu_evidence["cuda_parity_claimed"] is False
    assert gpu_evidence["release_grade_gpu_speedup_claimed"] is False
    assert "gpu_backend_not_requested" in gpu_evidence["blocking_reasons"]
    assert "hosted_cuda_ci_not_observed" in gpu_evidence["blocking_reasons"]


def test_core_benchmark_matrix_run_summary_tracks_skips_and_failures() -> None:
    bench = load_core_bench()
    rows = [
        {
            "workload": "crossings",
            "backend": "numpy",
            "points": 32,
            "status": "completed",
        },
        {
            "workload": "crossings",
            "backend": "rust",
            "points": 32,
            "status": "skipped",
            "reason": "rust backend is not available",
        },
        {
            "workload": "crossings",
            "backend": "gpu",
            "points": 32,
            "status": "failed",
            "reason": "kernel launch failed",
        },
    ]

    summary = bench.benchmark_matrix_run_summary(
        rows,
        point_sizes=(32,),
        backends=("numpy", "rust", "gpu"),
        workloads=("crossings",),
    )

    assert summary["expected_row_count"] == 3
    assert summary["row_count"] == 3
    assert summary["status_counts"] == {"completed": 1, "skipped": 1, "failed": 1}
    assert summary["all_requested_rows_completed"] is False
    assert summary["has_failures"] is True
    assert summary["per_backend"]["numpy"]["completed_workloads"] == ["crossings"]
    assert summary["per_backend"]["rust"]["skipped_workloads"] == ["crossings"]
    assert summary["per_backend"]["rust"]["skipped_reasons"] == [
        "rust backend is not available"
    ]
    assert summary["per_backend"]["gpu"]["failed_workloads"] == ["crossings"]
    assert summary["per_backend"]["gpu"]["failure_reasons"] == [
        "kernel launch failed"
    ]


def test_core_benchmark_speedup_evidence_gates_release_claims() -> None:
    bench = load_core_bench()
    rows = [
        {
            "workload": "contacts",
            "backend": "numpy",
            "points": 128,
            "status": "completed",
            "seconds_median": 2.0,
        },
        {
            "workload": "contacts",
            "backend": "rust",
            "points": 128,
            "status": "completed",
            "seconds_median": 1.0,
        },
    ]

    smoke = bench.benchmark_speedup_evidence(rows, repeat=1)
    repeated = bench.benchmark_speedup_evidence(rows, repeat=3)
    stricter = bench.benchmark_speedup_evidence(
        rows,
        repeat=3,
        speedup_threshold=3.0,
        minimum_repeat_for_release_claim=2,
    )

    assert smoke["candidate_speedup_count"] == 1
    assert smoke["release_grade_speedup_claimed"] is False
    assert smoke["release_gate"]["repeat_satisfied"] is False
    assert smoke["release_gate"]["threshold_candidate_count"] == 1
    assert smoke["release_gate"]["threshold_candidate_count_by_backend"] == {
        "rust": 1
    }
    assert smoke["release_gate"]["release_grade_speedup_claimed_by_backend"] == {
        "rust": False
    }
    assert smoke["release_gate"]["blocking_reasons"] == ["repeat_below_minimum"]
    assert repeated["release_grade_speedup_claimed"] is True
    assert repeated["release_gate"]["release_grade_speedup_claimed"] is True
    assert repeated["release_gate"]["release_grade_speedup_claimed_by_backend"] == {
        "rust": True
    }
    assert repeated["release_gate"]["blocking_reasons"] == []
    assert stricter["candidate_speedup_count"] == 0
    assert stricter["release_grade_speedup_claimed"] is False
    assert stricter["release_gate"]["threshold_candidate_count"] == 0
    assert stricter["release_gate"]["threshold_candidate_count_by_backend"] == {
        "rust": 0
    }
    assert stricter["release_gate"]["release_grade_speedup_claimed_by_backend"] == {
        "rust": False
    }
    assert stricter["release_gate"]["blocking_reasons"] == [
        "no_backend_met_speedup_threshold"
    ]
    assert stricter["speedup_threshold"] == 3.0
    assert stricter["minimum_repeat_for_release_claim"] == 2
    comparison = repeated["comparisons"][0]
    assert comparison["fastest_backend"] == "rust"
    assert comparison["backend_speedups"] == [
        {
            "backend": "rust",
            "seconds_median": 1.0,
            "speedup_vs_baseline": 2.0,
            "meets_threshold": True,
        }
    ]
    assert repeated["backend_candidate_summary"] == {
        "rust": {
            "threshold_candidate_count": 1,
            "threshold_workloads": ["contacts"],
            "threshold_point_sizes": [128],
            "fastest_comparison_count": 1,
            "max_speedup_vs_baseline": 2.0,
            "release_grade_speedup_claimed": True,
        }
    }


def test_core_benchmark_cuda_gpu_evidence_keeps_local_thresholds_non_release() -> None:
    bench = load_core_bench()
    rows = [
        {
            "workload": "contacts",
            "backend": "numpy",
            "points": 128,
            "status": "completed",
            "seconds_median": 2.0,
        },
        {
            "workload": "contacts",
            "backend": "gpu",
            "points": 128,
            "status": "completed",
            "seconds_median": 0.5,
        },
    ]
    report = {
        "backends": {
            "gpu": {
                "available": True,
                "backend_info": {
                    "backend": "cupy",
                    "cuda_runtime_version": 12080,
                    "device_count": 1,
                },
            }
        }
    }
    speedup = bench.benchmark_speedup_evidence(rows, repeat=3)

    evidence = bench.benchmark_cuda_gpu_evidence(
        rows,
        backend_report=report,
        speedup_evidence=speedup,
        point_sizes=(128,),
        backends=("numpy", "gpu"),
        workloads=("contacts",),
    )

    assert evidence["gpu_backend_requested"] is True
    assert evidence["gpu_backend_available"] is True
    assert evidence["cuda_runtime_observed"] is True
    assert evidence["gpu_requested_row_count"] == 1
    assert evidence["gpu_completed_row_count"] == 1
    assert evidence["gpu_skipped_row_count"] == 0
    assert evidence["gpu_failed_row_count"] == 0
    assert evidence["repeat_satisfied"] is True
    assert evidence["gpu_threshold_candidate_count"] == 1
    assert evidence["generic_speedup_gate_claimed_for_gpu"] is True
    assert evidence["local_gpu_speedup_threshold_met"] is True
    assert evidence["hosted_cuda_ci_claimed"] is False
    assert evidence["cuda_parity_claimed"] is False
    assert evidence["release_grade_gpu_speedup_claimed"] is False
    assert evidence["blocking_reasons"] == [
        "cuda_parity_not_claimed",
        "hosted_cuda_ci_not_observed",
    ]
    assert evidence["blocking_reason_count"] == 2


def test_core_benchmark_backend_contract_summary_extracts_native_metadata() -> None:
    bench = load_core_bench()
    report = {
        "kernel_capabilities": [
            "segment_segment_distance",
            "segment_bbox_candidate_pairs_2d",
        ],
        "backends": {
            "numpy": {
                "available": True,
                "selected_by_auto": False,
                "explicit_only": False,
                "capabilities": {
                    "segment_segment_distance": True,
                    "segment_bbox_candidate_pairs_2d": True,
                },
                "missing_capabilities": [],
            },
            "rust": {
                "available": True,
                "selected_by_auto": True,
                "explicit_only": False,
                "capabilities": {
                    "segment_segment_distance": True,
                    "segment_bbox_candidate_pairs_2d": True,
                },
                "missing_capabilities": [],
                "backend_info": {
                    "candidate_pair_algorithm": "adaptive_axis_sweep_active_set",
                },
            },
            "gpu": {
                "available": True,
                "selected_by_auto": False,
                "explicit_only": True,
                "capabilities": {
                    "segment_segment_distance": True,
                    "segment_bbox_candidate_pairs_2d": False,
                },
                "missing_capabilities": ["segment_bbox_candidate_pairs_2d"],
                "backend_info": {
                    "raw_cuda_kernels": {
                        "segment_segment_distances": True,
                        "segment_bbox_candidate_pairs_2d": True,
                        "unused_optional_kernel": False,
                    },
                    "candidate_pair_compaction": {
                        "strategy": "raw_cuda_block_count_then_raw_kernel_fill",
                        "count_pass": "raw_cuda_block_count",
                        "count_pass_allocates_output_pairs": False,
                        "count_pass_runs_on_gpu": True,
                        "count_pass_reduces_block_counts_on_host": True,
                        "fill_pass_allocates_accepted_pairs_only": True,
                        "uses_atomic_compaction": True,
                    },
                },
            },
        },
    }

    summary = bench.benchmark_backend_contract_summary(report)

    assert summary["numpy"] == {
        "available": True,
        "selected_by_auto": False,
        "explicit_only": False,
        "capability_count": 2,
        "expected_capability_count": 2,
        "missing_capability_count": 0,
        "missing_capabilities": [],
        "candidate_pair_algorithm": None,
        "candidate_pair_compaction_strategy": None,
        "raw_cuda_kernel_count": 0,
        "release_grade_acceleration_claimed": False,
    }
    assert summary["rust"]["candidate_pair_algorithm"] == "adaptive_axis_sweep_active_set"
    assert summary["rust"]["release_grade_acceleration_claimed"] is False
    assert summary["gpu"]["explicit_only"] is True
    assert summary["gpu"]["capability_count"] == 1
    assert summary["gpu"]["missing_capability_count"] == 1
    assert (
        summary["gpu"]["candidate_pair_compaction_strategy"]
        == "raw_cuda_block_count_then_raw_kernel_fill"
    )
    assert summary["gpu"]["raw_cuda_kernel_count"] == 2
    assert summary["gpu"]["gpu_count_pass"] == "raw_cuda_block_count"
    assert summary["gpu"]["gpu_count_pass_allocates_output_pairs"] is False
    assert summary["gpu"]["gpu_count_pass_runs_on_gpu"] is True
    assert summary["gpu"]["gpu_count_pass_reduces_block_counts_on_host"] is True
    assert summary["gpu"]["gpu_fill_pass_allocates_accepted_pairs_only"] is True
    assert summary["gpu"]["gpu_uses_atomic_compaction"] is True


def test_core_benchmark_matrix_cli_json_smoke() -> None:
    completed = subprocess.run(
        [
            sys.executable,
            str(BENCHMARK_PATH),
            "--matrix",
            "--point-sizes",
            "16",
            "--backends",
            "numpy",
            "--speedup-threshold",
            "1.1",
            "--min-release-repeat",
            "2",
            "--json",
        ],
        cwd=ROOT,
        check=True,
        text=True,
        capture_output=True,
    )

    payload = json.loads(completed.stdout)

    assert payload["method"] == "iroll_core_benchmark_matrix"
    assert payload["completed_count"] == 4
    assert payload["matrix_summary"]["all_requested_rows_completed"] is True
    assert payload["matrix_summary"]["status_counts"]["completed"] == 4
    assert payload["failed_count"] == 0
    assert payload["environment"]["python_version"]
    assert payload["speedup_evidence"]["speedup_threshold"] == 1.1
    assert payload["speedup_evidence"]["minimum_repeat_for_release_claim"] == 2
    assert payload["speedup_evidence"]["release_gate"]["repeat_satisfied"] is False
    assert "repeat_below_minimum" in payload["speedup_evidence"]["release_gate"][
        "blocking_reasons"
    ]
