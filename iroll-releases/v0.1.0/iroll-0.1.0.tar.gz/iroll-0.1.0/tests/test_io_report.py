from __future__ import annotations

import math
from pathlib import Path

import pytest

from iroll.io import dump_report, write_report


def test_dump_report_rejects_non_finite_numbers() -> None:
    with pytest.raises(ValueError, match="Out of range float values"):
        dump_report({"value": math.nan})


def test_write_report_rejects_non_finite_numbers_before_writing(tmp_path) -> None:
    path = tmp_path / "report.json"

    with pytest.raises(ValueError, match="Out of range float values"):
        write_report({"value": math.inf}, path)

    assert not path.exists()


def test_dump_report_remains_sorted_strict_json() -> None:
    assert dump_report({"b": 2, "a": 1}, indent=None) == '{"a": 1, "b": 2}'


def test_report_schema_docs_cover_strict_writer_boundary() -> None:
    root = Path(__file__).resolve().parents[1]
    docs = (root / "docs" / "report-schema.md").read_text(encoding="utf-8")
    checklist = (root / "docs" / "mvp-completion-checklist.md").read_text(
        encoding="utf-8"
    )

    assert "strict JSON serialization" in docs
    assert "shared report writer uses the same strict JSON boundary" in docs
    assert "non-finite `NaN`/`Infinity` values are rejected" in docs
    assert "before CLI/report files are written" in docs
    assert "strict JSON-compatible and schema-checkable" in checklist
    assert "rejects non-finite `NaN`/`Infinity` values" in checklist
    assert "before writing CLI or" in checklist
    assert "report files" in checklist
