from __future__ import annotations

import ctypes
import importlib.machinery
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import pytest

from iroll.reports import imgui_invariant_status_payload_from_reports
from iroll.kernels import (
    KernelBackendError,
    backend_report,
    compute_gaussian_linking_number,
    compute_writhe,
    rust_native_extension_path,
    rust_unsupported_invariant_result_handle_report,
    segment_bbox_candidate_pairs_2d,
    segment_bbox_candidate_pairs_3d,
    segment_intersections_2d,
    segment_segment_distance,
    segment_segment_distances,
)
from tests.fixtures import circle_points, hopf_link_points

EXPECTED_NATIVE_INVARIANT_RESULT_HANDLE_BLOCKERS = [
    "homfly_native_compute_handle_missing",
    "alexander_native_compute_handle_missing",
    "native_result_compute_payload_lifecycle_incomplete",
    "long_invariant_progress_cancel_missing",
    "python_fixture_report_parity_missing",
    "dear_imgui_native_invariant_status_reload_missing",
]
EXPECTED_NATIVE_INVARIANTS = ["homfly", "alexander"]
EXPECTED_NATIVE_INVARIANT_UNAVAILABLE_STATUS_CODES = [
    "homfly_native_compute_handle_missing",
    "alexander_native_compute_handle_missing",
]
EXPECTED_NATIVE_INVARIANT_COMPUTE_GATES_BY_INVARIANT = {
    "homfly": "homfly_native_compute_handle",
    "alexander": "alexander_native_compute_handle",
}
EXPECTED_NATIVE_INVARIANT_COUNT_CONSISTENCY = {
    "schema_version": 1,
    "tracked_invariant_count": len(EXPECTED_NATIVE_INVARIANTS),
    "per_invariant_count": len(EXPECTED_NATIVE_INVARIANTS),
    "per_invariant_unavailable_count": len(EXPECTED_NATIVE_INVARIANTS),
    "per_invariant_blocker_count": len(EXPECTED_NATIVE_INVARIANTS),
    "per_invariant_blocking_gate_count": len(EXPECTED_NATIVE_INVARIANTS),
    "total_blocker_count": len(EXPECTED_NATIVE_INVARIANT_RESULT_HANDLE_BLOCKERS),
    "total_required_gate_count": 6,
    "tracked_invariant_count_matches_per_invariant": True,
    "per_invariant_unavailable_count_matches_tracked_invariants": True,
    "per_invariant_status_code_count_matches_unavailable": True,
    "per_invariant_blocker_count_matches_unavailable": True,
    "per_invariant_blocking_gate_count_matches_tracked_invariants": True,
    "total_blocker_count_matches_metadata_list": True,
    "total_gate_count_matches_metadata_list": True,
    "homfly_alexander_gate_count_matches_tracked_invariants": True,
}
EXPECTED_INVARIANT_RESULT_HANDLE_METADATA_SCHEMA_VERSION = 1
EXPECTED_INVARIANT_RESULT_HANDLE_METADATA_CONTRACT_VERSION = (
    "rust_c_abi_19_invariant_result_handles_lifecycle_metadata_v1"
)
EXPECTED_INVARIANT_RESULT_HANDLE_READINESS_PROVENANCE_NOTE = (
    "readiness_provenance_self_consistency=present; readiness=blocked; "
    "ready_for_native_result_handles=false; current_boundary=python_file_recompute; "
    "required_native_handle_gates_block_native_result_handle_boundary=true"
)
EXPECTED_OWNED_STRING_CONTRACT = {
    "schema_version": 1,
    "contract_version": "rust_owned_string_v1",
    "abi_version": 19,
    "owner": "rust_library",
    "data": "utf8_json_nul_terminated",
    "length": "utf8_byte_length_excluding_trailing_nul",
    "handle": "opaque_free_handle",
    "free_symbol": "iroll_kernel_owned_string_free",
    "free_required": True,
    "free_accepts_zero_initialized": True,
    "borrowed_across_calls": False,
}
EXPECTED_INVARIANT_RESULT_HANDLE_REQUIRED_METADATA_FIELDS = [
    "capability",
    "result_handle_abi",
    "metadata_schema_version",
    "metadata_contract_version",
    "required_metadata_fields",
    "required_metadata_field_count",
    "metadata_report_available",
    "metadata_report_symbol",
    "available_exported_symbols",
    "owned_string_free_symbol",
    "returned_string_ownership",
    "returned_string_free_required",
    "homfly_report_json",
    "alexander_report_json",
    "native_computation_claimed",
    "native_invariant_result_handles_complete",
    "native_invariant_compute_handles_status",
    "metadata_consistency",
    "native_invariant_result_handle_blockers",
    "native_invariant_result_handle_blocker_count",
    "required_native_invariant_handle_gates",
    "required_native_invariant_handle_gate_count",
    "python_file_recompute_boundary",
    "file_recompute_boundary",
    "current_file_recompute_boundary",
    "complete_result_handle_abi",
    "release_grade_result_handles",
    "future_handle_ownership",
    "claim_scope",
    "status",
]

EXPECTED_REQUIRED_NATIVE_INVARIANT_HANDLE_GATES = [
    {
        "gate": "homfly_native_compute_handle",
        "status": "missing",
        "evidence_required": (
            "Rust C ABI result handle that computes HOMFLY from signed-PD input "
            "without CLI file recompute"
        ),
    },
    {
        "gate": "alexander_native_compute_handle",
        "status": "missing",
        "evidence_required": (
            "Rust C ABI result handle that computes multi-variable Alexander from "
            "signed-PD input without CLI file recompute"
        ),
    },
    {
        "gate": "result_ownership_freeing_lifecycle",
        "status": "unsupported_handle_lifecycle_only",
        "evidence_required": (
            "Opaque unsupported invariant result handle ownership/free lifecycle "
            "is available; complete native compute payload ownership remains pending"
        ),
    },
    {
        "gate": "progress_cancel_for_long_invariant_computations",
        "status": "missing",
        "evidence_required": (
            "Progress and cancel callbacks wired through long-running "
            "HOMFLY/Alexander native computations"
        ),
    },
    {
        "gate": "parity_against_python_fixture_reports",
        "status": "missing",
        "evidence_required": (
            "Fixture parity reports showing native HOMFLY/Alexander payloads "
            "match Python signed-PD reports"
        ),
    },
    {
        "gate": "host_reload_into_dear_imgui_invariant_status_rows",
        "status": "file_recompute_boundary_only",
        "evidence_required": (
            "Dear ImGui invariant-status reload consumes native invariant result "
            "payloads without the CLI handoff"
        ),
    },
]

EXPECTED_CURRENT_FILE_RECOMPUTE_BOUNDARY = {
    "boundary": "python_file_recompute",
    "input_formats": ["signed_pd_json", "imgui_signed_pd_json"],
    "pipeline": [
        "signed_pd_json/imgui_signed_pd_json",
        "iroll homfly-pd or iroll multivariable-alexander-pd",
        "iroll imgui-signed-pd-invariant-status-payload",
        "Dear ImGui invariant-status rows",
    ],
    "native_result_handle_boundary": False,
    "host_reload_payload": "imgui-signed-pd-invariant-status-payload",
}

EXPECTED_INVARIANT_RESULT_HANDLE_REQUIRED_GATE_BLOCKER_LINKS = [
    {
        "gate": "homfly_native_compute_handle",
        "gate_status": "missing",
        "blocker": "homfly_native_compute_handle_missing",
        "blocks_tracked_invariants": ["homfly"],
        "required_before_native_result_handle_boundary": True,
    },
    {
        "gate": "alexander_native_compute_handle",
        "gate_status": "missing",
        "blocker": "alexander_native_compute_handle_missing",
        "blocks_tracked_invariants": ["alexander"],
        "required_before_native_result_handle_boundary": True,
    },
    {
        "gate": "result_ownership_freeing_lifecycle",
        "gate_status": "unsupported_handle_lifecycle_only",
        "blocker": "native_result_compute_payload_lifecycle_incomplete",
        "blocks_tracked_invariants": [],
        "required_before_native_result_handle_boundary": True,
    },
    {
        "gate": "progress_cancel_for_long_invariant_computations",
        "gate_status": "missing",
        "blocker": "long_invariant_progress_cancel_missing",
        "blocks_tracked_invariants": [],
        "required_before_native_result_handle_boundary": True,
    },
    {
        "gate": "parity_against_python_fixture_reports",
        "gate_status": "missing",
        "blocker": "python_fixture_report_parity_missing",
        "blocks_tracked_invariants": [],
        "required_before_native_result_handle_boundary": True,
    },
    {
        "gate": "host_reload_into_dear_imgui_invariant_status_rows",
        "gate_status": "file_recompute_boundary_only",
        "blocker": "dear_imgui_native_invariant_status_reload_missing",
        "blocks_tracked_invariants": [],
        "required_before_native_result_handle_boundary": True,
    },
]

EXPECTED_INVARIANT_RESULT_HANDLE_READINESS_PROVENANCE_SELF_CONSISTENCY = {
    "schema_version": 1,
    "readiness": "blocked",
    "ready_for_native_result_handles": False,
    "native_computation_claimed": False,
    "python_file_recompute_boundary": True,
    "native_result_handle_boundary": False,
    "current_boundary": "python_file_recompute",
    "host_action": "use_python_file_recompute_boundary",
    "provenance": {
        "metadata_report_symbol": "iroll_invariant_result_handles_report_json",
        "compute_status_field": "native_invariant_compute_handles_status",
        "per_invariant_rows_field": (
            "native_invariant_compute_handles_status.per_invariant"
        ),
        "required_gates_field": "required_native_invariant_handle_gates",
        "blockers_field": "native_invariant_result_handle_blockers",
        "current_boundary_field": "current_file_recompute_boundary",
    },
    "per_invariant_links": [
        {
            "invariant": "homfly",
            "unsupported": True,
            "status": "unsupported",
            "status_code": "homfly_native_compute_handle_missing",
            "blocking_status_code": "homfly_native_compute_handle_missing",
            "blocking_gate": "homfly_native_compute_handle",
            "gate_status": "missing",
            "metadata_blocker": "homfly_native_compute_handle_missing",
            "required_boundary": "python_file_recompute",
            "host_action": "use_python_file_recompute_boundary",
            "native_computation_claimed": False,
            "python_file_recompute_boundary": True,
            "native_result_handle_boundary": False,
        },
        {
            "invariant": "alexander",
            "unsupported": True,
            "status": "unsupported",
            "status_code": "alexander_native_compute_handle_missing",
            "blocking_status_code": "alexander_native_compute_handle_missing",
            "blocking_gate": "alexander_native_compute_handle",
            "gate_status": "missing",
            "metadata_blocker": "alexander_native_compute_handle_missing",
            "required_boundary": "python_file_recompute",
            "host_action": "use_python_file_recompute_boundary",
            "native_computation_claimed": False,
            "python_file_recompute_boundary": True,
            "native_result_handle_boundary": False,
        },
    ],
    "required_gate_blocker_links": (
        EXPECTED_INVARIANT_RESULT_HANDLE_REQUIRED_GATE_BLOCKER_LINKS
    ),
    "self_consistency": {
        "unsupported_row_count": len(EXPECTED_NATIVE_INVARIANTS),
        "per_invariant_link_count": len(EXPECTED_NATIVE_INVARIANTS),
        "required_gate_blocker_link_count": len(
            EXPECTED_REQUIRED_NATIVE_INVARIANT_HANDLE_GATES
        ),
        "per_invariant_links_match_unsupported_rows": True,
        "per_invariant_blockers_match_metadata_blockers": True,
        "per_invariant_gates_match_required_gates": True,
        "per_invariant_boundaries_match_current_boundary": True,
        "per_invariant_host_actions_match_compute_status": True,
        "required_gate_blocker_links_cover_required_gates": True,
        "required_gate_blocker_links_cover_metadata_blockers": True,
        "file_recompute_boundary_matches_current": True,
        "native_result_handle_boundary_matches_current": True,
        "native_computation_non_claim_consistent": True,
        "readiness_blocked_by_required_gates": True,
    },
}

EXPECTED_NATIVE_INVARIANT_COMPUTE_HANDLES_STATUS = {
    "schema_version": 1,
    "boundary": "rust_c_abi_invariant_compute_handles_status",
    "status": "unsupported",
    "status_code": "native_invariant_compute_handles_unavailable",
    "status_reason": "homfly_alexander_native_compute_handles_not_implemented",
    "compute_handle_abi": "not_available",
    "result_handle_abi": "owned_string_v1_probe_only",
    "native_computation_claimed": False,
    "native_invariant_result_handles_complete": False,
    "homfly_report_json": False,
    "alexander_report_json": False,
    "python_file_recompute_boundary": True,
    "current_boundary": "python_file_recompute",
    "host_action": "use_python_file_recompute_boundary",
    "c_abi_probe_symbol": "iroll_invariant_result_handles_report_json",
    "owned_string_free_symbol": "iroll_kernel_owned_string_free",
    "tracked_invariants": EXPECTED_NATIVE_INVARIANTS,
    "tracked_invariant_count": len(EXPECTED_NATIVE_INVARIANTS),
    "per_invariant_count": len(EXPECTED_NATIVE_INVARIANTS),
    "per_invariant_unavailable_count": len(EXPECTED_NATIVE_INVARIANTS),
    "per_invariant_unavailable_status_codes": (
        EXPECTED_NATIVE_INVARIANT_UNAVAILABLE_STATUS_CODES
    ),
    "per_invariant_blocker_count": len(EXPECTED_NATIVE_INVARIANTS),
    "per_invariant_blocking_gates": [
        "homfly_native_compute_handle",
        "alexander_native_compute_handle",
    ],
    "per_invariant_blocking_gate_count": len(EXPECTED_NATIVE_INVARIANTS),
    "count_consistency": EXPECTED_NATIVE_INVARIANT_COUNT_CONSISTENCY,
    "per_invariant": [
        {
            "invariant": "homfly",
            "native_compute_handle_available": False,
            "report_json_available": False,
            "report_json_symbol_available": False,
            "native_computation_claimed": False,
            "blocking_gate": "homfly_native_compute_handle",
            "gate_status": "missing",
            "status": "unsupported",
            "status_code": "homfly_native_compute_handle_missing",
            "blocking_status_code": "homfly_native_compute_handle_missing",
            "required_boundary": "python_file_recompute",
            "host_action": "use_python_file_recompute_boundary",
        },
        {
            "invariant": "alexander",
            "native_compute_handle_available": False,
            "report_json_available": False,
            "report_json_symbol_available": False,
            "native_computation_claimed": False,
            "blocking_gate": "alexander_native_compute_handle",
            "gate_status": "missing",
            "status": "unsupported",
            "status_code": "alexander_native_compute_handle_missing",
            "blocking_status_code": "alexander_native_compute_handle_missing",
            "required_boundary": "python_file_recompute",
            "host_action": "use_python_file_recompute_boundary",
        },
    ],
}

EXPECTED_INVARIANT_RESULT_HANDLE_METADATA_CONSISTENCY = {
    "schema_version": 1,
    "file_recompute_boundary_matches_current": True,
    "current_boundary_matches_compute_status": True,
    "blocker_count_matches_list": True,
    "required_gate_count_matches_list": True,
    "required_metadata_field_count": len(
        EXPECTED_INVARIANT_RESULT_HANDLE_REQUIRED_METADATA_FIELDS
    ),
    "required_metadata_field_count_matches_list": True,
    "required_metadata_fields_present": True,
    "tracked_invariant_count": len(EXPECTED_NATIVE_INVARIANTS),
    "per_invariant_count": len(EXPECTED_NATIVE_INVARIANTS),
    "per_invariant_unavailable_count": len(EXPECTED_NATIVE_INVARIANTS),
    "tracked_invariant_count_matches_per_invariant": True,
    "per_invariant_unavailable_count_matches_tracked_invariants": True,
    "per_invariant_blocker_count": len(EXPECTED_NATIVE_INVARIANTS),
    "per_invariant_blocker_count_matches_unavailable": True,
    "per_invariant_blocking_gate_count": len(EXPECTED_NATIVE_INVARIANTS),
    "per_invariant_blocking_gate_count_matches_tracked_invariants": True,
    "per_invariant_status_codes_match_blockers": True,
    "required_native_compute_gate_statuses_match_per_invariant": True,
    "native_computation_non_claim_consistent": True,
    "native_invariant_result_handle_blocker_count": len(
        EXPECTED_NATIVE_INVARIANT_RESULT_HANDLE_BLOCKERS
    ),
    "required_native_invariant_handle_gate_count": len(
        EXPECTED_REQUIRED_NATIVE_INVARIANT_HANDLE_GATES
    ),
}

EXPECTED_INVARIANT_RESULT_HANDLE_METADATA = {
    "capability": "invariant_result_handles_metadata_report",
    "result_handle_abi": "opaque_invariant_result_handle_v1",
    "report_transport_abi": "owned_string_v1",
    "metadata_schema_version": EXPECTED_INVARIANT_RESULT_HANDLE_METADATA_SCHEMA_VERSION,
    "metadata_contract_version": (
        EXPECTED_INVARIANT_RESULT_HANDLE_METADATA_CONTRACT_VERSION
    ),
    "required_metadata_fields": (
        EXPECTED_INVARIANT_RESULT_HANDLE_REQUIRED_METADATA_FIELDS
    ),
    "required_metadata_field_count": len(
        EXPECTED_INVARIANT_RESULT_HANDLE_REQUIRED_METADATA_FIELDS
    ),
    "metadata_report_available": True,
    "metadata_report_symbol": "iroll_invariant_result_handles_report_json",
    "available_exported_symbols": [
        "iroll_invariant_result_handles_report_json",
        "iroll_invariant_result_handle_create_unsupported",
        "iroll_invariant_result_handle_report_json",
        "iroll_invariant_result_handle_free",
        "iroll_kernel_owned_string_free",
    ],
    "owned_string_free_symbol": "iroll_kernel_owned_string_free",
    "returned_string_ownership": "rust_owned",
    "returned_string_free_required": True,
    "unsupported_result_handle_lifecycle_available": True,
    "unsupported_result_handle_create_symbol": (
        "iroll_invariant_result_handle_create_unsupported"
    ),
    "result_handle_report_symbol": "iroll_invariant_result_handle_report_json",
    "result_handle_free_symbol": "iroll_invariant_result_handle_free",
    "homfly_report_json": False,
    "alexander_report_json": False,
    "native_computation_claimed": False,
    "native_invariant_result_handles_complete": False,
    "native_invariant_compute_handles_status": (
        EXPECTED_NATIVE_INVARIANT_COMPUTE_HANDLES_STATUS
    ),
    "metadata_consistency": EXPECTED_INVARIANT_RESULT_HANDLE_METADATA_CONSISTENCY,
    "readiness_provenance_self_consistency": (
        EXPECTED_INVARIANT_RESULT_HANDLE_READINESS_PROVENANCE_SELF_CONSISTENCY
    ),
    "readiness_provenance_note": (
        EXPECTED_INVARIANT_RESULT_HANDLE_READINESS_PROVENANCE_NOTE
    ),
    "native_invariant_result_handle_blockers": (
        EXPECTED_NATIVE_INVARIANT_RESULT_HANDLE_BLOCKERS
    ),
    "native_invariant_result_handle_blocker_count": len(
        EXPECTED_NATIVE_INVARIANT_RESULT_HANDLE_BLOCKERS
    ),
    "required_native_invariant_handle_gates": (
        EXPECTED_REQUIRED_NATIVE_INVARIANT_HANDLE_GATES
    ),
    "required_native_invariant_handle_gate_count": len(
        EXPECTED_REQUIRED_NATIVE_INVARIANT_HANDLE_GATES
    ),
    "python_file_recompute_boundary": True,
    "file_recompute_boundary": {
        "boundary": "python_file_recompute",
        "input_formats": ["signed_pd_json", "imgui_signed_pd_json"],
        "homfly_cli_command": "iroll homfly-pd",
        "alexander_cli_command": "iroll multivariable-alexander-pd",
        "result_transport": ["json_file", "stdout_json"],
        "host_reload_payload": "imgui-signed-pd-invariant-status-payload",
    },
    "current_file_recompute_boundary": EXPECTED_CURRENT_FILE_RECOMPUTE_BOUNDARY,
    "complete_result_handle_abi": False,
    "release_grade_result_handles": False,
    "future_handle_ownership": {
        "owner": "rust_library",
        "requires_explicit_free_symbol": True,
        "free_symbol_claimed": True,
        "free_symbol": "iroll_invariant_result_handle_free",
        "create_unsupported_symbol": (
            "iroll_invariant_result_handle_create_unsupported"
        ),
        "report_symbol": "iroll_invariant_result_handle_report_json",
        "lifecycle_scope": "unsupported_handle_only",
        "complete_compute_payload_lifecycle": False,
        "borrowed_across_calls": False,
    },
    "claim_scope": "capability_probe_only",
    "status": "metadata_only",
}


def assert_invariant_result_handle_metadata_consistency(
    invariant_handles: dict[str, object],
) -> None:
    assert invariant_handles["status"] == "metadata_only"
    assert invariant_handles["claim_scope"] == "capability_probe_only"
    assert invariant_handles["homfly_report_json"] is False
    assert invariant_handles["alexander_report_json"] is False
    assert invariant_handles["native_computation_claimed"] is False
    assert invariant_handles["native_invariant_result_handles_complete"] is False
    assert invariant_handles["complete_result_handle_abi"] is False
    assert invariant_handles["release_grade_result_handles"] is False
    assert (
        invariant_handles["metadata_schema_version"]
        == EXPECTED_INVARIANT_RESULT_HANDLE_METADATA_SCHEMA_VERSION
    )
    assert (
        invariant_handles["metadata_contract_version"]
        == EXPECTED_INVARIANT_RESULT_HANDLE_METADATA_CONTRACT_VERSION
    )
    required_metadata_fields = invariant_handles["required_metadata_fields"]
    assert (
        required_metadata_fields
        == EXPECTED_INVARIANT_RESULT_HANDLE_REQUIRED_METADATA_FIELDS
    )
    assert invariant_handles["required_metadata_field_count"] == len(
        required_metadata_fields
    )
    assert all(field in invariant_handles for field in required_metadata_fields)
    assert invariant_handles["required_metadata_field_count"] == 30
    assert "readiness_provenance_self_consistency" not in required_metadata_fields
    assert "readiness_provenance_note" not in required_metadata_fields

    file_boundary = invariant_handles["file_recompute_boundary"]
    current_boundary = invariant_handles["current_file_recompute_boundary"]
    compute_handle_status = invariant_handles["native_invariant_compute_handles_status"]
    consistency = invariant_handles["metadata_consistency"]
    readiness = invariant_handles["readiness_provenance_self_consistency"]
    assert consistency == EXPECTED_INVARIANT_RESULT_HANDLE_METADATA_CONSISTENCY
    assert (
        readiness
        == EXPECTED_INVARIANT_RESULT_HANDLE_READINESS_PROVENANCE_SELF_CONSISTENCY
    )
    assert (
        invariant_handles["readiness_provenance_note"]
        == EXPECTED_INVARIANT_RESULT_HANDLE_READINESS_PROVENANCE_NOTE
    )
    assert "readiness_provenance_self_consistency=present" in invariant_handles[
        "readiness_provenance_note"
    ]

    assert invariant_handles["python_file_recompute_boundary"] is True
    assert compute_handle_status["python_file_recompute_boundary"] is True
    assert readiness["python_file_recompute_boundary"] is True
    assert readiness["native_result_handle_boundary"] is False
    assert readiness["native_computation_claimed"] is False
    assert readiness["ready_for_native_result_handles"] is False
    assert file_boundary["boundary"] == current_boundary["boundary"]
    assert current_boundary["boundary"] == compute_handle_status["current_boundary"]
    assert readiness["current_boundary"] == current_boundary["boundary"]
    assert file_boundary["input_formats"] == current_boundary["input_formats"]
    assert file_boundary["host_reload_payload"] == current_boundary["host_reload_payload"]
    assert current_boundary["native_result_handle_boundary"] is False
    assert consistency["file_recompute_boundary_matches_current"] is True
    assert consistency["current_boundary_matches_compute_status"] is True

    blockers = invariant_handles["native_invariant_result_handle_blockers"]
    gates = invariant_handles["required_native_invariant_handle_gates"]
    readiness_consistency = readiness["self_consistency"]
    assert invariant_handles["native_invariant_result_handle_blocker_count"] == len(
        blockers
    )
    assert invariant_handles["required_native_invariant_handle_gate_count"] == len(
        gates
    )
    assert consistency["blocker_count_matches_list"] is True
    assert consistency["required_gate_count_matches_list"] is True
    assert consistency["required_metadata_field_count"] == len(
        required_metadata_fields
    )
    assert consistency["required_metadata_field_count_matches_list"] is True
    assert consistency["required_metadata_fields_present"] is True
    assert consistency["native_invariant_result_handle_blocker_count"] == len(blockers)
    assert consistency["required_native_invariant_handle_gate_count"] == len(gates)
    assert readiness_consistency["required_gate_blocker_link_count"] == len(gates)
    assert set(
        link["blocker"] for link in readiness["required_gate_blocker_links"]
    ) == set(blockers)
    assert set(link["gate"] for link in readiness["required_gate_blocker_links"]) == {
        gate["gate"] for gate in gates
    }

    per_invariant = compute_handle_status["per_invariant"]
    count_consistency = compute_handle_status["count_consistency"]
    assert count_consistency == EXPECTED_NATIVE_INVARIANT_COUNT_CONSISTENCY
    unavailable = [
        item
        for item in per_invariant
        if item["status"] == "unsupported"
        and item["native_compute_handle_available"] is False
        and item["report_json_available"] is False
        and item["report_json_symbol_available"] is False
        and item["native_computation_claimed"] is False
    ]
    assert compute_handle_status["tracked_invariants"] == [
        item["invariant"] for item in per_invariant
    ]
    assert compute_handle_status["tracked_invariants"] == EXPECTED_NATIVE_INVARIANTS
    assert compute_handle_status["tracked_invariant_count"] == len(per_invariant)
    assert compute_handle_status["per_invariant_count"] == len(per_invariant)
    assert compute_handle_status["per_invariant_unavailable_count"] == len(unavailable)
    assert compute_handle_status["per_invariant_blocker_count"] == len(unavailable)
    assert compute_handle_status["per_invariant_blocking_gate_count"] == len(
        per_invariant
    )
    assert compute_handle_status["per_invariant_blocking_gates"] == [
        item["blocking_gate"] for item in per_invariant
    ]
    assert readiness["per_invariant_links"] == [
        {
            "invariant": item["invariant"],
            "unsupported": True,
            "status": item["status"],
            "status_code": item["status_code"],
            "blocking_status_code": item["blocking_status_code"],
            "blocking_gate": item["blocking_gate"],
            "gate_status": item["gate_status"],
            "metadata_blocker": item["status_code"],
            "required_boundary": item["required_boundary"],
            "host_action": item["host_action"],
            "native_computation_claimed": item["native_computation_claimed"],
            "python_file_recompute_boundary": True,
            "native_result_handle_boundary": current_boundary[
                "native_result_handle_boundary"
            ],
        }
        for item in per_invariant
    ]
    assert readiness_consistency["unsupported_row_count"] == len(unavailable)
    assert readiness_consistency["per_invariant_link_count"] == len(per_invariant)
    assert count_consistency["tracked_invariant_count"] == len(per_invariant)
    assert count_consistency["per_invariant_count"] == len(per_invariant)
    assert count_consistency["per_invariant_unavailable_count"] == len(unavailable)
    assert count_consistency["per_invariant_blocker_count"] == len(unavailable)
    assert count_consistency["per_invariant_blocking_gate_count"] == len(
        per_invariant
    )
    assert count_consistency["total_blocker_count"] == len(blockers)
    assert count_consistency["total_required_gate_count"] == len(gates)
    assert consistency["per_invariant_count"] == len(per_invariant)
    assert consistency["per_invariant_unavailable_count"] == len(unavailable)
    assert consistency["tracked_invariant_count"] == len(per_invariant)
    assert consistency["per_invariant_blocker_count"] == len(unavailable)
    assert consistency["per_invariant_blocking_gate_count"] == len(per_invariant)
    assert compute_handle_status["per_invariant_unavailable_status_codes"] == [
        item["status_code"] for item in unavailable
    ]
    assert (
        compute_handle_status["per_invariant_unavailable_status_codes"]
        == EXPECTED_NATIVE_INVARIANT_UNAVAILABLE_STATUS_CODES
    )
    assert consistency["tracked_invariant_count_matches_per_invariant"] is True
    assert (
        consistency["per_invariant_unavailable_count_matches_tracked_invariants"]
        is True
    )
    assert count_consistency["tracked_invariant_count_matches_per_invariant"] is True
    assert (
        count_consistency["per_invariant_unavailable_count_matches_tracked_invariants"]
        is True
    )
    assert (
        count_consistency["per_invariant_status_code_count_matches_unavailable"]
        is True
    )
    assert count_consistency["per_invariant_blocker_count_matches_unavailable"] is True
    assert (
        count_consistency[
            "per_invariant_blocking_gate_count_matches_tracked_invariants"
        ]
        is True
    )
    assert count_consistency["total_blocker_count_matches_metadata_list"] is True
    assert count_consistency["total_gate_count_matches_metadata_list"] is True
    assert (
        count_consistency["homfly_alexander_gate_count_matches_tracked_invariants"]
        is True
    )
    assert consistency["per_invariant_blocker_count_matches_unavailable"] is True
    assert (
        consistency["per_invariant_blocking_gate_count_matches_tracked_invariants"]
        is True
    )
    assert consistency["per_invariant_status_codes_match_blockers"] is True
    assert all(item["status_code"] in blockers for item in per_invariant)
    assert all(
        item["blocking_status_code"] == item["status_code"]
        for item in per_invariant
    )
    assert all(
        item["required_boundary"] == current_boundary["boundary"]
        for item in per_invariant
    )
    assert all(
        item["host_action"] == compute_handle_status["host_action"]
        for item in per_invariant
    )

    gate_by_name = {gate["gate"]: gate for gate in gates}
    per_invariant_by_name = {item["invariant"]: item for item in per_invariant}
    assert set(per_invariant_by_name) == set(
        EXPECTED_NATIVE_INVARIANT_COMPUTE_GATES_BY_INVARIANT
    )
    for invariant, gate_name in (
        EXPECTED_NATIVE_INVARIANT_COMPUTE_GATES_BY_INVARIANT.items()
    ):
        assert per_invariant_by_name[invariant]["status_code"] in blockers
        assert per_invariant_by_name[invariant]["blocking_gate"] == gate_name
        assert per_invariant_by_name[invariant]["gate_status"] == "missing"
        assert gate_by_name[gate_name]["status"] == "missing"
    assert (
        consistency["required_native_compute_gate_statuses_match_per_invariant"]
        is True
    )
    assert consistency["native_computation_non_claim_consistent"] is True
    assert readiness_consistency["per_invariant_links_match_unsupported_rows"] is True
    assert readiness_consistency["per_invariant_blockers_match_metadata_blockers"] is True
    assert readiness_consistency["per_invariant_gates_match_required_gates"] is True
    assert (
        readiness_consistency["per_invariant_boundaries_match_current_boundary"]
        is True
    )
    assert readiness_consistency["per_invariant_host_actions_match_compute_status"] is True
    assert readiness_consistency["required_gate_blocker_links_cover_required_gates"] is True
    assert (
        readiness_consistency["required_gate_blocker_links_cover_metadata_blockers"]
        is True
    )
    assert readiness_consistency["file_recompute_boundary_matches_current"] is True
    assert readiness_consistency["native_result_handle_boundary_matches_current"] is True
    assert readiness_consistency["native_computation_non_claim_consistent"] is True
    assert readiness_consistency["readiness_blocked_by_required_gates"] is True


def backend_available(name: str) -> bool:
    return bool(backend_report()["backends"][name]["available"])


def test_rust_native_extension_path_resolves_package_and_extension_origins(
    tmp_path: Path,
) -> None:
    suffix = importlib.machinery.EXTENSION_SUFFIXES[0]
    package_dir = tmp_path / "iroll_kernels_rust"
    package_dir.mkdir()
    package_origin = package_dir / "__init__.py"
    package_origin.write_text("", encoding="utf-8")
    extension = package_dir / f"iroll_kernels_rust{suffix}"
    extension.write_bytes(b"")

    assert rust_native_extension_path(str(package_origin)) == extension
    assert rust_native_extension_path(str(extension)) == extension
    assert rust_native_extension_path(None) is None


def test_rust_unsupported_invariant_result_handle_report_rejects_unknown_invariant() -> None:
    with pytest.raises(ValueError, match="invariant must be"):
        rust_unsupported_invariant_result_handle_report("jones")


def load_gpu_smoke_module():
    script = (
        Path(__file__).resolve().parents[1]
        / "native"
        / "iroll-kernels-gpu"
        / "examples"
        / "gpu_smoke.py"
    )
    spec = importlib.util.spec_from_file_location("iroll_gpu_smoke_contract", script)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


EXPECTED_GPU_SMOKE_REQUIRED_CAPABILITIES = [
    "segment_segment_distance",
    "segment_segment_distances",
    "segment_intersections_2d",
    "segment_bbox_candidate_pairs_2d",
    "segment_bbox_candidate_pairs_3d",
    "compute_writhe",
    "compute_gaussian_linking_number",
]

GPU_SMOKE_EVIDENCE_KEYS = {
    "gpu_dispatch_parity",
    "no_cuda_boundary",
    "cuda_parity",
    "release_grade_speedup",
}

GPU_SMOKE_CLAIM_BOOLEAN_KEYS = (
    "gpu_dispatch_parity_smoke_claimed",
    "cuda_parity_claimed",
    "release_grade_speedup_claimed",
)

GPU_SMOKE_RELEASE_GATE_KEYS = {
    "schema_version",
    "gate_scope",
    "gpu_backend_available",
    "cuda_runtime_observed",
    "required_check_count",
    "parity_check_count",
    "passed_check_count",
    "failed_check_count",
    "required_capability_count",
    "blocking_reasons",
    "blocking_reason_count",
    "gpu_dispatch_parity_smoke_claimed",
    "cuda_parity_claimed",
    "release_grade_speedup_claimed",
    "gate_passed",
}


def assert_gpu_smoke_common_artifact_fields(
    payload: dict[str, object],
    *,
    artifact_kind: str,
    execution_path: str,
    claim_scope: str,
) -> None:
    assert payload["artifact_schema_version"] == 1
    assert payload["artifact_kind"] == artifact_kind
    assert payload["execution_path"] == execution_path
    assert payload["claim_scope"] == claim_scope
    assert payload["required_capabilities"] == EXPECTED_GPU_SMOKE_REQUIRED_CAPABILITIES
    assert payload["required_capability_count"] == len(
        EXPECTED_GPU_SMOKE_REQUIRED_CAPABILITIES
    )
    assert payload["required_capability_count"] == len(
        payload["required_capabilities"]
    )
    assert isinstance(payload["environment_metadata"], dict)
    assert isinstance(payload["environment_witness"], dict)
    assert payload["environment_witness"]["schema_version"] == 1
    assert set(payload["evidence"]) == GPU_SMOKE_EVIDENCE_KEYS
    for claim_key in GPU_SMOKE_CLAIM_BOOLEAN_KEYS:
        assert isinstance(payload[claim_key], bool)
    assert payload["gpu_dispatch_parity_smoke_claimed"] == payload["evidence"][
        "gpu_dispatch_parity"
    ]
    assert payload["cuda_parity_claimed"] == payload["evidence"]["cuda_parity"]
    assert (
        payload["release_grade_speedup_claimed"]
        == payload["evidence"]["release_grade_speedup"]
    )
    assert payload["parity_check_count"] == len(payload["check_results"])
    assert payload["passed_check_count"] == sum(
        1 for check in payload["check_results"] if check["matched"] is True
    )
    assert payload["failed_check_count"] == sum(
        1 for check in payload["check_results"] if check["matched"] is False
    )
    assert (
        payload["parity_check_count"]
        == payload["passed_check_count"] + payload["failed_check_count"]
    )
    gate = payload["gpu_release_gate"]
    assert isinstance(gate, dict)
    assert set(gate) == GPU_SMOKE_RELEASE_GATE_KEYS
    assert gate["schema_version"] == 1
    assert gate["gate_scope"] == "gpu_dispatch_parity_smoke"
    assert gate["gpu_backend_available"] == payload["environment_metadata"][
        "gpu_backend_available"
    ]
    assert gate["cuda_runtime_observed"] == payload["environment_witness"]["runtime"][
        "cuda_runtime_observed"
    ]
    assert gate["required_check_count"] == len(
        EXPECTED_GPU_SMOKE_REQUIRED_CAPABILITIES
    )
    assert gate["parity_check_count"] == payload["parity_check_count"]
    assert gate["passed_check_count"] == payload["passed_check_count"]
    assert gate["failed_check_count"] == payload["failed_check_count"]
    assert gate["required_capability_count"] == payload["required_capability_count"]
    assert gate["blocking_reason_count"] == len(gate["blocking_reasons"])
    assert (
        gate["gpu_dispatch_parity_smoke_claimed"]
        == payload["gpu_dispatch_parity_smoke_claimed"]
    )
    assert gate["cuda_parity_claimed"] == payload["cuda_parity_claimed"]
    assert (
        gate["release_grade_speedup_claimed"]
        == payload["release_grade_speedup_claimed"]
    )
    assert gate["release_grade_speedup_claimed"] is False
    assert gate["cuda_parity_claimed"] is False
    assert gate["gate_passed"] == (gate["blocking_reason_count"] == 0)


def test_numpy_backend_writhe_matches_auto_backend() -> None:
    points = circle_points(count=128)

    auto = compute_writhe(points, closed=True, backend="auto")
    numpy_value = compute_writhe(points, closed=True, backend="numpy")

    assert np.isclose(auto, numpy_value)


def test_numpy_backend_linking_matches_auto_backend() -> None:
    first, second = hopf_link_points(count=256)

    auto = compute_gaussian_linking_number(first, second, backend="auto")
    numpy_value = compute_gaussian_linking_number(first, second, backend="numpy")

    assert np.isclose(auto, numpy_value)


def test_explicit_rust_backend_errors_when_uninstalled() -> None:
    if backend_available("rust"):
        pytest.skip("Rust kernels are installed in this environment")

    with pytest.raises(KernelBackendError, match="Rust kernels"):
        compute_writhe(circle_points(count=32), closed=True, backend="rust")


def test_explicit_gpu_backend_errors_when_uninstalled() -> None:
    if backend_available("gpu"):
        pytest.skip("GPU kernels are installed in this environment")

    with pytest.raises(KernelBackendError, match="GPU kernels"):
        compute_writhe(circle_points(count=32), closed=True, backend="gpu")


def test_distance_kernel_accepts_auto_backend() -> None:
    distance, *_ = segment_segment_distance(
        [0.0, 0.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        [1.0, 1.0, 0.0],
    )

    assert np.isclose(distance, 1.0)


def test_explicit_rust_backend_matches_numpy_when_installed() -> None:
    if not backend_available("rust"):
        pytest.skip("Rust kernels are not installed in this environment")

    points = circle_points(count=128)
    first, second = hopf_link_points(count=256)

    rust_distance, *_ = segment_segment_distance(
        [0.0, 0.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        [1.0, 1.0, 0.0],
        backend="rust",
    )
    numpy_distance, *_ = segment_segment_distance(
        [0.0, 0.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        [1.0, 1.0, 0.0],
        backend="numpy",
    )
    rust_writhe = compute_writhe(points, closed=True, backend="rust")
    numpy_writhe = compute_writhe(points, closed=True, backend="numpy")
    rust_linking = compute_gaussian_linking_number(first, second, backend="rust")
    numpy_linking = compute_gaussian_linking_number(first, second, backend="numpy")
    a0 = np.array([[0.0, 0.0, 0.0], [-1.0, 0.0, 0.0]])
    a1 = np.array([[1.0, 0.0, 0.0], [1.0, 0.0, 0.0]])
    b0 = np.array([[0.0, 1.0, 0.0], [0.0, -1.0, 0.0]])
    b1 = np.array([[1.0, 1.0, 0.0], [0.0, 1.0, 0.0]])
    rust_batch = segment_segment_distances(a0, a1, b0, b1, backend="rust")
    numpy_batch = segment_segment_distances(a0, a1, b0, b1, backend="numpy")

    assert np.isclose(rust_distance, numpy_distance)
    assert np.isclose(rust_writhe, numpy_writhe)
    assert np.isclose(rust_linking, numpy_linking)
    for rust_values, numpy_values in zip(rust_batch, numpy_batch):
        assert np.allclose(rust_values, numpy_values)


def test_explicit_gpu_segment_distance_matches_numpy_when_installed() -> None:
    if not backend_available("gpu"):
        pytest.skip("GPU kernels are not installed in this environment")

    gpu_distance, *_ = segment_segment_distance(
        [0.0, 0.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        [1.0, 1.0, 0.0],
        backend="gpu",
    )
    numpy_distance, *_ = segment_segment_distance(
        [0.0, 0.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        [1.0, 1.0, 0.0],
        backend="numpy",
    )

    assert np.isclose(gpu_distance, numpy_distance)


def test_batch_segment_distances_match_scalar_numpy() -> None:
    a0 = np.array([[0.0, 0.0, 0.0], [-1.0, 0.0, 0.0]])
    a1 = np.array([[1.0, 0.0, 0.0], [1.0, 0.0, 0.0]])
    b0 = np.array([[0.0, 1.0, 0.0], [0.0, -1.0, 0.0]])
    b1 = np.array([[1.0, 1.0, 0.0], [0.0, 1.0, 0.0]])

    batch = segment_segment_distances(a0, a1, b0, b1, backend="numpy")
    scalar = [
        segment_segment_distance(*endpoints, backend="numpy")
        for endpoints in zip(a0, a1, b0, b1)
    ]

    assert np.allclose(batch[0], [item[0] for item in scalar])
    assert np.allclose(batch[1], [item[1] for item in scalar])
    assert np.allclose(batch[2], [item[2] for item in scalar])
    assert np.allclose(batch[3], [item[3] for item in scalar])
    assert np.allclose(batch[4], [item[4] for item in scalar])


def test_gpu_batch_segment_distances_match_numpy_when_installed() -> None:
    if not backend_available("gpu"):
        pytest.skip("GPU kernels are not installed in this environment")

    a0 = np.array([[0.0, 0.0, 0.0], [-1.0, 0.0, 0.0]])
    a1 = np.array([[1.0, 0.0, 0.0], [1.0, 0.0, 0.0]])
    b0 = np.array([[0.0, 1.0, 0.0], [0.0, -1.0, 0.0]])
    b1 = np.array([[1.0, 1.0, 0.0], [0.0, 1.0, 0.0]])

    gpu = segment_segment_distances(a0, a1, b0, b1, backend="gpu")
    numpy = segment_segment_distances(a0, a1, b0, b1, backend="numpy")

    for gpu_values, numpy_values in zip(gpu, numpy):
        assert np.allclose(gpu_values, numpy_values)


def test_segment_bbox_candidate_pairs_3d_skips_adjacent_segments() -> None:
    min_x = np.array([-1.0, -1.0, -1.0, -1.0])
    max_x = np.array([1.0, 1.0, 1.0, 1.0])
    min_y = np.array([-1.0, -1.0, -1.0, -1.0])
    max_y = np.array([1.0, 1.0, 1.0, 1.0])
    min_z = np.array([-1.0, -1.0, -1.0, -1.0])
    max_z = np.array([1.0, 1.0, 1.0, 1.0])
    component_ids = np.array([0, 0, 0, 0])
    segment_ids = np.array([0, 1, 2, 3])
    component_segment_counts = np.array([4])
    component_closed = np.array([True])
    order_rank = np.array([0, 1, 2, 3])

    left, right = segment_bbox_candidate_pairs_3d(
        min_x,
        max_x,
        min_y,
        max_y,
        min_z,
        max_z,
        component_ids,
        segment_ids,
        component_segment_counts,
        component_closed,
        order_rank,
        threshold=0.0,
        backend="numpy",
    )
    adjacent_left, adjacent_right = segment_bbox_candidate_pairs_3d(
        min_x,
        max_x,
        min_y,
        max_y,
        min_z,
        max_z,
        component_ids,
        segment_ids,
        component_segment_counts,
        component_closed,
        order_rank,
        threshold=0.0,
        include_adjacent=True,
        backend="numpy",
    )

    assert left.tolist() == [0, 1]
    assert right.tolist() == [2, 3]
    assert len(adjacent_left) == len(adjacent_right) == 6


def test_gpu_segment_bbox_candidate_pairs_3d_match_numpy_when_installed() -> None:
    if not backend_available("gpu"):
        pytest.skip("GPU kernels are not installed in this environment")

    min_x = np.array([-1.0, -1.0, -1.0, 4.0, 4.5])
    max_x = np.array([1.0, 1.0, 1.0, 5.0, 5.5])
    min_y = np.array([-1.0, -1.0, -1.0, 4.0, 4.5])
    max_y = np.array([1.0, 1.0, 1.0, 5.0, 5.5])
    min_z = np.array([-1.0, -1.0, -1.0, 4.0, 4.5])
    max_z = np.array([1.0, 1.0, 1.0, 5.0, 5.5])
    component_ids = np.array([0, 0, 0, 1, 1])
    segment_ids = np.array([0, 1, 2, 0, 1])
    component_segment_counts = np.array([3, 2])
    component_closed = np.array([False, False])
    order_rank = np.array([0, 1, 2, 3, 4])

    gpu = segment_bbox_candidate_pairs_3d(
        min_x,
        max_x,
        min_y,
        max_y,
        min_z,
        max_z,
        component_ids,
        segment_ids,
        component_segment_counts,
        component_closed,
        order_rank,
        threshold=0.1,
        backend="gpu",
    )
    numpy = segment_bbox_candidate_pairs_3d(
        min_x,
        max_x,
        min_y,
        max_y,
        min_z,
        max_z,
        component_ids,
        segment_ids,
        component_segment_counts,
        component_closed,
        order_rank,
        threshold=0.1,
        backend="numpy",
    )

    assert np.array_equal(gpu[0], numpy[0])
    assert np.array_equal(gpu[1], numpy[1])

    gpu_adjacent = segment_bbox_candidate_pairs_3d(
        min_x,
        max_x,
        min_y,
        max_y,
        min_z,
        max_z,
        component_ids,
        segment_ids,
        component_segment_counts,
        component_closed,
        order_rank,
        threshold=0.1,
        include_adjacent=True,
        backend="gpu",
    )
    numpy_adjacent = segment_bbox_candidate_pairs_3d(
        min_x,
        max_x,
        min_y,
        max_y,
        min_z,
        max_z,
        component_ids,
        segment_ids,
        component_segment_counts,
        component_closed,
        order_rank,
        threshold=0.1,
        include_adjacent=True,
        backend="numpy",
    )

    assert np.array_equal(gpu_adjacent[0], numpy_adjacent[0])
    assert np.array_equal(gpu_adjacent[1], numpy_adjacent[1])


def test_rust_segment_bbox_candidate_pairs_3d_match_numpy_when_installed() -> None:
    if not backend_available("rust"):
        pytest.skip("Rust kernels are not installed in this environment")

    min_x = np.array([-1.0, -1.0, -1.0, 4.0, 4.5])
    max_x = np.array([1.0, 1.0, 1.0, 5.0, 5.5])
    min_y = np.array([-1.0, -1.0, -1.0, 4.0, 4.5])
    max_y = np.array([1.0, 1.0, 1.0, 5.0, 5.5])
    min_z = np.array([-1.0, -1.0, -1.0, 4.0, 4.5])
    max_z = np.array([1.0, 1.0, 1.0, 5.0, 5.5])
    component_ids = np.array([0, 0, 0, 1, 1])
    segment_ids = np.array([0, 1, 2, 0, 1])
    component_segment_counts = np.array([3, 2])
    component_closed = np.array([False, False])
    order_rank = np.array([0, 1, 2, 3, 4])

    rust = segment_bbox_candidate_pairs_3d(
        min_x,
        max_x,
        min_y,
        max_y,
        min_z,
        max_z,
        component_ids,
        segment_ids,
        component_segment_counts,
        component_closed,
        order_rank,
        threshold=0.1,
        backend="rust",
    )
    numpy = segment_bbox_candidate_pairs_3d(
        min_x,
        max_x,
        min_y,
        max_y,
        min_z,
        max_z,
        component_ids,
        segment_ids,
        component_segment_counts,
        component_closed,
        order_rank,
        threshold=0.1,
        backend="numpy",
    )

    assert np.array_equal(rust[0], numpy[0])
    assert np.array_equal(rust[1], numpy[1])


def test_batch_segment_intersections_2d_reports_strict_hits() -> None:
    p0 = np.array([[0.0, 0.0], [0.0, 0.0]])
    p1 = np.array([[1.0, 1.0], [1.0, 0.0]])
    q0 = np.array([[0.0, 1.0], [0.0, 1.0]])
    q1 = np.array([[1.0, 0.0], [1.0, 1.0]])

    hit, t, u, points, denominator = segment_intersections_2d(
        p0,
        p1,
        q0,
        q1,
        backend="numpy",
    )

    assert hit.tolist() == [True, False]
    assert np.isclose(t[0], 0.5)
    assert np.isclose(u[0], 0.5)
    assert np.allclose(points[0], [0.5, 0.5])
    assert np.isclose(denominator[0], -2.0)


def test_rust_batch_segment_intersections_2d_match_numpy_when_installed() -> None:
    if not backend_available("rust"):
        pytest.skip("Rust kernels are not installed in this environment")

    p0 = np.array([[0.0, 0.0], [0.0, 0.0], [-1.0, 0.0]])
    p1 = np.array([[1.0, 1.0], [1.0, 0.0], [1.0, 0.0]])
    q0 = np.array([[0.0, 1.0], [0.0, 1.0], [0.0, -1.0]])
    q1 = np.array([[1.0, 0.0], [1.0, 1.0], [0.0, 1.0]])

    rust = segment_intersections_2d(p0, p1, q0, q1, backend="rust")
    numpy = segment_intersections_2d(p0, p1, q0, q1, backend="numpy")

    assert np.array_equal(rust[0], numpy[0])
    for rust_values, numpy_values in zip(rust[1:], numpy[1:]):
        assert np.allclose(rust_values, numpy_values)


def test_segment_bbox_candidate_pairs_2d_skips_adjacent_segments() -> None:
    min_x = np.array([-1.0, -1.0, -1.0, -1.0])
    max_x = np.array([1.0, 1.0, 1.0, 1.0])
    min_y = np.array([-1.0, -1.0, -1.0, -1.0])
    max_y = np.array([1.0, 1.0, 1.0, 1.0])
    component_ids = np.array([0, 0, 0, 0])
    segment_ids = np.array([0, 1, 2, 3])
    component_segment_counts = np.array([4])
    component_closed = np.array([True])
    order_rank = np.array([0, 1, 2, 3])

    left, right = segment_bbox_candidate_pairs_2d(
        min_x,
        max_x,
        min_y,
        max_y,
        component_ids,
        segment_ids,
        component_segment_counts,
        component_closed,
        order_rank,
        backend="numpy",
    )

    assert left.tolist() == [0, 1]
    assert right.tolist() == [2, 3]


def test_rust_segment_bbox_candidate_pairs_2d_match_numpy_when_installed() -> None:
    if not backend_available("rust"):
        pytest.skip("Rust kernels are not installed in this environment")

    min_x = np.array([-1.0, -1.0, -1.0, 4.0, 4.5])
    max_x = np.array([1.0, 1.0, 1.0, 5.0, 5.5])
    min_y = np.array([-1.0, -1.0, -1.0, 4.0, 4.5])
    max_y = np.array([1.0, 1.0, 1.0, 5.0, 5.5])
    component_ids = np.array([0, 0, 0, 1, 1])
    segment_ids = np.array([0, 1, 2, 0, 1])
    component_segment_counts = np.array([3, 2])
    component_closed = np.array([False, False])
    order_rank = np.array([0, 1, 2, 3, 4])

    rust = segment_bbox_candidate_pairs_2d(
        min_x,
        max_x,
        min_y,
        max_y,
        component_ids,
        segment_ids,
        component_segment_counts,
        component_closed,
        order_rank,
        backend="rust",
    )
    numpy = segment_bbox_candidate_pairs_2d(
        min_x,
        max_x,
        min_y,
        max_y,
        component_ids,
        segment_ids,
        component_segment_counts,
        component_closed,
        order_rank,
        backend="numpy",
    )

    assert np.array_equal(rust[0], numpy[0])
    assert np.array_equal(rust[1], numpy[1])


def test_gpu_segment_bbox_candidate_pairs_2d_match_numpy_when_installed() -> None:
    if not backend_available("gpu"):
        pytest.skip("GPU kernels are not installed in this environment")

    min_x = np.array([-1.0, -1.0, -1.0, 4.0, 4.5])
    max_x = np.array([1.0, 1.0, 1.0, 5.0, 5.5])
    min_y = np.array([-1.0, -1.0, -1.0, 4.0, 4.5])
    max_y = np.array([1.0, 1.0, 1.0, 5.0, 5.5])
    component_ids = np.array([0, 0, 0, 1, 1])
    segment_ids = np.array([0, 1, 2, 0, 1])
    component_segment_counts = np.array([3, 2])
    component_closed = np.array([False, False])
    order_rank = np.array([0, 1, 2, 3, 4])

    gpu = segment_bbox_candidate_pairs_2d(
        min_x,
        max_x,
        min_y,
        max_y,
        component_ids,
        segment_ids,
        component_segment_counts,
        component_closed,
        order_rank,
        backend="gpu",
    )
    numpy = segment_bbox_candidate_pairs_2d(
        min_x,
        max_x,
        min_y,
        max_y,
        component_ids,
        segment_ids,
        component_segment_counts,
        component_closed,
        order_rank,
        backend="numpy",
    )

    assert np.array_equal(gpu[0], numpy[0])
    assert np.array_equal(gpu[1], numpy[1])


def test_gpu_batch_segment_intersections_2d_match_numpy_when_installed() -> None:
    if not backend_available("gpu"):
        pytest.skip("GPU kernels are not installed in this environment")

    p0 = np.array([[0.0, 0.0], [0.0, 0.0], [-1.0, 0.0]])
    p1 = np.array([[1.0, 1.0], [1.0, 0.0], [1.0, 0.0]])
    q0 = np.array([[0.0, 1.0], [0.0, 1.0], [0.0, -1.0]])
    q1 = np.array([[1.0, 0.0], [1.0, 1.0], [0.0, 1.0]])

    gpu = segment_intersections_2d(p0, p1, q0, q1, backend="gpu")
    numpy = segment_intersections_2d(p0, p1, q0, q1, backend="numpy")

    assert np.array_equal(gpu[0], numpy[0])
    for gpu_values, numpy_values in zip(gpu[1:], numpy[1:]):
        assert np.allclose(gpu_values, numpy_values)


def test_explicit_gpu_writhe_and_linking_match_numpy_when_installed() -> None:
    if not backend_available("gpu"):
        pytest.skip("GPU kernels are not installed in this environment")

    points = circle_points(count=128)
    first, second = hopf_link_points(count=256)

    gpu_writhe = compute_writhe(points, closed=True, backend="gpu")
    numpy_writhe = compute_writhe(points, closed=True, backend="numpy")
    gpu_linking = compute_gaussian_linking_number(first, second, backend="gpu")
    numpy_linking = compute_gaussian_linking_number(first, second, backend="numpy")

    assert np.isclose(gpu_writhe, numpy_writhe)
    assert np.isclose(gpu_linking, numpy_linking)


def test_backend_report_exposes_optional_backend_boundaries() -> None:
    report = backend_report()

    expected_capabilities = {
        "segment_segment_distance",
        "segment_segment_distances",
        "segment_intersections_2d",
        "segment_bbox_candidate_pairs_2d",
        "segment_bbox_candidate_pairs_3d",
        "compute_writhe",
        "compute_gaussian_linking_number",
    }

    assert set(report["kernel_capabilities"]) == expected_capabilities
    assert report["backends"]["numpy"]["available"] is True
    assert report["backends"]["numpy"]["capabilities"] == {
        name: True
        for name in expected_capabilities
    }
    assert report["backends"]["numpy"]["missing_capabilities"] == []
    assert report["auto_backend"] in {"numpy", "rust"}
    assert report["backends"]["gpu"]["explicit_only"] is True
    assert report["backends"]["gpu"]["selected_by_auto"] is False
    for backend in ("rust", "gpu"):
        assert set(report["backends"][backend]["capabilities"]) == expected_capabilities
        missing = report["backends"][backend]["missing_capabilities"]
        assert missing == [
            name
            for name in report["kernel_capabilities"]
            if not report["backends"][backend]["capabilities"][name]
        ]


def test_rust_backend_report_includes_algorithm_metadata_when_installed() -> None:
    if not backend_available("rust"):
        pytest.skip("Rust kernels are not installed in this environment")

    rust = backend_report()["backends"]["rust"]
    info = rust["backend_info"]

    assert rust["available"] is True
    assert rust["missing_capabilities"] == []
    assert info["backend"] == "rust"
    assert info["abi_version"] == 19
    assert info["candidate_pair_algorithm"] == "adaptive_axis_sweep_active_set"
    assert info["candidate_pair_count_fill"] == {
        "segment_bbox_candidate_pairs_2d_count": True,
        "segment_bbox_candidate_pairs_3d_count": True,
        "count_only_allocates_output_pairs": False,
    }
    assert info["owned_string_reports"] == {
        "result_handle_abi": "owned_string_v1",
        "owned_string_contract": EXPECTED_OWNED_STRING_CONTRACT,
        "kernel_backend_report_json": True,
        "invariant_result_handles_report_json": True,
        "invariant_result_handle_report_json": True,
        "segment_segment_distance_report_json": True,
        "gaussian_linking_report_json": True,
        "writhe_report_json": True,
        "segment_contact_records_3d_report_json": True,
        "segment_intersection_records_2d_report_json": True,
        "segment_intersections_2d_report_json": True,
        "segment_bbox_candidate_pairs_2d_report_json": True,
        "segment_bbox_candidate_pairs_3d_report_json": True,
    }
    assert info["invariant_result_handles"] == EXPECTED_INVARIANT_RESULT_HANDLE_METADATA
    invariant_handles = info["invariant_result_handles"]
    assert_invariant_result_handle_metadata_consistency(invariant_handles)
    compute_handle_status = invariant_handles["native_invariant_compute_handles_status"]
    assert compute_handle_status["status"] == "unsupported"
    assert (
        compute_handle_status["status_code"]
        == "native_invariant_compute_handles_unavailable"
    )
    assert compute_handle_status["native_computation_claimed"] is False
    assert compute_handle_status["native_invariant_result_handles_complete"] is False
    assert compute_handle_status["host_action"] == "use_python_file_recompute_boundary"
    assert invariant_handles["native_invariant_result_handles_complete"] is False
    assert invariant_handles["native_invariant_result_handle_blocker_count"] == len(
        invariant_handles["native_invariant_result_handle_blockers"]
    )
    assert invariant_handles["required_native_invariant_handle_gate_count"] == len(
        invariant_handles["required_native_invariant_handle_gates"]
    )
    assert (
        invariant_handles["current_file_recompute_boundary"][
            "native_result_handle_boundary"
        ]
        is False
    )
    assert info["c_abi_callbacks"]["candidate_pair_count"] is True
    assert info["c_abi_callbacks"]["candidate_pair_fill"] is True


def test_rust_invariant_readiness_provenance_links_when_installed() -> None:
    if not backend_available("rust"):
        pytest.skip("Rust kernels are not installed in this environment")

    invariant_handles = backend_report()["backends"]["rust"]["backend_info"][
        "invariant_result_handles"
    ]
    readiness = invariant_handles["readiness_provenance_self_consistency"]
    readiness_note = invariant_handles["readiness_provenance_note"]
    compute_status = invariant_handles["native_invariant_compute_handles_status"]
    current_boundary = invariant_handles["current_file_recompute_boundary"]
    blockers = set(invariant_handles["native_invariant_result_handle_blockers"])
    gates_by_name = {
        gate["gate"]: gate
        for gate in invariant_handles["required_native_invariant_handle_gates"]
    }
    rows_by_invariant = {
        row["invariant"]: row for row in compute_status["per_invariant"]
    }

    assert readiness["readiness"] == "blocked"
    assert (
        readiness_note == EXPECTED_INVARIANT_RESULT_HANDLE_READINESS_PROVENANCE_NOTE
    )
    assert "readiness_provenance_note" not in invariant_handles[
        "required_metadata_fields"
    ]
    assert invariant_handles["required_metadata_field_count"] == 30
    assert readiness["ready_for_native_result_handles"] is False
    assert readiness["native_computation_claimed"] is False
    assert readiness["python_file_recompute_boundary"] is True
    assert readiness["native_result_handle_boundary"] is False
    assert current_boundary["native_result_handle_boundary"] is False
    assert readiness["current_boundary"] == current_boundary["boundary"]
    assert readiness["host_action"] == compute_status["host_action"]
    assert readiness["provenance"] == {
        "metadata_report_symbol": "iroll_invariant_result_handles_report_json",
        "compute_status_field": "native_invariant_compute_handles_status",
        "per_invariant_rows_field": (
            "native_invariant_compute_handles_status.per_invariant"
        ),
        "required_gates_field": "required_native_invariant_handle_gates",
        "blockers_field": "native_invariant_result_handle_blockers",
        "current_boundary_field": "current_file_recompute_boundary",
    }

    for link in readiness["per_invariant_links"]:
        row = rows_by_invariant[link["invariant"]]
        assert link["unsupported"] is True
        assert row["status"] == "unsupported"
        assert link["status"] == row["status"]
        assert link["status_code"] == row["status_code"]
        assert link["blocking_status_code"] == row["blocking_status_code"]
        assert link["blocking_gate"] == row["blocking_gate"]
        assert link["gate_status"] == gates_by_name[link["blocking_gate"]]["status"]
        assert link["metadata_blocker"] in blockers
        assert link["metadata_blocker"] == row["status_code"]
        assert link["required_boundary"] == current_boundary["boundary"]
        assert link["host_action"] == compute_status["host_action"]
        assert link["native_computation_claimed"] is False
        assert link["python_file_recompute_boundary"] is True
        assert link["native_result_handle_boundary"] is False

    gate_blocker_links = readiness["required_gate_blocker_links"]
    assert {link["gate"] for link in gate_blocker_links} == set(gates_by_name)
    assert {link["blocker"] for link in gate_blocker_links} == blockers
    assert all(
        link["gate_status"] == gates_by_name[link["gate"]]["status"]
        for link in gate_blocker_links
    )
    assert all(
        link["required_before_native_result_handle_boundary"] is True
        for link in gate_blocker_links
    )

    self_consistency = readiness["self_consistency"]
    assert self_consistency["unsupported_row_count"] == len(rows_by_invariant)
    assert self_consistency["per_invariant_link_count"] == len(rows_by_invariant)
    assert self_consistency["required_gate_blocker_link_count"] == len(gates_by_name)
    assert self_consistency["per_invariant_links_match_unsupported_rows"] is True
    assert self_consistency["required_gate_blocker_links_cover_metadata_blockers"] is True
    assert self_consistency["native_computation_non_claim_consistent"] is True
    assert self_consistency["readiness_blocked_by_required_gates"] is True


def test_rust_backend_c_report_owned_string_contract_when_installed() -> None:
    if not backend_available("rust"):
        pytest.skip("Rust kernels are not installed in this environment")

    rust = backend_report()["backends"]["rust"]
    module_origin = rust["module_origin"]
    if module_origin is None:
        pytest.skip("Rust module origin is unavailable")
    native_extension = rust_native_extension_path(module_origin)
    if native_extension is None:
        pytest.skip("Rust native extension path is unavailable")

    class IrollKernelOwnedString(ctypes.Structure):
        _fields_ = [
            ("data", ctypes.c_void_p),
            ("length", ctypes.c_size_t),
            ("handle", ctypes.c_void_p),
        ]

    library = ctypes.CDLL(str(native_extension))
    report_json = library.iroll_kernel_backend_report_json
    report_json.argtypes = [ctypes.POINTER(IrollKernelOwnedString)]
    report_json.restype = ctypes.c_int
    free_owned_string = library.iroll_kernel_owned_string_free
    free_owned_string.argtypes = [IrollKernelOwnedString]
    free_owned_string.restype = None

    empty = IrollKernelOwnedString()
    free_owned_string(empty)

    report = IrollKernelOwnedString()
    status = report_json(ctypes.byref(report))
    assert status == 0
    assert report.data
    assert report.handle
    assert report.length > 0
    try:
        raw_with_nul = ctypes.string_at(report.data, report.length + 1)
        assert raw_with_nul.endswith(b"\0")
        raw = raw_with_nul[:-1]
        assert len(raw) == report.length
        payload = json.loads(raw.decode("utf-8"))
    finally:
        free_owned_string(report)

    assert payload["backend"] == "rust"
    assert payload["abi_version"] == 19
    assert payload["result_handle_abi"] == "owned_string_v1"
    assert payload["owned_string_contract"] == EXPECTED_OWNED_STRING_CONTRACT


def test_rust_invariant_result_handles_c_report_json_when_installed() -> None:
    if not backend_available("rust"):
        pytest.skip("Rust kernels are not installed in this environment")

    rust = backend_report()["backends"]["rust"]
    module_origin = rust["module_origin"]
    if module_origin is None:
        pytest.skip("Rust module origin is unavailable")
    native_extension = rust_native_extension_path(module_origin)
    if native_extension is None:
        pytest.skip("Rust native extension path is unavailable")

    class IrollKernelOwnedString(ctypes.Structure):
        _fields_ = [
            ("data", ctypes.c_void_p),
            ("length", ctypes.c_size_t),
            ("handle", ctypes.c_void_p),
        ]

    library = ctypes.CDLL(str(native_extension))
    report_json = library.iroll_invariant_result_handles_report_json
    report_json.argtypes = [ctypes.POINTER(IrollKernelOwnedString)]
    report_json.restype = ctypes.c_int
    free_owned_string = library.iroll_kernel_owned_string_free
    free_owned_string.argtypes = [IrollKernelOwnedString]
    free_owned_string.restype = None

    report = IrollKernelOwnedString()
    status = report_json(ctypes.byref(report))
    assert status == 0
    assert report.data
    assert report.handle
    assert report.length > 0
    try:
        payload = json.loads(ctypes.string_at(report.data, report.length).decode("utf-8"))
    finally:
        free_owned_string(report)

    assert payload["method"] == "invariant_result_handles_report"
    assert payload["backend"] == "rust"
    assert payload["abi_version"] == 19
    backend_invariant_handles = rust["backend_info"]["invariant_result_handles"]
    required_metadata_fields = backend_invariant_handles[
        "required_metadata_fields"
    ]
    assert {
        key: payload[key] for key in required_metadata_fields
    } == {key: backend_invariant_handles[key] for key in required_metadata_fields}
    assert payload["readiness_provenance_self_consistency"] == (
        backend_invariant_handles["readiness_provenance_self_consistency"]
    )
    for key, value in EXPECTED_INVARIANT_RESULT_HANDLE_METADATA.items():
        assert payload[key] == value
    assert_invariant_result_handle_metadata_consistency(payload)
    compute_handle_status = payload["native_invariant_compute_handles_status"]
    assert compute_handle_status["status"] == "unsupported"
    assert (
        compute_handle_status["status_code"]
        == "native_invariant_compute_handles_unavailable"
    )
    assert compute_handle_status["per_invariant"] == [
        {
            "invariant": "homfly",
            "native_compute_handle_available": False,
            "report_json_available": False,
            "report_json_symbol_available": False,
            "native_computation_claimed": False,
            "blocking_gate": "homfly_native_compute_handle",
            "gate_status": "missing",
            "status": "unsupported",
            "status_code": "homfly_native_compute_handle_missing",
            "blocking_status_code": "homfly_native_compute_handle_missing",
            "required_boundary": "python_file_recompute",
            "host_action": "use_python_file_recompute_boundary",
        },
        {
            "invariant": "alexander",
            "native_compute_handle_available": False,
            "report_json_available": False,
            "report_json_symbol_available": False,
            "native_computation_claimed": False,
            "blocking_gate": "alexander_native_compute_handle",
            "gate_status": "missing",
            "status": "unsupported",
            "status_code": "alexander_native_compute_handle_missing",
            "blocking_status_code": "alexander_native_compute_handle_missing",
            "required_boundary": "python_file_recompute",
            "host_action": "use_python_file_recompute_boundary",
        },
    ]
    assert payload["native_invariant_result_handles_complete"] is False
    assert payload["native_invariant_result_handle_blocker_count"] == len(
        payload["native_invariant_result_handle_blockers"]
    )
    assert payload["required_native_invariant_handle_gate_count"] == len(
        payload["required_native_invariant_handle_gates"]
    )
    assert (
        payload["current_file_recompute_boundary"]["native_result_handle_boundary"]
        is False
    )
    assert payload["notes"] == [
        "Dedicated C ABI owned-string metadata report for invariant result-handle capability probing",
        "HOMFLY/Alexander native computation is not claimed by this report",
        "Python file recomputation remains the invariant computation boundary",
    ]


def test_rust_unsupported_result_handle_report_loads_as_imgui_status_when_installed(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    if not backend_available("rust"):
        pytest.skip("Rust kernels are not installed in this environment")

    rust = backend_report()["backends"]["rust"]
    module_origin = rust["module_origin"]
    if module_origin is None:
        pytest.skip("Rust module origin is unavailable")
    native_extension = rust_native_extension_path(module_origin)
    if native_extension is None:
        pytest.skip("Rust native extension path is unavailable")

    class IrollKernelOwnedString(ctypes.Structure):
        _fields_ = [
            ("data", ctypes.c_void_p),
            ("length", ctypes.c_size_t),
            ("handle", ctypes.c_void_p),
        ]

    library = ctypes.CDLL(str(native_extension))
    create_unsupported = library.iroll_invariant_result_handle_create_unsupported
    create_unsupported.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p)]
    create_unsupported.restype = ctypes.c_int
    report_json = library.iroll_invariant_result_handle_report_json
    report_json.argtypes = [ctypes.c_void_p, ctypes.POINTER(IrollKernelOwnedString)]
    report_json.restype = ctypes.c_int
    free_handle = library.iroll_invariant_result_handle_free
    free_handle.argtypes = [ctypes.c_void_p]
    free_handle.restype = None
    free_owned_string = library.iroll_kernel_owned_string_free
    free_owned_string.argtypes = [IrollKernelOwnedString]
    free_owned_string.restype = None

    handle = ctypes.c_void_p()
    status = create_unsupported(b"homfly", ctypes.byref(handle))
    assert status == 0
    assert handle.value
    try:
        report = IrollKernelOwnedString()
        report_status = report_json(handle, ctypes.byref(report))
        assert report_status == 0
        assert report.data
        assert report.handle
        assert report.length > 0
        try:
            payload = json.loads(
                ctypes.string_at(report.data, report.length).decode("utf-8")
            )
        finally:
            free_owned_string(report)
    finally:
        free_handle(handle)

    assert payload["method"] == "invariant_result_handle_report"
    assert payload["backend"] == "rust"
    assert payload["abi_version"] == 19
    assert payload["handle_kind"] == "unsupported"
    assert payload["invariant"] == "homfly"
    assert payload["status"] == "unsupported"
    assert payload["status_code"] == "homfly_native_compute_handle_missing"
    assert payload["blocking_gate"] == "homfly_native_compute_handle"
    assert payload["gate_status"] == "missing"
    assert payload["native_compute_handle_available"] is False
    assert payload["native_computation_claimed"] is False
    assert payload["result_available"] is False
    assert payload["python_file_recompute_boundary"] is True
    assert payload["current_boundary"] == "python_file_recompute"
    assert payload["host_action"] == "use_python_file_recompute_boundary"
    assert payload["claim_scope"] == "unsupported_lifecycle_probe_only"

    helper_payload = rust_unsupported_invariant_result_handle_report("homfly")
    assert helper_payload["method"] == payload["method"]
    assert helper_payload["backend"] == payload["backend"]
    assert helper_payload["abi_version"] == payload["abi_version"]
    assert helper_payload["handle_kind"] == payload["handle_kind"]
    assert helper_payload["invariant"] == payload["invariant"]
    assert helper_payload["status_code"] == payload["status_code"]
    assert helper_payload["native_computation_claimed"] is False
    assert helper_payload["result_available"] is False
    assert helper_payload["claim_scope"] == payload["claim_scope"]

    alexander_helper_payload = rust_unsupported_invariant_result_handle_report(
        "alexander"
    )
    assert alexander_helper_payload["method"] == "invariant_result_handle_report"
    assert alexander_helper_payload["backend"] == "rust"
    assert alexander_helper_payload["abi_version"] == 19
    assert alexander_helper_payload["handle_kind"] == "unsupported"
    assert alexander_helper_payload["invariant"] == "alexander"
    assert (
        alexander_helper_payload["status_code"]
        == "alexander_native_compute_handle_missing"
    )
    assert (
        alexander_helper_payload["blocking_gate"]
        == "alexander_native_compute_handle"
    )
    assert alexander_helper_payload["native_computation_claimed"] is False
    assert alexander_helper_payload["result_available"] is False
    assert (
        alexander_helper_payload["claim_scope"]
        == "unsupported_lifecycle_probe_only"
    )

    status_payload = imgui_invariant_status_payload_from_reports([payload])
    assert status_payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert status_payload["invariant_status_count"] == 1
    assert status_payload["invariant_required_check_count"] == 0
    assert status_payload["invariant_passed_check_count"] == 0
    assert status_payload["invariant_failed_check_count"] == 0
    row = status_payload["invariant_statuses"][0]
    assert row["name"] == "HOMFLY-PT native result handle"
    assert row["value"] == "skipped"
    assert row["skipped"] is True
    assert row["required_check_count"] == 0
    assert row["passed_check_count"] == 0
    assert row["failed_check_count"] == 0
    assert "status_code=homfly_native_compute_handle_missing" in row["notes"]
    assert "blocking_gate=homfly_native_compute_handle" in row["notes"]
    assert "gate_status=missing" in row["notes"]
    assert "native_computation_claimed=false" in row["notes"]
    assert "result_available=false" in row["notes"]
    assert "current_boundary=python_file_recompute" in row["notes"]
    assert "host_action=use_python_file_recompute_boundary" in row["notes"]
    assert "claim_scope=unsupported_lifecycle_probe_only" in row["notes"]
    assert "native_computation_claimed=true" not in row["notes"]
    assert "result_available=true" not in row["notes"]
    json.dumps(status_payload, allow_nan=False)

    report_path = tmp_path / "rust-unsupported-homfly-handle-report.json"
    report_path.write_text(json.dumps(payload), encoding="utf-8")
    from iroll.cli import main

    cli_exit = main(["imgui-invariant-status-summary-payload", str(report_path)])
    cli_status_payload = json.loads(capsys.readouterr().out)
    assert cli_exit == 0
    assert cli_status_payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert cli_status_payload["invariant_status_count"] == 1
    assert cli_status_payload["invariant_required_check_count"] == 0
    assert cli_status_payload["invariant_passed_check_count"] == 0
    assert cli_status_payload["invariant_failed_check_count"] == 0
    cli_row = cli_status_payload["invariant_statuses"][0]
    assert cli_row["name"] == "HOMFLY-PT native result handle"
    assert cli_row["value"] == "skipped"
    assert cli_row["skipped"] is True
    assert "status_code=homfly_native_compute_handle_missing" in cli_row["notes"]
    assert "native_computation_claimed=false" in cli_row["notes"]
    assert "result_available=false" in cli_row["notes"]
    assert "current_boundary=python_file_recompute" in cli_row["notes"]
    assert "claim_scope=unsupported_lifecycle_probe_only" in cli_row["notes"]
    assert "native_computation_claimed=true" not in cli_row["notes"]
    assert "result_available=true" not in cli_row["notes"]


def test_gpu_backend_report_includes_device_metadata_when_installed() -> None:
    if not backend_available("gpu"):
        pytest.skip("GPU kernels are not installed in this environment")

    gpu = backend_report()["backends"]["gpu"]

    assert gpu["available"] is True
    assert gpu["missing_capabilities"] == []
    assert gpu["backend_info"]["backend"] == "cupy"
    assert gpu["backend_info"]["device_count"] >= 1
    assert gpu["backend_info"]["device_name"]
    assert len(gpu["backend_info"]["compute_capability"]) == 2
    assert gpu["backend_info"]["raw_cuda_kernels"] == {
        "segment_segment_distances": True,
        "segment_intersections_2d": True,
        "segment_bbox_candidate_pairs_2d": True,
        "segment_bbox_candidate_pairs_3d": True,
        "segment_bbox_candidate_pairs_2d_count": True,
        "segment_bbox_candidate_pairs_3d_count": True,
        "segment_bbox_candidate_pairs_2d_fill": True,
        "segment_bbox_candidate_pairs_3d_fill": True,
    }
    assert gpu["backend_info"]["candidate_pair_compaction"] == {
        "strategy": "raw_cuda_block_count_then_raw_kernel_fill",
        "count_pass": "raw_cuda_block_count",
        "fill_pass": "raw_cuda_atomic_compaction",
        "traversal": "upper_triangle_o_n2",
        "count_pass_allocates_output_pairs": False,
        "count_pass_runs_on_gpu": True,
        "count_pass_reduces_block_counts_on_host": True,
        "fill_pass_allocates_accepted_pairs_only": True,
        "uses_atomic_compaction": True,
    }


def test_gpu_smoke_success_claim_tracks_required_parity_checks() -> None:
    smoke = load_gpu_smoke_module()

    check_results = [
        {
            "name": name,
            "matched": True,
            "reference_backend": "numpy",
            "tested_backend": "gpu",
            "max_abs_error": 0.0,
            "max_rel_error": 0.0,
            "exact_match": True,
        }
        for name in smoke.REQUIRED_CAPABILITIES
    ]
    payload = smoke.finalize_success_payload(
        {
            "available": True,
            "backend_info": {
                "backend": "cupy",
                "cuda_runtime_version": 12080,
                "device_count": 1,
                "device_name": "contract-test-gpu",
            },
        },
        check_results,
    )

    assert_gpu_smoke_common_artifact_fields(
        payload,
        artifact_kind="gpu_smoke_parity_result",
        execution_path="gpu_backend_parity",
        claim_scope="gpu_dispatch_parity_smoke",
    )
    assert payload["matched"] is True
    assert payload["evidence"]["gpu_dispatch_parity"] is True
    assert payload["gpu_dispatch_parity_smoke_claimed"] is True
    assert payload["gpu_dispatch_parity_smoke_claimed"] == payload["evidence"][
        "gpu_dispatch_parity"
    ]
    assert payload["gpu_release_gate"]["gate_passed"] is True
    assert payload["gpu_release_gate"]["blocking_reasons"] == []
    assert payload["gpu_release_gate"]["cuda_runtime_observed"] is True
    assert payload["gpu_release_gate"]["release_grade_speedup_claimed"] is False
    assert payload["environment_witness"]["schema_version"] == 1
    assert payload["environment_witness"]["backend"]["import_attempted"] is True
    assert payload["environment_witness"]["backend"]["imported"] is True
    assert payload["environment_witness"]["backend"]["backend_info_observed"] is True
    assert payload["environment_witness"]["backend"]["backend_info_backend"] == "cupy"
    assert payload["environment_witness"]["runtime"]["cuda_runtime_observed"] is True
    assert payload["environment_witness"]["runtime"]["cuda_runtime_version"] == 12080
    assert payload["environment_witness"]["runtime"]["device_count"] == 1
    assert payload["environment_witness"]["runtime"]["device_name_observed"] is True
    assert payload["environment_witness"]["simulation"] == {
        "forced_unavailable": False,
        "simulated_parity_failure": False,
    }

    check_results[0] = {**check_results[0], "matched": False}
    payload = smoke.finalize_success_payload({"available": True}, check_results)

    assert_gpu_smoke_common_artifact_fields(
        payload,
        artifact_kind="gpu_smoke_parity_result",
        execution_path="gpu_backend_parity",
        claim_scope="gpu_dispatch_parity_smoke",
    )
    assert payload["matched"] is False
    assert payload["failed_check_count"] == 1
    assert payload["evidence"]["gpu_dispatch_parity"] is False
    assert payload["gpu_dispatch_parity_smoke_claimed"] is False
    assert payload["gpu_dispatch_parity_smoke_claimed"] == payload["evidence"][
        "gpu_dispatch_parity"
    ]
    assert payload["cuda_parity_claimed"] is False
    assert payload["release_grade_speedup_claimed"] is False
    assert payload["gpu_release_gate"]["gate_passed"] is False
    assert payload["gpu_release_gate"]["blocking_reasons"] == [
        "cuda_runtime_not_observed",
        "required_checks_failed",
    ]


def test_gpu_smoke_failure_payload_preserves_machine_readable_boundaries() -> None:
    smoke = load_gpu_smoke_module()

    payload = smoke.failed_parity_payload(AssertionError("distance mismatch"))

    assert_gpu_smoke_common_artifact_fields(
        payload,
        artifact_kind="gpu_smoke_parity_failure",
        execution_path="gpu_backend_parity_mismatch",
        claim_scope="gpu_dispatch_parity_smoke",
    )
    assert payload["available"] is True
    assert payload["matched"] is False
    assert payload["artifact_kind"] == "gpu_smoke_parity_failure"
    assert payload["execution_path"] == "gpu_backend_parity_mismatch"
    assert payload["evidence"] == {
        "gpu_dispatch_parity": False,
        "no_cuda_boundary": False,
        "cuda_parity": False,
        "release_grade_speedup": False,
    }
    assert payload["gpu_dispatch_parity_smoke_claimed"] is False
    assert payload["cuda_parity_claimed"] is False
    assert payload["release_grade_speedup_claimed"] is False
    assert payload["environment_witness"]["backend"]["import_attempted"] is True
    assert payload["environment_witness"]["backend"]["imported"] is True
    assert payload["environment_witness"]["runtime"]["cuda_runtime_observed"] is False
    assert payload["gpu_release_gate"]["gate_passed"] is False
    assert payload["gpu_release_gate"]["blocking_reasons"] == [
        "cuda_runtime_not_observed",
        "required_checks_incomplete",
        "required_checks_failed",
    ]
    assert "not CUDA parity evidence" in payload["note"]
    assert "not release-grade speedup evidence" in payload["note"]

    payload_with_backend_info = smoke.failed_parity_payload(
        AssertionError("distance mismatch"),
        backend_info={
            "backend": "cupy",
            "cuda_runtime_version": 12080,
            "device_count": 1,
            "device_name": "contract-test-gpu",
        },
    )
    assert payload_with_backend_info["environment_metadata"][
        "backend_info_available"
    ] is True
    assert payload_with_backend_info["environment_witness"]["backend"][
        "backend_info_observed"
    ] is True
    assert payload_with_backend_info["environment_witness"]["backend"][
        "backend_info_backend"
    ] == "cupy"
    assert payload_with_backend_info["environment_witness"]["runtime"][
        "cuda_runtime_observed"
    ] is True
    assert payload_with_backend_info["environment_witness"]["runtime"][
        "device_count_observed"
    ] is True
    assert payload_with_backend_info["gpu_release_gate"]["gate_passed"] is False
    assert payload_with_backend_info["gpu_release_gate"]["blocking_reasons"] == [
        "required_checks_incomplete",
        "required_checks_failed",
    ]


def test_gpu_smoke_simulated_parity_failure_emits_failure_artifact() -> None:
    script = (
        Path(__file__).resolve().parents[1]
        / "native"
        / "iroll-kernels-gpu"
        / "examples"
        / "gpu_smoke.py"
    )

    result = subprocess.run(
        [
            sys.executable,
            str(script),
            "--simulate-parity-failure",
        ],
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 1

    payload = json.loads(result.stdout)

    assert_gpu_smoke_common_artifact_fields(
        payload,
        artifact_kind="gpu_smoke_parity_failure",
        execution_path="gpu_backend_parity_mismatch",
        claim_scope="gpu_dispatch_parity_smoke",
    )
    assert payload["available"] is False
    assert payload["matched"] is False
    assert payload["artifact_kind"] == "gpu_smoke_parity_failure"
    assert payload["execution_path"] == "gpu_backend_parity_mismatch"
    assert payload["environment_metadata"]["gpu_backend_import_attempted"] is False
    assert payload["environment_metadata"]["gpu_backend_available"] is False
    assert payload["environment_witness"]["package"]["repo_source_present"] is True
    assert payload["environment_witness"]["backend"]["import_attempted"] is False
    assert payload["environment_witness"]["backend"]["imported"] is False
    assert payload["environment_witness"]["runtime"]["cuda_runtime_observed"] is False
    assert payload["environment_witness"]["simulation"] == {
        "forced_unavailable": False,
        "simulated_parity_failure": True,
    }
    assert payload["evidence"] == {
        "gpu_dispatch_parity": False,
        "no_cuda_boundary": False,
        "cuda_parity": False,
        "release_grade_speedup": False,
    }
    assert payload["gpu_dispatch_parity_smoke_claimed"] is False
    assert payload["cuda_parity_claimed"] is False
    assert payload["release_grade_speedup_claimed"] is False
    assert payload["gpu_release_gate"]["gate_passed"] is False
    assert payload["gpu_release_gate"]["blocking_reasons"] == [
        "gpu_backend_unavailable",
        "cuda_runtime_not_observed",
        "required_checks_incomplete",
        "required_checks_failed",
        "simulated_parity_failure",
    ]
    assert "simulated GPU parity mismatch" in payload["error"]


def test_gpu_smoke_allow_unavailable_emits_no_cuda_boundary_artifact() -> None:
    script = (
        Path(__file__).resolve().parents[1]
        / "native"
        / "iroll-kernels-gpu"
        / "examples"
        / "gpu_smoke.py"
    )

    result = subprocess.run(
        [
            sys.executable,
            str(script),
            "--allow-unavailable",
            "--force-unavailable",
        ],
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr

    payload = json.loads(result.stdout)

    assert_gpu_smoke_common_artifact_fields(
        payload,
        artifact_kind="gpu_smoke_unavailable_boundary",
        execution_path="optional_gpu_unavailable",
        claim_scope="optional_no_cuda_boundary",
    )
    assert payload["available"] is False
    assert payload["matched"] is False
    assert payload["artifact_kind"] == "gpu_smoke_unavailable_boundary"
    assert payload["execution_path"] == "optional_gpu_unavailable"
    assert payload["environment_metadata"] == {
        "gpu_package_optional": True,
        "gpu_backend_import_attempted": False,
        "gpu_backend_available": False,
        "forced_unavailable": True,
        "backend_info_available": False,
        "unavailable_error_type": "ImportError",
    }
    assert payload["environment_witness"]["package"]["repo_source_present"] is True
    assert payload["environment_witness"]["backend"]["import_attempted"] is False
    assert payload["environment_witness"]["backend"]["imported"] is False
    assert payload["environment_witness"]["backend"]["backend_info_observed"] is False
    assert payload["environment_witness"]["runtime"]["cuda_runtime_observed"] is False
    assert payload["environment_witness"]["runtime"]["device_count_observed"] is False
    assert payload["environment_witness"]["simulation"] == {
        "forced_unavailable": True,
        "simulated_parity_failure": False,
    }
    assert payload["environment_witness"]["unavailable_error_type"] == "ImportError"
    assert payload["evidence"] == {
        "gpu_dispatch_parity": False,
        "no_cuda_boundary": True,
        "cuda_parity": False,
        "release_grade_speedup": False,
    }
    assert payload["required_capabilities"] == EXPECTED_GPU_SMOKE_REQUIRED_CAPABILITIES
    assert payload["claim_scope"] == "optional_no_cuda_boundary"
    assert payload["gpu_dispatch_parity_smoke_claimed"] is False
    assert payload["gpu_dispatch_parity_smoke_claimed"] == payload["evidence"][
        "gpu_dispatch_parity"
    ]
    assert payload["cuda_parity_claimed"] is False
    assert payload["parity_check_count"] == 0
    assert payload["passed_check_count"] == 0
    assert payload["failed_check_count"] == 0
    assert payload["check_results"] == []
    assert payload["release_grade_speedup_claimed"] is False
    assert payload["gpu_release_gate"]["gate_passed"] is False
    assert payload["gpu_release_gate"]["blocking_reasons"] == [
        "gpu_backend_unavailable",
        "cuda_runtime_not_observed",
        "required_checks_incomplete",
        "forced_unavailable",
    ]
