from __future__ import annotations

import os
from collections import Counter
from copy import deepcopy
from pathlib import Path

import pytest

import iroll.topology.multivariable_alexander as alexander_module
from iroll.topology import (
    build_planar_diagram,
    fox_admissible_minor_summary,
    fox_derivative_word,
    fox_jacobian,
    fox_minor_from_presentation,
    fox_square_minors_from_presentation,
    get_diagram_fixture,
    homfly_descending_terminal_from_pd,
    homfly_fixture_comparison,
    homfly_mirror_polynomial,
    homfly_polynomial_for_knot,
    homfly_polynomial_for_link,
    homfly_polynomial_from_pd,
    homfly_recursive_evaluation_from_pd,
    homfly_skein_expansion_from_pd,
    homfly_skein_relation,
    homfly_skein_trace_from_pd,
    homfly_unlink_polynomial,
    mirror_signed_pd,
    MultivariateLaurentPolynomial,
    multivariable_alexander_candidates_from_oriented_pd,
    multivariable_alexander_candidates_from_presentation,
    multivariable_alexander_admissible_minor_normalization_audit,
    multivariable_alexander_fixture_comparison,
    multivariable_alexander_from_oriented_pd,
    multivariable_alexander_from_pd,
    multivariable_alexander_from_presentation,
    multivariable_alexander_for_link,
    multivariable_alexander_gcd_from_presentation,
    multivariable_alexander_fixture_acceptance_report,
    multivariable_alexander_improve_scanned_gcd_result,
    multivariable_alexander_minor_divisibility_audit,
    multivariable_alexander_minor_divisibility_audit_from_pd,
    multivariable_alexander_minor_divisibility_audit_from_presentation,
    multivariable_alexander_input_certification_evidence,
    multivariable_alexander_scanned_gcd_audit,
    multivariable_alexander_scanned_gcd_audit_from_pd,
    multivariable_alexander_scanned_gcd_audit_from_presentation,
    multivariable_alexander_signed_pd_coverage_report,
    multivariable_alexander_wirtinger_fox_audit,
    PDCrossingOrientation,
    PDOrientation,
    WirtingerPresentation,
    wirtinger_presentation_from_oriented_crossings,
    wirtinger_presentation_from_oriented_pd,
    wirtinger_presentation_from_pd,
)
from iroll.topology.multivariable_alexander import (
    _common_gcd_attempt_evidence_from_minors,
    _conservative_common_gcd_from_minors,
    _conservative_common_gcd_with_evidence_from_minors,
)
from iroll.validation.fixtures import hopf_link, unlink
from iroll.topology import classify_link


def _synthetic_minor(polynomial: MultivariateLaurentPolynomial) -> dict:
    return {
        "is_zero": polynomial.is_zero,
        "terms": [
            {
                "exponents": list(exponents),
                "coefficient": coefficient,
            }
            for exponents, coefficient in polynomial.terms
        ],
    }


def _synthetic_square_minor_scan(
    polynomials: list[MultivariateLaurentPolynomial],
    *,
    variables: tuple[str, ...],
) -> dict:
    minors = []
    for index, polynomial in enumerate(polynomials):
        normalized = polynomial.normalize_unit()
        minors.append(
            {
                "rows": [0],
                "columns": [index],
                "polynomial": normalized.format(),
                "raw_polynomial": polynomial.format(),
                "terms": _synthetic_minor(normalized)["terms"],
                "raw_terms": _synthetic_minor(polynomial)["terms"],
                "is_zero": polynomial.is_zero,
                "is_unit": len(normalized.terms) == 1
                and abs(normalized.terms[0][1]) == 1,
                "term_count": len(normalized.terms),
            }
        )
    scan = {
        "method": "fox_square_minor_scan",
        "variables": list(variables),
        "matrix_size": [1, len(polynomials)],
        "target_size": 1,
        "minors": minors,
        "truncated": False,
        "skipped": False,
        "notes": ["synthetic square-minor scan"],
    }
    scan["admissible_minor_summary"] = fox_admissible_minor_summary(scan)
    return scan


def _assert_bounded_witness_consistency(
    summary: dict,
    *,
    witness_kind: str,
    witness_count: int,
    witness_list_count: int,
    witness_limit: int,
    witness_truncated: bool,
) -> None:
    expected_witness_list_count = min(witness_count, witness_limit)
    assert summary == {
        "witness_kind": witness_kind,
        "witness_count": witness_count,
        "witness_list_count": witness_list_count,
        "witness_limit": witness_limit,
        "witness_truncated": witness_truncated,
        "expected_witness_list_count": expected_witness_list_count,
        "witness_list_within_limit": witness_list_count <= witness_limit,
        "witness_count_covers_list": witness_count >= witness_list_count,
        "witness_list_count_matches_expected": (
            witness_list_count == expected_witness_list_count
        ),
        "witness_truncation_matches_count": witness_truncated
        == (witness_count > witness_list_count),
        "count_list_limit_truncation_consistent": (
            witness_list_count <= witness_limit
            and witness_count >= witness_list_count
            and witness_list_count == expected_witness_list_count
            and witness_truncated == (witness_count > witness_list_count)
        ),
    }


def _assert_blocker_witness_summary_consistency(
    summary: dict,
    *,
    witness_available: bool,
    missing_witness_reasons: list[str],
    blocker_reason_counts: dict[str, int] | None = None,
) -> None:
    consistency = summary["summary_consistency"]
    if blocker_reason_counts is None:
        blocker_reason_counts = dict(Counter(summary["blocker_reason_codes"]))
    missing_witness_reason_counts = dict(Counter(missing_witness_reasons))
    blocker_witness_sources = summary["blocker_witness_sources"]
    blocker_witness_source_counts_by_reason = dict(
        Counter(row["reason_code"] for row in blocker_witness_sources)
    )
    blocker_witness_source_available_counts_by_reason = dict(
        Counter(
            row["reason_code"]
            for row in blocker_witness_sources
            if row["available"]
        )
    )
    blocker_witness_source_missing_counts_by_reason = dict(
        Counter(
            row["reason_code"]
            for row in blocker_witness_sources
            if not row["available"]
        )
    )
    blocker_witness_source_reason_codes = [
        row["reason_code"] for row in blocker_witness_sources
    ]
    blocker_witness_source_available_blockers = [
        row["blocker"] for row in blocker_witness_sources if row["available"]
    ]
    blocker_witness_source_missing_blockers = [
        row["blocker"] for row in blocker_witness_sources if not row["available"]
    ]
    blocker_witness_source_missing_reasons = [
        row["missing_reason"]
        for row in blocker_witness_sources
        if not row["available"] and row["missing_reason"] is not None
    ]
    blocker_witness_source_missing_reason_counts = dict(
        Counter(blocker_witness_source_missing_reasons)
    )
    assert summary["reason_count"] == len(summary["blocker_reason_codes"])
    assert summary["blocker_reason_count"] == summary["reason_count"]
    assert summary["blocker_reason_counts"] == blocker_reason_counts
    assert summary["witness_available_count"] == int(witness_available)
    assert summary["missing_witness_reasons"] == missing_witness_reasons
    assert summary["missing_witness_reason_counts"] == missing_witness_reason_counts
    assert summary["missing_witness_reason_count"] == len(missing_witness_reasons)
    assert summary["blocker_witness_source_count"] == len(
        blocker_witness_sources
    )
    assert summary["blocker_witness_source_count"] == len(summary["blockers"])
    assert (
        summary["blocker_witness_source_reason_codes"]
        == blocker_witness_source_reason_codes
    )
    assert (
        summary["blocker_witness_source_counts_by_reason"]
        == blocker_witness_source_counts_by_reason
    )
    assert summary["blocker_witness_source_available_count"] == sum(
        int(row["available"]) for row in blocker_witness_sources
    )
    assert (
        summary["blocker_witness_source_available_blockers"]
        == blocker_witness_source_available_blockers
    )
    assert (
        summary["blocker_witness_source_available_counts_by_reason"]
        == blocker_witness_source_available_counts_by_reason
    )
    assert summary["blocker_witness_source_missing_count"] == sum(
        int(not row["available"]) for row in blocker_witness_sources
    )
    assert (
        summary["blocker_witness_source_missing_blockers"]
        == blocker_witness_source_missing_blockers
    )
    assert (
        summary["blocker_witness_source_missing_reasons"]
        == blocker_witness_source_missing_reasons
    )
    assert (
        summary["blocker_witness_source_missing_reason_counts"]
        == blocker_witness_source_missing_reason_counts
    )
    assert summary["blocker_witness_source_missing_reason_count"] == len(
        blocker_witness_source_missing_reasons
    )
    assert (
        summary["blocker_witness_source_missing_counts_by_reason"]
        == blocker_witness_source_missing_counts_by_reason
    )
    assert [
        row["blocker"] for row in blocker_witness_sources
    ] == summary["blockers"]
    assert all(
        row["reason_code"]
        in blocker_witness_source_counts_by_reason
        for row in blocker_witness_sources
    )
    assert all(row["source_provenance_consistent"] for row in blocker_witness_sources)
    assert consistency["method"] == (
        "bounded_admissible_minor_normalization_blocker_summary_consistency"
    )
    assert consistency["blocker_count"] == summary["blocker_count"]
    assert consistency["blocker_list_count"] == len(summary["blockers"])
    assert consistency["blocker_count_matches_list"] is True
    assert consistency["reason_count"] == summary["reason_count"]
    assert consistency["reason_list_count"] == len(summary["blocker_reason_codes"])
    assert consistency["blocker_reason_count"] == summary["blocker_reason_count"]
    assert consistency["reason_count_matches_list"] is True
    assert consistency["blocker_reason_count_matches_reason_count"] is True
    assert consistency["reason_codes_unique"] is True
    assert consistency["blocker_reason_counts_total"] == sum(
        blocker_reason_counts.values()
    )
    assert consistency["expected_blocker_reason_counts_total"] == (
        len(summary["blockers"])
        if summary["blockers"]
        else len(summary["blocker_reason_codes"])
    )
    assert consistency["blocker_reason_counts_total_matches_expected"] is True
    assert consistency["blocker_reason_counts_key_count"] == len(
        blocker_reason_counts
    )
    assert consistency["blocker_reason_counts_keys_match_reason_codes"] is True
    assert consistency["blocker_reason_count_matches_counts_key_count"] is True
    assert consistency["first_witness_available"] is witness_available
    assert consistency["witness_available_count"] == int(witness_available)
    assert consistency["witness_available_count_matches_first_witness"] is True
    assert consistency["first_witness_source_available"] is witness_available
    assert consistency["first_witness_source_matches_witness"] is True
    assert consistency["first_witness_kind_matches_source"] is True
    assert consistency["missing_witness_reason_count"] == len(
        missing_witness_reasons
    )
    assert consistency["missing_witness_reason_list_count"] == len(
        missing_witness_reasons
    )
    assert consistency["missing_witness_reason_count_matches_list"] is True
    assert consistency["missing_witness_reason_counts_total"] == sum(
        missing_witness_reason_counts.values()
    )
    assert consistency["missing_witness_reason_counts_key_count"] == len(
        missing_witness_reason_counts
    )
    assert consistency["missing_witness_reason_counts_total_matches_list"] is True
    assert consistency["missing_witness_reason_counts_keys_match_reasons"] is True
    assert consistency["missing_witness_reason_count_matches_counts_total"] is True
    assert consistency["missing_witness_reasons_match_availability"] is True
    assert consistency["blocker_witness_source_count"] == len(
        blocker_witness_sources
    )
    assert consistency["blocker_witness_source_count_matches_blocker_count"] is True
    assert consistency["blocker_witness_source_blockers"] == summary["blockers"]
    assert consistency["blocker_witness_source_blockers_match_blockers"] is True
    assert (
        consistency["blocker_witness_source_reason_codes"]
        == blocker_witness_source_reason_codes
    )
    assert (
        consistency["expected_blocker_witness_source_reason_codes"]
        == blocker_witness_source_reason_codes
    )
    assert consistency["blocker_witness_source_reason_code_count"] == len(
        blocker_witness_source_reason_codes
    )
    assert (
        consistency[
            "blocker_witness_source_reason_code_count_matches_source_count"
        ]
        is True
    )
    assert (
        consistency[
            "blocker_witness_source_reason_codes_match_blocker_reasons"
        ]
        is True
    )
    assert (
        consistency["blocker_witness_source_counts_by_reason"]
        == blocker_witness_source_counts_by_reason
    )
    assert (
        consistency["expected_blocker_witness_source_counts_by_reason"]
        == blocker_witness_source_counts_by_reason
    )
    assert consistency["blocker_witness_source_reason_counts_match_expected"] is True
    assert consistency["blocker_witness_source_available_count"] == summary[
        "blocker_witness_source_available_count"
    ]
    assert (
        consistency["blocker_witness_source_available_blockers"]
        == blocker_witness_source_available_blockers
    )
    assert (
        consistency[
            "blocker_witness_source_available_blocker_count_matches_available_count"
        ]
        is True
    )
    assert (
        consistency["blocker_witness_source_available_counts_by_reason"]
        == blocker_witness_source_available_counts_by_reason
    )
    assert consistency["blocker_witness_source_available_counts_total"] == sum(
        blocker_witness_source_available_counts_by_reason.values()
    )
    assert (
        consistency[
            "blocker_witness_source_available_counts_total_matches_available_count"
        ]
        is True
    )
    assert consistency["blocker_witness_source_missing_count"] == summary[
        "blocker_witness_source_missing_count"
    ]
    assert (
        consistency["blocker_witness_source_missing_blockers"]
        == blocker_witness_source_missing_blockers
    )
    assert (
        consistency[
            "blocker_witness_source_missing_blocker_count_matches_missing_count"
        ]
        is True
    )
    assert (
        consistency["blocker_witness_source_missing_reasons"]
        == blocker_witness_source_missing_reasons
    )
    assert (
        consistency["blocker_witness_source_missing_reason_counts"]
        == blocker_witness_source_missing_reason_counts
    )
    assert consistency["blocker_witness_source_missing_reason_count"] == len(
        blocker_witness_source_missing_reasons
    )
    assert (
        consistency[
            "blocker_witness_source_missing_reason_count_matches_missing_count"
        ]
        is True
    )
    assert (
        consistency[
            "blocker_witness_source_missing_reason_counts_total_matches_missing_count"
        ]
        is True
    )
    assert (
        consistency["blocker_witness_source_missing_counts_by_reason"]
        == blocker_witness_source_missing_counts_by_reason
    )
    assert consistency["blocker_witness_source_missing_counts_total"] == sum(
        blocker_witness_source_missing_counts_by_reason.values()
    )
    assert (
        consistency[
            "blocker_witness_source_missing_counts_total_matches_missing_count"
        ]
        is True
    )
    assert (
        consistency["blocker_witness_source_availability_counts_sum_to_source_count"]
        is True
    )
    assert (
        consistency["blocker_witness_source_available_rows_have_no_missing_reason"]
        is True
    )
    assert consistency["blocker_witness_source_provenance_consistent"] is True
    assert consistency["source_witness_rows_consistent"] is True
    assert consistency["count_list_source_provenance_consistent"] is True
    assert consistency["full_admissible_minor_normalization_certified"] is False
    assert consistency["full_invariant_certified"] is False


def _assert_gate_summary_matches_blockers(
    summary: dict,
    *,
    expected_blockers: list[str],
) -> None:
    consistency = summary["summary_consistency"]
    pressure = summary["gate_pressure_summary"]
    failed_gate_blocker_attributions = summary[
        "failed_gate_blocker_attributions"
    ]
    provenance = summary["failed_gate_blocker_provenance_consistency"]
    pressure_provenance = pressure[
        "failed_gate_blocker_provenance_consistency"
    ]
    attributed_gate_names = list(
        dict.fromkeys(row["gate"] for row in failed_gate_blocker_attributions)
    )
    failed_gate_names = [
        gate
        for gate, passed in summary["gate_statuses"].items()
        if not passed
    ]
    attributed_gates = {
        row["gate"] for row in failed_gate_blocker_attributions
    }
    attributed_blockers = {
        row["blocker"] for row in failed_gate_blocker_attributions
    }
    attribution_counts_by_gate = dict(
        Counter(row["gate"] for row in failed_gate_blocker_attributions)
    )
    attribution_counts_by_blocker = dict(
        Counter(row["blocker"] for row in failed_gate_blocker_attributions)
    )
    attribution_reason_counts = dict(
        Counter(row["reason_code"] for row in failed_gate_blocker_attributions)
    )
    assert summary["method"] == "bounded_admissible_minor_normalization_gate_summary"
    assert summary["blockers"] == expected_blockers
    assert summary["blocker_count"] == len(expected_blockers)
    assert summary["failed_gate_names"] == failed_gate_names
    assert summary["failed_gate_count"] == len(failed_gate_names)
    assert summary["failed_gate_blockers"] == expected_blockers
    assert summary["failed_gate_blocker_count"] == len(expected_blockers)
    assert summary["failed_gate_blocker_reason_counts"] == attribution_reason_counts
    assert summary["failed_gate_blocker_attribution_count"] == len(
        failed_gate_blocker_attributions
    )
    assert summary["failed_gate_blocker_attribution_counts_by_reason"] == (
        attribution_reason_counts
    )
    assert pressure["method"] == (
        "bounded_admissible_minor_normalization_gate_pressure_summary"
    )
    assert pressure["gate_count"] == summary["gate_count"]
    assert pressure["passed_gate_count"] == summary["passed_gate_count"]
    assert pressure["failed_gate_count"] == summary["failed_gate_count"]
    assert pressure["failed_gate_names"] == summary["failed_gate_names"]
    assert pressure["failed_gate_blockers"] == expected_blockers
    assert pressure["failed_gate_blocker_count"] == len(expected_blockers)
    assert pressure["failed_gate_blocker_reason_counts"] == (
        summary["failed_gate_blocker_reason_counts"]
    )
    assert pressure["failed_gate_blocker_attributions"] == (
        failed_gate_blocker_attributions
    )
    assert pressure["failed_gate_blocker_attribution_count"] == len(
        failed_gate_blocker_attributions
    )
    assert pressure["failed_gate_blocker_attribution_counts_by_reason"] == (
        attribution_reason_counts
    )
    assert pressure_provenance == provenance
    assert provenance["method"] == (
        "bounded_admissible_minor_normalization_failed_gate_blocker_provenance_consistency"
    )
    assert provenance["claim_scope"] == summary["claim_scope"]
    assert provenance["failed_gate_names"] == failed_gate_names
    assert provenance["failed_gate_count"] == len(failed_gate_names)
    assert provenance["failed_gate_blockers"] == expected_blockers
    assert provenance["failed_gate_blocker_count"] == len(expected_blockers)
    assert provenance["failed_gate_blocker_list_count"] == len(expected_blockers)
    assert provenance["failed_gate_blocker_count_matches_list"] is True
    assert provenance["failed_gate_blocker_reason_counts"] == (
        summary["failed_gate_blocker_reason_counts"]
    )
    assert provenance["failed_gate_blocker_reason_count"] == len(
        summary["failed_gate_blocker_reason_counts"]
    )
    assert provenance["failed_gate_blocker_reason_counts_total"] == len(
        expected_blockers
    )
    assert (
        provenance[
            "failed_gate_blocker_reason_counts_total_matches_blocker_count"
        ]
        is True
    )
    assert (
        provenance[
            "failed_gate_blocker_reason_count_matches_counts_key_count"
        ]
        is True
    )
    assert provenance["failed_gate_blocker_attribution_count"] == len(
        failed_gate_blocker_attributions
    )
    assert (
        provenance["failed_gate_blocker_attributed_gate_names"]
        == attributed_gate_names
    )
    assert (
        provenance["failed_gate_blocker_attribution_counts_by_gate"]
        == attribution_counts_by_gate
    )
    assert (
        provenance["failed_gate_blocker_attribution_counts_by_blocker"]
        == attribution_counts_by_blocker
    )
    assert (
        provenance["failed_gate_blocker_attribution_counts_by_reason"]
        == attribution_reason_counts
    )
    assert (
        provenance[
            "failed_gate_blocker_attribution_counts_by_reason_total_matches_attribution_count"
        ]
        is True
    )
    assert (
        provenance[
            "failed_gate_blocker_attribution_blocker_set_matches_failed_gate_blocker_set"
        ]
        is True
    )
    assert (
        provenance[
            "failed_gate_blocker_attribution_gate_set_matches_failed_gate_names"
        ]
        is True
    )
    assert provenance["blocker_witness_summary_available"] is True
    assert provenance["blocker_witness_summary_blockers"] == expected_blockers
    assert provenance["blocker_witness_summary_blocker_count"] == len(
        expected_blockers
    )
    assert provenance["blocker_witness_summary_reason_counts"] == (
        summary["failed_gate_blocker_reason_counts"]
    )
    provenance_rows = provenance["failed_gate_blocker_provenance_rows"]
    assert provenance["failed_gate_blocker_provenance_row_count"] == len(
        provenance_rows
    )
    assert [row["blocker"] for row in provenance_rows] == expected_blockers
    provenance_source_keys = [
        {
            "blocker": row["blocker"],
            "reason_code": row["reason_code"],
            "available": row["source_available"],
            "source_blocker": row["source_blocker"],
            "source_reason_code": row["source_reason_code"],
            "source_field": row["source_field"],
            "source_detail_field": row["source_detail_field"],
            "witness_kind": row["witness_kind"],
            "missing_reason": row["missing_reason"],
            "source_provenance_consistent": row[
                "source_provenance_consistent"
            ],
        }
        for row in provenance_rows
    ]
    source_available_counts_by_reason = dict(
        Counter(
            row["reason_code"] for row in provenance_rows if row["source_available"]
        )
    )
    source_missing_counts_by_reason = dict(
        Counter(
            row["reason_code"]
            for row in provenance_rows
            if not row["source_available"]
        )
    )
    assert provenance["blocker_witness_source_row_count"] == len(provenance_rows)
    assert provenance["blocker_witness_source_row_blockers"] == expected_blockers
    assert provenance["blocker_witness_source_row_reason_counts"] == (
        summary["failed_gate_blocker_reason_counts"]
    )
    assert provenance["blocker_witness_source_row_available_count"] == sum(
        int(row["source_available"]) for row in provenance_rows
    )
    assert provenance["blocker_witness_source_row_missing_count"] == sum(
        int(not row["source_available"]) for row in provenance_rows
    )
    assert (
        provenance["blocker_witness_source_row_available_counts_by_reason"]
        == source_available_counts_by_reason
    )
    assert (
        provenance["blocker_witness_source_row_missing_counts_by_reason"]
        == source_missing_counts_by_reason
    )
    assert (
        provenance["blocker_witness_source_row_provenance_keys"]
        == provenance_source_keys
    )
    assert provenance["failed_gate_blocker_provenance_row_reason_counts"] == (
        summary["failed_gate_blocker_reason_counts"]
    )
    assert provenance["failed_gate_blocker_provenance_row_gate_count_total"] == (
        len(failed_gate_blocker_attributions)
    )
    assert provenance[
        "failed_gate_blocker_provenance_row_failed_gate_names"
    ] == failed_gate_names
    assert provenance[
        "failed_gate_blocker_provenance_source_available_counts_by_reason"
    ] == source_available_counts_by_reason
    assert provenance[
        "failed_gate_blocker_provenance_source_available_counts_total"
    ] == sum(source_available_counts_by_reason.values())
    assert provenance[
        "failed_gate_blocker_provenance_source_missing_counts_by_reason"
    ] == source_missing_counts_by_reason
    assert provenance[
        "failed_gate_blocker_provenance_source_missing_counts_total"
    ] == sum(source_missing_counts_by_reason.values())
    assert (
        provenance["failed_gate_blocker_provenance_row_source_keys"]
        == provenance_source_keys
    )
    assert (
        provenance["failed_gate_blocker_provenance_missing_source_blockers"]
        == []
    )
    assert (
        provenance["failed_gate_blocker_provenance_inconsistent_source_blockers"]
        == []
    )
    assert (
        provenance[
            "blocker_witness_summary_blockers_match_failed_gate_blockers"
        ]
        is True
    )
    assert (
        provenance[
            "blocker_witness_summary_blocker_count_matches_failed_gate_blocker_count"
        ]
        is True
    )
    assert (
        provenance[
            "blocker_witness_summary_reason_counts_match_failed_gate_reason_counts"
        ]
        is True
    )
    assert (
        provenance[
            "blocker_witness_source_row_count_matches_failed_gate_blocker_count"
        ]
        is True
    )
    assert (
        provenance[
            "blocker_witness_source_row_blockers_match_failed_gate_blockers"
        ]
        is True
    )
    assert (
        provenance[
            "blocker_witness_source_row_reason_counts_match_failed_gate_reason_counts"
        ]
        is True
    )
    assert (
        provenance[
            "blocker_witness_source_row_availability_counts_sum_to_row_count"
        ]
        is True
    )
    assert (
        provenance["blocker_witness_source_rows_match_provenance_rows"]
        is True
    )
    assert provenance["provenance_row_count_matches_failed_gate_blocker_count"] is True
    assert provenance["provenance_row_reason_counts_match_failed_gate_reason_counts"] is True
    assert provenance["provenance_row_gate_count_total_matches_attribution_count"] is True
    assert provenance["provenance_row_failed_gate_names_match_failed_gate_names"] is True
    assert provenance["provenance_rows_have_witness_sources"] is True
    assert provenance["provenance_source_provenance_consistent"] is True
    assert (
        provenance["provenance_source_availability_counts_sum_to_row_count"]
        is True
    )
    assert (
        provenance[
            "provenance_source_available_counts_total_matches_available_count"
        ]
        is True
    )
    assert (
        provenance[
            "provenance_source_missing_counts_total_matches_missing_count"
        ]
        is True
    )
    assert provenance["normalization_gate_provenance_consistent"] is True
    assert provenance["full_admissible_minor_normalization_certified"] is False
    assert provenance["full_invariant_certified"] is False
    assert pressure["failed_gate_blocker_set_matches_attribution_set"] is True
    assert (
        pressure[
            "failed_gate_blocker_attribution_gate_set_matches_failed_gate_names"
        ]
        is True
    )
    assert (
        pressure[
            "failed_gate_blocker_attribution_count_covers_failed_gate_blocker_count"
        ]
        is True
    )
    assert (
        pressure[
            "blocker_witness_summary_blocker_count_matches_failed_gate_blocker_count"
        ]
        is True
    )
    assert (
        pressure[
            "blocker_witness_summary_blocker_set_matches_failed_gate_blocker_set"
        ]
        is True
    )
    assert set(expected_blockers) == attributed_blockers
    assert set(failed_gate_names) == attributed_gates
    assert consistency["method"] == (
        "bounded_admissible_minor_normalization_gate_summary_consistency"
    )
    assert (
        consistency["failed_gate_blocker_provenance_consistency"]
        == provenance
    )
    assert consistency["gate_count"] == summary["gate_count"]
    assert consistency["gate_list_count"] == len(summary["gate_checks"])
    assert consistency["gate_names"] == list(summary["gate_statuses"])
    assert consistency["gate_name_count_matches_gate_count"] is True
    assert consistency["gate_blocker_map_keys"] == list(summary["gate_blockers"])
    assert consistency["gate_blocker_keys_match_gate_names"] is True
    assert consistency["passed_gate_count"] == summary["passed_gate_count"]
    assert consistency["failed_gate_count"] == summary["failed_gate_count"]
    assert consistency["failed_gate_names"] == summary["failed_gate_names"]
    assert consistency["failed_gate_name_count_matches_failed_gate_count"] is True
    assert consistency["blocker_count"] == len(expected_blockers)
    assert consistency["failed_gate_blockers_match_blockers"] is True
    assert consistency["failed_gate_blocker_set_matches_blocker_set"] is True
    assert (
        consistency["failed_gate_blocker_reason_counts"]
        == summary["failed_gate_blocker_reason_counts"]
    )
    assert (
        consistency[
            "failed_gate_blocker_reason_counts_total_matches_blocker_count"
        ]
        is True
    )
    assert (
        consistency["failed_gate_blocker_attributions"]
        == failed_gate_blocker_attributions
    )
    assert (
        consistency["failed_gate_blocker_attribution_reason_counts"]
        == attribution_reason_counts
    )
    assert (
        consistency[
            "failed_gate_blocker_attribution_reason_counts_total_matches_attribution_count"
        ]
        is True
    )
    assert (
        consistency[
            "failed_gate_blocker_attribution_set_matches_failed_gate_blocker_set"
        ]
        is True
    )
    assert (
        consistency[
            "failed_gate_blocker_attribution_gate_set_matches_failed_gate_names"
        ]
        is True
    )
    assert (
        consistency[
            "failed_gate_blocker_attribution_count_covers_failed_gate_blocker_count"
        ]
        is True
    )
    assert consistency["blocker_witness_summary_blockers_match"] is True
    assert consistency["blocker_witness_summary_blocker_count_matches"] is True
    assert (
        consistency[
            "blocker_witness_summary_blocker_set_matches_failed_gate_blocker_set"
        ]
        is True
    )
    assert consistency["gate_blocker_summary_consistent"] is True
    assert consistency["full_admissible_minor_normalization_certified"] is False
    assert consistency["full_invariant_certified"] is False


def test_multivariable_alexander_admissible_minor_normalization_audit_certifies_bounded_scan() -> None:
    variables = ("t1",)
    representative = MultivariateLaurentPolynomial.from_dict(
        {(0,): 1, (1,): -1},
        variables=variables,
    )
    shifted_opposite_sign = (-representative).shift((3,))
    scan = _synthetic_square_minor_scan(
        [representative, shifted_opposite_sign],
        variables=variables,
    )
    result = {
        "method": "fox_square_minor_consensus_gcd",
        "multivariable_alexander_polynomial": representative.format(),
        "candidate_polynomials": [representative.normalize_unit().format()],
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "skipped": False,
    }

    audit = multivariable_alexander_admissible_minor_normalization_audit(result)

    assert audit["method"] == (
        "multivariable_alexander_admissible_minor_normalization_audit"
    )
    assert audit["skipped"] is False
    assert audit["normalized_representative_polynomial"] == "1 - t1"
    assert audit["all_nonzero_minors_laurent_unit_equivalent"] is True
    assert audit["bounded_admissible_minor_normalization_certified"] is True
    assert audit["checked_nonzero_minor_count"] == 2
    assert audit["failed_nonzero_minor_count"] == 0
    assert audit["normalization_class_count"] == 1
    assert audit["largest_normalization_class_minor_count"] == 2
    assert audit["representative_normalization_class_minor_count"] == 2
    assert audit["nonrepresentative_normalization_class_count"] == 0
    _assert_bounded_witness_consistency(
        audit["normalization_mismatch_witness_consistency"],
        witness_kind="normalization_mismatch",
        witness_count=0,
        witness_list_count=0,
        witness_limit=8,
        witness_truncated=False,
    )
    assert audit["expected_combination_count"] == 2
    assert audit["scanned_minor_count"] == 2
    assert audit["nonzero_minor_count"] == 2
    assert audit["zero_minor_count"] == 0
    assert audit["unique_nonzero_polynomial_count"] == 1
    assert audit["all_rows_have_nonzero_minor"] is True
    assert audit["all_columns_have_nonzero_minor"] is True
    assert audit["complete_combination_scan"] is True
    assert audit["nonzero_minor_coverage_complete"] is True
    assert audit["full_admissible_minor_normalization_certified"] is False
    assert audit["full_invariant_certified"] is False
    assert audit["admissible_minor_normalization_blockers"] == []
    assert audit["admissible_minor_normalization_blocker_count"] == 0
    assert audit["admissible_minor_normalization_blocker_details"] == {}
    assert audit["full_alexander_completion_blockers"] == [
        "full_admissible_minor_normalization_not_certified",
        "full_varied_polynomial_gcd_not_certified",
        "full_invariant_not_certified",
    ]
    assert audit["full_alexander_completion_blocker_count"] == 3
    assert all(
        record["matches_representative"]
        for record in audit["normalization_records"]
    )


def test_multivariable_alexander_admissible_minor_normalization_gate_summary_tracks_certified_fixture_path() -> None:
    fixture = get_diagram_fixture("3_1")
    result = multivariable_alexander_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
        variables=fixture.expected_multivariable_alexander_variables,
    )
    scanned = multivariable_alexander_scanned_gcd_audit(result)
    normalization = multivariable_alexander_admissible_minor_normalization_audit(
        result
    )
    evidence = multivariable_alexander_input_certification_evidence(
        scanned,
        None,
        normalization,
    )

    assert normalization["bounded_admissible_minor_normalization_certified"] is True
    assert scanned["complete_scanned_gcd_certified"] is True
    normalization_summary = normalization[
        "bounded_admissible_minor_normalization_gate_summary"
    ]
    _assert_gate_summary_matches_blockers(
        normalization_summary,
        expected_blockers=[],
    )
    assert normalization_summary["all_required_gates_passed"] is True
    assert normalization_summary["failed_gate_blockers"] == []
    assert normalization_summary["failed_gate_blocker_reason_counts"] == {}
    assert normalization_summary["failed_gate_blocker_attributions"] == []
    assert normalization_summary["gate_pressure_summary"][
        "blocker_witness_summary_blockers"
    ] == []
    assert normalization_summary["gate_statuses"] == {
        "complete_scan": True,
        "row_coverage": True,
        "column_coverage": True,
        "nonzero_minor_present": True,
        "unique_normalized_class": True,
        "normalization_mismatch_absent": True,
    }
    assert (
        normalization_summary["bounded_admissible_minor_normalization_certified"]
        is True
    )

    evidence_summary = evidence[
        "bounded_admissible_minor_normalization_gate_summary"
    ]
    _assert_gate_summary_matches_blockers(
        evidence_summary,
        expected_blockers=[],
    )
    assert evidence_summary["all_required_gates_passed"] is True
    assert evidence_summary["failed_gate_blockers"] == []
    assert evidence_summary["failed_gate_blocker_reason_counts"] == {}
    assert evidence_summary["failed_gate_blocker_attributions"] == []
    assert evidence_summary["gate_pressure_summary"][
        "blocker_witness_summary_blocker_count"
    ] == 0
    assert evidence_summary["gate_statuses"]["exact_scanned_gcd"] is True
    assert evidence_summary["gate_statuses"]["quotient_gcd"] is True
    assert evidence["full_admissible_minor_normalization_certified"] is False
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_admissible_minor_normalization_audit_keeps_varied_minors_uncertified() -> None:
    variables = ("t1",)
    left = MultivariateLaurentPolynomial.from_dict(
        {(0,): 1, (1,): -1},
        variables=variables,
    )
    right = MultivariateLaurentPolynomial.from_dict(
        {(0,): 1, (1,): 1},
        variables=variables,
    )
    scan = _synthetic_square_minor_scan([left, right], variables=variables)
    result = {
        "method": "fox_square_minor_candidate_scan",
        "multivariable_alexander_polynomial": None,
        "candidate_polynomials": scan["admissible_minor_summary"][
            "unique_nonzero_polynomials"
        ],
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "skipped": False,
    }

    audit = multivariable_alexander_admissible_minor_normalization_audit(result)

    assert audit["all_nonzero_minors_laurent_unit_equivalent"] is False
    assert audit["bounded_admissible_minor_normalization_certified"] is False
    assert audit["checked_nonzero_minor_count"] == 2
    assert audit["failed_nonzero_minor_count"] == 1
    assert audit["scanned_minor_count"] == 2
    assert audit["nonzero_minor_count"] == 2
    assert audit["unique_nonzero_polynomial_count"] == 2
    assert audit["normalization_class_count"] == 2
    assert audit["largest_normalization_class_minor_count"] == 1
    assert audit["representative_normalization_class_minor_count"] == 1
    assert audit["nonrepresentative_normalization_class_count"] == 1
    assert audit["normalization_representative_witness"] == {
        "minor_index": 0,
        "rows": [0],
        "columns": [0],
        "raw_polynomial": "1 - t1",
        "minor_polynomial": "1 - t1",
        "normalized_polynomial": "1 - t1",
    }
    assert audit["normalization_mismatch_witness_count"] == 1
    assert audit["normalization_mismatch_witness_limit"] == 8
    assert audit["normalization_mismatch_witness_truncated"] is False
    _assert_bounded_witness_consistency(
        audit["normalization_mismatch_witness_consistency"],
        witness_kind="normalization_mismatch",
        witness_count=1,
        witness_list_count=1,
        witness_limit=8,
        witness_truncated=False,
    )
    assert audit["normalization_mismatch_witnesses"] == [
        {
            "representative_minor_index": 0,
            "representative_rows": [0],
            "representative_columns": [0],
            "representative_normalized_polynomial": "1 - t1",
            "mismatched_minor_index": 1,
            "mismatched_rows": [0],
            "mismatched_columns": [1],
            "mismatched_normalized_polynomial": "1 + t1",
            "mismatched_raw_polynomial": "1 + t1",
            "mismatched_minor_polynomial": "1 + t1",
        },
    ]
    assert audit["admissible_minor_normalization_blockers"] == [
        "failed_nonzero_minor_normalization",
        "normalization_class_not_unique",
        "normalization_mismatch_witnesses_present",
    ]
    assert audit["admissible_minor_normalization_blocker_count"] == 3
    assert audit["admissible_minor_normalization_blocker_details"][
        "failed_nonzero_minor_normalization"
    ] == {
        "failed_nonzero_minor_count": 1,
        "failed_minor_indices": [1],
    }
    blocker_witness_summary = audit[
        "bounded_admissible_minor_normalization_blocker_witness_summary"
    ]
    assert blocker_witness_summary["method"] == (
        "bounded_admissible_minor_normalization_blocker_witness_summary"
    )
    assert blocker_witness_summary["blockers"] == (
        audit["admissible_minor_normalization_blockers"]
    )
    assert blocker_witness_summary["blocker_reason_codes"] == [
        "nonunique_class"
    ]
    _assert_blocker_witness_summary_consistency(
        blocker_witness_summary,
        witness_available=True,
        missing_witness_reasons=[],
        blocker_reason_counts={"nonunique_class": 3},
    )
    assert blocker_witness_summary["blocker_witness_source_counts_by_reason"] == {
        "nonunique_class": 3,
    }
    assert (
        blocker_witness_summary[
            "blocker_witness_source_available_counts_by_reason"
        ]
        == {"nonunique_class": 3}
    )
    assert (
        blocker_witness_summary["blocker_witness_source_missing_counts_by_reason"]
        == {}
    )
    assert [
        row["blocker"]
        for row in blocker_witness_summary["blocker_witness_sources"]
    ] == audit["admissible_minor_normalization_blockers"]
    assert all(
        row["available"]
        and row["source_matches_blocker"]
        and row["source_reason_matches_blocker_reason"]
        for row in blocker_witness_summary["blocker_witness_sources"]
    )
    assert blocker_witness_summary["first_witness_source"] == {
        "available": True,
        "source_blocker": "failed_nonzero_minor_normalization",
        "source_reason_code": "nonunique_class",
        "source_field": "normalization_audit.normalization_records",
        "source_detail_field": (
            "blocker_details.failed_nonzero_minor_normalization."
            "failed_minor_indices"
        ),
        "witness_kind": "normalization_record",
        "missing_reason": None,
    }
    assert blocker_witness_summary["first_witness"] == {
        "witness_kind": "normalization_record",
        "minor_index": 1,
        "rows": [0],
        "columns": [1],
        "normalized_polynomial": "1 + t1",
        "minor_polynomial": "1 + t1",
        "raw_polynomial": "1 + t1",
    }
    assert audit["admissible_minor_normalization_blocker_details"][
        "bounded_admissible_minor_normalization_blocker_witness_summary"
    ] == blocker_witness_summary
    assert audit["full_alexander_completion_blocker_details"][
        "full_admissible_minor_normalization_not_certified"
    ][
        "bounded_admissible_minor_normalization_blocker_witness_summary"
    ] == blocker_witness_summary
    assert audit["admissible_minor_normalization_blocker_details"][
        "normalization_class_not_unique"
    ]["normalization_class_count"] == 2
    class_detail = audit["admissible_minor_normalization_blocker_details"][
        "normalization_class_not_unique"
    ]
    assert class_detail["normalization_class_witness_count"] == 2
    assert {
        witness["normalized_polynomial"]
        for witness in class_detail["normalization_class_witnesses"]
    } == {
        "1 - t1",
        "1 + t1",
    }
    assert all(
        "first_minor_index" in witness
        and "first_rows" in witness
        and "first_columns" in witness
        for witness in class_detail["normalization_class_witnesses"]
    )
    assert audit["admissible_minor_normalization_blocker_details"][
        "normalization_mismatch_witnesses_present"
    ]["normalization_mismatch_witness_count"] == 1
    assert audit["failed_minor_indices"] == [1]
    assert {row["normalized_polynomial"] for row in audit["normalization_class_counts"]} == {
        "1 - t1",
        "1 + t1",
    }
    assert all(
        "first_minor_index" in row
        and "first_rows" in row
        and "first_columns" in row
        for row in audit["normalization_class_counts"]
    )
    assert audit["full_admissible_minor_normalization_certified"] is False


def test_multivariable_alexander_admissible_minor_normalization_gate_summary_crosschecks_blocker_path() -> None:
    variables = ("t1",)
    left = MultivariateLaurentPolynomial.from_dict(
        {(0,): 1, (1,): -1},
        variables=variables,
    )
    right = MultivariateLaurentPolynomial.from_dict(
        {(0,): 1, (1,): 1},
        variables=variables,
    )
    scan = _synthetic_square_minor_scan([left, right], variables=variables)
    result = {
        "method": "fox_square_minor_candidate_scan",
        "multivariable_alexander_polynomial": None,
        "candidate_polynomials": scan["admissible_minor_summary"][
            "unique_nonzero_polynomials"
        ],
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "skipped": False,
    }

    audit = multivariable_alexander_admissible_minor_normalization_audit(result)

    expected_blockers = [
        "failed_nonzero_minor_normalization",
        "normalization_class_not_unique",
        "normalization_mismatch_witnesses_present",
    ]
    assert audit["bounded_admissible_minor_normalization_certified"] is False
    assert audit["admissible_minor_normalization_blockers"] == expected_blockers
    gate_summary = audit["bounded_admissible_minor_normalization_gate_summary"]
    _assert_gate_summary_matches_blockers(
        gate_summary,
        expected_blockers=expected_blockers,
    )
    assert gate_summary["bounded_admissible_minor_normalization_certified"] is False
    assert gate_summary["gate_statuses"] == {
        "complete_scan": True,
        "row_coverage": True,
        "column_coverage": True,
        "nonzero_minor_present": True,
        "unique_normalized_class": False,
        "normalization_mismatch_absent": False,
    }
    assert gate_summary["failed_gate_names"] == [
        "unique_normalized_class",
        "normalization_mismatch_absent",
    ]
    assert gate_summary["failed_gate_blocker_reason_codes"] == [
        "nonunique_class"
    ]
    assert gate_summary["failed_gate_blocker_reason_counts"] == {
        "nonunique_class": 3,
    }
    assert gate_summary["failed_gate_blocker_attributions"] == [
        {
            "gate": "unique_normalized_class",
            "blocker": "normalization_class_not_unique",
            "reason_code": "nonunique_class",
        },
        {
            "gate": "normalization_mismatch_absent",
            "blocker": "failed_nonzero_minor_normalization",
            "reason_code": "nonunique_class",
        },
        {
            "gate": "normalization_mismatch_absent",
            "blocker": "normalization_mismatch_witnesses_present",
            "reason_code": "nonunique_class",
        },
    ]
    assert gate_summary["failed_gate_blocker_attribution_counts_by_gate"] == {
        "unique_normalized_class": 1,
        "normalization_mismatch_absent": 2,
    }
    assert gate_summary["failed_gate_blocker_attribution_counts_by_blocker"] == {
        "normalization_class_not_unique": 1,
        "failed_nonzero_minor_normalization": 1,
        "normalization_mismatch_witnesses_present": 1,
    }
    assert gate_summary["failed_gate_blocker_attribution_counts_by_reason"] == {
        "nonunique_class": 3,
    }
    assert gate_summary["gate_pressure_summary"][
        "failed_gate_blocker_attribution_counts_by_gate"
    ] == {
        "unique_normalized_class": 1,
        "normalization_mismatch_absent": 2,
    }
    assert gate_summary["gate_blockers"]["unique_normalized_class"] == [
        "normalization_class_not_unique"
    ]
    assert gate_summary["gate_blockers"]["normalization_mismatch_absent"] == [
        "failed_nonzero_minor_normalization",
        "normalization_mismatch_witnesses_present",
    ]
    provenance = gate_summary["failed_gate_blocker_provenance_consistency"]
    assert provenance["normalization_gate_provenance_consistent"] is True
    assert provenance["blocker_witness_summary_first_witness_source"] == {
        "available": True,
        "source_blocker": "failed_nonzero_minor_normalization",
        "source_reason_code": "nonunique_class",
        "source_field": "normalization_audit.normalization_records",
        "source_detail_field": (
            "blocker_details.failed_nonzero_minor_normalization."
            "failed_minor_indices"
        ),
        "witness_kind": "normalization_record",
        "missing_reason": None,
    }
    provenance_rows = {
        row["blocker"]: {
            "reason_code": row["reason_code"],
            "gates": row["gates"],
            "gate_count": row["gate_count"],
            "source_available": row["source_available"],
            "source_blocker": row["source_blocker"],
            "source_reason_code": row["source_reason_code"],
            "source_field": row["source_field"],
            "source_detail_field": row["source_detail_field"],
            "witness_kind": row["witness_kind"],
            "missing_reason": row["missing_reason"],
            "source_provenance_consistent": row[
                "source_provenance_consistent"
            ],
        }
        for row in provenance["failed_gate_blocker_provenance_rows"]
    }
    assert provenance_rows == {
        "failed_nonzero_minor_normalization": {
            "reason_code": "nonunique_class",
            "gates": ["normalization_mismatch_absent"],
            "gate_count": 1,
            "source_available": True,
            "source_blocker": "failed_nonzero_minor_normalization",
            "source_reason_code": "nonunique_class",
            "source_field": "normalization_audit.normalization_records",
            "source_detail_field": (
                "blocker_details.failed_nonzero_minor_normalization."
                "failed_minor_indices"
            ),
            "witness_kind": "normalization_record",
            "missing_reason": None,
            "source_provenance_consistent": True,
        },
        "normalization_class_not_unique": {
            "reason_code": "nonunique_class",
            "gates": ["unique_normalized_class"],
            "gate_count": 1,
            "source_available": True,
            "source_blocker": "normalization_class_not_unique",
            "source_reason_code": "nonunique_class",
            "source_field": (
                "blocker_details.normalization_class_not_unique."
                "normalization_class_witnesses[0]"
            ),
            "source_detail_field": None,
            "witness_kind": "normalization_class",
            "missing_reason": None,
            "source_provenance_consistent": True,
        },
        "normalization_mismatch_witnesses_present": {
            "reason_code": "nonunique_class",
            "gates": ["normalization_mismatch_absent"],
            "gate_count": 1,
            "source_available": True,
            "source_blocker": "normalization_mismatch_witnesses_present",
            "source_reason_code": "nonunique_class",
            "source_field": (
                "normalization_audit.normalization_mismatch_witnesses[0]"
            ),
            "source_detail_field": None,
            "witness_kind": "normalization_mismatch",
            "missing_reason": None,
            "source_provenance_consistent": True,
        },
    }
    assert provenance["failed_gate_blocker_provenance_source_available_count"] == 3
    assert provenance["failed_gate_blocker_provenance_source_missing_count"] == 0
    assert provenance[
        "failed_gate_blocker_provenance_source_available_counts_by_reason"
    ] == {"nonunique_class": 3}
    blocker_witness_summary = audit[
        "bounded_admissible_minor_normalization_blocker_witness_summary"
    ]
    assert (
        gate_summary["summary_consistency"]["blocker_witness_summary_blockers"]
        == blocker_witness_summary["blockers"]
    )
    assert audit["full_admissible_minor_normalization_certified"] is False
    assert audit["full_invariant_certified"] is False


def test_multivariable_alexander_admissible_minor_normalization_audit_caps_mismatch_witnesses() -> None:
    variables = ("t1",)
    representative = MultivariateLaurentPolynomial.from_dict(
        {(0,): 1, (1,): -1},
        variables=variables,
    )
    varied = [
        MultivariateLaurentPolynomial.from_dict(
            {(0,): 1, (1,): coefficient},
            variables=variables,
        )
        for coefficient in range(1, 11)
    ]
    scan = _synthetic_square_minor_scan(
        [representative, *varied],
        variables=variables,
    )
    result = {
        "method": "fox_square_minor_univariate_unit_gcd",
        "multivariable_alexander_polynomial": "1",
        "candidate_polynomials": scan["admissible_minor_summary"][
            "unique_nonzero_polynomials"
        ],
        "presentation": {"variables": list(variables)},
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "skipped": False,
    }

    audit = multivariable_alexander_admissible_minor_normalization_audit(result)
    scanned = multivariable_alexander_scanned_gcd_audit(result)
    evidence = multivariable_alexander_input_certification_evidence(
        scanned,
        None,
        audit,
    )

    assert audit["all_nonzero_minors_laurent_unit_equivalent"] is False
    assert audit["bounded_admissible_minor_normalization_certified"] is False
    assert audit["checked_nonzero_minor_count"] == 11
    assert audit["failed_nonzero_minor_count"] == 10
    assert audit["failed_minor_indices"] == list(range(1, 11))
    assert audit["normalization_class_count"] == 11
    assert audit["normalization_mismatch_witness_count"] == 10
    assert audit["normalization_mismatch_witness_limit"] == 8
    assert len(audit["normalization_mismatch_witnesses"]) == 8
    assert audit["normalization_mismatch_witness_truncated"] is True
    _assert_bounded_witness_consistency(
        audit["normalization_mismatch_witness_consistency"],
        witness_kind="normalization_mismatch",
        witness_count=10,
        witness_list_count=8,
        witness_limit=8,
        witness_truncated=True,
    )
    assert audit["admissible_minor_normalization_blockers"] == [
        "failed_nonzero_minor_normalization",
        "normalization_class_not_unique",
        "normalization_mismatch_witnesses_present",
    ]
    assert audit["admissible_minor_normalization_blocker_details"][
        "normalization_mismatch_witnesses_present"
    ] == {
        "normalization_mismatch_witness_count": 10,
        "normalization_mismatch_witness_limit": 8,
        "normalization_mismatch_witness_truncated": True,
    }
    first_witness = audit["normalization_mismatch_witnesses"][0]
    assert first_witness["representative_minor_index"] == 0
    assert first_witness["representative_normalized_polynomial"] == "1 - t1"
    assert first_witness["mismatched_minor_index"] == 1
    assert first_witness["mismatched_normalized_polynomial"] == "1 + t1"
    assert evidence["admissible_minor_normalization_mismatch_witness_count"] == 10
    assert evidence["admissible_minor_normalization_mismatch_witness_limit"] == 8
    assert evidence["admissible_minor_normalization_mismatch_witness_truncated"] is True
    _assert_bounded_witness_consistency(
        evidence["admissible_minor_normalization_mismatch_witness_consistency"],
        witness_kind="normalization_mismatch",
        witness_count=10,
        witness_list_count=8,
        witness_limit=8,
        witness_truncated=True,
    )
    assert evidence["admissible_minor_normalization_mismatch_witnesses"] == (
        audit["normalization_mismatch_witnesses"]
    )
    assert evidence["admissible_minor_normalization_blockers"] == (
        audit["admissible_minor_normalization_blockers"]
    )
    assert evidence["admissible_minor_normalization_blocker_count"] == 3
    assert evidence["full_admissible_minor_normalization_certified"] is False
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_input_certification_evidence_carries_admissible_normalization() -> None:
    variables = ("t1",)
    representative = MultivariateLaurentPolynomial.from_dict(
        {(0,): 1, (1,): -1},
        variables=variables,
    )
    shifted_opposite_sign = (-representative).shift((2,))
    scan = _synthetic_square_minor_scan(
        [representative, shifted_opposite_sign],
        variables=variables,
    )
    result = {
        "method": "fox_square_minor_consensus_gcd",
        "multivariable_alexander_polynomial": representative.format(),
        "candidate_polynomials": [representative.normalize_unit().format()],
        "presentation": {"variables": list(variables)},
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "skipped": False,
    }

    scanned = multivariable_alexander_scanned_gcd_audit(result)
    normalization = multivariable_alexander_admissible_minor_normalization_audit(
        result
    )
    evidence = multivariable_alexander_input_certification_evidence(
        scanned,
        None,
        normalization,
    )

    assert evidence["bounded_scanned_gcd_certified"] is True
    assert evidence["bounded_alexander_maturity_path"] == (
        "laurent_unit_normalization_consensus"
    )
    assert evidence["bounded_alexander_maturity_path_certified"] is True
    assert evidence["bounded_admissible_minor_normalization_certified"] is True
    assert evidence["all_nonzero_minors_laurent_unit_equivalent"] is True
    assert (
        evidence["admissible_minor_normalized_representative_polynomial"]
        == "1 - t1"
    )
    assert evidence["admissible_minor_normalization_checked_nonzero_minor_count"] == 2
    assert evidence["admissible_minor_normalization_failed_nonzero_minor_count"] == 0
    assert evidence["admissible_minor_normalization_class_count"] == 1
    assert evidence["admissible_minor_normalization_largest_class_minor_count"] == 2
    assert evidence["admissible_minor_normalization_representative_class_minor_count"] == 2
    assert evidence["admissible_minor_normalization_nonrepresentative_class_count"] == 0
    assert evidence["admissible_minor_normalization_mismatch_witness_count"] == 0
    assert evidence["admissible_minor_normalization_mismatch_witness_limit"] == 8
    assert evidence["admissible_minor_normalization_mismatch_witness_truncated"] is False
    assert evidence["admissible_minor_normalization_mismatch_witnesses"] == []
    _assert_bounded_witness_consistency(
        evidence["admissible_minor_normalization_mismatch_witness_consistency"],
        witness_kind="normalization_mismatch",
        witness_count=0,
        witness_list_count=0,
        witness_limit=8,
        witness_truncated=False,
    )
    assert evidence["admissible_minor_normalization_evidence"] == normalization
    assert evidence["certification_blockers"] == []
    assert evidence["certification_blocker_count"] == 0
    assert evidence["certification_blocker_details"] == {}
    assert evidence["admissible_minor_normalization_blockers"] == []
    assert evidence["admissible_minor_normalization_blocker_count"] == 0
    assert evidence["full_alexander_completion_blockers"] == [
        "full_admissible_minor_normalization_not_certified",
        "full_varied_polynomial_gcd_not_certified",
        "full_invariant_not_certified",
    ]
    assert evidence["full_alexander_completion_blocker_count"] == 3
    assert evidence["full_admissible_minor_normalization_certified"] is False
    assert any(
        "bounded admissible-minor normalization audit is attached"
        in note
        for note in evidence["notes"]
    )


def test_multivariable_alexander_input_certification_rebuilds_legacy_normalization_blockers() -> None:
    variables = ("t1",)
    left = MultivariateLaurentPolynomial.from_dict(
        {(0,): 1, (1,): -1},
        variables=variables,
    )
    right = MultivariateLaurentPolynomial.from_dict(
        {(0,): 1, (1,): 1},
        variables=variables,
    )
    scan = _synthetic_square_minor_scan([left, right], variables=variables)
    result = {
        "method": "fox_square_minor_univariate_unit_gcd",
        "multivariable_alexander_polynomial": "1",
        "candidate_polynomials": scan["admissible_minor_summary"][
            "unique_nonzero_polynomials"
        ],
        "presentation": {"variables": list(variables)},
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "skipped": False,
    }

    scanned = multivariable_alexander_scanned_gcd_audit(result)
    normalization = multivariable_alexander_admissible_minor_normalization_audit(
        result
    )
    legacy_normalization = dict(normalization)
    for key in (
        "admissible_minor_normalization_blockers",
        "admissible_minor_normalization_blocker_count",
        "admissible_minor_normalization_blocker_details",
    ):
        legacy_normalization.pop(key, None)

    evidence = multivariable_alexander_input_certification_evidence(
        scanned,
        None,
        legacy_normalization,
    )

    assert scanned["candidate_is_exact_scanned_gcd"] is True
    assert evidence["bounded_scanned_gcd_certified"] is True
    assert evidence["bounded_admissible_minor_normalization_certified"] is False
    assert evidence["admissible_minor_normalization_blockers"] == [
        "failed_nonzero_minor_normalization",
        "normalization_class_not_unique",
        "normalization_mismatch_witnesses_present",
    ]
    assert evidence["admissible_minor_normalization_blocker_count"] == 3
    class_detail = evidence["admissible_minor_normalization_blocker_details"][
        "normalization_class_not_unique"
    ]
    assert class_detail["normalization_class_count"] == 2
    assert class_detail["normalization_class_witness_count"] == 2
    assert class_detail["normalization_class_witnesses"] == (
        normalization["normalization_class_counts"]
    )
    assert {
        witness["normalized_polynomial"]
        for witness in class_detail["normalization_class_witnesses"]
    } == {
        "1 - t1",
        "1 + t1",
    }
    assert all(
        "first_minor_index" in witness
        and "first_rows" in witness
        and "first_columns" in witness
        for witness in class_detail["normalization_class_witnesses"]
    )
    assert evidence["admissible_minor_normalization_mismatch_witness_count"] == 1
    assert evidence["admissible_minor_normalization_mismatch_witnesses"] == (
        normalization["normalization_mismatch_witnesses"]
    )
    assert evidence["full_admissible_minor_normalization_certified"] is False
    assert evidence["full_invariant_certified"] is False

    legacy_without_class_counts = dict(legacy_normalization)
    legacy_without_class_counts.pop("normalization_class_counts", None)
    legacy_without_class_counts["full_admissible_minor_normalization_certified"] = True
    legacy_without_class_counts["full_invariant_certified"] = True

    evidence_without_class_counts = multivariable_alexander_input_certification_evidence(
        scanned,
        None,
        legacy_without_class_counts,
    )

    missing_class_detail = evidence_without_class_counts[
        "admissible_minor_normalization_blocker_details"
    ]["normalization_class_not_unique"]
    assert missing_class_detail["normalization_class_count"] == 2
    assert missing_class_detail["normalization_class_witness_count"] == 0
    assert missing_class_detail["normalization_class_witnesses"] == []
    mismatch_detail = evidence_without_class_counts[
        "admissible_minor_normalization_blocker_details"
    ]["normalization_mismatch_witnesses_present"]
    assert mismatch_detail["normalization_mismatch_witness_count"] == 1
    assert evidence_without_class_counts[
        "admissible_minor_normalization_mismatch_witnesses"
    ] == normalization["normalization_mismatch_witnesses"]
    assert (
        evidence_without_class_counts["full_admissible_minor_normalization_certified"]
        is False
    )
    assert evidence_without_class_counts["full_invariant_certified"] is False

    legacy_without_witnesses = dict(legacy_normalization)
    for key in (
        "admissible_minor_normalization_blockers",
        "admissible_minor_normalization_blocker_count",
        "admissible_minor_normalization_blocker_details",
        "normalization_class_counts",
        "normalization_records",
        "normalization_mismatch_witnesses",
        "normalization_representative_witness",
    ):
        legacy_without_witnesses.pop(key, None)

    evidence_without_witnesses = multivariable_alexander_input_certification_evidence(
        scanned,
        None,
        legacy_without_witnesses,
    )

    no_forge_summary = evidence_without_witnesses[
        "bounded_admissible_minor_normalization_blocker_witness_summary"
    ]
    assert no_forge_summary["blocker_reason_codes"] == ["nonunique_class"]
    assert no_forge_summary["first_witness_available"] is False
    assert no_forge_summary["first_witness_kind"] is None
    assert no_forge_summary["first_witness"] is None
    _assert_blocker_witness_summary_consistency(
        no_forge_summary,
        witness_available=False,
        missing_witness_reasons=["no_reusable_locator_witness"],
        blocker_reason_counts={"nonunique_class": 2},
    )
    assert no_forge_summary["blocker_witness_source_counts_by_reason"] == {
        "nonunique_class": 2,
    }
    assert no_forge_summary[
        "blocker_witness_source_available_counts_by_reason"
    ] == {}
    assert no_forge_summary[
        "blocker_witness_source_missing_counts_by_reason"
    ] == {"nonunique_class": 2}
    assert no_forge_summary["blocker_witness_source_missing_count"] == 2
    assert no_forge_summary["blocker_witness_sources"] == [
        {
            "blocker": "failed_nonzero_minor_normalization",
            "reason_code": "nonunique_class",
            "available": False,
            "source_blocker": None,
            "source_reason_code": None,
            "source_field": None,
            "source_detail_field": None,
            "witness_kind": None,
            "missing_reason": "no_reusable_locator_witness",
            "source_matches_blocker": False,
            "source_reason_matches_blocker_reason": False,
            "source_provenance_consistent": True,
        },
        {
            "blocker": "normalization_class_not_unique",
            "reason_code": "nonunique_class",
            "available": False,
            "source_blocker": None,
            "source_reason_code": None,
            "source_field": None,
            "source_detail_field": None,
            "witness_kind": None,
            "missing_reason": "no_reusable_locator_witness",
            "source_matches_blocker": False,
            "source_reason_matches_blocker_reason": False,
            "source_provenance_consistent": True,
        },
    ]
    assert no_forge_summary["first_witness_source"] == {
        "available": False,
        "source_blocker": None,
        "source_reason_code": None,
        "source_field": None,
        "source_detail_field": None,
        "witness_kind": None,
        "missing_reason": "no_reusable_locator_witness",
    }
    assert evidence_without_witnesses[
        "admissible_minor_normalization_blocker_details"
    ][
        "bounded_admissible_minor_normalization_blocker_witness_summary"
    ] == no_forge_summary


def test_multivariable_alexander_input_certification_normalizes_stale_legacy_normalization_details() -> None:
    variables = ("t1",)
    left = MultivariateLaurentPolynomial.from_dict(
        {(0,): 1, (1,): -1},
        variables=variables,
    )
    right = MultivariateLaurentPolynomial.from_dict(
        {(0,): 1, (1,): 1},
        variables=variables,
    )
    scan = _synthetic_square_minor_scan([left, right], variables=variables)
    result = {
        "method": "fox_square_minor_univariate_unit_gcd",
        "multivariable_alexander_polynomial": "1",
        "candidate_polynomials": scan["admissible_minor_summary"][
            "unique_nonzero_polynomials"
        ],
        "presentation": {"variables": list(variables)},
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "skipped": False,
    }

    scanned = multivariable_alexander_scanned_gcd_audit(result)
    normalization = multivariable_alexander_admissible_minor_normalization_audit(
        result
    )
    legacy_normalization = deepcopy(normalization)
    legacy_normalization["failed_nonzero_minor_count"] = 99
    legacy_normalization["normalization_mismatch_witness_count"] = 99
    legacy_normalization["normalization_mismatch_witness_truncated"] = False
    legacy_normalization["full_admissible_minor_normalization_certified"] = True
    legacy_normalization["full_invariant_certified"] = True
    details = legacy_normalization[
        "admissible_minor_normalization_blocker_details"
    ]
    details["failed_nonzero_minor_normalization"][
        "failed_nonzero_minor_count"
    ] = 99
    details["normalization_class_not_unique"][
        "normalization_class_witness_count"
    ] = 99
    details["normalization_class_not_unique"][
        "normalization_class_witnesses"
    ] = []
    details["normalization_mismatch_witnesses_present"][
        "normalization_mismatch_witness_count"
    ] = 99

    evidence = multivariable_alexander_input_certification_evidence(
        scanned,
        None,
        legacy_normalization,
    )

    assert evidence["admissible_minor_normalization_failed_nonzero_minor_count"] == 1
    assert evidence["admissible_minor_normalization_mismatch_witness_count"] == len(
        evidence["admissible_minor_normalization_mismatch_witnesses"]
    )
    assert evidence["admissible_minor_normalization_mismatch_witness_count"] == 1
    assert (
        evidence["admissible_minor_normalization_mismatch_witness_truncated"]
        is False
    )
    _assert_bounded_witness_consistency(
        evidence["admissible_minor_normalization_mismatch_witness_consistency"],
        witness_kind="normalization_mismatch",
        witness_count=1,
        witness_list_count=1,
        witness_limit=8,
        witness_truncated=False,
    )
    blocker_details = evidence["admissible_minor_normalization_blocker_details"]
    failed_detail = blocker_details["failed_nonzero_minor_normalization"]
    assert failed_detail["failed_nonzero_minor_count"] == len(
        failed_detail["failed_minor_indices"]
    )
    assert failed_detail["failed_nonzero_minor_count"] == 1
    class_detail = blocker_details["normalization_class_not_unique"]
    assert class_detail["normalization_class_witnesses"] == (
        normalization["normalization_class_counts"]
    )
    assert class_detail["normalization_class_witness_count"] == len(
        class_detail["normalization_class_witnesses"]
    )
    assert class_detail["normalization_class_witness_count"] == 2
    mismatch_detail = blocker_details["normalization_mismatch_witnesses_present"]
    assert mismatch_detail["normalization_mismatch_witness_count"] == len(
        evidence["admissible_minor_normalization_mismatch_witnesses"]
    )
    assert mismatch_detail["normalization_mismatch_witness_count"] == 1
    assert mismatch_detail["normalization_mismatch_witness_limit"] == 8
    assert mismatch_detail["normalization_mismatch_witness_truncated"] is False
    assert evidence["full_admissible_minor_normalization_certified"] is False
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_input_certification_blockers_report_truncated_scan() -> None:
    variables = ("t1",)
    representative = MultivariateLaurentPolynomial.from_dict(
        {(0,): 1, (1,): -1},
        variables=variables,
    )
    scan = _synthetic_square_minor_scan([representative], variables=variables)
    scan["truncated"] = True
    scan["admissible_minor_summary"] = fox_admissible_minor_summary(scan)
    result = {
        "method": "fox_square_minor_consensus_gcd",
        "multivariable_alexander_polynomial": representative.format(),
        "candidate_polynomials": [representative.normalize_unit().format()],
        "presentation": {"variables": list(variables)},
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "skipped": False,
    }

    scanned = multivariable_alexander_scanned_gcd_audit(result)
    normalization = multivariable_alexander_admissible_minor_normalization_audit(
        result
    )
    evidence = multivariable_alexander_input_certification_evidence(
        scanned,
        None,
        normalization,
    )

    assert scanned["candidate_is_exact_scanned_gcd"] is True
    assert evidence["complete_scanned_gcd_certified"] is False
    assert evidence["certification_blockers"] == [
        "complete_combination_scan_incomplete",
        "square_minor_scan_truncated",
        "nonzero_minor_coverage_incomplete",
    ]
    assert evidence["certification_blocker_count"] == 3
    assert evidence["certification_blocker_details"][
        "square_minor_scan_truncated"
    ] == {
        "expected_combination_count": 1,
        "scanned_minor_count": 1,
    }
    assert normalization["bounded_admissible_minor_normalization_certified"] is False
    assert normalization["admissible_minor_normalization_blockers"] == [
        "complete_combination_scan_incomplete",
        "square_minor_scan_truncated",
        "nonzero_minor_coverage_incomplete",
    ]


def test_homfly_table_result_for_knot_entry() -> None:
    result = homfly_polynomial_for_knot(
        determinant=7,
        alexander_polynomial="2 - 3t + 2t^2",
        crossing_count=5,
    )

    assert result["skipped"] is False
    assert result["table_match"]["notation"] == "5_2"
    assert result["homfly_polynomial"]


def test_homfly_pd_zero_crossing_normalization() -> None:
    diagram = build_planar_diagram([], component_count=1, name="unknot")
    result = homfly_polynomial_from_pd(diagram)

    assert result["homfly_polynomial"] == "1"
    assert result["skipped"] is False


def test_homfly_zero_crossing_unlink_uses_split_union_factor() -> None:
    diagram = build_planar_diagram([], component_count=2, name="two-component unlink")
    result = homfly_polynomial_from_pd(diagram)

    assert result["homfly_polynomial"] == "-a^-1*z^-1 + a*z^-1"
    assert homfly_unlink_polynomial(1) == "1"


def test_homfly_skein_expansion_solves_zero_crossing_diagram() -> None:
    diagram = build_planar_diagram([], component_count=2, name="two-component unlink")

    expansion = homfly_skein_expansion_from_pd(diagram)

    assert expansion["homfly_polynomial"] == "-a^-1*z^-1 + a*z^-1"
    assert expansion["frontier_count"] == 0
    assert expansion["terminal_terms"]


def test_homfly_pd_nonterminal_returns_bounded_skein_trace() -> None:
    diagram = build_planar_diagram(
        [
            [1, 4, 2, 5],
            [3, 6, 4, 1],
            [5, 2, 6, 3],
        ],
        signs=[-1, -1, -1],
        component_count=1,
        name="trefoil",
    )

    trace = homfly_skein_trace_from_pd(diagram, max_depth=1, max_nodes=8)
    result = homfly_polynomial_from_pd(diagram, max_depth=1, max_nodes=8)

    assert trace["method"] == "bounded_skein_trace"
    assert trace["node_count"] >= 2
    assert result["skipped"] is True
    assert result["method"] == "bounded_skein_expansion_without_evaluation"
    assert result["trace"]["node_count"] >= 2


def test_homfly_descending_diagram_terminal_evaluates_without_expansion() -> None:
    diagram = build_planar_diagram(
        [
            [3, 1, 4, 2],
            [4, 2, 1, 3],
        ],
        signs=[1, -1],
        component_count=1,
        name="descending-two-crossing-unknot",
    )

    terminal = homfly_descending_terminal_from_pd(diagram)
    expansion = homfly_skein_expansion_from_pd(diagram, max_depth=0)
    trace = homfly_skein_trace_from_pd(diagram, max_depth=0)
    result = homfly_polynomial_from_pd(diagram, max_depth=0)

    assert terminal["terminal"] is True
    assert terminal["terminal_kind"] == "descending_unlink"
    assert [visit["strand"] for visit in terminal["first_visits"]] == ["over", "over"]
    assert expansion["homfly_polynomial"] == "1"
    assert expansion["terminal_terms"][0]["terminal_kind"] == "descending_unlink"
    assert expansion["frontier_count"] == 0
    assert trace["nodes"][0]["terminal_kind"] == "descending_unlink"
    assert trace["nodes"][0]["has_orientation"] is True
    assert result["homfly_polynomial"] == "1"
    assert result["skipped"] is False


def test_homfly_recursive_switching_reaches_descending_terminals() -> None:
    diagram = build_planar_diagram(
        [
            [1, 3, 2, 4],
            [2, 4, 3, 1],
        ],
        signs=[1, -1],
        component_count=1,
        name="under-first-two-crossing-unknot",
    )
    orientation = PDOrientation.from_signed_pd_roles(diagram)

    relation = homfly_skein_relation(diagram, 0, orientation=orientation)
    switched_terminal = homfly_descending_terminal_from_pd(
        relation["negative"],
        orientation=relation["negative_orientation"],
    )
    result = homfly_recursive_evaluation_from_pd(diagram, max_depth=4, max_nodes=32)

    assert switched_terminal["first_visits"][0]["strand"] == "over"
    assert relation["negative"].crossings[0].code == (3, 1, 4, 2)
    assert relation["negative"].crossings[0].sign == -1
    assert relation["negative_orientation"].validation_issues(relation["negative"]) == []
    assert result["skipped"] is False
    assert result["homfly_polynomial"] == "1"
    assert result["recursion_nodes"] > 1
    assert result["cache_hits"] >= 1
    assert {item["terminal_kind"] for item in result["terminal_reductions"]} == {
        "descending_unlink",
    }
    assert {item["component_count"] for item in result["terminal_reductions"]} >= {1, 2}


def test_homfly_recursive_frontier_preserves_path_coefficients() -> None:
    diagram = build_planar_diagram(
        [
            [1, 3, 2, 4],
            [2, 4, 3, 1],
        ],
        signs=[1, -1],
        component_count=1,
        name="under-first-two-crossing-unknot",
    )

    result = homfly_recursive_evaluation_from_pd(diagram, max_depth=4, max_nodes=1)

    assert result["skipped"] is True
    assert result["truncated"] is True
    assert result["frontier_count"] == 2
    assert {item["coefficient"] for item in result["frontier"]} == {
        "a^-2",
        "a^-1*z",
    }
    assert {item["move"] for item in result["frontier"]} == {"switch", "smooth"}


def test_homfly_fixture_regression_pack_matches_registered_values() -> None:
    for notation in ("0_1", "L0a1", "L2a1", "3_1", "4_1"):
        fixture = get_diagram_fixture(notation)
        comparison = homfly_fixture_comparison(notation)

        assert fixture.expected_homfly
        assert fixture.expected_homfly_source
        assert comparison["skipped"] is False
        assert comparison["matched"] is True
        assert comparison["observed_homfly"] == fixture.expected_homfly
        assert comparison["fixture"]["expected_homfly"] == fixture.expected_homfly


def test_homfly_fixture_comparison_uses_explicit_figure_eight_orientation() -> None:
    fixture = get_diagram_fixture("4_1")
    comparison = homfly_fixture_comparison("4_1")

    assert fixture.expected_homfly == "a^-2 - 1 - z^2 + a^2"
    assert fixture.orientation().validation_issues(fixture.diagram()) == []
    assert comparison["skipped"] is False
    assert comparison["matched"] is True
    assert comparison["expected_homfly"] == fixture.expected_homfly
    assert comparison["observed_homfly"] == fixture.expected_homfly
    assert comparison["certified_for_input"] is True
    assert comparison["full_table_normalization_certified"] is False
    assert comparison["result"]["method"] == "certified_iterative_recursive_switching_to_descending"
    assert comparison["result"]["recursive_evaluation"]["method"] == (
        "bounded_recursive_switching_to_descending"
    )
    assert comparison["result"]["recursive_evaluation"]["frontier_count"] == 0
    assert comparison["result"]["recursive_evaluation"]["truncated"] is False
    assert any(
        "default signed-PD position-role inference remains intentionally rejected"
        in note
        for note in comparison["fixture"]["convention_notes"]
    )


def test_homfly_mirror_pair_for_trefoil_matches_polynomial_transform() -> None:
    diagram = get_diagram_fixture("3_1").diagram()
    orientation = PDOrientation.from_signed_pd_roles(diagram)
    mirrored_diagram, mirrored_orientation = mirror_signed_pd(
        diagram,
        orientation=orientation,
    )

    original = homfly_polynomial_from_pd(
        diagram,
        orientation=orientation,
        max_depth=8,
        max_nodes=512,
    )
    mirrored = homfly_polynomial_from_pd(
        mirrored_diagram,
        orientation=mirrored_orientation,
        max_depth=8,
        max_nodes=512,
    )

    assert original["skipped"] is False
    assert mirrored["skipped"] is False
    assert mirrored["homfly_polynomial"] == homfly_mirror_polynomial(
        original["homfly_polynomial"]
    )
    assert homfly_mirror_polynomial(mirrored["homfly_polynomial"]) == original[
        "homfly_polynomial"
    ]


def test_homfly_skein_relation_can_use_explicit_pd_orientation() -> None:
    diagram = build_planar_diagram(
        [[1, 4, 2, 3], [3, 2, 4, 1]],
        signs=[1, -1],
        component_count=2,
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(
                under_in=1,
                under_out=2,
                over_in=4,
                over_out=3,
            ),
            PDCrossingOrientation(
                under_in=3,
                under_out=4,
                over_in=2,
                over_out=1,
            ),
        ),
        edge_components=((1, 0), (2, 0), (3, 1), (4, 1)),
    )

    relation = homfly_skein_relation(diagram, 0, orientation=orientation)

    assert relation["smoothing_method"] == "oriented"
    assert relation["smoothed"].crossing_count == 1
    assert relation["smoothed_orientation"].validation_issues(relation["smoothed"]) == []


def test_homfly_skein_trace_propagates_explicit_pd_orientation() -> None:
    diagram = build_planar_diagram(
        [[1, 4, 2, 3], [3, 2, 4, 1]],
        signs=[1, -1],
        component_count=2,
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(
                under_in=1,
                under_out=2,
                over_in=4,
                over_out=3,
            ),
            PDCrossingOrientation(
                under_in=3,
                under_out=4,
                over_in=2,
                over_out=1,
            ),
        ),
        edge_components=((1, 0), (2, 0), (3, 1), (4, 1)),
    )

    trace = homfly_skein_trace_from_pd(
        diagram,
        orientation=orientation,
        max_depth=1,
        max_nodes=8,
    )
    result = homfly_polynomial_from_pd(
        diagram,
        orientation=orientation,
        max_depth=1,
        max_nodes=8,
    )

    assert trace["nodes"][0]["has_orientation"] is True
    assert any(node["move"] == "smooth" and node["has_orientation"] for node in trace["nodes"])
    assert result["method"] == "bounded_recursive_switching_to_descending"
    assert result["recursive_evaluation"]["recursion_nodes"] >= 1
    assert result["recursive_evaluation"]["terminal_reductions"]


def test_homfly_skein_expansion_reports_oriented_frontier_terms() -> None:
    diagram = build_planar_diagram(
        [[1, 4, 2, 3], [3, 2, 4, 1]],
        signs=[1, -1],
        component_count=2,
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(
                under_in=1,
                under_out=2,
                over_in=4,
                over_out=3,
            ),
            PDCrossingOrientation(
                under_in=3,
                under_out=4,
                over_in=2,
                over_out=1,
            ),
        ),
        edge_components=((1, 0), (2, 0), (3, 1), (4, 1)),
    )

    expansion = homfly_skein_expansion_from_pd(
        diagram,
        orientation=orientation,
        max_depth=1,
        max_nodes=8,
    )
    result = homfly_polynomial_from_pd(
        diagram,
        orientation=orientation,
        max_depth=1,
        max_nodes=8,
    )

    assert expansion["homfly_polynomial"] is None
    assert expansion["frontier_count"] >= 1
    assert any(term["has_orientation"] for term in expansion["frontier"])
    assert result["method"] == "bounded_recursive_switching_to_descending"
    assert result["recursive_evaluation"]["frontier_count"] == 0
    assert result["recursive_evaluation"]["terminal_reductions"]


def test_homfly_link_result_skips_without_known_polynomial() -> None:
    result = homfly_polynomial_for_link("whitehead_link")

    assert result["skipped"] is True
    assert result["table_match"]["link_type"] == "whitehead_link"


def test_multivariable_alexander_link_result() -> None:
    unlink_result = multivariable_alexander_for_link("unlink")
    whitehead_result = multivariable_alexander_for_link("whitehead_link")

    assert unlink_result["skipped"] is False
    assert unlink_result["multivariable_alexander_polynomial"] == "0"
    assert whitehead_result["skipped"] is True


def test_multivariable_alexander_zero_crossing_unlink_from_pd_uses_terminal_normalization() -> None:
    unknot = get_diagram_fixture("0_1").diagram()
    unlink = get_diagram_fixture("L0a1").diagram()

    unknot_result = multivariable_alexander_from_pd(unknot)
    unlink_result = multivariable_alexander_from_pd(unlink)
    unlink_presentation = wirtinger_presentation_from_pd(unlink)

    assert unknot_result["skipped"] is False
    assert unknot_result["method"] == "zero_crossing_unlink_normalization"
    assert unknot_result["multivariable_alexander_polynomial"] == "1"
    assert unknot_result["variables"] == ["t1"]
    assert unknot_result["zero_crossing_unlink_certified"] is True
    assert unknot_result["full_invariant_certified"] is False

    assert unlink_result["skipped"] is False
    assert unlink_result["method"] == "zero_crossing_unlink_normalization"
    assert unlink_result["multivariable_alexander_polynomial"] == "0"
    assert unlink_result["variables"] == ["t1", "t2"]
    assert unlink_result["admissible_minor_summary"]["skipped"] is True
    assert unlink_result["zero_crossing_unlink_certified"] is True
    assert unlink_result["full_admissible_minor_normalization_certified"] is False
    assert unlink_result["full_invariant_certified"] is False

    assert unlink_presentation["skipped"] is True
    assert unlink_presentation["presentation"] is None
    assert "do not contain Wirtinger arc generators" in unlink_presentation["notes"][0]


def test_fox_derivative_for_commutator_word() -> None:
    commutator = [(0, 1), (1, 1), (0, -1), (1, -1)]

    dx = fox_derivative_word(
        commutator,
        target_generator=0,
        generator_components=[0, 1],
    )
    dy = fox_derivative_word(
        commutator,
        target_generator=1,
        generator_components=[0, 1],
    )

    assert dx.format() == "1 - t2"
    assert dy.format() == "-1 + t1"


def test_fox_jacobian_and_minor_from_presentation() -> None:
    commutator = [(0, 1), (1, 1), (0, -1), (1, -1)]
    jacobian = fox_jacobian([commutator], generator_components=[0, 1])
    minor = fox_minor_from_presentation(
        [commutator],
        generator_components=[0, 1],
        remove_column=0,
    )

    assert len(jacobian) == 1
    assert len(jacobian[0]) == 2
    assert minor["method"] == "fox_calculus_presentation_minor"
    assert minor["polynomial"] == "1 - t1"
    assert minor["skipped"] is False


def test_wirtinger_presentation_from_explicit_oriented_crossings() -> None:
    presentation = wirtinger_presentation_from_oriented_crossings(
        generator_components=[0, 0],
        crossings=[
            {
                "under_in": 0,
                "under_out": 1,
                "over": 1,
                "sign": 1,
            }
        ],
    )
    result = multivariable_alexander_from_presentation(
        presentation,
        remove_column=0,
    )

    assert presentation.relations == (((1, 1), (0, 1), (1, -1), (1, -1)),)
    assert result["presentation"]["source"] == "explicit_oriented_crossing_records"
    assert result["method"] == "fox_calculus_presentation_minor"


def test_wirtinger_presentation_from_explicit_oriented_pd() -> None:
    diagram = build_planar_diagram(
        [[1, 4, 2, 3], [3, 2, 4, 1]],
        signs=[1, -1],
        component_count=2,
        name="oriented-hopf",
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(
                under_in=1,
                under_out=2,
                over_in=4,
                over_out=3,
            ),
            PDCrossingOrientation(
                under_in=3,
                under_out=4,
                over_in=2,
                over_out=1,
            ),
        ),
        edge_components=((1, 0), (2, 0), (3, 1), (4, 1)),
    )

    presentation = wirtinger_presentation_from_oriented_pd(
        diagram,
        orientation,
        variables=("t1", "t2"),
    )
    result = multivariable_alexander_from_presentation(presentation, remove_column=0)

    assert presentation.to_dict()["source"] == "explicit_oriented_signed_pd"
    assert presentation.generator_components == (0, 1)
    assert presentation.variables == ("t1", "t2")
    assert result["presentation"]["source"] == "explicit_oriented_signed_pd"
    assert result["skipped"] is True
    assert "not square" in result["notes"][0]


def test_fox_square_minor_scan_for_oriented_pd_presentation() -> None:
    diagram = build_planar_diagram(
        [[1, 4, 2, 3], [3, 2, 4, 1]],
        signs=[1, -1],
        component_count=2,
        name="oriented-hopf",
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(
                under_in=1,
                under_out=2,
                over_in=4,
                over_out=3,
            ),
            PDCrossingOrientation(
                under_in=3,
                under_out=4,
                over_in=2,
                over_out=1,
            ),
        ),
        edge_components=((1, 0), (2, 0), (3, 1), (4, 1)),
    )
    presentation = wirtinger_presentation_from_oriented_pd(
        diagram,
        orientation,
        variables=("t1", "t2"),
    )

    scan = fox_square_minors_from_presentation(
        presentation.relations,
        generator_components=presentation.generator_components,
        variables=presentation.variables,
        target_size=1,
    )

    assert scan["method"] == "fox_square_minor_scan"
    assert scan["matrix_size"] == [2, 2]
    assert len(scan["minors"]) == 4
    assert any(not minor["is_zero"] for minor in scan["minors"])
    assert all("terms" in minor and "raw_terms" in minor for minor in scan["minors"])
    assert {minor["polynomial"] for minor in scan["minors"]} == {"1 - t1", "1 - t2"}

    summary = scan["admissible_minor_summary"]
    assert summary == fox_admissible_minor_summary(scan)
    assert summary["method"] == "fox_admissible_minor_summary"
    assert summary["expected_combination_count"] == 4
    assert summary["scanned_minor_count"] == 4
    assert summary["complete_combination_scan"] is True
    assert summary["nonzero_minor_count"] == 4
    assert summary["zero_minor_count"] == 0
    assert summary["unit_minor_count"] == 0
    assert summary["unique_nonzero_polynomials"] == ["1 - t2", "1 - t1"]
    assert summary["admissible_minor_indices"] == [0, 1, 2, 3]
    assert summary["row_subsets"] == [[0], [1]]
    assert summary["column_subsets"] == [[0], [1]]
    assert summary["covered_rows"] == [0, 1]
    assert summary["covered_columns"] == [0, 1]
    assert summary["all_rows_covered"] is True
    assert summary["all_columns_covered"] is True
    assert summary["nonzero_row_subset_count"] == 2
    assert summary["nonzero_column_subset_count"] == 2
    assert summary["nonzero_row_subsets"] == [[0], [1]]
    assert summary["nonzero_column_subsets"] == [[0], [1]]
    assert summary["nonzero_covered_rows"] == [0, 1]
    assert summary["nonzero_covered_columns"] == [0, 1]
    assert summary["all_rows_have_nonzero_minor"] is True
    assert summary["all_columns_have_nonzero_minor"] is True
    assert summary["nonzero_minor_coverage_complete"] is True


def test_fox_admissible_minor_summary_reports_truncated_scan() -> None:
    diagram = build_planar_diagram(
        [[1, 4, 2, 3], [3, 2, 4, 1]],
        signs=[1, -1],
        component_count=2,
        name="oriented-hopf",
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(
                under_in=1,
                under_out=2,
                over_in=4,
                over_out=3,
            ),
            PDCrossingOrientation(
                under_in=3,
                under_out=4,
                over_in=2,
                over_out=1,
            ),
        ),
        edge_components=((1, 0), (2, 0), (3, 1), (4, 1)),
    )
    presentation = wirtinger_presentation_from_oriented_pd(
        diagram,
        orientation,
        variables=("t1", "t2"),
    )

    scan = fox_square_minors_from_presentation(
        presentation.relations,
        generator_components=presentation.generator_components,
        variables=presentation.variables,
        target_size=1,
        max_minors=1,
    )
    result = multivariable_alexander_gcd_from_presentation(
        presentation,
        max_minors=1,
    )

    summary = scan["admissible_minor_summary"]
    assert scan["truncated"] is True
    assert summary["expected_combination_count"] == 4
    assert summary["scanned_minor_count"] == 1
    assert summary["complete_combination_scan"] is False
    assert summary["truncated"] is True
    assert summary["nonzero_minor_count"] == 1
    assert summary["row_subsets"] == [[0]]
    assert summary["column_subsets"] == [[0]]
    assert summary["all_rows_covered"] is False
    assert summary["all_columns_covered"] is False
    assert summary["nonzero_row_subsets"] == [[0]]
    assert summary["nonzero_column_subsets"] == [[0]]
    assert summary["nonzero_covered_rows"] == [0]
    assert summary["nonzero_covered_columns"] == [0]
    assert summary["all_rows_have_nonzero_minor"] is False
    assert summary["all_columns_have_nonzero_minor"] is False
    assert summary["nonzero_minor_coverage_complete"] is False
    assert result["skipped"] is True
    assert result["admissible_minor_summary"] == summary


def test_multivariable_alexander_candidate_scan_from_oriented_pd() -> None:
    diagram = build_planar_diagram(
        [[1, 4, 2, 3], [3, 2, 4, 1]],
        signs=[1, -1],
        component_count=2,
        name="oriented-hopf",
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(
                under_in=1,
                under_out=2,
                over_in=4,
                over_out=3,
            ),
            PDCrossingOrientation(
                under_in=3,
                under_out=4,
                over_in=2,
                over_out=1,
            ),
        ),
        edge_components=((1, 0), (2, 0), (3, 1), (4, 1)),
    )

    result = multivariable_alexander_candidates_from_oriented_pd(
        diagram,
        orientation,
        variables=("t1", "t2"),
    )
    from_presentation = multivariable_alexander_candidates_from_presentation(
        wirtinger_presentation_from_oriented_pd(
            diagram,
            orientation,
            variables=("t1", "t2"),
        ),
    )

    assert result["method"] == "fox_square_minor_candidate_scan"
    assert result["candidate_polynomials"]
    assert result["requires_normalization"] is True
    assert result["multivariable_alexander_polynomial"] is None
    assert set(result["candidate_polynomials"]) == {"1 - t1", "1 - t2"}
    assert result["square_minors"]["matrix_size"] == [2, 2]
    assert from_presentation["candidate_polynomials"] == result["candidate_polynomials"]


def test_multivariable_alexander_gcd_summary_from_oriented_pd() -> None:
    diagram = build_planar_diagram(
        [[1, 4, 2, 3], [3, 2, 4, 1]],
        signs=[1, -1],
        component_count=2,
        name="oriented-hopf",
    )
    orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(
                under_in=1,
                under_out=2,
                over_in=4,
                over_out=3,
            ),
            PDCrossingOrientation(
                under_in=3,
                under_out=4,
                over_in=2,
                over_out=1,
            ),
        ),
        edge_components=((1, 0), (2, 0), (3, 1), (4, 1)),
    )
    presentation = wirtinger_presentation_from_oriented_pd(
        diagram,
        orientation,
        variables=("t1", "t2"),
    )

    result = multivariable_alexander_gcd_from_presentation(presentation)
    from_pd = multivariable_alexander_from_oriented_pd(
        diagram,
        orientation,
        variables=("t1", "t2"),
    )
    presentation_payload = wirtinger_presentation_from_pd(
        diagram,
        orientation=orientation,
        variables=("t1", "t2"),
    )

    assert result["method"] == "fox_square_minor_disjoint_support_gcd"
    assert result["candidate_polynomials"] == ["1 - t2", "1 - t1"]
    assert result["multivariable_alexander_polynomial"] == "1"
    assert result["requires_normalization"] is False
    first_minor, _second_minor, shifted_minor, _fourth_minor = result["square_minors"]["minors"]
    assert first_minor["normalization"]["applied"] is True
    assert first_minor["normalization"]["raw_polynomial"] == "-1 + t2"
    assert first_minor["normalization"]["normalized_polynomial"] == "1 - t2"
    assert first_minor["normalization"]["unit_sign"] == -1
    assert first_minor["normalization"]["unit_exponents"] == [0, 0]
    assert shifted_minor["normalization"]["unit_exponents"] == [1, 0]
    assert shifted_minor["normalization"]["output_polynomial"] == "1 - t2"
    assert from_pd["skipped"] is False
    assert from_pd["multivariable_alexander_polynomial"] == "1"
    assert from_pd["diagram"]["name"] == "oriented-hopf"
    assert presentation_payload["skipped"] is False
    assert presentation_payload["presentation"]["source"] == "explicit_oriented_signed_pd"


def test_signed_pd_to_wirtinger_infers_position_role_metadata() -> None:
    diagram = build_planar_diagram(
        [
            [1, 4, 2, 3],
            [3, 2, 4, 1],
        ],
        signs=[1, -1],
        component_count=2,
        name="hopf-link",
    )

    result = wirtinger_presentation_from_pd(diagram)
    alexander = multivariable_alexander_from_pd(
        diagram,
        variables=("t1", "t2"),
    )

    assert result["skipped"] is False
    assert result["method"] == "inferred_signed_pd_position_roles"
    assert result["presentation"]["generator_components"] == [0, 1]
    assert alexander["skipped"] is False
    assert alexander["method"] == "fox_square_minor_disjoint_support_gcd"
    assert alexander["multivariable_alexander_polynomial"] == "1"
    assert set(alexander["candidate_polynomials"]) == {"1 - t1", "1 - t2"}


def test_signed_pd_to_wirtinger_accepts_declared_global_role_order() -> None:
    diagram = build_planar_diagram(
        [
            [4, 1, 2, 3],
            [2, 3, 4, 1],
        ],
        signs=[1, -1],
        component_count=2,
        name="hopf-link-external-role-order",
    )

    default_alexander = multivariable_alexander_from_pd(
        diagram,
        variables=("t1", "t2"),
    )
    declared_presentation = wirtinger_presentation_from_pd(
        diagram,
        role_order=(1, 0, 2, 3),
        variables=("t1", "t2"),
    )
    declared_alexander = multivariable_alexander_from_pd(
        diagram,
        role_order=(1, 0, 2, 3),
        variables=("t1", "t2"),
    )

    assert default_alexander["skipped"] is False
    assert default_alexander["orientation_inference"]["method"] == (
        "inferred_signed_pd_position_roles"
    )
    assert declared_presentation["skipped"] is False
    assert declared_presentation["method"] == "inferred_signed_pd_global_role_order"
    assert declared_presentation["orientation_inference"]["role_order"] == [1, 0, 2, 3]
    assert declared_presentation["presentation"]["generator_components"] == [0, 1]
    assert declared_alexander["skipped"] is False
    assert declared_alexander["orientation_inference"]["method"] == (
        "inferred_signed_pd_global_role_order"
    )
    assert declared_alexander["orientation_inference"]["role_order"] == [1, 0, 2, 3]
    assert declared_alexander["method"] == "fox_square_minor_disjoint_support_gcd"
    assert declared_alexander["multivariable_alexander_polynomial"] == "1"
    assert set(declared_alexander["candidate_polynomials"]) == {"1 - t1", "1 - t2"}

def test_multivariable_alexander_detects_bounded_common_binomial_factor() -> None:
    commutator_xy = ((0, 1), (1, 1), (0, -1), (1, -1))
    commutator_yz = ((1, 1), (2, 1), (1, -1), (2, -1))
    presentation = WirtingerPresentation(
        relations=(commutator_xy, commutator_yz),
        generator_components=(0, 0, 1),
        variables=("t1", "t2"),
        source="synthetic_commutator_chain",
    )

    result = multivariable_alexander_gcd_from_presentation(
        presentation,
        target_size=2,
        max_matrix_size=3,
        max_minors=16,
    )

    assert result["skipped"] is False
    assert result["method"] == "fox_square_minor_multivariate_factor_gcd"
    assert result["multivariable_alexander_polynomial"] == "1 - t1"
    assert result["requires_normalization"] is False
    assert set(result["candidate_polynomials"]) == {
        "1 - 2t1 + t1^2",
        "1 - t2 - t1 + t1*t2",
    }
    evidence = result["common_gcd_evidence"]
    assert evidence["method"] == "fox_square_minor_common_gcd_evidence"
    assert evidence["candidate_method"] == result["method"]
    assert evidence["candidate_polynomial"] == "1 - t1"
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert {record["quotient_polynomial"] for record in evidence["division_records"]} == {
        "1 - t1",
        "1 - t2",
    }
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["quotient_common_factor_certified"] is True
    assert evidence["quotient_common_factor_polynomial"] == "1"
    assert (
        evidence["quotient_common_factor_method"]
        == "quotient_disjoint_support_unit_gcd"
    )
    assert evidence["quotient_common_factor_is_unit"] is True
    quotient_status = evidence["quotient_common_factor_status"]
    assert quotient_status["quotient_count"] == len(evidence["division_records"])
    assert quotient_status["common_variable_support"] == []
    assert quotient_status["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_common_gcd_evidence_summarizes_varied_polynomial_scan() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): -1,
        },
        variables=variables,
    )
    quotient_t1 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
        },
        variables=variables,
    )
    quotient_t2 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): 1,
        },
        variables=variables,
    )
    quotient_mixed = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * quotient_t1),
            _synthetic_minor(common * quotient_t2),
            _synthetic_minor(common * quotient_mixed),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_factor_gcd"
    assert polynomial.format() == "1 - t1"
    assert "bounded exact scan" in note
    assert evidence["input_polynomial_count"] == 3
    assert evidence["unique_input_polynomial_count"] == 3
    assert evidence["input_term_count_min"] == 2
    assert evidence["input_term_count_max"] == 4
    assert evidence["input_term_count_signature"] == [
        {"term_count": 2, "input_count": 1},
        {"term_count": 4, "input_count": 2},
    ]
    assert evidence["candidate_polynomial"] == "1 - t1"
    assert evidence["candidate_term_count"] == 2
    assert evidence["divides_all_inputs"] is True
    assert evidence["divisible_input_count"] == 3
    assert evidence["failed_input_count"] == 0
    assert evidence["failed_input_indices"] == []
    assert evidence["quotient_count"] == 3
    assert evidence["unique_quotient_polynomial_count"] == 3
    assert evidence["quotient_term_count_min"] == 2
    assert evidence["quotient_term_count_max"] == 3
    assert evidence["quotient_term_count_signature"] == [
        {"term_count": 2, "quotient_count": 2},
        {"term_count": 3, "quotient_count": 1},
    ]
    assert evidence["quotient_unit_count"] == 0
    assert evidence["quotient_unit_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["quotient_common_factor_polynomial"] == "1"
    assert evidence["full_admissible_minor_normalization_certified"] is False
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_optional_symbolic_gcd_detects_larger_common_factor() -> None:
    pytest.importorskip("sympy")
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 2,
            (0, 1): 3,
            (2, 0): 5,
            (1, 1): 7,
            (0, 2): 11,
            (3, 0): 13,
            (2, 1): 17,
            (1, 2): 19,
            (0, 3): 23,
            (3, 1): 29,
            (2, 2): 31,
            (1, 3): 37,
            (3, 2): 41,
            (2, 3): 43,
        },
        variables=variables,
    )
    extra_t1 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
        },
        variables=variables,
    )
    extra_t2 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * extra_t1),
            _synthetic_minor(common * extra_t2),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_optional_symbolic_multivariate_gcd"
    assert polynomial.format() == common.format()
    assert "optional exact symbolic gcd" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["candidate_term_count"] == 15
    assert evidence["divides_all_inputs"] is True
    assert evidence["quotient_common_factor_certified"] is True
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert (
        evidence["bounded_search_limits"]["optional_symbolic_gcd_max_total_terms"]
        == 128
    )
    assert evidence["full_admissible_minor_normalization_certified"] is False
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_detects_common_scanned_polynomial_divisor() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): -1,
            (1, 0): -1,
            (1, 1): 1,
        },
        variables=variables,
    )
    extra = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_from_minors(
        [
            _synthetic_minor(common),
            _synthetic_minor(common * extra),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note = result
    assert method == "fox_square_minor_multivariate_divisor_gcd"
    assert polynomial.format() == "1 - t2 - t1 + t1*t2"
    assert "exact multivariate division" in note


def test_multivariable_alexander_detects_nine_term_scanned_polynomial_divisor() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 2,
            (0, 1): 1,
            (2, 0): 1,
            (0, 2): 3,
            (2, 1): 1,
            (1, 2): -1,
            (3, 0): 1,
            (0, 3): 1,
        },
        variables=variables,
    ).normalize_unit()
    extra = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): -1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common),
            _synthetic_minor(common * extra),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_divisor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 9
    assert "exact multivariate division" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["full_invariant_certified"] is False

def test_multivariable_alexander_detects_fourteen_term_scanned_polynomial_divisor() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 2,
            (0, 1): 1,
            (2, 0): 1,
            (0, 2): 3,
            (2, 1): 1,
            (1, 2): -1,
            (3, 0): 1,
            (0, 3): 1,
            (3, 2): -2,
            (2, 3): 4,
            (4, 1): -3,
            (1, 4): 5,
            (4, 4): -1,
        },
        variables=variables,
    ).normalize_unit()
    extra = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (50, 0): -1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common),
            _synthetic_minor(common * extra),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_divisor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 14
    assert "exact multivariate division" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    limits = evidence["bounded_search_limits"]
    assert limits["max_candidate_terms"] == 14
    assert limits["direct_scanned_minor_divisor_max_terms"] == 14
    assert limits["sparse_factor_max_terms"] == 14
    assert limits["sparse_factor_max_factors"] == 4
    assert limits["sparse_factor_max_candidates"] == 2048
    assert limits["root_binomial_max_candidates"] == 512
    assert limits["cofactor_max_terms"] == 14
    assert limits["cofactor_max_divisor_factors"] == 2
    assert limits["cofactor_max_candidates"] == 512
    assert limits["cofactor_small_divisor_sparse_factor_max_terms"] == 14
    assert limits["full_invariant_certified"] is False
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_records_uncertified_common_gcd_attempt_evidence() -> None:
    variables = ("t1", "t2")
    first = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): 1,
        },
        variables=variables,
    )
    second = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): 2,
        },
        variables=variables,
    )
    minors = [_synthetic_minor(first), _synthetic_minor(second)]

    assert (
        _conservative_common_gcd_with_evidence_from_minors(
            minors,
            variables=variables,
        )
        is None
    )
    evidence = _common_gcd_attempt_evidence_from_minors(
        minors,
        variables=variables,
        status="not_certified",
        notes=["synthetic bounded common-gcd search did not certify a factor"],
    )

    assert evidence["method"] == "fox_square_minor_common_gcd_attempt_evidence"
    assert evidence["claim_scope"] == "bounded_scanned_fox_minor_common_gcd_attempt"
    assert evidence["status"] == "not_certified"
    assert evidence["certified"] is False
    assert evidence["input_polynomial_count"] == 2
    assert evidence["unique_input_polynomial_count"] == 2
    assert evidence["input_term_count_min"] == 3
    assert evidence["input_term_count_max"] == 3
    assert evidence["input_term_count_signature"] == [
        {"term_count": 3, "input_count": 2},
    ]
    assert evidence["common_integer_content"] == 1
    assert evidence["candidate_polynomial"] is None
    assert evidence["candidate_method"] is None
    assert "bounded_multivariate_sparse_factor" in evidence[
        "candidate_methods_attempted"
    ]
    assert evidence["bounded_search_limits"]["max_candidate_terms"] == 14
    assert evidence["full_admissible_minor_normalization_certified"] is False
    assert evidence["full_invariant_certified"] is False
    diagnostics = evidence["attempt_diagnostics"]
    assert diagnostics["support_signature_variant_count"] == 1
    assert diagnostics["input_term_count_signature"] == [
        {"term_count": 3, "input_count": 2},
    ]
    assert diagnostics["full_admissible_minor_normalization_certified"] is False
    direct_summary = diagnostics["direct_scanned_minor_divisor_summary"]
    assert direct_summary["candidate_count"] == 2
    assert direct_summary["failed_input_count_min"] == 1
    assert direct_summary["failed_input_count_max"] == 1
    assert direct_summary["all_candidates_failed"] is True
    assert direct_summary["full_admissible_minor_normalization_certified"] is False
    assert "did not certify" in evidence["notes"][0]


def test_multivariable_alexander_scanned_gcd_audit_preserves_common_gcd_attempt() -> None:
    variables = ("t1", "t2")
    attempt_evidence = {
        "method": "fox_square_minor_common_gcd_attempt_evidence",
        "claim_scope": "bounded_scanned_fox_minor_common_gcd_attempt",
        "status": "not_certified",
        "certified": False,
        "variables": list(variables),
        "input_polynomial_count": 2,
        "unique_input_polynomial_count": 2,
        "common_integer_content": 1,
        "candidate_methods_attempted": [
            "integer_content",
            "bounded_multivariate_sparse_factor",
        ],
        "bounded_search_limits": {
            "max_candidate_terms": 14,
            "sparse_factor_max_candidates": 2048,
        },
        "full_invariant_certified": False,
        "notes": ["synthetic skipped common-gcd attempt"],
    }
    result = {
        "method": "skipped",
        "multivariable_alexander_polynomial": None,
        "candidate_polynomials": ["1 + t2 + t1", "1 + 2t2 + t1"],
        "presentation": {"variables": list(variables)},
        "square_minors": {"truncated": False, "admissible_minor_summary": {}},
        "admissible_minor_summary": {},
        "common_gcd_attempt_evidence": attempt_evidence,
        "skipped": True,
        "notes": ["synthetic skipped Alexander result"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)
    evidence = multivariable_alexander_input_certification_evidence(audit)

    assert audit["skipped"] is True
    assert audit["common_gcd_attempt_evidence"] == attempt_evidence
    assert evidence["common_gcd_attempt_evidence"] == attempt_evidence
    assert evidence["bounded_scanned_gcd_certified"] is False
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_scanned_gcd_audit_exposes_quotient_uncertainty() -> None:
    variables = ("t1", "t2")
    first = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): 1,
        },
        variables=variables,
    )
    second = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): 2,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan([first, second], variables=variables)
    result = {
        "method": "synthetic_uncertified_quotient_gcd_candidate",
        "multivariable_alexander_polynomial": "1",
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "presentation": {"variables": list(variables)},
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic quotient-gcd uncertainty witness"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)
    evidence = multivariable_alexander_input_certification_evidence(audit)

    assert audit["skipped"] is False
    assert audit["failed_nonzero_minor_count"] == 0
    assert audit["failed_division_witness_count"] == 0
    assert audit["candidate_is_exact_scanned_gcd"] is False
    assert audit["quotient_gcd_certified"] is False
    assert audit["quotient_gcd_polynomial"] is None
    uncertainty = audit["quotient_gcd_uncertainty_evidence"]
    assert uncertainty["method"] == (
        "fox_square_minor_quotient_gcd_uncertainty_evidence"
    )
    assert uncertainty["status"] == "not_certified"
    assert uncertainty["certified"] is False
    assert uncertainty["quotient_polynomial_count"] == 2
    assert uncertainty["quotient_polynomial_count"] == len(
        uncertainty["quotient_polynomials"]
    )
    assert uncertainty["unique_quotient_polynomial_count"] == 2
    assert uncertainty["unique_quotient_polynomial_count"] == len(
        set(uncertainty["quotient_polynomials"])
    )
    assert uncertainty["quotient_polynomial_count_consistency"] == {
        "method": "quotient_polynomial_count_consistency",
        "claim_scope": "bounded_scanned_fox_minor_quotient_gcd_uncertainty",
        "quotient_polynomial_count": 2,
        "quotient_polynomial_list_count": 2,
        "unique_quotient_polynomial_count": 2,
        "unique_quotient_polynomial_list_count": 2,
        "quotient_polynomial_count_matches_list": True,
        "unique_quotient_polynomial_count_matches_list": True,
        "quotient_polynomial_count_covers_unique_count": True,
        "count_list_consistent": True,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
    }
    assert uncertainty["quotient_polynomial_witness_count"] == 2
    assert uncertainty["quotient_polynomial_witness_limit"] == 8
    assert uncertainty["quotient_polynomial_witness_truncated"] is False
    assert uncertainty["first_quotient_polynomial_witness"] == {
        "quotient_index": 0,
        "quotient_polynomial": "1 + t2 + t1",
        "quotient_term_count": 3,
        "variable_support": ["t1", "t2"],
    }
    _assert_bounded_witness_consistency(
        uncertainty["quotient_polynomial_witness_consistency"],
        witness_kind="quotient_polynomial",
        witness_count=2,
        witness_list_count=2,
        witness_limit=8,
        witness_truncated=False,
    )
    assert uncertainty["common_variable_support"] == ["t1", "t2"]
    assert "quotient_conservative_common_laurent_gcd" in uncertainty[
        "candidate_methods_attempted"
    ]
    diagnostics = uncertainty["attempt_diagnostics"]
    assert diagnostics["support_signature_variant_count"] == 1
    assert diagnostics["direct_scanned_minor_divisor_summary"][
        "all_candidates_failed"
    ] is True
    assert evidence["quotient_gcd_uncertainty_present"] is True
    assert evidence["quotient_gcd_uncertainty_evidence"] == uncertainty
    assert "quotient_gcd_uncertified" in evidence["certification_blockers"]
    uncertainty_detail = evidence["certification_blocker_details"][
        "quotient_gcd_uncertified"
    ]
    assert uncertainty_detail["quotient_gcd_uncertainty_present"] is True
    assert uncertainty_detail["quotient_gcd_uncertainty_evidence"] == uncertainty
    certification_witness_summary = evidence["certification_blocker_details"][
        "bounded_admissible_minor_normalization_blocker_witness_summary"
    ]
    assert "quotient_uncertainty" in certification_witness_summary[
        "blocker_reason_codes"
    ]
    _assert_blocker_witness_summary_consistency(
        certification_witness_summary,
        witness_available=True,
        missing_witness_reasons=[],
    )
    assert certification_witness_summary["first_witness_source"] == {
        "available": True,
        "source_blocker": "quotient_gcd_uncertified",
        "source_reason_code": "quotient_uncertainty",
        "source_field": (
            "quotient_gcd_uncertainty_evidence."
            "first_quotient_polynomial_witness"
        ),
        "source_detail_field": None,
        "witness_kind": "quotient_polynomial",
        "missing_reason": None,
    }
    assert certification_witness_summary["first_witness"] == {
        **uncertainty["first_quotient_polynomial_witness"],
        "witness_kind": "quotient_polynomial",
    }
    assert evidence[
        "bounded_admissible_minor_normalization_blocker_witness_summary"
    ] == certification_witness_summary
    assert evidence["full_alexander_completion_blocker_details"][
        "full_admissible_minor_normalization_not_certified"
    ][
        "bounded_admissible_minor_normalization_blocker_witness_summary"
    ] == certification_witness_summary
    assert evidence["bounded_scanned_gcd_certified"] is False
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_blocker_witness_summary_splits_mixed_reason_sources() -> None:
    variables = ("t1", "t2")
    first = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): 1,
        },
        variables=variables,
    )
    second = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): 2,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan([first, second], variables=variables)
    result = {
        "method": "synthetic_uncertified_quotient_gcd_candidate",
        "multivariable_alexander_polynomial": "1",
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "presentation": {"variables": list(variables)},
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic mixed blocker witness-source evidence"],
    }

    scanned = multivariable_alexander_scanned_gcd_audit(result)
    normalization = multivariable_alexander_admissible_minor_normalization_audit(
        result
    )
    evidence = multivariable_alexander_input_certification_evidence(
        scanned,
        None,
        normalization,
    )

    summary = evidence[
        "bounded_admissible_minor_normalization_blocker_witness_summary"
    ]

    assert scanned["candidate_is_exact_scanned_gcd"] is False
    assert scanned["quotient_gcd_uncertainty_evidence"]["status"] == "not_certified"
    assert normalization["bounded_admissible_minor_normalization_certified"] is False
    assert summary["blockers"] == [
        "candidate_not_exact_scanned_gcd",
        "quotient_gcd_uncertified",
        "failed_nonzero_minor_normalization",
        "normalization_class_not_unique",
        "normalization_mismatch_witnesses_present",
    ]
    assert summary["blocker_reason_counts"] == {
        "scanned_gcd_not_exact": 1,
        "quotient_uncertainty": 1,
        "nonunique_class": 3,
    }
    _assert_blocker_witness_summary_consistency(
        summary,
        witness_available=True,
        missing_witness_reasons=[],
        blocker_reason_counts={
            "scanned_gcd_not_exact": 1,
            "quotient_uncertainty": 1,
            "nonunique_class": 3,
        },
    )
    assert summary["blocker_witness_source_counts_by_reason"] == {
        "scanned_gcd_not_exact": 1,
        "quotient_uncertainty": 1,
        "nonunique_class": 3,
    }
    assert summary[
        "blocker_witness_source_available_counts_by_reason"
    ] == {
        "quotient_uncertainty": 1,
        "nonunique_class": 3,
    }
    assert summary["blocker_witness_source_missing_counts_by_reason"] == {
        "scanned_gcd_not_exact": 1,
    }
    rows = {row["blocker"]: row for row in summary["blocker_witness_sources"]}
    assert rows["candidate_not_exact_scanned_gcd"] == {
        "blocker": "candidate_not_exact_scanned_gcd",
        "reason_code": "scanned_gcd_not_exact",
        "available": False,
        "source_blocker": None,
        "source_reason_code": None,
        "source_field": None,
        "source_detail_field": None,
        "witness_kind": None,
        "missing_reason": "no_reusable_locator_witness",
        "source_matches_blocker": False,
        "source_reason_matches_blocker_reason": False,
        "source_provenance_consistent": True,
    }
    assert rows["quotient_gcd_uncertified"]["available"] is True
    assert rows["quotient_gcd_uncertified"]["witness_kind"] == (
        "quotient_polynomial"
    )
    assert rows["failed_nonzero_minor_normalization"]["source_detail_field"] == (
        "blocker_details.failed_nonzero_minor_normalization."
        "failed_minor_indices"
    )
    assert all(
        rows[blocker]["source_matches_blocker"]
        and rows[blocker]["source_reason_matches_blocker_reason"]
        for blocker in (
            "quotient_gcd_uncertified",
            "failed_nonzero_minor_normalization",
            "normalization_class_not_unique",
            "normalization_mismatch_witnesses_present",
        )
    )
    assert evidence["full_admissible_minor_normalization_certified"] is False
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_input_certification_normalizes_stale_witness_counts() -> None:
    failed_witness = {
        "minor_index": 3,
        "rows": [0],
        "columns": [1],
        "minor_polynomial": "1 - t1",
        "divisible": False,
        "quotient_polynomial": None,
    }
    scanned = {
        "method": "multivariable_alexander_scanned_gcd_audit",
        "source_method": "legacy_stale_scanned_gcd_audit",
        "multivariable_alexander_polynomial": "1 + t1",
        "variables": ["t1"],
        "candidate_polynomials": ["1 - t1"],
        "candidate_is_exact_scanned_gcd": False,
        "complete_scanned_gcd_certified": False,
        "quotient_gcd_certified": False,
        "quotient_gcd_polynomial": None,
        "quotient_gcd_method": None,
        "quotient_gcd_uncertainty_evidence": {
            "method": "fox_square_minor_quotient_gcd_uncertainty_evidence",
            "status": "not_certified",
            "certified": False,
            "quotient_polynomial_count": 99,
            "unique_quotient_polynomial_count": 88,
            "quotient_polynomials": ["1 + t1", "1 + t1", "1 + t1^2"],
            "full_admissible_minor_normalization_certified": True,
            "full_invariant_certified": True,
        },
        "checked_nonzero_minor_count": 1,
        "failed_nonzero_minor_count": 1,
        "failed_minor_indices": [3],
        "failed_division_witness_count": 99,
        "failed_division_witness_limit": 8,
        "failed_division_witness_truncated": False,
        "failed_division_witnesses": [failed_witness],
        "division_records": [failed_witness],
        "admissible_minor_summary": {
            "expected_combination_count": 1,
            "scanned_minor_count": 1,
            "nonzero_minor_count": 1,
            "zero_minor_count": 0,
            "unit_minor_count": 0,
            "unique_nonzero_polynomial_count": 1,
            "complete_combination_scan": True,
            "nonzero_minor_coverage_complete": True,
            "all_rows_have_nonzero_minor": True,
            "all_columns_have_nonzero_minor": True,
        },
        "complete_combination_scan": True,
        "truncated": False,
        "skipped": False,
        "notes": ["legacy payload with stale nested counts"],
    }

    evidence = multivariable_alexander_input_certification_evidence(scanned)

    assert evidence["certification_blocker_count"] == len(
        evidence["certification_blockers"]
    )
    assert evidence["failed_division_witness_count"] == len(
        evidence["failed_division_witnesses"]
    )
    assert evidence["failed_division_witness_count"] == 1
    _assert_bounded_witness_consistency(
        evidence["failed_division_witness_consistency"],
        witness_kind="failed_division",
        witness_count=1,
        witness_list_count=1,
        witness_limit=8,
        witness_truncated=False,
    )
    failed_detail = evidence["certification_blocker_details"][
        "failed_nonzero_minor_division"
    ]
    assert failed_detail["failed_division_witness_count"] == len(
        failed_detail["failed_division_witnesses"]
    )
    assert failed_detail["failed_division_witness_count"] == 1
    assert failed_detail["failed_division_witnesses"] == (
        evidence["failed_division_witnesses"]
    )
    assert failed_detail["failed_division_witness_consistency"] == (
        evidence["failed_division_witness_consistency"]
    )

    uncertainty = evidence["quotient_gcd_uncertainty_evidence"]
    assert uncertainty["quotient_polynomial_count"] == len(
        uncertainty["quotient_polynomials"]
    )
    assert uncertainty["unique_quotient_polynomial_count"] == len(
        set(uncertainty["quotient_polynomials"])
    )
    assert uncertainty["quotient_polynomial_count"] == 3
    assert uncertainty["unique_quotient_polynomial_count"] == 2
    assert uncertainty["variables"] == ["t1"]
    assert uncertainty["quotient_polynomial_count_consistency"][
        "count_list_consistent"
    ] is True
    assert uncertainty["first_quotient_polynomial_witness"] == {
        "quotient_index": 0,
        "quotient_polynomial": "1 + t1",
        "quotient_term_count": 2,
        "variable_support": ["t1"],
    }
    _assert_bounded_witness_consistency(
        uncertainty["quotient_polynomial_witness_consistency"],
        witness_kind="quotient_polynomial",
        witness_count=3,
        witness_list_count=3,
        witness_limit=8,
        witness_truncated=False,
    )
    assert uncertainty["full_admissible_minor_normalization_certified"] is False
    assert uncertainty["full_invariant_certified"] is False
    uncertainty_detail = evidence["certification_blocker_details"][
        "quotient_gcd_uncertified"
    ]
    assert uncertainty_detail["quotient_gcd_uncertainty_present"] is True
    assert uncertainty_detail["quotient_gcd_uncertainty_evidence"] == uncertainty
    assert evidence["full_admissible_minor_normalization_certified"] is False
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_improves_scanned_gcd_result_from_audit() -> None:
    variables = ("t1", "t2")
    divisor = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): -1,
        },
        variables=variables,
    )
    common_quotient = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): -1,
        },
        variables=variables,
    )
    extra = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): -1,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan(
        [divisor * common_quotient, divisor * common_quotient * extra],
        variables=variables,
    )

    source_result = {
        "multivariable_alexander_polynomial": divisor.format(),
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "method": "synthetic_nonmaximal_scanned_gcd_candidate",
        "presentation": {
            "variables": list(variables),
        },
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "common_gcd_evidence": {
            "method": "synthetic_weak_common_gcd",
            "full_admissible_minor_normalization_certified": False,
            "full_invariant_certified": False,
        },
        "notes": ["synthetic non-maximal scanned gcd candidate"],
    }
    improvement = multivariable_alexander_improve_scanned_gcd_result(source_result)

    assert improvement["skipped"] is False
    assert improvement["improved"] is True
    assert improvement["accepted"] is True
    assert improvement["source_audit"]["candidate_is_exact_scanned_gcd"] is False
    assert improvement["source_audit"]["improved_candidate_polynomial"] == (
        "1 - t2 - t1 + t1*t2"
    )
    assert improvement["improved_candidate_polynomial"] == "1 - t2 - t1 + t1*t2"

    improved_result = improvement["result"]
    assert improved_result["method"] == (
        "synthetic_nonmaximal_scanned_gcd_candidate_improved_by_scanned_quotient_gcd"
    )
    assert (
        improved_result["source_multivariable_alexander_polynomial"]
        == divisor.format()
    )
    assert (
        improved_result["multivariable_alexander_polynomial"]
        == "1 - t2 - t1 + t1*t2"
    )
    assert "common_gcd_evidence" not in improved_result
    assert improved_result["source_common_gcd_evidence"]["method"] == (
        "synthetic_weak_common_gcd"
    )
    promotion = improved_result["scanned_gcd_improvement_evidence"]
    assert promotion["method"] == "bounded_scanned_gcd_candidate_promotion"
    assert promotion["source_polynomial"] == divisor.format()
    assert promotion["improved_candidate_polynomial"] == "1 - t2 - t1 + t1*t2"
    assert promotion["quotient_gcd_certified"] is True
    assert promotion["candidate_is_exact_scanned_gcd_before_promotion"] is False
    assert promotion["full_admissible_minor_normalization_certified"] is False
    assert promotion["full_invariant_certified"] is False

    improved_audit = improvement["improved_audit"]
    assert improved_audit["candidate_is_exact_scanned_gcd"] is True
    assert improved_audit["complete_scanned_gcd_certified"] is True
    assert improved_audit["quotient_gcd_certified"] is True
    assert improved_audit["quotient_gcd_polynomial"] == "1"
    assert improved_audit["improved_candidate_polynomial"] is None
    assert improved_audit["failed_nonzero_minor_count"] == 0


def test_multivariable_alexander_gcd_from_presentation_promotes_scanned_quotient_gcd(
    monkeypatch,
) -> None:
    variables = ("t1", "t2")
    divisor = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): -1,
        },
        variables=variables,
    )
    common_quotient = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): -1,
        },
        variables=variables,
    )
    extra = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): -1,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan(
        [divisor * common_quotient, divisor * common_quotient * extra],
        variables=variables,
    )
    presentation = WirtingerPresentation(
        relations=(((0, 1),), ((1, 1),)),
        generator_components=(0, 1),
        variables=variables,
        source="synthetic_promoted_scanned_gcd",
    )
    original_common_gcd = (
        alexander_module._conservative_common_gcd_with_evidence_from_minors
    )
    calls = {"count": 0}

    def weak_first_common_gcd(minors, *, variables):
        if calls["count"] == 0:
            calls["count"] += 1
            return (
                divisor,
                "synthetic_weak_common_gcd",
                "synthetic weak bounded common divisor",
                {
                    "method": "synthetic_weak_common_gcd",
                    "full_admissible_minor_normalization_certified": False,
                    "full_invariant_certified": False,
                },
            )
        calls["count"] += 1
        return original_common_gcd(minors, variables=variables)

    monkeypatch.setattr(
        alexander_module,
        "fox_square_minors_from_presentation",
        lambda *args, **kwargs: deepcopy(scan),
    )
    monkeypatch.setattr(
        alexander_module,
        "_conservative_common_gcd_with_evidence_from_minors",
        weak_first_common_gcd,
    )

    result = multivariable_alexander_gcd_from_presentation(
        presentation,
        max_matrix_size=1,
        max_minors=2,
    )

    assert result["multivariable_alexander_polynomial"] == "1 - t2 - t1 + t1*t2"
    assert result["method"] == "synthetic_weak_common_gcd_improved_by_scanned_quotient_gcd"
    assert result["source_multivariable_alexander_polynomial"] == divisor.format()
    assert "common_gcd_evidence" not in result
    assert result["source_common_gcd_evidence"]["method"] == "synthetic_weak_common_gcd"
    promotion = result["scanned_gcd_improvement_evidence"]
    assert promotion["accepted"] is True
    assert promotion["candidate_is_exact_scanned_gcd_after_promotion"] is True
    assert promotion["full_admissible_minor_normalization_certified"] is False
    assert promotion["full_invariant_certified"] is False

    audit = multivariable_alexander_scanned_gcd_audit(result)
    assert audit["candidate_is_exact_scanned_gcd"] is True
    assert audit["complete_scanned_gcd_certified"] is True
    assert audit["improved_candidate_polynomial"] is None
    assert audit["scanned_gcd_promoted_candidate"] is True
    assert audit["scanned_gcd_promoted_candidate_count"] == 1
    assert audit["scanned_gcd_improvement_evidence"] == promotion
    assert audit["source_common_gcd_evidence"]["method"] == "synthetic_weak_common_gcd"
    assert audit["full_invariant_certified"] is False

    evidence = multivariable_alexander_input_certification_evidence(audit)
    assert evidence["bounded_scanned_gcd_certified"] is True
    assert evidence["scanned_gcd_promoted_candidate"] is True
    assert evidence["scanned_gcd_promoted_candidate_count"] == 1
    assert evidence["scanned_gcd_improvement_evidence"] == promotion
    assert evidence["source_common_gcd_evidence"]["method"] == "synthetic_weak_common_gcd"
    assert evidence["improved_candidate_polynomial"] is None
    assert evidence["full_admissible_minor_normalization_certified"] is False
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_detects_common_integer_content() -> None:
    variables = ("t1", "t2")
    first = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 2,
            (1, 0): 2,
        },
        variables=variables,
    )
    second = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 4,
            (0, 1): 4,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_from_minors(
        [
            _synthetic_minor(first),
            _synthetic_minor(second),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note = result
    assert method == "fox_square_minor_integer_content_gcd"
    assert polynomial.format() == "2"
    assert "integer coefficient content" in note


def test_multivariable_alexander_scanned_gcd_audit_accepts_integer_content_gcd() -> None:
    variables = ("t1", "t2")
    first = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 2,
            (1, 0): 2,
        },
        variables=variables,
    )
    second = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 4,
            (0, 1): 4,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan([first, second], variables=variables)
    result = {
        "multivariable_alexander_polynomial": "2",
        "candidate_polynomials": [first.format(), second.format()],
        "method": "fox_square_minor_integer_content_gcd",
        "presentation": {
            "variables": list(variables),
        },
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic integer-content gcd"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)

    assert audit["skipped"] is False
    assert audit["source_method"] == "fox_square_minor_integer_content_gcd"
    assert audit["candidate_is_exact_scanned_gcd"] is True
    assert audit["complete_scanned_gcd_certified"] is True
    assert audit["quotient_gcd_polynomial"] == "1"
    assert audit["quotient_gcd_method"] == "fox_square_minor_disjoint_support_gcd"
    assert audit["checked_nonzero_minor_count"] == 2
    assert audit["failed_nonzero_minor_count"] == 0
    assert audit["full_invariant_certified"] is False


def test_multivariable_alexander_scanned_gcd_audit_reports_improved_candidate() -> None:
    variables = ("t1", "t2")
    divisor = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): -1,
        },
        variables=variables,
    )
    common_quotient = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): -1,
        },
        variables=variables,
    )
    extra = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): -1,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan(
        [divisor * common_quotient, divisor * common_quotient * extra],
        variables=variables,
    )
    result = {
        "multivariable_alexander_polynomial": divisor.format(),
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "method": "synthetic_nonmaximal_scanned_gcd_candidate",
        "presentation": {
            "variables": list(variables),
        },
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "common_gcd_evidence": {
            "method": "synthetic_weak_common_gcd",
            "full_admissible_minor_normalization_certified": False,
            "full_invariant_certified": False,
        },
        "notes": ["synthetic non-maximal scanned gcd candidate"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)

    assert audit["skipped"] is False
    assert audit["candidate_is_exact_scanned_gcd"] is False
    assert audit["complete_scanned_gcd_certified"] is False
    assert audit["quotient_gcd_certified"] is True
    assert audit["quotient_gcd_polynomial"] == "1 - t2"
    assert audit["quotient_gcd_method"] == "fox_square_minor_multivariate_divisor_gcd"
    assert audit["improved_candidate_polynomial"] == "1 - t2 - t1 + t1*t2"
    assert audit["checked_nonzero_minor_count"] == 2
    assert audit["failed_nonzero_minor_count"] == 0
    assert audit["failed_minor_indices"] == []
    assert {record["quotient_polynomial"] for record in audit["division_records"]} == {
        "1 - t2",
        "1 - t2 - t1 + t1*t2",
    }
    quotient_evidence = audit["quotient_gcd_evidence"]
    assert quotient_evidence["candidate_polynomial"] == "1 - t2"
    assert quotient_evidence["divides_all_inputs"] is True
    assert quotient_evidence["failed_input_indices"] == []
    assert quotient_evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert quotient_evidence["quotient_common_factor_certified"] is True
    assert quotient_evidence["quotient_common_factor_method"] == (
        "quotient_unit_witness_gcd"
    )
    assert quotient_evidence["quotient_common_factor_status"][
        "quotient_unit_witness_count"
    ] == 1
    assert "not maximal" in audit["notes"][1]
    assert audit["full_invariant_certified"] is False


def test_multivariable_alexander_scanned_gcd_audit_reports_root_binomial_improvement() -> None:
    variables = ("t1", "t2", "t3")
    divisor = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): -1,
        },
        variables=variables,
    )
    hidden_common = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 1,
            (0, 1, 0): -1,
        },
        variables=variables,
    )
    hidden_square = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 1,
            (0, 1, 0): 1,
        },
        variables=variables,
    )
    hidden_extra = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 1,
            (0, 1, 0): 2,
        },
        variables=variables,
    )
    off_axis_extra = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): 1,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan(
        [
            divisor * hidden_common * hidden_square,
            divisor * hidden_common * hidden_extra * off_axis_extra,
        ],
        variables=variables,
    )
    result = {
        "multivariable_alexander_polynomial": divisor.format(),
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "method": "synthetic_nonmaximal_root_binomial_candidate",
        "presentation": {
            "variables": list(variables),
        },
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic non-maximal root-binomial candidate"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)

    assert audit["skipped"] is False
    assert audit["candidate_is_exact_scanned_gcd"] is False
    assert audit["quotient_gcd_certified"] is True
    assert (
        audit["quotient_gcd_method"]
        == "fox_square_minor_multivariate_root_binomial_factor_gcd"
    )
    assert audit["quotient_gcd_polynomial"] == "t2 - t1"
    assert audit["improved_candidate_polynomial"] == (
        "t2 - t2*t3 - t1 + t1*t3"
    )
    quotient_evidence = audit["quotient_gcd_evidence"]
    assert quotient_evidence["candidate_method"] == (
        "fox_square_minor_multivariate_root_binomial_factor_gcd"
    )
    assert quotient_evidence["candidate_polynomial"] == "t2 - t1"
    assert quotient_evidence["divides_all_inputs"] is True
    assert quotient_evidence["candidate_is_exact_gcd_for_inputs"] is False
    assert audit["full_invariant_certified"] is False


def test_multivariable_alexander_scanned_gcd_audit_reports_cubic_root_binomial_improvement() -> None:
    variables = ("t1", "t2", "t3")
    divisor = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): -1,
        },
        variables=variables,
    )
    hidden_common = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 1,
            (0, 1, 0): -1,
        },
        variables=variables,
    )
    cubic_complement = MultivariateLaurentPolynomial.from_dict(
        {
            (2, 0, 0): 1,
            (1, 1, 0): 1,
            (0, 2, 0): 1,
        },
        variables=variables,
    )
    hidden_extra = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 1,
            (0, 1, 0): 2,
        },
        variables=variables,
    )
    off_axis_extra = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): 1,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan(
        [
            divisor * hidden_common * cubic_complement,
            divisor * hidden_common * hidden_extra * off_axis_extra,
        ],
        variables=variables,
    )
    result = {
        "multivariable_alexander_polynomial": divisor.format(),
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "method": "synthetic_nonmaximal_cubic_root_binomial_candidate",
        "presentation": {
            "variables": list(variables),
        },
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic non-maximal cubic root-binomial candidate"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)

    assert audit["skipped"] is False
    assert audit["candidate_is_exact_scanned_gcd"] is False
    assert audit["quotient_gcd_certified"] is True
    assert (
        audit["quotient_gcd_method"]
        == "fox_square_minor_multivariate_root_binomial_factor_gcd"
    )
    assert audit["quotient_gcd_polynomial"] == "t2 - t1"
    assert audit["improved_candidate_polynomial"] == (
        "t2 - t2*t3 - t1 + t1*t3"
    )
    quotient_evidence = audit["quotient_gcd_evidence"]
    assert quotient_evidence["candidate_polynomial"] == "t2 - t1"
    assert quotient_evidence["divides_all_inputs"] is True
    assert audit["full_invariant_certified"] is False


def test_multivariable_alexander_scanned_gcd_audit_reports_scaled_root_binomial_improvement() -> None:
    variables = ("t1", "t2", "t3", "t4")
    divisor = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0, 0): 1,
            (0, 0, 0, 1): -1,
        },
        variables=variables,
    )
    hidden_common = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0, 0): 1,
            (0, 1, 0, 0): -2,
        },
        variables=variables,
    )
    scaled_complement = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0, 0): 1,
            (0, 1, 0, 0): 2,
        },
        variables=variables,
    )
    scaled_extra = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0, 0): 1,
            (0, 1, 0, 0): 3,
        },
        variables=variables,
    )
    off_axis_positive = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0, 0): 1,
            (0, 0, 1, 0): 1,
        },
        variables=variables,
    )
    off_axis_negative = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0, 0): 1,
            (0, 0, 1, 0): -1,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan(
        [
            divisor * hidden_common * scaled_complement * off_axis_positive,
            divisor * hidden_common * scaled_extra * off_axis_negative,
        ],
        variables=variables,
    )
    result = {
        "multivariable_alexander_polynomial": divisor.format(),
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "method": "synthetic_nonmaximal_scaled_root_binomial_candidate",
        "presentation": {
            "variables": list(variables),
        },
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic non-maximal scaled root-binomial candidate"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)

    assert audit["skipped"] is False
    assert audit["candidate_is_exact_scanned_gcd"] is False
    assert audit["quotient_gcd_certified"] is True
    assert (
        audit["quotient_gcd_method"]
        == "fox_square_minor_multivariate_root_binomial_factor_gcd"
    )
    assert audit["quotient_gcd_polynomial"] == "2t2 - t1"
    assert audit["improved_candidate_polynomial"] == (
        "2t2 - 2*t2*t4 - t1 + t1*t4"
    )
    quotient_evidence = audit["quotient_gcd_evidence"]
    assert quotient_evidence["candidate_polynomial"] == "2t2 - t1"
    assert quotient_evidence["divides_all_inputs"] is True
    assert quotient_evidence["candidate_is_exact_gcd_for_inputs"] is False
    assert audit["full_invariant_certified"] is False


def test_multivariable_alexander_scanned_gcd_audit_reports_weighted_root_binomial_improvement() -> None:
    variables = ("t1", "t2", "t3")
    divisor = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): -1,
        },
        variables=variables,
    )
    hidden_common = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 2,
            (0, 1, 0): -3,
        },
        variables=variables,
    )
    weighted_cubic_complement = MultivariateLaurentPolynomial.from_dict(
        {
            (2, 0, 0): 4,
            (1, 1, 0): 6,
            (0, 2, 0): 9,
        },
        variables=variables,
    )
    hidden_extra = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 1,
            (0, 1, 0): 2,
        },
        variables=variables,
    )
    off_axis_extra = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): 1,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan(
        [
            divisor * hidden_common * weighted_cubic_complement,
            divisor * hidden_common * hidden_extra * off_axis_extra,
        ],
        variables=variables,
    )
    result = {
        "multivariable_alexander_polynomial": divisor.format(),
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "method": "synthetic_nonmaximal_weighted_root_binomial_candidate",
        "presentation": {
            "variables": list(variables),
        },
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic non-maximal weighted root-binomial candidate"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)

    assert audit["skipped"] is False
    assert audit["candidate_is_exact_scanned_gcd"] is False
    assert audit["quotient_gcd_certified"] is True
    assert (
        audit["quotient_gcd_method"]
        == "fox_square_minor_multivariate_root_binomial_factor_gcd"
    )
    assert audit["quotient_gcd_polynomial"] == "3t2 - 2t1"
    assert audit["improved_candidate_polynomial"] == (
        divisor * hidden_common
    ).normalize_unit().format()
    quotient_evidence = audit["quotient_gcd_evidence"]
    assert quotient_evidence["candidate_polynomial"] == "3t2 - 2t1"
    assert quotient_evidence["divides_all_inputs"] is True
    assert audit["full_invariant_certified"] is False

def test_multivariable_alexander_detects_common_sparse_factor() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): 1,
        },
        variables=variables,
    )
    extra_t1 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (2, 0): 1,
        },
        variables=variables,
    )
    extra_t2 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 2): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_from_minors(
        [
            _synthetic_minor(common * extra_t1),
            _synthetic_minor(common * extra_t2),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note = result
    assert method == "fox_square_minor_multivariate_sparse_factor_gcd"
    assert polynomial.format() == "1 + t2 + t1"
    assert "bounded exact sparse-factor scan" in note


def test_multivariable_alexander_detects_hidden_sparse_cofactor_factor() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): 1,
        },
        variables=variables,
    )
    extra_t1 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): -1,
        },
        variables=variables,
    )
    extra_t2 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): -1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_from_minors(
        [
            _synthetic_minor(common * extra_t1),
            _synthetic_minor(common * extra_t2),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note = result
    assert method == "fox_square_minor_multivariate_cofactor_factor_gcd"
    assert polynomial.format() == "1 + t2 + t1"
    assert "bounded exact cofactor scan" in note


def test_multivariable_alexander_detects_nine_term_hidden_cofactor_factor() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 2,
            (0, 1): 1,
            (2, 0): 1,
            (0, 2): 3,
            (2, 1): 1,
            (1, 2): -1,
            (3, 0): 1,
            (0, 3): 1,
        },
        variables=variables,
    ).normalize_unit()
    extra_t1 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
        },
        variables=variables,
    )
    extra_t2 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * extra_t1),
            _synthetic_minor(common * extra_t2),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_cofactor_factor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 9
    assert "bounded exact cofactor scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_detects_two_step_hidden_cofactor_factor() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 2,
            (0, 1): 1,
            (2, 0): 1,
            (0, 2): 3,
            (2, 1): 1,
            (1, 2): -1,
            (3, 0): 1,
            (0, 3): 1,
        },
        variables=variables,
    ).normalize_unit()
    extra_t1 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
        },
        variables=variables,
    )
    extra_t2 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): 1,
        },
        variables=variables,
    )
    extra_t1_square = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (2, 0): 1,
        },
        variables=variables,
    )
    extra_t2_square = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 2): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * extra_t1 * extra_t2),
            _synthetic_minor(common * extra_t1_square * extra_t2_square),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_cofactor_factor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 9
    assert "bounded exact cofactor scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is False
    assert evidence["quotient_common_factor_certified"] is False
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_detects_seven_term_small_cofactor_peel() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 2,
            (2, 0): -1,
            (3, 0): 3,
            (4, 0): 5,
            (5, 0): -2,
            (6, 0): 7,
            (7, 0): 11,
        },
        variables=variables,
    ).normalize_unit()
    cofactor_a = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): 1,
            (0, 2): -1,
            (0, 3): 2,
            (0, 4): 1,
            (0, 5): -1,
            (0, 6): 1,
        },
        variables=variables,
    ).normalize_unit()
    cofactor_b = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): -2,
            (0, 2): 1,
            (0, 3): 1,
            (0, 4): 3,
            (0, 5): 1,
            (0, 6): -1,
        },
        variables=variables,
    ).normalize_unit()

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * cofactor_a),
            _synthetic_minor(common * cofactor_b),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_cofactor_factor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 8
    assert len(cofactor_a.terms) == 7
    assert len(cofactor_b.terms) == 7
    assert "bounded exact cofactor scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["quotient_common_factor_certified"] is True
    assert evidence["quotient_common_factor_is_unit"] is True
    assert evidence["full_invariant_certified"] is False



def test_multivariable_alexander_detects_eight_term_small_cofactor_peel() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (10, 0): 2,
            (11, 0): -1,
            (12, 0): 3,
            (13, 0): 5,
            (14, 0): -2,
            (15, 0): 7,
            (16, 0): 11,
            (17, 0): -3,
        },
        variables=variables,
    ).normalize_unit()
    cofactor_a = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): 1,
            (0, 2): -1,
            (0, 3): 2,
            (0, 4): 1,
            (0, 5): -1,
            (0, 6): 1,
            (0, 7): 3,
        },
        variables=variables,
    ).normalize_unit()
    cofactor_b = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): -2,
            (0, 2): 1,
            (0, 3): 1,
            (0, 4): 3,
            (0, 5): 1,
            (0, 6): -1,
            (0, 7): 2,
        },
        variables=variables,
    ).normalize_unit()

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * cofactor_a),
            _synthetic_minor(common * cofactor_b),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_cofactor_factor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 9
    assert len(cofactor_a.terms) == 8
    assert len(cofactor_b.terms) == 8
    assert "bounded exact cofactor scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["quotient_common_factor_certified"] is True
    assert evidence["quotient_common_factor_is_unit"] is True
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_detects_nine_term_small_cofactor_peel() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (20, 0): 1,
            (21, 0): 2,
            (22, 0): -1,
            (23, 0): 3,
            (24, 0): 5,
            (25, 0): -2,
            (26, 0): 7,
            (27, 0): 11,
            (28, 0): -3,
            (29, 0): 13,
        },
        variables=variables,
    ).normalize_unit()
    cofactor_a = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): 1,
            (0, 2): -1,
            (0, 3): 2,
            (0, 4): 1,
            (0, 5): -1,
            (0, 6): 1,
            (0, 7): 3,
            (0, 8): -2,
        },
        variables=variables,
    ).normalize_unit()
    cofactor_b = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): -2,
            (0, 2): 1,
            (0, 3): 1,
            (0, 4): 3,
            (0, 5): 1,
            (0, 6): -1,
            (0, 7): 2,
            (0, 8): 4,
        },
        variables=variables,
    ).normalize_unit()

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * cofactor_a),
            _synthetic_minor(common * cofactor_b),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_cofactor_factor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 10
    assert len(cofactor_a.terms) == 9
    assert len(cofactor_b.terms) == 9
    assert "bounded exact cofactor scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["quotient_common_factor_certified"] is True
    assert evidence["quotient_common_factor_is_unit"] is True
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_detects_ten_term_small_cofactor_peel() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (20, 0): 1,
            (21, 0): 2,
            (22, 0): -1,
            (23, 0): 3,
            (24, 0): 5,
            (25, 0): -2,
            (26, 0): 7,
            (27, 0): 11,
            (28, 0): -3,
            (29, 0): 13,
            (30, 0): -5,
        },
        variables=variables,
    ).normalize_unit()
    cofactor_a = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): 1,
            (0, 2): -1,
            (0, 3): 2,
            (0, 4): 1,
            (0, 5): -1,
            (0, 6): 1,
            (0, 7): 3,
            (0, 8): -2,
            (0, 9): 5,
        },
        variables=variables,
    ).normalize_unit()
    cofactor_b = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): -2,
            (0, 2): 1,
            (0, 3): 1,
            (0, 4): 3,
            (0, 5): 1,
            (0, 6): -1,
            (0, 7): 2,
            (0, 8): 4,
            (0, 9): -3,
        },
        variables=variables,
    ).normalize_unit()

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * cofactor_a),
            _synthetic_minor(common * cofactor_b),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_cofactor_factor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 11
    assert len(cofactor_a.terms) == 10
    assert len(cofactor_b.terms) == 10
    assert "bounded exact cofactor scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["quotient_common_factor_certified"] is True
    assert evidence["quotient_common_factor_is_unit"] is True
    assert evidence["full_invariant_certified"] is False



def test_multivariable_alexander_detects_twelve_term_small_cofactor_peel() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (20, 0): 1,
            (21, 0): 2,
            (22, 0): -1,
            (23, 0): 3,
            (24, 0): 5,
            (25, 0): -2,
            (26, 0): 7,
            (27, 0): 11,
            (28, 0): -3,
            (29, 0): 13,
            (30, 0): -5,
            (31, 0): 17,
        },
        variables=variables,
    ).normalize_unit()
    cofactor_a = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): 1,
            (0, 2): -1,
            (0, 3): 2,
            (0, 4): 1,
            (0, 5): -1,
            (0, 6): 1,
            (0, 7): 3,
            (0, 8): -2,
            (0, 9): 5,
            (0, 10): -3,
            (0, 11): 7,
        },
        variables=variables,
    ).normalize_unit()
    cofactor_b = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): -2,
            (0, 2): 1,
            (0, 3): 1,
            (0, 4): 3,
            (0, 5): 1,
            (0, 6): -1,
            (0, 7): 2,
            (0, 8): 4,
            (0, 9): -3,
            (0, 10): 5,
            (0, 11): -7,
        },
        variables=variables,
    ).normalize_unit()

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * cofactor_a),
            _synthetic_minor(common * cofactor_b),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_cofactor_factor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 12
    assert len(cofactor_a.terms) == 12
    assert len(cofactor_b.terms) == 12
    assert "bounded exact cofactor scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["quotient_common_factor_certified"] is True
    assert evidence["quotient_common_factor_is_unit"] is True
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_detects_fourteen_term_small_cofactor_peel() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (40, 0): 1,
            (41, 0): 2,
            (42, 0): -1,
            (43, 0): 3,
            (44, 0): 5,
            (45, 0): -2,
            (46, 0): 7,
            (47, 0): 11,
            (48, 0): -3,
            (49, 0): 13,
            (50, 0): -5,
            (51, 0): 17,
            (52, 0): -7,
            (53, 0): 19,
        },
        variables=variables,
    ).normalize_unit()
    cofactor_a = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): 1,
            (0, 2): -1,
            (0, 3): 2,
            (0, 4): 1,
            (0, 5): -1,
            (0, 6): 1,
            (0, 7): 3,
            (0, 8): -2,
            (0, 9): 5,
            (0, 10): -3,
            (0, 11): 7,
            (0, 12): -5,
            (0, 13): 11,
        },
        variables=variables,
    ).normalize_unit()
    cofactor_b = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 1): -2,
            (0, 2): 1,
            (0, 3): 1,
            (0, 4): 3,
            (0, 5): 1,
            (0, 6): -1,
            (0, 7): 2,
            (0, 8): 4,
            (0, 9): -3,
            (0, 10): 5,
            (0, 11): -7,
            (0, 12): 9,
            (0, 13): -11,
        },
        variables=variables,
    ).normalize_unit()

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * cofactor_a),
            _synthetic_minor(common * cofactor_b),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_cofactor_factor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 14
    assert len(cofactor_a.terms) == 14
    assert len(cofactor_b.terms) == 14
    assert "bounded exact cofactor scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["quotient_common_factor_certified"] is True
    assert evidence["quotient_common_factor_is_unit"] is True
    assert evidence["full_invariant_certified"] is False
def test_multivariable_alexander_scanned_gcd_audit_reports_two_step_cofactor_improvement() -> None:
    variables = ("t1", "t2", "t3")
    divisor = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): -1,
        },
        variables=variables,
    )
    hidden_common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (1, 0, 0): 2,
            (0, 1, 0): 1,
            (2, 0, 0): 1,
            (0, 2, 0): 3,
            (2, 1, 0): 1,
            (1, 2, 0): -1,
            (3, 0, 0): 1,
            (0, 3, 0): 1,
        },
        variables=variables,
    ).normalize_unit()
    extra_t1 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (1, 0, 0): 1,
        },
        variables=variables,
    )
    extra_t2 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 1, 0): 1,
        },
        variables=variables,
    )
    extra_t1_square = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (2, 0, 0): 1,
        },
        variables=variables,
    )
    extra_t2_square = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 2, 0): 1,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan(
        [
            divisor * hidden_common * extra_t1 * extra_t2,
            divisor * hidden_common * extra_t1_square * extra_t2_square,
        ],
        variables=variables,
    )
    result = {
        "multivariable_alexander_polynomial": divisor.format(),
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "method": "synthetic_nonmaximal_two_step_cofactor_candidate",
        "presentation": {
            "variables": list(variables),
        },
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic non-maximal two-step cofactor candidate"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)

    assert audit["skipped"] is False
    assert audit["candidate_is_exact_scanned_gcd"] is False
    assert audit["quotient_gcd_certified"] is True
    assert (
        audit["quotient_gcd_method"]
        == "fox_square_minor_multivariate_cofactor_factor_gcd"
    )
    assert audit["quotient_gcd_polynomial"] == hidden_common.format()
    assert audit["improved_candidate_polynomial"] == (
        divisor * hidden_common
    ).normalize_unit().format()
    quotient_evidence = audit["quotient_gcd_evidence"]
    assert quotient_evidence["candidate_method"] == (
        "fox_square_minor_multivariate_cofactor_factor_gcd"
    )
    assert quotient_evidence["candidate_polynomial"] == hidden_common.format()
    assert quotient_evidence["divides_all_inputs"] is True
    assert quotient_evidence["candidate_is_exact_gcd_for_inputs"] is False
    assert audit["full_invariant_certified"] is False

def test_multivariable_alexander_scanned_gcd_audit_reports_cofactor_improvement() -> None:
    variables = ("t1", "t2", "t3")
    divisor = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): -1,
        },
        variables=variables,
    )
    hidden_common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (1, 0, 0): 1,
            (0, 1, 0): 1,
        },
        variables=variables,
    )
    extra_t1 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (1, 0, 0): -1,
        },
        variables=variables,
    )
    extra_t2 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 1, 0): -1,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan(
        [
            divisor * hidden_common * extra_t1,
            divisor * hidden_common * extra_t2,
        ],
        variables=variables,
    )
    result = {
        "multivariable_alexander_polynomial": divisor.format(),
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "method": "synthetic_nonmaximal_cofactor_candidate",
        "presentation": {
            "variables": list(variables),
        },
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic non-maximal cofactor candidate"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)

    assert audit["skipped"] is False
    assert audit["candidate_is_exact_scanned_gcd"] is False
    assert audit["quotient_gcd_certified"] is True
    assert (
        audit["quotient_gcd_method"]
        == "fox_square_minor_multivariate_cofactor_factor_gcd"
    )
    assert audit["quotient_gcd_polynomial"] == "1 + t2 + t1"
    assert audit["improved_candidate_polynomial"] == (
        "1 - t3 + t2 - t2*t3 + t1 - t1*t3"
    )
    quotient_evidence = audit["quotient_gcd_evidence"]
    assert quotient_evidence["candidate_method"] == (
        "fox_square_minor_multivariate_cofactor_factor_gcd"
    )
    assert quotient_evidence["candidate_polynomial"] == "1 + t2 + t1"
    assert quotient_evidence["divides_all_inputs"] is True
    assert quotient_evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert audit["full_invariant_certified"] is False


def test_multivariable_alexander_detects_rank_one_monomial_gcd() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 1): -1,
        },
        variables=variables,
    )
    companion = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 1): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_from_minors(
        [
            _synthetic_minor(common * common),
            _synthetic_minor(common * companion),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note = result
    assert method == "fox_square_minor_rank_one_monomial_gcd"
    assert polynomial.format() == "1 - t1*t2"
    assert "monomial exponent axis [1,1]" in note


def test_multivariable_alexander_scanned_gcd_audit_accepts_rank_one_gcd() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 1): -1,
        },
        variables=variables,
    )
    companion = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 1): 1,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan(
        [
            common * common,
            common * companion,
        ],
        variables=variables,
    )
    result = {
        "multivariable_alexander_polynomial": common.format(),
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "method": "fox_square_minor_rank_one_monomial_gcd",
        "presentation": {
            "variables": list(variables),
        },
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic rank-one monomial gcd"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)

    assert audit["skipped"] is False
    assert audit["source_method"] == "fox_square_minor_rank_one_monomial_gcd"
    assert audit["candidate_is_exact_scanned_gcd"] is True
    assert audit["complete_scanned_gcd_certified"] is True
    assert audit["quotient_gcd_certified"] is True
    assert audit["quotient_gcd_polynomial"] == "1"
    assert audit["failed_nonzero_minor_count"] == 0


def test_multivariable_alexander_detects_five_term_sparse_factor() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): 1,
            (2, 1): 1,
            (1, 2): 1,
        },
        variables=variables,
    ).normalize_unit()
    extra_t1 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (3, 0): 1,
        },
        variables=variables,
    )
    extra_t2 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 3): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_from_minors(
        [
            _synthetic_minor(common * extra_t1),
            _synthetic_minor(common * extra_t2),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note = result
    assert method == "fox_square_minor_multivariate_sparse_factor_gcd"
    assert polynomial.format() == common.format()
    assert "bounded exact sparse-factor scan" in note


def test_multivariable_alexander_detects_six_term_sparse_factor() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): 1,
            (2, 0): 2,
            (0, 2): 1,
            (1, 2): -1,
        },
        variables=variables,
    ).normalize_unit()
    extra_t1 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (4, 0): 1,
        },
        variables=variables,
    )
    extra_t2 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 4): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * extra_t1),
            _synthetic_minor(common * extra_t2),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_sparse_factor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 6
    assert "bounded exact sparse-factor scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_detects_seven_term_sparse_factor() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): -1,
            (2, 0): 2,
            (0, 2): 1,
            (2, 1): -1,
            (1, 2): 1,
        },
        variables=variables,
    ).normalize_unit()
    extra_t1 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (5, 0): 1,
        },
        variables=variables,
    )
    extra_t2 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 5): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * extra_t1),
            _synthetic_minor(common * extra_t2),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_sparse_factor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 7
    assert "bounded exact sparse-factor scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["full_invariant_certified"] is False



def test_multivariable_alexander_detects_eight_term_sparse_factor() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): -1,
            (2, 0): 2,
            (0, 2): 1,
            (2, 1): -1,
            (1, 2): 1,
            (3, 1): 2,
        },
        variables=variables,
    ).normalize_unit()
    extra_t1 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (6, 0): 1,
        },
        variables=variables,
    )
    extra_t2 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 6): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * extra_t1),
            _synthetic_minor(common * extra_t2),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_sparse_factor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 8
    assert "bounded exact sparse-factor scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["full_invariant_certified"] is False



def test_multivariable_alexander_detects_nine_term_sparse_factor() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): -1,
            (2, 0): 2,
            (0, 2): 1,
            (2, 1): -1,
            (1, 2): 1,
            (3, 1): 2,
            (1, 3): -2,
        },
        variables=variables,
    ).normalize_unit()
    extra_a = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (20, 0): 1,
        },
        variables=variables,
    )
    extra_b = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (21, 0): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * extra_a),
            _synthetic_minor(common * extra_b),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_sparse_factor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 9
    assert "bounded exact sparse-factor scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_detects_ten_term_sparse_factor() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): -1,
            (2, 0): 2,
            (0, 2): 1,
            (2, 1): -1,
            (1, 2): 1,
            (3, 1): 2,
            (1, 3): -2,
            (4, 0): 3,
        },
        variables=variables,
    ).normalize_unit()
    extra_a = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (30, 0): 1,
        },
        variables=variables,
    )
    extra_b = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (31, 0): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * extra_a),
            _synthetic_minor(common * extra_b),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_sparse_factor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 10
    assert "bounded exact sparse-factor scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_detects_twelve_term_sparse_factor() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): -1,
            (2, 0): 2,
            (0, 2): 1,
            (2, 1): -1,
            (1, 2): 1,
            (3, 1): 2,
            (1, 3): -2,
            (4, 0): 3,
            (0, 4): -3,
            (4, 2): 5,
        },
        variables=variables,
    ).normalize_unit()
    extra_a = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (40, 0): 1,
        },
        variables=variables,
    )
    extra_b = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (41, 0): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * extra_a),
            _synthetic_minor(common * extra_b),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_sparse_factor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 12
    assert "bounded exact sparse-factor scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_detects_fourteen_term_sparse_factor() -> None:
    variables = ("t1", "t2")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): -1,
            (2, 0): 2,
            (0, 2): 1,
            (2, 1): -1,
            (1, 2): 1,
            (3, 1): 2,
            (1, 3): -2,
            (4, 0): 3,
            (0, 4): -3,
            (4, 2): 5,
            (2, 4): -5,
            (5, 1): 7,
        },
        variables=variables,
    ).normalize_unit()
    extra_a = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (60, 0): 1,
        },
        variables=variables,
    )
    extra_b = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (61, 0): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * extra_a),
            _synthetic_minor(common * extra_b),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_sparse_factor_gcd"
    assert polynomial.format() == common.format()
    assert len(polynomial.terms) == 14
    assert "bounded exact sparse-factor scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == common.format()
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert evidence["full_invariant_certified"] is False
def test_multivariable_alexander_scanned_gcd_audit_reports_seven_term_sparse_improvement() -> None:
    variables = ("t1", "t2", "t3")
    divisor = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): -1,
        },
        variables=variables,
    )
    hidden_common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (1, 0, 0): 1,
            (0, 1, 0): -1,
            (2, 0, 0): 2,
            (0, 2, 0): 1,
            (2, 1, 0): -1,
            (1, 2, 0): 1,
        },
        variables=variables,
    ).normalize_unit()
    extra_t1 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (5, 0, 0): 1,
        },
        variables=variables,
    )
    extra_t2 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 5, 0): 1,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan(
        [
            divisor * hidden_common * extra_t1,
            divisor * hidden_common * extra_t2,
        ],
        variables=variables,
    )
    result = {
        "multivariable_alexander_polynomial": divisor.format(),
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "method": "synthetic_nonmaximal_seven_term_sparse_candidate",
        "presentation": {
            "variables": list(variables),
        },
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic non-maximal seven-term sparse candidate"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)

    assert audit["skipped"] is False
    assert audit["candidate_is_exact_scanned_gcd"] is False
    assert audit["quotient_gcd_certified"] is True
    assert (
        audit["quotient_gcd_method"]
        == "fox_square_minor_multivariate_sparse_factor_gcd"
    )
    assert audit["quotient_gcd_polynomial"] == hidden_common.format()
    assert audit["improved_candidate_polynomial"] == (
        divisor * hidden_common
    ).normalize_unit().format()
    quotient_evidence = audit["quotient_gcd_evidence"]
    assert quotient_evidence["candidate_method"] == (
        "fox_square_minor_multivariate_sparse_factor_gcd"
    )
    assert quotient_evidence["candidate_polynomial"] == hidden_common.format()
    assert quotient_evidence["divides_all_inputs"] is True
    assert quotient_evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert audit["full_invariant_certified"] is False



def test_multivariable_alexander_scanned_gcd_audit_reports_eight_term_sparse_improvement() -> None:
    variables = ("t1", "t2", "t3")
    divisor = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): -1,
        },
        variables=variables,
    )
    hidden_common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (1, 0, 0): 1,
            (0, 1, 0): -1,
            (2, 0, 0): 2,
            (0, 2, 0): 1,
            (2, 1, 0): -1,
            (1, 2, 0): 1,
            (3, 1, 0): 2,
        },
        variables=variables,
    ).normalize_unit()
    extra_t1 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (6, 0, 0): 1,
        },
        variables=variables,
    )
    extra_t2 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 6, 0): 1,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan(
        [
            divisor * hidden_common * extra_t1,
            divisor * hidden_common * extra_t2,
        ],
        variables=variables,
    )
    result = {
        "multivariable_alexander_polynomial": divisor.format(),
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "method": "synthetic_nonmaximal_eight_term_sparse_candidate",
        "presentation": {
            "variables": list(variables),
        },
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic non-maximal eight-term sparse candidate"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)

    assert audit["skipped"] is False
    assert audit["candidate_is_exact_scanned_gcd"] is False
    assert audit["quotient_gcd_certified"] is True
    assert (
        audit["quotient_gcd_method"]
        == "fox_square_minor_multivariate_sparse_factor_gcd"
    )
    assert audit["quotient_gcd_polynomial"] == hidden_common.format()
    assert audit["improved_candidate_polynomial"] == (
        divisor * hidden_common
    ).normalize_unit().format()
    quotient_evidence = audit["quotient_gcd_evidence"]
    assert quotient_evidence["candidate_method"] == (
        "fox_square_minor_multivariate_sparse_factor_gcd"
    )
    assert quotient_evidence["candidate_polynomial"] == hidden_common.format()
    assert quotient_evidence["divides_all_inputs"] is True
    assert quotient_evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert audit["full_invariant_certified"] is False



def test_multivariable_alexander_scanned_gcd_audit_reports_nine_term_sparse_improvement() -> None:
    variables = ("t1", "t2", "t3")
    divisor = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): -1,
        },
        variables=variables,
    )
    hidden_common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (1, 0, 0): 1,
            (0, 1, 0): -1,
            (2, 0, 0): 2,
            (0, 2, 0): 1,
            (2, 1, 0): -1,
            (1, 2, 0): 1,
            (3, 1, 0): 2,
            (1, 3, 0): -2,
        },
        variables=variables,
    ).normalize_unit()
    extra_a = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (20, 0, 0): 1,
        },
        variables=variables,
    )
    extra_b = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (21, 0, 0): 1,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan(
        [
            divisor * hidden_common * extra_a,
            divisor * hidden_common * extra_b,
        ],
        variables=variables,
    )
    result = {
        "multivariable_alexander_polynomial": divisor.format(),
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "method": "synthetic_nonmaximal_nine_term_sparse_candidate",
        "presentation": {
            "variables": list(variables),
        },
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic non-maximal nine-term sparse candidate"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)

    assert audit["skipped"] is False
    assert audit["candidate_is_exact_scanned_gcd"] is False
    assert audit["quotient_gcd_certified"] is True
    assert (
        audit["quotient_gcd_method"]
        == "fox_square_minor_multivariate_sparse_factor_gcd"
    )
    assert audit["quotient_gcd_polynomial"] == hidden_common.format()
    assert audit["improved_candidate_polynomial"] == (
        divisor * hidden_common
    ).normalize_unit().format()
    quotient_evidence = audit["quotient_gcd_evidence"]
    assert quotient_evidence["candidate_method"] == (
        "fox_square_minor_multivariate_sparse_factor_gcd"
    )
    assert quotient_evidence["candidate_polynomial"] == hidden_common.format()
    assert quotient_evidence["divides_all_inputs"] is True
    assert quotient_evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert audit["full_invariant_certified"] is False


def test_multivariable_alexander_scanned_gcd_audit_reports_ten_term_sparse_improvement() -> None:
    variables = ("t1", "t2", "t3")
    divisor = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): -1,
        },
        variables=variables,
    )
    hidden_common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (1, 0, 0): 1,
            (0, 1, 0): -1,
            (2, 0, 0): 2,
            (0, 2, 0): 1,
            (2, 1, 0): -1,
            (1, 2, 0): 1,
            (3, 1, 0): 2,
            (1, 3, 0): -2,
            (4, 0, 0): 3,
        },
        variables=variables,
    ).normalize_unit()
    extra_a = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (30, 0, 0): 1,
        },
        variables=variables,
    )
    extra_b = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (31, 0, 0): 1,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan(
        [
            divisor * hidden_common * extra_a,
            divisor * hidden_common * extra_b,
        ],
        variables=variables,
    )
    result = {
        "multivariable_alexander_polynomial": divisor.format(),
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "method": "synthetic_nonmaximal_ten_term_sparse_candidate",
        "presentation": {
            "variables": list(variables),
        },
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic non-maximal ten-term sparse candidate"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)

    assert audit["skipped"] is False
    assert audit["candidate_is_exact_scanned_gcd"] is False
    assert audit["quotient_gcd_certified"] is True
    assert (
        audit["quotient_gcd_method"]
        == "fox_square_minor_multivariate_sparse_factor_gcd"
    )
    assert audit["quotient_gcd_polynomial"] == hidden_common.format()
    assert audit["improved_candidate_polynomial"] == (
        divisor * hidden_common
    ).normalize_unit().format()
    quotient_evidence = audit["quotient_gcd_evidence"]
    assert quotient_evidence["candidate_method"] == (
        "fox_square_minor_multivariate_sparse_factor_gcd"
    )
    assert quotient_evidence["candidate_polynomial"] == hidden_common.format()
    assert quotient_evidence["divides_all_inputs"] is True
    assert quotient_evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert audit["full_invariant_certified"] is False


def test_multivariable_alexander_scanned_gcd_audit_reports_twelve_term_sparse_improvement() -> None:
    variables = ("t1", "t2", "t3")
    divisor = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): -1,
        },
        variables=variables,
    )
    hidden_common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (1, 0, 0): 1,
            (0, 1, 0): -1,
            (2, 0, 0): 2,
            (0, 2, 0): 1,
            (2, 1, 0): -1,
            (1, 2, 0): 1,
            (3, 1, 0): 2,
            (1, 3, 0): -2,
            (4, 0, 0): 3,
            (0, 4, 0): -3,
            (4, 2, 0): 5,
        },
        variables=variables,
    ).normalize_unit()
    extra_a = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (40, 0, 0): 1,
        },
        variables=variables,
    )
    extra_b = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (41, 0, 0): 1,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan(
        [
            divisor * hidden_common * extra_a,
            divisor * hidden_common * extra_b,
        ],
        variables=variables,
    )
    result = {
        "multivariable_alexander_polynomial": divisor.format(),
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "method": "synthetic_nonmaximal_twelve_term_sparse_candidate",
        "presentation": {
            "variables": list(variables),
        },
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic non-maximal twelve-term sparse candidate"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)

    assert audit["skipped"] is False
    assert audit["candidate_is_exact_scanned_gcd"] is False
    assert audit["quotient_gcd_certified"] is True
    assert (
        audit["quotient_gcd_method"]
        == "fox_square_minor_multivariate_sparse_factor_gcd"
    )
    assert audit["quotient_gcd_polynomial"] == hidden_common.format()
    assert audit["improved_candidate_polynomial"] == (
        divisor * hidden_common
    ).normalize_unit().format()
    quotient_evidence = audit["quotient_gcd_evidence"]
    assert quotient_evidence["candidate_method"] == (
        "fox_square_minor_multivariate_sparse_factor_gcd"
    )
    assert quotient_evidence["candidate_polynomial"] == hidden_common.format()
    assert quotient_evidence["divides_all_inputs"] is True
    assert quotient_evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert audit["full_invariant_certified"] is False


def test_multivariable_alexander_scanned_gcd_audit_reports_fourteen_term_sparse_improvement() -> None:
    variables = ("t1", "t2", "t3")
    divisor = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): -1,
        },
        variables=variables,
    )
    hidden_common = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (1, 0, 0): 1,
            (0, 1, 0): -1,
            (2, 0, 0): 2,
            (0, 2, 0): 1,
            (2, 1, 0): -1,
            (1, 2, 0): 1,
            (3, 1, 0): 2,
            (1, 3, 0): -2,
            (4, 0, 0): 3,
            (0, 4, 0): -3,
            (4, 2, 0): 5,
            (2, 4, 0): -5,
            (5, 1, 0): 7,
        },
        variables=variables,
    ).normalize_unit()
    extra_a = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (60, 0, 0): 1,
        },
        variables=variables,
    )
    extra_b = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (61, 0, 0): 1,
        },
        variables=variables,
    )
    scan = _synthetic_square_minor_scan(
        [
            divisor * hidden_common * extra_a,
            divisor * hidden_common * extra_b,
        ],
        variables=variables,
    )
    result = {
        "multivariable_alexander_polynomial": divisor.format(),
        "candidate_polynomials": [minor["polynomial"] for minor in scan["minors"]],
        "method": "synthetic_nonmaximal_fourteen_term_sparse_candidate",
        "presentation": {
            "variables": list(variables),
        },
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic non-maximal fourteen-term sparse candidate"],
    }

    audit = multivariable_alexander_scanned_gcd_audit(result)

    assert audit["skipped"] is False
    assert audit["candidate_is_exact_scanned_gcd"] is False
    assert audit["quotient_gcd_certified"] is True
    assert (
        audit["quotient_gcd_method"]
        == "fox_square_minor_multivariate_sparse_factor_gcd"
    )
    assert audit["quotient_gcd_polynomial"] == hidden_common.format()
    assert audit["improved_candidate_polynomial"] == (
        divisor * hidden_common
    ).normalize_unit().format()
    quotient_evidence = audit["quotient_gcd_evidence"]
    assert quotient_evidence["candidate_method"] == (
        "fox_square_minor_multivariate_sparse_factor_gcd"
    )
    assert quotient_evidence["candidate_polynomial"] == hidden_common.format()
    assert quotient_evidence["divides_all_inputs"] is True
    assert quotient_evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert audit["full_invariant_certified"] is False
def test_multivariable_alexander_detects_iterated_sparse_factor_product() -> None:
    variables = ("t1", "t2")
    common_a = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (1, 0): 1,
            (0, 1): 1,
        },
        variables=variables,
    )
    common_b = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (2, 0): 1,
            (0, 2): 1,
        },
        variables=variables,
    )
    extra_t1 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (3, 0): 1,
        },
        variables=variables,
    )
    extra_t2 = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0): 1,
            (0, 3): 1,
        },
        variables=variables,
    )
    expected = (common_a * common_b).normalize_unit()

    result = _conservative_common_gcd_from_minors(
        [
            _synthetic_minor(expected * extra_t1),
            _synthetic_minor(expected * extra_t2),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note = result
    assert method == "fox_square_minor_multivariate_sparse_factor_gcd"
    assert polynomial.format() == expected.format()
    assert "bounded exact sparse-factor scan" in note


def test_multivariable_alexander_detects_hidden_root_binomial_factor() -> None:
    variables = ("t1", "t2", "t3")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 1,
            (0, 1, 0): -1,
        },
        variables=variables,
    )
    hidden_square = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 1,
            (0, 1, 0): 1,
        },
        variables=variables,
    )
    hidden_extra = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 1,
            (0, 1, 0): 2,
        },
        variables=variables,
    )
    off_axis_extra = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * hidden_square),
            _synthetic_minor(common * hidden_extra * off_axis_extra),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_root_binomial_factor_gcd"
    assert polynomial.format() == "t2 - t1"
    assert "root-binomial scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == "t2 - t1"
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert {record["quotient_polynomial"] for record in evidence["division_records"]} == {
        "t2 + t1",
        "2t2 + 2*t2*t3 + t1 + t1*t3",
    }
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_detects_hidden_cubic_root_binomial_factor() -> None:
    variables = ("t1", "t2", "t3")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 1,
            (0, 1, 0): -1,
        },
        variables=variables,
    )
    cubic_complement = MultivariateLaurentPolynomial.from_dict(
        {
            (2, 0, 0): 1,
            (1, 1, 0): 1,
            (0, 2, 0): 1,
        },
        variables=variables,
    )
    hidden_extra = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 1,
            (0, 1, 0): 2,
        },
        variables=variables,
    )
    off_axis_extra = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * cubic_complement),
            _synthetic_minor(common * hidden_extra * off_axis_extra),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_root_binomial_factor_gcd"
    assert polynomial.format() == "t2 - t1"
    assert "root-binomial scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == "t2 - t1"
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_detects_hidden_scaled_root_binomial_factor() -> None:
    variables = ("t1", "t2", "t3")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 1,
            (0, 1, 0): -2,
        },
        variables=variables,
    )
    scaled_complement = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 1,
            (0, 1, 0): 2,
        },
        variables=variables,
    )
    scaled_extra = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 1,
            (0, 1, 0): 3,
        },
        variables=variables,
    )
    off_axis_positive = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): 1,
        },
        variables=variables,
    )
    off_axis_negative = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): -1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * scaled_complement * off_axis_positive),
            _synthetic_minor(common * scaled_extra * off_axis_negative),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_root_binomial_factor_gcd"
    assert polynomial.format() == "2t2 - t1"
    assert "root-binomial scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == "2t2 - t1"
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_detects_weighted_cubic_root_binomial_factor() -> None:
    variables = ("t1", "t2", "t3")
    common = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 2,
            (0, 1, 0): -3,
        },
        variables=variables,
    )
    weighted_cubic_complement = MultivariateLaurentPolynomial.from_dict(
        {
            (2, 0, 0): 4,
            (1, 1, 0): 6,
            (0, 2, 0): 9,
        },
        variables=variables,
    )
    hidden_extra = MultivariateLaurentPolynomial.from_dict(
        {
            (1, 0, 0): 1,
            (0, 1, 0): 2,
        },
        variables=variables,
    )
    off_axis_extra = MultivariateLaurentPolynomial.from_dict(
        {
            (0, 0, 0): 1,
            (0, 0, 1): 1,
        },
        variables=variables,
    )

    result = _conservative_common_gcd_with_evidence_from_minors(
        [
            _synthetic_minor(common * weighted_cubic_complement),
            _synthetic_minor(common * hidden_extra * off_axis_extra),
        ],
        variables=variables,
    )

    assert result is not None
    polynomial, method, note, evidence = result
    assert method == "fox_square_minor_multivariate_root_binomial_factor_gcd"
    assert polynomial.format() == "3t2 - 2t1"
    assert "root-binomial scan" in note
    assert evidence["candidate_method"] == method
    assert evidence["candidate_polynomial"] == "3t2 - 2t1"
    assert evidence["divides_all_inputs"] is True
    assert evidence["failed_input_indices"] == []
    assert evidence["full_invariant_certified"] is False

def test_trefoil_signed_pd_alexander_matches_one_variable_fixture() -> None:
    diagram = get_diagram_fixture("3_1").diagram()

    result = multivariable_alexander_from_pd(
        diagram,
        variables=("t",),
        max_minors=64,
    )

    assert result["skipped"] is False
    assert result["method"] == "fox_square_minor_consensus_gcd"
    assert result["multivariable_alexander_polynomial"] == "1 - t + t^2"
    assert result["presentation"]["generator_components"] == [0, 0, 0]


def test_multivariable_alexander_minor_divisibility_audit_for_fixtures() -> None:
    for notation in ("L2a1", "3_1", "4_1"):
        fixture = get_diagram_fixture(notation)
        audit = multivariable_alexander_minor_divisibility_audit_from_pd(
            fixture.diagram(),
            orientation=fixture.orientation(),
            variables=fixture.expected_multivariable_alexander_variables,
            max_minors=64,
        )

        assert audit["skipped"] is False
        assert audit["all_nonzero_minors_divisible"] is True
        assert audit["complete_combination_scan"] is True
        assert audit["full_invariant_certified"] is False
        assert audit["claim_scope"] == "bounded_scanned_fox_minor_divisibility"
        assert audit["failed_minor_indices"] == []
        assert audit["failed_nonzero_minor_count"] == 0
        assert audit["checked_nonzero_minor_count"] >= 1
        assert (
            audit["multivariable_alexander_polynomial"]
            == fixture.expected_multivariable_alexander
        )
        assert "exact multivariate division" in audit["notes"][0]


def test_multivariable_alexander_scanned_gcd_audit_for_fixtures() -> None:
    for notation in ("L2a1", "3_1", "4_1"):
        fixture = get_diagram_fixture(notation)
        audit = multivariable_alexander_scanned_gcd_audit_from_pd(
            fixture.diagram(),
            orientation=fixture.orientation(),
            variables=fixture.expected_multivariable_alexander_variables,
            max_minors=64,
        )

        assert audit["skipped"] is False
        assert audit["candidate_is_exact_scanned_gcd"] is True
        assert audit["complete_scanned_gcd_certified"] is True
        assert audit["quotient_gcd_certified"] is True
        assert audit["quotient_gcd_polynomial"] == "1"
        assert audit["complete_combination_scan"] is True
        assert audit["full_invariant_certified"] is False
        assert audit["claim_scope"] == "bounded_scanned_fox_minor_exact_gcd"
        assert audit["failed_minor_indices"] == []
        assert audit["failed_nonzero_minor_count"] == 0
        assert audit["checked_nonzero_minor_count"] >= 1
        assert (
            audit["multivariable_alexander_polynomial"]
            == fixture.expected_multivariable_alexander
        )
        if audit["quotient_gcd_method"] == "fox_square_minor_quotient_unit_gcd":
            quotient_evidence = audit["quotient_gcd_evidence"]
            assert quotient_evidence["candidate_method"] == (
                "fox_square_minor_quotient_unit_gcd"
            )
            assert quotient_evidence["candidate_polynomial"] == "1"
            assert quotient_evidence["candidate_is_exact_gcd_for_inputs"] is True
            assert quotient_evidence["quotient_common_factor_method"] == (
                "quotient_unit_witness_gcd"
            )


def test_multivariable_alexander_wirtinger_fox_audit_for_fixtures() -> None:
    for notation in ("L2a1", "3_1", "4_1"):
        fixture = get_diagram_fixture(notation)
        result = multivariable_alexander_from_pd(
            fixture.diagram(),
            orientation=fixture.orientation(),
            variables=fixture.expected_multivariable_alexander_variables,
            max_minors=64,
        )

        audit = multivariable_alexander_wirtinger_fox_audit(result)

        assert audit["method"] == "multivariable_alexander_wirtinger_fox_audit"
        assert audit["claim_scope"] == (
            "input_wirtinger_presentation_and_fox_matrix_consistency"
        )
        assert audit["skipped"] is False
        assert audit["presentation_valid"] is True
        assert audit["presentation_source"] == "stored_wirtinger_presentation"
        assert "over^sign under_in over^-sign under_out^-1" in audit[
            "presentation_convention"
        ]
        assert audit["wirtinger_relation_shape_valid"] is True
        assert audit["wirtinger_relation_shape_invalid_count"] == 0
        assert audit["wirtinger_relation_shape_witnesses"] == []
        assert audit["wirtinger_generator_component_coverage_complete"] is True
        assert sum(
            row["generator_count"]
            for row in audit["wirtinger_generator_component_counts"]
        ) == audit["generator_count"]
        assert audit["fox_jacobian_valid"] is True
        assert audit["fox_square_minor_scan_valid"] is True
        assert audit["input_chain_consistent"] is True
        assert audit["relation_count"] == len(result["presentation"]["relations"])
        assert audit["generator_count"] == len(
            result["presentation"]["generator_components"]
        )
        assert audit["variable_count"] == len(result["presentation"]["variables"])
        assert audit["jacobian_matrix_size"] == result["square_minors"]["matrix_size"]
        assert audit["square_minor_matrix_size"] == result["square_minors"]["matrix_size"]
        assert audit["invalid_minor_reference_count"] == 0
        assert audit["invalid_normalization_count"] == 0
        assert audit["complete_combination_scan"] is True
        assert audit["truncated"] is False
        assert audit["full_invariant_certified"] is False

        scanned = multivariable_alexander_scanned_gcd_audit(result)
        evidence = multivariable_alexander_input_certification_evidence(
            scanned,
            audit,
        )
        assert evidence["wirtinger_fox_input_chain_consistent"] is True
        assert evidence["wirtinger_presentation_valid"] is True
        assert evidence["wirtinger_relation_shape_valid"] is True
        assert evidence["wirtinger_relation_shape_invalid_count"] == 0
        assert evidence["wirtinger_relation_shape_witness_count"] == 0
        assert evidence["wirtinger_relation_shape_count_consistent"] is True
        assert evidence["wirtinger_generator_component_coverage_complete"] is True
        assert evidence["wirtinger_generator_component_count_row_count"] == len(
            audit["wirtinger_generator_component_counts"]
        )
        assert evidence["wirtinger_generator_component_count_total"] == audit[
            "generator_count"
        ]
        assert evidence["wirtinger_generator_component_count_consistent"] is True
        assert evidence["fox_jacobian_valid"] is True
        assert evidence["fox_square_minor_scan_valid"] is True
        assert evidence["wirtinger_relation_count"] == audit["relation_count"]
        assert evidence["wirtinger_generator_count"] == audit["generator_count"]
        assert evidence["fox_square_minor_invalid_reference_count"] == 0
        assert evidence["fox_square_minor_invalid_normalization_count"] == 0


def test_multivariable_alexander_wirtinger_fox_audit_rejects_invalid_presentation() -> None:
    fixture = get_diagram_fixture("3_1")
    result = multivariable_alexander_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
        variables=fixture.expected_multivariable_alexander_variables,
        max_minors=64,
    )
    bad_result = {
        **result,
        "presentation": {
            **result["presentation"],
            "relations": [[[99, 1]]],
        },
    }

    audit = multivariable_alexander_wirtinger_fox_audit(bad_result)

    assert audit["skipped"] is False
    assert audit["presentation_valid"] is False
    assert audit["fox_jacobian_valid"] is False
    assert audit["input_chain_consistent"] is False
    assert "generator index out of range" in "\n".join(audit["notes"])


def test_multivariable_alexander_wirtinger_fox_audit_rejects_bad_relation_shape() -> None:
    fixture = get_diagram_fixture("3_1")
    result = multivariable_alexander_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
        variables=fixture.expected_multivariable_alexander_variables,
        max_minors=64,
    )
    bad_result = deepcopy(result)
    relation = [list(term) for term in bad_result["presentation"]["relations"][0]]
    relation[2][0] = relation[1][0]
    bad_result["presentation"]["relations"][0] = relation

    audit = multivariable_alexander_wirtinger_fox_audit(bad_result)

    assert audit["skipped"] is False
    assert audit["presentation_valid"] is True
    assert audit["wirtinger_relation_shape_valid"] is False
    assert audit["wirtinger_relation_shape_invalid_count"] == 1
    assert audit["wirtinger_relation_shape_witnesses"][0]["relation_index"] == 0
    assert (
        audit["wirtinger_relation_shape_witnesses"][0]["reason"]
        == "first and third Wirtinger terms do not share the over generator"
    )
    assert audit["fox_jacobian_valid"] is True
    assert audit["input_chain_consistent"] is False
    assert audit["full_admissible_minor_normalization_certified"] is False
    assert audit["full_invariant_certified"] is False


def test_multivariable_alexander_wirtinger_fox_audit_rejects_bad_minor_normalization() -> None:
    fixture = get_diagram_fixture("L2a1")
    result = multivariable_alexander_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
        variables=fixture.expected_multivariable_alexander_variables,
        max_minors=64,
    )
    bad_result = deepcopy(result)
    bad_result["square_minors"]["minors"][0]["normalization"]["unit_sign"] = 1

    audit = multivariable_alexander_wirtinger_fox_audit(bad_result)

    assert audit["skipped"] is False
    assert audit["presentation_valid"] is True
    assert audit["fox_jacobian_valid"] is True
    assert audit["fox_square_minor_scan_valid"] is False
    assert audit["input_chain_consistent"] is False
    assert audit["invalid_minor_reference_count"] == 0
    assert audit["invalid_minor_reference_witness_count"] == 0
    assert audit["invalid_minor_reference_witnesses"] == []
    assert audit["invalid_normalization_count"] == 1
    assert audit["invalid_normalization_witness_count"] == 1
    assert audit["invalid_normalization_witness_limit"] == 8
    assert audit["invalid_normalization_witness_truncated"] is False
    assert len(audit["invalid_normalization_witnesses"]) == 1
    _assert_bounded_witness_consistency(
        audit["invalid_normalization_witness_consistency"],
        witness_kind="invalid_minor_normalization",
        witness_count=1,
        witness_list_count=1,
        witness_limit=8,
        witness_truncated=False,
    )
    witness = audit["invalid_normalization_witnesses"][0]
    assert witness["minor_index"] == 0
    assert witness["validation_kind"] == "normalization"
    assert witness["rows"] == bad_result["square_minors"]["minors"][0]["rows"]
    assert witness["columns"] == bad_result["square_minors"]["minors"][0]["columns"]
    assert witness["issue_count"] >= 1
    assert "unit_sign does not match deterministic normalization" in witness["issues"]

    scanned = multivariable_alexander_scanned_gcd_audit(bad_result)
    evidence = multivariable_alexander_input_certification_evidence(
        scanned,
        audit,
    )
    assert evidence["fox_square_minor_invalid_reference_witness_count"] == 0
    assert evidence["fox_square_minor_invalid_normalization_witness_count"] == 1
    assert evidence["fox_square_minor_invalid_normalization_witnesses"] == [
        witness
    ]
    assert evidence[
        "fox_square_minor_invalid_normalization_witness_consistency"
    ] == audit["invalid_normalization_witness_consistency"]
    assert "normalization metadata invalid" in "\n".join(audit["notes"])

def test_multivariable_alexander_minor_divisibility_audit_rejects_wrong_candidate() -> None:
    fixture = get_diagram_fixture("3_1")
    result = multivariable_alexander_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
        variables=fixture.expected_multivariable_alexander_variables,
        max_minors=64,
    )

    wrong_result = {
        **result,
        "multivariable_alexander_polynomial": "1 + t",
    }
    audit = multivariable_alexander_minor_divisibility_audit(wrong_result)

    assert audit["skipped"] is False
    assert audit["all_nonzero_minors_divisible"] is False
    assert audit["checked_nonzero_minor_count"] >= 1
    assert audit["failed_nonzero_minor_count"] == len(audit["failed_minor_indices"])
    assert audit["failed_nonzero_minor_count"] >= 1
    assert audit["failed_division_witness_count"] == (
        audit["failed_nonzero_minor_count"]
    )
    assert audit["failed_division_witness_limit"] == 8
    assert audit["failed_division_witness_truncated"] is (
        audit["failed_nonzero_minor_count"] > audit["failed_division_witness_limit"]
    )
    assert len(audit["failed_division_witnesses"]) == min(
        audit["failed_nonzero_minor_count"],
        audit["failed_division_witness_limit"],
    )
    _assert_bounded_witness_consistency(
        audit["failed_division_witness_consistency"],
        witness_kind="failed_division",
        witness_count=audit["failed_nonzero_minor_count"],
        witness_list_count=len(audit["failed_division_witnesses"]),
        witness_limit=8,
        witness_truncated=audit["failed_division_witness_truncated"],
    )
    first_witness = audit["failed_division_witnesses"][0]
    assert first_witness["minor_index"] in audit["failed_minor_indices"]
    assert first_witness["divisible"] is False
    assert first_witness["quotient_polynomial"] is None
    assert any(
        record["divisible"] is False for record in audit["division_records"]
    )
    assert "failed exact division" in audit["notes"][0]
    assert audit["full_invariant_certified"] is False


def test_multivariable_alexander_scanned_gcd_audit_rejects_wrong_candidate() -> None:
    fixture = get_diagram_fixture("3_1")
    result = multivariable_alexander_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
        variables=fixture.expected_multivariable_alexander_variables,
        max_minors=64,
    )

    wrong_result = {
        **result,
        "multivariable_alexander_polynomial": "1 + t",
    }
    audit = multivariable_alexander_scanned_gcd_audit(wrong_result)

    assert audit["skipped"] is False
    assert audit["candidate_is_exact_scanned_gcd"] is False
    assert audit["quotient_gcd_certified"] is False
    assert audit["failed_nonzero_minor_count"] >= 1
    assert audit["failed_nonzero_minor_count"] == len(audit["failed_minor_indices"])
    assert audit["failed_division_witness_count"] == (
        audit["failed_nonzero_minor_count"]
    )
    assert audit["failed_division_witness_limit"] == 8
    assert audit["failed_division_witness_truncated"] is (
        audit["failed_nonzero_minor_count"] > audit["failed_division_witness_limit"]
    )
    assert len(audit["failed_division_witnesses"]) == min(
        audit["failed_nonzero_minor_count"],
        audit["failed_division_witness_limit"],
    )
    _assert_bounded_witness_consistency(
        audit["failed_division_witness_consistency"],
        witness_kind="failed_division",
        witness_count=audit["failed_nonzero_minor_count"],
        witness_list_count=len(audit["failed_division_witnesses"]),
        witness_limit=8,
        witness_truncated=audit["failed_division_witness_truncated"],
    )
    first_witness = audit["failed_division_witnesses"][0]
    assert first_witness["minor_index"] in audit["failed_minor_indices"]
    assert first_witness["divisible"] is False
    assert first_witness["quotient_polynomial"] is None
    assert "failed exact division" in audit["notes"][0]
    assert audit["full_invariant_certified"] is False

    evidence = multivariable_alexander_input_certification_evidence(audit)
    assert evidence["skipped"] is False
    assert evidence["bounded_scanned_gcd_certified"] is False
    assert evidence["candidate_is_exact_scanned_gcd"] is False
    assert evidence["failed_nonzero_minor_count"] >= 1
    assert evidence["failed_minor_count"] == len(audit["failed_minor_indices"])
    assert evidence["failed_division_witness_count"] == (
        audit["failed_division_witness_count"]
    )
    assert evidence["failed_division_witnesses"] == (
        audit["failed_division_witnesses"]
    )
    assert evidence["failed_division_witness_consistency"] == (
        audit["failed_division_witness_consistency"]
    )
    assert "candidate_not_exact_scanned_gcd" in evidence["certification_blockers"]
    assert "failed_nonzero_minor_division" in evidence["certification_blockers"]
    assert "quotient_gcd_uncertified" in evidence["certification_blockers"]
    assert evidence["certification_blocker_count"] == len(
        evidence["certification_blockers"]
    )
    assert evidence["certification_blocker_details"][
        "failed_nonzero_minor_division"
    ]["failed_minor_indices"] == audit["failed_minor_indices"]
    assert evidence["certification_blocker_details"][
        "failed_nonzero_minor_division"
    ]["failed_division_witnesses"] == audit["failed_division_witnesses"]
    assert evidence["full_invariant_certified"] is False


def test_multivariable_alexander_input_certification_evidence_handles_missing_audit() -> None:
    evidence = multivariable_alexander_input_certification_evidence(None)

    assert evidence["method"] == (
        "multivariable_alexander_input_certification_evidence"
    )
    assert evidence["skipped"] is True
    assert evidence["bounded_scanned_gcd_certified"] is False
    assert evidence["bounded_alexander_maturity_path"] == "not_certified"
    assert evidence["bounded_alexander_maturity_path_certified"] is False
    assert evidence["checked_nonzero_minor_count"] == 0
    assert evidence["complete_scanned_gcd_certified"] is False
    assert evidence["certification_blockers"] == ["scanned_gcd_audit_missing"]
    assert evidence["certification_blocker_count"] == 1
    assert evidence["full_alexander_completion_blockers"] == [
        "full_admissible_minor_normalization_not_certified",
        "full_varied_polynomial_gcd_not_certified",
        "full_invariant_not_certified",
    ]
    assert evidence["notes"] == ["no scanned-gcd audit supplied"]


def test_multivariable_alexander_minor_divisibility_audit_keeps_hopf_boundary() -> None:
    fixture = get_diagram_fixture("L2a1")

    audit = multivariable_alexander_minor_divisibility_audit_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
        variables=fixture.expected_multivariable_alexander_variables,
    )

    assert audit["source_method"] == "fox_square_minor_disjoint_support_gcd"
    assert audit["multivariable_alexander_polynomial"] == "1"
    assert set(audit["candidate_polynomials"]) == {"1 - t1", "1 - t2"}
    assert audit["checked_nonzero_minor_count"] == 4
    assert audit["checked_nonzero_minor_count"] == (
        audit["admissible_minor_summary"]["nonzero_minor_count"]
    )
    assert {record["quotient_polynomial"] for record in audit["division_records"]} == {
        "1 - t1",
        "1 - t2",
    }
    assert audit["failed_nonzero_minor_count"] == 0
    assert audit["full_invariant_certified"] is False


def test_multivariable_alexander_scanned_gcd_audit_keeps_hopf_boundary() -> None:
    fixture = get_diagram_fixture("L2a1")

    audit = multivariable_alexander_scanned_gcd_audit_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
        variables=fixture.expected_multivariable_alexander_variables,
    )

    assert audit["source_method"] == "fox_square_minor_disjoint_support_gcd"
    assert audit["multivariable_alexander_polynomial"] == "1"
    assert set(audit["candidate_polynomials"]) == {"1 - t1", "1 - t2"}
    assert audit["candidate_is_exact_scanned_gcd"] is True
    assert audit["complete_scanned_gcd_certified"] is True
    assert audit["quotient_gcd_method"] == "fox_square_minor_disjoint_support_gcd"
    assert audit["quotient_gcd_polynomial"] == "1"
    assert {record["quotient_polynomial"] for record in audit["division_records"]} == {
        "1 - t1",
        "1 - t2",
    }
    assert audit["full_invariant_certified"] is False


def test_multivariable_alexander_minor_divisibility_audit_for_common_factor() -> None:
    commutator_xy = ((0, 1), (1, 1), (0, -1), (1, -1))
    commutator_yz = ((1, 1), (2, 1), (1, -1), (2, -1))
    presentation = WirtingerPresentation(
        relations=(commutator_xy, commutator_yz),
        generator_components=(0, 0, 1),
        variables=("t1", "t2"),
        source="synthetic_commutator_chain",
    )

    audit = multivariable_alexander_minor_divisibility_audit_from_presentation(
        presentation,
        target_size=2,
        max_matrix_size=3,
        max_minors=16,
    )

    assert audit["skipped"] is False
    assert audit["source_method"] == "fox_square_minor_multivariate_factor_gcd"
    assert audit["multivariable_alexander_polynomial"] == "1 - t1"
    assert audit["all_nonzero_minors_divisible"] is True
    assert audit["failed_minor_indices"] == []
    assert {record["quotient_polynomial"] for record in audit["division_records"]} == {
        "1 - t1",
        "1 - t2",
    }


def test_multivariable_alexander_scanned_gcd_audit_for_common_factor() -> None:
    commutator_xy = ((0, 1), (1, 1), (0, -1), (1, -1))
    commutator_yz = ((1, 1), (2, 1), (1, -1), (2, -1))
    presentation = WirtingerPresentation(
        relations=(commutator_xy, commutator_yz),
        generator_components=(0, 0, 1),
        variables=("t1", "t2"),
        source="synthetic_commutator_chain",
    )

    audit = multivariable_alexander_scanned_gcd_audit_from_presentation(
        presentation,
        target_size=2,
        max_matrix_size=3,
        max_minors=16,
    )

    assert audit["skipped"] is False
    assert audit["source_method"] == "fox_square_minor_multivariate_factor_gcd"
    assert audit["multivariable_alexander_polynomial"] == "1 - t1"
    assert audit["candidate_is_exact_scanned_gcd"] is True
    assert audit["quotient_gcd_polynomial"] == "1"
    assert audit["quotient_gcd_method"] == "fox_square_minor_disjoint_support_gcd"
    quotient_evidence = audit["quotient_gcd_evidence"]
    assert quotient_evidence["method"] == "fox_square_minor_common_gcd_evidence"
    assert quotient_evidence["candidate_method"] == (
        "fox_square_minor_disjoint_support_gcd"
    )
    assert quotient_evidence["candidate_polynomial"] == "1"
    assert quotient_evidence["divides_all_inputs"] is True
    assert quotient_evidence["failed_input_indices"] == []
    assert quotient_evidence["candidate_is_exact_gcd_for_inputs"] is True
    assert quotient_evidence["quotient_common_factor_certified"] is True
    assert quotient_evidence["quotient_common_factor_method"] == (
        "quotient_disjoint_support_unit_gcd"
    )
    assert quotient_evidence["full_invariant_certified"] is False
    assert audit["failed_minor_indices"] == []


def test_multivariable_alexander_minor_divisibility_audit_reports_truncated_source() -> None:
    fixture = get_diagram_fixture("3_1")

    audit = multivariable_alexander_minor_divisibility_audit_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
        variables=fixture.expected_multivariable_alexander_variables,
        max_minors=1,
    )

    assert audit["skipped"] is True
    assert audit["source_method"] == "skipped"
    assert audit["all_nonzero_minors_divisible"] is False
    assert "source Alexander result did not return a polynomial" in audit["notes"]


def test_multivariable_alexander_scanned_gcd_audit_reports_truncated_source() -> None:
    fixture = get_diagram_fixture("3_1")

    audit = multivariable_alexander_scanned_gcd_audit_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
        variables=fixture.expected_multivariable_alexander_variables,
        max_minors=1,
    )

    assert audit["skipped"] is True
    assert audit["source_method"] == "skipped"
    assert audit["candidate_is_exact_scanned_gcd"] is False
    assert audit["complete_scanned_gcd_certified"] is False
    assert "source Alexander result did not return a polynomial" in audit["notes"]


def test_multivariable_alexander_fixture_acceptance_report_aggregates_current_evidence() -> None:
    report = multivariable_alexander_fixture_acceptance_report()

    assert report["method"] == "multivariable_alexander_fixture_acceptance_report"
    assert report["claim_scope"] == "registered_fixture_acceptance_under_iroll_convention"
    assert report["bounded_certification_scope"] == (
        "exact_scanned_fox_minor_gcd_for_registered_signed_pd_inputs"
    )
    assert report["full_admissible_minor_normalization_certified"] is False
    assert report["full_invariant_certified"] is False
    assert report["accepted"] is True
    assert report["fixture_count"] == 5
    assert report["accepted_count"] == 5
    assert report["incomplete_notations"] == []
    assert report["comparison_checked_count"] == 5
    assert report["comparison_matched_count"] == 5
    assert report["minor_divisibility_audit_checked_count"] == 3
    assert report["minor_divisibility_audit_matched_count"] == 3
    assert report["scanned_gcd_audit_checked_count"] == 3
    assert report["scanned_gcd_audit_matched_count"] == 3
    assert report["wirtinger_fox_audit_checked_count"] == 3
    assert report["wirtinger_fox_audit_matched_count"] == 3
    assert report["wirtinger_fox_invalid_minor_reference_count"] == 0
    assert report["wirtinger_fox_invalid_normalization_count"] == 0
    assert report["wirtinger_fox_complete_scan_count"] == 3
    assert report["wirtinger_fox_truncated_count"] == 0
    assert report["bounded_scanned_gcd_certification_applicable_count"] == 3
    assert report["bounded_scanned_gcd_certified_count"] == 3
    assert report["bounded_scanned_gcd_uncertified_count"] == 0
    assert report["bounded_scanned_gcd_checked_nonzero_minor_count"] >= 3
    assert report["bounded_scanned_gcd_failed_nonzero_minor_count"] == 0
    assert report["bounded_scanned_gcd_scanned_minor_count"] >= 3
    assert report["bounded_scanned_gcd_division_record_count"] >= 3
    assert report["bounded_scanned_gcd_complete_scan_count"] == 3
    assert report["bounded_scanned_gcd_nonzero_minor_coverage_complete_count"] == 3
    assert report["bounded_scanned_gcd_truncated_count"] == 0
    assert report["bounded_scanned_gcd_quotient_gcd_certified_count"] == 3
    assert report["bounded_scanned_gcd_complete_certified_count"] == 3
    assert report["bounded_scanned_gcd_improved_candidate_count"] == 0
    assert report["bounded_alexander_maturity_path_counts"] == [
        {"bounded_alexander_maturity_path": "exact_scanned_gcd", "fixture_count": 1},
        {
            "bounded_alexander_maturity_path": "laurent_unit_normalization_consensus",
            "fixture_count": 2,
        },
        {
            "bounded_alexander_maturity_path": "zero_crossing_unlink_terminal",
            "fixture_count": 2,
        },
    ]
    assert report["bounded_alexander_maturity_path_distinct_count"] == 3
    assert report["bounded_alexander_maturity_path_certified_count"] == 5
    maturity_consistency = report["bounded_alexander_maturity_path_summary_consistency"]
    assert maturity_consistency["method"] == (
        "bounded_alexander_maturity_path_summary_consistency"
    )
    assert maturity_consistency["matched"] is True
    assert maturity_consistency["record_count_field"] == "fixture_count"
    assert maturity_consistency["record_count"] == report["fixture_count"]
    assert maturity_consistency["path_count_total"] == report["fixture_count"]
    assert maturity_consistency["distinct_count_matches_path_count_rows"] is True
    assert maturity_consistency["certified_count_matches_paths"] is True
    assert maturity_consistency["certified_count"] == 5
    assert maturity_consistency["full_admissible_minor_normalization_certified"] is False
    assert maturity_consistency["full_invariant_certified"] is False
    assert report["zero_crossing_unlink_normalization_applicable_count"] == 2
    assert report["zero_crossing_unlink_normalization_certified_count"] == 2
    assert report["zero_crossing_unlink_normalization_uncertified_count"] == 0
    assert report["input_certification_zero_crossing_count"] == 2
    assert report["registered_knot_admissible_normalization_applicable_count"] == 2
    assert report["registered_knot_admissible_normalization_certified_count"] == 2
    assert report["registered_knot_admissible_normalization_uncertified_count"] == 0
    assert report["required_check_count"] == 18
    assert report["passed_check_count"] == 18
    assert report["failed_check_count"] == 0

    rows = {row["notation"]: row for row in report["fixtures"]}
    assert set(rows) == {"0_1", "L0a1", "L2a1", "3_1", "4_1"}
    for notation, expected in (("0_1", "1"), ("L0a1", "0")):
        assert rows[notation]["comparison"]["matched"] is True
        assert rows[notation]["comparison"]["observed_multivariable_alexander"] == expected
        assert rows[notation]["minor_divisibility_audit_applicable"] is False
        assert rows[notation]["minor_divisibility_audit"] is None
        assert rows[notation]["scanned_gcd_audit_applicable"] is False
        assert rows[notation]["scanned_gcd_audit"] is None
        assert rows[notation]["wirtinger_fox_audit_applicable"] is False
        assert rows[notation]["wirtinger_fox_audit"] is None
        assert rows[notation]["bounded_scanned_gcd_certification_applicable"] is False
        assert rows[notation]["bounded_scanned_gcd_certified"] is False
        assert rows[notation]["bounded_alexander_maturity_path"] == (
            "zero_crossing_unlink_terminal"
        )
        assert rows[notation]["bounded_alexander_maturity_path_certified"] is True
        assert rows[notation]["bounded_scanned_gcd_evidence"]["skipped"] is True
        assert rows[notation]["bounded_scanned_gcd_evidence"][
            "bounded_alexander_maturity_path"
        ] == "not_certified"
        assert rows[notation]["zero_crossing_unlink_normalization_applicable"] is True
        assert rows[notation]["zero_crossing_unlink_normalization_certified"] is True
        zero_evidence = rows[notation]["zero_crossing_unlink_normalization_evidence"]
        assert zero_evidence["method"] == "zero_crossing_unlink_normalization_evidence"
        assert zero_evidence["certified"] is True
        assert zero_evidence["bounded_alexander_maturity_path"] == (
            "zero_crossing_unlink_terminal"
        )
        assert zero_evidence["bounded_alexander_maturity_path_certified"] is True
        assert zero_evidence["observed_multivariable_alexander"] == expected
        assert zero_evidence["full_invariant_certified"] is False
        assert rows[notation]["required_check_count"] == 2
        assert rows[notation]["passed_check_count"] == 2
        assert rows[notation]["failed_check_count"] == 0
        assert rows[notation]["accepted"] is True

    for notation in ("L2a1", "3_1", "4_1"):
        assert rows[notation]["comparison"]["matched"] is True
        assert rows[notation]["minor_divisibility_audit"][
            "all_nonzero_minors_divisible"
        ] is True
        assert rows[notation]["minor_divisibility_audit"][
            "full_invariant_certified"
        ] is False
        assert rows[notation]["scanned_gcd_audit"][
            "candidate_is_exact_scanned_gcd"
        ] is True
        assert rows[notation]["scanned_gcd_audit"][
            "full_invariant_certified"
        ] is False
        assert rows[notation][
            "bounded_scanned_gcd_certification_applicable"
        ] is True
        assert rows[notation]["bounded_scanned_gcd_certified"] is True
        assert rows[notation]["scanned_gcd_audit"][
            "complete_scanned_gcd_certified"
        ] is True
        assert rows[notation]["wirtinger_fox_audit_matched"] is True
        assert rows[notation]["wirtinger_fox_audit"]["input_chain_consistent"] is True
        evidence = rows[notation]["bounded_scanned_gcd_evidence"]
        assert evidence["method"] == (
            "multivariable_alexander_input_certification_evidence"
        )
        expected_maturity_path = (
            "exact_scanned_gcd"
            if notation == "L2a1"
            else "laurent_unit_normalization_consensus"
        )
        assert rows[notation]["bounded_alexander_maturity_path"] == (
            expected_maturity_path
        )
        assert rows[notation]["bounded_alexander_maturity_path_certified"] is True
        assert evidence["bounded_scanned_gcd_certified"] is True
        assert evidence["bounded_alexander_maturity_path"] == expected_maturity_path
        assert evidence["bounded_alexander_maturity_path_certified"] is True
        assert evidence["candidate_is_exact_scanned_gcd"] is True
        assert evidence["complete_scanned_gcd_certified"] is True
        assert evidence["quotient_gcd_certified"] is True
        assert evidence["improved_candidate_polynomial"] is None
        assert evidence["checked_nonzero_minor_count"] >= 1
        assert evidence["failed_nonzero_minor_count"] == 0
        assert evidence["division_record_count"] >= 1
        assert evidence["complete_combination_scan"] is True
        assert evidence["nonzero_minor_coverage_complete"] is True
        assert evidence["all_rows_have_nonzero_minor"] is True
        assert evidence["all_columns_have_nonzero_minor"] is True
        assert evidence["truncated"] is False
        assert evidence["full_admissible_minor_normalization_certified"] is False
        assert evidence["full_invariant_certified"] is False
        assert rows[notation]["full_invariant_certified"] is False
        knot_evidence = rows[notation][
            "registered_knot_admissible_normalization_evidence"
        ]
        if notation == "L2a1":
            assert rows[notation][
                "registered_knot_admissible_normalization_applicable"
            ] is False
            assert rows[notation][
                "registered_knot_admissible_normalization_certified"
            ] is False
            assert knot_evidence["skipped"] is True
            assert rows[notation]["required_check_count"] == 4
            assert rows[notation]["passed_check_count"] == 4
        else:
            assert rows[notation][
                "registered_knot_admissible_normalization_applicable"
            ] is True
            assert rows[notation][
                "registered_knot_admissible_normalization_certified"
            ] is True
            assert knot_evidence["certified"] is True
            assert knot_evidence["comparison_matched"] is True
            assert knot_evidence["scanned_gcd_certified"] is True
            assert knot_evidence["wirtinger_fox_input_chain_consistent"] is True
            assert knot_evidence["complete_combination_scan"] is True
            assert knot_evidence["nonzero_minor_coverage_complete"] is True
            assert knot_evidence[
                "full_admissible_minor_normalization_certified"
            ] is False
            assert rows[notation]["required_check_count"] == 5
            assert rows[notation]["passed_check_count"] == 5
            assert rows[notation]["failed_check_count"] == 0
            assert rows[notation]["accepted"] is True


def _assert_alexander_source_notation_summary_consistency(report: dict) -> None:
    consistency = report["source_notation_summary_consistency"]
    count_fields = [
        "case_count",
        "accepted_case_count",
        "uncertified_case_count",
        "result_skipped_case_count",
        "nonzero_evaluated_result_skipped_case_count",
        "unevaluated_skipped_case_count",
        "truncated_case_count",
        "zero_crossing_unlink_certified_case_count",
        "scanned_minor_count",
        "expected_minor_combination_count",
        "nonzero_minor_count",
        "zero_minor_count",
        "unit_minor_count",
        "nonzero_evaluated_case_count",
        "nonzero_unique_evaluation_count",
        "nonzero_reused_evaluation_count",
    ]
    source_field_by_count_field = {
        "expected_minor_combination_count": "expected_combination_count",
        "nonzero_unique_evaluation_count": "nonzero_cache_miss_evaluation_count",
        "nonzero_reused_evaluation_count": "nonzero_cache_hit_evaluation_count",
    }
    report_count_totals = {
        field: int(report.get(field, 0) or 0)
        for field in count_fields
    }
    source_count_totals = {}
    for field in count_fields:
        source_field = source_field_by_count_field.get(field, field)
        source_count_totals[field] = sum(
            int(row.get(source_field, row.get(field, 0)) or 0)
            for row in report["source_notation_summary"]
        )

    assert consistency["method"] == (
        "multivariable_alexander_source_notation_summary_consistency"
    )
    assert consistency["claim_scope"] == (
        "generated_signed_pd_report_source_summary_count_consistency"
    )
    assert consistency["matched"] is True
    assert consistency["count_totals_matched"] is True
    assert consistency["source_notation_count_matches_fixture_count"] is True
    assert consistency["fixture_count"] == report["fixture_count"]
    assert consistency["source_notation_count"] == len(
        report["source_notation_summary"]
    )
    assert consistency["compared_count_fields"] == count_fields
    assert consistency["report_count_totals"] == report_count_totals
    assert consistency["source_count_totals"] == source_count_totals
    assert source_count_totals == report_count_totals
    assert consistency["count_matches"] == {
        field: {
            "report_total": report_count_totals[field],
            "source_total": source_count_totals[field],
            "matched": True,
        }
        for field in count_fields
    }
    assert consistency["full_admissible_minor_normalization_certified"] is False
    assert consistency["full_invariant_certified"] is False


def test_multivariable_alexander_signed_pd_coverage_report_certifies_generated_branches() -> None:
    report = multivariable_alexander_signed_pd_coverage_report()

    assert report["method"] == "multivariable_alexander_signed_pd_coverage_report"
    assert report["claim_scope"] == (
        "generated_small_signed_pd_wirtinger_fox_scanned_gcd_coverage"
    )
    assert report["accepted"] is True
    assert report["source_notations"] == ["L2a1", "3_1", "4_1"]
    assert report["fixture_count"] == 3
    assert report["case_count"] == 30
    assert report["non_fixture_case_count"] == 27
    assert report["unique_diagram_count"] == 19
    assert report["unique_oriented_diagram_count"] == 20
    assert report["nonzero_evaluated_case_count"] == 30
    assert report["nonzero_unique_evaluation_count"] == 20
    assert report["nonzero_reused_evaluation_count"] == 10
    _assert_alexander_source_notation_summary_consistency(report)
    cache_evidence = report["nonzero_evaluation_cache_evidence"]
    assert cache_evidence["method"] == (
        "multivariable_alexander_signed_pd_coverage_nonzero_evaluation_cache_evidence"
    )
    assert cache_evidence["claim_scope"] == (
        "generated_signed_pd_nonzero_input_evaluation_reuse_accounting"
    )
    assert cache_evidence["nonzero_evaluated_case_count"] == report[
        "nonzero_evaluated_case_count"
    ]
    assert cache_evidence["nonzero_unique_evaluation_count"] == report[
        "nonzero_unique_evaluation_count"
    ]
    assert cache_evidence["nonzero_reused_evaluation_count"] == report[
        "nonzero_reused_evaluation_count"
    ]
    assert cache_evidence["nonzero_cache_reuse_observed"] is True
    assert cache_evidence["zero_crossing_unlink_case_count"] == 0
    assert cache_evidence["result_skipped_case_count"] == 0
    assert cache_evidence["nonzero_evaluated_result_skipped_case_count"] == 0
    assert cache_evidence["unevaluated_skipped_case_count"] == 0
    assert cache_evidence["accounted_case_count"] == report["case_count"]
    assert cache_evidence["nonzero_evaluation_accounting_complete"] is True
    assert cache_evidence["source_notation_count"] == len(
        report["source_notation_summary"]
    )
    assert cache_evidence["source_case_count"] == report["case_count"]
    assert cache_evidence["source_nonzero_evaluated_case_count"] == report[
        "nonzero_evaluated_case_count"
    ]
    assert cache_evidence["source_nonzero_cache_miss_evaluation_count"] == report[
        "nonzero_unique_evaluation_count"
    ]
    assert cache_evidence["source_nonzero_cache_hit_evaluation_count"] == report[
        "nonzero_reused_evaluation_count"
    ]
    assert cache_evidence["source_zero_crossing_unlink_case_count"] == report[
        "zero_crossing_unlink_certified_case_count"
    ]
    assert cache_evidence["source_result_skipped_case_count"] == report[
        "result_skipped_case_count"
    ]
    assert cache_evidence[
        "source_nonzero_evaluated_result_skipped_case_count"
    ] == cache_evidence["nonzero_evaluated_result_skipped_case_count"]
    assert cache_evidence["source_unevaluated_skipped_case_count"] == (
        cache_evidence["unevaluated_skipped_case_count"]
    )
    assert cache_evidence["source_accounted_case_count"] == report["case_count"]
    assert cache_evidence["source_cache_totals_match_report"] is True
    assert cache_evidence["source_case_accounting_complete"] is True
    assert cache_evidence["full_admissible_minor_normalization_certified"] is False
    assert cache_evidence["full_invariant_certified"] is False
    assert report["accepted_case_count"] == 30
    assert report["uncertified_case_count"] == 0
    assert report["result_skipped_case_count"] == 0
    assert report["truncated_case_count"] == 0
    assert report["relation_error_count"] == 0
    assert report["minor_divisibility_matched_case_count"] == 30
    assert report["bounded_scanned_gcd_certified_case_count"] == 30
    assert report["wirtinger_fox_matched_case_count"] == 30
    assert report["failed_nonzero_minor_count"] == 0
    assert report["invalid_minor_reference_count"] == 0
    assert report["invalid_normalization_count"] == 0
    assert report["max_crossing_count"] == 4
    assert report["full_admissible_minor_normalization_certified"] is False
    assert report["full_invariant_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False
    assert report["bounded_alexander_maturity_path_counts"] == [
        {"bounded_alexander_maturity_path": "exact_scanned_gcd", "case_count": 14},
        {
            "bounded_alexander_maturity_path": (
                "laurent_unit_normalization_consensus"
            ),
            "case_count": 16,
        },
    ]
    assert report["bounded_alexander_maturity_path_distinct_count"] == 2
    assert report["bounded_alexander_maturity_path_certified_count"] == 30
    maturity_consistency = report["bounded_alexander_maturity_path_summary_consistency"]
    assert maturity_consistency["matched"] is True
    assert maturity_consistency["record_count_field"] == "case_count"
    assert maturity_consistency["record_count"] == report["case_count"]
    assert maturity_consistency["path_count_total"] == report["case_count"]
    assert maturity_consistency["path_count_total_matches_record_count"] is True
    assert maturity_consistency["certified_count"] == report["case_count"]
    assert maturity_consistency["certified_count_matches_paths"] is True
    assert maturity_consistency["full_invariant_certified"] is False

    branch_counts = {}
    notation_counts = {}
    for case in report["cases"]:
        branch_counts[case["branch"]] = branch_counts.get(case["branch"], 0) + 1
        notation_counts[case["source_notation"]] = (
            notation_counts.get(case["source_notation"], 0) + 1
        )
        assert case["accepted"] is True
        assert case["result_skipped"] is False
        assert case["minor_divisibility_matched"] is True
        assert case["bounded_scanned_gcd_certified"] is True
        assert case["bounded_alexander_maturity_path_certified"] is True
        assert case["wirtinger_fox_matched"] is True
        assert case["truncated"] is False
        assert case["invalid_minor_reference_count"] == 0
        assert case["invalid_normalization_count"] == 0
        assert case["input_certification_evidence"][
            "bounded_scanned_gcd_certified"
        ] is True
        assert case["wirtinger_fox_audit"]["input_chain_consistent"] is True

    assert branch_counts == {
        "root": 3,
        "positive": 9,
        "negative": 9,
        "smoothed": 9,
    }
    assert notation_counts == {"L2a1": 7, "3_1": 10, "4_1": 13}
    by_source_summary = {
        row["source_notation"]: row for row in report["source_notation_summary"]
    }
    assert list(by_source_summary) == ["L2a1", "3_1", "4_1"]
    assert {
        notation: row["case_count"] for notation, row in by_source_summary.items()
    } == notation_counts
    assert sum(
        row["accepted_case_count"] for row in by_source_summary.values()
    ) == report["accepted_case_count"]
    assert sum(
        row["scanned_minor_count"] for row in by_source_summary.values()
    ) == report["scanned_minor_count"]
    assert sum(
        row["nonzero_evaluated_case_count"]
        for row in by_source_summary.values()
    ) == report["nonzero_evaluated_case_count"]
    assert sum(
        row["nonzero_cache_miss_evaluation_count"]
        for row in by_source_summary.values()
    ) == report["nonzero_unique_evaluation_count"]
    assert sum(
        row["nonzero_cache_hit_evaluation_count"]
        for row in by_source_summary.values()
    ) == report["nonzero_reused_evaluation_count"]
    assert all(row["accepted"] is True for row in by_source_summary.values())
    assert all(
        row["failed_nonzero_minor_count"] == 0
        for row in by_source_summary.values()
    )
    assert all(
        row["nonzero_evaluation_cache_accounted"] is True
        for row in by_source_summary.values()
    )
    assert cache_evidence["source_notation_counts"] == [
        {
            "source_notation": row["source_notation"],
            "case_count": row["case_count"],
            "nonzero_evaluated_case_count": row["nonzero_evaluated_case_count"],
            "nonzero_cache_miss_evaluation_count": row[
                "nonzero_cache_miss_evaluation_count"
            ],
            "nonzero_cache_hit_evaluation_count": row[
                "nonzero_cache_hit_evaluation_count"
            ],
            "zero_crossing_unlink_case_count": row[
                "zero_crossing_unlink_certified_case_count"
            ],
            "result_skipped_case_count": row["result_skipped_case_count"],
            "nonzero_evaluated_result_skipped_case_count": row[
                "nonzero_evaluated_result_skipped_case_count"
            ],
            "unevaluated_skipped_case_count": row[
                "unevaluated_skipped_case_count"
            ],
            "accounted_case_count": (
                row["nonzero_evaluated_case_count"]
                + row["zero_crossing_unlink_certified_case_count"]
                + row["unevaluated_skipped_case_count"]
            ),
            "nonzero_evaluation_cache_accounted": row[
                "nonzero_evaluation_cache_accounted"
            ],
            "case_accounting_complete": (
                row["nonzero_evaluated_case_count"]
                + row["zero_crossing_unlink_certified_case_count"]
                + row["unevaluated_skipped_case_count"]
                == row["case_count"]
            ),
            "nonzero_evaluation_cache_reuse_observed": row[
                "nonzero_evaluation_cache_reuse_observed"
            ],
        }
        for row in report["source_notation_summary"]
    ]
    assert by_source_summary["L2a1"]["branch_counts"] == [
        {"branch": "negative", "case_count": 2},
        {"branch": "positive", "case_count": 2},
        {"branch": "root", "case_count": 1},
        {"branch": "smoothed", "case_count": 2},
    ]


def test_multivariable_alexander_signed_pd_coverage_report_supports_bounded_branch_depth_two() -> None:
    report = multivariable_alexander_signed_pd_coverage_report(
        notations=["L2a1"],
        branch_depth=2,
    )

    assert report["source_notations"] == ["L2a1"]
    assert report["branch_depth"] == 2
    assert report["max_generated_branch_depth"] == 2
    assert report["case_count"] == 37
    assert report["non_fixture_case_count"] == 36
    assert report["unique_diagram_count"] == 7
    assert report["unique_oriented_diagram_count"] == 9
    assert report["accepted"] is True
    assert report["accepted_case_count"] == 37
    assert report["uncertified_case_count"] == 0
    assert report["result_skipped_case_count"] == 0
    assert report["truncated_case_count"] == 0
    assert report["relation_error_count"] == 0
    assert report["minor_divisibility_matched_case_count"] == 35
    assert report["bounded_scanned_gcd_certified_case_count"] == 35
    assert report["wirtinger_fox_matched_case_count"] == 35
    assert report["zero_crossing_unlink_certified_case_count"] == 2
    assert report["nonzero_evaluated_case_count"] == 35
    assert report["nonzero_unique_evaluation_count"] == 8
    assert report["nonzero_reused_evaluation_count"] == 27
    _assert_alexander_source_notation_summary_consistency(report)
    cache_evidence = report["nonzero_evaluation_cache_evidence"]
    assert cache_evidence["nonzero_evaluated_case_count"] == 35
    assert cache_evidence["nonzero_unique_evaluation_count"] == 8
    assert cache_evidence["nonzero_reused_evaluation_count"] == 27
    assert cache_evidence["nonzero_cache_reuse_observed"] is True
    assert cache_evidence["zero_crossing_unlink_case_count"] == 2
    assert cache_evidence["result_skipped_case_count"] == 0
    assert cache_evidence["nonzero_evaluated_result_skipped_case_count"] == 0
    assert cache_evidence["unevaluated_skipped_case_count"] == 0
    assert cache_evidence["accounted_case_count"] == 37
    assert cache_evidence["nonzero_evaluation_accounting_complete"] is True
    assert cache_evidence["source_case_count"] == 37
    assert cache_evidence["source_nonzero_evaluated_case_count"] == 35
    assert cache_evidence["source_nonzero_cache_miss_evaluation_count"] == 8
    assert cache_evidence["source_nonzero_cache_hit_evaluation_count"] == 27
    assert cache_evidence["source_zero_crossing_unlink_case_count"] == 2
    assert cache_evidence["source_result_skipped_case_count"] == 0
    assert cache_evidence[
        "source_nonzero_evaluated_result_skipped_case_count"
    ] == 0
    assert cache_evidence["source_unevaluated_skipped_case_count"] == 0
    assert cache_evidence["source_accounted_case_count"] == 37
    assert cache_evidence["source_cache_totals_match_report"] is True
    assert cache_evidence["source_case_accounting_complete"] is True
    assert report["scanned_minor_count"] == 118
    assert report["failed_nonzero_minor_count"] == 0
    assert len(report["source_notation_summary"]) == 1
    source_summary = report["source_notation_summary"][0]
    assert source_summary["source_notation"] == "L2a1"
    assert source_summary["case_count"] == report["case_count"]
    assert source_summary["accepted_case_count"] == report["accepted_case_count"]
    assert source_summary["unique_diagram_count"] == report["unique_diagram_count"]
    assert source_summary["unique_oriented_diagram_count"] == report[
        "unique_oriented_diagram_count"
    ]
    assert source_summary["scanned_minor_count"] == report["scanned_minor_count"]
    assert source_summary["checked_nonzero_minor_count"] == report[
        "checked_nonzero_minor_count"
    ]
    assert source_summary["zero_crossing_unlink_certified_case_count"] == report[
        "zero_crossing_unlink_certified_case_count"
    ]
    assert source_summary["nonzero_evaluated_case_count"] == 35
    assert source_summary["nonzero_cache_miss_evaluation_count"] == 8
    assert source_summary["nonzero_cache_hit_evaluation_count"] == 27
    assert source_summary["nonzero_evaluated_result_skipped_case_count"] == 0
    assert source_summary["unevaluated_skipped_case_count"] == 0
    assert source_summary["nonzero_evaluation_cache_accounted"] is True
    assert source_summary["nonzero_evaluation_cache_reuse_observed"] is True
    assert cache_evidence["source_notation_counts"] == [
        {
            "source_notation": "L2a1",
            "case_count": 37,
            "nonzero_evaluated_case_count": 35,
            "nonzero_cache_miss_evaluation_count": 8,
            "nonzero_cache_hit_evaluation_count": 27,
            "zero_crossing_unlink_case_count": 2,
            "result_skipped_case_count": 0,
            "nonzero_evaluated_result_skipped_case_count": 0,
            "unevaluated_skipped_case_count": 0,
            "accounted_case_count": 37,
            "nonzero_evaluation_cache_accounted": True,
            "case_accounting_complete": True,
            "nonzero_evaluation_cache_reuse_observed": True,
        },
    ]
    assert source_summary["branch_depth_counts"] == [
        {"branch_depth": 0, "case_count": 1},
        {"branch_depth": 1, "case_count": 6},
        {"branch_depth": 2, "case_count": 30},
    ]
    assert source_summary["source_kind_counts"] == [
        {"source_kind": "fixture_root", "case_count": 1},
        {"source_kind": "multi_step_skein_branch", "case_count": 30},
        {"source_kind": "one_step_skein_branch", "case_count": 6},
    ]
    assert source_summary["accepted"] is True
    branch_depth_counts = {}
    source_kind_counts = {}
    for case in report["cases"]:
        branch_depth_counts[case["branch_depth"]] = (
            branch_depth_counts.get(case["branch_depth"], 0) + 1
        )
        source_kind_counts[case["source_kind"]] = (
            source_kind_counts.get(case["source_kind"], 0) + 1
        )
    assert branch_depth_counts == {0: 1, 1: 6, 2: 30}
    assert source_kind_counts == {
        "fixture_root": 1,
        "one_step_skein_branch": 6,
        "multi_step_skein_branch": 30,
    }
    depth_two = [case for case in report["cases"] if case["branch_depth"] == 2]
    assert all(case["parent_case_id"] for case in depth_two)
    assert all(len(case["branch_path"]) == 2 for case in depth_two)
    zero_crossing_case_ids = {
        case["case_id"]
        for case in report["cases"]
        if case["zero_crossing_unlink_certified"]
    }
    assert zero_crossing_case_ids == {
        "L2a1:0:smoothed|0:smoothed",
        "L2a1:1:smoothed|0:smoothed",
    }
    zero_crossing_cases = [
        case for case in report["cases"] if case["zero_crossing_unlink_certified"]
    ]
    assert all(case["accepted"] is True for case in zero_crossing_cases)
    assert all(case["result_method"] == "zero_crossing_unlink_normalization" for case in zero_crossing_cases)
    assert all(case["multivariable_alexander_polynomial"] == "0" for case in zero_crossing_cases)
    assert all(case["bounded_scanned_gcd_certified"] is False for case in zero_crossing_cases)
    assert all(case["complete_scanned_gcd_certified"] is False for case in zero_crossing_cases)
    assert all(
        case["input_certification_evidence"]["claim_scope"]
        == "zero_crossing_unlink_terminal_normalization"
        for case in zero_crossing_cases
    )


def test_multivariable_alexander_signed_pd_coverage_cache_evidence_accounts_evaluated_skips() -> None:
    report = multivariable_alexander_signed_pd_coverage_report(
        notations=["L2a1"],
        max_matrix_size=0,
    )

    assert report["accepted"] is False
    assert report["case_count"] == 7
    assert report["accepted_case_count"] == 2
    assert report["result_skipped_case_count"] == 5
    assert report["nonzero_evaluated_case_count"] == 7
    assert report["nonzero_unique_evaluation_count"] == 5
    assert report["nonzero_reused_evaluation_count"] == 2
    _assert_alexander_source_notation_summary_consistency(report)

    cache_evidence = report["nonzero_evaluation_cache_evidence"]
    assert cache_evidence["result_skipped_case_count"] == 5
    assert cache_evidence["nonzero_evaluated_result_skipped_case_count"] == 5
    assert cache_evidence["unevaluated_skipped_case_count"] == 0
    assert cache_evidence["accounted_case_count"] == report["case_count"]
    assert cache_evidence["nonzero_evaluation_accounting_complete"] is True
    assert cache_evidence["source_case_count"] == report["case_count"]
    assert cache_evidence["source_result_skipped_case_count"] == report[
        "result_skipped_case_count"
    ]
    assert cache_evidence[
        "source_nonzero_evaluated_result_skipped_case_count"
    ] == cache_evidence["nonzero_evaluated_result_skipped_case_count"]
    assert cache_evidence["source_unevaluated_skipped_case_count"] == 0
    assert cache_evidence["source_accounted_case_count"] == report["case_count"]
    assert cache_evidence["source_cache_totals_match_report"] is True
    assert cache_evidence["source_case_accounting_complete"] is True

    assert cache_evidence["full_admissible_minor_normalization_certified"] is False
    assert cache_evidence["full_invariant_certified"] is False
    assert report["full_admissible_minor_normalization_certified"] is False
    assert report["full_invariant_certified"] is False


def test_multivariable_alexander_signed_pd_coverage_depth_two_extends_knot_fixtures() -> None:
    expected = {
        "3_1": {
            "case_count": 82,
            "unique_diagram_count": 11,
            "minor_divisibility_matched_case_count": 82,
            "bounded_scanned_gcd_certified_case_count": 82,
            "wirtinger_fox_matched_case_count": 82,
            "zero_crossing_unlink_certified_case_count": 0,
            "complete_scan_case_count": 82,
            "nonzero_minor_coverage_complete_case_count": 76,
            "complete_scanned_gcd_certified_case_count": 76,
            "scanned_minor_count": 549,
            "checked_nonzero_minor_count": 549,
            "max_crossing_count": 3,
            "branch_counts": {0: 1, 1: 9, 2: 72},
        },
        "4_1": {
            "case_count": 145,
            "unique_diagram_count": 32,
            "accepted": False,
            "accepted_case_count": 141,
            "uncertified_case_count": 4,
            "result_skipped_case_count": 4,
            "minor_divisibility_matched_case_count": 141,
            "bounded_scanned_gcd_certified_case_count": 141,
            "wirtinger_fox_matched_case_count": 141,
            "zero_crossing_unlink_certified_case_count": 0,
            "complete_scan_case_count": 141,
            "nonzero_minor_coverage_complete_case_count": 133,
            "complete_scanned_gcd_certified_case_count": 133,
            "scanned_minor_count": 1812,
            "checked_nonzero_minor_count": 1716,
            "max_crossing_count": 4,
            "branch_counts": {0: 1, 1: 12, 2: 132},
        },
    }

    for notation, metrics in expected.items():
        report = multivariable_alexander_signed_pd_coverage_report(
            notations=[notation],
            branch_depth=2,
        )

        assert report["source_notations"] == [notation]
        assert report["branch_depth"] == 2
        assert report["max_generated_branch_depth"] == 2
        assert report["case_count"] == metrics["case_count"]
        assert report["non_fixture_case_count"] == metrics["case_count"] - 1
        assert report["unique_diagram_count"] == metrics["unique_diagram_count"]
        assert report["accepted"] is metrics.get("accepted", True)
        assert report["accepted_case_count"] == metrics.get(
            "accepted_case_count", metrics["case_count"]
        )
        assert report["uncertified_case_count"] == metrics.get(
            "uncertified_case_count", 0
        )
        assert report["result_skipped_case_count"] == metrics.get(
            "result_skipped_case_count", 0
        )
        assert report["truncated_case_count"] == 0
        assert report["relation_error_count"] == 0
        assert (
            report["minor_divisibility_matched_case_count"]
            == metrics["minor_divisibility_matched_case_count"]
        )
        assert (
            report["bounded_scanned_gcd_certified_case_count"]
            == metrics["bounded_scanned_gcd_certified_case_count"]
        )
        assert (
            report["wirtinger_fox_matched_case_count"]
            == metrics["wirtinger_fox_matched_case_count"]
        )
        assert (
            report["zero_crossing_unlink_certified_case_count"]
            == metrics["zero_crossing_unlink_certified_case_count"]
        )
        assert report["complete_scan_case_count"] == metrics["complete_scan_case_count"]
        assert (
            report["nonzero_minor_coverage_complete_case_count"]
            == metrics["nonzero_minor_coverage_complete_case_count"]
        )
        assert (
            report["complete_scanned_gcd_certified_case_count"]
            == metrics["complete_scanned_gcd_certified_case_count"]
        )
        assert report["scanned_minor_count"] == metrics["scanned_minor_count"]
        assert (
            report["checked_nonzero_minor_count"]
            == metrics["checked_nonzero_minor_count"]
        )
        assert report["failed_nonzero_minor_count"] == 0
        assert report["invalid_minor_reference_count"] == 0
        assert report["invalid_normalization_count"] == 0
        assert report["max_crossing_count"] == metrics["max_crossing_count"]

        branch_depth_counts = {}
        source_kind_counts = {}
        for case in report["cases"]:
            branch_depth_counts[case["branch_depth"]] = (
                branch_depth_counts.get(case["branch_depth"], 0) + 1
            )
            source_kind_counts[case["source_kind"]] = (
                source_kind_counts.get(case["source_kind"], 0) + 1
            )
            if case["result_skipped"]:
                assert notation == "4_1"
                assert case["accepted"] is False
                assert case["minor_divisibility_matched"] is False
                assert case["bounded_scanned_gcd_certified"] is False
                continue
            assert case["minor_divisibility_matched"] is True
            assert case["bounded_scanned_gcd_certified"] is True
            assert case["zero_crossing_unlink_certified"] is False
            assert case["truncated"] is False
            assert case["failed_nonzero_minor_count"] == 0
            assert case["invalid_minor_reference_count"] == 0
            assert case["invalid_normalization_count"] == 0
            if case["accepted"]:
                assert case["wirtinger_fox_matched"] is True
            else:
                assert notation == "4_1"
                assert case["wirtinger_fox_matched"] is False

        assert branch_depth_counts == metrics["branch_counts"]
        assert source_kind_counts == {
            "fixture_root": 1,
            "one_step_skein_branch": metrics["branch_counts"][1],
            "multi_step_skein_branch": metrics["branch_counts"][2],
        }
        depth_two = [case for case in report["cases"] if case["branch_depth"] == 2]
        assert all(case["parent_case_id"] for case in depth_two)
        assert all(len(case["branch_path"]) == 2 for case in depth_two)


def test_multivariable_alexander_signed_pd_coverage_depth_three_extends_generated_frontier() -> None:
    expected = {
        "L2a1": {
            "case_count": 169,
            "unique_diagram_count": 7,
            "minor_divisibility_matched_case_count": 155,
            "bounded_scanned_gcd_certified_case_count": 155,
            "wirtinger_fox_matched_case_count": 155,
            "zero_crossing_unlink_certified_case_count": 14,
            "complete_scan_case_count": 155,
            "nonzero_minor_coverage_complete_case_count": 85,
            "complete_scanned_gcd_certified_case_count": 85,
            "scanned_minor_count": 494,
            "checked_nonzero_minor_count": 494,
            "max_crossing_count": 2,
            "branch_counts": {0: 1, 1: 6, 2: 30, 3: 132},
            "source_kind_counts": {
                "fixture_root": 1,
                "one_step_skein_branch": 6,
                "multi_step_skein_branch": 162,
            },
        },
        "3_1": {
            "case_count": 604,
            "unique_diagram_count": 15,
            "minor_divisibility_matched_case_count": 598,
            "bounded_scanned_gcd_certified_case_count": 598,
            "wirtinger_fox_matched_case_count": 598,
            "zero_crossing_unlink_certified_case_count": 6,
            "complete_scan_case_count": 598,
            "nonzero_minor_coverage_complete_case_count": 520,
            "complete_scanned_gcd_certified_case_count": 520,
            "scanned_minor_count": 3693,
            "checked_nonzero_minor_count": 3693,
            "max_crossing_count": 3,
            "branch_counts": {0: 1, 1: 9, 2: 72, 3: 522},
            "source_kind_counts": {
                "fixture_root": 1,
                "one_step_skein_branch": 9,
                "multi_step_skein_branch": 594,
            },
        },
        "4_1": {
            "case_count": 1489,
            "unique_diagram_count": 68,
            "accepted": False,
            "accepted_case_count": 1389,
            "uncertified_case_count": 100,
            "result_skipped_case_count": 100,
            "minor_divisibility_matched_case_count": 1389,
            "bounded_scanned_gcd_certified_case_count": 1389,
            "wirtinger_fox_matched_case_count": 1389,
            "zero_crossing_unlink_certified_case_count": 0,
            "complete_scan_case_count": 1389,
            "nonzero_minor_coverage_complete_case_count": 1261,
            "complete_scanned_gcd_certified_case_count": 1261,
            "scanned_minor_count": 16988,
            "checked_nonzero_minor_count": 15452,
            "max_crossing_count": 4,
            "branch_counts": {0: 1, 1: 12, 2: 132, 3: 1344},
            "source_kind_counts": {
                "fixture_root": 1,
                "one_step_skein_branch": 12,
                "multi_step_skein_branch": 1476,
            },
        },
    }

    for notation, metrics in expected.items():
        report = multivariable_alexander_signed_pd_coverage_report(
            notations=[notation],
            branch_depth=3,
        )

        assert report["source_notations"] == [notation]
        assert report["branch_depth"] == 3
        assert report["max_generated_branch_depth"] == 3
        assert report["case_count"] == metrics["case_count"]
        assert report["non_fixture_case_count"] == metrics["case_count"] - 1
        assert report["unique_diagram_count"] == metrics["unique_diagram_count"]
        assert report["accepted"] is metrics.get("accepted", True)
        assert report["accepted_case_count"] == metrics.get(
            "accepted_case_count", metrics["case_count"]
        )
        assert report["uncertified_case_count"] == metrics.get(
            "uncertified_case_count", 0
        )
        assert report["result_skipped_case_count"] == metrics.get(
            "result_skipped_case_count", 0
        )
        assert report["truncated_case_count"] == 0
        assert report["relation_error_count"] == 0
        assert (
            report["minor_divisibility_matched_case_count"]
            == metrics["minor_divisibility_matched_case_count"]
        )
        assert (
            report["bounded_scanned_gcd_certified_case_count"]
            == metrics["bounded_scanned_gcd_certified_case_count"]
        )
        assert (
            report["wirtinger_fox_matched_case_count"]
            == metrics["wirtinger_fox_matched_case_count"]
        )
        assert (
            report["zero_crossing_unlink_certified_case_count"]
            == metrics["zero_crossing_unlink_certified_case_count"]
        )
        assert report["complete_scan_case_count"] == metrics["complete_scan_case_count"]
        assert (
            report["nonzero_minor_coverage_complete_case_count"]
            == metrics["nonzero_minor_coverage_complete_case_count"]
        )
        assert (
            report["complete_scanned_gcd_certified_case_count"]
            == metrics["complete_scanned_gcd_certified_case_count"]
        )
        assert report["scanned_minor_count"] == metrics["scanned_minor_count"]
        assert (
            report["checked_nonzero_minor_count"]
            == metrics["checked_nonzero_minor_count"]
        )
        assert report["failed_nonzero_minor_count"] == 0
        assert report["invalid_minor_reference_count"] == 0
        assert report["invalid_normalization_count"] == 0
        assert report["max_crossing_count"] == metrics["max_crossing_count"]
        assert Counter(case["branch_depth"] for case in report["cases"]) == metrics[
            "branch_counts"
        ]
        assert Counter(case["source_kind"] for case in report["cases"]) == metrics[
            "source_kind_counts"
        ]

        for case in report["cases"]:
            assert case["truncated"] is False
            assert case["failed_nonzero_minor_count"] == 0
            assert case["invalid_minor_reference_count"] == 0
            assert case["invalid_normalization_count"] == 0
            if case["result_skipped"]:
                assert notation == "4_1"
                assert case["accepted"] is False
                assert case["minor_divisibility_matched"] is False
                assert case["bounded_scanned_gcd_certified"] is False
                continue
            if case["zero_crossing_unlink_certified"]:
                assert case["result_method"] == "zero_crossing_unlink_normalization"
                assert case["bounded_scanned_gcd_certified"] is False
                assert case["complete_scanned_gcd_certified"] is False
                assert case["input_certification_evidence"]["claim_scope"] == (
                    "zero_crossing_unlink_terminal_normalization"
                )
            else:
                assert case["minor_divisibility_matched"] is True
                assert case["bounded_scanned_gcd_certified"] is True
                if case["accepted"]:
                    assert case["wirtinger_fox_matched"] is True
                else:
                    assert notation == "4_1"
                    assert case["wirtinger_fox_matched"] is False
                assert case["complete_scanned_gcd_certified"] is (
                    case["nonzero_minor_coverage_complete"]
                )

        depth_three = [case for case in report["cases"] if case["branch_depth"] == 3]
        assert depth_three
        assert all(case["parent_case_id"] for case in depth_three)
        assert all(len(case["branch_path"]) == 3 for case in depth_three)
        assert report["full_admissible_minor_normalization_certified"] is False
        assert report["full_invariant_certified"] is False
        assert report["arbitrary_diagram_coverage_certified"] is False


def test_multivariable_alexander_signed_pd_coverage_depth_four_extends_generated_frontier() -> None:
    expected = {
        "L2a1": {
            "case_count": 721,
            "unique_diagram_count": 7,
            "minor_divisibility_matched_case_count": 651,
            "bounded_scanned_gcd_certified_case_count": 651,
            "wirtinger_fox_matched_case_count": 651,
            "zero_crossing_unlink_certified_case_count": 70,
            "complete_scan_case_count": 651,
            "nonzero_minor_coverage_complete_case_count": 341,
            "complete_scanned_gcd_certified_case_count": 341,
            "scanned_minor_count": 2014,
            "checked_nonzero_minor_count": 2014,
            "max_crossing_count": 2,
            "branch_counts": {0: 1, 1: 6, 2: 30, 3: 132, 4: 552},
        },
        "3_1": {
            "case_count": 4132,
            "unique_diagram_count": 15,
            "minor_divisibility_matched_case_count": 4054,
            "bounded_scanned_gcd_certified_case_count": 4054,
            "wirtinger_fox_matched_case_count": 4054,
            "zero_crossing_unlink_certified_case_count": 78,
            "complete_scan_case_count": 4054,
            "nonzero_minor_coverage_complete_case_count": 3376,
            "complete_scanned_gcd_certified_case_count": 3376,
            "scanned_minor_count": 23733,
            "checked_nonzero_minor_count": 23733,
            "max_crossing_count": 3,
            "branch_counts": {0: 1, 1: 9, 2: 72, 3: 522, 4: 3528},
        },
        "4_1": {
            "case_count": 14329,
            "unique_diagram_count": 99,
            "accepted": False,
            "accepted_case_count": 12869,
            "uncertified_case_count": 1460,
            "result_skipped_case_count": 1460,
            "minor_divisibility_matched_case_count": 12845,
            "bounded_scanned_gcd_certified_case_count": 12845,
            "wirtinger_fox_matched_case_count": 12845,
            "zero_crossing_unlink_certified_case_count": 24,
            "complete_scan_case_count": 12845,
            "nonzero_minor_coverage_complete_case_count": 11437,
            "complete_scanned_gcd_certified_case_count": 11437,
            "scanned_minor_count": 151484,
            "checked_nonzero_minor_count": 134588,
            "max_crossing_count": 4,
            "branch_counts": {0: 1, 1: 12, 2: 132, 3: 1344, 4: 12840},
        },
    }

    for notation, metrics in expected.items():
        report = multivariable_alexander_signed_pd_coverage_report(
            notations=[notation],
            branch_depth=4,
        )

        assert report["source_notations"] == [notation]
        assert report["branch_depth"] == 4
        assert report["max_generated_branch_depth"] == 4
        assert report["case_count"] == metrics["case_count"]
        assert report["non_fixture_case_count"] == metrics["case_count"] - 1
        assert report["unique_diagram_count"] == metrics["unique_diagram_count"]
        assert report["accepted"] is metrics.get("accepted", True)
        assert report["accepted_case_count"] == metrics.get(
            "accepted_case_count", metrics["case_count"]
        )
        assert report["uncertified_case_count"] == metrics.get(
            "uncertified_case_count", 0
        )
        assert report["result_skipped_case_count"] == metrics.get(
            "result_skipped_case_count", 0
        )
        assert report["truncated_case_count"] == 0
        assert report["relation_error_count"] == 0
        assert (
            report["minor_divisibility_matched_case_count"]
            == metrics["minor_divisibility_matched_case_count"]
        )
        assert (
            report["bounded_scanned_gcd_certified_case_count"]
            == metrics["bounded_scanned_gcd_certified_case_count"]
        )
        assert (
            report["wirtinger_fox_matched_case_count"]
            == metrics["wirtinger_fox_matched_case_count"]
        )
        assert (
            report["zero_crossing_unlink_certified_case_count"]
            == metrics["zero_crossing_unlink_certified_case_count"]
        )
        assert report["complete_scan_case_count"] == metrics["complete_scan_case_count"]
        assert (
            report["nonzero_minor_coverage_complete_case_count"]
            == metrics["nonzero_minor_coverage_complete_case_count"]
        )
        assert (
            report["complete_scanned_gcd_certified_case_count"]
            == metrics["complete_scanned_gcd_certified_case_count"]
        )
        assert report["scanned_minor_count"] == metrics["scanned_minor_count"]
        assert (
            report["checked_nonzero_minor_count"]
            == metrics["checked_nonzero_minor_count"]
        )
        assert report["failed_nonzero_minor_count"] == 0
        assert report["invalid_minor_reference_count"] == 0
        assert report["invalid_normalization_count"] == 0
        assert report["max_crossing_count"] == metrics["max_crossing_count"]
        assert Counter(case["branch_depth"] for case in report["cases"]) == metrics[
            "branch_counts"
        ]
        depth_four = [case for case in report["cases"] if case["branch_depth"] == 4]
        assert depth_four
        assert all(case["parent_case_id"] for case in depth_four)
        assert all(len(case["branch_path"]) == 4 for case in depth_four)
        assert (
            sum(1 for case in report["cases"] if case["accepted"])
            == metrics.get("accepted_case_count", metrics["case_count"])
        )
        for case in report["cases"]:
            if case["result_skipped"]:
                assert notation == "4_1"
                assert case["accepted"] is False
                assert case["minor_divisibility_matched"] is False
                assert case["bounded_scanned_gcd_certified"] is False
                continue
            if not case["accepted"]:
                assert notation == "4_1"
                assert case["wirtinger_fox_matched"] is False
                assert case["minor_divisibility_matched"] is True
                assert case["bounded_scanned_gcd_certified"] is True
                assert case["result_skipped"] is False
                assert case["truncated"] is False
        assert sum(
            1 for case in report["cases"] if case["result_skipped"]
        ) == metrics.get("result_skipped_case_count", 0)
        assert all(case["truncated"] is False for case in report["cases"])
        assert report["full_admissible_minor_normalization_certified"] is False
        assert report["full_invariant_certified"] is False
        assert report["arbitrary_diagram_coverage_certified"] is False


def test_multivariable_alexander_signed_pd_coverage_depth_five_extends_hopf_frontier() -> None:
    report = multivariable_alexander_signed_pd_coverage_report(
        notations=["L2a1"],
        branch_depth=5,
    )

    assert report["source_notations"] == ["L2a1"]
    assert report["branch_depth"] == 5
    assert report["max_generated_branch_depth"] == 5
    assert report["case_count"] == 2977
    assert report["non_fixture_case_count"] == 2976
    assert report["unique_diagram_count"] == 7
    assert report["unique_oriented_diagram_count"] == 9
    assert report["accepted"] is True
    assert report["accepted_case_count"] == 2977
    assert report["uncertified_case_count"] == 0
    assert report["result_skipped_case_count"] == 0
    assert report["truncated_case_count"] == 0
    assert report["relation_error_count"] == 0
    assert report["minor_divisibility_matched_case_count"] == 2667
    assert report["bounded_scanned_gcd_certified_case_count"] == 2667
    assert report["wirtinger_fox_matched_case_count"] == 2667
    assert report["zero_crossing_unlink_certified_case_count"] == 310
    assert report["complete_scan_case_count"] == 2667
    assert report["nonzero_minor_coverage_complete_case_count"] == 1365
    assert report["complete_scanned_gcd_certified_case_count"] == 1365
    assert report["scanned_minor_count"] == 8126
    assert report["checked_nonzero_minor_count"] == 8126
    assert report["failed_nonzero_minor_count"] == 0
    assert report["invalid_minor_reference_count"] == 0
    assert report["invalid_normalization_count"] == 0
    assert report["max_crossing_count"] == 2
    assert Counter(case["branch_depth"] for case in report["cases"]) == {
        0: 1,
        1: 6,
        2: 30,
        3: 132,
        4: 552,
        5: 2256,
    }
    assert Counter(case["source_kind"] for case in report["cases"]) == {
        "fixture_root": 1,
        "one_step_skein_branch": 6,
        "multi_step_skein_branch": 2970,
    }
    source_summary = report["source_notation_summary"][0]
    assert source_summary["source_notation"] == "L2a1"
    assert source_summary["case_count"] == report["case_count"]
    assert source_summary["accepted_case_count"] == report["accepted_case_count"]
    assert source_summary["scanned_minor_count"] == report["scanned_minor_count"]
    assert source_summary["zero_crossing_unlink_certified_case_count"] == report[
        "zero_crossing_unlink_certified_case_count"
    ]
    assert source_summary["branch_depth_counts"][-1] == {
        "branch_depth": 5,
        "case_count": 2256,
    }
    assert all(case["accepted"] for case in report["cases"])
    assert all(case["result_skipped"] is False for case in report["cases"])
    assert all(case["truncated"] is False for case in report["cases"])
    assert report["full_admissible_minor_normalization_certified"] is False
    assert report["full_invariant_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False


def test_multivariable_alexander_signed_pd_coverage_depth_six_extends_hopf_frontier() -> None:
    report = multivariable_alexander_signed_pd_coverage_report(
        notations=["L2a1"],
        branch_depth=6,
    )

    assert report["source_notations"] == ["L2a1"]
    assert report["branch_depth"] == 6
    assert report["max_generated_branch_depth"] == 6
    assert report["case_count"] == 12097
    assert report["non_fixture_case_count"] == 12096
    assert report["unique_diagram_count"] == 7
    assert report["unique_oriented_diagram_count"] == 9
    assert report["nonzero_unique_evaluation_count"] == 8
    assert report["nonzero_reused_evaluation_count"] == 10787
    assert report["accepted"] is True
    assert report["accepted_case_count"] == 12097
    assert report["uncertified_case_count"] == 0
    assert report["result_skipped_case_count"] == 0
    assert report["truncated_case_count"] == 0
    assert report["relation_error_count"] == 0
    assert report["minor_divisibility_matched_case_count"] == 10795
    assert report["bounded_scanned_gcd_certified_case_count"] == 10795
    assert report["wirtinger_fox_matched_case_count"] == 10795
    assert report["zero_crossing_unlink_certified_case_count"] == 1302
    assert report["complete_scan_case_count"] == 10795
    assert report["nonzero_minor_coverage_complete_case_count"] == 5461
    assert report["complete_scanned_gcd_certified_case_count"] == 5461
    assert report["scanned_minor_count"] == 32638
    assert report["checked_nonzero_minor_count"] == 32638
    assert report["failed_nonzero_minor_count"] == 0
    assert report["invalid_minor_reference_count"] == 0
    assert report["invalid_normalization_count"] == 0
    assert report["max_crossing_count"] == 2
    assert Counter(case["branch_depth"] for case in report["cases"]) == {
        0: 1,
        1: 6,
        2: 30,
        3: 132,
        4: 552,
        5: 2256,
        6: 9120,
    }
    assert Counter(case["source_kind"] for case in report["cases"]) == {
        "fixture_root": 1,
        "one_step_skein_branch": 6,
        "multi_step_skein_branch": 12090,
    }
    source_summary = report["source_notation_summary"][0]
    assert source_summary["source_notation"] == "L2a1"
    assert source_summary["case_count"] == report["case_count"]
    assert source_summary["accepted_case_count"] == report["accepted_case_count"]
    assert source_summary["scanned_minor_count"] == report["scanned_minor_count"]
    assert source_summary["zero_crossing_unlink_certified_case_count"] == report[
        "zero_crossing_unlink_certified_case_count"
    ]
    assert source_summary["branch_depth_counts"][-1] == {
        "branch_depth": 6,
        "case_count": 9120,
    }
    assert all(case["accepted"] for case in report["cases"])
    assert all(case["result_skipped"] is False for case in report["cases"])
    assert all(case["truncated"] is False for case in report["cases"])
    assert report["full_admissible_minor_normalization_certified"] is False
    assert report["full_invariant_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False


def test_multivariable_alexander_signed_pd_coverage_depth_five_extends_trefoil_frontier() -> None:
    report = multivariable_alexander_signed_pd_coverage_report(
        notations=["3_1"],
        branch_depth=5,
    )

    assert report["source_notations"] == ["3_1"]
    assert report["branch_depth"] == 5
    assert report["max_generated_branch_depth"] == 5
    assert report["case_count"] == 26956
    assert report["non_fixture_case_count"] == 26955
    assert report["unique_diagram_count"] == 15
    assert report["unique_oriented_diagram_count"] == 29
    assert report["accepted"] is True
    assert report["accepted_case_count"] == 26956
    assert report["uncertified_case_count"] == 0
    assert report["result_skipped_case_count"] == 0
    assert report["truncated_case_count"] == 0
    assert report["relation_error_count"] == 0
    assert report["minor_divisibility_matched_case_count"] == 26278
    assert report["bounded_scanned_gcd_certified_case_count"] == 26278
    assert report["wirtinger_fox_matched_case_count"] == 26278
    assert report["zero_crossing_unlink_certified_case_count"] == 678
    assert report["complete_scan_case_count"] == 26278
    assert report["nonzero_minor_coverage_complete_case_count"] == 21280
    assert report["complete_scanned_gcd_certified_case_count"] == 21280
    assert report["scanned_minor_count"] == 148629
    assert report["checked_nonzero_minor_count"] == 148629
    assert report["failed_nonzero_minor_count"] == 0
    assert report["invalid_minor_reference_count"] == 0
    assert report["invalid_normalization_count"] == 0
    assert report["max_crossing_count"] == 3
    assert Counter(case["branch_depth"] for case in report["cases"]) == {
        0: 1,
        1: 9,
        2: 72,
        3: 522,
        4: 3528,
        5: 22824,
    }
    assert Counter(case["source_kind"] for case in report["cases"]) == {
        "fixture_root": 1,
        "one_step_skein_branch": 9,
        "multi_step_skein_branch": 26946,
    }
    source_summary = report["source_notation_summary"][0]
    assert source_summary["source_notation"] == "3_1"
    assert source_summary["case_count"] == report["case_count"]
    assert source_summary["accepted_case_count"] == report["accepted_case_count"]
    assert source_summary["scanned_minor_count"] == report["scanned_minor_count"]
    assert source_summary["zero_crossing_unlink_certified_case_count"] == report[
        "zero_crossing_unlink_certified_case_count"
    ]
    assert source_summary["branch_depth_counts"][-1] == {
        "branch_depth": 5,
        "case_count": 22824,
    }
    assert all(case["accepted"] for case in report["cases"])
    assert all(case["result_skipped"] is False for case in report["cases"])
    assert all(case["truncated"] is False for case in report["cases"])
    assert report["full_admissible_minor_normalization_certified"] is False
    assert report["full_invariant_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False


def test_multivariable_alexander_signed_pd_coverage_depth_six_extends_trefoil_frontier() -> None:
    report = multivariable_alexander_signed_pd_coverage_report(
        notations=["3_1"],
        branch_depth=6,
    )

    assert report["source_notations"] == ["3_1"]
    assert report["branch_depth"] == 6
    assert report["max_generated_branch_depth"] == 6
    assert report["case_count"] == 170668
    assert report["non_fixture_case_count"] == 170667
    assert report["unique_diagram_count"] == 15
    assert report["unique_oriented_diagram_count"] == 29
    assert report["nonzero_unique_evaluation_count"] == 28
    assert report["nonzero_reused_evaluation_count"] == 165642
    assert report["accepted"] is True
    assert report["accepted_case_count"] == 170668
    assert report["uncertified_case_count"] == 0
    assert report["result_skipped_case_count"] == 0
    assert report["truncated_case_count"] == 0
    assert report["relation_error_count"] == 0
    assert report["minor_divisibility_matched_case_count"] == 165670
    assert report["bounded_scanned_gcd_certified_case_count"] == 165670
    assert report["wirtinger_fox_matched_case_count"] == 165670
    assert report["zero_crossing_unlink_certified_case_count"] == 4998
    assert report["complete_scan_case_count"] == 165670
    assert report["nonzero_minor_coverage_complete_case_count"] == 131776
    assert report["complete_scanned_gcd_certified_case_count"] == 131776
    assert report["scanned_minor_count"] == 916533
    assert report["checked_nonzero_minor_count"] == 916533
    assert report["failed_nonzero_minor_count"] == 0
    assert report["invalid_minor_reference_count"] == 0
    assert report["invalid_normalization_count"] == 0
    assert report["max_crossing_count"] == 3
    assert Counter(case["branch_depth"] for case in report["cases"]) == {
        0: 1,
        1: 9,
        2: 72,
        3: 522,
        4: 3528,
        5: 22824,
        6: 143712,
    }
    assert Counter(case["source_kind"] for case in report["cases"]) == {
        "fixture_root": 1,
        "one_step_skein_branch": 9,
        "multi_step_skein_branch": 170658,
    }
    source_summary = report["source_notation_summary"][0]
    assert source_summary["source_notation"] == "3_1"
    assert source_summary["case_count"] == report["case_count"]
    assert source_summary["accepted_case_count"] == report["accepted_case_count"]
    assert source_summary["scanned_minor_count"] == report["scanned_minor_count"]
    assert source_summary["zero_crossing_unlink_certified_case_count"] == report[
        "zero_crossing_unlink_certified_case_count"
    ]
    assert source_summary["branch_depth_counts"][-1] == {
        "branch_depth": 6,
        "case_count": 143712,
    }
    assert all(case["accepted"] for case in report["cases"])
    assert all(case["result_skipped"] is False for case in report["cases"])
    assert all(case["truncated"] is False for case in report["cases"])
    assert report["full_admissible_minor_normalization_certified"] is False
    assert report["full_invariant_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False


def test_multivariable_alexander_signed_pd_coverage_depth_five_extends_figure_eight_frontier() -> None:
    report = multivariable_alexander_signed_pd_coverage_report(
        notations=["4_1"],
        branch_depth=5,
    )

    assert report["source_notations"] == ["4_1"]
    assert report["branch_depth"] == 5
    assert report["max_generated_branch_depth"] == 5
    assert report["case_count"] == 131161
    assert report["non_fixture_case_count"] == 131160
    assert report["unique_diagram_count"] == 112
    assert report["unique_oriented_diagram_count"] == 281
    assert report["nonzero_unique_evaluation_count"] == 280
    assert report["nonzero_reused_evaluation_count"] == 130377
    assert report["accepted"] is False
    assert report["accepted_case_count"] == 114341
    assert report["uncertified_case_count"] == 16820
    assert report["result_skipped_case_count"] == 16820
    assert report["truncated_case_count"] == 0
    assert report["relation_error_count"] == 0
    assert report["minor_divisibility_matched_case_count"] == 113837
    assert report["bounded_scanned_gcd_certified_case_count"] == 113837
    assert report["wirtinger_fox_matched_case_count"] == 113837
    assert report["zero_crossing_unlink_certified_case_count"] == 504
    assert report["complete_scan_case_count"] == 113837
    assert report["nonzero_minor_coverage_complete_case_count"] == 100429
    assert report["complete_scanned_gcd_certified_case_count"] == 100429
    assert report["scanned_minor_count"] == 1306588
    assert report["checked_nonzero_minor_count"] == 1145692
    assert report["failed_nonzero_minor_count"] == 0
    assert report["invalid_minor_reference_count"] == 0
    assert report["invalid_normalization_count"] == 0
    assert report["max_crossing_count"] == 4
    assert Counter(case["branch_depth"] for case in report["cases"]) == {
        0: 1,
        1: 12,
        2: 132,
        3: 1344,
        4: 12840,
        5: 116832,
    }
    assert Counter(case["source_kind"] for case in report["cases"]) == {
        "fixture_root": 1,
        "one_step_skein_branch": 12,
        "multi_step_skein_branch": 131148,
    }
    source_summary = report["source_notation_summary"][0]
    assert source_summary["source_notation"] == "4_1"
    assert source_summary["case_count"] == report["case_count"]
    assert source_summary["accepted_case_count"] == report["accepted_case_count"]
    assert source_summary["scanned_minor_count"] == report["scanned_minor_count"]
    assert source_summary["zero_crossing_unlink_certified_case_count"] == report[
        "zero_crossing_unlink_certified_case_count"
    ]
    assert source_summary["branch_depth_counts"][-1] == {
        "branch_depth": 5,
        "case_count": 116832,
    }
    assert sum(1 for case in report["cases"] if case["accepted"]) == 114341
    assert all(
        case["wirtinger_fox_matched"] is False
        for case in report["cases"]
        if not case["accepted"]
    )
    assert sum(1 for case in report["cases"] if case["result_skipped"]) == 16820
    assert all(case["truncated"] is False for case in report["cases"])
    assert report["full_admissible_minor_normalization_certified"] is False
    assert report["full_invariant_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False


@pytest.mark.skipif(
    os.environ.get("IROLL_RUN_DEEP_COVERAGE") != "1",
    reason=(
        "Set IROLL_RUN_DEEP_COVERAGE=1 to run the 1.15M-case "
        "Alexander 4_1 depth-six generated coverage audit."
    ),
)
def test_multivariable_alexander_signed_pd_coverage_depth_six_extends_figure_eight_frontier() -> None:
    report = multivariable_alexander_signed_pd_coverage_report(
        notations=["4_1"],
        branch_depth=6,
    )

    assert report["source_notations"] == ["4_1"]
    assert report["branch_depth"] == 6
    assert report["max_generated_branch_depth"] == 6
    assert report["case_count"] == 1157113
    assert report["non_fixture_case_count"] == 1157112
    assert report["unique_diagram_count"] == 115
    assert report["unique_oriented_diagram_count"] == 315
    assert report["nonzero_unique_evaluation_count"] == 314
    assert report["nonzero_reused_evaluation_count"] == 1150055
    assert report["accepted"] is False
    assert report["accepted_case_count"] == 986629
    assert report["uncertified_case_count"] == 170484
    assert report["result_skipped_case_count"] == 170484
    assert report["truncated_case_count"] == 0
    assert report["relation_error_count"] == 0
    assert report["minor_divisibility_matched_case_count"] == 979885
    assert report["bounded_scanned_gcd_certified_case_count"] == 979885
    assert report["wirtinger_fox_matched_case_count"] == 979885
    assert report["zero_crossing_unlink_certified_case_count"] == 6744
    assert report["complete_scan_case_count"] == 979885
    assert report["nonzero_minor_coverage_complete_case_count"] == 860749
    assert report["complete_scanned_gcd_certified_case_count"] == 860749
    assert report["scanned_minor_count"] == 11022940
    assert report["checked_nonzero_minor_count"] == 9593308
    assert report["failed_nonzero_minor_count"] == 0
    assert report["invalid_minor_reference_count"] == 0
    assert report["invalid_normalization_count"] == 0
    assert report["max_crossing_count"] == 4
    assert Counter(case["branch_depth"] for case in report["cases"]) == {
        0: 1,
        1: 12,
        2: 132,
        3: 1344,
        4: 12840,
        5: 116832,
        6: 1025952,
    }
    assert Counter(case["source_kind"] for case in report["cases"]) == {
        "fixture_root": 1,
        "one_step_skein_branch": 12,
        "multi_step_skein_branch": 1157100,
    }
    source_summary = report["source_notation_summary"][0]
    assert source_summary["source_notation"] == "4_1"
    assert source_summary["case_count"] == report["case_count"]
    assert source_summary["accepted_case_count"] == report["accepted_case_count"]
    assert source_summary["scanned_minor_count"] == report["scanned_minor_count"]
    assert source_summary["zero_crossing_unlink_certified_case_count"] == report[
        "zero_crossing_unlink_certified_case_count"
    ]
    assert source_summary["branch_depth_counts"][-1] == {
        "branch_depth": 6,
        "case_count": 1025952,
    }
    root_case = next(
        case for case in report["cases"] if case["source_kind"] == "fixture_root"
    )
    assert root_case["result"]["presentation"]["source"] == "explicit_oriented_signed_pd"
    assert sum(1 for case in report["cases"] if case["accepted"]) == 986629
    assert all(
        case["wirtinger_fox_matched"] is False
        for case in report["cases"]
        if not case["accepted"]
    )
    assert sum(1 for case in report["cases"] if case["result_skipped"]) == 170484
    assert all(case["truncated"] is False for case in report["cases"])
    assert report["full_admissible_minor_normalization_certified"] is False
    assert report["full_invariant_certified"] is False
    assert report["arbitrary_diagram_coverage_certified"] is False


def test_multivariable_alexander_fixture_acceptance_report_keeps_unregistered_fixtures_visible() -> None:
    report = multivariable_alexander_fixture_acceptance_report(
        include_unregistered=True,
    )

    def source_divisibility_key(suffix: str) -> str:
        return (
            "source_table_multivariable_alexander_numerator_"
            f"source_divisibility_{suffix}"
        )

    assert report["accepted"] is False
    assert report["fixture_count"] == 7
    assert set(report["incomplete_notations"]) == {"L5a1", "L6a4"}
    assert report["bounded_scanned_gcd_certification_applicable_count"] == 3
    assert report["bounded_scanned_gcd_certified_count"] == 3
    assert report["bounded_scanned_gcd_uncertified_count"] == 0
    assert report["bounded_scanned_gcd_failed_nonzero_minor_count"] == 0
    assert report["bounded_scanned_gcd_truncated_count"] == 0
    assert report["bounded_scanned_gcd_quotient_gcd_certified_count"] == 3
    assert report["bounded_scanned_gcd_complete_certified_count"] == 3
    assert report["bounded_scanned_gcd_improved_candidate_count"] == 0
    assert report["bounded_alexander_maturity_path_counts"] == [
        {"bounded_alexander_maturity_path": "exact_scanned_gcd", "fixture_count": 1},
        {
            "bounded_alexander_maturity_path": "laurent_unit_normalization_consensus",
            "fixture_count": 2,
        },
        {
            "bounded_alexander_maturity_path": "source_table_diagnostic_only",
            "fixture_count": 2,
        },
        {
            "bounded_alexander_maturity_path": "zero_crossing_unlink_terminal",
            "fixture_count": 2,
        },
    ]
    assert report["bounded_alexander_maturity_path_distinct_count"] == 4
    assert report["bounded_alexander_maturity_path_certified_count"] == 5
    maturity_consistency = report["bounded_alexander_maturity_path_summary_consistency"]
    assert maturity_consistency["matched"] is True
    assert maturity_consistency["record_count"] == report["fixture_count"]
    assert maturity_consistency["path_count_total"] == report["fixture_count"]
    assert maturity_consistency["certified_count"] == 5
    assert maturity_consistency["certified_path_count"] == 5
    assert maturity_consistency["certified_count_matches_paths"] is True
    assert any(
        row["bounded_alexander_maturity_path"] == "source_table_diagnostic_only"
        for row in maturity_consistency["path_counts_by_path"]
    )
    assert report["zero_crossing_unlink_normalization_applicable_count"] == 2
    assert report["zero_crossing_unlink_normalization_certified_count"] == 2
    assert report["zero_crossing_unlink_normalization_uncertified_count"] == 0
    assert report["registered_knot_admissible_normalization_applicable_count"] == 2
    assert report["registered_knot_admissible_normalization_certified_count"] == 2
    assert report["registered_knot_admissible_normalization_uncertified_count"] == 0
    assert report["source_table_invariant_audit_applicable_count"] == 2
    assert report["source_table_registration_checked_count"] == 2
    assert report["source_table_registration_ready_count"] == 0
    assert report["source_table_registration_blocked_count"] == 2
    assert report["source_table_registration_blocker_count"] == 8
    assert report["source_table_registration_blocked_notations"] == [
        "L5a1",
        "L6a4",
    ]
    assert report["source_table_registration_ready_notations"] == []
    assert report["source_table_registration_blockers"] == [
        "fixture_signs_not_registered",
        "registered_fixture_invariant_claim_disabled",
        "source_compatible_sign_pattern_not_unique",
        "source_table_values_uncomputed",
    ]
    assert report["source_table_registration_blocker_counts"] == [
        {
            "blocker": "fixture_signs_not_registered",
            "fixture_count": 2,
        },
        {
            "blocker": "registered_fixture_invariant_claim_disabled",
            "fixture_count": 2,
        },
        {
            "blocker": "source_compatible_sign_pattern_not_unique",
            "fixture_count": 2,
        },
        {
            "blocker": "source_table_values_uncomputed",
            "fixture_count": 2,
        },
    ]
    registration_consistency = report[
        "source_table_registration_summary_consistency"
    ]
    assert registration_consistency["matched"] is True
    assert registration_consistency["mismatch_count"] == 0
    assert registration_consistency["first_mismatch"] is None
    assert registration_consistency["mismatch_witnesses"] == []
    assert registration_consistency["checked_count_matches_rows"] is True
    assert registration_consistency["ready_count_matches_rows"] is True
    assert registration_consistency["blocked_count_matches_rows"] is True
    assert registration_consistency["blocker_count_matches_rows"] is True
    assert registration_consistency["blocker_counts_match_rows"] is True
    assert registration_consistency["blocked_notations_match_rows"] is True
    assert registration_consistency["ready_notations_match_rows"] is True
    assert registration_consistency["row_blocker_count_matches_list"] is True
    assert registration_consistency["row_blocker_details_cover_blockers"] is True
    assert registration_consistency["reported_checked_count"] == 2
    assert registration_consistency["report_checked_count"] == 2
    assert registration_consistency["row_checked_count"] == 2
    assert registration_consistency["reported_ready_count"] == 0
    assert registration_consistency["report_ready_count"] == 0
    assert registration_consistency["row_ready_count"] == 0
    assert registration_consistency["reported_blocked_count"] == 2
    assert registration_consistency["report_blocked_count"] == 2
    assert registration_consistency["row_blocked_count"] == 2
    assert registration_consistency["reported_blocker_count"] == 8
    assert registration_consistency["report_blocker_count"] == 8
    assert registration_consistency["row_blocker_count"] == 8
    assert registration_consistency["reported_blocked_notations"] == [
        "L5a1",
        "L6a4",
    ]
    assert registration_consistency["row_blocked_notations"] == [
        "L5a1",
        "L6a4",
    ]
    assert registration_consistency["reported_ready_notations"] == []
    assert registration_consistency["row_ready_notations"] == []
    assert registration_consistency["reported_blocker_counts"] == (
        report["source_table_registration_blocker_counts"]
    )
    assert registration_consistency["report_blocker_counts"] == (
        report["source_table_registration_blocker_counts"]
    )
    assert registration_consistency["row_blocker_counts"] == (
        report["source_table_registration_blocker_counts"]
    )
    assert registration_consistency["row_blocker_count_mismatches"] == []
    assert registration_consistency["row_blocker_detail_mismatches"] == []
    docs = (
        Path(__file__).resolve().parents[1] / "docs/mathematical-definitions.md"
    ).read_text(encoding="utf-8")
    convention_docs = (
        Path(__file__).resolve().parents[1] / "docs/diagram-fixture-conventions.md"
    ).read_text(encoding="utf-8")
    for expected in [
        "source_table_registration_checked_count=2",
        "source_table_registration_ready_count=0",
        "source_table_registration_blocked_count=2",
        "source_table_registration_blocker_count=8",
        "source_table_registration_blocked_notations=L5a1,L6a4",
        "source_table_registration_ready_notations=[]",
        "fixture_signs_not_registered:2",
        "registered_fixture_invariant_claim_disabled:2",
        "source_compatible_sign_pattern_not_unique:2",
        "source_table_values_uncomputed:2",
        (
            "bounded_alexander_maturity_paths=exact_scanned_gcd:1,"
            "laurent_unit_normalization_consensus:2,"
            "source_table_diagnostic_only:2,zero_crossing_unlink_terminal:2"
        ),
        "bounded_alexander_maturity_certified=5",
        "bounded_alexander_maturity_distinct=4",
        "not registered signed-PD Alexander fixture values",
        "not full admissible-minor normalization",
    ]:
        assert expected in docs
    for expected in [
        "source_table_registration_checked_count=2",
        "source_table_registration_ready_count=0",
        "source_table_registration_blocked_count=2",
        "source_table_registration_blocker_count=8",
        "source_table_registration_blocked_notations=L5a1,L6a4",
        "source_table_registration_ready_notations=[]",
        "fixture_signs_not_registered:2",
        "registered_fixture_invariant_claim_disabled:2",
        "source_compatible_sign_pattern_not_unique:2",
        "source_table_values_uncomputed:2",
        "source-table convention evidence",
        "not registered signed-PD Alexander fixture values",
    ]:
        assert expected in convention_docs
    assert (
        report["source_table_multivariable_alexander_numerator_checked_count"] == 2
    )
    assert (
        report["source_table_multivariable_alexander_numerator_source_seen_count"] == 2
    )
    assert (
        report[
            "source_table_multivariable_alexander_numerator_complete_match_count"
        ]
        == 1
    )
    assert (
        report[
            "source_table_multivariable_alexander_numerator_incomplete_or_unstable_count"
        ]
        == 1
    )
    assert (
        report[
            "source_table_multivariable_alexander_numerator_skipped_candidate_count"
        ]
        == 8
    )
    assert (
        report[
            "source_table_multivariable_alexander_numerator_missing_candidate_count"
        ]
        == 8
    )
    assert (
        report[
            "source_table_alexander_numerator_link_normalization_checked_count"
        ]
        == 2
    )
    assert (
        report[
            "source_table_alexander_numerator_link_normalization_ready_count"
        ]
        == 1
    )
    assert (
        report[
            "source_table_alexander_numerator_link_normalization_blocked_count"
        ]
        == 1
    )
    assert (
        report[
            "source_table_alexander_numerator_link_normalization_blocker_count"
        ]
        == 2
    )
    assert report[
        "source_table_alexander_numerator_link_normalization_ready_notations"
    ] == ["L6a4"]
    assert report[
        "source_table_alexander_numerator_link_normalization_blocked_notations"
    ] == ["L5a1"]
    assert report[
        "source_table_alexander_numerator_link_normalization_blockers"
    ] == [
        "source_table_alexander_numerator_not_complete_source_match",
        "source_table_alexander_source_divisibility_failed",
    ]
    assert report[
        "source_table_alexander_numerator_link_normalization_blocker_counts"
    ] == [
        {
            "blocker": "source_table_alexander_numerator_not_complete_source_match",
            "fixture_count": 1,
        },
        {
            "blocker": "source_table_alexander_source_divisibility_failed",
            "fixture_count": 1,
        },
    ]
    assert (
        report[
            "source_table_multivariable_alexander_numerator_source_divisibility_checked_candidate_count"
        ]
        == 8
    )
    assert (
        report[
            "source_table_multivariable_alexander_numerator_source_divisibility_source_divides_all_candidate_count"
        ]
        == 0
    )
    assert (
        report[
            "source_table_multivariable_alexander_numerator_source_divisibility_source_division_failed_candidate_count"
        ]
        == 8
    )
    assert (
        report[
            "source_table_multivariable_alexander_numerator_source_divisibility_all_checked_candidates_divisible_count"
        ]
        == 0
    )
    assert report[
        "source_table_multivariable_alexander_numerator_source_divisibility_statuses"
    ] == ["source_does_not_divide_all_inputs"]
    assert report[
        "source_table_multivariable_alexander_numerator_source_divisibility_status_counts"
    ] == [
        {
            "status": "source_does_not_divide_all_inputs",
            "candidate_count": 8,
        },
    ]
    assert report[
        "source_table_multivariable_alexander_numerator_source_divisibility_failure_status_counts"
    ] == [
        {
            "status": "source_does_not_divide_all_inputs",
            "candidate_count": 8,
        },
    ]
    assert (
        report[
            "source_table_multivariable_alexander_numerator_source_divisibility_failed_input_count_min"
        ]
        == 10
    )
    assert (
        report[
            "source_table_multivariable_alexander_numerator_source_divisibility_failed_input_count_max"
        ]
        == 10
    )
    assert (
        report[
            "source_table_multivariable_alexander_numerator_source_divisibility_unique_input_polynomial_count_min"
        ]
        == 10
    )
    assert (
        report[
            "source_table_multivariable_alexander_numerator_source_divisibility_unique_input_polynomial_count_max"
        ]
        == 10
    )
    assert (
        report[
            "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_notation"
        ]
        == "L5a1"
    )
    assert (
        report[
            "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_candidate_index"
        ]
        == 4
    )
    assert (
        report[
            "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_input_polynomial"
        ]
        == "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2"
    )
    assert report[source_divisibility_key("failed_candidate_witness_count")] == 8
    assert report[source_divisibility_key("failed_candidate_witness_limit")] == 8
    assert report[source_divisibility_key("failed_candidate_witness_truncated")] is False
    assert len(report[source_divisibility_key("failed_candidate_witnesses")]) == 8
    _assert_bounded_witness_consistency(
        report[source_divisibility_key("failed_candidate_witness_consistency")],
        witness_kind="source_table_alexander_source_divisibility_failed_candidate",
        witness_count=8,
        witness_list_count=8,
        witness_limit=8,
        witness_truncated=False,
    )
    assert report[
        source_divisibility_key("first_failed_candidate_witness")
    ] == {
        "notation": "L5a1",
        "candidate_index": 4,
        "status": "source_does_not_divide_all_inputs",
        "source_polynomial": "1 - t2 - t1 + t1*t2",
        "normalized_source_polynomial": "1 - t2 - t1 + t1*t2",
        "failed_input_count": 10,
        "invalid_input_count": 0,
        "unique_input_polynomial_count": 10,
        "first_failed_input_witness": {
            "input_index": 0,
            "input_polynomial": "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2",
            "divisible": False,
            "invalid": False,
            "quotient_polynomial": None,
        },
    }

    rows = {row["notation"]: row for row in report["fixtures"]}
    first_failed_notation = report[source_divisibility_key("first_failed_notation")]
    assert first_failed_notation is not None
    first_failed_row = rows[first_failed_notation]
    assert (
        first_failed_row[source_divisibility_key("first_failed_candidate_index")]
        == report[source_divisibility_key("first_failed_candidate_index")]
    )
    assert (
        first_failed_row[source_divisibility_key("first_failed_input_polynomial")]
        == report[source_divisibility_key("first_failed_input_polynomial")]
    )
    assert report[source_divisibility_key("first_failed_candidate_index")] in (
        first_failed_row[source_divisibility_key("candidate_indices")]
    )
    assert rows["0_1"]["expected_multivariable_alexander"] == "1"
    assert rows["0_1"]["bounded_scanned_gcd_certification_applicable"] is False
    assert rows["0_1"]["bounded_scanned_gcd_certified"] is False
    assert rows["0_1"]["bounded_scanned_gcd_evidence"]["skipped"] is True
    assert rows["0_1"]["bounded_scanned_gcd_evidence"][
        "bounded_scanned_gcd_certified"
    ] is False
    assert rows["0_1"]["comparison"]["skipped"] is False
    assert rows["0_1"]["comparison"]["matched"] is True
    assert rows["0_1"]["zero_crossing_unlink_normalization_certified"] is True
    assert rows["0_1"]["minor_divisibility_audit"] is None
    assert rows["0_1"]["scanned_gcd_audit"] is None
    assert rows["L0a1"]["expected_multivariable_alexander"] == "0"
    assert rows["L0a1"]["bounded_scanned_gcd_certification_applicable"] is False
    assert rows["L0a1"]["bounded_scanned_gcd_certified"] is False
    assert rows["L0a1"]["bounded_scanned_gcd_evidence"]["skipped"] is True
    assert rows["L0a1"]["comparison"]["matched"] is True
    assert rows["L0a1"]["zero_crossing_unlink_normalization_certified"] is True
    assert "fixture does not have a signed-PD diagram" in rows["L5a1"][
        "comparison"
    ]["notes"]
    source_orientation = rows["L5a1"]["comparison"]["source_orientation_diagnostics"]
    assert source_orientation["skipped"] is False
    assert source_orientation["has_gauss_code"] is True
    assert source_orientation["gauss_code_matched"] is True
    assert source_orientation["gauss_code_orientation_diagnostics"][
        "matching_sample_count"
    ] == 2
    source_pairwise = rows["L5a1"]["comparison"][
        "source_pairwise_candidate_diagnostics"
    ]
    assert source_pairwise["skipped"] is False
    assert source_pairwise["target_pairwise_linking"] == [0.0]
    assert source_pairwise["matching_candidate_count"] == 24
    assert source_pairwise["matching_sign_summary"][
        "unique_sign_pattern_count"
    ] == 12
    assert rows["L5a1"]["minor_divisibility_audit"] is None
    assert rows["L5a1"]["scanned_gcd_audit"] is None
    assert rows["L5a1"]["bounded_scanned_gcd_evidence"]["skipped"] is True
    assert rows["L5a1"]["bounded_scanned_gcd_evidence"]["notes"] == [
        "no scanned-gcd audit supplied",
    ]
    assert rows["L5a1"]["bounded_alexander_maturity_path"] == (
        "source_table_diagnostic_only"
    )
    assert rows["L5a1"]["bounded_alexander_maturity_path_certified"] is False
    assert rows["L5a1"]["bounded_scanned_gcd_evidence"][
        "bounded_alexander_maturity_path"
    ] == "not_certified"
    assert rows["L5a1"]["bounded_scanned_gcd_evidence"][
        "bounded_alexander_maturity_path_certified"
    ] is False
    l5_bounded_summary = rows["L5a1"]["bounded_scanned_gcd_evidence"][
        "bounded_admissible_minor_normalization_blocker_witness_summary"
    ]
    assert rows["L5a1"]["accepted"] is False
    assert rows["L5a1"]["bounded_scanned_gcd_evidence"][
        "full_admissible_minor_normalization_certified"
    ] is False
    assert l5_bounded_summary["blocker_reason_codes"] == ["scan_missing"]
    assert l5_bounded_summary["first_witness"] is None
    _assert_blocker_witness_summary_consistency(
        l5_bounded_summary,
        witness_available=False,
        missing_witness_reasons=["no_reusable_locator_witness"],
        blocker_reason_counts={"scan_missing": 1},
    )
    assert l5_bounded_summary["first_witness_source"] == {
        "available": False,
        "source_blocker": None,
        "source_reason_code": None,
        "source_field": None,
        "source_detail_field": None,
        "witness_kind": None,
        "missing_reason": "no_reusable_locator_witness",
    }
    assert rows["L5a1"]["source_table_invariant_audit"][
        "registered_fixture_invariant_claim"
    ] is False
    assert rows["L5a1"]["source_table_invariant_audit"][
        "source_table_registration_ready"
    ] is False
    assert rows["L5a1"]["source_table_registration_ready"] is False
    assert rows["L5a1"]["source_table_registration_blockers"] == [
        "fixture_signs_not_registered",
        "registered_fixture_invariant_claim_disabled",
        "source_table_values_uncomputed",
        "source_compatible_sign_pattern_not_unique",
    ]
    assert rows["L5a1"]["source_table_registration_blocker_count"] == 4
    assert rows["L5a1"]["source_table_registration_blocker_details"] == {
        "source_table_values_uncomputed": [
            "jones",
            "homfly",
            "multivariable_alexander_numerator",
        ],
        "source_compatible_sign_pattern_not_unique": {
            "complete_source_compatible_unique_sign_pattern_count": 0,
        },
    }
    l5_link_normalization = rows["L5a1"][
        "source_table_alexander_numerator_link_normalization_evidence"
    ]
    assert rows["L5a1"][
        "source_table_alexander_numerator_link_normalization_checked"
    ] is True
    assert rows["L5a1"][
        "source_table_alexander_numerator_link_normalization_ready"
    ] is False
    assert rows["L5a1"][
        "source_table_alexander_numerator_link_normalization_blockers"
    ] == [
        "source_table_alexander_numerator_not_complete_source_match",
        "source_table_alexander_source_divisibility_failed",
    ]
    assert rows["L5a1"][
        "source_table_alexander_numerator_link_normalization_blocker_count"
    ] == 2
    assert l5_link_normalization["claim_scope"] == (
        "source_table_alexander_numerator_link_normalization_readiness"
    )
    assert l5_link_normalization["checked"] is True
    assert l5_link_normalization["ready"] is False
    assert l5_link_normalization["source_seen"] is True
    assert l5_link_normalization["complete_match"] is False
    assert l5_link_normalization["resolution_status"] == (
        "source_seen_with_incomplete_candidates"
    )
    assert l5_link_normalization["skipped_candidate_count"] == 8
    assert l5_link_normalization["missing_candidate_count"] == 8
    assert l5_link_normalization[
        "source_divisibility_failed_candidate_count"
    ] == 8
    assert l5_link_normalization["registration_ready"] is False
    assert l5_link_normalization["registration_blocker_count"] == 4
    assert l5_link_normalization[
        "full_admissible_minor_normalization_certified"
    ] is False
    assert l5_link_normalization["full_invariant_certified"] is False
    assert rows["L5a1"]["bounded_scanned_gcd_certification_applicable"] is False
    assert rows["L5a1"]["bounded_scanned_gcd_certified"] is False
    assert rows["L5a1"]["source_table_invariant_audit_applicable"] is True
    assert (
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_source_seen"
        ]
        is True
    )
    assert (
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_complete_match"
        ]
        is False
    )
    assert (
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_resolution_status"
        ]
        == "source_seen_with_incomplete_candidates"
    )
    assert (
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_candidate_unique_value_count"
        ]
        == 2
    )
    assert (
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_source_divisibility_checked_candidate_count"
        ]
        == 8
    )
    assert (
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_source_divisibility_source_division_failed_candidate_count"
        ]
        == 8
    )
    assert (
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_source_divisibility_statuses"
        ]
        == ["source_does_not_divide_all_inputs"]
    )
    assert (
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_source_divisibility_status_counts"
        ]
        == [
            {
                "status": "source_does_not_divide_all_inputs",
                "candidate_count": 8,
            },
        ]
    )
    assert (
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_source_divisibility_failure_status_counts"
        ]
        == [
            {
                "status": "source_does_not_divide_all_inputs",
                "candidate_count": 8,
            },
        ]
    )
    assert (
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_source_divisibility_candidate_indices"
        ]
        == [4, 5, 10, 11, 12, 13, 18, 19]
    )
    assert (
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_source_divisibility_failed_input_count_min"
        ]
        == 10
    )
    assert (
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_source_divisibility_failed_input_count_max"
        ]
        == 10
    )
    assert (
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_source_divisibility_unique_input_polynomial_count_min"
        ]
        == 10
    )
    assert (
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_source_divisibility_unique_input_polynomial_count_max"
        ]
        == 10
    )
    assert (
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_candidate_index"
        ]
        == 4
    )
    assert (
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_input_polynomial"
        ]
        == "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2"
    )
    l5_witness_summary = rows["L5a1"][
        "source_table_multivariable_alexander_numerator_source_divisibility_failed_candidate_witness_summary"
    ]
    assert l5_witness_summary["method"] == (
        "source_table_alexander_source_divisibility_failed_candidate_witness_summary"
    )
    assert l5_witness_summary["failed_candidate_witness_count"] == 8
    assert l5_witness_summary["failed_candidate_witness_limit"] == 8
    assert l5_witness_summary["failed_candidate_witness_truncated"] is False
    assert rows["L5a1"][
        "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_candidate_witness"
    ] == l5_witness_summary["first_failed_candidate_witness"]
    _assert_bounded_witness_consistency(
        rows["L5a1"][
            "source_table_multivariable_alexander_numerator_source_divisibility_failed_candidate_witness_consistency"
        ],
        witness_kind="source_table_alexander_source_divisibility_failed_candidate",
        witness_count=8,
        witness_list_count=8,
        witness_limit=8,
        witness_truncated=False,
    )
    assert rows["L6a4"]["comparison"]["skipped"] is True
    assert "fixture does not have a signed-PD diagram" in rows["L6a4"][
        "comparison"
    ]["notes"]
    borromean_source_orientation = rows["L6a4"]["comparison"][
        "source_orientation_diagnostics"
    ]
    assert borromean_source_orientation["skipped"] is False
    assert borromean_source_orientation["has_gauss_code"] is True
    assert borromean_source_orientation["gauss_code_matched"] is True
    assert borromean_source_orientation["gauss_code_orientation_diagnostics"][
        "matching_sample_count"
    ] == 1
    borromean_source_pairwise = rows["L6a4"]["comparison"][
        "source_pairwise_candidate_diagnostics"
    ]
    assert borromean_source_pairwise["skipped"] is False
    assert borromean_source_pairwise["target_pairwise_linking"] == [0.0, 0.0, 0.0]
    assert borromean_source_pairwise["matching_candidate_count"] == 8
    assert borromean_source_pairwise["matching_sign_summary"][
        "mirror_pair_count"
    ] == 4
    assert rows["L6a4"]["accepted"] is False
    assert rows["L6a4"]["bounded_scanned_gcd_evidence"]["skipped"] is True
    assert rows["L6a4"]["bounded_alexander_maturity_path"] == (
        "source_table_diagnostic_only"
    )
    assert rows["L6a4"]["bounded_alexander_maturity_path_certified"] is False
    assert rows["L6a4"]["bounded_scanned_gcd_evidence"][
        "bounded_alexander_maturity_path"
    ] == "not_certified"
    assert rows["L6a4"]["bounded_scanned_gcd_evidence"][
        "bounded_alexander_maturity_path_certified"
    ] is False
    l6_bounded_summary = rows["L6a4"]["bounded_scanned_gcd_evidence"][
        "bounded_admissible_minor_normalization_blocker_witness_summary"
    ]
    assert rows["L6a4"]["bounded_scanned_gcd_evidence"][
        "full_admissible_minor_normalization_certified"
    ] is False
    assert l6_bounded_summary["blocker_reason_codes"] == ["scan_missing"]
    assert l6_bounded_summary["first_witness"] is None
    _assert_blocker_witness_summary_consistency(
        l6_bounded_summary,
        witness_available=False,
        missing_witness_reasons=["no_reusable_locator_witness"],
        blocker_reason_counts={"scan_missing": 1},
    )
    assert l6_bounded_summary["first_witness_source"] == {
        "available": False,
        "source_blocker": None,
        "source_reason_code": None,
        "source_field": None,
        "source_detail_field": None,
        "witness_kind": None,
        "missing_reason": "no_reusable_locator_witness",
    }
    assert rows["L6a4"]["source_table_invariant_audit"][
        "registered_fixture_invariant_claim"
    ] is False
    assert rows["L6a4"]["source_table_invariant_audit"][
        "source_table_registration_ready"
    ] is False
    assert rows["L6a4"]["source_table_registration_ready"] is False
    assert rows["L6a4"]["source_table_registration_blockers"] == [
        "fixture_signs_not_registered",
        "registered_fixture_invariant_claim_disabled",
        "source_table_values_uncomputed",
        "source_compatible_sign_pattern_not_unique",
    ]
    assert rows["L6a4"]["source_table_registration_blocker_count"] == 4
    assert rows["L6a4"]["source_table_registration_blocker_details"] == {
        "source_table_values_uncomputed": ["homfly"],
        "source_compatible_sign_pattern_not_unique": {
            "complete_source_compatible_unique_sign_pattern_count": 0,
        },
    }
    l6_link_normalization = rows["L6a4"][
        "source_table_alexander_numerator_link_normalization_evidence"
    ]
    assert rows["L6a4"][
        "source_table_alexander_numerator_link_normalization_checked"
    ] is True
    assert rows["L6a4"][
        "source_table_alexander_numerator_link_normalization_ready"
    ] is True
    assert rows["L6a4"][
        "source_table_alexander_numerator_link_normalization_blockers"
    ] == []
    assert rows["L6a4"][
        "source_table_alexander_numerator_link_normalization_blocker_count"
    ] == 0
    assert l6_link_normalization["checked"] is True
    assert l6_link_normalization["ready"] is True
    assert l6_link_normalization["source_seen"] is True
    assert l6_link_normalization["complete_match"] is True
    assert l6_link_normalization["returned_match"] is True
    assert l6_link_normalization["resolution_status"] == "complete_source_match"
    assert l6_link_normalization["candidate_unique_value_count"] == 1
    assert l6_link_normalization["skipped_candidate_count"] == 0
    assert l6_link_normalization["missing_candidate_count"] == 0
    assert l6_link_normalization[
        "source_divisibility_failed_candidate_count"
    ] == 0
    assert l6_link_normalization["registration_ready"] is False
    assert l6_link_normalization["registration_blocker_count"] == 4
    assert l6_link_normalization["readiness_blockers"] == []
    assert l6_link_normalization[
        "full_admissible_minor_normalization_certified"
    ] is False
    assert l6_link_normalization["full_invariant_certified"] is False
    assert rows["L6a4"]["bounded_scanned_gcd_certification_applicable"] is False
    assert rows["L6a4"]["bounded_scanned_gcd_certified"] is False
    assert rows["L6a4"]["source_table_invariant_audit_applicable"] is True
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_source_seen"
        ]
        is True
    )
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_complete_match"
        ]
        is True
    )
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_resolution_status"
        ]
        == "complete_source_match"
    )
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_candidate_unique_value_count"
        ]
        == 1
    )
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_source_divisibility_checked_candidate_count"
        ]
        == 0
    )
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_source_divisibility_statuses"
        ]
        == []
    )
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_source_divisibility_status_counts"
        ]
        == []
    )
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_source_divisibility_failure_status_counts"
        ]
        == []
    )
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_source_divisibility_candidate_indices"
        ]
        == []
    )
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_source_divisibility_failed_input_count_min"
        ]
        == 0
    )
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_source_divisibility_failed_input_count_max"
        ]
        == 0
    )
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_source_divisibility_unique_input_polynomial_count_min"
        ]
        == 0
    )
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_source_divisibility_unique_input_polynomial_count_max"
        ]
        == 0
    )
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_candidate_index"
        ]
        is None
    )
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_input_polynomial"
        ]
        is None
    )
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_source_divisibility_failed_candidate_witness_count"
        ]
        == 0
    )
    assert (
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_candidate_witness"
        ]
        is None
    )
    _assert_bounded_witness_consistency(
        rows["L6a4"][
            "source_table_multivariable_alexander_numerator_source_divisibility_failed_candidate_witness_consistency"
        ],
        witness_kind="source_table_alexander_source_divisibility_failed_candidate",
        witness_count=0,
        witness_list_count=0,
        witness_limit=8,
        witness_truncated=False,
    )
    assert (
        rows["L6a4"]["source_table_invariant_audit"]["comparisons"][
            "multivariable_alexander_numerator"
        ]["complete_candidate_source_match"]
        is True
    )


def test_multivariable_alexander_fixture_regression_pack_matches_registered_values() -> None:
    for notation in ("L2a1", "3_1", "4_1"):
        fixture = get_diagram_fixture(notation)
        comparison = multivariable_alexander_fixture_comparison(notation)

        assert fixture.expected_multivariable_alexander
        assert fixture.expected_multivariable_alexander_source
        assert comparison["skipped"] is False
        assert comparison["matched"] is True
        assert (
            comparison["observed_multivariable_alexander"]
            == fixture.expected_multivariable_alexander
        )
        assert (
            comparison["fixture"]["expected_multivariable_alexander"]
            == fixture.expected_multivariable_alexander
        )


def test_multivariable_alexander_fixture_comparison_matches_figure_eight() -> None:
    comparison = multivariable_alexander_fixture_comparison("4_1")

    assert comparison["skipped"] is False
    assert comparison["matched"] is True
    assert comparison["expected_multivariable_alexander"] == "1 - 3t + t^2"
    assert comparison["observed_multivariable_alexander"] == "1 - 3t + t^2"
    assert comparison["result"]["method"] == "fox_square_minor_consensus_gcd"


def test_link_classification_exposes_post_mvp_invariants() -> None:
    result = classify_link(unlink(count=128), direction=[0.3, 0.5, 1.0]).to_dict()

    assert result["table_match"]["link_type"] == "unlink"
    assert result["invariants"]["homfly"]["skipped"] is True
    assert result["invariants"]["multivariable_alexander"]["skipped"] is False


def test_hopf_classification_uses_signed_pd_fixture_invariants() -> None:
    result = classify_link(hopf_link(count=128), direction=[0.3, 0.5, 1.0]).to_dict()

    assert result["link_type"] == "hopf_link"
    assert result["invariants"]["homfly"]["method"] == "signed_pd_fixture_comparison"
    assert result["invariants"]["homfly"]["homfly_polynomial"] == (
        "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z"
    )
    assert (
        result["invariants"]["multivariable_alexander"]["method"]
        == "fox_square_minor_disjoint_support_gcd"
    )
    assert (
        result["invariants"]["multivariable_alexander"][
            "multivariable_alexander_polynomial"
        ]
        == "1"
    )
    assert result["invariants"]["multivariable_alexander"]["fixture"]["notation"] == "L2a1"
    assert (
        result["invariants"]["multivariable_alexander"]["fixture_comparison"]["matched"]
        is True
    )
