from __future__ import annotations

import json

import pytest

from iroll.adapters import AdapterUnavailableError, classify_with_adapter, list_available_adapters
from iroll.cli import main
from iroll.validation import run_validation, trefoil_curve


def test_run_validation_builtin_cases_pass() -> None:
    report = run_validation(count=128)

    assert report["failed"] == 0
    assert report["passed"] == report["total"]


def test_cli_validate_prints_json(capsys) -> None:
    exit_code = main(["validate", "--points", "128"])
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["failed"] == 0


def test_adapter_listing_is_json_friendly() -> None:
    adapters = list_available_adapters()

    assert set(adapters) == {"pyknotid", "topoly"}
    assert all("available" in value for value in adapters.values())


def test_cli_adapters_prints_json(capsys) -> None:
    exit_code = main(["adapters"])
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert "pyknotid" in payload["adapters"]


def test_missing_adapter_raises_clear_error_when_uninstalled() -> None:
    adapters = list_available_adapters()
    if adapters["pyknotid"]["available"]:
        pytest.skip("pyknotid is installed in this environment")

    with pytest.raises(AdapterUnavailableError, match="pyknotid"):
        classify_with_adapter(trefoil_curve(count=128), adapter="pyknotid")
