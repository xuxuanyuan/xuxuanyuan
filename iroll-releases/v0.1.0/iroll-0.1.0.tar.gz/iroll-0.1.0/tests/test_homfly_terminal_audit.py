from __future__ import annotations

from copy import deepcopy

from iroll.topology import (
    get_diagram_fixture,
    homfly_certified_evaluation_from_pd,
    homfly_fixture_acceptance_report,
    homfly_input_certification_evidence,
    homfly_terminal_reduction_audit,
)
from iroll.topology.homfly import (
    _homfly_reduction_contribution_witness_consistency_record,
)


def test_homfly_terminal_reduction_audit_matches_certified_trefoil_sum() -> None:
    fixture = get_diagram_fixture("3_1")
    result = homfly_certified_evaluation_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
    )

    audit = homfly_terminal_reduction_audit(result)

    assert audit["method"] == "homfly_terminal_reduction_audit"
    assert audit["claim_scope"] == (
        "exact_sum_of_recorded_terminal_and_memoized_reduction_contributions"
    )
    assert audit["skipped"] is False
    assert audit["matched_result"] is True
    assert audit["terminal_reduction_count"] > 0
    assert audit["failed_terminal_reduction_count"] == 0
    assert audit["terminal_contribution_sum"] == fixture.expected_homfly
    assert audit["homfly_polynomial"] == fixture.expected_homfly
    assert (
        audit["parsed_reduction_contribution_count"]
        == audit["reduction_contribution_count"]
    )
    assert audit["unparsed_reduction_contribution_count"] == 0
    kind_counts = {
        row["reduction_kind"]: row["reduction_count"]
        for row in audit["reduction_kind_counts"]
    }
    assert kind_counts["terminal"] == audit["terminal_reduction_count"]
    assert kind_counts.get("memoized_subtree", 0) == audit[
        "memoized_reduction_count"
    ]
    kind_sums = {
        row["reduction_kind"]: row["contribution_sum"]
        for row in audit["reduction_kind_contribution_sums"]
    }
    assert set(kind_sums) == set(kind_counts)
    assert audit["reduction_contribution_witness_limit"] == 8
    assert audit["reduction_contribution_witness_count"] == min(
        audit["reduction_contribution_count"],
        audit["reduction_contribution_witness_limit"],
    )
    assert audit["reduction_contribution_witnesses_truncated"] is (
        audit["reduction_contribution_count"]
        > audit["reduction_contribution_witness_count"]
    )
    assert audit["first_reduction_contribution_witness"] == audit[
        "reduction_contribution_witnesses"
    ][0]
    assert (
        audit["first_reduction_contribution_witness"]["reduction_kind"]
        in kind_counts
    )
    assert "contribution" in audit["first_reduction_contribution_witness"]
    summary = audit["reduction_contribution_witness_summary"]
    assert summary["method"] == "homfly_reduction_contribution_witness_summary"
    assert summary["reduction_contribution_count"] == audit[
        "reduction_contribution_count"
    ]
    assert summary["reduction_contribution_witness_count"] == audit[
        "reduction_contribution_witness_count"
    ]
    assert summary["reduction_contribution_witness_list_count"] == len(
        audit["reduction_contribution_witnesses"]
    )
    assert summary["first_reduction_kind"] in kind_counts
    consistency = audit["reduction_contribution_witness_consistency"]
    assert consistency["method"] == (
        "homfly_reduction_contribution_witness_consistency"
    )
    assert consistency["matched"] is True
    assert consistency["mismatch_count"] == 0
    assert consistency["witness_count_matches_list_count"] is True
    assert consistency["first_reduction_contribution_witness_matches_list"] is True
    assert consistency["parsed_unparsed_matches_total"] is True
    assert consistency["reduction_kind_counts_match_total"] is True
    assert consistency["summary_matches_witness_shape"] is True

    evidence = homfly_input_certification_evidence(result)
    assert evidence["bounded_homfly_maturity_path"] == (
        "recursive_switching_to_descending_frontier_exhausted"
    )
    assert evidence["bounded_homfly_maturity_path_certified"] is True
    maturity_evidence = evidence["bounded_homfly_maturity_path_evidence"]
    assert maturity_evidence["method"] == "homfly_bounded_maturity_path_evidence"
    assert maturity_evidence["bounded_homfly_maturity_path"] == evidence[
        "bounded_homfly_maturity_path"
    ]
    assert maturity_evidence["expected_bounded_homfly_maturity_path"] == (
        "recursive_switching_to_descending_frontier_exhausted"
    )
    assert maturity_evidence["bounded_homfly_maturity_path_matches_expected"] is True
    assert maturity_evidence["bounded_homfly_maturity_path_certified"] is True
    assert maturity_evidence["zero_crossing_certified"] is False
    assert maturity_evidence["certified_for_input"] is True
    assert maturity_evidence["frontier_exhausted"] is True
    assert maturity_evidence["skipped"] is False
    assert maturity_evidence["truncated"] is False
    assert maturity_evidence["frontier_count"] == 0
    assert maturity_evidence["certification_blocker_count"] == 0
    assert evidence["terminal_contribution_matches_result"] is True
    assert evidence["terminal_contribution_audit_skipped"] is False
    assert evidence["terminal_contribution_sum"] == fixture.expected_homfly
    assert evidence["reduction_kind_counts"] == audit["reduction_kind_counts"]
    assert evidence["reduction_kind_contribution_sums"] == audit[
        "reduction_kind_contribution_sums"
    ]
    assert evidence["reduction_contribution_witnesses"] == audit[
        "reduction_contribution_witnesses"
    ]
    assert evidence["first_reduction_contribution_witness"] == audit[
        "first_reduction_contribution_witness"
    ]
    assert evidence["reduction_contribution_witness_summary"] == audit[
        "reduction_contribution_witness_summary"
    ]
    assert evidence["reduction_contribution_witness_consistency"] == audit[
        "reduction_contribution_witness_consistency"
    ]
    assert evidence["terminal_contribution_audit"] == audit


def test_homfly_reduction_witness_consistency_pinpoints_tampered_summary() -> None:
    fixture = get_diagram_fixture("3_1")
    result = homfly_certified_evaluation_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
    )
    audit = homfly_terminal_reduction_audit(result)
    tampered = deepcopy(audit)
    tampered["reduction_contribution_witness_count"] += 1
    tampered["first_reduction_contribution_witness"] = {
        **tampered["first_reduction_contribution_witness"],
        "index": 999,
    }
    tampered["reduction_contribution_witnesses_truncated"] = not tampered[
        "reduction_contribution_witnesses_truncated"
    ]
    tampered["reduction_contribution_witness_summary"] = {
        **tampered["reduction_contribution_witness_summary"],
        "reduction_contribution_witness_count": 999,
    }

    consistency = _homfly_reduction_contribution_witness_consistency_record(
        tampered,
        context={"notation": "3_1"},
    )

    assert consistency["matched"] is False
    assert consistency["witness_count_matches_list_count"] is False
    assert consistency["first_reduction_contribution_witness_matches_list"] is False
    assert consistency["truncated_matches_witness_count"] is False
    assert consistency["truncated_matches_witness_list"] is False
    assert consistency["summary_matches_witness_shape"] is False
    assert consistency["mismatch_count"] >= 4
    assert consistency["first_mismatch"]["notation"] == "3_1"
    assert consistency["first_mismatch"]["field"] == (
        "reduction_contribution_witness_count"
    )
    fields = {row["field"] for row in consistency["mismatch_witnesses"]}
    assert "first_reduction_contribution_witness" in fields
    assert "reduction_contribution_witnesses_truncated" in fields
    assert "reduction_contribution_witness_summary" in fields

def test_homfly_terminal_reduction_audit_detects_tampered_result() -> None:
    fixture = get_diagram_fixture("3_1")
    result = homfly_certified_evaluation_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
    )
    tampered = {
        **result,
        "recursive_evaluation": {
            **result["recursive_evaluation"],
            "homfly_polynomial": "1",
        },
    }

    audit = homfly_terminal_reduction_audit(tampered)

    assert audit["skipped"] is False
    assert audit["matched_result"] is False
    assert audit["terminal_contribution_sum"] == fixture.expected_homfly
    assert audit["homfly_polynomial"] == "1"
    assert audit["notes"] == [
        "recorded terminal and memoized reduction contributions do not sum to the final HOMFLY polynomial",
    ]


def test_homfly_terminal_reduction_audit_skips_zero_crossing_result() -> None:
    fixture = get_diagram_fixture("0_1")
    result = homfly_certified_evaluation_from_pd(fixture.diagram())

    audit = homfly_terminal_reduction_audit(result)
    evidence = homfly_input_certification_evidence(result)

    assert audit["skipped"] is True
    assert audit["matched_result"] is False
    assert audit["terminal_reduction_count"] == 0
    assert audit["notes"] == [
        "result does not include recursive reductions to audit",
    ]
    assert evidence["zero_crossing_certified"] is True
    assert evidence["bounded_homfly_maturity_path"] == (
        "zero_crossing_unlink_terminal"
    )
    assert evidence["bounded_homfly_maturity_path_certified"] is True
    zero_maturity_evidence = evidence["bounded_homfly_maturity_path_evidence"]
    assert zero_maturity_evidence["bounded_homfly_maturity_path"] == evidence[
        "bounded_homfly_maturity_path"
    ]
    assert zero_maturity_evidence["expected_bounded_homfly_maturity_path"] == (
        "zero_crossing_unlink_terminal"
    )
    assert zero_maturity_evidence["bounded_homfly_maturity_path_matches_expected"] is True
    assert zero_maturity_evidence["bounded_homfly_maturity_path_certified"] is True
    assert zero_maturity_evidence["zero_crossing_certified"] is True
    assert zero_maturity_evidence["certified_for_input"] is False
    assert zero_maturity_evidence["frontier_exhausted"] is True
    assert zero_maturity_evidence["skipped"] is False
    assert zero_maturity_evidence["truncated"] is False
    assert zero_maturity_evidence["frontier_count"] == 0
    assert evidence["terminal_contribution_audit_skipped"] is True
    assert evidence["terminal_contribution_matches_result"] is False


def test_homfly_acceptance_report_aggregates_terminal_audit_counts() -> None:
    report = homfly_fixture_acceptance_report()

    assert (
        report["input_certification_terminal_contribution_audit_applicable_count"]
        == 3
    )
    assert report["input_certification_terminal_contribution_matched_count"] == 3
    assert report["input_certification_terminal_contribution_failed_count"] == 0

    rows = {row["notation"]: row for row in report["fixtures"]}
    for notation in ("L2a1", "3_1", "4_1"):
        evidence = rows[notation]["input_certification_evidence"]
        assert evidence["terminal_contribution_audit_skipped"] is False
        assert evidence["terminal_contribution_matches_result"] is True
    assert rows["4_1"]["input_certification_evidence"][
        "memoized_reduction_count"
    ] > 0
    assert rows["4_1"]["input_certification_evidence"][
        "terminal_contribution_audit"
    ]["memoized_reduction_count"] > 0
    figure_eight_evidence = rows["4_1"]["input_certification_evidence"]
    figure_eight_kind_counts = {
        row["reduction_kind"]: row["reduction_count"]
        for row in figure_eight_evidence["reduction_kind_counts"]
    }
    assert figure_eight_kind_counts["memoized_subtree"] == figure_eight_evidence[
        "memoized_reduction_count"
    ]
    assert figure_eight_evidence["parsed_reduction_contribution_count"] == (
        figure_eight_evidence["reduction_contribution_count"]
    )
    assert figure_eight_evidence["unparsed_reduction_contribution_count"] == 0
    assert any(
        row["reduction_kind"] == "memoized_subtree"
        for row in figure_eight_evidence["reduction_kind_contribution_sums"]
    )
    skipped_notes = {
        "0_1": "result does not include recursive reductions to audit",
        "L0a1": "result does not include recursive reductions to audit",
    }
    for notation, note in skipped_notes.items():
        evidence = rows[notation]["input_certification_evidence"]
        audit = evidence["terminal_contribution_audit"]
        assert evidence["terminal_contribution_audit_skipped"] is True
        assert audit["reduction_contribution_witness_consistency"]["matched"] is True
        assert audit["reduction_contribution_witness_summary"][
            "reduction_contribution_count"
        ] == 0
        assert audit["notes"] == [note]
