from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.skipif(sys.platform != "win32", reason="Windows PowerShell script test")
def test_dev_wrapper_script_mode_does_not_need_powershell_on_path() -> None:
    powershell = shutil.which("powershell.exe")
    if powershell is None:
        pytest.skip("powershell.exe is not available")

    env = os.environ.copy()
    env["Path"] = r"C:\Windows\System32;C:\Windows"

    result = subprocess.run(
        [
            powershell,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(REPO_ROOT / "scripts" / "dev.ps1"),
            "-NoMsvc",
            "-Script",
            "Write-Output ok",
        ],
        cwd=REPO_ROOT,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )

    assert result.stdout.strip() == "ok"
