from __future__ import annotations

from iroll import Polyline3D
from iroll.topology import (
    analyze_curve,
    build_knot_diagram,
    classify_curve,
    find_curve_crossings,
    mirror_laurent_polynomial,
)
from iroll.topology.classify import knot_determinant
from iroll.topology.diagram import alexander_polynomial_from_diagram, knot_determinant_from_diagram
from tests.fixtures import circle_points, trefoil_points


def test_empty_circle_diagram_is_json_friendly() -> None:
    curve = Polyline3D(circle_points(count=64), closed=True)
    diagram = build_knot_diagram(find_curve_crossings(curve, direction=[0.0, 0.0, 1.0]))

    payload = diagram.to_dict(include_matrix=True)

    assert payload["crossing_count"] == 0
    assert payload["arc_count"] == 0
    assert payload["gauss_code"] == []
    assert payload["coloring_matrix"] == []


def test_trefoil_diagram_exposes_arcs_gauss_code_and_coloring_matrix() -> None:
    curve = Polyline3D(trefoil_points(), closed=True)
    crossings = find_curve_crossings(curve, direction=[0.0, 0.0, 1.0])
    diagram = build_knot_diagram(crossings)
    payload = diagram.to_dict(include_matrix=True)

    assert diagram.crossing_count == 3
    assert diagram.arc_count == 3
    assert len(payload["gauss_code"]) == 6
    assert len(payload["pd_code"]) == 3
    assert all(len(item["code"]) == 4 for item in payload["pd_code"])
    assert len(payload["arc_relations"]) == 3
    assert knot_determinant_from_diagram(diagram) == 3
    assert knot_determinant(crossings) == 3
    assert alexander_polynomial_from_diagram(diagram) is not None


def test_classification_includes_arc_count() -> None:
    curve = Polyline3D(trefoil_points(), closed=True)
    result = classify_curve(curve, direction=[0.0, 0.0, 1.0])

    assert result.arc_count == 3
    assert result.to_dict()["arc_count"] == 3


def test_analyze_curve_includes_diagram_summary() -> None:
    curve = Polyline3D(trefoil_points(), closed=True)
    report = analyze_curve(curve, direction=[0.0, 0.0, 1.0])

    assert report["topology"]["diagram"]["crossing_count"] == 3
    assert report["topology"]["diagram"]["arc_count"] == 3
    assert len(report["topology"]["diagram"]["gauss_code"]) == 6
    assert len(report["topology"]["diagram"]["pd_code"]) == 3
    assert "coloring_matrix" not in report["topology"]["diagram"]


def test_analyze_curve_can_include_diagram_matrix() -> None:
    curve = Polyline3D(trefoil_points(), closed=True)
    report = analyze_curve(
        curve,
        direction=[0.0, 0.0, 1.0],
        include_diagram_matrix=True,
    )

    assert report["topology"]["diagram"]["coloring_matrix"]


def test_mirror_laurent_polynomial_replaces_t_by_inverse() -> None:
    assert mirror_laurent_polynomial("t^-1 + t^-3 - t^-4") == "-t^4 + t^3 + t"
