from __future__ import annotations

import numpy as np
import pytest

from iroll import Polyline3D
from tests.fixtures import circle_points, line_points


def test_open_polyline_validation_and_counts() -> None:
    curve = Polyline3D(line_points(5), closed=False, name="line")

    assert curve.point_count == 5
    assert curve.segment_count == 4
    assert curve.name == "line"


def test_closed_polyline_strips_duplicate_endpoint() -> None:
    points = circle_points(count=16)
    duplicated = np.vstack([points, points[0]])

    curve = Polyline3D(duplicated, closed=True)

    assert curve.point_count == 16
    assert curve.segment_count == 16
    assert np.allclose(curve.copy_points(close=True)[0], curve.copy_points(close=True)[-1])


def test_invalid_shape_raises() -> None:
    with pytest.raises(ValueError, match="shape"):
        Polyline3D([1.0, 2.0, 3.0])


def test_zero_length_segment_raises() -> None:
    points = np.array([[0.0, 0.0, 0.0], [0.0, 0.0, 0.0], [1.0, 0.0, 0.0]])

    with pytest.raises(ValueError, match="zero-length"):
        Polyline3D(points)


def test_geometry_summary_is_json_friendly() -> None:
    curve = Polyline3D(circle_points(radius=2.0, count=64), closed=True)
    summary = curve.geometry_summary()

    assert summary["closed"] is True
    assert summary["point_count"] == 64
    assert isinstance(summary["arc_length"], float)
    assert isinstance(summary["curvature"]["mean"], float)
