from __future__ import annotations

import numpy as np
import pytest

from iroll import Link3D, Polyline3D
from iroll.kernels import backend_report, segment_segment_distance
from iroll.topology import (
    analyze_curve,
    analyze_link,
    find_curve_contacts,
    find_link_contacts,
)


def backend_available(name: str) -> bool:
    return bool(backend_report()["backends"][name]["available"])


def test_segment_segment_distance_for_crossing_segments() -> None:
    distance, s, t, point_a, point_b = segment_segment_distance(
        [-1.0, 0.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, -1.0, 0.0],
        [0.0, 1.0, 0.0],
        backend="numpy",
    )

    assert np.isclose(distance, 0.0)
    assert np.isclose(s, 0.5)
    assert np.isclose(t, 0.5)
    assert np.allclose(point_a, [0.0, 0.0, 0.0])
    assert np.allclose(point_b, [0.0, 0.0, 0.0])


def test_segment_segment_distance_for_parallel_segments() -> None:
    distance, s, t, _, _ = segment_segment_distance(
        [0.0, 0.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, 0.25, 0.0],
        [1.0, 0.25, 0.0],
        backend="numpy",
    )

    assert np.isclose(distance, 0.25)
    assert 0.0 <= s <= 1.0
    assert 0.0 <= t <= 1.0


def test_curve_contacts_skip_adjacent_segments_by_default() -> None:
    curve = Polyline3D(
        np.array(
            [
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [1.0, 0.1, 0.0],
            ]
        )
    )

    contacts = find_curve_contacts(curve, threshold=0.2, backend="numpy")

    assert contacts == []


def test_curve_contacts_find_non_adjacent_close_segments() -> None:
    curve = Polyline3D(
        np.array(
            [
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [1.0, 1.0, 0.0],
                [0.0, 1.0, 0.0],
                [0.0, 0.1, 0.0],
            ]
        ),
        closed=False,
    )

    contacts = find_curve_contacts(curve, threshold=0.11, backend="numpy")

    assert len(contacts) == 1
    assert np.isclose(contacts[0].distance, 0.1)


def test_link_contacts_find_close_components() -> None:
    first = Polyline3D(np.array([[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]]))
    second = Polyline3D(np.array([[0.0, 0.05, 0.0], [1.0, 0.05, 0.0]]))
    link = Link3D([first, second])

    contacts = find_link_contacts(link, threshold=0.06, backend="numpy")

    assert len(contacts) == 1
    assert np.isclose(contacts[0].distance, 0.05)


def test_curve_contacts_gpu_matches_numpy_when_installed() -> None:
    if not backend_available("gpu"):
        pytest.skip("GPU kernels are not installed in this environment")

    curve = Polyline3D(
        np.array(
            [
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [1.0, 1.0, 0.0],
                [0.0, 1.0, 0.0],
                [0.0, 0.1, 0.0],
            ]
        ),
        closed=False,
    )

    gpu_contacts = find_curve_contacts(curve, threshold=0.11, backend="gpu")
    numpy_contacts = find_curve_contacts(curve, threshold=0.11, backend="numpy")

    assert len(gpu_contacts) == len(numpy_contacts) == 1
    assert np.isclose(gpu_contacts[0].distance, numpy_contacts[0].distance)
    assert np.allclose(gpu_contacts[0].point3d_a, numpy_contacts[0].point3d_a)
    assert np.allclose(gpu_contacts[0].point3d_b, numpy_contacts[0].point3d_b)


def test_curve_contacts_rust_matches_numpy_when_installed() -> None:
    if not backend_available("rust"):
        pytest.skip("Rust kernels are not installed in this environment")

    curve = Polyline3D(
        np.array(
            [
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [1.0, 1.0, 0.0],
                [0.0, 1.0, 0.0],
                [0.0, 0.1, 0.0],
            ]
        ),
        closed=False,
    )

    rust_contacts = find_curve_contacts(curve, threshold=0.11, backend="rust")
    numpy_contacts = find_curve_contacts(curve, threshold=0.11, backend="numpy")

    assert len(rust_contacts) == len(numpy_contacts) == 1
    assert np.isclose(rust_contacts[0].distance, numpy_contacts[0].distance)
    assert np.allclose(rust_contacts[0].point3d_a, numpy_contacts[0].point3d_a)
    assert np.allclose(rust_contacts[0].point3d_b, numpy_contacts[0].point3d_b)


def test_analyze_curve_includes_contact_summary_when_requested() -> None:
    curve = Polyline3D(
        np.array(
            [
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [1.0, 1.0, 0.0],
                [0.0, 1.0, 0.0],
                [0.0, 0.1, 0.0],
            ]
        )
    )

    report = analyze_curve(curve, contact_threshold=0.11, backend="numpy")

    assert "bounding_box" in report["geometry"]
    assert report["topology"]["contacts"]["count"] == 1


def test_analyze_link_includes_contact_summary_when_requested() -> None:
    first = Polyline3D(np.array([[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]]))
    second = Polyline3D(np.array([[0.0, 0.05, 0.0], [1.0, 0.05, 0.0]]))
    link = Link3D([first, second])

    report = analyze_link(link, contact_threshold=0.06, backend="numpy")

    assert report["topology"]["contacts"]["count"] == 1
