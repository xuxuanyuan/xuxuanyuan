from __future__ import annotations

from collections import Counter
from contextlib import contextmanager
import json
import math
from pathlib import Path
import shutil
import uuid

import numpy as np

from iroll.cli import (
    _signed_pd_input_from_payload,
    _signed_pd_input_report,
    _source_candidate_replay_metadata,
    main,
)
from iroll.io import load_points, load_ribbon_json
from iroll.kernels import backend_report
from iroll.topology import MultivariateLaurentPolynomial, get_diagram_fixture
from tests.fixtures import circle_points, hopf_link_points


@contextmanager
def workspace_tempdir():
    root = Path(".test-tmp")
    path = root / uuid.uuid4().hex
    path.mkdir(parents=True, exist_ok=False)
    try:
        yield path
    finally:
        shutil.rmtree(path, ignore_errors=True)


def _assert_strict_json_serializable(*payloads: dict) -> None:
    for payload in payloads:
        json.dumps(payload, allow_nan=False)


def test_source_candidate_replay_metadata_rejects_non_finite_lists() -> None:
    try:
        _source_candidate_replay_metadata(
            {
                "source_notation": "L2a1",
                "pairwise_linking": [math.nan],
            }
        )
    except ValueError as exc:
        assert "Out of range float values" in str(exc)
    else:
        raise AssertionError("source candidate replay metadata accepted NaN")


def _synthetic_nonmaximal_alexander_result() -> dict:
    variables = ("t1", "t2")

    def polynomial(terms: dict[tuple[int, int], int]) -> MultivariateLaurentPolynomial:
        return MultivariateLaurentPolynomial.from_dict(terms, variables=variables)

    divisor = polynomial({(0, 0): 1, (1, 0): -1})
    common_quotient = polynomial({(0, 0): 1, (0, 1): -1})
    extra = polynomial({(0, 0): 1, (1, 0): -1})
    minors = [divisor * common_quotient, divisor * common_quotient * extra]
    minor_rows = [
        {
            "rows": [index],
            "columns": [index],
            "polynomial": minor.normalize_unit().format(),
            "terms": [
                {"exponents": list(exponents), "coefficient": coefficient}
                for exponents, coefficient in minor.terms
            ],
            "is_zero": minor.is_zero,
        }
        for index, minor in enumerate(minors)
    ]
    summary = {
        "complete_combination_scan": True,
        "nonzero_minor_coverage_complete": True,
    }
    return {
        "method": "synthetic_nonmaximal_scanned_gcd_candidate",
        "multivariable_alexander_polynomial": divisor.format(),
        "candidate_polynomials": [row["polynomial"] for row in minor_rows],
        "presentation": {"variables": list(variables)},
        "square_minors": {
            "method": "synthetic_square_minor_scan",
            "variables": list(variables),
            "skipped": False,
            "truncated": False,
            "minors": minor_rows,
            "admissible_minor_summary": summary,
        },
        "admissible_minor_summary": summary,
        "requires_normalization": False,
        "skipped": False,
        "notes": ["synthetic non-maximal scanned gcd candidate"],
    }


def _synthetic_alexander_input_certification_evidence() -> dict:
    return {
        "method": "multivariable_alexander_input_certification_evidence",
        "claim_scope": "exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        "source_method": "multivariable_alexander_from_pd",
        "multivariable_alexander_polynomial": "1",
        "variables": ["t1", "t2"],
        "candidate_polynomials": ["1 - t1", "1 - t2"],
        "bounded_scanned_gcd_certified": True,
        "candidate_is_exact_scanned_gcd": True,
        "complete_scanned_gcd_certified": True,
        "quotient_gcd_certified": True,
        "quotient_gcd_polynomial": "1",
        "quotient_gcd_method": "fox_square_minor_quotient_unit_gcd",
        "improved_candidate_polynomial": None,
        "bounded_admissible_minor_normalization_certified": True,
        "all_nonzero_minors_laurent_unit_equivalent": True,
        "admissible_minor_normalized_representative_polynomial": "1",
        "admissible_minor_normalization_checked_nonzero_minor_count": 2,
        "admissible_minor_normalization_failed_nonzero_minor_count": 0,
        "checked_nonzero_minor_count": 2,
        "failed_nonzero_minor_count": 0,
        "failed_minor_count": 0,
        "division_record_count": 2,
        "scanned_minor_count": 2,
        "nonzero_minor_count": 2,
        "zero_minor_count": 0,
        "unit_minor_count": 2,
        "all_rows_have_nonzero_minor": True,
        "all_columns_have_nonzero_minor": True,
        "nonzero_minor_coverage_complete": True,
        "wirtinger_fox_input_chain_consistent": True,
        "wirtinger_presentation_valid": True,
        "wirtinger_relation_shape_valid": True,
        "wirtinger_relation_shape_invalid_count": 0,
        "wirtinger_relation_shape_witness_count": 0,
        "wirtinger_relation_shape_count_consistent": True,
        "wirtinger_generator_component_coverage_complete": True,
        "wirtinger_generator_component_count_row_count": 2,
        "wirtinger_generator_component_count_total": 2,
        "wirtinger_generator_component_count_consistent": True,
        "fox_jacobian_valid": True,
        "fox_square_minor_scan_valid": True,
        "wirtinger_relation_count": 2,
        "wirtinger_generator_count": 2,
        "fox_jacobian_row_count": 2,
        "fox_jacobian_column_count": 2,
        "fox_square_minor_invalid_reference_count": 0,
        "fox_square_minor_invalid_normalization_count": 0,
        "complete_combination_scan": True,
        "truncated": False,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "skipped": False,
        "notes": [
            "input evidence is limited to the scanned Fox-minor set and does not certify full admissible-minor normalization",
        ],
    }


def _synthetic_alexander_minor_divisibility_audit() -> dict:
    return {
        "method": "multivariable_alexander_minor_divisibility_audit",
        "claim_scope": "bounded_scanned_fox_minor_divisibility",
        "source_method": "synthetic_nonmaximal_scanned_gcd_candidate",
        "multivariable_alexander_polynomial": "1 - t1",
        "variables": ["t1", "t2"],
        "candidate_polynomials": ["1 - t1 - t2 + t1*t2"],
        "all_nonzero_minors_divisible": True,
        "checked_nonzero_minor_count": 2,
        "failed_nonzero_minor_count": 0,
        "division_records": [
            {"minor_index": 0, "divisible": True},
            {"minor_index": 1, "divisible": True},
        ],
        "complete_combination_scan": True,
        "truncated": False,
        "admissible_minor_summary": {
            "scanned_minor_count": 2,
            "nonzero_minor_count": 2,
            "zero_minor_count": 0,
            "unit_minor_count": 0,
            "complete_combination_scan": True,
            "nonzero_minor_coverage_complete": True,
        },
        "full_invariant_certified": False,
        "skipped": False,
        "notes": [
            "reported polynomial divides every nonzero scanned Fox minor by exact multivariate division",
        ],
    }


def _synthetic_homfly_skein_identity_audit() -> dict:
    return {
        "method": "homfly_skein_identity_audit",
        "claim_scope": "local_homfly_skein_identity_for_signed_pd_input",
        "normalization": "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1",
        "crossing_count": 2,
        "checked_crossing_count": 2,
        "max_crossings": 8,
        "max_depth": 12,
        "max_nodes": 2048,
        "matched": True,
        "skipped": False,
        "truncated": False,
        "crossing_audits": [
            {
                "crossing_index": 0,
                "matched": True,
                "skipped": False,
                "truncated": False,
                "branches": {
                    "positive": {"frontier_count": 0, "truncated": False},
                    "negative": {"frontier_count": 0, "truncated": False},
                    "smoothed": {"frontier_count": 0, "truncated": False},
                },
                "difference": "0",
                "notes": [],
            },
            {
                "crossing_index": 1,
                "matched": True,
                "skipped": False,
                "truncated": False,
                "branches": {
                    "positive": {"frontier_count": 0, "truncated": False},
                    "negative": {"frontier_count": 0, "truncated": False},
                    "smoothed": {"frontier_count": 0, "truncated": False},
                },
                "difference": "0",
                "notes": [],
            },
        ],
        "notes": [
            "each audited crossing is checked by exact sparse Laurent arithmetic in a,z",
        ],
    }


def _synthetic_homfly_input_certification_evidence() -> dict:
    return {
        "method": "homfly_input_certification_evidence",
        "claim_scope": "recursive_frontier_exhaustion_for_one_signed_pd_input",
        "evaluation_method": "certified_iterative_recursive_homfly",
        "homfly_polynomial": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
        "max_crossings": 8,
        "max_depth": 8,
        "max_nodes": 2048,
        "initial_depth": 0,
        "iterative_attempt_count": 3,
        "iterative_solved_depth": 2,
        "iterative_depth_attempts": [],
        "certified_for_input": True,
        "frontier_exhausted": True,
        "zero_crossing_certified": False,
        "full_table_normalization_certified": False,
        "arbitrary_diagram_coverage_certified": False,
        "recursion_nodes": 12,
        "cache_hits": 2,
        "terminal_reduction_count": 3,
        "memoized_reduction_count": 1,
        "reduction_contribution_count": 4,
        "parsed_reduction_contribution_count": 4,
        "unparsed_reduction_contribution_count": 0,
        "reduction_contribution_witness_count": 2,
        "reduction_contribution_witness_limit": 8,
        "reduction_contribution_witnesses_truncated": False,
        "first_reduction_contribution_witness": {
            "index": 0,
            "reduction_kind": "terminal",
            "contribution": "1",
        },
        "reduction_contribution_witnesses": [
            {"index": 0, "reduction_kind": "terminal", "contribution": "1"},
            {"index": 1, "reduction_kind": "memoized_subtree", "contribution": "a"},
        ],
        "reduction_contribution_witness_consistency": {
            "matched": True,
            "mismatch_count": 0,
        },
        "terminal_contribution_sum": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
        "terminal_contribution_matches_result": True,
        "terminal_contribution_audit_skipped": False,
        "frontier_count": 0,
        "frontier_reason_count": 0,
        "frontier_reasons": [],
        "truncated": False,
        "certification_blockers": [],
        "certification_blocker_count": 0,
        "certification_blocker_details": [],
        "certification_blocker_detail_count": 0,
        "homfly_completion_blockers": [
            "full_table_normalization_not_certified",
            "arbitrary_diagram_coverage_not_certified",
        ],
        "homfly_completion_blocker_count": 2,
        "homfly_completion_blocker_details": [
            {
                "code": "full_table_normalization_not_certified",
                "severity": "blocking",
                "scope": "homfly_completion",
                "reason": (
                    "external HOMFLY table normalization has not been certified"
                ),
                "cap": {"full_table_normalization_certified": False},
            },
            {
                "code": "arbitrary_diagram_coverage_not_certified",
                "severity": "blocking",
                "scope": "homfly_completion",
                "reason": (
                    "generated/input-scoped evidence does not certify arbitrary signed-PD coverage"
                ),
                "cap": {"arbitrary_diagram_coverage_certified": False},
            },
        ],
        "homfly_completion_blocker_detail_count": 2,
        "skipped": False,
        "notes": [
            "input evidence is limited to this supplied signed-PD payload and does not certify table normalization",
        ],
    }


def _synthetic_homfly_compact_evidence_report() -> dict:
    return {
        "method": "homfly_input_certification_evidence",
        "claim_scope": "recursive_frontier_exhaustion_for_one_signed_pd_input",
        "homfly_polynomial": "P",
        "certified_for_input": False,
        "frontier_exhausted": False,
        "terminal_contribution_audit_skipped": True,
        "frontier_count": 1,
        "frontier_reason_count": 1,
        "frontier_witness_summary": {
            "method": "homfly_frontier_witness_summary",
            "claim_scope": "capped_frontier_witness_diagnostics",
            "frontier_count": 1,
            "witness_count": 1,
            "frontier_witness_limit": 8,
            "witness_summary_truncated": False,
            "reason_counts": [
                {"reason": "max_depth", "witness_count": 1},
            ],
            "reason_count": 1,
            "min_depth": 4,
            "max_depth": 4,
            "recursive_path_prefix_counts": [
                {"path_prefix": ["root", "left"], "witness_count": 1},
            ],
            "recursive_path_prefix_count": 1,
            "source_kind_counts": [
                {"source_kind": "skein_leaf", "witness_count": 1},
            ],
            "source_kind_count": 1,
            "branch_counts": [
                {"branch": "L", "witness_count": 1},
            ],
            "branch_count": 1,
            "min_branch_depth": 1,
            "max_branch_depth": 1,
            "branch_path_prefix_counts": [],
            "run_cap_frontier_pressure": {
                "frontier_count": 1,
                "witness_count": 1,
                "unwitnessed_frontier_count": 0,
                "all_frontier_witnessed": True,
                "frontier_reason_counts_available": True,
                "first_witness_reason": "max_depth",
                "first_unwitnessed_reason": None,
                "reason_counts": [
                    {
                        "reason": "max_depth",
                        "frontier_count": 1,
                        "witness_count": 1,
                        "unwitnessed_frontier_count": 0,
                        "all_frontier_witnessed": True,
                    }
                ],
                "reason_count": 1,
            },
            "notes": [
                "computed only from capped frontier_witnesses",
            ],
        },
        "truncated": False,
        "certification_blockers": ["frontier_not_exhausted"],
        "certification_blocker_count": 1,
        "certification_blocker_details": [
            {
                "code": "frontier_not_exhausted",
                "severity": "blocking",
                "scope": "input_certification",
            }
        ],
        "certification_blocker_detail_count": 1,
        "homfly_completion_blockers": ["full_table_normalization_not_certified"],
        "homfly_completion_blocker_count": 1,
        "arbitrary_diagram_completion_gate": {
            "completion_blocker_provenance": {
                "method": "homfly_completion_blocker_provenance",
                "claim_scope": "bounded_non_claim_completion_blocker_provenance",
                "matched": True,
                "completion_blocker_code": (
                    "arbitrary_diagram_coverage_not_certified"
                ),
                "completion_blocked": True,
                "arbitrary_diagram_coverage_certified": False,
                "non_claim_matched": True,
                "gate_pressure_consistency_matched": True,
                "frontier_pressure_counts_matched": True,
                "frontier_witness_consistency_matched": True,
                "terminal_audit_consistency_matched": True,
                "source_fields": [
                    "arbitrary_diagram_completion_gate.blocked",
                    "arbitrary_diagram_completion_gate.gate_pressure_consistency",
                    "arbitrary_diagram_completion_gate.frontier_witnesses",
                ],
            }
        },
        "homfly_completion_blocker_details": [
            {
                "code": "full_table_normalization_not_certified",
                "severity": "blocking",
                "scope": "homfly_completion",
            }
        ],
        "homfly_completion_blocker_detail_count": 1,
        "skipped": False,
        "notes": ["bounded HOMFLY diagnostic row"],
    }


def _synthetic_alexander_compact_witness_report() -> dict:
    return {
        "method": "multivariable_alexander_input_certification_evidence",
        "claim_scope": "exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        "multivariable_alexander_polynomial": "1 + t1",
        "bounded_scanned_gcd_certified": False,
        "complete_scanned_gcd_certified": False,
        "quotient_gcd_certified": False,
        "failed_nonzero_minor_count": 1,
        "failed_division_witness_count": 1,
        "failed_division_witness_limit": 8,
        "failed_division_witnesses": [
            {
                "minor_index": 3,
                "rows": [0],
                "columns": [1],
                "minor_polynomial": "1 - t1",
                "divisible": False,
                "quotient_polynomial": None,
                "reason": "source_does_not_divide_all_inputs",
            }
        ],
        "quotient_gcd_uncertainty_evidence": {
            "method": "fox_square_minor_quotient_gcd_uncertainty_evidence",
            "status": "not_certified",
            "certified": False,
        },
        "admissible_minor_normalization_blocker_details": {
            "normalization_class_not_unique": {
                "normalization_class_witness_count": 2,
                "normalization_class_witnesses": [
                    {
                        "normalized_polynomial": "1 - t1",
                        "minor_count": 1,
                    },
                    {
                        "normalized_polynomial": "1 + t1",
                        "minor_count": 1,
                    },
                ],
            },
        },
        "bounded_admissible_minor_normalization_blocker_witness_summary": {
            "method": (
                "bounded_admissible_minor_normalization_blocker_witness_summary"
            ),
            "reason_count": 3,
            "witness_available_count": 1,
            "missing_witness_reasons": [
                {
                    "reason": "quotient_gcd_uncertainty_witness_missing",
                    "witness_available": False,
                },
                "normalization_representative_witness_missing",
            ],
            "missing_witness_reason_count": 2,
            "blocker_witness_sources": [
                {
                    "reason": "normalization_class_not_unique",
                    "source_kind": "normalization_class_witness",
                    "status": "available",
                    "witness_available": True,
                },
                {
                    "reason": "failed_division_witness_present",
                    "source_kind": "failed_division_witness",
                    "status": "available",
                    "witness_available": True,
                },
                {
                    "reason": "quotient_gcd_uncertainty_witness_missing",
                    "source_kind": "quotient_gcd_uncertainty_witness",
                    "status": "missing",
                    "witness_available": False,
                },
                {
                    "reason": "normalization_representative_witness_missing",
                    "source_kind": "normalization_representative_witness",
                    "status": "missing",
                    "witness_available": False,
                },
            ],
            "blocker_witness_source_count": 4,
            "blocker_witness_source_available_count": 2,
            "blocker_witness_source_missing_count": 2,
            "blocker_witness_source_counts_by_reason": [
                {
                    "reason": "normalization_class_not_unique",
                    "witness_source_count": 1,
                },
                {
                    "reason": "failed_division_witness_present",
                    "witness_source_count": 1,
                },
                {
                    "reason": "quotient_gcd_uncertainty_witness_missing",
                    "witness_source_count": 1,
                },
                {
                    "reason": "normalization_representative_witness_missing",
                    "witness_source_count": 1,
                },
            ],
            "blocker_witness_source_available_counts_by_reason": [
                {
                    "reason": "normalization_class_not_unique",
                    "witness_source_count": 1,
                },
                {
                    "reason": "failed_division_witness_present",
                    "witness_source_count": 1,
                },
            ],
            "blocker_witness_source_missing_counts_by_reason": [
                {
                    "reason": "quotient_gcd_uncertainty_witness_missing",
                    "witness_source_count": 1,
                },
                {
                    "reason": "normalization_representative_witness_missing",
                    "witness_source_count": 1,
                },
            ],
            "first_witness_source": {
                "source_kind": "normalization_class_witness",
                "status": "available",
            },
            "summary_consistency": {
                "matched": True,
                "reason_count_matched": True,
                "witness_available_count_matched": True,
                "missing_witness_reason_count_matched": True,
                "blocker_witness_source_count_matched": True,
                "blocker_witness_source_available_count_matched": True,
                "blocker_witness_source_missing_count_matched": True,
            },
        },
        "bounded_admissible_minor_normalization_gate_summary": {
            "method": "bounded_admissible_minor_normalization_gate_summary",
            "gate_count": 5,
            "passed_gate_count": 2,
            "failed_gate_count": 3,
            "failed_gate_blockers": [
                "candidate_not_exact_scanned_gcd",
                "quotient_gcd_uncertified",
                "normalization_class_not_unique",
            ],
            "failed_gate_blocker_count": 3,
            "failed_gate_blocker_provenance_consistency": {
                "method": (
                    "bounded_admissible_minor_normalization_failed_gate_blocker_provenance_consistency"
                ),
                "normalization_gate_provenance_consistent": True,
                "failed_gate_names": [
                    "exact_scanned_gcd",
                    "quotient_gcd",
                    "unique_normalized_class",
                ],
                "failed_gate_count": 3,
                "failed_gate_blocker_provenance_row_count": 3,
                "failed_gate_blocker_attribution_count": 3,
                "failed_gate_blocker_provenance_row_reason_counts": {
                    "exact_scanned_gcd_not_certified": 1,
                    "quotient_gcd_uncertified": 1,
                    "normalization_class_not_unique": 1,
                },
                "failed_gate_blocker_provenance_source_available_count": 2,
                "failed_gate_blocker_provenance_source_missing_count": 1,
                "failed_gate_blocker_provenance_missing_source_blockers": [
                    "quotient_gcd_uncertified",
                ],
                "failed_gate_blocker_provenance_inconsistent_source_blockers": [],
            },
            "summary_consistency": {
                "gate_blocker_summary_consistent": True,
            },
        },
        "wirtinger_fox_input_chain_consistent": True,
        "full_invariant_certified": False,
        "skipped": False,
        "notes": ["bounded Alexander diagnostic row"],
    }


def _assert_cli_blocker_detail_codes(payload: dict, key: str, codes: list[str]) -> None:
    details = payload[key]
    assert [row["code"] for row in details] == codes
    assert all(row["severity"] == "blocking" for row in details)
    assert all(row["reason"] for row in details)
    assert all("cap" in row or "witness" in row for row in details)


def _cli_optional_int(value) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _cli_witness_path(witness: dict, *fields: str) -> list[str]:
    for field in fields:
        raw_path = witness.get(field)
        if isinstance(raw_path, list):
            return [str(step) for step in raw_path]
    return []


def _cli_witness_count_records(counter: Counter, key: str) -> list[dict]:
    return [
        {key: value, "witness_count": counter[value]}
        for value in sorted(counter)
    ]


def _cli_witness_path_prefix_records(counter: Counter) -> list[dict]:
    return [
        {"path_prefix": list(value), "witness_count": counter[value]}
        for value in sorted(counter)
    ]


def _assert_cli_homfly_frontier_witness_summary(payload: dict) -> None:
    summary = payload["frontier_witness_summary"]
    witnesses = [
        witness
        for witness in payload.get("frontier_witnesses", []) or []
        if isinstance(witness, dict)
    ]
    reason_counts: Counter[str] = Counter()
    source_kind_counts: Counter[str] = Counter()
    branch_counts: Counter[str] = Counter()
    recursive_path_prefix_counts: Counter[tuple[str, ...]] = Counter()
    branch_path_prefix_counts: Counter[tuple[str, ...]] = Counter()
    depths: list[int] = []
    branch_depths: list[int] = []

    for witness in witnesses:
        if witness.get("reason"):
            reason_counts[str(witness["reason"])] += 1
        if witness.get("source_kind") is not None:
            source_kind_counts[str(witness["source_kind"])] += 1
        if witness.get("branch") is not None:
            branch_counts[str(witness["branch"])] += 1
        depth = _cli_optional_int(
            witness.get("recursive_depth", witness.get("depth"))
        )
        if depth is not None:
            depths.append(depth)
        branch_depth = _cli_optional_int(witness.get("branch_depth"))
        if branch_depth is not None:
            branch_depths.append(branch_depth)
        recursive_path = _cli_witness_path(witness, "recursive_path", "path")
        if recursive_path:
            recursive_path_prefix_counts[tuple(recursive_path[:2])] += 1
        branch_path = _cli_witness_path(witness, "branch_path")
        if branch_path:
            branch_path_prefix_counts[tuple(branch_path[:2])] += 1

    assert summary["method"] == "homfly_frontier_witness_summary"
    assert summary["frontier_count"] == int(payload.get("frontier_count", 0) or 0)
    assert summary["witness_count"] == len(witnesses)
    assert summary["frontier_witness_limit"] == int(
        payload.get("frontier_witness_limit", 8) or 8
    )
    assert summary["witness_summary_truncated"] is bool(
        payload.get("frontier_witnesses_truncated", False)
    )
    assert summary["reason_counts"] == _cli_witness_count_records(
        reason_counts,
        "reason",
    )
    assert summary["reason_count"] == len(reason_counts)
    assert summary["min_depth"] == (min(depths) if depths else None)
    assert summary["max_depth"] == (max(depths) if depths else None)
    assert summary["recursive_path_prefix_counts"] == (
        _cli_witness_path_prefix_records(recursive_path_prefix_counts)
    )
    assert summary["recursive_path_prefix_count"] == len(
        recursive_path_prefix_counts
    )
    assert summary["source_kind_counts"] == _cli_witness_count_records(
        source_kind_counts,
        "source_kind",
    )
    assert summary["source_kind_count"] == len(source_kind_counts)
    assert summary["branch_counts"] == _cli_witness_count_records(
        branch_counts,
        "branch",
    )
    assert summary["branch_count"] == len(branch_counts)
    assert summary["min_branch_depth"] == (
        min(branch_depths) if branch_depths else None
    )
    assert summary["max_branch_depth"] == (
        max(branch_depths) if branch_depths else None
    )
    assert summary["branch_path_prefix_counts"] == (
        _cli_witness_path_prefix_records(branch_path_prefix_counts)
    )


def _assert_cli_homfly_frontier_witness_consistency(payload: dict) -> None:
    consistency = payload["frontier_witness_consistency"]
    witnesses = payload.get("frontier_witnesses", []) or []
    expected_first = witnesses[0] if witnesses else None

    _assert_cli_homfly_frontier_witness_summary(payload)
    assert consistency["method"] == "homfly_frontier_witness_consistency"
    assert consistency["matched"] is True
    assert consistency["frontier_witness_count"] == payload[
        "frontier_witness_count"
    ]
    assert consistency["frontier_witness_list_count"] == len(witnesses)
    assert consistency["frontier_witness_limit"] == payload[
        "frontier_witness_limit"
    ]
    assert consistency["frontier_witnesses_truncated"] is payload[
        "frontier_witnesses_truncated"
    ]
    assert consistency["expected_first_frontier_witness"] == expected_first
    assert consistency["witness_count_matches_list_count"] is True
    assert consistency["first_frontier_witness_matches_list"] is True
    assert consistency["truncated_matches_witness_count"] is True
    assert consistency["truncated_matches_witness_list"] is True
    assert consistency["mismatch_count"] == 0


def _assert_cli_homfly_arbitrary_completion_gate(gate: dict) -> None:
    assert gate["method"] == "homfly_arbitrary_signed_pd_completion_gate"
    assert gate["claim_scope"] == "arbitrary_signed_pd_homfly_completion_gate"
    assert gate["arbitrary_diagram_coverage_certified"] is False
    assert gate["blocked"] is True
    assert gate["frontier_reason_count"] == len(gate["frontier_reasons"])
    assert gate["frontier_witness_count"] == len(
        gate.get("frontier_witnesses", [])
    )
    assert gate["first_frontier_witness"] == (
        gate["frontier_witnesses"][0] if gate["frontier_witnesses"] else None
    )
    assert gate["frontier_witnesses_truncated"] is (
        gate["frontier_count"] > gate["frontier_witness_count"]
    )
    _assert_cli_homfly_frontier_witness_consistency(gate)
    assert gate["certification_blocker_count"] == len(
        gate["certification_blockers"]
    )
    assert sum(
        row["blocker_count"] for row in gate["certification_blocker_code_counts"]
    ) == gate["certification_blocker_count"]
    assert sum(
        row["detail_count"]
        for row in gate["certification_blocker_detail_code_counts"]
    ) == gate["certification_blocker_detail_count"]
    assert gate["convention_blocker_count"] == len(gate["convention_blockers"])
    if gate["evidence_scope"] == "generated_small_signed_pd_coverage":
        assert gate["blocker_detail_code_count_consistency_matched"] is True


def _assert_cli_homfly_pd_top_level_blocker_fields_match_evidence(
    payload: dict,
) -> None:
    evidence = payload["input_certification_evidence"]
    for key in (
        "certification_blockers",
        "certification_blocker_count",
        "certification_blocker_details",
        "certification_blocker_detail_count",
        "homfly_completion_blockers",
        "homfly_completion_blocker_count",
        "homfly_completion_blocker_details",
        "homfly_completion_blocker_detail_count",
    ):
        assert payload[key] == evidence[key]


def _assert_cli_homfly_source_notation_summary_consistency(payload: dict) -> None:
    consistency = payload["source_notation_summary_consistency"]
    assert consistency["method"] == "homfly_source_notation_summary_consistency"
    assert consistency["matched"] is True
    assert consistency["count_totals_matched"] is True
    assert consistency["distribution_totals_matched"] is True
    assert consistency["frontier_reason_counts_matched"] is True
    assert consistency["frontier_witness_summary_matched"] is True
    assert consistency["source_notation_count_matches_fixture_count"] is True
    assert consistency["source_count_totals"]["case_count"] == payload["case_count"]
    assert consistency["report_count_totals"]["case_count"] == payload["case_count"]
    assert consistency["source_frontier_reason_counts"] == payload[
        "frontier_reason_counts"
    ]
    assert consistency["report_frontier_reason_counts"] == payload[
        "frontier_reason_counts"
    ]
    assert consistency["report_frontier_witness_summary"] == payload[
        "frontier_witness_summary"
    ]
    assert consistency["source_frontier_witness_summary"] == payload[
        "frontier_witness_summary"
    ]


def _assert_cli_homfly_blocker_detail_code_count_consistency(
    payload: dict,
) -> None:
    frontier_consistency = payload["case_evidence_consistency"][
        "frontier_witness_consistency"
    ]
    assert frontier_consistency["method"] == (
        "homfly_case_frontier_witness_consistency"
    )
    assert frontier_consistency["matched"] is True
    assert frontier_consistency["checked_case_count"] == payload["case_count"]
    assert frontier_consistency["missing_evidence_count"] == 0
    assert (
        frontier_consistency["case_frontier_witness_consistency_matched"]
        is True
    )
    assert (
        frontier_consistency["evidence_frontier_witness_consistency_matched"]
        is True
    )
    assert frontier_consistency["mismatch_count"] == 0
    assert payload["case_evidence_consistency"][
        "frontier_witness_consistency_matched"
    ] is True

    consistency = payload["case_evidence_consistency"][
        "blocker_detail_code_count_consistency"
    ]
    assert consistency["method"] == "homfly_blocker_detail_code_count_consistency"
    assert consistency["matched"] is True
    assert consistency["checked_case_count"] == payload["case_count"]
    assert consistency["missing_evidence_count"] == 0
    assert consistency["report_completion_blocker_code_counts"] == payload[
        "homfly_completion_blocker_code_counts"
    ]
    assert consistency["report_completion_blocker_detail_code_counts"] == payload[
        "homfly_completion_blocker_detail_code_counts"
    ]
    assert consistency["evidence_completion_blocker_code_counts"] == (
        consistency["expected_case_completion_blocker_code_counts"]
    )
    assert consistency["evidence_completion_blocker_detail_code_counts"] == (
        consistency["expected_case_completion_blocker_detail_code_counts"]
    )
    assert consistency["case_completion_blocker_detail_code_count_mismatch_count"] == 0
    assert consistency["mismatch_count"] == 0


def _assert_cli_alexander_source_notation_summary_consistency(payload: dict) -> None:
    consistency = payload["source_notation_summary_consistency"]
    assert consistency["method"] == (
        "multivariable_alexander_source_notation_summary_consistency"
    )
    assert consistency["matched"] is True
    assert consistency["count_totals_matched"] is True
    assert consistency["source_notation_count_matches_fixture_count"] is True
    assert consistency["source_count_totals"]["case_count"] == payload["case_count"]
    assert consistency["report_count_totals"]["case_count"] == payload["case_count"]
    assert consistency["source_count_totals"] == consistency["report_count_totals"]
    assert consistency["full_admissible_minor_normalization_certified"] is False
    assert consistency["full_invariant_certified"] is False


HOMFLY_SOURCE_NOTATION_SUMMARY_CONSISTENCY_NOTE = (
    "source_notation_summary_consistency=matched=True; "
    "count_totals_matched=True; "
    "distribution_totals_matched=True; "
    "frontier_reason_counts_matched=True; "
    "source_notation_count_matches_fixture_count=True"
)

ALEXANDER_SOURCE_NOTATION_SUMMARY_CONSISTENCY_NOTE = (
    "source_notation_summary_consistency=matched=True; "
    "count_totals_matched=True; "
    "source_notation_count_matches_fixture_count=True"
)


def test_load_points_csv_with_header() -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "points.csv"
        path.write_text("x,y,z\n0,0,0\n1,0,0\n1,1,0\n", encoding="utf-8")

        points = load_points(path)

        assert points.shape == (3, 3)
        assert np.allclose(points[-1], [1.0, 1.0, 0.0])


def test_load_points_json_object() -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "points.json"
        path.write_text(json.dumps({"points": [[0, 0, 0], [1, 0, 0]]}), encoding="utf-8")

        points = load_points(path)

        assert points.shape == (2, 3)


def test_cli_analyze_curve_prints_json(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "circle.json"
        path.write_text(json.dumps({"points": circle_points(count=64).tolist()}), encoding="utf-8")

        exit_code = main(
            [
                "analyze-curve",
                str(path),
                "--closed",
                "--name",
                "circle",
                "--direction",
                "0,0,1",
                "--backend",
                "numpy",
                "--contact-threshold",
                "0.1",
                "--include-diagram-matrix",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

        assert exit_code == 0
        assert payload["input"]["name"] == "circle"
        assert payload["topology"]["classification"]["knot_type"] == "unknot"
        assert payload["topology"]["contacts"]["threshold"] == 0.1
        assert "coloring_matrix" in payload["topology"]["diagram"]


def test_cli_analyze_curve_reports_missing_optional_adapter(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "circle.json"
        path.write_text(json.dumps({"points": circle_points(count=64).tolist()}), encoding="utf-8")

        exit_code = main(
            [
                "analyze-curve",
                str(path),
                "--closed",
                "--adapter",
                "pyknotid",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

        assert exit_code == 0
        adapter = payload["topology"]["external_adapter"]
        assert adapter["adapter"] == "pyknotid"
        assert "available" in adapter


def test_cli_knot_table_prints_json(capsys) -> None:
    exit_code = main(["knot-table"])
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert {entry["notation"] for entry in payload["knots"]} >= {"0_1", "3_1", "4_1", "6_3"}
    assert all("jones_polynomial" in entry for entry in payload["knots"])


def test_cli_link_table_prints_json(capsys) -> None:
    exit_code = main(["link-table"])
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert {entry["link_type"] for entry in payload["links"]} >= {
        "hopf_link",
        "whitehead_link",
        "borromean_rings",
    }


def test_cli_backends_prints_diagnostics(capsys) -> None:
    exit_code = main(["backends"])
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert "segment_segment_distance" in payload["kernel_capabilities"]
    assert payload["backends"]["numpy"]["available"] is True
    assert payload["backends"]["numpy"]["capabilities"]["compute_writhe"] is True
    assert payload["backends"]["gpu"]["explicit_only"] is True
    assert "compute_gaussian_linking_number" in payload["backends"]["gpu"]["capabilities"]
    rust_backend = payload["backends"].get("rust", {})
    if not rust_backend.get("available"):
        return
    backend_info = rust_backend.get("backend_info", {})
    invariant_result_handles = backend_info.get("invariant_result_handles")
    if not invariant_result_handles:
        return
    file_recompute_boundary = invariant_result_handles["file_recompute_boundary"]
    assert file_recompute_boundary["boundary"] == "python_file_recompute"
    assert {
        "signed_pd_json",
        "imgui_signed_pd_json",
    } <= set(file_recompute_boundary["input_formats"])
    assert file_recompute_boundary["homfly_cli_command"] == "iroll homfly-pd"
    assert (
        file_recompute_boundary["alexander_cli_command"]
        == "iroll multivariable-alexander-pd"
    )
    assert {"json_file", "stdout_json"} <= set(
        file_recompute_boundary["result_transport"]
    )
    assert (
        file_recompute_boundary["host_reload_payload"]
        == "imgui-signed-pd-invariant-status-payload"
    )


def test_cli_rust_unsupported_invariant_result_handle_reports_when_installed(
    capsys,
) -> None:
    if not backend_report()["backends"]["rust"]["available"]:
        return

    with workspace_tempdir() as tmp_path:
        for invariant, status_name in (
            ("homfly", "HOMFLY-PT native result handle"),
            ("alexander", "multi-variable Alexander native result handle"),
        ):
            report_path = (
                tmp_path / f"rust-unsupported-{invariant}-result-handle-report.json"
            )
            exit_code = main(
                [
                    "rust-unsupported-invariant-result-handle-report",
                    "--invariant",
                    invariant,
                    "-o",
                    str(report_path),
                ]
            )
            capsys.readouterr()
            payload = json.loads(report_path.read_text(encoding="utf-8"))

            status_path = (
                tmp_path / f"rust-unsupported-{invariant}-result-handle-imgui-status.json"
            )
            status_exit = main(
                [
                    "imgui-invariant-status-summary-payload",
                    str(report_path),
                    "-o",
                    str(status_path),
                ]
            )
            capsys.readouterr()
            status_payload = json.loads(status_path.read_text(encoding="utf-8"))
            _assert_strict_json_serializable(payload, status_payload)

            assert exit_code == 0
            assert payload["method"] == "invariant_result_handle_report"
            assert payload["backend"] == "rust"
            assert payload["abi_version"] == 19
            assert payload["handle_kind"] == "unsupported"
            assert payload["invariant"] == invariant
            assert (
                payload["status_code"]
                == f"{invariant}_native_compute_handle_missing"
            )
            assert (
                payload["blocking_gate"]
                == f"{invariant}_native_compute_handle"
            )
            assert payload["native_computation_claimed"] is False
            assert payload["result_available"] is False
            assert payload["current_boundary"] == "python_file_recompute"
            assert payload["claim_scope"] == "unsupported_lifecycle_probe_only"

            assert status_exit == 0
            assert (
                status_payload["method"]
                == "imgui_invariant_status_payload_from_reports"
            )
            assert status_payload["invariant_status_count"] == 1
            assert status_payload["invariant_required_check_count"] == 0
            status = status_payload["invariant_statuses"][0]
            assert status["name"] == status_name
            assert status["value"] == "skipped"
            assert status["skipped"] is True
            assert (
                f"status_code={invariant}_native_compute_handle_missing"
                in status["notes"]
            )
            assert (
                f"blocking_gate={invariant}_native_compute_handle"
                in status["notes"]
            )
            assert "native_computation_claimed=false" in status["notes"]
            assert "result_available=false" in status["notes"]
            assert "claim_scope=unsupported_lifecycle_probe_only" in status["notes"]


def test_cli_validate_table_prints_validation_payload(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        table_path = tmp_path / "knots.json"
        table_path.write_text(
            json.dumps(
                {
                    "knots": [
                        {
                            "notation": "0_1",
                            "knot_type": "unknot",
                            "minimal_crossing_number": 0,
                            "determinant": 1,
                            "alexander_polynomial": "1",
                            "jones_polynomial": "1",
                            "homfly_polynomial": None,
                            "chiral": False,
                            "source": "Knot Atlas",
                            "source_url": "https://katlas.org/wiki/0_1",
                            "convention": "iroll-test",
                        }
                    ]
                }
            ),
            encoding="utf-8",
        )

        exit_code = main(["validate-table", str(table_path), "--kind", "knot"])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["valid"] is True
    assert payload["record_count"] == 1
    assert payload["source_metadata_summary"]["claim_scope"] == (
        "table_source_metadata_scan"
    )
    assert payload["source_metadata_summary"]["source_count"] == 1
    assert payload["source_metadata_summary"]["source_url_count"] == 1
    assert payload["source_metadata_summary"]["source_url_scheme_counts"] == {
        "https": 1
    }
    assert payload["source_metadata_summary"]["source_url_domain_counts"] == {
        "katlas.org": 1
    }
    assert payload["source_metadata_summary"]["source_url_without_source_count"] == 0
    assert payload["source_metadata_summary"]["provenance_review_ready"] is True
    assert payload["source_metadata_summary"]["provenance_blocker_count"] == 0
    assert payload["source_metadata_summary"]["provenance_blocker_codes"] == []
    assert payload["source_metadata_summary"]["provenance_blocker_details"] == []
    assert payload["source_metadata_summary"][
        "provenance_blocker_summary_consistency"
    ] == {
        "method": "source_metadata_provenance_blocker_summary_consistency",
        "claim_scope": "table_source_metadata_provenance_blocker_self_consistency",
        "matched": True,
        "blocker_count": 0,
        "detail_count": 0,
        "code_count": 0,
        "detail_count_matched": True,
        "unique_code_count_matched": True,
        "review_ready_matched": True,
    }
    assert payload["source_metadata_summary"]["all_source_urls_have_source"] is True
    assert payload["source_metadata_summary"]["summary_consistency"]["method"] == (
        "source_metadata_summary_consistency"
    )
    assert payload["source_metadata_summary"]["summary_consistency"]["matched"] is True
    assert (
        payload["source_metadata_summary"]["summary_consistency"][
            "source_with_source_url_count"
        ]
        == 1
    )
    assert (
        payload["source_metadata_summary"]["summary_consistency"][
            "valid_source_url_count"
        ]
        == 1
    )
    assert (
        payload["source_metadata_summary"]["summary_consistency"][
            "source_url_missing_scheme_count"
        ]
        == 0
    )
    assert (
        payload["source_metadata_summary"]["summary_consistency"][
            "source_url_missing_domain_count"
        ]
        == 0
    )
    assert (
        payload["source_metadata_summary"]["summary_consistency"][
            "convention_count_matched"
        ]
        is True
    )
    assert (
        payload["source_metadata_summary"]["summary_consistency"][
            "convention_metadata_count_matched"
        ]
        is True
    )
    assert (
        payload["source_metadata_summary"]["summary_consistency"][
            "known_limitations_count_matched"
        ]
        is True
    )
    assert payload["source_metadata_summary"]["table_correctness_certified"] is False
    assert payload["source_metadata_summary"]["external_source_verified"] is False


def test_cli_validate_table_writes_review_ready_payload(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        table_path = tmp_path / "links.json"
        output_path = tmp_path / "validate-table-ready.json"
        table_path.write_text(
            json.dumps(
                [
                    {
                        "notation": "L0a1",
                        "link_type": "unlink",
                        "component_count": 1,
                        "minimal_crossing_number": 0,
                        "pairwise_linking": [],
                        "source": "Knot Atlas",
                        "source_url": "https://katlas.org/wiki/L0a1",
                        "convention": "iroll-test",
                        "convention_metadata": {
                            "notes": "reviewer-visible metadata without name"
                        },
                        "known_limitations": [
                            "fixture import boundary",
                            "reviewer-only source metadata",
                        ],
                    },
                    {
                        "notation": "L2a1",
                        "link_type": "hopf_link",
                        "component_count": 2,
                        "minimal_crossing_number": 2,
                        "pairwise_linking": [1],
                        "source": "KnotInfo",
                        "source_url": "https://knotinfo.math.indiana.edu/link/L2a1",
                        "convention_metadata": {"name": "iroll-test"},
                    },
                ]
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "validate-table",
                str(table_path),
                "--kind",
                "link",
                "--expected-convention",
                "iroll-test",
                "-o",
                str(output_path),
            ]
        )

        assert exit_code == 0
        assert capsys.readouterr().out == ""
        assert output_path.exists()
        payload = json.loads(output_path.read_text(encoding="utf-8"))
        analysis_exit = main(["imgui-analysis-summary-payload", str(output_path)])
        analysis = json.loads(capsys.readouterr().out)
        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(output_path)]
        )
        host = json.loads(capsys.readouterr().out)
        _assert_strict_json_serializable(payload, analysis, host)

    summary = payload["source_metadata_summary"]
    assert payload["valid"] is True
    assert payload["record_count"] == 2
    assert payload["issues"] == []
    assert summary["source_count"] == 2
    assert summary["source_url_count"] == 2
    assert summary["source_with_source_url_count"] == 2
    assert summary["valid_source_url_count"] == 2
    assert summary["missing_source_count"] == 0
    assert summary["missing_source_url_count"] == 0
    assert summary["source_url_without_source_count"] == 0
    assert summary["invalid_source_url_count"] == 0
    assert summary["provenance_review_ready"] is True
    assert summary["provenance_blocker_count"] == 0
    assert summary["provenance_blocker_codes"] == []
    assert summary["provenance_blocker_details"] == []
    assert summary["convention_metadata_count"] == 2
    assert summary["convention_metadata_name_count"] == 1
    assert summary["convention_metadata_without_name_count"] == 1
    assert summary["convention_metadata_without_name_rows"] == ["$[0]"]
    assert summary["known_limitations_count"] == 1
    assert summary["known_limitations_rows"] == ["$[0]"]
    assert summary["provenance_blocker_summary_consistency"]["matched"] is True
    assert summary["summary_consistency"]["matched"] is True
    assert summary["summary_consistency"]["convention_metadata_without_name_count"] == 1
    assert summary["summary_consistency"]["known_limitations_count"] == 1
    assert summary["summary_consistency"]["known_limitations_count_matched"] is True
    assert summary["source_value_counts"] == {
        "Knot Atlas": 1,
        "KnotInfo": 1,
    }
    assert summary["source_value_rows"] == {
        "Knot Atlas": ["$[0]"],
        "KnotInfo": ["$[1]"],
    }
    assert summary["source_url_scheme_counts"] == {"https": 2}
    assert summary["source_url_domain_counts"] == {
        "katlas.org": 1,
        "knotinfo.math.indiana.edu": 1,
    }
    assert summary["source_url_issue_code_counts"] == {}
    assert summary["source_url_issue_code_rows"] == {}
    assert summary["source_completeness_rows"] == [
        {
            "row": "$[0]",
            "has_source": True,
            "has_source_url": True,
            "source_record_has_source_url": True,
            "source_url_has_source": True,
            "source_with_source_url": True,
            "source_url_http_or_https": True,
            "source_url_missing_scheme": False,
            "source_url_missing_domain": False,
            "source_url_invalid": False,
        },
        {
            "row": "$[1]",
            "has_source": True,
            "has_source_url": True,
            "source_record_has_source_url": True,
            "source_url_has_source": True,
            "source_with_source_url": True,
            "source_url_http_or_https": True,
            "source_url_missing_scheme": False,
            "source_url_missing_domain": False,
            "source_url_invalid": False,
        },
    ]
    assert summary["summary_consistency"]["source_url_issue_code_total"] == 0
    assert (
        summary["summary_consistency"]["source_url_issue_code_count_total_matched"]
        is True
    )
    assert (
        summary["summary_consistency"][
            "source_url_issue_code_invalid_row_coverage_matched"
        ]
        is True
    )
    assert summary["summary_consistency"]["source_completeness_row_count"] == 2
    assert (
        summary["summary_consistency"]["source_completeness_row_count_matched"]
        is True
    )
    docs = (
        Path(__file__).resolve().parents[1] / "docs/validation-and-robustness.md"
    ).read_text(encoding="utf-8")
    assert "`source_completeness_rows=2`" in docs
    assert "`source_url_http_or_https=true`" in docs
    assert "for both" in docs
    assert "`source_completeness_row_count=2`" in docs
    assert "`source_completeness_row_count_matched=true`" in docs
    assert "`source_completeness_source_count_matched=true`" in docs
    assert "`source_completeness_source_url_count_matched=true`" in docs
    assert "`source_completeness_invalid_url_count_matched=true`" in docs
    assert summary["all_records_have_source"] is True
    assert summary["all_source_records_have_source_url"] is True
    assert summary["all_source_urls_have_source"] is True
    assert summary["all_source_urls_are_http_or_https"] is True
    assert summary["table_correctness_certified"] is False
    assert summary["external_source_verified"] is False
    assert analysis_exit == 0
    assert analysis["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert analysis["analysis_summary_count"] == 1
    assert analysis["analysis_validate_table_source_metadata_artifact_count"] == 1
    assert analysis["analysis_validate_table_source_metadata_valid_count"] == 1
    assert analysis["analysis_validate_table_source_metadata_record_count"] == 2
    assert (
        analysis["analysis_validate_table_source_metadata_source_value_label_count"]
        == 2
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_source_value_row_count_total"
        ]
        == 2
    )
    assert (
        analysis["analysis_validate_table_source_metadata_source_url_scheme_count"]
        == 1
    )
    assert (
        analysis["analysis_validate_table_source_metadata_source_url_domain_count"]
        == 2
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_provenance_review_ready_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_table_correctness_certified_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_convention_metadata_without_name_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_known_limitations_count"
        ]
        == 1
    )
    analysis_summary = analysis["analysis_summaries"][0]
    assert (
        analysis_summary["source_method"]
        == "validate_table_source_metadata_report"
    )
    assert analysis_summary["accepted"] is True
    assert (
        "validate_table_source_metadata_source_value_rows=Knot Atlas:$[0]|KnotInfo:$[1]"
        in analysis_summary["notes"]
    )
    assert (
        "validate_table_source_metadata_source_url_schemes=https:2"
        in analysis_summary["notes"]
    )
    assert (
        "validate_table_source_metadata_source_url_scheme_rows=https:$[0],$[1]"
        in analysis_summary["notes"]
    )
    assert (
        "validate_table_source_metadata_source_url_domains=katlas.org:1|knotinfo.math.indiana.edu:1"
        in analysis_summary["notes"]
    )
    assert (
        "validate_table_source_metadata_source_url_domain_rows=katlas.org:$[0]|knotinfo.math.indiana.edu:$[1]"
        in analysis_summary["notes"]
    )
    assert (
        "validate_table_source_metadata_source_completeness=rows=2; "
        "row_count_matched=true; source_count_matched=true; "
        "source_url_count_matched=true; invalid_url_count_matched=true"
        in analysis_summary["notes"]
    )
    assert (
        "validate_table_source_metadata_known_limitations_rows=$[0]"
        in analysis_summary["notes"]
    )
    assert (
        "validate_table_source_metadata_convention_metadata_without_name_rows=$[0]"
        in analysis_summary["notes"]
    )
    assert "not external table correctness" in analysis_summary["notes"]
    assert host_exit == 0
    assert host["method"] == "imgui_host_payload"
    host_analysis = host["analysis"]
    assert host_analysis["analysis_validate_table_source_metadata_artifact_count"] == 1
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_provenance_review_ready_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_source_value_label_count"
        ]
        == 2
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_source_url_domain_count"
        ]
        == 2
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_convention_metadata_without_name_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_known_limitations_count"
        ]
        == 1
    )
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    assert (
        host_summaries["validate_table_source_metadata_report"]["accepted"] is True
    )
    assert (
        "validate_table_source_metadata_source_url_domain_rows=katlas.org:$[0]|knotinfo.math.indiana.edu:$[1]"
        in host_summaries["validate_table_source_metadata_report"]["notes"]
    )
    assert (
        "validate_table_source_metadata_source_completeness=rows=2; "
        "row_count_matched=true; source_count_matched=true; "
        "source_url_count_matched=true; invalid_url_count_matched=true"
        in host_summaries["validate_table_source_metadata_report"]["notes"]
    )


def test_cli_validate_table_retains_convention_mismatch_blocked_pack(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        table_path = tmp_path / "links-convention-mismatch.json"
        output_path = tmp_path / "validate-table-source-metadata-blocked.json"
        table_path.write_text(
            json.dumps(
                [
                    {
                        "notation": "L2a1-blocked",
                        "link_type": "hopf_link",
                        "component_count": 2,
                        "minimal_crossing_number": 2,
                        "pairwise_linking": [1],
                        "source": "IROLL blocked test fixture",
                        "source_url": (
                            "https://example.test/iroll/link/L2a1-blocked"
                        ),
                        "convention": "source-table",
                    }
                ]
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "validate-table",
                str(table_path),
                "--kind",
                "link",
                "--expected-convention",
                "iroll-test",
                "-o",
                str(output_path),
            ]
        )
        assert exit_code == 0
        assert capsys.readouterr().out == ""

        analysis_exit = main(["imgui-analysis-summary-payload", str(output_path)])
        analysis = json.loads(capsys.readouterr().out)
        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(output_path)]
        )
        host = json.loads(capsys.readouterr().out)
        payload = json.loads(output_path.read_text(encoding="utf-8"))
        _assert_strict_json_serializable(payload, analysis, host)

    summary = payload["source_metadata_summary"]
    assert payload["valid"] is False
    assert payload["record_count"] == 1
    assert len(payload["issues"]) == 1
    assert payload["issues"][0]["path"] == "$[0].convention"
    assert "expected convention" in payload["issues"][0]["message"]
    assert summary["claim_scope"] == "table_source_metadata_scan"
    assert summary["expected_convention"] == "iroll-test"
    assert summary["source_count"] == 1
    assert summary["source_url_count"] == 1
    assert summary["valid_source_url_count"] == 1
    assert summary["provenance_review_ready"] is False
    assert summary["provenance_blocker_count"] == 1
    assert summary["provenance_blocker_codes"] == ["convention_mismatch"]
    assert summary["convention_mismatch_count"] == 1
    assert summary["all_conventions_match_expected"] is False
    assert summary["summary_consistency"]["matched"] is True
    assert (
        summary["summary_consistency"]["convention_mismatch_count_matched"]
        is True
    )
    assert summary["provenance_blocker_summary_consistency"]["matched"] is True
    assert (
        summary["provenance_blocker_summary_consistency"]["review_ready_matched"]
        is True
    )
    assert summary["table_correctness_certified"] is False
    assert summary["external_source_verified"] is False

    assert analysis_exit == 0
    assert analysis["analysis_validate_table_source_metadata_artifact_count"] == 1
    assert analysis["analysis_validate_table_source_metadata_valid_count"] == 0
    assert (
        analysis[
            "analysis_validate_table_source_metadata_provenance_review_ready_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_convention_mismatch_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_blocker_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_table_correctness_certified_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_external_source_verified_count"
        ]
        == 0
    )
    blocked_row = analysis["analysis_summaries"][0]
    assert blocked_row["source_method"] == "validate_table_source_metadata_report"
    assert blocked_row["accepted"] is False
    assert (
        blocked_row[
            "validate_table_source_metadata_all_conventions_match_expected"
        ]
        is False
    )
    assert "provenance_review_ready=false" in blocked_row["notes"]
    assert "convention_mismatches=1" in blocked_row["notes"]
    assert (
        "validate_table_source_metadata_provenance_blocker_codes=convention_mismatch"
        in blocked_row["notes"]
    )
    assert "validate_table_source_metadata_convention_mismatch_rows=$[0]" in (
        blocked_row["notes"]
    )

    assert host_exit == 0
    host_analysis = host["analysis"]
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_convention_mismatch_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_provenance_review_ready_count"
        ]
        == 0
    )
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    blocked_host_row = host_summaries["validate_table_source_metadata_report"]
    assert blocked_host_row["source_method"] == "validate_table_source_metadata_report"
    assert blocked_host_row["accepted"] is False
    assert (
        blocked_host_row[
            "validate_table_source_metadata_all_conventions_match_expected"
        ]
        is False
    )
    assert "validate_table_source_metadata_convention_mismatch_rows=$[0]" in (
        blocked_host_row["notes"]
    )


def test_cli_validate_table_retains_invalid_known_limitations_pack(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        table_path = tmp_path / "links-invalid-known-limitations.json"
        output_path = (
            tmp_path / "validate-table-source-metadata-invalid-known-limitations.json"
        )
        table_path.write_text(
            json.dumps(
                [
                    {
                        "notation": "L2a1-known-limitations",
                        "link_type": "hopf_link",
                        "component_count": 2,
                        "minimal_crossing_number": 2,
                        "pairwise_linking": [1],
                        "source": "IROLL known-limitations test fixture",
                        "source_url": (
                            "https://example.test/iroll/"
                            "L2a1-known-limitations"
                        ),
                        "convention": "iroll-test",
                        "known_limitations": [],
                    }
                ]
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "validate-table",
                str(table_path),
                "--kind",
                "link",
                "--expected-convention",
                "iroll-test",
                "-o",
                str(output_path),
            ]
        )
        assert exit_code == 0
        assert capsys.readouterr().out == ""

        analysis_exit = main(["imgui-analysis-summary-payload", str(output_path)])
        analysis = json.loads(capsys.readouterr().out)
        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(output_path)]
        )
        host = json.loads(capsys.readouterr().out)
        payload = json.loads(output_path.read_text(encoding="utf-8"))
        _assert_strict_json_serializable(payload, analysis, host)

    summary = payload["source_metadata_summary"]
    assert payload["valid"] is False
    assert payload["record_count"] == 1
    assert len(payload["issues"]) == 1
    assert payload["issues"][0]["path"] == "$[0].known_limitations"
    assert "expected non-empty string" in payload["issues"][0]["message"]
    assert summary["claim_scope"] == "table_source_metadata_scan"
    assert summary["expected_convention"] == "iroll-test"
    assert summary["provenance_review_ready"] is True
    assert summary["provenance_blocker_count"] == 0
    assert summary["provenance_blocker_codes"] == []
    assert summary["known_limitations_count"] == 0
    assert summary["summary_consistency"]["matched"] is True
    assert summary["summary_consistency"]["known_limitations_count_matched"] is True
    assert summary["provenance_blocker_summary_consistency"]["matched"] is True
    assert summary["table_correctness_certified"] is False
    assert summary["external_source_verified"] is False

    assert analysis_exit == 0
    assert analysis["analysis_validate_table_source_metadata_artifact_count"] == 1
    assert analysis["analysis_validate_table_source_metadata_valid_count"] == 0
    assert analysis["analysis_validate_table_source_metadata_issue_count"] == 1
    assert (
        analysis[
            "analysis_validate_table_source_metadata_provenance_review_ready_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_provenance_blocker_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_known_limitations_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_table_correctness_certified_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_external_source_verified_count"
        ]
        == 0
    )
    invalid_row = analysis["analysis_summaries"][0]
    assert invalid_row["source_method"] == "validate_table_source_metadata_report"
    assert invalid_row["accepted"] is False
    assert "provenance_review_ready=true" in invalid_row["notes"]
    assert "blockers=0" in invalid_row["notes"]
    assert (
        "validate_table_source_metadata_issue_paths=$[0].known_limitations"
        in invalid_row["notes"]
    )
    assert "validate_table_source_metadata_issue_messages=" in invalid_row["notes"]
    assert "expected non-empty string" in invalid_row["notes"]

    assert host_exit == 0
    host_analysis = host["analysis"]
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_provenance_review_ready_count"
        ]
        == 1
    )
    assert host_analysis["analysis_validate_table_source_metadata_valid_count"] == 0
    assert host_analysis["analysis_validate_table_source_metadata_issue_count"] == 1
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_known_limitations_count"
        ]
        == 0
    )
    host_summary = next(
        summary
        for summary in host_analysis["analysis_summaries"]
        if summary["source_method"] == "validate_table_source_metadata_report"
    )
    assert (
        "validate_table_source_metadata_issue_paths=$[0].known_limitations"
        in host_summary["notes"]
    )
    assert "expected non-empty string" in host_summary["notes"]


def test_cli_validate_table_retains_invalid_known_limitations_item_path(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        table_path = tmp_path / "links-invalid-known-limitations-item.json"
        output_path = (
            tmp_path
            / "validate-table-source-metadata-invalid-known-limitations-item.json"
        )
        table_path.write_text(
            json.dumps(
                [
                    {
                        "notation": "L2a1-known-limitations-item",
                        "link_type": "hopf_link",
                        "component_count": 2,
                        "minimal_crossing_number": 2,
                        "pairwise_linking": [1],
                        "source": "IROLL known-limitations item fixture",
                        "source_url": (
                            "https://example.test/iroll/"
                            "L2a1-known-limitations-item"
                        ),
                        "convention": "iroll-test",
                        "known_limitations": ["fixture only", 5],
                    }
                ]
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "validate-table",
                str(table_path),
                "--kind",
                "link",
                "--expected-convention",
                "iroll-test",
                "-o",
                str(output_path),
            ]
        )
        assert exit_code == 0
        assert capsys.readouterr().out == ""

        analysis_exit = main(["imgui-analysis-summary-payload", str(output_path)])
        analysis = json.loads(capsys.readouterr().out)
        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(output_path)]
        )
        host = json.loads(capsys.readouterr().out)
        payload = json.loads(output_path.read_text(encoding="utf-8"))
        _assert_strict_json_serializable(payload, analysis, host)

    summary = payload["source_metadata_summary"]
    assert payload["valid"] is False
    assert payload["issues"] == [
        {
            "path": "$[0].known_limitations[1]",
            "message": "expected non-empty string",
        }
    ]
    assert summary["provenance_review_ready"] is True
    assert summary["provenance_blocker_count"] == 0
    assert summary["known_limitations_count"] == 1
    assert summary["known_limitations_rows"] == ["$[0]"]
    assert summary["summary_consistency"]["known_limitations_count_matched"] is True
    assert summary["provenance_blocker_summary_consistency"]["matched"] is True
    assert summary["table_correctness_certified"] is False
    assert summary["external_source_verified"] is False

    assert analysis_exit == 0
    assert analysis["analysis_validate_table_source_metadata_valid_count"] == 0
    assert analysis["analysis_validate_table_source_metadata_issue_count"] == 1
    assert (
        analysis[
            "analysis_validate_table_source_metadata_provenance_review_ready_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_provenance_blocker_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_known_limitations_count"
        ]
        == 1
    )
    invalid_row = analysis["analysis_summaries"][0]
    assert invalid_row["accepted"] is False
    assert (
        "validate_table_source_metadata_issue_paths=$[0].known_limitations[1]"
        in invalid_row["notes"]
    )
    assert (
        "validate_table_source_metadata_known_limitations_rows=$[0]"
        in invalid_row["notes"]
    )
    assert "expected non-empty string" in invalid_row["notes"]

    assert host_exit == 0
    host_analysis = host["analysis"]
    assert host_analysis["analysis_validate_table_source_metadata_valid_count"] == 0
    assert host_analysis["analysis_validate_table_source_metadata_issue_count"] == 1
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_known_limitations_count"
        ]
        == 1
    )
    host_summary = next(
        summary
        for summary in host_analysis["analysis_summaries"]
        if summary["source_method"] == "validate_table_source_metadata_report"
    )
    assert (
        "validate_table_source_metadata_issue_paths=$[0].known_limitations[1]"
        in host_summary["notes"]
    )
    assert (
        "validate_table_source_metadata_known_limitations_rows=$[0]"
        in host_summary["notes"]
    )


def test_cli_validate_table_source_metadata_multi_report_aggregation(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        ready_table_path = tmp_path / "links-ready.json"
        invalid_table_path = tmp_path / "links-invalid-known-limitations.json"
        ready_output_path = tmp_path / "validate-table-source-metadata-ready.json"
        invalid_output_path = (
            tmp_path / "validate-table-source-metadata-invalid-known-limitations.json"
        )
        ready_table_path.write_text(
            json.dumps(
                [
                    {
                        "notation": "L2a1-ready",
                        "link_type": "hopf_link",
                        "component_count": 2,
                        "minimal_crossing_number": 2,
                        "pairwise_linking": [1],
                        "source": "IROLL multi-report ready fixture",
                        "source_url": "https://example.test/iroll/link/L2a1",
                        "convention": "iroll-test",
                    }
                ]
            ),
            encoding="utf-8",
        )
        invalid_table_path.write_text(
            json.dumps(
                [
                    {
                        "notation": "L2a1-invalid-known-limitations",
                        "link_type": "hopf_link",
                        "component_count": 2,
                        "minimal_crossing_number": 2,
                        "pairwise_linking": [1],
                        "source": "IROLL multi-report invalid fixture",
                        "source_url": "https://example.test/iroll/link/L2a1",
                        "convention": "iroll-test",
                        "known_limitations": [],
                    }
                ]
            ),
            encoding="utf-8",
        )

        ready_exit = main(
            [
                "validate-table",
                str(ready_table_path),
                "--kind",
                "link",
                "--expected-convention",
                "iroll-test",
                "-o",
                str(ready_output_path),
            ]
        )
        assert ready_exit == 0
        assert capsys.readouterr().out == ""
        invalid_exit = main(
            [
                "validate-table",
                str(invalid_table_path),
                "--kind",
                "link",
                "--expected-convention",
                "iroll-test",
                "-o",
                str(invalid_output_path),
            ]
        )
        assert invalid_exit == 0
        assert capsys.readouterr().out == ""

        analysis_exit = main(
            [
                "imgui-analysis-summary-payload",
                str(ready_output_path),
                str(invalid_output_path),
            ]
        )
        analysis = json.loads(capsys.readouterr().out)
        host_exit = main(
            [
                "imgui-host-payload",
                "--analysis-report-json",
                str(ready_output_path),
                "--analysis-report-json",
                str(invalid_output_path),
            ]
        )
        host = json.loads(capsys.readouterr().out)
        _assert_strict_json_serializable(analysis, host)

    assert analysis_exit == 0
    assert host_exit == 0
    assert analysis["analysis_summary_count"] == 2
    assert analysis["analysis_validate_table_source_metadata_artifact_count"] == 2
    assert analysis["analysis_validate_table_source_metadata_valid_count"] == 1
    assert analysis["analysis_validate_table_source_metadata_issue_count"] == 1
    assert (
        analysis[
            "analysis_validate_table_source_metadata_provenance_review_ready_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_provenance_blocker_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_table_correctness_certified_count"
        ]
        == 0
    )
    summaries_by_validity = {
        summary["validate_table_source_metadata_valid_count"]: summary
        for summary in analysis["analysis_summaries"]
    }
    assert summaries_by_validity[1]["accepted"] is True
    invalid_summary = summaries_by_validity[0]
    assert invalid_summary["accepted"] is False
    assert (
        "validate_table_source_metadata_issue_paths=$[0].known_limitations"
        in invalid_summary["notes"]
    )

    host_analysis = host["analysis"]
    assert host_analysis["analysis_validate_table_source_metadata_artifact_count"] == 2
    assert host_analysis["analysis_validate_table_source_metadata_valid_count"] == 1
    assert host_analysis["analysis_validate_table_source_metadata_issue_count"] == 1
    host_validate_table_summaries = [
        summary
        for summary in host_analysis["analysis_summaries"]
        if summary["source_method"] == "validate_table_source_metadata_report"
    ]
    assert len(host_validate_table_summaries) == 2
    host_invalid_summary = {
        summary["validate_table_source_metadata_valid_count"]: summary
        for summary in host_validate_table_summaries
    }[0]
    assert (
        "validate_table_source_metadata_issue_paths=$[0].known_limitations"
        in host_invalid_summary["notes"]
    )

    docs = (
        Path(__file__).resolve().parents[1] / "docs/validation-and-robustness.md"
    ).read_text(encoding="utf-8")
    assert "multi-report aggregation" in docs
    assert "`analysis_summary_count=2`" in docs
    assert "`analysis_validate_table_source_metadata_artifact_count=2`" in docs
    assert "`analysis_validate_table_source_metadata_valid_count=1`" in docs
    assert "`analysis_validate_table_source_metadata_issue_count=1`" in docs
    assert (
        "`analysis_validate_table_source_metadata_provenance_review_ready_count=2`"
        in docs
    )
    assert (
        "`analysis_validate_table_source_metadata_provenance_blocker_count=0`"
        in docs
    )
    assert (
        "`validate_table_source_metadata_issue_paths=$[0].known_limitations`"
        in docs
    )
    assert "metadata-shape evidence only" in docs
    assert "not provenance blockers" in docs


def test_cli_validate_table_retains_invalid_source_url_pack(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        table_path = tmp_path / "links-invalid-source-url.json"
        output_path = tmp_path / "validate-table-source-metadata-invalid-source-url.json"
        table_path.write_text(
            json.dumps(
                [
                    {
                        "notation": "L2a1-invalid-source-url",
                        "link_type": "hopf_link",
                        "component_count": 2,
                        "minimal_crossing_number": 2,
                        "pairwise_linking": [1],
                        "source": "IROLL invalid-source-url test fixture",
                        "source_url": "ftp://example.test/iroll/link/L2a1",
                        "convention": "iroll-test",
                    }
                ]
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "validate-table",
                str(table_path),
                "--kind",
                "link",
                "--expected-convention",
                "iroll-test",
                "-o",
                str(output_path),
            ]
        )
        assert exit_code == 0
        assert capsys.readouterr().out == ""

        analysis_exit = main(["imgui-analysis-summary-payload", str(output_path)])
        analysis = json.loads(capsys.readouterr().out)
        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(output_path)]
        )
        host = json.loads(capsys.readouterr().out)
        payload = json.loads(output_path.read_text(encoding="utf-8"))
        _assert_strict_json_serializable(payload, analysis, host)

    summary = payload["source_metadata_summary"]
    assert payload["valid"] is True
    assert payload["record_count"] == 1
    assert payload["issues"] == []
    assert summary["claim_scope"] == "table_source_metadata_scan"
    assert summary["expected_convention"] == "iroll-test"
    assert summary["provenance_review_ready"] is False
    assert summary["provenance_blocker_count"] == 1
    assert summary["provenance_blocker_codes"] == ["invalid_source_url"]
    assert summary["source_url_count"] == 1
    assert summary["valid_source_url_count"] == 0
    assert summary["invalid_source_url_count"] == 1
    assert summary["all_records_have_source"] is True
    assert summary["all_source_records_have_source_url"] is True
    assert summary["all_source_urls_have_source"] is True
    assert summary["all_source_urls_are_http_or_https"] is False
    assert summary["source_url_issue_code_counts"] == {"unsupported_scheme": 1}
    assert summary["source_url_issue_code_rows"] == {"unsupported_scheme": ["$[0]"]}
    assert summary["source_completeness_rows"] == [
        {
            "row": "$[0]",
            "has_source": True,
            "has_source_url": True,
            "source_record_has_source_url": True,
            "source_url_has_source": True,
            "source_with_source_url": True,
            "source_url_http_or_https": False,
            "source_url_missing_scheme": False,
            "source_url_missing_domain": False,
            "source_url_invalid": True,
        }
    ]
    assert summary["summary_consistency"]["matched"] is True
    assert (
        summary["summary_consistency"][
            "source_url_issue_code_count_total_matched"
        ]
        is True
    )
    assert (
        summary["summary_consistency"][
            "source_url_issue_code_invalid_row_coverage_matched"
        ]
        is True
    )
    assert summary["provenance_blocker_summary_consistency"]["matched"] is True
    assert summary["table_correctness_certified"] is False
    assert summary["external_source_verified"] is False

    assert analysis_exit == 0
    assert analysis["analysis_validate_table_source_metadata_artifact_count"] == 1
    assert analysis["analysis_validate_table_source_metadata_valid_count"] == 1
    assert analysis["analysis_validate_table_source_metadata_issue_count"] == 0
    assert (
        analysis[
            "analysis_validate_table_source_metadata_provenance_review_ready_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_provenance_blocker_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_invalid_source_url_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_valid_source_url_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_all_records_have_source_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_all_source_records_have_source_url_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_all_source_urls_have_source_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_all_source_urls_are_http_or_https_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_table_correctness_certified_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_external_source_verified_count"
        ]
        == 0
    )
    invalid_url_row = analysis["analysis_summaries"][0]
    assert invalid_url_row["source_method"] == "validate_table_source_metadata_report"
    assert invalid_url_row["accepted"] is False
    assert "valid=true" in invalid_url_row["notes"]
    assert "provenance_review_ready=false" in invalid_url_row["notes"]
    assert "invalid_source_urls=1" in invalid_url_row["notes"]
    assert (
        "validate_table_source_metadata_source_url_issue_codes=unsupported_scheme:1"
        in invalid_url_row["notes"]
    )
    assert (
        "validate_table_source_metadata_source_url_issue_code_rows=unsupported_scheme:$[0]"
        in invalid_url_row["notes"]
    )
    assert (
        "validate_table_source_metadata_provenance_blocker_codes=invalid_source_url"
        in invalid_url_row["notes"]
    )

    assert host_exit == 0
    host_analysis = host["analysis"]
    assert host_analysis["analysis_validate_table_source_metadata_valid_count"] == 1
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_invalid_source_url_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_valid_source_url_count"
        ]
        == 0
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_all_records_have_source_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_all_source_records_have_source_url_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_all_source_urls_have_source_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_all_source_urls_are_http_or_https_count"
        ]
        == 0
    )
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    host_row = host_summaries["validate_table_source_metadata_report"]
    assert host_row["source_method"] == "validate_table_source_metadata_report"
    assert host_row["accepted"] is False
    assert (
        "validate_table_source_metadata_source_url_issue_code_rows=unsupported_scheme:$[0]"
        in host_row["notes"]
    )
    assert (
        "validate_table_source_metadata_source_url_issue_codes=unsupported_scheme:1"
        in host_row["notes"]
    )
    assert (
        "validate_table_source_metadata_provenance_blocker_codes=invalid_source_url"
        in host_row["notes"]
    )


def test_cli_validate_table_retains_provenance_blocker_vocabulary(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        table_path = tmp_path / "links.json"
        output_path = tmp_path / "validate-table-provenance-blockers.json"
        table_path.write_text(
            json.dumps(
                [
                    {
                        "notation": "L-vocab-missing-source",
                        "link_type": "link",
                        "component_count": 2,
                        "minimal_crossing_number": 2,
                        "pairwise_linking": [1],
                        "source_url": (
                            "https://example.test/iroll/"
                            "source-url-without-source"
                        ),
                        "convention": "iroll-test",
                    },
                    {
                        "notation": "L-vocab-missing-source-url",
                        "link_type": "link",
                        "component_count": 2,
                        "minimal_crossing_number": 4,
                        "pairwise_linking": [0],
                        "source": "synthetic provenance vocabulary fixture",
                        "convention": "iroll-test",
                    },
                    {
                        "notation": "L-vocab-invalid-source-url",
                        "link_type": "link",
                        "component_count": 2,
                        "minimal_crossing_number": 6,
                        "pairwise_linking": [0],
                        "source": "synthetic provenance vocabulary fixture",
                        "source_url": "ftp://example.test/iroll/unsupported-scheme",
                        "convention": "iroll-test",
                    },
                    {
                        "notation": "L-vocab-missing-convention",
                        "link_type": "link",
                        "component_count": 2,
                        "minimal_crossing_number": 8,
                        "pairwise_linking": [0],
                        "source": "synthetic provenance vocabulary fixture",
                        "source_url": (
                            "https://example.test/iroll/missing-convention"
                        ),
                    },
                ]
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "validate-table",
                str(table_path),
                "--kind",
                "link",
                "--expected-convention",
                "iroll-test",
                "-o",
                str(output_path),
            ]
        )

        assert exit_code == 0
        assert capsys.readouterr().out == ""
        payload = json.loads(output_path.read_text(encoding="utf-8"))
        analysis_exit = main(["imgui-analysis-summary-payload", str(output_path)])
        analysis = json.loads(capsys.readouterr().out)
        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(output_path)]
        )
        host = json.loads(capsys.readouterr().out)
        _assert_strict_json_serializable(payload, analysis, host)

    summary = payload["source_metadata_summary"]
    assert payload["valid"] is False
    assert payload["record_count"] == 4
    assert len(payload["issues"]) == 1
    assert payload["issues"][0]["path"] == "$[3].convention"
    assert summary["source_count"] == 3
    assert summary["source_url_count"] == 3
    assert summary["source_with_source_url_count"] == 2
    assert summary["valid_source_url_count"] == 2
    assert summary["invalid_source_url_count"] == 1
    assert summary["missing_source_count"] == 1
    assert summary["missing_source_url_count"] == 1
    assert summary["source_url_without_source_count"] == 1
    assert summary["convention_mismatch_count"] == 0
    assert summary["all_conventions_match_expected"] is True
    assert summary["provenance_review_ready"] is False
    assert summary["provenance_blocker_count"] == 5
    assert summary["provenance_blocker_codes"] == [
        "missing_source",
        "missing_source_url",
        "source_url_without_source",
        "invalid_source_url",
        "missing_convention",
    ]
    assert summary["source_url_issue_code_counts"] == {"unsupported_scheme": 1}
    assert summary["summary_consistency"]["matched"] is True
    assert (
        summary["summary_consistency"][
            "source_url_issue_code_invalid_row_coverage_matched"
        ]
        is True
    )
    assert summary["provenance_blocker_summary_consistency"]["matched"] is True
    assert summary["table_correctness_certified"] is False
    assert summary["external_source_verified"] is False

    assert analysis_exit == 0
    assert analysis["analysis_validate_table_source_metadata_valid_count"] == 0
    assert analysis["analysis_validate_table_source_metadata_issue_count"] == 1
    assert analysis["analysis_validate_table_source_metadata_record_count"] == 4
    assert (
        analysis[
            "analysis_validate_table_source_metadata_provenance_review_ready_count"
        ]
        == 0
    )
    assert (
        analysis["analysis_validate_table_source_metadata_provenance_blocker_count"]
        == 5
    )
    assert analysis["analysis_validate_table_source_metadata_source_count"] == 3
    assert analysis["analysis_validate_table_source_metadata_source_url_count"] == 3
    assert (
        analysis[
            "analysis_validate_table_source_metadata_source_url_without_source_count"
        ]
        == 1
    )
    assert (
        analysis["analysis_validate_table_source_metadata_invalid_source_url_count"]
        == 1
    )
    assert analysis["analysis_validate_table_source_metadata_missing_source_count"] == 1
    assert (
        analysis[
            "analysis_validate_table_source_metadata_missing_source_url_count"
        ]
        == 1
    )
    analysis_summary = analysis["analysis_summaries"][0]
    assert (
        analysis_summary["source_method"]
        == "validate_table_source_metadata_report"
    )
    assert analysis_summary["accepted"] is False
    assert "blockers=5" in analysis_summary["notes"]
    assert (
        "validate_table_source_metadata_source_url_issue_codes=unsupported_scheme:1"
        in analysis_summary["notes"]
    )
    assert (
        "validate_table_source_metadata_source_url_issue_code_rows=unsupported_scheme:$[2]"
        in analysis_summary["notes"]
    )
    assert (
        "validate_table_source_metadata_provenance_blocker_codes=missing_source,missing_source_url,source_url_without_source,invalid_source_url,missing_convention"
        in analysis_summary["notes"]
    )
    assert "validate_table_source_metadata_missing_source_rows=$[0]" in (
        analysis_summary["notes"]
    )
    assert "validate_table_source_metadata_missing_source_url_rows=$[1]" in (
        analysis_summary["notes"]
    )
    assert (
        "validate_table_source_metadata_source_url_without_source_rows=$[0]"
        in analysis_summary["notes"]
    )
    assert (
        analysis_summary[
            "validate_table_source_metadata_source_url_without_source_count"
        ]
        == 1
    )

    assert host_exit == 0
    host_analysis = host["analysis"]
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_provenance_blocker_count"
        ]
        == 5
    )
    assert host_analysis["analysis_validate_table_source_metadata_record_count"] == 4
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    host_summary = host_summaries["validate_table_source_metadata_report"]
    assert host_summary["source_method"] == "validate_table_source_metadata_report"
    assert host_summary["accepted"] is False
    assert "validate_table_source_metadata_missing_source_rows=$[0]" in (
        host_summary["notes"]
    )


def test_cli_validate_table_retains_missing_source_url_subcodes(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        table_path = tmp_path / "links.json"
        output_path = tmp_path / "validate-table-missing-url-subcodes.json"
        table_path.write_text(
            json.dumps(
                [
                    {
                        "notation": "L-url-subcodes",
                        "link_type": "link",
                        "component_count": 2,
                        "minimal_crossing_number": 2,
                        "pairwise_linking": [1],
                        "source": "synthetic URL diagnostic fixture",
                        "source_url": "example.test/iroll/missing-scheme",
                        "convention": "iroll-test",
                    }
                ]
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "validate-table",
                str(table_path),
                "--kind",
                "link",
                "--expected-convention",
                "iroll-test",
                "-o",
                str(output_path),
            ]
        )

        assert exit_code == 0
        assert capsys.readouterr().out == ""
        payload = json.loads(output_path.read_text(encoding="utf-8"))
        analysis_exit = main(["imgui-analysis-summary-payload", str(output_path)])
        analysis = json.loads(capsys.readouterr().out)
        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(output_path)]
        )
        host = json.loads(capsys.readouterr().out)
        _assert_strict_json_serializable(payload, analysis, host)

    summary = payload["source_metadata_summary"]
    assert payload["valid"] is True
    assert payload["issues"] == []
    assert summary["provenance_review_ready"] is False
    assert summary["provenance_blocker_count"] == 1
    assert summary["provenance_blocker_codes"] == ["invalid_source_url"]
    assert summary["invalid_source_url_count"] == 1
    assert summary["source_url_missing_scheme_count"] == 1
    assert summary["source_url_missing_domain_count"] == 1
    assert summary["source_url_issue_code_counts"] == {
        "missing_scheme": 1,
        "missing_domain": 1,
    }
    assert summary["source_url_issue_code_rows"] == {
        "missing_scheme": ["$[0]"],
        "missing_domain": ["$[0]"],
    }
    assert summary["summary_consistency"]["source_url_issue_code_total"] == 2
    assert (
        summary["summary_consistency"]["source_url_issue_code_count_total_matched"]
        is True
    )
    assert (
        summary["summary_consistency"][
            "source_url_issue_code_invalid_row_coverage_matched"
        ]
        is True
    )

    assert analysis_exit == 0
    assert analysis["analysis_validate_table_source_metadata_valid_count"] == 1
    assert (
        analysis[
            "analysis_validate_table_source_metadata_provenance_review_ready_count"
        ]
        == 0
    )
    assert (
        analysis["analysis_validate_table_source_metadata_provenance_blocker_count"]
        == 1
    )
    assert (
        analysis["analysis_validate_table_source_metadata_invalid_source_url_count"]
        == 1
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_source_url_missing_scheme_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_source_url_missing_domain_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_validate_table_source_metadata_source_url_issue_code_total"
        ]
        == 2
    )
    analysis_summary = analysis["analysis_summaries"][0]
    assert (
        "validate_table_source_metadata_source_url_issue_codes=missing_domain:1|missing_scheme:1"
        in analysis_summary["notes"]
    )
    assert (
        "validate_table_source_metadata_source_url_issue_code_rows=missing_domain:$[0]|missing_scheme:$[0]"
        in analysis_summary["notes"]
    )

    assert host_exit == 0
    host_analysis = host["analysis"]
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_source_url_missing_scheme_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_source_url_missing_domain_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_validate_table_source_metadata_source_url_issue_code_total"
        ]
        == 2
    )
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    host_summary = host_summaries["validate_table_source_metadata_report"]
    assert (
        "validate_table_source_metadata_source_url_issue_code_rows=missing_domain:$[0]|missing_scheme:$[0]"
        in host_summary["notes"]
    )


def test_cli_fixture_acceptance_commands_print_full_reports(capsys) -> None:
    homfly_exit = main(
        [
            "homfly-fixture-acceptance",
            "--notation",
            "L2a1",
        ]
    )
    homfly = json.loads(capsys.readouterr().out)

    assert homfly_exit == 0
    assert homfly["method"] == "homfly_fixture_acceptance_report"
    assert homfly["fixture_count"] == 1
    assert homfly["accepted"] is True
    assert homfly["input_certification_applicable_count"] == 1
    assert homfly["certified_input_count"] == 1
    assert homfly["full_table_normalization_certified"] is False
    assert homfly["arbitrary_diagram_coverage_certified"] is False
    assert homfly["fixtures"][0]["input_certification_evidence"]["frontier_count"] == 0

    alexander_exit = main(
        [
            "multivariable-alexander-fixture-acceptance",
            "--notation",
            "3_1",
        ]
    )
    alexander = json.loads(capsys.readouterr().out)

    assert alexander_exit == 0
    assert alexander["method"] == "multivariable_alexander_fixture_acceptance_report"
    assert alexander["fixture_count"] == 1
    assert alexander["accepted"] is True
    assert alexander["bounded_scanned_gcd_certified_count"] == 1
    assert alexander["registered_knot_admissible_normalization_certified_count"] == 1
    assert alexander["wirtinger_fox_audit_matched_count"] == 1
    assert alexander["full_admissible_minor_normalization_certified"] is False
    assert alexander["full_invariant_certified"] is False
    evidence = alexander["fixtures"][0]["bounded_scanned_gcd_evidence"]
    assert evidence["bounded_scanned_gcd_certified"] is True
    assert evidence["failed_nonzero_minor_count"] == 0


def test_cli_fixture_validation_pack_audit_exports_metadata_readiness(capsys) -> None:
    exit_code = main(["fixture-validation-pack-audit"])
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["ci_fail_on_not_ready"] is False
    assert payload["ci_exit_code"] == 0
    assert payload["method"] == "cross_workstream_validation_pack_audit"
    assert payload["claim_scope"] == "final_completion_checklist_metadata_audit"
    assert payload["required_diagram_fixture_count"] == 7
    assert payload["registered_required_diagram_fixture_count"] == 7
    assert payload["required_diagram_fixture_metadata_complete"] is True
    assert payload["metadata_blocker_count"] == 0
    assert payload["signed_diagram_fixture_registration_complete"] is False
    assert payload["unsigned_required_fixture_count"] == 2
    assert [row["notation"] for row in payload["signed_fixture_blockers"]] == [
        "L5a1",
        "L6a4",
    ]
    assert {
        row["code"] for row in payload["signed_fixture_blockers"]
    } == {"signed_pd_not_registered"}
    signed_blockers = {
        row["notation"]: row for row in payload["signed_fixture_blockers"]
    }
    assert signed_blockers["L5a1"]["registration_status"] == (
        "source_table_unsigned_fixture_pending_sign_registration"
    )
    assert signed_blockers["L5a1"]["source_url"] == "https://katlas.org/wiki/L5a1"
    assert signed_blockers["L5a1"]["has_signed_pd"] is False
    assert signed_blockers["L5a1"]["has_gauss_code"] is True
    assert signed_blockers["L5a1"]["source_table_homfly_available"] is True
    assert "verified signed crossing assignment" in signed_blockers["L5a1"][
        "required_evidence"
    ]
    assert "fixture remains unsigned and unregistered" in signed_blockers["L5a1"][
        "current_evidence"
    ]
    assert signed_blockers["L6a4"][
        "source_table_multivariable_alexander_available"
    ] is True
    assert signed_blockers["L6a4"]["missing_artifact"] == (
        "verified_signed_crossing_assignment"
    )
    assert payload["non_diagram_requirement_count"] == 6
    assert payload["open_non_diagram_requirement_count"] == 1
    assert payload["final_completion_gate_count"] == 7
    assert payload["final_completion_passed_gate_count"] == 1
    assert payload["final_completion_failed_gate_count"] == 6
    assert payload["final_completion_failed_gates"] == [
        "signed_diagram_fixture_registration",
        "non_diagram_requirements",
        "full_homfly_pt_evaluation",
        "full_multivariable_alexander_normalization",
        "production_imgui_renderer",
        "release_artifacts",
    ]
    assert payload["final_completion_failed_gate_signature"] == (
        "signed_diagram_fixture_registration|non_diagram_requirements|"
        "full_homfly_pt_evaluation|"
        "full_multivariable_alexander_normalization|"
        "production_imgui_renderer|release_artifacts"
    )
    assert payload["final_completion_blocker_count"] == 7
    assert payload["final_completion_blocker_code_count"] == 6
    assert payload["final_completion_blocker_code_counts"][
        "signed_pd_not_registered"
    ] == 2
    assert payload["final_completion_blocker_code_counts"][
        "release_artifacts_not_published"
    ] == 1
    expected_missing_artifacts = [
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "verified_signed_crossing_assignment",
    ]
    assert payload["final_completion_missing_artifact_count"] == 5
    assert payload["final_completion_missing_artifacts"] == expected_missing_artifacts
    assert payload["final_completion_missing_artifact_signature"] == "|".join(
        expected_missing_artifacts
    )
    final_blockers = payload["final_completion_blockers"]
    signed_final_blocker = next(
        row
        for row in final_blockers
        if row["kind"] == "signed_fixture" and row["notation"] == "L5a1"
    )
    assert signed_final_blocker["completion_evidence_artifact_filenames"] == [
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    release_final_blocker = next(
        row
        for row in final_blockers
        if row["code"] == "release_artifacts_not_published"
    )
    assert release_final_blocker["completion_evidence_artifact_filenames"] == [
        "signed_release_publication_manifest.json"
    ]
    gate_checks = {row["gate"]: row for row in payload["final_completion_gate_checks"]}
    assert gate_checks["signed_diagram_fixture_registration"][
        "completion_evidence_artifact_filenames"
    ] == [
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert gate_checks["release_artifacts"][
        "completion_evidence_artifact_filenames"
    ] == ["signed_release_publication_manifest.json"]
    missing_bundle_evidence = payload["completion_evidence_bundle"]
    assert missing_bundle_evidence["available"] is False
    assert missing_bundle_evidence["missing_bundle_keys"] == [
        "verified_signed_crossing_assignments",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
    ]
    assert missing_bundle_evidence["artifact_preflight_row_count"] == 0
    assert missing_bundle_evidence["expected_artifact_preflight_row_count"] == 6
    assert missing_bundle_evidence["bundle_contract_coverage_complete"] is False
    assert missing_bundle_evidence["bundle_contract_coverage"][
        "missing_artifact_types"
    ] == [
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "verified_signed_crossing_assignment",
    ]
    code_consistency = payload["final_completion_blocker_code_consistency"]
    assert code_consistency["claim_scope"] == (
        "validation_pack_final_completion_blocker_code_consistency"
    )
    assert code_consistency["blocker_count"] == 7
    assert code_consistency["code_count"] == 6
    assert code_consistency["top_level_code_count"] == 6
    assert code_consistency["code_count_total"] == 7
    assert code_consistency["code_count_total_matches_blocker_count"] is True
    assert code_consistency["unique_code_count_matches_top_level"] is True
    assert code_consistency["codes_match_top_level"] is True
    assert code_consistency["signature_matches_counts"] is True
    assert code_consistency["all_blockers_have_code"] is True
    assert code_consistency["matched"] is True
    assert code_consistency["code_counts"] == payload[
        "final_completion_blocker_code_counts"
    ]
    assert code_consistency["code_counts"]["signed_pd_not_registered"] == 2
    assert code_consistency["signature"] == payload[
        "final_completion_blocker_signature"
    ]
    code_summary = {
        row["blocker_code"]: row
        for row in payload["final_completion_blocker_code_summary"]
    }
    assert code_summary["signed_pd_not_registered"]["blocker_count"] == 2
    assert code_summary["signed_pd_not_registered"]["blocker_kinds"] == [
        "signed_fixture"
    ]
    assert code_summary["signed_pd_not_registered"]["missing_artifacts"] == [
        "verified_signed_crossing_assignment"
    ]
    code_detail = payload[
        "final_completion_blocker_code_summary_detail_consistency"
    ]
    assert code_detail["claim_scope"] == (
        "validation_pack_final_completion_blocker_code_summary_detail_consistency"
    )
    assert code_detail["summary_row_count"] == 6
    assert code_detail["code_count"] == 6
    assert code_detail["checked_blocker_code_count"] == 6
    assert code_detail["blocker_count"] == 7
    assert code_detail["blocker_kind_reference_count"] == 6
    assert code_detail["blocker_label_reference_count"] == 7
    assert code_detail["missing_artifact_reference_count"] == 6
    assert code_detail["unique_missing_artifact_count"] == 5
    assert code_detail["summary_blocker_count_total"] == 7
    assert code_detail["blocker_count_matched_count"] == 6
    assert code_detail["blocker_kinds_matched_count"] == 6
    assert code_detail["blocker_labels_matched_count"] == 6
    assert code_detail["missing_artifacts_matched_count"] == 6
    assert code_detail["mismatched_summary_row_count"] == 0
    assert code_detail["matched"] is True
    kind_summary = {
        row["blocker_kind"]: row
        for row in payload["final_completion_blocker_kind_summary"]
    }
    assert set(kind_summary) == {
        "completion_gate",
        "non_diagram_requirement",
        "signed_fixture",
    }
    assert kind_summary["signed_fixture"]["blocker_count"] == 2
    assert kind_summary["non_diagram_requirement"]["blocker_count"] == 1
    assert kind_summary["completion_gate"]["blocker_count"] == 4
    kind_consistency = payload["final_completion_blocker_kind_consistency"]
    assert kind_consistency["claim_scope"] == (
        "validation_pack_final_completion_blocker_kind_consistency"
    )
    assert kind_consistency["blocker_count"] == 7
    assert kind_consistency["summary_row_count"] == 3
    assert kind_consistency["summary_blocker_count"] == 7
    assert kind_consistency["blocker_kind_count"] == 3
    assert kind_consistency["kind_count"] == 3
    assert kind_consistency["kind_count_total"] == 7
    assert kind_consistency["kind_counts"] == {
        "completion_gate": 4,
        "non_diagram_requirement": 1,
        "signed_fixture": 2,
    }
    assert kind_consistency["signed_fixture_blocker_count"] == 2
    assert kind_consistency["non_diagram_requirement_blocker_count"] == 1
    assert kind_consistency["completion_gate_blocker_count"] == 4
    assert kind_consistency["all_blockers_have_kind"] is True
    assert kind_consistency["summary_blocker_count_matches_top_level"] is True
    assert kind_consistency["kind_count_total_matches_blocker_count"] is True
    assert kind_consistency["unique_kind_count_matches_summary"] is True
    assert kind_consistency["matched"] is True
    kind_detail = payload[
        "final_completion_blocker_kind_summary_detail_consistency"
    ]
    assert kind_detail["claim_scope"] == (
        "validation_pack_final_completion_blocker_kind_summary_detail_consistency"
    )
    assert kind_detail["summary_row_count"] == 3
    assert kind_detail["kind_count"] == 3
    assert kind_detail["checked_blocker_kind_count"] == 3
    assert kind_detail["blocker_count"] == 7
    assert kind_detail["blocker_code_reference_count"] == 6
    assert kind_detail["unique_blocker_code_reference_count"] == 6
    assert kind_detail["missing_artifact_reference_count"] == 6
    assert kind_detail["unique_missing_artifact_reference_count"] == 6
    assert kind_detail["unique_missing_artifact_count"] == 5
    assert kind_detail["summary_blocker_count_total"] == 7
    assert kind_detail["blocker_count_matched_count"] == 3
    assert kind_detail["blocker_codes_matched_count"] == 3
    assert kind_detail["missing_artifacts_matched_count"] == 3
    assert kind_detail["mismatched_summary_row_count"] == 0
    assert kind_detail["all_blocker_counts_matched"] is True
    assert kind_detail["all_blocker_codes_matched"] is True
    assert kind_detail["all_missing_artifacts_matched"] is True
    assert kind_detail["matched"] is True
    kind_detail_rows = {row["blocker_kind"]: row for row in kind_detail["rows"]}
    assert kind_detail_rows["completion_gate"]["expected_blocker_count"] == 4
    assert kind_detail_rows["non_diagram_requirement"]["expected_blocker_count"] == 1
    assert kind_detail_rows["signed_fixture"]["expected_blocker_count"] == 2
    assert kind_detail_rows["signed_fixture"]["summary_blocker_codes"] == [
        "signed_pd_not_registered"
    ]
    gate_summary = {
        row["gate"]: row
        for row in payload["final_completion_open_gate_blocker_summary"]
    }
    assert set(gate_summary) == {
        "full_homfly_pt_evaluation",
        "full_multivariable_alexander_normalization",
        "non_diagram_requirements",
        "production_imgui_renderer",
        "release_artifacts",
        "signed_diagram_fixture_registration",
    }
    assert gate_summary["signed_diagram_fixture_registration"]["blocker_count"] == 2
    assert gate_summary["non_diagram_requirements"]["blocker_count"] == 1
    assert gate_summary["production_imgui_renderer"]["retained_evidence_count"] == 2
    assert gate_summary["non_diagram_requirements"]["retained_evidence_count"] == 2
    gate_summary_consistency = payload[
        "final_completion_open_gate_blocker_summary_consistency"
    ]
    assert gate_summary_consistency["claim_scope"] == (
        "final_completion_open_gate_blocker_summary_consistency"
    )
    assert gate_summary_consistency["failed_gate_count"] == 6
    assert gate_summary_consistency["summary_gate_count"] == 6
    assert gate_summary_consistency["blocker_count"] == 7
    assert gate_summary_consistency["summary_blocker_count"] == 7
    assert gate_summary_consistency["gate_sets_matched"] is True
    assert gate_summary_consistency["blocker_count_matched"] is True
    assert gate_summary_consistency["all_blockers_have_gate"] is True
    gate_summary_detail = payload[
        "final_completion_open_gate_blocker_summary_detail_consistency"
    ]
    assert gate_summary_detail["claim_scope"] == (
        "validation_pack_final_completion_open_gate_blocker_summary_detail_consistency"
    )
    assert gate_summary_detail["summary_gate_count"] == 6
    assert gate_summary_detail["checked_gate_count"] == 6
    assert gate_summary_detail["blocker_count"] == 7
    assert gate_summary_detail["blocker_code_reference_count"] == 6
    assert gate_summary_detail["missing_artifact_reference_count"] == 6
    assert gate_summary_detail["unique_missing_artifact_count"] == 5
    assert gate_summary_detail["retained_evidence_reference_count"] == 10
    assert gate_summary_detail["summary_blocker_count_total"] == 7
    assert gate_summary_detail["blocker_count_matched_count"] == 6
    assert gate_summary_detail["blocker_codes_matched_count"] == 6
    assert gate_summary_detail["missing_artifacts_matched_count"] == 6
    assert gate_summary_detail["retained_evidence_count_matched_count"] == 6
    assert gate_summary_detail["mismatched_summary_row_count"] == 0
    assert gate_summary_detail["all_blocker_counts_matched"] is True
    assert gate_summary_detail["all_blocker_codes_matched"] is True
    assert gate_summary_detail["all_missing_artifacts_matched"] is True
    assert gate_summary_detail["all_retained_evidence_counts_matched"] is True
    assert gate_summary_detail["matched"] is True
    gate_summary_detail_rows = {
        row["gate"]: row for row in gate_summary_detail["rows"]
    }
    assert gate_summary_detail_rows["non_diagram_requirements"][
        "expected_retained_evidence_count"
    ] == 2
    assert gate_summary_detail_rows["release_artifacts"][
        "summary_missing_artifacts"
    ] == ["signed_release_publication_manifest"]
    gate_blocker_consistency = payload[
        "final_completion_gate_blocker_consistency"
    ]
    assert gate_blocker_consistency["claim_scope"] == (
        "validation_pack_final_completion_gate_blocker_consistency"
    )
    assert gate_blocker_consistency["gate_check_count"] == 7
    assert gate_blocker_consistency["summary_gate_count"] == 6
    assert gate_blocker_consistency["checked_gate_count"] == 7
    assert gate_blocker_consistency["matched_gate_count"] == 7
    assert gate_blocker_consistency["mismatched_gate_count"] == 0
    assert gate_blocker_consistency["blocker_count_matched_gate_count"] == 7
    assert gate_blocker_consistency["blocker_codes_matched_gate_count"] == 7
    assert gate_blocker_consistency["all_gate_blocker_counts_matched"] is True
    assert gate_blocker_consistency["all_gate_blocker_codes_matched"] is True
    assert gate_blocker_consistency["matched"] is True
    gate_blocker_rows = {
        row["gate"]: row for row in gate_blocker_consistency["gate_rows"]
    }
    assert gate_blocker_rows["required_diagram_fixture_metadata"][
        "summary_blocker_count"
    ] == 0
    assert gate_blocker_rows["required_diagram_fixture_metadata"][
        "summary_blocker_codes"
    ] == []
    assert gate_blocker_rows["non_diagram_requirements"][
        "gate_blocker_count"
    ] == 1
    assert gate_blocker_rows["non_diagram_requirements"][
        "summary_blocker_count"
    ] == 1
    assert gate_blocker_rows["non_diagram_requirements"][
        "blocker_codes_matched"
    ] is True
    required_check_consistency = payload[
        "final_completion_required_check_consistency"
    ]
    assert required_check_consistency["claim_scope"] == (
        "validation_pack_final_completion_required_check_consistency"
    )
    assert payload["required_check_count"] == 3
    assert payload["passed_check_count"] == 1
    assert payload["failed_check_count"] == 2
    assert required_check_consistency["required_check_count"] == 3
    assert required_check_consistency["passed_required_check_count"] == 1
    assert required_check_consistency["failed_required_check_count"] == 2
    assert required_check_consistency["mismatched_required_check_count"] == 2
    assert required_check_consistency["metadata_check_passed"] is True
    assert required_check_consistency["signed_fixture_check_passed"] is False
    assert required_check_consistency["non_diagram_check_passed"] is False
    assert required_check_consistency["metadata_blocker_count"] == 0
    assert required_check_consistency["signed_fixture_blocker_count"] == 2
    assert required_check_consistency["open_non_diagram_requirement_count"] == 1
    assert required_check_consistency["final_completion_ready"] is False
    assert required_check_consistency["final_completion_ready_expected"] is False
    assert (
        required_check_consistency[
            "final_completion_ready_matches_required_checks"
        ]
        is True
    )
    assert required_check_consistency["all_required_checks_matched"] is False
    assert required_check_consistency["matched"] is False
    required_check_rows = {
        row["check"]: row for row in required_check_consistency["required_check_rows"]
    }
    assert required_check_rows["required_diagram_fixture_metadata"]["passed"] is True
    assert (
        required_check_rows["signed_diagram_fixture_registration"]["blocker_count"]
        == 2
    )
    assert (
        required_check_rows["signed_diagram_fixture_registration"]["expected_passed"]
        is True
    )
    assert required_check_rows["signed_diagram_fixture_registration"]["matched"] is False
    assert (
        required_check_rows["non_diagram_requirements"]["blocker_codes"]
        == [
            "native_imgui_screenshot_framebuffer_fixtures_partial",
        ]
    )
    assert required_check_rows["non_diagram_requirements"]["expected_passed"] is True
    assert required_check_rows["non_diagram_requirements"]["matched"] is False
    required_fixture_metadata = payload[
        "final_completion_required_diagram_fixture_metadata_consistency"
    ]
    assert required_fixture_metadata["claim_scope"] == (
        "validation_pack_final_completion_required_diagram_fixture_metadata_consistency"
    )
    assert required_fixture_metadata["required_fixture_count"] == 7
    assert required_fixture_metadata["registered_fixture_count"] == 7
    assert required_fixture_metadata["missing_fixture_count"] == 0
    assert required_fixture_metadata["metadata_complete_fixture_count"] == 7
    assert required_fixture_metadata["metadata_incomplete_fixture_count"] == 0
    assert required_fixture_metadata["mismatched_fixture_count"] == 0
    assert required_fixture_metadata["metadata_blocker_count"] == 0
    assert required_fixture_metadata["row_metadata_blocker_count"] == 0
    assert required_fixture_metadata["gate_passed"] is True
    assert required_fixture_metadata["gate_blocker_count"] == 0
    assert required_fixture_metadata["gate_blocker_codes"] == []
    assert required_fixture_metadata["all_required_fixtures_registered"] is True
    assert required_fixture_metadata["all_fixture_metadata_complete"] is True
    assert (
        required_fixture_metadata["top_level_metadata_complete_matched"] is True
    )
    assert required_fixture_metadata["gate_passed_matches_metadata_complete"] is True
    assert required_fixture_metadata["gate_blocker_count_matched"] is True
    assert required_fixture_metadata["matched"] is True
    assert [row["notation"] for row in required_fixture_metadata["rows"]] == [
        "0_1",
        "3_1",
        "4_1",
        "L0a1",
        "L2a1",
        "L5a1",
        "L6a4",
    ]
    for row in required_fixture_metadata["rows"]:
        if row["source_url_required"]:
            assert row["source_url_scheme"] in {"http", "https"}
            assert row["source_url_domain"]
            assert row["source_url_http_or_https"] is True
            assert row["source_url_http_or_https_when_applicable"] is True
            assert row["source_url_requirement_satisfied"] is True
    assert all(
        row["metadata_complete"] is True
        and row["metadata_blocker_count"] == 0
        and row["metadata_complete_matched"] is True
        for row in required_fixture_metadata["rows"]
    )
    signed_fixture_consistency = payload[
        "final_completion_signed_fixture_consistency"
    ]
    assert signed_fixture_consistency["claim_scope"] == (
        "validation_pack_final_completion_signed_fixture_consistency"
    )
    assert signed_fixture_consistency["signed_fixture_blocker_count"] == 2
    assert signed_fixture_consistency["final_blocker_count"] == 2
    assert signed_fixture_consistency["matched_fixture_count"] == 2
    assert signed_fixture_consistency["mismatched_fixture_count"] == 0
    assert signed_fixture_consistency["source_url_present_count"] == 2
    assert signed_fixture_consistency["unsigned_non_claim_preserved_count"] == 2
    assert signed_fixture_consistency["source_table_metadata_available_count"] == 2
    assert signed_fixture_consistency["missing_artifact_matched_count"] == 2
    assert signed_fixture_consistency["evidence_fields_matched_count"] == 2
    assert signed_fixture_consistency["source_candidate_evidence_available_count"] == 2
    assert signed_fixture_consistency["source_candidate_not_unique_count"] == 2
    assert signed_fixture_consistency["source_candidate_replay_all_valid_count"] == 2
    assert (
        signed_fixture_consistency[
            "source_candidate_matching_candidate_count_total"
        ]
        == 32
    )
    assert (
        signed_fixture_consistency[
            "source_candidate_unique_sign_pattern_count_total"
        ]
        == 20
    )
    assert (
        signed_fixture_consistency[
            "all_signed_fixture_blockers_have_final_blockers"
        ]
        is True
    )
    assert signed_fixture_consistency[
        "all_final_blockers_have_signed_fixture_rows"
    ] is True
    assert signed_fixture_consistency["all_missing_artifacts_matched"] is True
    assert signed_fixture_consistency["all_evidence_fields_matched"] is True
    assert signed_fixture_consistency["all_unsigned_non_claims_preserved"] is True
    assert signed_fixture_consistency["all_source_table_metadata_available"] is True
    assert signed_fixture_consistency["matched"] is True
    signed_fixture_rows = {
        row["notation"]: row for row in signed_fixture_consistency["rows"]
    }
    assert signed_fixture_rows["L5a1"]["blocker_code"] == "signed_pd_not_registered"
    assert signed_fixture_rows["L5a1"]["source_url"] == (
        "https://katlas.org/wiki/L5a1"
    )
    assert signed_fixture_rows["L5a1"]["source_candidate_matching_candidate_count"] == 24
    assert signed_fixture_rows["L5a1"]["source_candidate_unique_sign_pattern_count"] == 12
    assert signed_fixture_rows["L6a4"]["source_url"] == (
        "https://katlas.org/wiki/L6a4"
    )
    assert signed_fixture_rows["L6a4"]["source_candidate_matching_candidate_count"] == 8
    assert signed_fixture_rows["L6a4"]["source_candidate_unique_sign_pattern_count"] == 8
    assert signed_fixture_rows["L6a4"]["unsigned_non_claim_preserved"] is True
    non_diagram_consistency = payload[
        "final_completion_non_diagram_requirement_consistency"
    ]
    assert non_diagram_consistency["claim_scope"] == (
        "validation_pack_final_completion_non_diagram_requirement_consistency"
    )
    assert non_diagram_consistency["requirement_count"] == 6
    assert non_diagram_consistency["open_requirement_count"] == 1
    assert non_diagram_consistency["blocker_count"] == 1
    assert non_diagram_consistency["matched_requirement_count"] == 1
    assert non_diagram_consistency["mismatched_requirement_count"] == 0
    assert non_diagram_consistency["retained_evidence_reference_count"] == 2
    assert non_diagram_consistency["retained_evidence_id_count"] == 2
    assert non_diagram_consistency["retained_evidence_ids"] == [
        "imgui_real_kernel_loader_smoke_retained_pack",
        "imgui_test_stub_framebuffer_smoke_retained_pack",
    ]
    assert (
        non_diagram_consistency[
            "retained_evidence_reference_count_matches_top_level"
        ]
        is True
    )
    assert (
        non_diagram_consistency["retained_evidence_id_count_matches_top_level"]
        is True
    )
    assert non_diagram_consistency["missing_artifact_matched_count"] == 1
    assert non_diagram_consistency["evidence_fields_matched_count"] == 1
    assert non_diagram_consistency["retained_evidence_count_matched_count"] == 1
    assert non_diagram_consistency["completion_claimed_false_count"] == 1
    assert non_diagram_consistency["all_open_requirements_have_blockers"] is True
    assert non_diagram_consistency["all_blockers_have_open_requirements"] is True
    assert non_diagram_consistency["all_missing_artifacts_matched"] is True
    assert non_diagram_consistency["all_evidence_fields_matched"] is True
    assert non_diagram_consistency["all_retained_evidence_counts_matched"] is True
    assert non_diagram_consistency["all_retained_evidence_ids_matched"] is True
    assert non_diagram_consistency["all_completion_claims_false"] is True
    assert non_diagram_consistency["matched"] is True
    non_diagram_rows = {
        row["requirement"]: row for row in non_diagram_consistency["rows"]
    }
    assert "noisy sampled curves" not in non_diagram_rows
    assert "high-point-count performance curves" not in non_diagram_rows
    assert non_diagram_rows["native ImGui screenshot/framebuffer fixtures"][
        "retained_evidence_count"
    ] == 2
    assert non_diagram_rows["native ImGui screenshot/framebuffer fixtures"][
        "blocker_code"
    ] == "native_imgui_screenshot_framebuffer_fixtures_partial"
    assert non_diagram_rows["native ImGui screenshot/framebuffer fixtures"][
        "retained_evidence_ids"
    ] == [
        "imgui_real_kernel_loader_smoke_retained_pack",
        "imgui_test_stub_framebuffer_smoke_retained_pack",
    ]
    non_claim_gate_consistency = payload[
        "final_completion_non_claim_gate_consistency"
    ]
    assert non_claim_gate_consistency["claim_scope"] == (
        "validation_pack_final_completion_non_claim_gate_consistency"
    )
    assert non_claim_gate_consistency["non_claim_gate_count"] == 4
    assert non_claim_gate_consistency["non_claim_field_count"] == 4
    assert non_claim_gate_consistency["top_level_false_count"] == 4
    assert non_claim_gate_consistency["false_non_claim_field_count"] == 4
    assert non_claim_gate_consistency["completion_gate_check_count"] == 4
    assert non_claim_gate_consistency["gate_check_failed_count"] == 4
    assert non_claim_gate_consistency["completion_gate_blocker_count"] == 4
    assert non_claim_gate_consistency["missing_artifact_reference_count"] == 4
    assert non_claim_gate_consistency["unique_missing_artifact_count"] == 4
    assert non_claim_gate_consistency["blocker_code_matched_count"] == 4
    assert non_claim_gate_consistency["missing_artifact_matched_count"] == 4
    assert non_claim_gate_consistency["matched_gate_count"] == 4
    assert non_claim_gate_consistency["matched_non_claim_field_count"] == 4
    assert non_claim_gate_consistency["mismatched_non_claim_field_count"] == 0
    assert non_claim_gate_consistency["all_non_claim_fields_false"] is True
    assert non_claim_gate_consistency["all_top_level_values_false"] is True
    assert non_claim_gate_consistency["all_false_fields_have_failed_gate"] is True
    assert non_claim_gate_consistency["all_gate_checks_failed"] is True
    assert (
        non_claim_gate_consistency["all_false_fields_have_completion_gate_blocker"]
        is True
    )
    assert non_claim_gate_consistency["all_completion_gate_blockers_present"] is True
    assert non_claim_gate_consistency["all_false_fields_have_missing_artifact"] is True
    assert non_claim_gate_consistency["all_blocker_codes_matched"] is True
    assert non_claim_gate_consistency["all_missing_artifacts_matched"] is True
    assert non_claim_gate_consistency["matched"] is True
    non_claim_gate_rows = {
        row["gate"]: row for row in non_claim_gate_consistency["gate_rows"]
    }
    assert non_claim_gate_rows["production_imgui_renderer"][
        "top_level_field"
    ] == "production_imgui_renderer_verified"
    assert non_claim_gate_rows["release_artifacts"][
        "expected_missing_artifact"
    ] == "signed_release_publication_manifest"
    completion_gate_evidence = payload[
        "final_completion_completion_gate_evidence_consistency"
    ]
    assert completion_gate_evidence["claim_scope"] == (
        "validation_pack_final_completion_completion_gate_evidence_consistency"
    )
    assert completion_gate_evidence["gate_count"] == 4
    assert completion_gate_evidence["gate_check_count"] == 4
    assert completion_gate_evidence["completion_gate_blocker_count"] == 4
    assert completion_gate_evidence["failed_gate_count"] == 4
    assert completion_gate_evidence["top_level_false_count"] == 4
    assert completion_gate_evidence["blocker_code_matched_count"] == 4
    assert completion_gate_evidence["gate_code_matched_count"] == 4
    assert completion_gate_evidence["required_evidence_matched_count"] == 4
    assert completion_gate_evidence["current_evidence_matched_count"] == 4
    assert completion_gate_evidence["missing_artifact_matched_count"] == 4
    assert completion_gate_evidence["missing_artifact_id_matched_count"] == 4
    assert completion_gate_evidence["retained_evidence_reference_count"] == 8
    assert completion_gate_evidence["retained_evidence_id_count"] == 8
    assert completion_gate_evidence["retained_evidence_ids_matched_count"] == 4
    assert completion_gate_evidence["mismatched_gate_count"] == 0
    assert completion_gate_evidence["all_gate_checks_present"] is True
    assert completion_gate_evidence["all_completion_gate_blockers_present"] is True
    assert completion_gate_evidence["all_completion_gates_failed"] is True
    assert completion_gate_evidence["all_top_level_fields_false"] is True
    assert completion_gate_evidence["all_evidence_fields_matched"] is True
    assert completion_gate_evidence["matched"] is True
    completion_gate_rows = {
        row["gate"]: row for row in completion_gate_evidence["rows"]
    }
    assert completion_gate_rows["production_imgui_renderer"][
        "current_evidence_matched"
    ] is True
    assert completion_gate_rows["release_artifacts"]["missing_artifact"] == (
        "signed_release_publication_manifest"
    )
    blocker_links = payload["final_completion_blocker_evidence_links"]
    assert len(blocker_links) == payload["final_completion_blocker_count"]
    linked_blocker_labels = {
        link["blocker_label"]
        for link in blocker_links
        if link["retained_evidence_count"] > 0
    }
    assert linked_blocker_labels == {
        "full_homfly_pt_evaluation",
        "full_multivariable_alexander_normalization",
        "native ImGui screenshot/framebuffer fixtures",
        "production_imgui_renderer",
        "release_artifacts",
    }
    native_link = {
        link["blocker_label"]: link for link in blocker_links
    }["native ImGui screenshot/framebuffer fixtures"]
    assert native_link["retained_evidence_count"] == 2
    assert native_link["retained_evidence_all_non_claimed"] is True
    blocker_link_consistency = payload[
        "final_completion_blocker_evidence_link_consistency"
    ]
    assert blocker_link_consistency["claim_scope"] == (
        "validation_pack_final_completion_blocker_retained_evidence_link_consistency"
    )
    assert blocker_link_consistency["blocker_count"] == 7
    assert blocker_link_consistency["linked_blocker_count"] == 5
    assert blocker_link_consistency["unlinked_blocker_count"] == 2
    assert blocker_link_consistency["retained_evidence_reference_count"] == 10
    assert blocker_link_consistency["retained_evidence_id_count"] == 8
    assert (
        blocker_link_consistency[
            "retained_evidence_reference_count_matches_top_level"
        ]
        is True
    )
    assert (
        blocker_link_consistency["retained_evidence_id_count_matches_top_level"]
        is True
    )
    assert (
        blocker_link_consistency[
            "retained_evidence_non_claim_consistency_matches_top_level"
        ]
        is True
    )
    assert blocker_link_consistency["blocker_label_present_count"] == 7
    assert blocker_link_consistency["blocker_code_present_count"] == 7
    assert blocker_link_consistency["missing_artifact_present_count"] == 7
    assert blocker_link_consistency["required_evidence_present_count"] == 7
    assert blocker_link_consistency["current_evidence_present_count"] == 7
    assert blocker_link_consistency["all_blockers_have_machine_audit_fields"] is True
    assert blocker_link_consistency["matched"] is True
    link_kind_summary = {
        row["blocker_kind"]: row
        for row in payload["final_completion_blocker_evidence_link_kind_summary"]
    }
    assert link_kind_summary["non_diagram_requirement"]["blocker_count"] == 1
    assert link_kind_summary["non_diagram_requirement"][
        "linked_blocker_count"
    ] == 1
    assert link_kind_summary["non_diagram_requirement"][
        "retained_evidence_reference_count"
    ] == 2
    assert link_kind_summary["completion_gate"]["linked_blocker_count"] == 4
    assert link_kind_summary["completion_gate"]["unlinked_blocker_count"] == 0
    assert link_kind_summary["completion_gate"][
        "retained_evidence_reference_count"
    ] == 8
    link_kind_detail = payload[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency"
    ]
    assert link_kind_detail["summary_row_count"] == 3
    assert link_kind_detail["checked_blocker_kind_count"] == 3
    assert link_kind_detail["blocker_count"] == 7
    assert link_kind_detail["linked_blocker_count"] == 5
    assert link_kind_detail["unlinked_blocker_count"] == 2
    assert link_kind_detail["retained_evidence_reference_count"] == 10
    assert link_kind_detail["retained_evidence_id_count"] == 8
    assert link_kind_detail["retained_evidence_non_claimed_link_count"] == 7
    assert link_kind_detail["blocker_count_matched_count"] == 3
    assert link_kind_detail["linked_blocker_count_matched_count"] == 3
    assert link_kind_detail["unlinked_blocker_count_matched_count"] == 3
    assert link_kind_detail["retained_evidence_reference_count_matched_count"] == 3
    assert link_kind_detail["retained_evidence_ids_matched_count"] == 3
    assert link_kind_detail["retained_evidence_non_claim_counts_matched_count"] == 3
    assert link_kind_detail["mismatched_summary_row_count"] == 0
    assert link_kind_detail["matched"] is True
    missing_artifact_summary = {
        row["missing_artifact"]: row
        for row in payload["final_completion_missing_artifact_summary"]
    }
    assert len(missing_artifact_summary) == 5
    assert missing_artifact_summary["verified_signed_crossing_assignment"][
        "blocker_count"
    ] == 2
    assert missing_artifact_summary["production_imgui_renderer_framebuffer_pack"][
        "blocker_count"
    ] == 2
    assert missing_artifact_summary["signed_release_publication_manifest"][
        "blocker_count"
    ] == 1
    missing_artifact_consistency = payload[
        "final_completion_missing_artifact_summary_consistency"
    ]
    assert missing_artifact_consistency["claim_scope"] == (
        "validation_pack_final_completion_missing_artifact_summary_consistency"
    )
    assert missing_artifact_consistency["reference_count"] == 7
    assert missing_artifact_consistency["unique_missing_artifact_count"] == 5
    assert missing_artifact_consistency["summary_row_count"] == 5
    assert missing_artifact_consistency["blocker_count"] == 7
    assert missing_artifact_consistency["references_match_blocker_count"] is True
    assert (
        missing_artifact_consistency[
            "summary_row_count_matches_unique_missing_artifacts"
        ]
        is True
    )
    assert missing_artifact_consistency["all_blockers_have_missing_artifact"] is True
    assert missing_artifact_consistency["top_level_missing_artifact_count"] == 5
    assert (
        missing_artifact_consistency["top_level_missing_artifacts"]
        == expected_missing_artifacts
    )
    assert missing_artifact_consistency[
        "top_level_missing_artifact_signature"
    ] == "|".join(expected_missing_artifacts)
    assert (
        missing_artifact_consistency[
            "top_level_missing_artifact_count_matches_summary"
        ]
        is True
    )
    assert (
        missing_artifact_consistency[
            "top_level_missing_artifacts_match_summary"
        ]
        is True
    )
    assert missing_artifact_consistency["matched"] is True
    missing_artifact_detail = payload[
        "final_completion_missing_artifact_summary_detail_consistency"
    ]
    assert missing_artifact_detail["claim_scope"] == (
        "validation_pack_final_completion_missing_artifact_summary_detail_consistency"
    )
    assert missing_artifact_detail["summary_row_count"] == 5
    assert missing_artifact_detail["unique_missing_artifact_count"] == 5
    assert missing_artifact_detail["blocker_count"] == 7
    assert missing_artifact_detail["blocker_code_reference_count"] == 6
    assert missing_artifact_detail["blocker_label_reference_count"] == 7
    assert missing_artifact_detail["blocker_count_matched_count"] == 5
    assert missing_artifact_detail["blocker_codes_matched_count"] == 5
    assert missing_artifact_detail["blocker_labels_matched_count"] == 5
    assert missing_artifact_detail["mismatched_summary_row_count"] == 0
    assert missing_artifact_detail["all_summary_rows_present"] is True
    assert missing_artifact_detail["all_blocker_counts_matched"] is True
    assert missing_artifact_detail["all_blocker_codes_matched"] is True
    assert missing_artifact_detail["all_blocker_labels_matched"] is True
    assert (
        missing_artifact_detail["summary_blocker_count_total_matches_top_level"]
        is True
    )
    assert missing_artifact_detail["matched"] is True
    detail_rows = {
        row["missing_artifact"]: row for row in missing_artifact_detail["rows"]
    }
    assert detail_rows["verified_signed_crossing_assignment"][
        "expected_blocker_count"
    ] == 2
    assert detail_rows["verified_signed_crossing_assignment"][
        "summary_blocker_codes"
    ] == ["signed_pd_not_registered"]
    assert detail_rows["production_imgui_renderer_framebuffer_pack"][
        "summary_blocker_labels"
    ] == [
        "native ImGui screenshot/framebuffer fixtures",
        "production_imgui_renderer",
    ]
    evidence_field_summary = {
        row["blocker_kind"]: row
        for row in payload["final_completion_blocker_evidence_field_summary"]
    }
    assert set(evidence_field_summary) == {
        "completion_gate",
        "non_diagram_requirement",
        "signed_fixture",
    }
    assert evidence_field_summary["signed_fixture"]["blocker_count"] == 2
    assert evidence_field_summary["non_diagram_requirement"]["blocker_count"] == 1
    assert evidence_field_summary["completion_gate"]["blocker_count"] == 4
    evidence_field_rows = payload["final_completion_blocker_evidence_field_rows"]
    assert len(evidence_field_rows) == payload["final_completion_blocker_count"]
    assert all(row["all_evidence_fields_present"] for row in evidence_field_rows)
    evidence_field_consistency = payload[
        "final_completion_blocker_evidence_field_consistency"
    ]
    assert evidence_field_consistency["claim_scope"] == (
        "validation_pack_final_completion_blocker_evidence_field_consistency"
    )
    assert evidence_field_consistency["blocker_count"] == 7
    assert evidence_field_consistency["summary_row_count"] == 3
    assert evidence_field_consistency["missing_artifact_present_count"] == 7
    assert evidence_field_consistency["required_evidence_present_count"] == 7
    assert evidence_field_consistency["current_evidence_present_count"] == 7
    assert evidence_field_consistency["all_evidence_fields_present_count"] == 7
    assert evidence_field_consistency["all_blockers_have_evidence_fields"] is True
    assert evidence_field_consistency["matched"] is True
    evidence_field_detail = payload[
        "final_completion_blocker_evidence_field_summary_detail_consistency"
    ]
    assert evidence_field_detail["claim_scope"] == (
        "validation_pack_final_completion_blocker_evidence_field_summary_detail_consistency"
    )
    assert evidence_field_detail["summary_row_count"] == 3
    assert evidence_field_detail["checked_blocker_kind_count"] == 3
    assert evidence_field_detail["blocker_count"] == 7
    assert evidence_field_detail["missing_artifact_present_count"] == 7
    assert evidence_field_detail["required_evidence_present_count"] == 7
    assert evidence_field_detail["current_evidence_present_count"] == 7
    assert evidence_field_detail["all_evidence_fields_present_count"] == 7
    assert evidence_field_detail["blocker_count_matched_count"] == 3
    assert evidence_field_detail["missing_artifact_present_count_matched_count"] == 3
    assert evidence_field_detail["required_evidence_present_count_matched_count"] == 3
    assert evidence_field_detail["current_evidence_present_count_matched_count"] == 3
    assert evidence_field_detail["all_evidence_fields_present_count_matched_count"] == 3
    assert evidence_field_detail["mismatched_summary_row_count"] == 0
    assert evidence_field_detail["all_evidence_field_counts_matched"] is True
    assert evidence_field_detail["matched"] is True
    evidence_field_detail_rows = {
        row["blocker_kind"]: row for row in evidence_field_detail["rows"]
    }
    assert evidence_field_detail_rows["completion_gate"][
        "expected_blocker_count"
    ] == 4
    assert evidence_field_detail_rows["non_diagram_requirement"][
        "expected_blocker_count"
    ] == 1
    assert evidence_field_detail_rows["signed_fixture"][
        "expected_blocker_count"
    ] == 2
    assert payload["retained_evidence_count"] == 10
    assert payload["retained_evidence_id_count"] == 8
    assert payload["retained_evidence_ids"] == [
        "alexander_generated_signed_pd_coverage_report",
        "alexander_registered_fixture_acceptance_report",
        "homfly_registered_fixture_acceptance_report",
        "homfly_small_diagram_generated_coverage_report",
        "imgui_real_kernel_loader_smoke_retained_pack",
        "imgui_test_stub_framebuffer_smoke_retained_pack",
        "imgui_windows_retained_artifacts_manifest",
        "rust_wheel_retained_metadata_manifest",
    ]
    assert payload["retained_evidence_completion_claimed_count"] == 0
    assert payload["retained_evidence_release_grade_speedup_claimed_count"] == 0
    assert (
        payload[
            "retained_evidence_real_graphics_backend_framebuffer_verified_count"
        ]
        == 0
    )
    assert payload["retained_evidence_screenshot_verified_count"] == 0
    assert payload["retained_evidence_all_non_claimed"] is True
    retained_non_claim = payload["retained_evidence_non_claim_consistency"]
    assert retained_non_claim["claim_scope"] == (
        "validation_pack_retained_evidence_non_claim_consistency"
    )
    assert retained_non_claim["entry_count"] == 10
    assert retained_non_claim["evidence_id_count"] == 8
    assert retained_non_claim["completion_claimed_count"] == 0
    assert retained_non_claim["release_grade_speedup_claimed_count"] == 0
    assert retained_non_claim[
        "real_graphics_backend_framebuffer_verified_count"
    ] == 0
    assert retained_non_claim["screenshot_verified_count"] == 0
    assert retained_non_claim["all_non_claimed"] is True
    assert retained_non_claim["entry_count_matches_top_level"] is True
    assert retained_non_claim["evidence_id_count_matches_top_level"] is True
    assert retained_non_claim["completion_claimed_count_matches_top_level"] is True
    assert (
        retained_non_claim[
            "release_grade_speedup_claimed_count_matches_top_level"
        ]
        is True
    )
    assert (
        retained_non_claim[
            "real_graphics_backend_framebuffer_verified_count_matches_top_level"
        ]
        is True
    )
    assert retained_non_claim["screenshot_verified_count_matches_top_level"] is True
    assert retained_non_claim["matched"] is True
    artifact_file_consistency = payload[
        "retained_evidence_artifact_file_consistency"
    ]
    assert artifact_file_consistency["claim_scope"] == (
        "validation_pack_retained_evidence_artifact_file_consistency"
    )
    assert artifact_file_consistency["entry_count"] == 10
    assert artifact_file_consistency["artifact_evidence_count"] == 2
    assert artifact_file_consistency["non_artifact_evidence_count"] == 8
    assert artifact_file_consistency["artifact_file_reference_count"] == 6
    assert artifact_file_consistency["unique_artifact_file_count"] == 6
    assert artifact_file_consistency["raw_file_count"] == 2
    assert artifact_file_consistency["analysis_file_count"] == 2
    assert artifact_file_consistency["host_file_count"] == 2
    assert artifact_file_consistency[
        "complete_raw_analysis_host_group_count"
    ] == 2
    assert artifact_file_consistency["incomplete_artifact_group_count"] == 0
    assert artifact_file_consistency[
        "artifact_file_reference_count_matches_groups"
    ] is True
    assert artifact_file_consistency["raw_analysis_host_file_counts_matched"] is True
    assert artifact_file_consistency["all_artifact_evidence_groups_complete"] is True
    assert artifact_file_consistency["all_artifact_files_unique"] is True
    assert artifact_file_consistency["matched"] is True
    artifact_rows = {
        row["evidence_id"]: row
        for row in artifact_file_consistency["artifact_rows"]
    }
    assert set(artifact_rows) == {
        "imgui_real_kernel_loader_smoke_retained_pack",
        "imgui_test_stub_framebuffer_smoke_retained_pack",
    }
    retained_evidence = [
        evidence
        for blocker in payload["final_completion_blockers"]
        for evidence in blocker.get("retained_evidence", [])
    ]
    assert len(retained_evidence) == payload["retained_evidence_count"]
    assert (
        len({evidence["evidence_id"] for evidence in retained_evidence})
        == payload["retained_evidence_id_count"]
    )
    assert (
        sum(1 for evidence in retained_evidence if evidence["completion_claimed"])
        == payload["retained_evidence_completion_claimed_count"]
    )
    final_signed_blockers = {
        row["notation"]: row
        for row in payload["final_completion_blockers"]
        if row["kind"] == "signed_fixture"
    }
    assert final_signed_blockers["L5a1"]["source"] == "Knot Atlas"
    assert final_signed_blockers["L5a1"]["source_table_homfly_available"] is True
    assert "verified signed crossing assignment" in final_signed_blockers["L5a1"][
        "required_evidence"
    ]
    assert "fixture remains unsigned and unregistered" in final_signed_blockers[
        "L5a1"
    ]["current_evidence"]
    assert final_signed_blockers["L6a4"][
        "source_table_multivariable_alexander_numerator_available"
    ] is True
    completion_gate_blockers = {
        row["gate"]: row
        for row in payload["final_completion_blockers"]
        if row["kind"] == "completion_gate"
    }
    assert completion_gate_blockers["full_homfly_pt_evaluation"][
        "missing_artifact"
    ] == "full_homfly_pt_evaluation_certification_pack"
    assert "bounded generated small-diagram coverage" in completion_gate_blockers[
        "full_homfly_pt_evaluation"
    ]["current_evidence"]
    assert completion_gate_blockers["full_multivariable_alexander_normalization"][
        "missing_artifact"
    ] == "full_multivariable_alexander_normalization_certification_pack"
    assert completion_gate_blockers["production_imgui_renderer"][
        "missing_artifact"
    ] == "production_imgui_renderer_framebuffer_pack"
    assert "repository test-stub framebuffer" in completion_gate_blockers[
        "production_imgui_renderer"
    ]["current_evidence"]
    assert completion_gate_blockers["release_artifacts"][
        "missing_artifact"
    ] == "signed_release_publication_manifest"
    gate_checks = {row["gate"]: row for row in payload["final_completion_gate_checks"]}
    assert gate_checks["signed_diagram_fixture_registration"]["blocked_notations"] == [
        "L5a1",
        "L6a4",
    ]
    assert gate_checks["non_diagram_requirements"]["blocker_codes"] == [
        "native_imgui_screenshot_framebuffer_fixtures_partial",
    ]
    assert gate_checks["production_imgui_renderer"]["missing_artifact"] == (
        "production_imgui_renderer_framebuffer_pack"
    )
    assert gate_checks["release_artifacts"]["missing_artifact"] == (
        "signed_release_publication_manifest"
    )
    requirement_statuses = {
        row["requirement"]: row["status"]
        for row in payload["non_diagram_requirements"]
    }
    assert requirement_statuses["mirror pairs"] == "available"
    assert requirement_statuses["split links"] == "available"
    assert requirement_statuses["UI sample reports with geometry"] == "available"
    assert requirement_statuses["noisy sampled curves"] == "available"
    assert requirement_statuses["high-point-count performance curves"] == "available"
    assert (
        requirement_statuses["native ImGui screenshot/framebuffer fixtures"]
        == "partial"
    )
    non_diagram_rows = {
        row["requirement"]: row for row in payload["non_diagram_requirements"]
    }
    assert non_diagram_rows["native ImGui screenshot/framebuffer fixtures"][
        "missing_artifact"
    ] == "production_imgui_renderer_framebuffer_pack"
    assert non_diagram_rows["native ImGui screenshot/framebuffer fixtures"][
        "completion_claimed"
    ] is False
    native_artifacts = non_diagram_rows[
        "native ImGui screenshot/framebuffer fixtures"
    ]["retained_evidence"]
    assert [artifact["artifact_kind"] for artifact in native_artifacts] == [
        "imgui_test_stub_framebuffer_smoke",
        "imgui_real_kernel_loader_smoke",
    ]
    assert native_artifacts[0]["evidence_id"] == (
        "imgui_test_stub_framebuffer_smoke_retained_pack"
    )
    assert native_artifacts[0]["completion_claimed"] is False
    assert "repository test-stub framebuffer" in non_diagram_rows[
        "native ImGui screenshot/framebuffer fixtures"
    ]["current_evidence"]
    assert non_diagram_rows["noisy sampled curves"]["certification_artifact"] == (
        "broad_noisy_curve_robustness_certification_pack"
    )
    noisy_evidence = non_diagram_rows["noisy sampled curves"][
        "certification_evidence"
    ]
    assert [evidence["evidence_id"] for evidence in noisy_evidence] == [
        "noisy_sampled_closed_curve_geometry_report_regression",
        "noisy_sampled_curve_family_matrix_regression",
        "broad_noisy_curve_robustness_certification_pack",
    ]
    assert noisy_evidence[0]["test"] == (
        "tests/test_geometry.py::"
        "test_noisy_sampled_closed_curve_keeps_finite_geometry_report"
    )
    assert noisy_evidence[0]["completion_claimed"] is False
    assert noisy_evidence[2]["test"] == (
        "tests/test_geometry.py::"
        "test_broad_noisy_sampled_curve_robustness_certification_pack"
    )
    assert noisy_evidence[2]["representative_curve_family_count"] == 6
    assert noisy_evidence[2]["completion_claimed"] is True
    assert non_diagram_rows["high-point-count performance curves"][
        "certification_artifact"
    ] == "release_grade_high_point_performance_pack"
    assert non_diagram_rows["high-point-count performance curves"][
        "status"
    ] == "available"
    high_point_evidence = non_diagram_rows[
        "high-point-count performance curves"
    ]["certification_evidence"]
    assert [evidence["evidence_id"] for evidence in high_point_evidence] == [
        "numpy_benchmark_matrix_local_profiling",
        "release_grade_high_point_performance_pack",
    ]
    assert high_point_evidence[0]["source_method"] == "iroll_core_benchmark_matrix"
    assert high_point_evidence[0]["release_grade_speedup_claimed"] is False
    assert high_point_evidence[1]["point_sizes"] == [128]
    assert high_point_evidence[1]["repeat"] == 3
    assert high_point_evidence[1]["release_grade_speedup_claimed"] is True
    assert high_point_evidence[1]["completion_claimed"] is True
    non_diagram_blockers = {
        row["requirement"]: row
        for row in payload["final_completion_blockers"]
        if row["kind"] == "non_diagram_requirement"
    }
    assert non_diagram_blockers["native ImGui screenshot/framebuffer fixtures"][
        "missing_artifact"
    ] == "production_imgui_renderer_framebuffer_pack"
    assert non_diagram_blockers["native ImGui screenshot/framebuffer fixtures"][
        "missing_artifact_id"
    ] == "production_imgui_renderer_framebuffer_pack"
    assert non_diagram_blockers["native ImGui screenshot/framebuffer fixtures"][
        "completion_claimed"
    ] is False
    assert non_diagram_blockers["native ImGui screenshot/framebuffer fixtures"][
        "retained_evidence"
    ][0]["artifact_kind"] == "imgui_test_stub_framebuffer_smoke"
    assert payload["final_completion_ready"] is False
    assert payload["production_imgui_renderer_verified"] is False
    source_url_summary = payload["fixture_source_url_shape_summary"]
    assert source_url_summary["claim_scope"] == (
        "validation_pack_fixture_source_url_shape_summary"
    )
    assert source_url_summary["fixture_row_count"] == 7
    assert source_url_summary["source_url_row_count"] == 3
    assert source_url_summary["external_source_url_row_count"] == 3
    assert source_url_summary["source_url_required_count"] == 3
    assert source_url_summary["source_url_http_or_https_count"] == 3
    assert source_url_summary["source_url_requirement_satisfied_count"] == 3
    assert source_url_summary["source_url_scheme_counts"] == {"https": 3}
    assert source_url_summary["source_url_domain_counts"] == {"katlas.org": 3}
    assert source_url_summary["matched"] is True
    known_limitations_summary = payload["fixture_known_limitations_summary"]
    assert known_limitations_summary["claim_scope"] == (
        "validation_pack_fixture_known_limitations_summary"
    )
    assert known_limitations_summary["fixture_row_count"] == 7
    assert known_limitations_summary["known_limitations_available_count"] == 7
    assert known_limitations_summary["known_limitations_unavailable_count"] == 0
    assert known_limitations_summary["known_limitations_note_count_total"] == 34
    assert (
        known_limitations_summary[
            "known_limitations_requirement_satisfied_count"
        ]
        == 7
    )
    assert known_limitations_summary["matched"] is True

    rows = {row["notation"]: row for row in payload["fixtures"]}
    assert rows["L5a1"]["has_signed_pd"] is False
    assert rows["L5a1"]["source_table_homfly_available"] is True
    assert rows["L6a4"]["source_url"] == "https://katlas.org/wiki/L6a4"

    with workspace_tempdir() as tmp_path:
        report_path = tmp_path / "validation-pack-audit.json"
        export_exit = main(["fixture-validation-pack-audit", "-o", str(report_path)])
        capsys.readouterr()
        analysis_exit = main(["imgui-analysis-summary-payload", str(report_path)])
        analysis = json.loads(capsys.readouterr().out)
        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(report_path)]
        )
        host = json.loads(capsys.readouterr().out)

    assert export_exit == 0
    assert analysis_exit == 0
    assert analysis["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert analysis["analysis_summary_count"] == 1
    assert analysis["analysis_validation_pack_audit_available_count"] == 1
    assert analysis["analysis_required_diagram_fixture_count"] == 7
    assert analysis["analysis_unsigned_required_fixture_count"] == 2
    assert analysis["analysis_open_non_diagram_requirement_count"] == 1
    assert analysis["analysis_final_completion_gate_count"] == 7
    assert analysis["analysis_final_completion_passed_gate_count"] == 1
    assert analysis["analysis_final_completion_failed_gate_count"] == 6
    assert analysis["analysis_final_completion_blocker_count"] == 7
    assert analysis["analysis_final_completion_blocker_code_count"] == 6
    assert analysis["analysis_final_completion_ready_count"] == 0
    assert analysis["analysis_validation_pack_fixture_source_url_fixture_row_count"] == 7
    assert analysis["analysis_validation_pack_fixture_source_url_row_count"] == 3
    assert analysis["analysis_validation_pack_fixture_source_url_external_row_count"] == 3
    assert analysis["analysis_validation_pack_fixture_source_url_required_count"] == 3
    assert (
        analysis["analysis_validation_pack_fixture_source_url_http_or_https_count"]
        == 3
    )
    assert (
        analysis[
            "analysis_validation_pack_fixture_source_url_requirement_satisfied_count"
        ]
        == 3
    )
    assert (
        analysis[
            "analysis_validation_pack_fixture_source_url_shape_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_validation_pack_fixture_known_limitations_fixture_row_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_validation_pack_fixture_known_limitations_available_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_validation_pack_fixture_known_limitations_unavailable_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_validation_pack_fixture_known_limitations_note_count_total"
        ]
        == 34
    )
    assert (
        analysis[
            "analysis_validation_pack_fixture_known_limitations_requirement_satisfied_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_validation_pack_fixture_known_limitations_matched_count"
        ]
        == 1
    )
    assert (
        "fixture_source_urls=rows=3; required=3"
        in analysis["analysis_summaries"][0]["notes"]
    )
    assert (
        "fixture_known_limitations=rows=7; available=7"
        in analysis["analysis_summaries"][0]["notes"]
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_code_consistency_code_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_code_consistency_code_total"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_code_consistency_total_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_code_consistency_unique_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_code_consistency_signature_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_code_consistency_all_have_code_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_code_consistency_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_code_summary_detail_consistency_row_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_code_summary_detail_consistency_code_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_code_summary_detail_consistency_blocker_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_code_summary_detail_consistency_kind_reference_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_code_summary_detail_consistency_label_reference_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_code_summary_detail_consistency_missing_artifact_reference_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_code_summary_detail_consistency_unique_missing_artifact_count"
        ]
        == 5
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_code_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert analysis["analysis_final_completion_blocker_kind_summary_row_count"] == 3
    assert (
        analysis["analysis_final_completion_blocker_kind_summary_blocker_count"]
        == 7
    )
    assert analysis["analysis_final_completion_blocker_kind_signed_fixture_count"] == 2
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_non_diagram_requirement_count"
        ]
        == 1
    )
    assert analysis["analysis_final_completion_blocker_kind_completion_gate_count"] == 4
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_consistency_blocker_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_consistency_kind_count"
        ]
        == 3
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_consistency_kind_total"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_consistency_total_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_consistency_unique_matched_count"
        ]
        == 1
    )
    assert (
        analysis["analysis_final_completion_blocker_kind_all_have_kind_count"]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_summary_count_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_consistency_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_row_count"
        ]
        == 3
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_kind_count"
        ]
        == 3
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_blocker_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_code_reference_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_missing_artifact_reference_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_unique_missing_artifact_count"
        ]
        == 5
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_blocker_count_matched_count"
        ]
        == 3
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_codes_matched_count"
        ]
        == 3
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_missing_artifacts_matched_count"
        ]
        == 3
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_gate_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_blocker_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_code_reference_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_missing_artifact_reference_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_unique_missing_artifact_count"
        ]
        == 5
    )
    assert (
        analysis[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_retained_evidence_reference_count"
            ]
            == 10
    )
    assert (
        analysis[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_blocker_count_matched_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_codes_matched_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_missing_artifacts_matched_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_retained_evidence_matched_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert analysis["analysis_retained_evidence_count"] == 10
    assert analysis["analysis_retained_evidence_id_count"] == 8
    assert analysis["analysis_retained_evidence_completion_claimed_count"] == 0
    assert (
        analysis[
            "analysis_retained_evidence_release_grade_speedup_claimed_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_retained_evidence_real_graphics_backend_framebuffer_verified_count"
        ]
        == 0
    )
    assert analysis["analysis_retained_evidence_screenshot_verified_count"] == 0
    assert analysis["analysis_retained_evidence_all_non_claimed_count"] == 1
    assert analysis["analysis_retained_evidence_non_claim_consistency_entry_count"] == 10
    assert (
        analysis["analysis_retained_evidence_non_claim_consistency_evidence_id_count"]
        == 8
    )
    assert (
        analysis[
            "analysis_retained_evidence_non_claim_consistency_completion_claimed_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_retained_evidence_non_claim_consistency_release_grade_speedup_claimed_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_retained_evidence_non_claim_consistency_real_backend_claimed_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_retained_evidence_non_claim_consistency_screenshot_verified_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_retained_evidence_non_claim_consistency_all_non_claimed_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_retained_evidence_non_claim_consistency_entry_top_level_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_retained_evidence_non_claim_consistency_id_top_level_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_retained_evidence_non_claim_consistency_completion_top_level_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_retained_evidence_non_claim_consistency_release_speedup_top_level_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_retained_evidence_non_claim_consistency_real_backend_top_level_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_retained_evidence_non_claim_consistency_screenshot_top_level_matched_count"
        ]
        == 1
    )
    assert (
        analysis["analysis_retained_evidence_non_claim_consistency_matched_count"]
        == 1
    )
    assert analysis["analysis_retained_evidence_artifact_file_consistency_entry_count"] == 10
    assert (
        analysis[
            "analysis_retained_evidence_artifact_file_consistency_artifact_evidence_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_retained_evidence_artifact_file_consistency_non_artifact_evidence_count"
        ]
        == 8
    )
    assert (
        analysis[
            "analysis_retained_evidence_artifact_file_consistency_file_reference_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_retained_evidence_artifact_file_consistency_unique_file_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_retained_evidence_artifact_file_consistency_raw_file_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_retained_evidence_artifact_file_consistency_analysis_file_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_retained_evidence_artifact_file_consistency_host_file_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_retained_evidence_artifact_file_consistency_complete_raw_analysis_host_group_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_retained_evidence_artifact_file_consistency_incomplete_group_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_retained_evidence_artifact_file_consistency_reference_count_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_retained_evidence_artifact_file_consistency_file_type_counts_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_retained_evidence_artifact_file_consistency_all_groups_complete_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_retained_evidence_artifact_file_consistency_all_files_unique_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_retained_evidence_artifact_file_consistency_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_linked_blocker_count"
        ]
        == 5
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_unlinked_blocker_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_reference_count"
        ]
        == 10
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_reference_count_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_link_consistency_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_label_present_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_code_present_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_missing_artifact_present_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_required_evidence_present_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_current_evidence_present_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_row_count"
        ]
        == 3
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_blocker_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_linked_count"
        ]
        == 5
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_unlinked_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_reference_count"
        ]
        == 10
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_id_count"
        ]
        == 8
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_non_claimed_link_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert analysis["analysis_final_completion_missing_artifact_reference_count"] == 7
    assert analysis["analysis_final_completion_missing_artifact_unique_count"] == 5
    assert (
        analysis[
            "analysis_final_completion_missing_artifact_summary_row_count"
        ]
        == 5
    )
    assert (
        analysis[
            "analysis_final_completion_missing_artifact_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_row_count"
        ]
        == 5
    )
    assert (
        analysis[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_unique_count"
        ]
        == 5
    )
    assert (
        analysis[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_blocker_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_code_reference_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_label_reference_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_blocker_count_matched_count"
        ]
        == 5
    )
    assert (
        analysis[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_codes_matched_count"
        ]
        == 5
    )
    assert (
        analysis[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_labels_matched_count"
        ]
        == 5
    )
    assert (
        analysis[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_field_summary_row_count"
        ]
        == 3
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_field_all_present_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_field_consistency_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_row_count"
        ]
        == 3
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_blocker_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_missing_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_required_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_current_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_all_present_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_blocker_count_matched_count"
        ]
        == 3
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_missing_matched_count"
        ]
        == 3
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_required_matched_count"
        ]
        == 3
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_current_matched_count"
        ]
        == 3
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_all_present_matched_count"
        ]
        == 3
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_gate_blocker_consistency_checked_gate_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_gate_blocker_consistency_mismatched_gate_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_final_completion_gate_blocker_count_matched_gate_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_gate_blocker_codes_matched_gate_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_gate_blocker_consistency_matched_count"
        ]
        == 1
    )
    assert analysis["analysis_final_completion_required_check_count"] == 3
    assert analysis["analysis_final_completion_required_check_passed_count"] == 1
    assert analysis["analysis_final_completion_required_check_failed_count"] == 2
    assert analysis["analysis_final_completion_required_check_mismatched_count"] == 2
    assert (
        analysis[
            "analysis_final_completion_required_check_final_ready_matched_count"
        ]
        == 1
    )
    assert (
        analysis["analysis_final_completion_required_check_all_matched_count"]
        == 0
    )
    assert (
        analysis[
            "analysis_final_completion_required_check_consistency_matched_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_required_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_registered_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_missing_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_metadata_complete_count"
        ]
        == 7
    )
    assert (
        analysis[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_metadata_incomplete_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_metadata_blocker_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_gate_passed_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_gate_blocker_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_signed_fixture_consistency_blocker_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_final_completion_signed_fixture_consistency_final_blocker_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_final_completion_signed_fixture_consistency_unsigned_non_claim_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_final_completion_signed_fixture_consistency_source_table_metadata_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_final_completion_signed_fixture_consistency_source_candidate_evidence_available_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_final_completion_signed_fixture_consistency_source_candidate_not_unique_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_final_completion_signed_fixture_consistency_source_candidate_replay_all_valid_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_final_completion_signed_fixture_consistency_source_candidate_matching_candidate_count_total"
        ]
        == 32
    )
    assert (
        analysis[
            "analysis_final_completion_signed_fixture_consistency_source_candidate_unique_sign_pattern_count_total"
        ]
        == 20
    )
    assert (
        analysis[
            "analysis_final_completion_signed_fixture_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_final_completion_signed_fixture_consistency_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_non_diagram_requirement_consistency_requirement_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_final_completion_non_diagram_requirement_consistency_open_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_non_diagram_requirement_consistency_blocker_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_non_diagram_requirement_consistency_retained_evidence_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_final_completion_non_diagram_requirement_consistency_retained_evidence_id_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_final_completion_non_diagram_requirement_consistency_retained_evidence_reference_top_level_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_non_diagram_requirement_consistency_retained_evidence_id_top_level_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_non_diagram_requirement_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_final_completion_non_diagram_requirement_consistency_matched_count"
        ]
        == 1
    )
    assert analysis["analysis_final_completion_non_claim_gate_count"] == 4
    assert (
        analysis["analysis_final_completion_non_claim_gate_top_level_false_count"]
        == 4
    )
    assert (
        analysis["analysis_final_completion_non_claim_gate_check_failed_count"]
        == 4
    )
    assert analysis["analysis_final_completion_non_claim_gate_blocker_count"] == 4
    assert (
        analysis["analysis_final_completion_non_claim_gate_code_matched_count"]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_non_claim_gate_missing_artifact_matched_count"
        ]
        == 4
    )
    assert (
        analysis["analysis_final_completion_non_claim_gate_matched_gate_count"]
        == 4
    )
    assert analysis["analysis_final_completion_non_claim_gate_all_false_count"] == 1
    assert (
        analysis[
            "analysis_final_completion_non_claim_gate_all_blockers_present_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_non_claim_gate_consistency_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_final_completion_non_claim_gate_consistency_field_count"
        ]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_non_claim_gate_consistency_false_count"
        ]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_non_claim_gate_consistency_gate_count"
        ]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_non_claim_gate_consistency_blocker_count"
        ]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_non_claim_gate_consistency_missing_artifact_count"
        ]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_non_claim_gate_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_gate_count"
        ]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_gate_check_count"
        ]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_blocker_count"
        ]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_failed_gate_count"
        ]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_top_level_false_count"
        ]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_code_matched_count"
        ]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_required_evidence_matched_count"
        ]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_current_evidence_matched_count"
        ]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_missing_artifact_matched_count"
        ]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_missing_artifact_id_matched_count"
        ]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_retained_evidence_count"
        ]
        == 8
    )
    assert (
        analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_retained_evidence_id_count"
        ]
        == 8
    )
    assert (
        analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_retained_evidence_ids_matched_count"
        ]
        == 4
    )
    assert (
        analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_mismatched_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_matched_count"
        ]
        == 1
    )
    summary = analysis["analysis_summaries"][0]
    assert summary["source_method"] == "cross_workstream_validation_pack_audit"
    assert summary["required_check_count"] == 3
    assert summary["passed_check_count"] == 1
    assert summary["failed_check_count"] == 2
    assert summary["final_completion_ready"] is False
    assert summary["unsigned_required_fixture_count"] == 2
    assert summary["open_non_diagram_requirement_count"] == 1
    assert summary["final_completion_gate_count"] == 7
    assert summary["final_completion_failed_gate_count"] == 6
    assert summary["final_completion_blocker_count"] == 7
    assert (
        summary[
            "final_completion_blocker_completion_evidence_artifact_filename_reference_count"
        ]
        == 9
    )
    assert (
        summary[
            "final_completion_blocker_completion_evidence_artifact_filename_unique_count"
        ]
        == 6
    )
    assert (
        summary[
            "final_completion_failed_gate_completion_evidence_artifact_filename_reference_count"
        ]
        == 7
    )
    assert (
        summary[
            "final_completion_failed_gate_completion_evidence_artifact_filename_unique_count"
        ]
        == 6
    )
    assert "final_blockers=7" in summary["notes"]
    assert "signed_pd_not_registered:2" in summary["notes"]
    assert "missing_artifacts=" in summary["notes"]
    assert "production_imgui_renderer_framebuffer_pack" in summary["notes"]
    assert "signed_release_publication_manifest" in summary["notes"]
    assert "completion_evidence_targets=" in summary["notes"]
    assert (
        "L5a1{files=verified_signed_crossing_assignment.L5a1.json,"
        "verified_signed_crossing_assignment.L6a4.json}"
        in summary["notes"]
    )
    assert "signed_release_publication_manifest.json" in summary["notes"]
    assert "open_evidence=" in summary["notes"]
    assert "L5a1{missing_artifact=verified_signed_crossing_assignment" in summary[
        "notes"
    ]
    assert "fixture remains unsigned and unregistered" in summary["notes"]
    assert "repository test-stub framebuffer" in summary["notes"]
    assert "retained_evidence=" in summary["notes"]
    assert "numpy_benchmark_matrix_local_profiling" not in summary["notes"]
    assert "imgui_test_stub_framebuffer_smoke_retained_pack" in summary["notes"]
    assert "completion_claimed=false" in summary["notes"]
    assert (
        "retained_evidence_kinds=ci_retained_artifact:6|repository_test:4"
        in summary["notes"]
    )
    assert "retained_evidence_consistency=entries=10; ids=8" in summary["notes"]
    assert "all_non_claimed=true" in summary["notes"]
    assert "retained_evidence_non_claim=entries=10; ids=8" in summary["notes"]
    assert "completion=0; release_speedup=0" in summary["notes"]
    assert "real_backend=0; screenshot=0; matched=true" in summary["notes"]
    assert (
        "retained_evidence_artifact_files=entries=10; artifact_entries=2"
        in summary["notes"]
    )
    assert "non_artifact=8; refs=6; unique=6" in summary["notes"]
    assert "raw=2; analysis=2; host=2" in summary["notes"]
    assert "complete_groups=2; incomplete_groups=0" in summary["notes"]
    assert "file_types_matched=true; groups_complete=true" in summary["notes"]
    assert "blocker_code_consistency=codes=6; total=7" in summary["notes"]
    assert "signature_matched=true; all_have_code=true" in summary["notes"]
    assert "blocker_code_summary_detail=rows=6; codes=6" in summary["notes"]
    assert "blockers=7; kinds=6; labels=7" in summary["notes"]
    assert "missing_refs=6; unique_missing=5" in summary["notes"]
    assert "kinds_matched=6; labels_matched=6" in summary["notes"]
    assert "blocker_kind_consistency=kinds=3; total=7" in summary["notes"]
    assert "signed=2; non_diagram=1; completion=4" in summary["notes"]
    assert "blocker_kind_summary_detail=rows=3; kinds=3" in summary["notes"]
    assert "blockers=7; codes=6; missing_refs=6; unique_missing=5" in summary[
        "notes"
    ]
    assert "count_matched=3; codes_matched=3" in summary["notes"]
    assert "missing_artifacts_matched=3; mismatched=0" in summary["notes"]
    assert "open_gate_blocker_summary=failed_gates=6; summary_gates=6" in summary[
        "notes"
    ]
    assert "blockers=7; summary_blockers=7" in summary["notes"]
    assert "gate_sets_matched=true" in summary["notes"]
    assert "blocker_count_matched=true" in summary["notes"]
    assert "all_blockers_have_gate=true" in summary["notes"]
    assert (
        "open_gate_blocker_summary_detail=gates=6; blockers=7"
        in summary["notes"]
    )
    assert "codes=6; missing_refs=6; unique_missing=5" in summary["notes"]
    assert "retained=10; count_matched=6" in summary["notes"]
    assert "missing_artifacts_matched=6; retained_matched=6" in summary["notes"]
    assert "blocker_evidence_links=linked=5; unlinked=2" in summary["notes"]
    assert "labels=7; codes=7; missing=7; required=7; current=7" in summary[
        "notes"
    ]
    assert "evidence_refs=10" in summary["notes"]
    assert "refs_matched=true" in summary["notes"]
    assert "ids_matched=true" in summary["notes"]
    assert "non_claim_matched=true" in summary["notes"]
    assert (
        "blocker_evidence_link_kind_detail=rows=3; blockers=7"
        in summary["notes"]
    )
    assert "linked=5; unlinked=2; refs=10; ids=8" in summary["notes"]
    assert "non_claimed_links=7; blocker_matched=3" in summary["notes"]
    assert "non_claim_matched=3; mismatched=0; matched=true" in summary["notes"]
    assert "gate_blocker_consistency=checked=7" in summary["notes"]
    assert "count_matched=7; codes_matched=7; mismatched=0" in summary["notes"]
    assert "required_check_consistency=required=3; passed=1" in summary[
        "notes"
    ]
    assert "failed=2; mismatched=2" in summary["notes"]
    assert "final_ready_matched=true" in summary["notes"]
    assert "all_matched=false; matched=false" in summary["notes"]
    assert (
        "required_fixture_metadata_consistency=required=7; registered=7"
        in summary["notes"]
    )
    assert "missing=0; metadata_complete=7" in summary["notes"]
    assert (
        "metadata_incomplete=0; blockers=0; gate_passed=true"
        in summary["notes"]
    )
    assert "signed_fixture_consistency=blockers=2; final_blockers=2" in summary[
        "notes"
    ]
    assert "unsigned_non_claims=2; source_table_metadata=2" in summary["notes"]
    assert "source_candidate_matches=32" in summary["notes"]
    assert "source_candidate_unique_signs=20" in summary["notes"]
    assert (
        "non_diagram_requirement_consistency=requirements=6; open=1"
        in summary["notes"]
    )
    assert "blockers=1; evidence_refs=2" in summary["notes"]
    assert "evidence_ids=2" in summary["notes"]
    assert "refs_top_level_matched=true" in summary["notes"]
    assert "ids_top_level_matched=true" in summary["notes"]
    assert "evidence_fields_matched=1" in summary["notes"]
    assert "mismatched=0" in summary["notes"]
    assert "non_claim_gate_consistency=fields=4; false=4" in summary[
        "notes"
    ]
    assert "gates=4; blockers=4; missing_artifacts=4" in summary["notes"]
    assert (
        "completion_gate_evidence_consistency=gates=4; gate_checks=4"
        in summary["notes"]
    )
    assert "blockers=4; failed=4; false=4; codes=4" in summary["notes"]
    assert (
        "required=4; current=4; missing_artifacts=4; missing_artifact_ids=4; retained_evidence=8; retained_evidence_ids=8; retained_evidence_matched=4; mismatched=0"
        in summary["notes"]
    )
    assert "missing_artifact_summary=refs=7; unique=5; rows=5" in summary[
        "notes"
    ]
    assert "rows_matched=true" in summary["notes"]
    assert (
        "missing_artifact_summary_detail=rows=5; unique=5; blockers=7"
        in summary["notes"]
    )
    assert "codes=6; labels=7; count_matched=5" in summary["notes"]
    assert "codes_matched=5; labels_matched=5; mismatched=0" in summary[
        "notes"
    ]
    assert "blocker_evidence_fields=summary_rows=3" in summary["notes"]
    assert "missing_artifact=7; required=7; current=7; all_present=7" in summary[
        "notes"
    ]
    assert (
        "blocker_evidence_field_summary_detail=rows=3; blockers=7"
        in summary["notes"]
    )
    assert "missing_artifact=7; required=7; current=7; all_present=7" in summary[
        "notes"
    ]
    assert "count_matched=3; missing_matched=3" in summary["notes"]
    assert "required_matched=3; current_matched=3" in summary["notes"]
    assert "all_present_matched=3; mismatched=0" in summary["notes"]
    assert "validation_pack=fixtures=7/7" in summary["notes"]
    assert host_exit == 0
    assert host["method"] == "imgui_host_payload"
    host_analysis = host["analysis"]
    assert host_analysis["analysis_summary_count"] == 3
    assert host_analysis["analysis_validation_pack_audit_available_count"] == 1
    assert host_analysis["analysis_required_diagram_fixture_count"] == 7
    assert host_analysis["analysis_unsigned_required_fixture_count"] == 2
    assert host_analysis["analysis_open_non_diagram_requirement_count"] == 1
    assert host_analysis["analysis_final_completion_gate_count"] == 7
    assert host_analysis["analysis_final_completion_failed_gate_count"] == 6
    assert host_analysis["analysis_final_completion_blocker_count"] == 7
    assert host_analysis["analysis_final_completion_ready_count"] == 0
    assert (
        host_analysis[
            "analysis_final_completion_blocker_completion_evidence_artifact_filename_reference_count"
        ]
        == 9
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_completion_evidence_artifact_filename_unique_count"
        ]
        == 6
    )
    assert (
        host_analysis[
            "analysis_final_completion_failed_gate_completion_evidence_artifact_filename_reference_count"
        ]
        == 7
    )
    assert (
        host_analysis[
            "analysis_final_completion_failed_gate_completion_evidence_artifact_filename_unique_count"
        ]
        == 6
    )
    assert (
        host_analysis[
            "analysis_validation_pack_fixture_source_url_fixture_row_count"
        ]
        == 7
    )
    assert host_analysis["analysis_validation_pack_fixture_source_url_row_count"] == 3
    assert (
        host_analysis[
            "analysis_validation_pack_fixture_source_url_http_or_https_count"
        ]
        == 3
    )
    assert (
        host_analysis[
            "analysis_validation_pack_fixture_source_url_requirement_satisfied_count"
        ]
        == 3
    )
    assert (
        host_analysis[
            "analysis_validation_pack_fixture_source_url_shape_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_validation_pack_fixture_known_limitations_fixture_row_count"
        ]
        == 7
    )
    assert (
        host_analysis[
            "analysis_validation_pack_fixture_known_limitations_available_count"
        ]
        == 7
    )
    assert (
        host_analysis[
            "analysis_validation_pack_fixture_known_limitations_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_code_consistency_code_total"
        ]
        == 7
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_code_consistency_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_code_summary_detail_consistency_row_count"
        ]
        == 6
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_code_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_kind_consistency_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_row_count"
        ]
        == 3
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_kind_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_gate_count"
        ]
        == 6
    )
    assert (
        host_analysis[
            "analysis_final_completion_open_gate_blocker_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert host_analysis["analysis_retained_evidence_count"] == 10
    assert host_analysis["analysis_retained_evidence_all_non_claimed_count"] == 1
    assert (
        host_analysis[
            "analysis_retained_evidence_non_claim_consistency_entry_count"
        ]
        == 10
    )
    assert (
        host_analysis[
            "analysis_retained_evidence_non_claim_consistency_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_retained_evidence_artifact_file_consistency_file_reference_count"
        ]
        == 6
    )
    assert (
        host_analysis[
            "analysis_retained_evidence_artifact_file_consistency_complete_raw_analysis_host_group_count"
        ]
        == 2
    )
    assert (
        host_analysis[
            "analysis_retained_evidence_artifact_file_consistency_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_evidence_reference_count"
        ]
        == 10
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_evidence_link_consistency_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_evidence_label_present_count"
        ]
        == 7
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_evidence_current_evidence_present_count"
        ]
        == 7
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_row_count"
        ]
        == 3
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_evidence_link_kind_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert host_analysis[
        "analysis_final_completion_missing_artifact_summary_consistency_matched_count"
    ] == 1
    assert (
        host_analysis[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_row_count"
        ]
        == 5
    )
    assert (
        host_analysis[
            "analysis_final_completion_missing_artifact_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_evidence_field_consistency_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_row_count"
        ]
        == 3
    )
    assert (
        host_analysis[
            "analysis_final_completion_blocker_evidence_field_summary_detail_consistency_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_final_completion_gate_blocker_consistency_checked_gate_count"
        ]
        == 7
    )
    assert (
        host_analysis[
            "analysis_final_completion_gate_blocker_consistency_matched_count"
        ]
        == 1
    )
    assert host_analysis["analysis_final_completion_required_check_count"] == 3
    assert (
        host_analysis[
            "analysis_final_completion_required_check_consistency_matched_count"
        ]
        == 0
    )
    assert (
        host_analysis[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_required_count"
        ]
        == 7
    )
    assert (
        host_analysis[
            "analysis_final_completion_required_diagram_fixture_metadata_consistency_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_final_completion_signed_fixture_consistency_blocker_count"
        ]
        == 2
    )
    assert (
        host_analysis[
            "analysis_final_completion_signed_fixture_consistency_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_final_completion_signed_fixture_consistency_source_candidate_matching_candidate_count_total"
        ]
        == 32
    )
    assert (
        host_analysis[
            "analysis_final_completion_signed_fixture_consistency_source_candidate_unique_sign_pattern_count_total"
        ]
        == 20
    )
    assert (
        host_analysis[
            "analysis_final_completion_non_diagram_requirement_consistency_open_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_final_completion_non_diagram_requirement_consistency_matched_count"
        ]
        == 1
    )
    assert host_analysis["analysis_final_completion_non_claim_gate_count"] == 4
    assert (
        host_analysis[
            "analysis_final_completion_non_claim_gate_consistency_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_gate_count"
        ]
        == 4
    )
    assert (
        host_analysis[
            "analysis_final_completion_completion_gate_evidence_consistency_matched_count"
        ]
        == 1
    )
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    host_summary = host_summaries["cross_workstream_validation_pack_audit"]
    assert host_summary["required_check_count"] == 3
    assert host_summary["passed_check_count"] == 1
    assert host_summary["failed_check_count"] == 2
    assert host_summary["final_completion_ready"] is False
    assert host_summary["unsigned_required_fixture_count"] == 2
    assert host_summary["open_non_diagram_requirement_count"] == 1
    assert host_summary["final_completion_blocker_count"] == 7
    assert "production_imgui_renderer_framebuffer_pack" in host_summary["notes"]
    assert "signed_release_publication_manifest" in host_summary["notes"]
    assert "completion_evidence_targets=" in host_summary["notes"]
    assert "verified_signed_crossing_assignment.L6a4.json" in host_summary["notes"]
    assert "open_evidence=" in host_summary["notes"]
    assert "L5a1{missing_artifact=verified_signed_crossing_assignment" in host_summary[
        "notes"
    ]
    assert "fixture remains unsigned and unregistered" in host_summary["notes"]
    assert "repository test-stub framebuffer" in host_summary["notes"]
    assert "retained_evidence=" in host_summary["notes"]
    assert "numpy_benchmark_matrix_local_profiling" not in host_summary["notes"]
    assert "imgui_test_stub_framebuffer_smoke_retained_pack" in host_summary[
        "notes"
    ]
    assert "completion_claimed=false" in host_summary["notes"]
    assert (
        "retained_evidence_kinds=ci_retained_artifact:6|repository_test:4"
        in host_summary["notes"]
    )
    assert "retained_evidence_consistency=entries=10; ids=8" in host_summary[
        "notes"
    ]
    assert "all_non_claimed=true" in host_summary["notes"]
    assert (
        "retained_evidence_artifact_files=entries=10; artifact_entries=2"
        in host_summary["notes"]
    )
    assert "complete_groups=2; incomplete_groups=0" in host_summary["notes"]
    assert "blocker_code_consistency=codes=6; total=7" in host_summary["notes"]
    assert "signature_matched=true; all_have_code=true" in host_summary["notes"]
    assert "blocker_code_summary_detail=rows=6; codes=6" in host_summary["notes"]
    assert "blocker_kind_consistency=kinds=3; total=7" in host_summary["notes"]
    assert "signed=2; non_diagram=1; completion=4" in host_summary["notes"]
    assert "blocker_kind_summary_detail=rows=3; kinds=3" in host_summary["notes"]
    assert "open_gate_blocker_summary=failed_gates=6; summary_gates=6" in host_summary[
        "notes"
    ]
    assert (
        "open_gate_blocker_summary_detail=gates=6; blockers=7"
        in host_summary["notes"]
    )
    assert "blocker_count_matched=true" in host_summary["notes"]
    assert "blocker_evidence_links=linked=5; unlinked=2" in host_summary[
        "notes"
    ]
    assert "labels=7; codes=7; missing=7; required=7; current=7" in host_summary[
        "notes"
    ]
    assert "blocker_evidence_link_kind_detail=rows=3; blockers=7" in host_summary[
        "notes"
    ]
    assert "matched=true" in host_summary["notes"]
    assert "gate_blocker_consistency=checked=7" in host_summary["notes"]
    assert "count_matched=7; codes_matched=7; mismatched=0" in host_summary[
        "notes"
    ]
    assert "required_check_consistency=required=3; passed=1" in host_summary[
        "notes"
    ]
    assert "signed_fixture_consistency=blockers=2; final_blockers=2" in host_summary[
        "notes"
    ]
    assert "source_candidate_matches=32" in host_summary["notes"]
    assert "source_candidate_unique_signs=20" in host_summary["notes"]
    assert (
        "non_diagram_requirement_consistency=requirements=6; open=1"
        in host_summary["notes"]
    )
    assert "non_claim_gate_consistency=fields=4; false=4" in host_summary[
        "notes"
    ]
    assert "missing_artifact_summary=refs=7; unique=5; rows=5" in host_summary[
        "notes"
    ]
    assert "blocker_evidence_fields=summary_rows=3" in host_summary["notes"]
    assert host["fixture_comparisons"]["fixture_comparison_count"] > 0
    assert host["signed_pd"]["signed_pd_diagram_count"] > 0
    assert host["invariants"]["invariant_status_count"] == 2


def test_cli_fixture_validation_pack_audit_can_fail_ci_when_not_ready(capsys) -> None:
    exit_code = main(["fixture-validation-pack-audit", "--fail-on-not-ready"])
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert "_exit_code" not in payload
    assert payload["ci_fail_on_not_ready"] is True
    assert payload["ci_exit_code"] == 1
    assert payload["final_completion_ready"] is False
    assert payload["final_completion_blocker_count"] == 7


def test_cli_fixture_validation_pack_audit_accepts_production_imgui_pack(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        pack_path = tmp_path / "production-framebuffer-pack.json"
        _write_imgui_production_framebuffer_pack(pack_path)

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--production-imgui-renderer-framebuffer-pack-json",
                str(pack_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["production_imgui_renderer_verified"] is True
    assert payload["open_non_diagram_requirement_count"] == 0
    assert payload["final_completion_blocker_count"] == 5
    assert payload["final_completion_blocker_code_counts"] == {
        "signed_pd_not_registered": 2,
        "full_homfly_pt_evaluation_not_certified": 1,
        "full_multivariable_alexander_normalization_not_certified": 1,
        "release_artifacts_not_published": 1,
    }
    requirements = {
        row["requirement"]: row for row in payload["non_diagram_requirements"]
    }
    native_row = requirements["native ImGui screenshot/framebuffer fixtures"]
    assert native_row["status"] == "available"
    assert native_row["certification_artifact"] == (
        "production_imgui_renderer_framebuffer_pack"
    )
    assert native_row["certification_evidence"][0]["certified"] is True
    gate_checks = {row["gate"]: row for row in payload["final_completion_gate_checks"]}
    assert gate_checks["production_imgui_renderer"]["passed"] is True
    assert gate_checks["non_diagram_requirements"]["passed"] is True


def test_cli_fixture_validation_pack_audit_accepts_signed_release_manifest(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        manifest_path = tmp_path / "signed-release-publication-manifest.json"
        _write_signed_release_publication_manifest(manifest_path)

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--signed-release-publication-manifest-json",
                str(manifest_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["release_artifacts_published"] is True
    assert payload["final_completion_blocker_count"] == 6
    assert payload["final_completion_blocker_code_counts"] == {
        "signed_pd_not_registered": 2,
        "native_imgui_screenshot_framebuffer_fixtures_partial": 1,
        "full_homfly_pt_evaluation_not_certified": 1,
        "full_multivariable_alexander_normalization_not_certified": 1,
        "production_imgui_renderer_not_verified": 1,
    }
    gate_checks = {row["gate"]: row for row in payload["final_completion_gate_checks"]}
    assert gate_checks["release_artifacts"]["passed"] is True
    assert gate_checks["release_artifacts"]["retained_evidence"][0][
        "evidence_id"
    ] == "signed_release_publication_manifest"


def test_cli_fixture_validation_pack_audit_accepts_full_invariant_packs(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        homfly_path = tmp_path / "full-homfly-certification-pack.json"
        alexander_path = tmp_path / "full-alexander-certification-pack.json"
        _write_full_homfly_certification_pack(homfly_path)
        _write_full_alexander_certification_pack(alexander_path)

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--full-homfly-pt-evaluation-certification-pack-json",
                str(homfly_path),
                "--full-multivariable-alexander-normalization-certification-pack-json",
                str(alexander_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["full_homfly_pt_evaluation_certified"] is True
    assert (
        payload["full_multivariable_alexander_normalization_certified"] is True
    )
    assert payload["final_completion_blocker_count"] == 5
    assert payload["final_completion_blocker_code_counts"] == {
        "signed_pd_not_registered": 2,
        "native_imgui_screenshot_framebuffer_fixtures_partial": 1,
        "production_imgui_renderer_not_verified": 1,
        "release_artifacts_not_published": 1,
    }
    gate_checks = {row["gate"]: row for row in payload["final_completion_gate_checks"]}
    assert gate_checks["full_homfly_pt_evaluation"]["passed"] is True
    assert gate_checks["full_multivariable_alexander_normalization"]["passed"] is True
    assert gate_checks["full_homfly_pt_evaluation"]["retained_evidence"][0][
        "evidence_id"
    ] == "full_homfly_pt_evaluation_certification_pack"
    assert gate_checks["full_multivariable_alexander_normalization"][
        "retained_evidence"
    ][0]["evidence_id"] == (
        "full_multivariable_alexander_normalization_certification_pack"
    )


def test_cli_fixture_validation_pack_audit_accepts_verified_signed_assignments(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        l5_path = tmp_path / "l5a1-signed-assignment.json"
        l6_path = tmp_path / "l6a4-signed-assignment.json"
        _write_verified_signed_crossing_assignment(
            l5_path,
            notation="L5a1",
            crossing_count=5,
        )
        _write_verified_signed_crossing_assignment(
            l6_path,
            notation="L6a4",
            crossing_count=6,
        )

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--verified-signed-crossing-assignment-json",
                str(l5_path),
                "--verified-signed-crossing-assignment-json",
                str(l6_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["signed_diagram_fixture_registration_complete"] is True
    assert payload["unsigned_required_fixture_count"] == 0
    assert payload["signed_fixture_blockers"] == []
    assert payload["final_completion_blocker_count"] == 5
    assert "signed_pd_not_registered" not in payload[
        "final_completion_blocker_code_counts"
    ]
    rows = {row["notation"]: row for row in payload["fixtures"]}
    assert rows["L5a1"]["has_signed_pd"] is True
    assert rows["L6a4"]["verified_signed_crossing_assignment_available"] is True
    gate_checks = {row["gate"]: row for row in payload["final_completion_gate_checks"]}
    assert gate_checks["signed_diagram_fixture_registration"]["passed"] is True


def test_cli_fixture_validation_pack_audit_rejects_duplicate_verified_assignment_notation(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        l5_path = tmp_path / "l5a1-signed-assignment.json"
        l5_duplicate_path = tmp_path / "l5a1-signed-assignment-duplicate.json"
        l6_path = tmp_path / "l6a4-signed-assignment.json"
        _write_verified_signed_crossing_assignment(
            l5_path,
            notation="L5a1",
            crossing_count=5,
        )
        _write_verified_signed_crossing_assignment(
            l5_duplicate_path,
            notation="L5a1",
            crossing_count=5,
        )
        _write_verified_signed_crossing_assignment(
            l6_path,
            notation="L6a4",
            crossing_count=6,
        )

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--verified-signed-crossing-assignment-json",
                str(l5_path),
                "--verified-signed-crossing-assignment-json",
                str(l5_duplicate_path),
                "--verified-signed-crossing-assignment-json",
                str(l6_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["signed_diagram_fixture_registration_complete"] is False
    assert payload["verified_signed_assignment_input_count"] == 3
    assert payload["verified_signed_assignment_notation_counts"]["L5a1"] == 2
    assert payload["duplicate_verified_signed_assignment_notations"] == ["L5a1"]
    assert payload["unexpected_verified_signed_assignment_notations"] == []
    assert payload["final_completion_blocker_code_counts"][
        "verified_signed_crossing_assignment_duplicate"
    ] == 1
    gate_checks = {row["gate"]: row for row in payload["final_completion_gate_checks"]}
    assert gate_checks["signed_diagram_fixture_registration"]["passed"] is False
    assert "verified_signed_crossing_assignment_duplicate" in gate_checks[
        "signed_diagram_fixture_registration"
    ]["blocker_codes"]


def test_cli_fixture_validation_pack_audit_rejects_unexpected_verified_assignment_notation(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        l5_path = tmp_path / "l5a1-signed-assignment.json"
        l6_path = tmp_path / "l6a4-signed-assignment.json"
        unexpected_path = tmp_path / "unexpected-signed-assignment.json"
        _write_verified_signed_crossing_assignment(
            l5_path,
            notation="L5a1",
            crossing_count=5,
        )
        _write_verified_signed_crossing_assignment(
            l6_path,
            notation="L6a4",
            crossing_count=6,
        )
        _write_verified_signed_crossing_assignment(
            unexpected_path,
            notation="L7a1",
            crossing_count=7,
        )

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--verified-signed-crossing-assignment-json",
                str(l5_path),
                "--verified-signed-crossing-assignment-json",
                str(l6_path),
                "--verified-signed-crossing-assignment-json",
                str(unexpected_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["signed_diagram_fixture_registration_complete"] is False
    assert payload["verified_signed_assignment_input_count"] == 3
    assert payload["duplicate_verified_signed_assignment_notations"] == []
    assert payload["unexpected_verified_signed_assignment_notations"] == ["L7a1"]
    assert payload["final_completion_blocker_code_counts"][
        "verified_signed_crossing_assignment_unexpected_notation"
    ] == 1
    gate_checks = {row["gate"]: row for row in payload["final_completion_gate_checks"]}
    assert gate_checks["signed_diagram_fixture_registration"]["passed"] is False
    assert "verified_signed_crossing_assignment_unexpected_notation" in gate_checks[
        "signed_diagram_fixture_registration"
    ]["blocker_codes"]


def test_cli_fixture_validation_pack_audit_rejects_missing_verified_assignment_notation(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        l5_path = tmp_path / "l5a1-signed-assignment.json"
        l6_path = tmp_path / "l6a4-signed-assignment.json"
        malformed_path = tmp_path / "missing-notation-signed-assignment.json"
        _write_verified_signed_crossing_assignment(
            l5_path,
            notation="L5a1",
            crossing_count=5,
        )
        _write_verified_signed_crossing_assignment(
            l6_path,
            notation="L6a4",
            crossing_count=6,
        )
        _write_verified_signed_crossing_assignment(
            malformed_path,
            notation="L5a1",
            crossing_count=5,
        )
        malformed_payload = json.loads(malformed_path.read_text(encoding="utf-8"))
        malformed_payload.pop("notation")
        malformed_path.write_text(json.dumps(malformed_payload), encoding="utf-8")

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--verified-signed-crossing-assignment-json",
                str(l5_path),
                "--verified-signed-crossing-assignment-json",
                str(l6_path),
                "--verified-signed-crossing-assignment-json",
                str(malformed_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["signed_diagram_fixture_registration_complete"] is False
    assert payload["verified_signed_assignment_input_count"] == 3
    assert payload["missing_notation_verified_signed_assignment_count"] == 1
    assert payload["duplicate_verified_signed_assignment_notations"] == []
    assert payload["unexpected_verified_signed_assignment_notations"] == []
    assert payload["final_completion_blocker_code_counts"][
        "verified_signed_crossing_assignment_missing_notation"
    ] == 1
    gate_checks = {row["gate"]: row for row in payload["final_completion_gate_checks"]}
    assert gate_checks["signed_diagram_fixture_registration"]["passed"] is False
    assert "verified_signed_crossing_assignment_missing_notation" in gate_checks[
        "signed_diagram_fixture_registration"
    ]["blocker_codes"]


def test_cli_fixture_validation_pack_audit_accepts_completion_evidence_bundle(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        bundle_path = tmp_path / "completion-evidence-bundle.json"
        _write_completion_evidence_bundle(bundle_path)

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--completion-evidence-bundle-json",
                str(bundle_path),
                "--fail-on-not-ready",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["ci_fail_on_not_ready"] is True
    assert payload["ci_exit_code"] == 0
    assert payload["completion_evidence_bundle_available"] is True
    assert payload["completion_evidence_bundle_certified"] is True
    bundle_evidence = payload["completion_evidence_bundle"]
    assert bundle_evidence["bundle_evidence_failed_check_count"] == 0
    assert bundle_evidence["bundle_evidence_failed_checks"] == []
    assert bundle_evidence["bundle_evidence_failed_check_signature"] == ""
    assert bundle_evidence["expected_artifact_preflight_row_count"] == 6
    assert bundle_evidence["expected_bundle_preflight_row_count_source"] == (
        "present_bundle_assignment_count_plus_single_artifacts"
    )
    assert (
        bundle_evidence[
            "expected_evidence_filename_count_matches_artifact_preflight_row_count"
        ]
        is True
    )
    assert bundle_evidence["artifact_preflight_row_count"] == 6
    assert bundle_evidence["artifact_preflight_failed_count"] == 0
    bundle_preflight_rows = {
        (row["artifact_type"], row["artifact_index"]): row
        for row in bundle_evidence["artifact_preflight_rows"]
    }
    assert bundle_preflight_rows[
        ("verified_signed_crossing_assignment", 0)
    ]["completion_evidence_artifact_filenames"] == [
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert bundle_preflight_rows[
        ("signed_release_publication_manifest", None)
    ]["completion_evidence_artifact_filenames"] == [
        "signed_release_publication_manifest.json"
    ]
    assert bundle_evidence["artifact_preflight_field_coverage_failed_count"] == 0
    assert bundle_evidence["artifact_preflight_field_coverage_failed_rows"] == []
    assert bundle_evidence["artifact_preflight_field_coverage_complete"] is True
    assert bundle_evidence["missing_artifact_fields_by_bundle_key"] == {}
    assert bundle_evidence["all_bundle_artifacts_certified"] is True
    coverage = bundle_evidence["bundle_contract_coverage"]
    assert bundle_evidence["bundle_contract_coverage_complete"] is True
    assert coverage["coverage_complete"] is True
    assert coverage["preflight_artifact_row_count"] == 6
    assert coverage["expected_artifact_type_count"] == 5
    assert coverage["missing_artifact_types"] == []
    assert coverage["unexpected_artifact_types"] == []
    assert coverage["signed_assignment_preflight_count"] == 2
    assert coverage["required_signed_assignment_count"] == 2
    assert coverage["signed_assignment_count_matches_required"] is True
    assert bundle_evidence["invalid_bundle_non_claim_fields"] == []
    assert bundle_evidence["bundle_completion_claimed"] is False
    assert bundle_evidence["bundle_certified_by_audit"] is False
    assert bundle_evidence["required_signed_assignment_notations"] == [
        "L5a1",
        "L6a4",
    ]
    assert bundle_evidence["present_signed_assignment_notations"] == [
        "L5a1",
        "L6a4",
    ]
    assert bundle_evidence["missing_signed_assignment_notations"] == []
    assert payload["final_completion_ready"] is True
    assert payload["final_completion_blocker_count"] == 0
    assert payload["final_completion_blocker_code_counts"] == {}
    assert payload["full_homfly_pt_evaluation_certified"] is True
    assert (
        payload["full_multivariable_alexander_normalization_certified"] is True
    )
    assert payload["production_imgui_renderer_verified"] is True
    assert payload["release_artifacts_published"] is True
    rows = {row["notation"]: row for row in payload["fixtures"]}
    assert rows["L5a1"]["registration_status"] == (
        "verified_signed_crossing_assignment_pack"
    )
    assert rows["L6a4"]["verified_signed_crossing_assignment_available"] is True


def test_cli_fixture_validation_pack_audit_summarizes_bundle_missing_artifact_fields(
    capsys,
) -> None:
    bundle = _completion_evidence_bundle_payload()
    bundle["signed_release_publication_manifest"]["signature_urls"] = []
    with workspace_tempdir() as tmp_path:
        bundle_path = tmp_path / "completion-evidence-bundle-missing-field.json"
        bundle_path.write_text(json.dumps(bundle), encoding="utf-8")

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--completion-evidence-bundle-json",
                str(bundle_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["completion_evidence_bundle_certified"] is False
    bundle_evidence = payload["completion_evidence_bundle"]
    assert bundle_evidence["bundle_evidence_failed_check_count"] == 1
    assert bundle_evidence["bundle_evidence_failed_checks"] == [
        "all_bundle_artifacts_certified",
    ]
    assert bundle_evidence["bundle_evidence_failed_check_signature"] == (
        "all_bundle_artifacts_certified"
    )
    assert bundle_evidence["artifact_preflight_failed_count"] == 1
    assert bundle_evidence["artifact_preflight_field_coverage_failed_count"] == 1
    assert bundle_evidence["artifact_preflight_field_coverage_complete"] is False
    assert bundle_evidence["missing_artifact_fields_by_bundle_key"] == {
        "signed_release_publication_manifest": [
            {
                "artifact_type": "signed_release_publication_manifest",
                "artifact_index": None,
                "missing_artifact_fields": ["signature_urls"],
            }
        ]
    }
    failed_rows = bundle_evidence["artifact_preflight_field_coverage_failed_rows"]
    assert failed_rows[0]["bundle_key"] == "signed_release_publication_manifest"
    assert failed_rows[0]["missing_artifact_fields"] == ["signature_urls"]
    assert payload["final_completion_ready"] is False


def test_cli_fixture_validation_pack_audit_rejects_bundle_traceability_mismatch(
    capsys,
) -> None:
    bundle = _completion_evidence_bundle_payload()
    bundle["completion_evidence_artifact_filenames"] = [
        "signed_release_publication_manifest.json"
    ]
    bundle["completion_evidence_artifact_filename_signature"] = (
        "signed_release_publication_manifest.json"
    )
    bundle["completion_evidence_artifact_instance_rows"] = [
        {"artifact_filename": "signed_release_publication_manifest.json"}
    ]
    with workspace_tempdir() as tmp_path:
        bundle_path = tmp_path / "completion-evidence-bundle-traceability-mismatch.json"
        bundle_path.write_text(json.dumps(bundle), encoding="utf-8")

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--completion-evidence-bundle-json",
                str(bundle_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["completion_evidence_bundle_certified"] is False
    bundle_evidence = payload["completion_evidence_bundle"]
    assert bundle_evidence["all_bundle_artifacts_certified"] is True
    assert bundle_evidence["completion_evidence_artifact_filenames_match_expected"] is False
    assert (
        bundle_evidence[
            "completion_evidence_artifact_filename_signature_matches_expected"
        ]
        is False
    )
    assert (
        bundle_evidence[
            "completion_evidence_artifact_instance_row_count_matches_expected"
        ]
        is False
    )
    assert bundle_evidence["bundle_evidence_failed_checks"] == [
        "completion_evidence_artifact_filenames_match_expected",
        "completion_evidence_artifact_filename_signature_matches_expected",
        "completion_evidence_artifact_instance_row_count_matches_expected",
    ]
    assert payload["final_completion_ready"] is False


def test_cli_fixture_validation_pack_audit_rejects_zero_render_frame_bundle(
    capsys,
) -> None:
    bundle = _completion_evidence_bundle_payload()
    bundle["production_imgui_renderer_framebuffer_pack"]["render_frame_count"] = 0
    with workspace_tempdir() as tmp_path:
        bundle_path = tmp_path / "completion-evidence-bundle-zero-frames.json"
        bundle_path.write_text(json.dumps(bundle), encoding="utf-8")

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--completion-evidence-bundle-json",
                str(bundle_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["final_completion_ready"] is False
    assert payload["completion_evidence_bundle_certified"] is False
    bundle_evidence = payload["completion_evidence_bundle"]
    assert bundle_evidence["all_bundle_artifacts_certified"] is False
    assert bundle_evidence["bundle_evidence_failed_checks"] == [
        "all_bundle_artifacts_certified"
    ]
    assert bundle_evidence["artifact_preflight_failed_count"] == 1
    failed_row = bundle_evidence["artifact_preflight_failed_rows"][0]
    assert failed_row["artifact_type"] == "production_imgui_renderer_framebuffer_pack"
    assert failed_row["artifact_field_coverage_complete"] is True
    assert failed_row["missing_artifact_fields"] == []
    assert failed_row["failed_checks"] == ["render_frame_count_positive"]


def test_cli_completion_evidence_bundle_builds_auditable_bundle(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        l5_path = tmp_path / "l5a1-signed-assignment.json"
        l6_path = tmp_path / "l6a4-signed-assignment.json"
        production_path = tmp_path / "production-imgui-pack.json"
        release_path = tmp_path / "signed-release-manifest.json"
        homfly_path = tmp_path / "full-homfly-pack.json"
        alexander_path = tmp_path / "full-alexander-pack.json"
        bundle_path = tmp_path / "completion-evidence-bundle.json"
        _write_verified_signed_crossing_assignment(
            l5_path,
            notation="L5a1",
            crossing_count=5,
        )
        _write_verified_signed_crossing_assignment(
            l6_path,
            notation="L6a4",
            crossing_count=6,
        )
        _write_imgui_production_framebuffer_pack(production_path)
        _write_signed_release_publication_manifest(release_path)
        _write_full_homfly_certification_pack(homfly_path)
        _write_full_alexander_certification_pack(alexander_path)

        build_exit_code = main(
            [
                "completion-evidence-bundle",
                "--verified-signed-crossing-assignment-json",
                str(l5_path),
                "--verified-signed-crossing-assignment-json",
                str(l6_path),
                "--production-imgui-renderer-framebuffer-pack-json",
                str(production_path),
                "--signed-release-publication-manifest-json",
                str(release_path),
                "--full-homfly-pt-evaluation-certification-pack-json",
                str(homfly_path),
                "--full-multivariable-alexander-normalization-certification-pack-json",
                str(alexander_path),
                "-o",
                str(bundle_path),
            ]
        )
        capsys.readouterr()
        bundle_exists = bundle_path.exists()
        bundle = json.loads(bundle_path.read_text(encoding="utf-8"))

        audit_exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--completion-evidence-bundle-json",
                str(bundle_path),
            ]
        )
        audit_payload = json.loads(capsys.readouterr().out)

    assert build_exit_code == 0
    assert bundle_exists
    assert bundle["artifact_kind"] == "cross_workstream_completion_evidence_bundle"
    assert bundle["claim_scope"] == "cross_workstream_final_completion_evidence"
    assert bundle["bundle_inputs_complete"] is True
    assert bundle["bundle_input_count"] == 5
    assert bundle["bundle_repeatable_assignment_count"] == 2
    assert bundle["bundle_certified_by_audit"] is False
    assert bundle["expected_evidence_filename_count"] == 6
    assert bundle["expected_evidence_filenames"] == [
        "full_homfly_pt_evaluation_certification_pack.json",
        "full_multivariable_alexander_normalization_certification_pack.json",
        "production_imgui_renderer_framebuffer_pack.json",
        "signed_release_publication_manifest.json",
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert bundle["bundle_all_inputs_command"].endswith(
        "-o completion-evidence-bundle.json"
    )
    assert bundle["final_validation_command"].endswith("--fail-on-not-ready")
    assert bundle["completion_evidence_artifact_instance_row_count"] == 6
    assert bundle["completion_evidence_artifact_filenames"] == bundle[
        "expected_evidence_filenames"
    ]
    bundle_instance_rows = {
        row["artifact_filename"]: row
        for row in bundle["completion_evidence_artifact_instance_rows"]
    }
    assert bundle_instance_rows["verified_signed_crossing_assignment.L6a4.json"][
        "final_completion_blocker_labels"
    ] == ["L6a4"]
    assert bundle_instance_rows["production_imgui_renderer_framebuffer_pack.json"][
        "final_completion_failed_gates"
    ] == ["non_diagram_requirements", "production_imgui_renderer"]
    assert bundle["retained_evidence_distinct_count"] == 8
    assert bundle["retained_evidence_completion_claimed_count"] == 0
    assert bundle["completion_claimed"] is False
    assert len(bundle["verified_signed_crossing_assignments"]) == 2
    assert audit_exit_code == 0
    assert audit_payload["completion_evidence_bundle_certified"] is True
    assert audit_payload["completion_evidence_bundle"][
        "expected_artifact_preflight_row_count"
    ] == 6
    assert audit_payload["completion_evidence_bundle"][
        "artifact_preflight_row_count"
    ] == 6
    assert audit_payload["completion_evidence_bundle"][
        "all_bundle_artifacts_certified"
    ] is True
    assert audit_payload["completion_evidence_bundle"][
        "missing_signed_assignment_notation_count"
    ] == 0
    assert audit_payload["completion_evidence_bundle"][
        "invalid_bundle_non_claim_fields"
    ] == []
    assert audit_payload["completion_evidence_bundle"][
        "completion_evidence_artifact_instance_row_count"
    ] == 6
    assert audit_payload["completion_evidence_bundle"][
        "completion_evidence_artifact_instance_rows"
    ][-1]["final_completion_blocker_labels"] == ["L6a4"]
    assert audit_payload["completion_evidence_bundle"][
        "completion_evidence_artifact_filenames"
    ] == bundle["expected_evidence_filenames"]
    assert audit_payload["final_completion_ready"] is True
    assert audit_payload["final_completion_blocker_count"] == 0


def test_cli_completion_evidence_bundle_requires_both_signed_assignments(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        l5_path = tmp_path / "l5a1-signed-assignment.json"
        production_path = tmp_path / "production-imgui-pack.json"
        release_path = tmp_path / "signed-release-manifest.json"
        homfly_path = tmp_path / "full-homfly-pack.json"
        alexander_path = tmp_path / "full-alexander-pack.json"
        bundle_path = tmp_path / "completion-evidence-bundle.json"
        _write_verified_signed_crossing_assignment(
            l5_path,
            notation="L5a1",
            crossing_count=5,
        )
        _write_imgui_production_framebuffer_pack(production_path)
        _write_signed_release_publication_manifest(release_path)
        _write_full_homfly_certification_pack(homfly_path)
        _write_full_alexander_certification_pack(alexander_path)

        build_exit_code = main(
            [
                "completion-evidence-bundle",
                "--verified-signed-crossing-assignment-json",
                str(l5_path),
                "--production-imgui-renderer-framebuffer-pack-json",
                str(production_path),
                "--signed-release-publication-manifest-json",
                str(release_path),
                "--full-homfly-pt-evaluation-certification-pack-json",
                str(homfly_path),
                "--full-multivariable-alexander-normalization-certification-pack-json",
                str(alexander_path),
                "-o",
                str(bundle_path),
            ]
        )
        capsys.readouterr()

        audit_exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--completion-evidence-bundle-json",
                str(bundle_path),
            ]
        )
        audit_payload = json.loads(capsys.readouterr().out)

    assert build_exit_code == 0
    assert audit_exit_code == 0
    bundle_evidence = audit_payload["completion_evidence_bundle"]
    assert audit_payload["completion_evidence_bundle_certified"] is False
    assert bundle_evidence["bundle_evidence_failed_check_count"] == 2
    assert bundle_evidence["bundle_evidence_failed_check_signature"] == (
        "verified_signed_crossing_assignment_required_notations|"
        "bundle_contract_coverage_complete"
    )
    assert bundle_evidence["artifact_preflight_row_count"] == 5
    assert bundle_evidence["artifact_preflight_failed_count"] == 0
    assert bundle_evidence["all_bundle_artifacts_certified"] is True
    coverage = bundle_evidence["bundle_contract_coverage"]
    assert bundle_evidence["bundle_contract_coverage_complete"] is False
    assert coverage["expected_artifact_type_coverage_complete"] is True
    assert coverage["single_artifact_type_coverage_complete"] is True
    assert coverage["signed_assignment_preflight_count"] == 1
    assert coverage["required_signed_assignment_count"] == 2
    assert coverage["signed_assignment_count_matches_required"] is False
    assert coverage["signed_assignment_notation_coverage_complete"] is False
    assert coverage["coverage_complete"] is False
    assert bundle_evidence["present_signed_assignment_notations"] == ["L5a1"]
    assert bundle_evidence["missing_signed_assignment_notations"] == ["L6a4"]
    assert "verified_signed_crossing_assignment_required_notations" in (
        bundle_evidence["failed_checks"]
    )
    assert "bundle_contract_coverage_complete" in bundle_evidence["failed_checks"]
    assert audit_payload["final_completion_ready"] is False
    assert audit_payload["final_completion_blocker_count"] == 7


def test_cli_fixture_validation_pack_audit_rejects_self_certifying_bundle(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        bundle_path = tmp_path / "self-certifying-completion-evidence-bundle.json"
        bundle = _completion_evidence_bundle_payload()
        bundle["completion_claimed"] = True
        bundle["bundle_certified_by_audit"] = True
        bundle_path.write_text(json.dumps(bundle), encoding="utf-8")

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--completion-evidence-bundle-json",
                str(bundle_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    evidence = payload["completion_evidence_bundle"]
    assert payload["completion_evidence_bundle_certified"] is False
    assert evidence["bundle_evidence_failed_check_count"] == 2
    assert evidence["bundle_evidence_failed_check_signature"] == (
        "bundle_completion_claimed_false|bundle_certified_by_audit_false"
    )
    assert evidence["invalid_bundle_non_claim_fields"] == [
        "completion_claimed",
        "bundle_certified_by_audit",
    ]
    assert evidence["bundle_completion_claimed"] is True
    assert evidence["bundle_certified_by_audit"] is True
    assert "bundle_completion_claimed_false" in evidence["failed_checks"]
    assert "bundle_certified_by_audit_false" in evidence["failed_checks"]
    assert payload["final_completion_ready"] is False
    assert payload["final_completion_blocker_count"] == 7


def test_cli_completion_evidence_bundle_discovers_evidence_directory(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        evidence_dir = tmp_path / "evidence"
        evidence_dir.mkdir()
        bundle_path = tmp_path / "completion-evidence-bundle.json"
        _write_verified_signed_crossing_assignment(
            evidence_dir / "verified_signed_crossing_assignment.L5a1.json",
            notation="L5a1",
            crossing_count=5,
        )
        _write_verified_signed_crossing_assignment(
            evidence_dir / "verified_signed_crossing_assignment.L6a4.json",
            notation="L6a4",
            crossing_count=6,
        )
        _write_imgui_production_framebuffer_pack(
            evidence_dir / "production_imgui_renderer_framebuffer_pack.json"
        )
        _write_signed_release_publication_manifest(
            evidence_dir / "signed_release_publication_manifest.json"
        )
        _write_full_homfly_certification_pack(
            evidence_dir / "full_homfly_pt_evaluation_certification_pack.json"
        )
        _write_full_alexander_certification_pack(
            evidence_dir
            / "full_multivariable_alexander_normalization_certification_pack.json"
        )

        build_exit_code = main(
            [
                "completion-evidence-bundle",
                "--evidence-directory",
                str(evidence_dir),
                "-o",
                str(bundle_path),
            ]
        )
        capsys.readouterr()
        bundle = json.loads(bundle_path.read_text(encoding="utf-8"))

        audit_exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--completion-evidence-bundle-json",
                str(bundle_path),
            ]
        )
        audit_payload = json.loads(capsys.readouterr().out)
        directory_audit_exit_code = main(
            ["completion-evidence-directory-audit", str(evidence_dir)]
        )
        directory_audit_payload = json.loads(capsys.readouterr().out)

    assert build_exit_code == 0
    assert bundle["source_evidence_directory"] == str(evidence_dir)
    assert bundle["discovered_evidence_file_count"] == 6
    assert bundle["bundle_inputs_complete"] is True
    assert bundle["bundle_repeatable_assignment_count"] == 2
    assert bundle["bundle_certified_by_audit"] is False
    assert bundle["expected_evidence_filename_count"] == 6
    assert bundle["expected_evidence_filenames"] == [
        "full_homfly_pt_evaluation_certification_pack.json",
        "full_multivariable_alexander_normalization_certification_pack.json",
        "production_imgui_renderer_framebuffer_pack.json",
        "signed_release_publication_manifest.json",
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert bundle["directory_audit_command"].endswith("--fail-on-not-ready")
    assert bundle["completion_evidence_artifact_instance_row_count"] == 6
    assert bundle["completion_evidence_artifact_filenames"] == bundle[
        "expected_evidence_filenames"
    ]
    assert bundle["completion_evidence_artifact_instance_rows"][-1][
        "final_completion_blocker_labels"
    ] == ["L6a4"]
    assert bundle["completion_claimed"] is False
    assert len(bundle["verified_signed_crossing_assignments"]) == 2
    assert audit_exit_code == 0
    assert audit_payload["completion_evidence_bundle_certified"] is True
    assert audit_payload["final_completion_ready"] is True
    assert audit_payload["final_completion_blocker_count"] == 0
    assert audit_payload["completion_evidence_bundle"][
        "completion_evidence_artifact_instance_row_count"
    ] == 6
    assert audit_payload["completion_evidence_bundle"][
        "completion_evidence_artifact_instance_rows"
    ][-1]["final_completion_blocker_labels"] == ["L6a4"]
    assert directory_audit_exit_code == 0
    bundle_coverage = audit_payload["completion_evidence_bundle"][
        "bundle_contract_coverage"
    ]
    directory_coverage = directory_audit_payload[
        "artifact_preflight_contract_coverage"
    ]
    for field in (
        "expected_artifact_types",
        "preflight_artifact_types",
        "preflight_artifact_type_counts",
        "missing_artifact_types",
        "unexpected_artifact_types",
        "signed_assignment_preflight_count",
        "required_signed_assignment_count",
        "signed_assignment_count_matches_required",
        "coverage_complete",
        "matched",
    ):
        assert bundle_coverage[field] == directory_coverage[field]


def test_cli_completion_evidence_directory_audit_reports_complete_directory(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        evidence_dir = tmp_path / "evidence"
        evidence_dir.mkdir()
        _write_verified_signed_crossing_assignment(
            evidence_dir / "verified_signed_crossing_assignment.L5a1.json",
            notation="L5a1",
            crossing_count=5,
        )
        _write_verified_signed_crossing_assignment(
            evidence_dir / "verified_signed_crossing_assignment.L6a4.json",
            notation="L6a4",
            crossing_count=6,
        )
        _write_imgui_production_framebuffer_pack(
            evidence_dir / "production_imgui_renderer_framebuffer_pack.json"
        )
        _write_signed_release_publication_manifest(
            evidence_dir / "signed_release_publication_manifest.json"
        )
        _write_full_homfly_certification_pack(
            evidence_dir / "full_homfly_pt_evaluation_certification_pack.json"
        )
        _write_full_alexander_certification_pack(
            evidence_dir
            / "full_multivariable_alexander_normalization_certification_pack.json"
        )

        exit_code = main(["completion-evidence-directory-audit", str(evidence_dir)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["artifact_kind"] == (
        "cross_workstream_completion_evidence_directory_audit"
    )
    assert payload["bundle_inputs_complete"] is True
    assert payload["retained_evidence_distinct_count"] == 8
    assert payload["retained_evidence_completion_claimed_count"] == 0
    assert payload["discovered_evidence_file_count"] == 6
    assert payload["present_input_count"] == 5
    assert payload["missing_input_count"] == 0
    assert payload["expected_evidence_filename_count"] == 6
    assert payload["expected_evidence_filenames"] == [
        "full_homfly_pt_evaluation_certification_pack.json",
        "full_multivariable_alexander_normalization_certification_pack.json",
        "production_imgui_renderer_framebuffer_pack.json",
        "signed_release_publication_manifest.json",
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert payload["contract_instance_filenames"] == payload[
        "expected_evidence_filenames"
    ]
    assert payload["contract_instance_filename_count"] == payload[
        "expected_evidence_filename_count"
    ]
    assert payload[
        "contract_instance_filenames_match_expected_evidence_filenames"
    ] is True
    assert payload["all_contract_consistency_passed"] is True
    assert payload["contract_instance_filename_signature"] == payload[
        "expected_evidence_filename_signature"
    ]
    assert payload["bundle_all_inputs_command"].endswith(
        "-o completion-evidence-bundle.json"
    )
    assert payload["directory_audit_command"].endswith("--fail-on-not-ready")
    assert payload["final_validation_command"].endswith("--fail-on-not-ready")
    assert payload["artifact_preflight_count"] == 6
    assert payload["artifact_preflight_certified_count"] == 6
    assert payload["artifact_preflight_failed_count"] == 0
    assert payload["artifact_preflight_all_certified"] is True
    assert payload["required_signed_assignment_notations"] == ["L5a1", "L6a4"]
    assert payload["present_signed_assignment_notations"] == ["L5a1", "L6a4"]
    assert payload["missing_signed_assignment_notations"] == []
    assert payload["signed_assignment_notation_coverage_complete"] is True
    coverage = payload["artifact_preflight_contract_coverage"]
    assert payload["artifact_preflight_contract_coverage_complete"] is True
    assert coverage["coverage_complete"] is True
    assert coverage["matched"] is True
    assert coverage["preflight_artifact_row_count"] == 6
    assert coverage["expected_artifact_type_count"] == 5
    assert coverage["preflight_artifact_type_count"] == 5
    assert coverage["missing_artifact_types"] == []
    assert coverage["unexpected_artifact_types"] == []
    assert coverage["missing_single_artifact_types"] == []
    assert coverage["repeated_single_artifact_types"] == []
    assert coverage["signed_assignment_preflight_count"] == 2
    assert coverage["required_signed_assignment_count"] == 2
    assert coverage["signed_assignment_count_matches_required"] is True
    assert {
        row["artifact_type"] for row in payload["artifact_preflight_audits"]
    } == {
        "verified_signed_crossing_assignment",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
    }
    preflight_rows = {
        row["artifact_type"]: row for row in payload["artifact_preflight_audits"]
    }
    assert preflight_rows["signed_release_publication_manifest"]["audit"][
        "completion_evidence_artifact_filenames"
    ] == ["signed_release_publication_manifest.json"]
    assert preflight_rows["verified_signed_crossing_assignment"]["audit"][
        "completion_evidence_artifact_filenames"
    ] == [
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    rows = {row["bundle_key"]: row for row in payload["discovered_inputs"]}
    assert rows["verified_signed_crossing_assignments"]["repeatable"] is True
    assert rows["verified_signed_crossing_assignments"]["discovered_path_count"] == 2
    assert rows["verified_signed_crossing_assignments"][
        "expected_instance_filenames"
    ] == [
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert rows["verified_signed_crossing_assignments"][
        "present_instance_filenames"
    ] == [
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert rows["verified_signed_crossing_assignments"][
        "missing_instance_filenames"
    ] == []
    assert rows["verified_signed_crossing_assignments"][
        "instance_filename_coverage_complete"
    ] is True
    assert "--evidence-directory" in payload["bundle_command"]
    assert payload["completion_evidence_pipeline_ready"] is False
    pipeline_steps = {row["step"]: row for row in payload["pipeline_steps"]}
    assert pipeline_steps["discover_required_inputs"]["passed"] is True
    assert pipeline_steps["preflight_discovered_artifacts"]["passed"] is True
    assert pipeline_steps["validate_artifact_contents"]["skipped_reason"] == (
        "not_requested"
    )


def test_cli_completion_evidence_directory_audit_validates_complete_directory(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        evidence_dir = tmp_path / "evidence"
        evidence_dir.mkdir()
        _write_verified_signed_crossing_assignment(
            evidence_dir / "verified_signed_crossing_assignment.L5a1.json",
            notation="L5a1",
            crossing_count=5,
        )
        _write_verified_signed_crossing_assignment(
            evidence_dir / "verified_signed_crossing_assignment.L6a4.json",
            notation="L6a4",
            crossing_count=6,
        )
        _write_imgui_production_framebuffer_pack(
            evidence_dir / "production_imgui_renderer_framebuffer_pack.json"
        )
        _write_signed_release_publication_manifest(
            evidence_dir / "signed_release_publication_manifest.json"
        )
        _write_full_homfly_certification_pack(
            evidence_dir / "full_homfly_pt_evaluation_certification_pack.json"
        )
        _write_full_alexander_certification_pack(
            evidence_dir
            / "full_multivariable_alexander_normalization_certification_pack.json"
        )

        exit_code = main(
            [
                "completion-evidence-directory-audit",
                str(evidence_dir),
                "--validate-artifacts",
                "--fail-on-not-ready",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["bundle_inputs_complete"] is True
    assert payload["artifact_validation_requested"] is True
    assert payload["artifact_validation_performed"] is True
    assert payload["artifact_validation_skipped_reason"] is None
    assert payload["artifact_validation_final_completion_ready"] is True
    assert payload["artifact_preflight_field_coverage_complete"] is True
    assert payload["artifact_preflight_field_coverage_failed_count"] == 0
    assert payload["artifact_preflight_field_coverage_failed_rows"] == []
    assert payload["missing_artifact_fields_by_path"] == {}
    assert payload["artifact_validation_final_completion_blocker_count"] == 0
    assert payload["artifact_validation_blocker_code_counts"] == {}
    assert payload["artifact_validation_failed_gate_count"] == 0
    assert payload["artifact_validation_failed_gates"] == []
    assert payload["artifact_validation_failed_gate_signature"] == ""
    assert payload["artifact_validation_missing_artifact_count"] == 0
    assert payload["artifact_validation_missing_artifacts"] == []
    assert payload["artifact_validation_missing_artifact_signature"] == ""
    assert payload["completion_evidence_pipeline_ready"] is True
    assert payload["completion_evidence_pipeline_blocker_count"] == 0
    assert payload["completion_evidence_pipeline_blocker_codes"] == []
    assert payload["completion_evidence_pipeline_blocker_code_counts"] == {}
    assert payload["completion_evidence_pipeline_blocker_signature"] == ""
    assert payload["completion_evidence_pipeline_blockers"] == []
    assert payload["ci_fail_on_not_ready"] is True
    assert payload["ci_exit_code"] == 0
    assert payload["pipeline_required_step_count"] == 3
    assert payload["pipeline_passed_required_step_count"] == 3
    assert payload["pipeline_failed_required_step_count"] == 0
    assert payload["pipeline_failed_required_steps"] == []
    assert payload["pipeline_failed_required_step_signature"] == ""
    assert payload["pipeline_skipped_required_step_count"] == 0
    pipeline_steps = {row["step"]: row for row in payload["pipeline_steps"]}
    assert pipeline_steps["discover_required_inputs"]["passed"] is True
    assert pipeline_steps["preflight_discovered_artifacts"]["passed"] is True
    assert pipeline_steps["validate_artifact_contents"]["passed"] is True


def test_cli_completion_evidence_directory_audit_explains_invalid_complete_directory(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        evidence_dir = tmp_path / "template-evidence"
        templates_exit_code = main(
            [
                "completion-evidence-templates",
                "--directory",
                str(evidence_dir),
            ]
        )
        capsys.readouterr()

        exit_code = main(
            [
                "completion-evidence-directory-audit",
                str(evidence_dir),
                "--validate-artifacts",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert templates_exit_code == 0
    assert exit_code == 0
    assert payload["bundle_inputs_complete"] is True
    assert payload["artifact_validation_performed"] is True
    assert payload["artifact_validation_final_completion_ready"] is False
    assert payload["artifact_validation_final_completion_blocker_count"] == 7
    assert payload["artifact_validation_failed_gate_count"] == 6
    assert payload["artifact_validation_failed_gates"] == [
        "signed_diagram_fixture_registration",
        "non_diagram_requirements",
        "full_homfly_pt_evaluation",
        "full_multivariable_alexander_normalization",
        "production_imgui_renderer",
        "release_artifacts",
    ]
    assert payload["artifact_validation_failed_gate_signature"] == (
        "signed_diagram_fixture_registration|non_diagram_requirements|"
        "full_homfly_pt_evaluation|full_multivariable_alexander_normalization|"
        "production_imgui_renderer|release_artifacts"
    )
    assert payload["artifact_validation_missing_artifact_count"] == 5
    assert payload["artifact_validation_missing_artifacts"] == [
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "verified_signed_crossing_assignment",
    ]
    assert payload["artifact_validation_missing_artifact_signature"] == (
        "full_homfly_pt_evaluation_certification_pack|"
        "full_multivariable_alexander_normalization_certification_pack|"
        "production_imgui_renderer_framebuffer_pack|"
        "signed_release_publication_manifest|verified_signed_crossing_assignment"
    )
    assert payload["expected_evidence_filename_count"] == 6
    assert payload["expected_evidence_filenames"] == [
        "full_homfly_pt_evaluation_certification_pack.json",
        "full_multivariable_alexander_normalization_certification_pack.json",
        "production_imgui_renderer_framebuffer_pack.json",
        "signed_release_publication_manifest.json",
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert (
        "--verified-signed-crossing-assignment-json "
        "<verified_signed_crossing_assignment.L6a4.json>"
    ) in payload["bundle_all_inputs_command"]
    assert payload["directory_audit_command"].startswith(
        "iroll completion-evidence-directory-audit"
    )
    assert payload["final_validation_command"] == (
        "iroll fixture-validation-pack-audit "
        "--completion-evidence-bundle-json completion-evidence-bundle.json "
        "--fail-on-not-ready"
    )
    assert payload["completion_evidence_pipeline_ready"] is False
    assert payload["completion_evidence_pipeline_blocker_count"] == 3
    assert payload["completion_evidence_pipeline_blocker_codes"] == [
        "artifact_preflight_not_certified",
        "artifact_validation_not_ready",
        "required_instance_files_missing",
    ]
    assert payload["completion_evidence_pipeline_blocker_code_counts"] == {
        "artifact_preflight_not_certified": 1,
        "artifact_validation_not_ready": 1,
        "required_instance_files_missing": 1,
    }
    assert payload["completion_evidence_pipeline_blocker_signature"] == (
        "artifact_preflight_not_certified:1,artifact_validation_not_ready:1,"
        "required_instance_files_missing:1"
    )
    pipeline_blockers = {
        row["step"]: row for row in payload["completion_evidence_pipeline_blockers"]
    }
    assert pipeline_blockers["preflight_discovered_artifacts"][
        "artifact_preflight_failed_count"
    ] == 5
    assert pipeline_blockers["validate_artifact_contents"][
        "artifact_validation_failed_gate_count"
    ] == 6
    assert pipeline_blockers["check_required_instance_files"][
        "missing_instance_filenames"
    ] == [
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert payload["pipeline_required_step_count"] == 3
    assert payload["pipeline_passed_required_step_count"] == 1
    assert payload["pipeline_failed_required_step_count"] == 2
    assert payload["pipeline_failed_required_steps"] == [
        "preflight_discovered_artifacts",
        "validate_artifact_contents",
    ]
    assert payload["pipeline_failed_required_step_signature"] == (
        "preflight_discovered_artifacts|validate_artifact_contents"
    )
    assert payload["pipeline_skipped_required_step_count"] == 0
    assert payload["artifact_preflight_count"] == 5
    assert payload["artifact_preflight_certified_count"] == 0
    assert payload["artifact_preflight_failed_count"] == 5
    assert payload["artifact_preflight_field_coverage_failed_count"] == 5
    assert payload["artifact_preflight_field_coverage_complete"] is False
    assert len(payload["artifact_preflight_field_coverage_failed_rows"]) == 5
    missing_fields_by_type = {
        row["artifact_type"]: row["audit"]["missing_artifact_fields"]
        for row in payload["artifact_preflight_field_coverage_failed_rows"]
    }
    assert missing_fields_by_type["signed_release_publication_manifest"] == [
        "package_index_url",
        "artifact_urls",
        "artifact_sha256s",
        "signature_urls",
        "signature_sha256s",
    ]
    release_path = next(
        path
        for path, row in payload["missing_artifact_fields_by_path"].items()
        if row["artifact_type"] == "signed_release_publication_manifest"
    )
    assert release_path.endswith("signed_release_publication_manifest.template.json")
    assert payload["missing_artifact_fields_by_path"][release_path][
        "missing_artifact_fields"
    ] == [
        "package_index_url",
        "artifact_urls",
        "artifact_sha256s",
        "signature_urls",
        "signature_sha256s",
    ]
    assert payload["artifact_preflight_all_certified"] is False
    assert payload["present_signed_assignment_notations"] == []
    assert payload["missing_signed_assignment_notations"] == ["L5a1", "L6a4"]
    assert payload["signed_assignment_notation_coverage_complete"] is False
    gate_checks = {
        row["gate"]: row for row in payload["artifact_validation_gate_checks"]
    }
    assert gate_checks["signed_diagram_fixture_registration"]["passed"] is False
    assert gate_checks["release_artifacts"]["passed"] is False
    missing_summary = {
        row["missing_artifact"]: row
        for row in payload["artifact_validation_missing_artifact_summary"]
    }
    assert missing_summary["verified_signed_crossing_assignment"][
        "blocker_count"
    ] == 2
    assert missing_summary["production_imgui_renderer_framebuffer_pack"][
        "blocker_count"
    ] == 2
    pipeline_steps = {row["step"]: row for row in payload["pipeline_steps"]}
    assert pipeline_steps["discover_required_inputs"]["passed"] is True
    assert pipeline_steps["preflight_discovered_artifacts"]["passed"] is False
    assert pipeline_steps["validate_artifact_contents"]["passed"] is False


def test_cli_completion_evidence_directory_audit_requires_both_signed_assignments(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        evidence_dir = tmp_path / "evidence"
        evidence_dir.mkdir()
        _write_verified_signed_crossing_assignment(
            evidence_dir / "verified_signed_crossing_assignment.L5a1.json",
            notation="L5a1",
            crossing_count=5,
        )
        _write_imgui_production_framebuffer_pack(
            evidence_dir / "production_imgui_renderer_framebuffer_pack.json"
        )
        _write_signed_release_publication_manifest(
            evidence_dir / "signed_release_publication_manifest.json"
        )
        _write_full_homfly_certification_pack(
            evidence_dir / "full_homfly_pt_evaluation_certification_pack.json"
        )
        _write_full_alexander_certification_pack(
            evidence_dir
            / "full_multivariable_alexander_normalization_certification_pack.json"
        )

        exit_code = main(["completion-evidence-directory-audit", str(evidence_dir)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["bundle_inputs_complete"] is True
    assert payload["artifact_preflight_count"] == 5
    assert payload["artifact_preflight_certified_count"] == 5
    assert payload["artifact_preflight_failed_count"] == 0
    assert payload["artifact_preflight_all_certified"] is False
    assert payload["present_signed_assignment_notations"] == ["L5a1"]
    assert payload["missing_signed_assignment_notations"] == ["L6a4"]
    assert payload["signed_assignment_notation_coverage_complete"] is False
    coverage = payload["artifact_preflight_contract_coverage"]
    assert payload["artifact_preflight_contract_coverage_complete"] is False
    assert coverage["expected_artifact_type_coverage_complete"] is True
    assert coverage["single_artifact_type_coverage_complete"] is True
    assert coverage["signed_assignment_notation_coverage_complete"] is False
    assert coverage["signed_assignment_preflight_count"] == 1
    assert coverage["required_signed_assignment_count"] == 2
    assert coverage["signed_assignment_count_matches_required"] is False
    assert coverage["coverage_complete"] is False
    assert payload["completion_evidence_pipeline_blocker_count"] == 3
    assert payload["completion_evidence_pipeline_blocker_codes"] == [
        "artifact_preflight_not_certified",
        "artifact_validation_not_ready",
        "required_instance_files_missing",
    ]
    assert payload["completion_evidence_pipeline_blocker_code_counts"] == {
        "artifact_preflight_not_certified": 1,
        "artifact_validation_not_ready": 1,
        "required_instance_files_missing": 1,
    }
    assert payload["completion_evidence_pipeline_blocker_signature"] == (
        "artifact_preflight_not_certified:1,artifact_validation_not_ready:1,"
        "required_instance_files_missing:1"
    )
    pipeline_blockers = {
        row["step"]: row for row in payload["completion_evidence_pipeline_blockers"]
    }
    assert pipeline_blockers["preflight_discovered_artifacts"][
        "missing_signed_assignment_notations"
    ] == ["L6a4"]
    assert pipeline_blockers["validate_artifact_contents"][
        "artifact_validation_skipped_reason"
    ] == "not_requested"
    assert pipeline_blockers["check_required_instance_files"][
        "missing_instance_filenames"
    ] == ["verified_signed_crossing_assignment.L6a4.json"]
    assert payload["pipeline_required_step_count"] == 3
    assert payload["pipeline_passed_required_step_count"] == 1
    assert payload["pipeline_failed_required_step_count"] == 2
    assert payload["pipeline_failed_required_steps"] == [
        "preflight_discovered_artifacts",
        "validate_artifact_contents",
    ]
    assert payload["pipeline_failed_required_step_signature"] == (
        "preflight_discovered_artifacts|validate_artifact_contents"
    )
    assert payload["pipeline_skipped_required_step_count"] == 1
    pipeline_steps = {row["step"]: row for row in payload["pipeline_steps"]}
    assert pipeline_steps["discover_required_inputs"]["passed"] is True
    assert pipeline_steps["preflight_discovered_artifacts"]["passed"] is False


def test_cli_completion_evidence_directory_audit_can_fail_ci_when_not_ready(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        evidence_dir = tmp_path / "template-evidence"
        templates_exit_code = main(
            [
                "completion-evidence-templates",
                "--directory",
                str(evidence_dir),
            ]
        )
        capsys.readouterr()

        exit_code = main(
            [
                "completion-evidence-directory-audit",
                str(evidence_dir),
                "--validate-artifacts",
                "--fail-on-not-ready",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert templates_exit_code == 0
    assert exit_code == 1
    assert "_exit_code" not in payload
    assert payload["ci_fail_on_not_ready"] is True
    assert payload["ci_exit_code"] == 1
    assert payload["completion_evidence_pipeline_ready"] is False
    assert payload["artifact_validation_failed_gate_signature"] == (
        "signed_diagram_fixture_registration|non_diagram_requirements|"
        "full_homfly_pt_evaluation|full_multivariable_alexander_normalization|"
        "production_imgui_renderer|release_artifacts"
    )


def test_cli_completion_evidence_directory_audit_writes_bundle_output(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        evidence_dir = tmp_path / "evidence"
        bundle_path = tmp_path / "completion-evidence-bundle.json"
        evidence_dir.mkdir()
        _write_verified_signed_crossing_assignment(
            evidence_dir / "verified_signed_crossing_assignment.L5a1.json",
            notation="L5a1",
            crossing_count=5,
        )
        _write_verified_signed_crossing_assignment(
            evidence_dir / "verified_signed_crossing_assignment.L6a4.json",
            notation="L6a4",
            crossing_count=6,
        )
        _write_imgui_production_framebuffer_pack(
            evidence_dir / "production_imgui_renderer_framebuffer_pack.json"
        )
        _write_signed_release_publication_manifest(
            evidence_dir / "signed_release_publication_manifest.json"
        )
        _write_full_homfly_certification_pack(
            evidence_dir / "full_homfly_pt_evaluation_certification_pack.json"
        )
        _write_full_alexander_certification_pack(
            evidence_dir
            / "full_multivariable_alexander_normalization_certification_pack.json"
        )

        exit_code = main(
            [
                "completion-evidence-directory-audit",
                str(evidence_dir),
                "--validate-artifacts",
                "--bundle-output",
                str(bundle_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)
        bundle = json.loads(bundle_path.read_text(encoding="utf-8"))

        audit_exit = main(
            [
                "fixture-validation-pack-audit",
                "--completion-evidence-bundle-json",
                str(bundle_path),
            ]
        )
        audit_payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["bundle_output_requested"] is True
    assert payload["bundle_output_written"] is True
    assert payload["bundle_output_skipped_reason"] is None
    assert payload["bundle_output_path"] == str(bundle_path)
    assert payload["artifact_validation_final_completion_ready"] is True
    assert bundle["artifact_kind"] == "cross_workstream_completion_evidence_bundle"
    assert bundle["bundle_inputs_complete"] is True
    assert bundle["bundle_repeatable_assignment_count"] == 2
    assert bundle["bundle_certified_by_audit"] is False
    assert bundle["completion_claimed"] is False
    assert len(bundle["verified_signed_crossing_assignments"]) == 2
    assert audit_exit == 0
    assert audit_payload["final_completion_ready"] is True


def test_cli_completion_evidence_directory_audit_writes_validation_output(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        evidence_dir = tmp_path / "evidence"
        validation_path = tmp_path / "validation-pack-audit.json"
        evidence_dir.mkdir()
        _write_verified_signed_crossing_assignment(
            evidence_dir / "verified_signed_crossing_assignment.L5a1.json",
            notation="L5a1",
            crossing_count=5,
        )
        _write_verified_signed_crossing_assignment(
            evidence_dir / "verified_signed_crossing_assignment.L6a4.json",
            notation="L6a4",
            crossing_count=6,
        )
        _write_imgui_production_framebuffer_pack(
            evidence_dir / "production_imgui_renderer_framebuffer_pack.json"
        )
        _write_signed_release_publication_manifest(
            evidence_dir / "signed_release_publication_manifest.json"
        )
        _write_full_homfly_certification_pack(
            evidence_dir / "full_homfly_pt_evaluation_certification_pack.json"
        )
        _write_full_alexander_certification_pack(
            evidence_dir
            / "full_multivariable_alexander_normalization_certification_pack.json"
        )

        exit_code = main(
            [
                "completion-evidence-directory-audit",
                str(evidence_dir),
                "--validation-output",
                str(validation_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)
        validation_payload = json.loads(validation_path.read_text(encoding="utf-8"))

    assert exit_code == 0
    assert payload["artifact_validation_requested"] is True
    assert payload["artifact_validation_performed"] is True
    assert payload["validation_output_requested"] is True
    assert payload["validation_output_written"] is True
    assert payload["validation_output_skipped_reason"] is None
    assert payload["validation_output_path"] == str(validation_path)
    assert validation_payload["method"] == "cross_workstream_validation_pack_audit"
    assert validation_payload["final_completion_ready"] is True
    assert validation_payload["final_completion_blocker_count"] == 0
    assert payload["completion_evidence_pipeline_ready"] is True


def test_cli_completion_evidence_directory_audit_reports_missing_inputs(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        evidence_dir = tmp_path / "partial-evidence"
        evidence_dir.mkdir()
        _write_verified_signed_crossing_assignment(
            evidence_dir / "verified_signed_crossing_assignment.L5a1.json",
            notation="L5a1",
            crossing_count=5,
        )

        exit_code = main(["completion-evidence-directory-audit", str(evidence_dir)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["bundle_inputs_complete"] is False
    assert payload["discovered_evidence_file_count"] == 1
    assert payload["present_input_count"] == 1
    assert payload["missing_input_count"] == 4
    assert payload["missing_inputs"] == [
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
    ]
    assert payload["missing_input_artifact_count"] == 4
    assert payload["missing_input_artifact_filenames"] == [
        "full_homfly_pt_evaluation_certification_pack.json",
        "full_multivariable_alexander_normalization_certification_pack.json",
        "production_imgui_renderer_framebuffer_pack.json",
        "signed_release_publication_manifest.json",
    ]
    missing_artifact_rows = {
        row["artifact_filename"]: row for row in payload["missing_input_artifact_rows"]
    }
    assert missing_artifact_rows[
        "production_imgui_renderer_framebuffer_pack.json"
    ]["producer_cli_argument"] == "--production-imgui-renderer-framebuffer-pack-json"
    assert missing_artifact_rows[
        "production_imgui_renderer_framebuffer_pack.json"
    ]["final_completion_failed_gates"] == [
        "non_diagram_requirements",
        "production_imgui_renderer",
    ]
    assert missing_artifact_rows[
        "production_imgui_renderer_framebuffer_pack.json"
    ]["final_completion_blocker_codes"] == [
        "native_imgui_screenshot_framebuffer_fixtures_partial",
        "production_imgui_renderer_not_verified",
    ]
    assert missing_artifact_rows[
        "full_homfly_pt_evaluation_certification_pack.json"
    ]["template_filename"] == "full_homfly_pt_evaluation_certification_pack.template.json"
    assert missing_artifact_rows[
        "signed_release_publication_manifest.json"
    ]["final_completion_failed_gate_signature"] == "release_artifacts"
    assert all(
        row["preflight_command"].endswith("--fail-on-not-certified")
        for row in payload["missing_input_artifact_rows"]
    )
    rows = {row["bundle_key"]: row for row in payload["discovered_inputs"]}
    assert rows["verified_signed_crossing_assignments"]["present"] is True
    assert rows["verified_signed_crossing_assignments"][
        "present_instance_filenames"
    ] == ["verified_signed_crossing_assignment.L5a1.json"]
    assert rows["verified_signed_crossing_assignments"][
        "missing_instance_filenames"
    ] == ["verified_signed_crossing_assignment.L6a4.json"]
    assert rows["verified_signed_crossing_assignments"][
        "instance_filename_coverage_complete"
    ] is False
    assert rows["signed_release_publication_manifest"]["present"] is False


def test_cli_completion_evidence_directory_audit_skips_bundle_output_when_incomplete(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        evidence_dir = tmp_path / "partial-evidence"
        bundle_path = tmp_path / "completion-evidence-bundle.json"
        evidence_dir.mkdir()
        _write_verified_signed_crossing_assignment(
            evidence_dir / "verified_signed_crossing_assignment.L5a1.json",
            notation="L5a1",
            crossing_count=5,
        )

        exit_code = main(
            [
                "completion-evidence-directory-audit",
                str(evidence_dir),
                "--bundle-output",
                str(bundle_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)
        bundle_exists = bundle_path.exists()

    assert exit_code == 0
    assert payload["bundle_inputs_complete"] is False
    assert payload["bundle_output_requested"] is True
    assert payload["bundle_output_written"] is False
    assert payload["bundle_output_skipped_reason"] == "missing_inputs"
    assert bundle_exists is False


def test_cli_completion_evidence_directory_audit_skips_validation_output_when_incomplete(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        evidence_dir = tmp_path / "partial-evidence"
        validation_path = tmp_path / "validation-pack-audit.json"
        evidence_dir.mkdir()
        _write_verified_signed_crossing_assignment(
            evidence_dir / "verified_signed_crossing_assignment.L5a1.json",
            notation="L5a1",
            crossing_count=5,
        )

        exit_code = main(
            [
                "completion-evidence-directory-audit",
                str(evidence_dir),
                "--validation-output",
                str(validation_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)
        validation_exists = validation_path.exists()

    assert exit_code == 0
    assert payload["bundle_inputs_complete"] is False
    assert payload["artifact_validation_requested"] is True
    assert payload["artifact_validation_performed"] is False
    assert payload["artifact_validation_skipped_reason"] == "missing_inputs"
    assert payload["validation_output_requested"] is True
    assert payload["validation_output_written"] is False
    assert payload["validation_output_skipped_reason"] == "missing_inputs"
    assert validation_exists is False


def test_cli_completion_evidence_directory_audit_skips_validation_when_incomplete(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        evidence_dir = tmp_path / "partial-evidence"
        evidence_dir.mkdir()
        _write_verified_signed_crossing_assignment(
            evidence_dir / "verified_signed_crossing_assignment.L5a1.json",
            notation="L5a1",
            crossing_count=5,
        )

        exit_code = main(
            [
                "completion-evidence-directory-audit",
                str(evidence_dir),
                "--validate-artifacts",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["bundle_inputs_complete"] is False
    assert payload["artifact_validation_requested"] is True
    assert payload["artifact_validation_performed"] is False
    assert payload["artifact_validation_skipped_reason"] == "missing_inputs"
    assert payload["artifact_validation_final_completion_ready"] is False
    assert payload["artifact_validation_final_completion_blocker_count"] is None
    assert payload["completion_evidence_pipeline_ready"] is False
    assert payload["completion_evidence_pipeline_blocker_count"] == 4
    assert payload["completion_evidence_pipeline_blocker_codes"] == [
        "artifact_preflight_not_certified",
        "artifact_validation_not_ready",
        "required_inputs_missing",
        "required_instance_files_missing",
    ]
    assert payload["completion_evidence_pipeline_blocker_code_counts"] == {
        "artifact_preflight_not_certified": 1,
        "artifact_validation_not_ready": 1,
        "required_instance_files_missing": 1,
        "required_inputs_missing": 1,
    }
    assert payload["completion_evidence_pipeline_blocker_signature"] == (
        "artifact_preflight_not_certified:1,artifact_validation_not_ready:1,"
        "required_inputs_missing:1,required_instance_files_missing:1"
    )
    pipeline_blockers = {
        row["step"]: row for row in payload["completion_evidence_pipeline_blockers"]
    }
    assert pipeline_blockers["discover_required_inputs"]["missing_input_count"] == 4
    assert pipeline_blockers["check_required_instance_files"][
        "missing_instance_filenames"
    ] == ["verified_signed_crossing_assignment.L6a4.json"]
    assert pipeline_blockers["preflight_discovered_artifacts"][
        "skipped_reason"
    ] == "missing_inputs"
    assert pipeline_blockers["validate_artifact_contents"][
        "artifact_validation_skipped_reason"
    ] == "missing_inputs"
    assert payload["pipeline_required_step_count"] == 3
    assert payload["pipeline_passed_required_step_count"] == 0
    assert payload["pipeline_failed_required_step_count"] == 3
    assert payload["pipeline_failed_required_steps"] == [
        "discover_required_inputs",
        "preflight_discovered_artifacts",
        "validate_artifact_contents",
    ]
    assert payload["pipeline_failed_required_step_signature"] == (
        "discover_required_inputs|preflight_discovered_artifacts|"
        "validate_artifact_contents"
    )
    assert payload["pipeline_skipped_required_step_count"] == 2
    pipeline_steps = {row["step"]: row for row in payload["pipeline_steps"]}
    assert pipeline_steps["discover_required_inputs"]["passed"] is False
    assert pipeline_steps["validate_artifact_contents"]["skipped_reason"] == (
        "missing_inputs"
    )


def test_cli_completion_evidence_requirements_lists_current_missing_artifacts(
    capsys,
) -> None:
    exit_code = main(["completion-evidence-requirements"])
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert (
        payload["artifact_kind"]
        == "cross_workstream_completion_evidence_requirements"
    )
    assert payload["claim_scope"] == (
        "cross_workstream_final_completion_evidence_requirements"
    )
    assert payload["final_completion_ready"] is False
    assert payload["final_completion_blocker_count"] == 7
    assert payload["final_completion_gate_count"] == 7
    assert payload["final_completion_passed_gate_count"] == 1
    assert payload["final_completion_failed_gate_count"] == 6
    assert payload["final_completion_blocker_count"] == 7
    assert payload["final_completion_blocker_code_count"] == 6
    assert payload["final_completion_blocker_code_counts"] == {
        "full_homfly_pt_evaluation_not_certified": 1,
        "full_multivariable_alexander_normalization_not_certified": 1,
        "native_imgui_screenshot_framebuffer_fixtures_partial": 1,
        "production_imgui_renderer_not_verified": 1,
        "release_artifacts_not_published": 1,
        "signed_pd_not_registered": 2,
    }
    assert payload["final_completion_blocker_signature"] == (
        "full_homfly_pt_evaluation_not_certified:1,"
        "full_multivariable_alexander_normalization_not_certified:1,"
        "native_imgui_screenshot_framebuffer_fixtures_partial:1,"
        "production_imgui_renderer_not_verified:1,"
        "release_artifacts_not_published:1,signed_pd_not_registered:2"
    )
    assert (
        payload["final_completion_missing_artifact_summary_consistency_matched"]
        is True
    )
    assert payload["final_completion_missing_artifact_count"] == 5
    assert payload["final_completion_missing_artifacts"] == [
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "verified_signed_crossing_assignment",
    ]
    assert payload["final_completion_missing_artifact_signature"] == (
        "full_homfly_pt_evaluation_certification_pack|"
        "full_multivariable_alexander_normalization_certification_pack|"
        "production_imgui_renderer_framebuffer_pack|"
        "signed_release_publication_manifest|verified_signed_crossing_assignment"
    )
    assert payload["required_artifact_count"] == 5
    assert payload["required_missing_artifacts"] == [
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "verified_signed_crossing_assignment",
    ]
    assert payload["required_missing_artifact_signature"] == (
        "full_homfly_pt_evaluation_certification_pack|"
        "full_multivariable_alexander_normalization_certification_pack|"
        "production_imgui_renderer_framebuffer_pack|"
        "signed_release_publication_manifest|verified_signed_crossing_assignment"
    )
    assert len(payload["artifact_preflight_commands"]) == 5
    assert len(payload["artifact_bundle_input_examples"]) == 5
    assert len(payload["artifact_template_filenames"]) == 5
    assert len(payload["artifact_producer_cli_arguments"]) == 5
    assert len(payload["artifact_audit_cli_arguments"]) == 5
    assert (
        "iroll completion-evidence-artifact-audit "
        "<verified_signed_crossing_assignment.json> "
        "--artifact-type verified_signed_crossing_assignment "
        "--fail-on-not-certified"
    ) in payload["artifact_preflight_commands"]
    assert (
        "iroll completion-evidence-bundle "
        "--verified-signed-crossing-assignment-json "
        "<verified_signed_crossing_assignment.json>"
    ) in payload["artifact_bundle_input_examples"]
    assert "verified_signed_crossing_assignment.template.json" in payload[
        "artifact_template_filenames"
    ]
    assert "--verified-signed-crossing-assignment-json" in payload[
        "artifact_producer_cli_arguments"
    ]
    assert "--full-homfly-pt-evaluation-certification-pack-json" in payload[
        "artifact_audit_cli_arguments"
    ]
    command_rows = {
        row["missing_artifact"]: row for row in payload["artifact_command_rows"]
    }
    assert payload["artifact_command_row_count"] == 5
    assert list(command_rows) == payload["required_missing_artifacts"]
    assert len(command_rows) == 5
    assert payload["expected_evidence_filename_count"] == 6
    assert payload["expected_evidence_filenames"] == [
        "full_homfly_pt_evaluation_certification_pack.json",
        "full_multivariable_alexander_normalization_certification_pack.json",
        "production_imgui_renderer_framebuffer_pack.json",
        "signed_release_publication_manifest.json",
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert "--verified-signed-crossing-assignment-json <verified_signed_crossing_assignment.L6a4.json>" in payload[
        "bundle_all_inputs_command"
    ]
    assert payload["directory_audit_command"] == (
        "iroll completion-evidence-directory-audit <evidence-directory> "
        "--validate-artifacts --bundle-output completion-evidence-bundle.json "
        "--validation-output validation-pack-audit.json --fail-on-not-ready"
    )
    assert payload["final_validation_command"] == (
        "iroll fixture-validation-pack-audit "
        "--completion-evidence-bundle-json completion-evidence-bundle.json "
        "--fail-on-not-ready"
    )
    assert [
        row["preflight_command"] for row in payload["artifact_command_rows"]
    ] == payload["artifact_preflight_commands"]
    assert [
        row["bundle_input_example"] for row in payload["artifact_command_rows"]
    ] == payload["artifact_bundle_input_examples"]
    assert [
        row["template_filename"] for row in payload["artifact_command_rows"]
    ] == payload["artifact_template_filenames"]
    assert command_rows["verified_signed_crossing_assignment"][
        "repeatable_instance_coverage_required"
    ] is True
    assert command_rows["verified_signed_crossing_assignment"][
        "required_instance_labels"
    ] == ["L5a1", "L6a4"]
    assert command_rows["verified_signed_crossing_assignment"][
        "producer_readiness_ready_count"
    ] == 0
    assert command_rows["verified_signed_crossing_assignment"][
        "producer_readiness_count"
    ] == 2
    assert command_rows["full_homfly_pt_evaluation_certification_pack"][
        "expected_artifact_kind"
    ] == "full_homfly_pt_evaluation_certification_pack"
    assert command_rows["full_homfly_pt_evaluation_certification_pack"][
        "producer_readiness_blockers"
    ] == [
        "arbitrary_signed_pd_coverage_certified",
        "certification_report_url",
        "counterexample_count_zero",
        "embedded_certification_report_available",
        "embedded_certification_report_replay_certified",
        "external_table_normalization_certified",
        "external_table_source_urls",
        "published_certification_report_witness_verified",
        "registered_fixture_regression_certified",
        "skein_relation_certified",
    ]
    assert payload["artifact_instance_command_row_count"] == 6
    instance_rows = {
        (row["missing_artifact"], row["instance_label"]): row
        for row in payload["artifact_instance_command_rows"]
    }
    assert set(instance_rows) == {
        ("full_homfly_pt_evaluation_certification_pack", None),
        ("full_multivariable_alexander_normalization_certification_pack", None),
        ("production_imgui_renderer_framebuffer_pack", None),
        ("signed_release_publication_manifest", None),
        ("verified_signed_crossing_assignment", "L5a1"),
        ("verified_signed_crossing_assignment", "L6a4"),
    }
    assert instance_rows[("verified_signed_crossing_assignment", "L5a1")][
        "artifact_filename"
    ] == "verified_signed_crossing_assignment.L5a1.json"
    assert instance_rows[("verified_signed_crossing_assignment", "L6a4")][
        "template_filename"
    ] == "verified_signed_crossing_assignment.L6a4.template.json"
    assert instance_rows[("verified_signed_crossing_assignment", "L6a4")][
        "template_to_artifact_filename"
    ] == "verified_signed_crossing_assignment.L6a4.json"
    assert instance_rows[("verified_signed_crossing_assignment", "L6a4")][
        "final_completion_failed_gates"
    ] == ["signed_diagram_fixture_registration"]
    assert instance_rows[("verified_signed_crossing_assignment", "L6a4")][
        "final_completion_blocker_labels"
    ] == ["L6a4"]
    assert instance_rows[("production_imgui_renderer_framebuffer_pack", None)][
        "final_completion_failed_gates"
    ] == ["non_diagram_requirements", "production_imgui_renderer"]
    assert instance_rows[("production_imgui_renderer_framebuffer_pack", None)][
        "final_completion_blocker_codes"
    ] == [
        "native_imgui_screenshot_framebuffer_fixtures_partial",
        "production_imgui_renderer_not_verified",
    ]
    assert "copy verified_signed_crossing_assignment.L6a4.template.json" in (
        instance_rows[("verified_signed_crossing_assignment", "L6a4")][
            "template_to_artifact_note"
        ]
    )
    assert instance_rows[("verified_signed_crossing_assignment", "L5a1")][
        "preflight_command"
    ] == (
        "iroll completion-evidence-artifact-audit "
        "<verified_signed_crossing_assignment.L5a1.json> "
        "--artifact-type verified_signed_crossing_assignment "
        "--fail-on-not-certified"
    )
    assert instance_rows[("verified_signed_crossing_assignment", "L6a4")][
        "bundle_input_example"
    ] == (
        "iroll completion-evidence-bundle "
        "--verified-signed-crossing-assignment-json "
        "<verified_signed_crossing_assignment.L6a4.json>"
    )
    assert (
        payload["final_completion_missing_artifacts"]
        == payload["required_missing_artifacts"]
    )
    assert (
        payload["final_completion_missing_artifact_signature"]
        == payload["required_missing_artifact_signature"]
    )
    assert payload["producer_readiness_available"] is True
    assert payload["producer_readiness_count"] == 6
    assert payload["producer_readiness_ready_count"] == 0
    assert payload["artifact_command_row_count"] == 5
    assert payload["artifact_instance_command_row_count"] == 6
    assert payload["expected_evidence_filename_count"] == 6
    assert "verified_signed_crossing_assignment.L6a4.json" in payload[
        "expected_evidence_filenames"
    ]
    assert payload["bundle_all_inputs_command"].endswith(
        "-o completion-evidence-bundle.json"
    )
    assert payload["producer_readiness_all_ready"] is False
    assert payload["producer_readiness_blocker_count"] == 34
    assert payload["producer_readiness_blockers"] == [
        "admissible_minor_normalization_certified",
        "all_admissible_minors_consistent",
        "arbitrary_signed_pd_coverage_certified",
        "artifact_urls",
        "certification_report_url",
        "counterexample_count_zero",
        "embedded_certification_report_available",
        "embedded_certification_report_replay_certified",
        "estimated_nonzero_pixels",
        "external_source_assignment_verified",
        "external_table_normalization_certified",
        "external_table_source_urls",
        "framebuffer_height",
        "framebuffer_touched",
        "framebuffer_width",
        "graphics_backend_name",
        "invariant_table_values_verified",
        "package_index_url",
        "passed",
        "platform_index_publication_claimed",
        "publication_claimed",
        "published_artifact_count",
        "published_certification_report_witness_verified",
        "real_graphics_backend_framebuffer_verified",
        "registered_fixture_regression_certified",
        "render_frame_count",
        "screenshot_url",
        "screenshot_verified",
        "signature_count",
        "signature_urls",
        "signed_pd_wirtinger_fox_certified",
        "signed_release_artifacts_published",
        "skein_relation_certified",
        "unique_sign_pattern",
    ]
    assert payload["producer_readiness_blocker_signature"] == "|".join(
        payload["producer_readiness_blockers"]
    )
    assert payload["producer_readiness_blocker_occurrence_count"] == 41
    assert payload["producer_readiness_blocker_code_counts"][
        "external_source_assignment_verified"
    ] == 2
    assert payload["producer_readiness_blocker_code_counts"][
        "invariant_table_values_verified"
    ] == 2
    assert payload["producer_readiness_blocker_code_counts"][
        "unique_sign_pattern"
    ] == 2
    assert payload["producer_readiness_blocker_code_counts"][
        "render_frame_count"
    ] == 1
    assert "external_source_assignment_verified:2" in payload[
        "producer_readiness_blocker_count_signature"
    ]
    assert payload["retained_evidence_available"] is True
    assert payload["retained_evidence_readiness_row_count"] == 4
    assert payload["retained_evidence_count"] == 10
    assert payload["retained_evidence_distinct_count"] == 8
    assert payload["retained_evidence_ids"] == [
        "alexander_generated_signed_pd_coverage_report",
        "alexander_registered_fixture_acceptance_report",
        "homfly_registered_fixture_acceptance_report",
        "homfly_small_diagram_generated_coverage_report",
        "imgui_real_kernel_loader_smoke_retained_pack",
        "imgui_test_stub_framebuffer_smoke_retained_pack",
        "imgui_windows_retained_artifacts_manifest",
        "rust_wheel_retained_metadata_manifest",
    ]
    assert payload["retained_evidence_kinds"] == [
        "ci_retained_artifact",
        "repository_test",
    ]
    assert payload["retained_evidence_repository_test_count"] == 4
    assert payload["retained_evidence_ci_retained_artifact_count"] == 6
    assert payload["retained_evidence_registered_fixture_scope_count"] == 2
    assert payload["retained_evidence_bounded_scope_count"] == 2
    assert payload["retained_evidence_completion_claimed_count"] == 0
    assert payload["retained_evidence_signed_release_artifacts_published_count"] == 0
    assert payload["retained_evidence_publication_claimed_count"] == 0
    assert payload["retained_evidence_platform_index_publication_claimed_count"] == 0
    assert (
        payload["retained_evidence_real_graphics_backend_framebuffer_verified_count"]
        == 0
    )
    assert payload["retained_evidence_screenshot_verified_count"] == 0
    assert payload["repeatable_instance_coverage_required"] is True
    assert payload["required_instance_count"] == 2
    assert payload["required_instance_labels"] == ["L5a1", "L6a4"]
    rows = {
        row["missing_artifact"]: row
        for row in payload["required_artifacts"]
    }
    assert rows["verified_signed_crossing_assignment"]["repeatable"] is True
    assert rows["verified_signed_crossing_assignment"][
        "repeatable_instance_coverage_required"
    ] is True
    assert rows["verified_signed_crossing_assignment"]["required_instance_count"] == 2
    assert rows["verified_signed_crossing_assignment"]["required_instance_labels"] == [
        "L5a1",
        "L6a4",
    ]
    assert rows["verified_signed_crossing_assignment"]["bundle_key"] == (
        "verified_signed_crossing_assignments"
    )
    assert rows["verified_signed_crossing_assignment"]["producer_cli_argument"] == (
        "--verified-signed-crossing-assignment-json"
    )
    assert rows["verified_signed_crossing_assignment"]["template_filename"] == (
        "verified_signed_crossing_assignment.template.json"
    )
    assert rows["verified_signed_crossing_assignment"]["preflight_command"] == (
        "iroll completion-evidence-artifact-audit "
        "<verified_signed_crossing_assignment.json> "
        "--artifact-type verified_signed_crossing_assignment "
        "--fail-on-not-certified"
    )
    assert rows["verified_signed_crossing_assignment"]["bundle_input_example"] == (
        "iroll completion-evidence-bundle "
        "--verified-signed-crossing-assignment-json "
        "<verified_signed_crossing_assignment.json>"
    )
    assert rows["verified_signed_crossing_assignment"][
        "producer_readiness_available"
    ] is True
    assert rows["verified_signed_crossing_assignment"]["producer_readiness_count"] == 2
    assert rows["verified_signed_crossing_assignment"][
        "producer_readiness_ready_count"
    ] == 0
    assert rows["verified_signed_crossing_assignment"][
        "producer_readiness_blockers"
    ] == [
        "external_source_assignment_verified",
        "invariant_table_values_verified",
        "unique_sign_pattern",
    ]
    readiness_rows = {
        row["notation"]: row
        for row in rows["verified_signed_crossing_assignment"][
            "producer_readiness"
        ]
    }
    assert readiness_rows["L5a1"]["claim_scope"] == (
        "verified_signed_crossing_assignment_readiness"
    )
    assert readiness_rows["L5a1"]["passed_check_count"] == 3
    assert readiness_rows["L5a1"]["failed_check_count"] == 3
    assert readiness_rows["L5a1"]["checks"] == {
        "source_url_available": True,
        "complete_candidate_set": True,
        "unique_sign_pattern": False,
        "source_candidate_replay_valid": True,
        "invariant_table_values_verified": False,
        "external_source_assignment_verified": False,
    }
    assert readiness_rows["L5a1"]["source_candidate_evidence_available"] is True
    assert readiness_rows["L5a1"]["matching_candidate_count"] == 24
    assert readiness_rows["L5a1"]["returned_candidate_count"] == 24
    assert readiness_rows["L5a1"]["unique_sign_pattern_count"] == 12
    assert readiness_rows["L5a1"]["mirror_pair_count"] == 6
    assert readiness_rows["L5a1"]["complete_candidate_set"] is True
    assert readiness_rows["L5a1"]["all_returned_candidates_have_valid_replay"] is True
    assert readiness_rows["L5a1"]["replay_checked_candidate_count"] == 24
    assert readiness_rows["L5a1"]["replay_valid_replay_count"] == 24
    assert readiness_rows["L5a1"]["registration_blocker_code"] == (
        "source_candidate_not_unique"
    )
    assert readiness_rows["L6a4"]["blockers"] == [
        "unique_sign_pattern",
        "invariant_table_values_verified",
        "external_source_assignment_verified",
    ]
    assert readiness_rows["L6a4"]["matching_candidate_count"] == 8
    assert readiness_rows["L6a4"]["unique_sign_pattern_count"] == 8
    assert readiness_rows["L6a4"]["candidate_group_count"] == 1
    assert readiness_rows["L6a4"]["stable_invariants"] == ["jones"]
    assert readiness_rows["L6a4"]["stable_invariant_count"] == 1
    assert readiness_rows["L6a4"]["target_pairwise_linking"] == [0.0, 0.0, 0.0]
    assert readiness_rows["L6a4"]["unique_candidate"] is False
    assert rows["production_imgui_renderer_framebuffer_pack"][
        "blocker_count"
    ] == 2
    assert rows["production_imgui_renderer_framebuffer_pack"][
        "producer_cli_argument"
    ] == "--production-imgui-renderer-framebuffer-pack-json"
    assert rows["production_imgui_renderer_framebuffer_pack"][
        "preflight_command"
    ] == (
        "iroll completion-evidence-artifact-audit "
        "<production_imgui_renderer_framebuffer_pack.json> "
        "--artifact-type production_imgui_renderer_framebuffer_pack "
        "--fail-on-not-certified"
    )
    assert rows["signed_release_publication_manifest"][
        "expected_claim_scope"
    ] == "signed_release_publication"
    assert rows["full_homfly_pt_evaluation_certification_pack"][
        "bundle_key"
    ] == "full_homfly_pt_evaluation_certification_pack"
    homfly_readiness = rows["full_homfly_pt_evaluation_certification_pack"][
        "producer_readiness"
    ][0]
    assert homfly_readiness["retained_evidence_ids"] == [
        "homfly_registered_fixture_acceptance_report",
        "homfly_small_diagram_generated_coverage_report",
    ]
    assert homfly_readiness["retained_evidence_kinds"] == ["repository_test"]
    assert homfly_readiness["retained_evidence_repository_test_count"] == 2
    assert homfly_readiness["retained_evidence_ci_retained_artifact_count"] == 0
    assert homfly_readiness["retained_evidence_registered_fixture_scope_count"] == 1
    assert homfly_readiness["retained_evidence_bounded_scope_count"] == 1
    assert homfly_readiness["retained_evidence_completion_claimed_count"] == 0
    assert rows["full_multivariable_alexander_normalization_certification_pack"][
        "expected_artifact_kind"
    ] == "full_multivariable_alexander_normalization_certification_pack"
    alexander_readiness = rows[
        "full_multivariable_alexander_normalization_certification_pack"
    ]["producer_readiness"][0]
    assert alexander_readiness["retained_evidence_ids"] == [
        "alexander_generated_signed_pd_coverage_report",
        "alexander_registered_fixture_acceptance_report",
    ]
    assert alexander_readiness["retained_evidence_kinds"] == ["repository_test"]
    assert alexander_readiness["retained_evidence_repository_test_count"] == 2
    assert alexander_readiness["retained_evidence_ci_retained_artifact_count"] == 0
    assert alexander_readiness["retained_evidence_registered_fixture_scope_count"] == 1
    assert alexander_readiness["retained_evidence_bounded_scope_count"] == 1
    assert alexander_readiness["retained_evidence_completion_claimed_count"] == 0
    assert rows["production_imgui_renderer_framebuffer_pack"][
        "producer_readiness_available"
    ] is True
    assert rows["production_imgui_renderer_framebuffer_pack"][
        "producer_readiness_blockers"
    ] == [
        "estimated_nonzero_pixels",
        "framebuffer_height",
        "framebuffer_touched",
        "framebuffer_width",
        "graphics_backend_name",
        "passed",
        "real_graphics_backend_framebuffer_verified",
        "render_frame_count",
        "screenshot_url",
        "screenshot_verified",
    ]
    production_readiness = rows["production_imgui_renderer_framebuffer_pack"][
        "producer_readiness"
    ][0]
    assert production_readiness["retained_evidence_available"] is True
    assert production_readiness["retained_evidence_count"] == 4
    assert production_readiness["retained_evidence_distinct_count"] == 2
    assert production_readiness["retained_evidence_ids"] == [
        "imgui_real_kernel_loader_smoke_retained_pack",
        "imgui_test_stub_framebuffer_smoke_retained_pack",
    ]
    assert production_readiness["retained_evidence_source_methods"] == [
        "imgui_real_kernel_loader_smoke",
        "imgui_test_stub_framebuffer_smoke",
    ]
    assert (
        production_readiness[
            "retained_evidence_real_graphics_backend_framebuffer_verified_count"
        ]
        == 0
    )
    assert production_readiness["retained_evidence_screenshot_verified_count"] == 0
    assert production_readiness["retained_evidence_completion_claimed_count"] == 0
    release_readiness = rows["signed_release_publication_manifest"][
        "producer_readiness"
    ][0]
    assert release_readiness["claim_scope"] == (
        "completion_evidence_artifact_producer_readiness"
    )
    assert release_readiness["failed_check_count"] == 8
    assert release_readiness["retained_evidence_available"] is True
    assert release_readiness["retained_evidence_count"] == 2
    assert release_readiness["retained_evidence_distinct_count"] == 2
    assert release_readiness["retained_evidence_ids"] == [
        "imgui_windows_retained_artifacts_manifest",
        "rust_wheel_retained_metadata_manifest",
    ]
    assert release_readiness["retained_evidence_source_methods"] == [
        "imgui_windows_retained_artifacts_manifest",
        "rust_wheel_retained_metadata_manifest",
    ]
    assert (
        release_readiness[
            "retained_evidence_signed_release_artifacts_published_count"
        ]
        == 0
    )
    assert release_readiness["retained_evidence_publication_claimed_count"] == 0
    assert (
        release_readiness[
            "retained_evidence_platform_index_publication_claimed_count"
        ]
        == 0
    )
    assert release_readiness["retained_evidence_completion_claimed_count"] == 0
    assert rows["signed_release_publication_manifest"][
        "producer_readiness_blockers"
    ] == [
        "artifact_urls",
        "package_index_url",
        "platform_index_publication_claimed",
        "publication_claimed",
        "published_artifact_count",
        "signature_count",
        "signature_urls",
        "signed_release_artifacts_published",
    ]
    assert rows["full_homfly_pt_evaluation_certification_pack"][
        "producer_readiness_blockers"
    ] == [
        "arbitrary_signed_pd_coverage_certified",
        "certification_report_url",
        "counterexample_count_zero",
        "embedded_certification_report_available",
        "embedded_certification_report_replay_certified",
        "external_table_normalization_certified",
        "external_table_source_urls",
        "published_certification_report_witness_verified",
        "registered_fixture_regression_certified",
        "skein_relation_certified",
    ]
    assert rows["full_multivariable_alexander_normalization_certification_pack"][
        "producer_readiness_blockers"
    ] == [
        "admissible_minor_normalization_certified",
        "all_admissible_minors_consistent",
        "certification_report_url",
        "counterexample_count_zero",
        "external_table_normalization_certified",
        "external_table_source_urls",
        "signed_pd_wirtinger_fox_certified",
    ]
    assert payload["bundle_producer_command"] == "iroll completion-evidence-bundle"
    assert "--completion-evidence-bundle-json" in payload["bundle_audit_command"]


def test_cli_completion_evidence_ci_plan_lists_hard_gate_commands(capsys) -> None:
    exit_code = main(["completion-evidence-ci-plan"])
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["artifact_kind"] == "cross_workstream_completion_evidence_ci_plan"
    assert payload["claim_scope"] == (
        "cross_workstream_final_completion_evidence_ci_plan"
    )
    assert payload["final_completion_ready"] is False
    assert payload["final_completion_blocker_count"] == 7
    assert payload["final_completion_gate_count"] == 7
    assert payload["final_completion_failed_gate_count"] == 6
    assert payload["final_completion_failed_gates"] == [
        "signed_diagram_fixture_registration",
        "non_diagram_requirements",
        "full_homfly_pt_evaluation",
        "full_multivariable_alexander_normalization",
        "production_imgui_renderer",
        "release_artifacts",
    ]
    assert payload["final_completion_failed_gate_signature"] == (
        "signed_diagram_fixture_registration|non_diagram_requirements|"
        "full_homfly_pt_evaluation|"
        "full_multivariable_alexander_normalization|"
        "production_imgui_renderer|release_artifacts"
    )
    assert payload["final_completion_blocker_code_count"] == 6
    assert payload["final_completion_blocker_code_counts"] == {
        "full_homfly_pt_evaluation_not_certified": 1,
        "full_multivariable_alexander_normalization_not_certified": 1,
        "native_imgui_screenshot_framebuffer_fixtures_partial": 1,
        "production_imgui_renderer_not_verified": 1,
        "release_artifacts_not_published": 1,
        "signed_pd_not_registered": 2,
    }
    assert "signed_pd_not_registered:2" in payload[
        "final_completion_blocker_signature"
    ]
    assert (
        payload["final_completion_missing_artifact_summary_consistency_matched"]
        is True
    )
    assert payload["final_completion_missing_artifact_count"] == 5
    assert payload["final_completion_missing_artifacts"] == [
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "verified_signed_crossing_assignment",
    ]
    assert payload["final_completion_missing_artifact_signature"] == (
        "full_homfly_pt_evaluation_certification_pack|"
        "full_multivariable_alexander_normalization_certification_pack|"
        "production_imgui_renderer_framebuffer_pack|"
        "signed_release_publication_manifest|verified_signed_crossing_assignment"
    )
    assert payload["required_artifact_count"] == 5
    assert payload["required_missing_artifacts"] == [
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "verified_signed_crossing_assignment",
    ]
    assert payload["required_missing_artifact_signature"] == (
        "full_homfly_pt_evaluation_certification_pack|"
        "full_multivariable_alexander_normalization_certification_pack|"
        "production_imgui_renderer_framebuffer_pack|"
        "signed_release_publication_manifest|verified_signed_crossing_assignment"
    )
    assert (
        payload["final_completion_missing_artifacts"]
        == payload["required_missing_artifacts"]
    )
    assert (
        payload["final_completion_missing_artifact_signature"]
        == payload["required_missing_artifact_signature"]
    )
    assert payload["producer_readiness_available"] is True
    assert payload["producer_readiness_count"] == 6
    assert payload["producer_readiness_ready_count"] == 0
    assert payload["producer_readiness_all_ready"] is False
    assert payload["producer_readiness_blocker_count"] == 34
    assert payload["producer_readiness_blocker_signature"] == "|".join(
        payload["producer_readiness_blockers"]
    )
    assert payload["producer_readiness_blocker_occurrence_count"] == 41
    assert payload["producer_readiness_blocker_code_counts"][
        "external_source_assignment_verified"
    ] == 2
    assert payload["producer_readiness_blocker_code_counts"][
        "unique_sign_pattern"
    ] == 2
    assert payload["retained_evidence_available"] is True
    assert payload["retained_evidence_count"] == 10
    assert payload["retained_evidence_distinct_count"] == 8
    assert payload["retained_evidence_repository_test_count"] == 4
    assert payload["retained_evidence_ci_retained_artifact_count"] == 6
    assert payload["retained_evidence_completion_claimed_count"] == 0
    assert payload["repeatable_instance_coverage_required"] is True
    assert payload["required_instance_count"] == 2
    assert payload["required_instance_labels"] == ["L5a1", "L6a4"]
    assert payload["plan_step_count"] == 13
    assert payload["required_plan_step_count"] == 11
    steps = {row["step"]: row for row in payload["plan_steps"]}
    assert payload["hard_gate_step_count"] == 3
    assert payload["hard_gate_steps"] == [
        "preflight_external_artifacts",
        "audit_directory",
        "audit_bundle",
    ]
    assert "--fail-on-not-certified" in steps["preflight_external_artifacts"][
        "command"
    ]
    assert "--fail-on-not-ready" in steps[
        "preflight_signed_assignment_readiness"
    ]["command"]
    assert "--fail-on-not-ready" in steps[
        "preflight_production_imgui_framebuffer_readiness"
    ]["command"]
    assert "--fail-on-not-ready" in steps[
        "preflight_signed_release_publication_readiness"
    ]["command"]
    assert "--fail-on-not-ready" in steps[
        "preflight_full_homfly_pt_evaluation_readiness"
    ]["command"]
    assert "--fail-on-not-ready" in steps[
        "preflight_full_multivariable_alexander_normalization_readiness"
    ]["command"]
    assert "--fail-on-not-ready" in steps["audit_directory"]["command"]
    assert "--fail-on-not-ready" in steps["audit_bundle"]["command"]
    assert steps["preflight_signed_assignment_readiness"]["hard_gate"] is False
    assert steps["publish_review_bundle"]["hard_gate"] is False
    assert steps["preflight_production_imgui_framebuffer_readiness"][
        "hard_gate"
    ] is False
    assert steps["preflight_signed_release_publication_readiness"][
        "hard_gate"
    ] is False
    assert steps["preflight_full_homfly_pt_evaluation_readiness"][
        "hard_gate"
    ] is False
    assert steps[
        "preflight_full_multivariable_alexander_normalization_readiness"
    ]["hard_gate"] is False
    assert steps["preflight_external_artifacts"]["hard_gate"] is True
    assert steps["audit_directory"]["hard_gate"] is True
    assert steps["audit_bundle"]["hard_gate"] is True
    assert steps["preflight_signed_assignment_readiness"][
        "expected_output_artifact_kind"
    ] == "verified_signed_crossing_assignment_readiness_report"
    assert steps["preflight_signed_assignment_readiness"][
        "expected_output_claim_scope"
    ] == "verified_signed_crossing_assignment_readiness"
    assert steps["preflight_signed_assignment_readiness"]["ready_field"] == (
        "readiness_all_ready"
    )
    assert steps["preflight_signed_assignment_readiness"][
        "required_ready_fields"
    ] == [
        "readiness_all_ready",
        "readiness_blocker_codes",
        "readiness_blocker_signature",
    ]
    assert steps["preflight_signed_assignment_readiness"]["ready_when"] == (
        "true_only_after_each_required_unsigned_source_fixture_has_a_"
        "unique_externally_verified_assignment"
    )
    assert steps["preflight_signed_assignment_readiness"]["failure_mode"] == (
        "exit_1_with_fail_on_not_ready"
    )
    assert steps["publish_review_bundle"]["expected_output_artifact_kind"] == (
        "cross_workstream_completion_evidence_review_bundle"
    )
    assert steps["publish_review_bundle"]["expected_output_claim_scope"] == (
        "cross_workstream_final_completion_evidence_review"
    )
    assert payload["review_bundle_directory"] == (
        "<evidence-dir>/completion-evidence-review-bundle"
    )
    assert payload["review_bundle_index_filename"] == (
        "completion-evidence-review-index.json"
    )
    assert payload["review_bundle_index_path"] == (
        "<evidence-dir>/completion-evidence-review-bundle/"
        "completion-evidence-review-index.json"
    )
    assert " -o " in steps["publish_review_bundle"]["command"]
    assert steps["publish_review_bundle"]["command"].endswith(
        payload["review_bundle_index_path"]
    )
    assert steps["publish_review_bundle"]["expected_output_index_filename"] == (
        payload["review_bundle_index_filename"]
    )
    assert steps["publish_review_bundle"]["expected_output_index_path"] == (
        payload["review_bundle_index_path"]
    )
    assert steps["publish_review_bundle"]["ready_field"] == "completion_claimed"
    assert steps["publish_review_bundle"]["required_ready_fields"] == [
        "completion_claimed"
    ]
    assert steps["publish_review_bundle"]["ready_when"] == (
        "false_review_handoff_bundle"
    )
    assert steps["publish_review_bundle"]["failure_mode"] == "report_only"
    assert steps["preflight_production_imgui_framebuffer_readiness"][
        "expected_output_artifact_kind"
    ] == "production_imgui_renderer_framebuffer_readiness_report"
    assert steps["preflight_production_imgui_framebuffer_readiness"][
        "expected_output_claim_scope"
    ] == "production_imgui_renderer_framebuffer_readiness"
    assert steps["preflight_production_imgui_framebuffer_readiness"][
        "ready_field"
    ] == "readiness_all_ready"
    assert steps["preflight_production_imgui_framebuffer_readiness"][
        "required_ready_fields"
    ] == [
        "readiness_all_ready",
        "readiness_blocker_codes",
        "readiness_blocker_signature",
        "retained_real_graphics_backend_framebuffer_verified_count",
        "retained_screenshot_verified_count",
    ]
    assert steps["preflight_production_imgui_framebuffer_readiness"][
        "ready_when"
    ] == (
        "true_only_after_a_real_graphics_backend_framebuffer_and_"
        "screenshot_are_verified"
    )
    assert steps["preflight_production_imgui_framebuffer_readiness"][
        "failure_mode"
    ] == "exit_1_with_fail_on_not_ready"
    assert steps["preflight_signed_release_publication_readiness"][
        "expected_output_artifact_kind"
    ] == "signed_release_publication_readiness_report"
    assert steps["preflight_signed_release_publication_readiness"][
        "expected_output_claim_scope"
    ] == "signed_release_publication_readiness"
    assert steps["preflight_signed_release_publication_readiness"][
        "ready_field"
    ] == "readiness_all_ready"
    assert steps["preflight_signed_release_publication_readiness"][
        "required_ready_fields"
    ] == [
        "readiness_all_ready",
        "readiness_blocker_codes",
        "readiness_blocker_signature",
        "retained_signed_release_artifacts_published_count",
        "retained_publication_claimed_count",
        "retained_platform_index_publication_claimed_count",
    ]
    assert steps["preflight_signed_release_publication_readiness"][
        "ready_when"
    ] == "true_only_after_signed_artifacts_and_platform_index_are_published"
    assert steps["preflight_signed_release_publication_readiness"][
        "failure_mode"
    ] == "exit_1_with_fail_on_not_ready"
    assert steps["preflight_full_homfly_pt_evaluation_readiness"][
        "expected_output_artifact_kind"
    ] == "full_homfly_pt_evaluation_readiness_report"
    assert steps["preflight_full_homfly_pt_evaluation_readiness"][
        "expected_output_claim_scope"
    ] == "full_homfly_pt_evaluation_readiness"
    assert steps["preflight_full_homfly_pt_evaluation_readiness"][
        "ready_field"
    ] == "readiness_all_ready"
    assert steps["preflight_full_homfly_pt_evaluation_readiness"][
        "required_ready_fields"
    ] == [
        "readiness_all_ready",
        "readiness_blocker_codes",
        "readiness_blocker_signature",
        "retained_repository_test_count",
        "retained_registered_fixture_scope_count",
        "retained_bounded_scope_count",
    ]
    assert steps["preflight_full_homfly_pt_evaluation_readiness"][
        "ready_when"
    ] == "true_only_after_full_homfly_pt_evaluation_certification_pack_is_certified"
    assert steps["preflight_full_homfly_pt_evaluation_readiness"][
        "failure_mode"
    ] == "exit_1_with_fail_on_not_ready"
    assert steps[
        "preflight_full_multivariable_alexander_normalization_readiness"
    ]["expected_output_artifact_kind"] == (
        "full_multivariable_alexander_normalization_readiness_report"
    )
    assert steps[
        "preflight_full_multivariable_alexander_normalization_readiness"
    ]["expected_output_claim_scope"] == (
        "full_multivariable_alexander_normalization_readiness"
    )
    assert steps[
        "preflight_full_multivariable_alexander_normalization_readiness"
    ]["ready_field"] == "readiness_all_ready"
    assert steps[
        "preflight_full_multivariable_alexander_normalization_readiness"
    ]["required_ready_fields"] == [
        "readiness_all_ready",
        "readiness_blocker_codes",
        "readiness_blocker_signature",
        "retained_repository_test_count",
        "retained_registered_fixture_scope_count",
        "retained_bounded_scope_count",
    ]
    assert steps[
        "preflight_full_multivariable_alexander_normalization_readiness"
    ]["ready_when"] == (
        "true_only_after_full_multivariable_alexander_normalization_"
        "certification_pack_is_certified"
    )
    assert steps[
        "preflight_full_multivariable_alexander_normalization_readiness"
    ]["failure_mode"] == "exit_1_with_fail_on_not_ready"
    assert steps["preflight_external_artifacts"]["expected_output_artifact_kind"] == (
        "completion_evidence_artifact_audit"
    )
    assert steps["preflight_external_artifacts"]["expected_output_claim_scope"] == (
        "completion_evidence_artifact_preflight"
    )
    assert steps["preflight_external_artifacts"]["ready_field"] == (
        "artifact_certified"
    )
    assert steps["preflight_external_artifacts"]["required_ready_fields"] == [
        "artifact_certified",
        "artifact_field_coverage_complete",
    ]
    assert steps["preflight_external_artifacts"]["ready_when"] == (
        "true_when_each_required_artifact_preflight_certified"
    )
    assert steps["preflight_external_artifacts"]["failure_mode"] == (
        "exit_1_with_fail_on_not_certified"
    )
    assert steps["audit_directory"]["expected_output_artifact_kind"] == (
        "cross_workstream_completion_evidence_directory_audit"
    )
    assert steps["audit_directory"]["expected_output_claim_scope"] == (
        "cross_workstream_final_completion_evidence_directory_audit"
    )
    assert steps["audit_directory"]["ready_field"] == (
        "completion_evidence_pipeline_ready"
    )
    assert steps["audit_directory"]["required_ready_fields"] == [
        "completion_evidence_pipeline_ready",
        "artifact_preflight_all_certified",
        "artifact_preflight_field_coverage_complete",
        "artifact_preflight_contract_coverage_complete",
        "artifact_validation_final_completion_ready",
        "instance_filename_coverage_complete",
        "pipeline_failed_required_step_signature",
        "completion_evidence_pipeline_blocker_signature",
    ]
    assert steps["audit_directory"]["ready_when"] == (
        "true_when_discovery_and_validation_pass"
    )
    assert steps["audit_directory"]["failure_mode"] == (
        "exit_1_with_fail_on_not_ready"
    )
    assert steps["audit_bundle"]["expected_output_artifact_kind"] == (
        "cross_workstream_validation_pack_audit"
    )
    assert steps["audit_bundle"]["expected_output_claim_scope"] == (
        "final_completion_checklist_metadata_audit"
    )
    assert steps["audit_bundle"]["ready_field"] == "final_completion_ready"
    assert steps["audit_bundle"]["required_ready_fields"] == [
        "final_completion_ready",
        "completion_evidence_bundle_certified",
        "artifact_preflight_field_coverage_complete",
        "bundle_contract_coverage_complete",
        "bundle_evidence_failed_check_signature",
    ]
    assert steps["audit_bundle"]["ready_when"] == (
        "true_when_all_final_gates_pass"
    )
    assert steps["audit_bundle"]["failure_mode"] == "exit_1_with_fail_on_not_ready"
    assert payload["hard_gate_commands"] == [
        steps["preflight_external_artifacts"]["command"],
        steps["audit_directory"]["command"],
        steps["audit_bundle"]["command"],
    ]
    assert payload["expected_output_artifact_kinds"] == [
        row["expected_output_artifact_kind"] for row in payload["plan_steps"]
    ]
    assert payload["ready_check_fields"] == [
        row["ready_field"] for row in payload["plan_steps"]
    ]
    assert payload["required_ready_field_sets"] == [
        row["required_ready_fields"] for row in payload["plan_steps"]
    ]
    assert "artifact_preflight_contract_coverage_complete" in payload[
        "required_ready_fields"
    ]
    assert "artifact_field_coverage_complete" in payload["required_ready_fields"]
    assert "artifact_preflight_field_coverage_complete" in payload[
        "required_ready_fields"
    ]
    assert "instance_filename_coverage_complete" in payload["required_ready_fields"]
    assert "bundle_contract_coverage_complete" in payload["required_ready_fields"]
    assert "bundle_evidence_failed_check_signature" in payload[
        "required_ready_fields"
    ]
    assert "completion_evidence_bundle_certified" in payload[
        "required_ready_fields"
    ]
    assert "completion_evidence_pipeline_blocker_signature" in payload[
        "required_ready_fields"
    ]
    assert "pipeline_failed_required_step_signature" in payload[
        "required_ready_fields"
    ]
    assert "retained_repository_test_count" in payload["required_ready_fields"]
    assert "retained_registered_fixture_scope_count" in payload[
        "required_ready_fields"
    ]
    assert "retained_bounded_scope_count" in payload["required_ready_fields"]
    assert "readiness_all_ready" in payload["required_ready_fields"]
    assert "readiness_blocker_codes" in payload["required_ready_fields"]
    assert "readiness_blocker_signature" in payload["required_ready_fields"]
    assert "retained_real_graphics_backend_framebuffer_verified_count" in payload[
        "required_ready_fields"
    ]
    assert "retained_screenshot_verified_count" in payload[
        "required_ready_fields"
    ]
    assert "retained_signed_release_artifacts_published_count" in payload[
        "required_ready_fields"
    ]
    assert "retained_publication_claimed_count" in payload[
        "required_ready_fields"
    ]
    assert "retained_platform_index_publication_claimed_count" in payload[
        "required_ready_fields"
    ]
    ci_instance_rows = {
        (row["missing_artifact"], row["instance_label"]): row
        for row in payload["artifact_instance_command_rows"]
    }
    assert ci_instance_rows[("verified_signed_crossing_assignment", "L6a4")][
        "final_completion_failed_gates"
    ] == ["signed_diagram_fixture_registration"]
    assert ci_instance_rows[("verified_signed_crossing_assignment", "L6a4")][
        "final_completion_blocker_labels"
    ] == ["L6a4"]
    assert ci_instance_rows[("production_imgui_renderer_framebuffer_pack", None)][
        "final_completion_failed_gate_count"
    ] == 2
    assert ci_instance_rows[("production_imgui_renderer_framebuffer_pack", None)][
        "final_completion_blocker_codes"
    ] == [
        "native_imgui_screenshot_framebuffer_fixtures_partial",
        "production_imgui_renderer_not_verified",
    ]
    assert payload["completion_claimed"] is False


def test_cli_completion_evidence_review_bundle_writes_current_audit_pack(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        bundle_dir = tmp_path / "completion-review"
        index_path = bundle_dir / "completion-evidence-review-index.json"
        exit_code = main(
            [
                "completion-evidence-review-bundle",
                str(bundle_dir),
                "-o",
                str(index_path),
            ]
        )
        assert capsys.readouterr().out == ""
        payload = json.loads(index_path.read_text(encoding="utf-8"))

        assert exit_code == 0
        assert index_path.exists()
        assert payload["artifact_kind"] == (
            "cross_workstream_completion_evidence_review_bundle"
        )
        assert payload["claim_scope"] == (
            "cross_workstream_final_completion_evidence_review"
        )
        assert payload["completion_claimed"] is False
        assert payload["final_completion_ready"] is False
        assert payload["final_completion_failed_gate_signature"] == (
            "signed_diagram_fixture_registration|non_diagram_requirements|"
            "full_homfly_pt_evaluation|"
            "full_multivariable_alexander_normalization|"
            "production_imgui_renderer|release_artifacts"
        )
        assert payload["final_completion_blocker_code_counts"] == {
            "signed_pd_not_registered": 2,
            "native_imgui_screenshot_framebuffer_fixtures_partial": 1,
            "full_homfly_pt_evaluation_not_certified": 1,
            "full_multivariable_alexander_normalization_not_certified": 1,
            "production_imgui_renderer_not_verified": 1,
            "release_artifacts_not_published": 1,
        }
        assert payload["final_completion_missing_artifact_signature"] == (
            "full_homfly_pt_evaluation_certification_pack|"
            "full_multivariable_alexander_normalization_certification_pack|"
            "production_imgui_renderer_framebuffer_pack|"
            "signed_release_publication_manifest|"
            "verified_signed_crossing_assignment"
        )
        assert payload["required_artifact_count"] == 5
        assert payload["producer_readiness_count"] == 6
        assert payload["producer_readiness_ready_count"] == 0
        assert payload["artifact_command_row_count"] == 5
        assert payload["artifact_instance_command_row_count"] == 6
        assert payload["expected_evidence_filename_count"] == 6
        assert "verified_signed_crossing_assignment.L6a4.json" in payload[
            "expected_evidence_filenames"
        ]
        assert "--fail-on-not-ready" in payload["final_validation_command"]
        assert payload["producer_readiness_blocker_occurrence_count"] == 41
        assert payload["producer_readiness_blocker_code_counts"][
            "external_source_assignment_verified"
        ] == 2
        assert payload["producer_readiness_blocker_code_counts"][
            "unique_sign_pattern"
        ] == 2
        assert payload["generated_report_count"] == 15
        assert payload["source_candidate_diagnostic_count"] == 2
        assert payload["source_candidate_diagnostic_files"] == [
            "source-invariant-l5a1-candidates.json",
            "source-invariant-l6a4-candidates.json",
        ]
        assert payload["source_table_diagnostic_count"] == 2
        assert payload["source_table_diagnostic_files"] == [
            "source-table-l5a1-audit.json",
            "source-table-l6a4-audit.json",
        ]
        rows = {row["filename"]: row for row in payload["generated_reports"]}
        expected_files = {
            "completion-evidence-requirements.json",
            "completion-evidence-contracts.json",
            "completion-evidence-ci-plan.json",
            "completion-evidence-templates.json",
            "completion-evidence-template-directory-audit.json",
            "validation-pack-audit.json",
            "verified-signed-crossing-assignment-readiness.json",
            "production-imgui-renderer-framebuffer-readiness.json",
            "signed-release-publication-readiness.json",
            "full-homfly-pt-evaluation-readiness.json",
            "full-multivariable-alexander-normalization-readiness.json",
            "source-invariant-l5a1-candidates.json",
            "source-invariant-l6a4-candidates.json",
            "source-table-l5a1-audit.json",
            "source-table-l6a4-audit.json",
        }
        assert set(rows) == expected_files
        for filename in expected_files:
            path = bundle_dir / filename
            assert path.exists()
            written = json.loads(path.read_text(encoding="utf-8"))
            assert written["artifact_kind"] == rows[filename]["artifact_kind"]
        assert rows["completion-evidence-ci-plan.json"]["artifact_kind"] == (
            "cross_workstream_completion_evidence_ci_plan"
        )
        assert rows["completion-evidence-template-directory-audit.json"][
            "artifact_kind"
        ] == "cross_workstream_completion_evidence_directory_audit"
        assert payload["traceability_report_count"] == 10
        assert "completion-evidence-contracts.json" in payload[
            "traceability_report_files"
        ]
        assert payload["traceability_artifact_filename_signatures_by_report"][
            "completion-evidence-templates.json"
        ] == payload["expected_evidence_filename_signature"]
        assert payload["producer_metadata_consistency_report_count"] == 5
        assert payload["producer_metadata_consistency_passed_count"] == 5
        assert payload["producer_metadata_consistency_failed_count"] == 0
        assert payload["producer_metadata_consistency_all_passed"] is True
        assert payload["producer_metadata_consistency_failed_files"] == []
        assert payload["producer_metadata_consistency_report_files"] == [
            "verified-signed-crossing-assignment-readiness.json",
            "production-imgui-renderer-framebuffer-readiness.json",
            "signed-release-publication-readiness.json",
            "full-homfly-pt-evaluation-readiness.json",
            "full-multivariable-alexander-normalization-readiness.json",
        ]
        assert rows["completion-evidence-contracts.json"][
            "contract_instance_row_count"
        ] == 6
        assert rows["completion-evidence-contracts.json"][
            "expected_evidence_filename_signature"
        ] == payload["expected_evidence_filename_signature"]
        assert rows["completion-evidence-templates.json"][
            "template_to_artifact_filename_signature"
        ] == payload["expected_evidence_filename_signature"]
        assert rows["completion-evidence-template-directory-audit.json"][
            "expected_evidence_filename_signature"
        ] == payload["expected_evidence_filename_signature"]
        template_audit = json.loads(
            (bundle_dir / "completion-evidence-template-directory-audit.json").read_text(
                encoding="utf-8"
            )
        )
        assert template_audit["completion_evidence_pipeline_ready"] is False
        assert "required_instance_files_missing" in template_audit[
            "completion_evidence_pipeline_blocker_codes"
        ]
        assert payload["template_directory_audit_available"] is True
        assert payload["template_directory_audit_pipeline_ready"] is False
        assert payload["template_directory_audit_blocker_signature"] == (
            "artifact_preflight_not_certified:1,"
            "artifact_validation_not_ready:1,"
            "required_instance_files_missing:1"
        )
        assert payload["template_directory_audit_missing_instance_filenames"] == [
            "verified_signed_crossing_assignment.L5a1.json",
            "verified_signed_crossing_assignment.L6a4.json",
        ]
        assert rows["full-homfly-pt-evaluation-readiness.json"][
            "readiness_all_ready"
        ] is False
        assert rows["verified-signed-crossing-assignment-readiness.json"][
            "readiness_blocker_codes"
        ] == [
            "external_source_assignment_verified",
            "invariant_table_values_verified",
            "unique_sign_pattern",
        ]
        assert rows["verified-signed-crossing-assignment-readiness.json"][
            "readiness_blocker_code_counts"
        ] == {
            "external_source_assignment_verified": 2,
            "invariant_table_values_verified": 2,
            "unique_sign_pattern": 2,
        }
        assert rows["production-imgui-renderer-framebuffer-readiness.json"][
            "readiness_blocker_count"
        ] == 10
        assert rows["production-imgui-renderer-framebuffer-readiness.json"][
            "completion_evidence_artifact_instance_row_count"
        ] == 1
        assert rows["production-imgui-renderer-framebuffer-readiness.json"][
            "completion_evidence_producer_metadata_consistency_passed"
        ] is True
        assert rows["production-imgui-renderer-framebuffer-readiness.json"][
            "completion_evidence_artifact_filenames_are_expected"
        ] is True
        assert rows["production-imgui-renderer-framebuffer-readiness.json"][
            "completion_evidence_template_to_artifact_filenames_match_artifact_filenames"
        ] is True
        assert rows["verified-signed-crossing-assignment-readiness.json"][
            "completion_evidence_producer_metadata_consistency_passed"
        ] is True
        assert rows["verified-signed-crossing-assignment-readiness.json"][
            "completion_evidence_artifact_instance_row_count"
        ] == 2
        assert rows["production-imgui-renderer-framebuffer-readiness.json"][
            "completion_evidence_final_completion_failed_gate_signature"
        ] == "non_diagram_requirements|production_imgui_renderer"
        assert rows["production-imgui-renderer-framebuffer-readiness.json"][
            "completion_evidence_final_completion_blocker_codes"
        ] == [
            "native_imgui_screenshot_framebuffer_fixtures_partial",
            "production_imgui_renderer_not_verified",
        ]
        assert rows["production-imgui-renderer-framebuffer-readiness.json"][
            "readiness_blocker_codes"
        ] == [
            "estimated_nonzero_pixels",
            "framebuffer_height",
            "framebuffer_touched",
            "framebuffer_width",
            "graphics_backend_name",
            "passed",
            "real_graphics_backend_framebuffer_verified",
            "render_frame_count",
            "screenshot_url",
            "screenshot_verified",
        ]
        assert rows["production-imgui-renderer-framebuffer-readiness.json"][
            "readiness_blocker_count_signature"
        ] == (
            "estimated_nonzero_pixels:1,framebuffer_height:1,"
            "framebuffer_touched:1,framebuffer_width:1,graphics_backend_name:1,"
            "passed:1,real_graphics_backend_framebuffer_verified:1,"
            "render_frame_count:1,screenshot_url:1,screenshot_verified:1"
        )
        assert rows["full-multivariable-alexander-normalization-readiness.json"][
            "readiness_all_ready"
        ] is False
        l5_candidates = json.loads(
            (bundle_dir / "source-invariant-l5a1-candidates.json").read_text(
                encoding="utf-8"
            )
        )
        assert l5_candidates["artifact_kind"] == (
            "verified_signed_crossing_assignment_source_candidate_diagnostics"
        )
        assert l5_candidates["completion_claimed"] is False
        assert l5_candidates["final_completion_ready"] is False
        assert l5_candidates["matching_candidate_count"] == 24
        assert l5_candidates["returned_candidate_count"] == 24
        assert l5_candidates["candidate_convergence"]["complete_candidate_set"] is True
        assert l5_candidates["matching_sign_summary"][
            "unique_sign_pattern_count"
        ] == 12
        assert l5_candidates["candidate_convergence"]["stable_invariants"] == []
        l6_candidates = json.loads(
            (bundle_dir / "source-invariant-l6a4-candidates.json").read_text(
                encoding="utf-8"
            )
        )
        assert l6_candidates["artifact_kind"] == (
            "verified_signed_crossing_assignment_source_candidate_diagnostics"
        )
        assert l6_candidates["completion_claimed"] is False
        assert l6_candidates["final_completion_ready"] is False
        assert l6_candidates["matching_candidate_count"] == 8
        assert l6_candidates["returned_candidate_count"] == 8
        assert l6_candidates["candidate_convergence"]["complete_candidate_set"] is True
        assert l6_candidates["matching_sign_summary"][
            "unique_sign_pattern_count"
        ] == 8
        assert l6_candidates["candidate_convergence"]["stable_invariants"] == [
            "jones",
            "multivariable_alexander",
        ]
        l5_source_table = json.loads(
            (bundle_dir / "source-table-l5a1-audit.json").read_text(
                encoding="utf-8"
            )
        )
        assert l5_source_table["artifact_kind"] == (
            "verified_signed_crossing_assignment_source_table_diagnostics"
        )
        assert l5_source_table["completion_claimed"] is False
        assert l5_source_table["final_completion_ready"] is False
        assert l5_source_table["source_url"] == "https://katlas.org/wiki/L5a1"
        assert l5_source_table["source_table_candidate_convergence_summary"][
            "full_source_table_convergence_certified"
        ] is False
        assert l5_source_table["candidate_source_table_match_summary"][
            "complete_source_compatible_unique_sign_pattern_count"
        ] == 0
        assert l5_source_table["mismatched_source_table_invariants"] == ["homfly"]
        l6_source_table = json.loads(
            (bundle_dir / "source-table-l6a4-audit.json").read_text(
                encoding="utf-8"
            )
        )
        assert l6_source_table["artifact_kind"] == (
            "verified_signed_crossing_assignment_source_table_diagnostics"
        )
        assert l6_source_table["completion_claimed"] is False
        assert l6_source_table["final_completion_ready"] is False
        assert l6_source_table["source_url"] == "https://katlas.org/wiki/L6a4"
        assert l6_source_table["source_table_candidate_convergence_summary"][
            "partial_source_table_convergence_certified"
        ] is True
        assert l6_source_table["matched_source_table_invariants"] == [
            "jones",
            "multivariable_alexander_numerator",
        ]
        assert l6_source_table["mismatched_source_table_invariants"] == ["homfly"]
        assert l6_source_table["candidate_source_table_match_summary"][
            "complete_source_compatible_unique_sign_pattern_count"
        ] == 0
        assignment_readiness = json.loads(
            (
                bundle_dir / "verified-signed-crossing-assignment-readiness.json"
            ).read_text(encoding="utf-8")
        )
        assert assignment_readiness["completion_evidence_artifact_filenames"] == [
            "verified_signed_crossing_assignment.L5a1.json",
            "verified_signed_crossing_assignment.L6a4.json",
        ]
        imgui_readiness = json.loads(
            (
                bundle_dir / "production-imgui-renderer-framebuffer-readiness.json"
            ).read_text(encoding="utf-8")
        )
        assert imgui_readiness["completion_evidence_artifact_filenames"] == [
            "production_imgui_renderer_framebuffer_pack.json"
        ]
        release_readiness = json.loads(
            (bundle_dir / "signed-release-publication-readiness.json").read_text(
                encoding="utf-8"
            )
        )
        assert release_readiness["completion_evidence_artifact_filenames"] == [
            "signed_release_publication_manifest.json"
        ]
        assert payload["template_file_count"] == 6
        assert (bundle_dir / "completion-evidence-templates").exists()
        assert all(Path(path).exists() for path in payload["template_files"])
        audit_exit_code = main(["completion-evidence-directory-audit", str(bundle_dir)])
        directory_audit = json.loads(capsys.readouterr().out)

        assert audit_exit_code == 0
        assert directory_audit["source_evidence_directory_kind"] == (
            "review_bundle_handoff"
        )
        assert directory_audit["review_bundle_handoff_detected"] is True
        assert directory_audit["review_bundle_not_final_evidence_directory"] is True
        assert directory_audit["review_bundle_templates_directory_present"] is True
        assert directory_audit["review_bundle_marker_file_count"] >= 5
        assert "validation-pack-audit.json" in directory_audit[
            "review_bundle_marker_files"
        ]
        assert directory_audit["review_bundle_index_present"] is True
        assert directory_audit["review_bundle_index_valid_json"] is True
        assert directory_audit["review_bundle_index_artifact_kind"] == (
            "cross_workstream_completion_evidence_review_bundle"
        )
        assert directory_audit["review_bundle_index_claim_scope"] == (
            "cross_workstream_final_completion_evidence_review"
        )
        assert (
            directory_audit["review_bundle_index_matches_review_bundle_contract"]
            is True
        )
        assert (
            directory_audit[
                "review_bundle_index_expected_evidence_filename_count_matches_requirements"
            ]
            is True
        )
        assert (
            directory_audit[
                "review_bundle_index_expected_evidence_filename_signature_matches_requirements"
            ]
            is True
        )
        assert (
            directory_audit["review_bundle_index_non_claim_consistency_passed"]
            is True
        )
        assert (
            directory_audit[
                "review_bundle_index_final_completion_blocker_count_matches_requirements"
            ]
            is True
        )
        assert (
            directory_audit[
                "review_bundle_index_final_completion_failed_gate_count_matches_requirements"
            ]
            is True
        )
        assert (
            directory_audit[
                "review_bundle_index_final_completion_failed_gate_signature_matches_requirements"
            ]
            is True
        )
        assert (
            directory_audit[
                "review_bundle_index_final_completion_missing_artifact_count_matches_requirements"
            ]
            is True
        )
        assert (
            directory_audit[
                "review_bundle_index_final_completion_missing_artifact_signature_matches_requirements"
            ]
            is True
        )
        assert (
            directory_audit["review_bundle_index_final_state_matches_requirements"]
            is True
        )
        assert (
            directory_audit["review_bundle_index_handoff_consistency_passed"]
            is True
        )
        assert directory_audit[
            "review_bundle_index_producer_metadata_consistency_report_count"
        ] == 5
        assert directory_audit[
            "review_bundle_index_producer_metadata_consistency_passed_count"
        ] == 5
        assert directory_audit[
            "review_bundle_index_producer_metadata_consistency_failed_count"
        ] == 0
        assert directory_audit[
            "review_bundle_index_producer_metadata_consistency_all_passed"
        ] is True
        assert directory_audit[
            "review_bundle_index_producer_metadata_consistency_failed_files"
        ] == []
        assert directory_audit[
            "review_bundle_index_expected_evidence_filename_count"
        ] == 6
        assert directory_audit[
            "review_bundle_index_expected_evidence_filename_signature"
        ] == payload["expected_evidence_filename_signature"]
        assert directory_audit["bundle_inputs_complete"] is False
        assert directory_audit["missing_input_artifact_count"] == 6
        assert directory_audit["missing_input_artifact_filenames"] == [
            "full_homfly_pt_evaluation_certification_pack.json",
            "full_multivariable_alexander_normalization_certification_pack.json",
            "production_imgui_renderer_framebuffer_pack.json",
            "signed_release_publication_manifest.json",
            "verified_signed_crossing_assignment.L5a1.json",
            "verified_signed_crossing_assignment.L6a4.json",
        ]
        assert directory_audit["missing_input_artifact_rows"][-1][
            "template_to_artifact_filename"
        ] == "verified_signed_crossing_assignment.L6a4.json"
        assert directory_audit["missing_input_artifact_rows"][-1][
            "final_completion_failed_gates"
        ] == ["signed_diagram_fixture_registration"]
        assert directory_audit["missing_input_artifact_rows"][-1][
            "final_completion_blocker_count"
        ] == 1
        assert directory_audit["missing_input_artifact_rows"][-1][
            "final_completion_blocker_labels"
        ] == ["L6a4"]
        production_missing = {
            row["artifact_filename"]: row
            for row in directory_audit["missing_input_artifact_rows"]
        }["production_imgui_renderer_framebuffer_pack.json"]
        assert production_missing["final_completion_failed_gate_count"] == 2
        assert production_missing["final_completion_blocker_codes"] == [
            "native_imgui_screenshot_framebuffer_fixtures_partial",
            "production_imgui_renderer_not_verified",
        ]
        assert "required_inputs_missing" in directory_audit[
            "completion_evidence_pipeline_blocker_codes"
        ]
        assert "review handoff" in " ".join(directory_audit["notes"])


def test_cli_completion_evidence_contracts_lists_required_fields(capsys) -> None:
    exit_code = main(["completion-evidence-contracts"])
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["artifact_kind"] == "cross_workstream_completion_evidence_contracts"
    assert payload["claim_scope"] == (
        "cross_workstream_final_completion_evidence_contracts"
    )
    assert payload["final_completion_ready"] is False
    assert payload["final_completion_blocker_count"] == 7
    assert payload["final_completion_failed_gate_count"] == 6
    assert payload["final_completion_failed_gate_signature"] == (
        "signed_diagram_fixture_registration|non_diagram_requirements|"
        "full_homfly_pt_evaluation|"
        "full_multivariable_alexander_normalization|"
        "production_imgui_renderer|release_artifacts"
    )
    assert payload["final_completion_blocker_code_count"] == 6
    assert payload["final_completion_blocker_code_counts"] == {
        "full_homfly_pt_evaluation_not_certified": 1,
        "full_multivariable_alexander_normalization_not_certified": 1,
        "native_imgui_screenshot_framebuffer_fixtures_partial": 1,
        "production_imgui_renderer_not_verified": 1,
        "release_artifacts_not_published": 1,
        "signed_pd_not_registered": 2,
    }
    assert payload["contract_count"] == 5
    assert payload["required_artifact_count"] == 5
    assert payload["final_completion_missing_artifact_count"] == 5
    assert payload["final_completion_missing_artifacts"] == [
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "verified_signed_crossing_assignment",
    ]
    assert payload["required_missing_artifacts"] == [
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "verified_signed_crossing_assignment",
    ]
    assert payload["required_missing_artifact_signature"] == (
        "full_homfly_pt_evaluation_certification_pack|"
        "full_multivariable_alexander_normalization_certification_pack|"
        "production_imgui_renderer_framebuffer_pack|"
        "signed_release_publication_manifest|verified_signed_crossing_assignment"
    )
    assert payload["expected_evidence_filename_count"] == 6
    assert payload["expected_evidence_filenames"] == [
        "full_homfly_pt_evaluation_certification_pack.json",
        "full_multivariable_alexander_normalization_certification_pack.json",
        "production_imgui_renderer_framebuffer_pack.json",
        "signed_release_publication_manifest.json",
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert payload["bundle_all_inputs_command"].endswith(
        "-o completion-evidence-bundle.json"
    )
    assert payload["directory_audit_command"].endswith("--fail-on-not-ready")
    assert payload["final_validation_command"].endswith("--fail-on-not-ready")
    assert (
        payload["final_completion_missing_artifact_signature"]
        == payload["required_missing_artifact_signature"]
    )
    assert payload["producer_readiness_available"] is True
    assert payload["producer_readiness_count"] == 6
    assert payload["producer_readiness_ready_count"] == 0
    assert payload["producer_readiness_all_ready"] is False
    assert payload["producer_readiness_blocker_count"] == 34
    assert payload["producer_readiness_blocker_signature"] == "|".join(
        payload["producer_readiness_blockers"]
    )
    assert payload["producer_readiness_blocker_occurrence_count"] == 41
    assert payload["producer_readiness_blocker_code_counts"][
        "external_source_assignment_verified"
    ] == 2
    assert payload["producer_readiness_blocker_code_counts"][
        "unique_sign_pattern"
    ] == 2
    assert payload["repeatable_instance_coverage_required"] is True
    assert payload["required_instance_count"] == 2
    assert payload["required_instance_labels"] == ["L5a1", "L6a4"]
    assert payload["contract_instance_row_count"] == 6
    contracts = {row["missing_artifact"]: row for row in payload["contracts"]}
    assert contracts["verified_signed_crossing_assignment"][
        "expected_artifact_kind"
    ] == "verified_signed_crossing_assignment"
    assert contracts["verified_signed_crossing_assignment"][
        "repeatable_instance_coverage_required"
    ] is True
    assert contracts["verified_signed_crossing_assignment"][
        "required_instance_count"
    ] == 2
    assert contracts["verified_signed_crossing_assignment"][
        "required_instance_labels"
    ] == ["L5a1", "L6a4"]
    assert contracts["verified_signed_crossing_assignment"][
        "contract_instance_filenames"
    ] == [
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert contracts["verified_signed_crossing_assignment"][
        "contract_instance_count_matches_required_instance_count"
    ] is True
    assert contracts["verified_signed_crossing_assignment"][
        "contract_expected_evidence_filename_count"
    ] == 2
    assert contracts["verified_signed_crossing_assignment"][
        "contract_instance_count_matches_expected_evidence_filename_count"
    ] is True
    assert contracts["verified_signed_crossing_assignment"][
        "contract_instance_count_matches_contract_expected_evidence_filename_count"
    ] is True
    assert contracts["production_imgui_renderer_framebuffer_pack"][
        "repeatable_instance_coverage_required"
    ] is False
    assert contracts["production_imgui_renderer_framebuffer_pack"][
        "required_instance_labels"
    ] == []
    assert contracts["production_imgui_renderer_framebuffer_pack"][
        "contract_instance_filenames"
    ] == ["production_imgui_renderer_framebuffer_pack.json"]
    assert contracts["production_imgui_renderer_framebuffer_pack"][
        "contract_expected_evidence_filename_count"
    ] == 1
    assert contracts["production_imgui_renderer_framebuffer_pack"][
        "contract_instance_count_matches_required_instance_count"
    ] is True
    assert contracts["production_imgui_renderer_framebuffer_pack"][
        "contract_instance_count_matches_expected_evidence_filename_count"
    ] is True
    assert contracts["production_imgui_renderer_framebuffer_pack"][
        "contract_instance_count_matches_contract_expected_evidence_filename_count"
    ] is True
    assert all(
        row[
            "contract_instance_count_matches_contract_expected_evidence_filename_count"
        ]
        is True
        for row in contracts.values()
    )
    assert contracts["production_imgui_renderer_framebuffer_pack"][
        "final_completion_failed_gates"
    ] == ["non_diagram_requirements", "production_imgui_renderer"]
    assert contracts["production_imgui_renderer_framebuffer_pack"][
        "final_completion_blocker_codes"
    ] == [
        "native_imgui_screenshot_framebuffer_fixtures_partial",
        "production_imgui_renderer_not_verified",
    ]
    assert "candidate_replay_sha256" in contracts[
        "verified_signed_crossing_assignment"
    ]["required_fields"]
    assert "render_frame_count" in contracts[
        "production_imgui_renderer_framebuffer_pack"
    ]["required_fields"]
    contract_instance_rows = {
        row["artifact_filename"]: row for row in payload["contract_instance_rows"]
    }
    assert contract_instance_rows["verified_signed_crossing_assignment.L6a4.json"][
        "final_completion_blocker_labels"
    ] == ["L6a4"]
    assert contract_instance_rows["verified_signed_crossing_assignment.L6a4.json"][
        "final_completion_failed_gates"
    ] == ["signed_diagram_fixture_registration"]
    assert contract_instance_rows["production_imgui_renderer_framebuffer_pack.json"][
        "final_completion_failed_gate_count"
    ] == 2
    assert contracts["verified_signed_crossing_assignment"]["field_rules"][
        "candidate_replay_sha256"
    ] == "sha256_hex_64"
    assert contracts["verified_signed_crossing_assignment"][
        "field_rule_preflight_links"
    ]["candidate_replay_sha256"] == [
        "candidate_replay_sha256_available",
        "candidate_replay_sha256_not_invariant_table_source_sha256s",
    ]
    assert contracts["verified_signed_crossing_assignment"][
        "field_rule_preflight_links"
    ]["source_url"] == [
        "source_url",
        "source_url_http",
        "source_url_matches_notation",
        "source_url_not_invariant_table_source_urls",
    ]
    assert contracts["verified_signed_crossing_assignment"][
        "field_rule_preflight_links"
    ]["signs"] == [
        "signs_match_crossing_count",
        "signs_are_plus_or_minus_one",
    ]
    assert contracts["verified_signed_crossing_assignment"][
        "field_rule_preflight_links"
    ]["role_orders"] == [
        "role_orders_match_crossing_count",
        "role_orders_are_four_role_permutations",
    ]
    assert "source_url_http" in contracts["verified_signed_crossing_assignment"][
        "preflight_checks"
    ]
    assert "template_placeholder_not_true" in contracts[
        "verified_signed_crossing_assignment"
    ]["preflight_checks"]
    assert "invariant_table_source_urls" in contracts[
        "verified_signed_crossing_assignment"
    ]["required_fields"]
    assert "invariant_table_source_sha256s" in contracts[
        "verified_signed_crossing_assignment"
    ]["required_fields"]
    assert contracts["verified_signed_crossing_assignment"]["field_rules"][
        "invariant_table_source_sha256s"
    ] == "unique_nonempty_sha256_hex_64_list_length_matches_invariant_table_source_urls"
    assert contracts["verified_signed_crossing_assignment"][
        "field_rule_preflight_links"
    ]["invariant_table_source_sha256s"] == [
        "invariant_table_source_sha256s_available",
        "invariant_table_source_sha256s_items_nonempty_strings",
        "invariant_table_source_sha256_count_matches_source_url_count",
        "invariant_table_source_sha256s_hex",
        "invariant_table_source_sha256s_unique",
        "invariant_table_source_witness_pairs_unique",
    ]
    assert contracts["verified_signed_crossing_assignment"][
        "field_rule_preflight_links"
    ]["invariant_table_source_urls"] == [
        "invariant_table_source_urls_available",
        "invariant_table_source_urls_items_nonempty_strings",
        "invariant_table_source_urls_http",
        "invariant_table_source_urls_unique",
        "invariant_table_source_witness_pairs_unique",
    ]
    assert "screenshot_url" in contracts[
        "production_imgui_renderer_framebuffer_pack"
    ]["required_fields"]
    assert contracts["production_imgui_renderer_framebuffer_pack"]["field_rules"][
        "screenshot_url"
    ] == "non_placeholder_http_or_https_url"
    assert contracts["production_imgui_renderer_framebuffer_pack"][
        "field_rule_preflight_links"
    ]["screenshot_url"] == ["screenshot_url_http"]
    assert contracts["production_imgui_renderer_framebuffer_pack"][
        "field_rule_preflight_links"
    ]["screenshot_sha256"] == ["screenshot_sha256_available"]
    assert contracts["production_imgui_renderer_framebuffer_pack"][
        "field_rule_preflight_links"
    ]["render_frame_count"] == ["render_frame_count_positive"]
    assert contracts["production_imgui_renderer_framebuffer_pack"][
        "field_rule_preflight_links"
    ]["estimated_nonzero_pixels"] == [
        "estimated_nonzero_pixels",
        "estimated_nonzero_pixels_covers_framebuffer_touched",
        "estimated_nonzero_pixels_within_framebuffer_area",
    ]
    assert "estimated_nonzero_pixels_within_framebuffer_area" in contracts[
        "production_imgui_renderer_framebuffer_pack"
    ]["field_rule_preflight_links"]["framebuffer_width"]
    assert "estimated_nonzero_pixels_within_framebuffer_area" in contracts[
        "production_imgui_renderer_framebuffer_pack"
    ]["field_rule_preflight_links"]["framebuffer_height"]
    assert "template_placeholder_not_true" in contracts[
        "production_imgui_renderer_framebuffer_pack"
    ]["preflight_checks"]
    assert "artifact_urls" in contracts[
        "signed_release_publication_manifest"
    ]["required_fields"]
    assert contracts["signed_release_publication_manifest"]["field_rules"][
        "artifact_urls"
    ] == "unique_nonempty_non_placeholder_http_or_https_url_list_length_matches_published_artifact_count"
    assert contracts["signed_release_publication_manifest"][
        "field_rule_preflight_links"
    ]["artifact_urls"] == [
        "artifact_urls_available",
        "artifact_urls_items_nonempty_strings",
        "artifact_url_count_matches_published_artifact_count",
        "artifact_urls_http",
        "artifact_urls_unique",
        "artifact_url_filenames_unique",
        "artifact_url_sha256_pairs_unique",
        "artifact_urls_disjoint_from_signature_urls",
        "signature_urls_match_artifact_url_filenames",
    ]
    assert contracts["signed_release_publication_manifest"]["field_rules"][
        "artifact_sha256s"
    ] == "unique_nonempty_sha256_hex_64_list_length_matches_published_artifact_count_and_artifact_urls"
    assert contracts["signed_release_publication_manifest"][
        "field_rule_preflight_links"
    ]["artifact_sha256s"] == [
        "artifact_sha256s_available",
        "artifact_sha256s_items_nonempty_strings",
        "artifact_sha256_count_matches_published_artifact_count",
        "artifact_sha256_count_matches_artifact_url_count",
        "artifact_sha256s_hex",
        "artifact_sha256s_unique",
        "artifact_url_sha256_pairs_unique",
        "artifact_sha256s_disjoint_from_signature_sha256s",
    ]
    assert contracts["signed_release_publication_manifest"][
        "field_rule_preflight_links"
    ]["signature_sha256s"] == [
        "signature_sha256s_available",
        "signature_sha256s_items_nonempty_strings",
        "signature_sha256_count_matches_signature_count",
        "signature_sha256_count_matches_signature_url_count",
        "signature_sha256s_hex",
        "signature_sha256s_unique",
        "signature_url_sha256_pairs_unique",
        "artifact_sha256s_disjoint_from_signature_sha256s",
    ]
    assert "artifact_urls_disjoint_from_signature_urls" in contracts[
        "signed_release_publication_manifest"
    ]["field_rule_preflight_links"]["signature_urls"]
    assert "signature_urls_match_artifact_url_filenames" in contracts[
        "signed_release_publication_manifest"
    ]["field_rule_preflight_links"]["signature_urls"]
    assert "signature_url_filenames_unique" in contracts[
        "signed_release_publication_manifest"
    ]["field_rule_preflight_links"]["signature_urls"]
    assert "signature_url_filenames_have_signature_extension" in contracts[
        "signed_release_publication_manifest"
    ]["field_rule_preflight_links"]["signature_urls"]
    assert "signature_url_sha256_pairs_unique" in contracts[
        "signed_release_publication_manifest"
    ]["field_rule_preflight_links"]["signature_urls"]
    assert "certification_report_url" in contracts[
        "full_homfly_pt_evaluation_certification_pack"
    ]["required_fields"]
    assert contracts["full_homfly_pt_evaluation_certification_pack"][
        "field_rule_preflight_links"
    ]["certification_report_url"] == [
        "certification_report_url_http",
        "published_certification_report_witness_verified",
    ]
    assert contracts["full_homfly_pt_evaluation_certification_pack"][
        "field_rule_preflight_links"
    ]["certification_report_sha256"] == [
        "certification_report_sha256_available",
        "certification_report_sha256_not_external_table_source_sha256s",
        "published_certification_report_witness_verified",
        "embedded_certification_report_raw_sha256_matches",
    ]
    assert contracts["full_homfly_pt_evaluation_certification_pack"][
        "field_rule_preflight_links"
    ]["external_table_source_sha256s"] == [
        "external_table_source_sha256s_available",
        "external_table_source_sha256s_items_nonempty_strings",
        "external_table_source_sha256_count_matches_source_url_count",
        "external_table_source_sha256s_hex",
        "external_table_source_sha256s_unique",
        "external_table_source_witness_pairs_unique",
        "certification_report_sha256_not_external_table_source_sha256s",
        "pinned_external_table_sources_exact",
    ]
    assert "certification_report_url_not_external_table_source_urls" in contracts[
        "full_homfly_pt_evaluation_certification_pack"
    ]["field_rule_preflight_links"]["external_table_source_urls"]
    assert "external_table_source_url_filenames_unique" in contracts[
        "full_homfly_pt_evaluation_certification_pack"
    ]["field_rule_preflight_links"]["external_table_source_urls"]
    assert "external_table_source_urls" in contracts[
        "full_multivariable_alexander_normalization_certification_pack"
    ]["required_fields"]
    assert "external_table_source_sha256s" in contracts[
        "full_multivariable_alexander_normalization_certification_pack"
    ]["required_fields"]
    assert "external_table_source_url_filenames_unique" in contracts[
        "full_multivariable_alexander_normalization_certification_pack"
    ]["field_rule_preflight_links"]["external_table_source_urls"]
    assert all(
        contracts[artifact]["field_rule_preflight_links"][
            "template_placeholder"
        ]
        == ["template_placeholder_not_true"]
        for artifact in contracts
    )
    expected_structural_preflight_checks = [
        "artifact_kind",
        "artifact_schema_version",
        "claim_scope",
    ]
    assert all(
        row["structural_preflight_checks"]
        == expected_structural_preflight_checks
        for row in payload["contracts"]
    )
    assert all(
        row["structural_preflight_check_count"] == 3
        for row in payload["contracts"]
    )
    assert all(
        row["accounted_preflight_check_count"] == row["preflight_check_count"]
        for row in payload["contracts"]
    )
    assert all(
        row["all_preflight_checks_accounted_for"] is True
        for row in payload["contracts"]
    )
    assert all(
        row["unexpected_unlinked_preflight_checks"] == []
        for row in payload["contracts"]
    )
    assert all(
        row["contract_preflight_consistency_passed"] is True
        for row in payload["contracts"]
    )
    assert payload["contract_preflight_consistency_passed_count"] == 5
    assert payload["all_contract_preflight_consistency_passed"] is True
    assert all(row["unlinked_field_rules"] == [] for row in payload["contracts"])
    assert all(row["invalid_preflight_links"] == [] for row in payload["contracts"])
    assert "--fail-on-not-certified" in contracts[
        "signed_release_publication_manifest"
    ]["preflight_command"]
    assert payload["completion_claimed"] is False


def test_cli_verified_signed_crossing_assignment_audit_fails_incomplete_pack(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "verified_signed_crossing_assignment_L5a1.json"
        path.write_text(
            json.dumps(
                {
                    "artifact_schema_version": 1,
                    "artifact_kind": "verified_signed_crossing_assignment",
                    "claim_scope": "verified_signed_crossing_assignment",
                    "notation": "L5a1",
                    "source_url": "https://katlas.org/wiki/L5a1",
                    "crossing_count": 5,
                    "signs": [],
                    "role_orders": [],
                    "source_gauss_code_match": True,
                    "source_candidate_replay_valid": False,
                    "unique_assignment_certified": False,
                    "invariant_table_values_verified": False,
                    "orientation_validation_issue_count": 0,
                }
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "verified-signed-crossing-assignment-audit",
                str(path),
                "--fail-on-not-certified",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert payload["artifact_kind"] == "verified_signed_crossing_assignment_audit"
    assert payload["claim_scope"] == "verified_signed_crossing_assignment_preflight"
    assert payload["assignment_certified"] is False
    assert payload["completion_evidence_artifact_filename_count"] == 2
    assert payload["completion_evidence_artifact_filenames"] == [
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert payload["completion_evidence_artifact_instance_row_count"] == 2
    assert payload["completion_evidence_artifact_filenames_are_expected"] is True
    assert (
        payload[
            "completion_evidence_template_to_artifact_filenames_match_artifact_filenames"
        ]
        is True
    )
    assert (
        payload[
            "completion_evidence_artifact_filename_count_matches_instance_row_count"
        ]
        is True
    )
    assert (
        payload[
            "completion_evidence_artifact_filename_signature_matches_instance_rows"
        ]
        is True
    )
    assert payload["completion_evidence_producer_metadata_consistency_passed"] is True
    assert payload["expected_evidence_filename_count"] == 6
    assert payload["ci_fail_on_not_certified"] is True
    assert payload["ci_exit_code"] == 1
    assert payload["failed_checks"] == [
        "signs_match_crossing_count",
        "role_orders_match_crossing_count",
        "source_candidate_replay_valid",
        "candidate_replay_sha256_available",
        "unique_assignment_certified",
        "invariant_table_values_verified",
        "invariant_table_source_urls_available",
        "invariant_table_source_urls_items_nonempty_strings",
        "invariant_table_source_sha256s_available",
        "invariant_table_source_sha256s_items_nonempty_strings",
        "invariant_table_source_witness_pairs_unique",
    ]
    assert payload["assignment_evidence"]["notation"] == "L5a1"


def test_cli_verified_signed_crossing_assignment_audit_accepts_certified_pack(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "verified_signed_crossing_assignment_L6a4.json"
        path.write_text(
            json.dumps(
                {
                    "artifact_schema_version": 1,
                    "artifact_kind": "verified_signed_crossing_assignment",
                    "claim_scope": "verified_signed_crossing_assignment",
                    "notation": "L6a4",
                    "source_url": "https://katlas.org/wiki/L6a4",
                    "crossing_count": 6,
                    "signs": [-1, -1, -1, 1, 1, 1],
                    "role_orders": [[0, 1, 2, 3]] * 6,
                    "source_gauss_code_match": True,
                    "source_candidate_replay_valid": True,
                    "candidate_replay_sha256": "a" * 64,
                    "unique_assignment_certified": True,
                    "invariant_table_values_verified": True,
                    "invariant_table_source_urls": [
                        "https://evidence.iroll.dev/tables/L6a4"
                    ],
                    "invariant_table_source_sha256s": ["b" * 64],
                    "orientation_validation_issue_count": 0,
                }
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "verified-signed-crossing-assignment-audit",
                str(path),
                "--fail-on-not-certified",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["assignment_certified"] is True
    assert payload["completion_evidence_artifact_filenames"] == [
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert payload["failed_check_count"] == 0
    assert payload["failed_checks"] == []
    assert payload["assignment_evidence"][
        "invariant_table_source_witness_pair_signature"
    ] == "https://evidence.iroll.dev/tables/L6a4#" + "b" * 64
    assert payload["ci_fail_on_not_certified"] is True
    assert payload["ci_exit_code"] == 0


def test_cli_verified_signed_crossing_assignment_producer_uses_pinned_sources(
    capsys,
    monkeypatch,
) -> None:
    from iroll import cli as cli_module

    source_content = {
        "Planar Diagrams": (
            "increasing labels as we go around each component; "
            "starting from the incoming lower edge and proceeding counterclockwise; "
            "upper strand is therefore oriented from l to j; "
            "upper strand is therefore oriented from j to l"
        ),
        "Data:L5a1/PD Presentation": (
            "X<sub>6172</sub> X<sub>10,7,5,8</sub> X<sub>4516</sub> "
            "X<sub>2,10,3,9</sub> X<sub>8493</sub>"
        ),
        "Data:L5a1/Gauss Code": "{1, -4, 5, -3}, {3, -1, 2, -5, 4, -2}",
        "Data:L5a1/Jones Polynomial": (
            r"<math>\frac{1}{q^{7/2}}-\frac{2}{q^{5/2}}-q^{3/2}"
            r"+\frac{1}{q^{3/2}}+\sqrt{q}-\frac{2}{\sqrt{q}}</math>"
        ),
        "Data:L5a1/HOMFLYPT Polynomial": (
            r"<math>-z a^3+z^3 a+2 z a+a z^{-1} -z a^{-1} "
            r"- a^{-1} z^{-1} </math>"
        ),
        "Data:L5a1/Multivariable Alexander": (
            r"<math>\frac{(u-1) (v-1)}{\sqrt{u} \sqrt{v}}</math>"
        ),
        "Data:L6a4/PD Presentation": (
            "X<sub>6172</sub> X<sub>12,8,9,7</sub> "
            "X<sub>4,12,1,11</sub> X<sub>10,5,11,6</sub> "
            "X<sub>8453</sub> X<sub>2,9,3,10</sub>"
        ),
        "Data:L6a4/Gauss Code": (
            "{1, -6, 5, -3}, {4, -1, 2, -5}, {6, -4, 3, -2}"
        ),
        "Data:L6a4/Jones Polynomial": (
            r"<math>-q^3- q^{-3} +3 q^2+3 q^{-2} -2 q-2 q^{-1} +4</math>"
        ),
        "Data:L6a4/HOMFLYPT Polynomial": (
            r"<math>-a^2 z^2-z^2 a^{-2} +a^2 z^{-2} + a^{-2} z^{-2} "
            r"+z^4+2 z^2-2 z^{-2} </math>"
        ),
        "Data:L6a4/Multivariable Alexander": (
            r"<math>\frac{(u-1) (v-1) (w-1)}"
            r"{\sqrt{u} \sqrt{v} \sqrt{w}}</math>"
        ),
    }

    def fake_fetch(title, revision_id, expected_sha256, *, timeout):
        del timeout
        return {
            "title": title,
            "revision_id": revision_id,
            "url": cli_module._knot_atlas_pinned_revision_url(title, revision_id),
            "expected_sha256": expected_sha256,
            "actual_sha256": expected_sha256,
            "byte_count": len(source_content.get(title, "<math>pinned</math>")),
            "fetched": True,
            "sha256_verified": True,
            "error": None,
            "_content": source_content.get(title, "<math>pinned</math>"),
        }

    monkeypatch.setattr(
        cli_module,
        "_fetch_knot_atlas_pinned_witness",
        fake_fetch,
    )

    expected = {
        "L5a1": [-1, -1, -1, 1, 1],
        "L6a4": [-1, 1, 1, -1, 1, -1],
    }
    for notation, signs in expected.items():
        exit_code = main(
            [
                "verified-signed-crossing-assignment-producer",
                notation,
                "--fail-on-not-certified",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

        assert exit_code == 0
        assert payload["notation"] == notation
        assert payload["signs"] == signs
        assert payload["unique_assignment_certified"] is True
        assert payload["invariant_table_values_verified"] is True
        assert payload["producer_failed_checks"] == []
        assert payload["producer_preflight_assignment_certified"] is True
        assert payload["producer_preflight_failed_checks"] == []
        assert payload["completion_claimed"] is True
        assert payload["template_placeholder"] is False
        assert len(payload["source_witnesses"]) == 6
        assert all(row["sha256_verified"] for row in payload["source_witnesses"])
        assert len(payload["invariant_table_value_checks"]) == 3
        assert all(
            row["source_math_matches_pinned_declaration"]
            and row["fixture_value_matches_pinned_declaration"]
            for row in payload["invariant_table_value_checks"]
        )

    source_content["Data:L5a1/Jones Polynomial"] = "<math>tampered</math>"
    exit_code = main(
        [
            "verified-signed-crossing-assignment-producer",
            "L5a1",
            "--fail-on-not-certified",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert payload["invariant_table_values_verified"] is False
    assert payload["producer_preflight_assignment_certified"] is False
    assert (
        "invariant_table_source_values_match_pinned_declarations"
        in payload["producer_failed_checks"]
    )


def test_cli_full_alexander_certification_producer_replays_uncapped_exact_path(
    capsys,
    monkeypatch,
) -> None:
    from iroll import cli as cli_module
    from iroll.topology.alexander_certification import (
        full_alexander_pinned_sources,
    )

    pinned = full_alexander_pinned_sources()

    def fake_data_fetch(title, revision_id, expected_sha256, *, timeout):
        del timeout
        declaration = next(
            records["data"]
            for records in pinned.values()
            if records["data"]["title"] == title
        )
        return {
            "title": title,
            "revision_id": revision_id,
            "url": declaration["url"],
            "expected_sha256": expected_sha256,
            "actual_sha256": expected_sha256,
            "byte_count": len(declaration["expected_math_source"]),
            "fetched": True,
            "sha256_verified": True,
            "error": None,
            "_content": declaration["expected_math_source"],
        }

    def fake_page_fetch(*, title, revision_id, url, expected_sha256, timeout):
        del timeout
        return {
            "title": title,
            "revision_id": revision_id,
            "url": url,
            "expected_sha256": expected_sha256,
            "actual_sha256": expected_sha256,
            "byte_count": 128,
            "fetched": True,
            "sha256_verified": True,
            "error": None,
            "_content": "pinned page source",
        }

    monkeypatch.setattr(
        cli_module,
        "_fetch_knot_atlas_pinned_witness",
        fake_data_fetch,
    )
    monkeypatch.setattr(cli_module, "_fetch_pinned_url_witness", fake_page_fetch)

    with workspace_tempdir() as tmp_path:
        assignment_paths = []
        for notation in ("L5a1", "L6a4"):
            fixture = get_diagram_fixture(notation)
            derivation = fixture.source_pd_convention_assignment_audit()
            path = tmp_path / f"verified_signed_crossing_assignment.{notation}.json"
            assignment = {
                "artifact_schema_version": 1,
                "artifact_kind": "verified_signed_crossing_assignment",
                "claim_scope": "verified_signed_crossing_assignment",
                "notation": notation,
                "source_url": (
                    f"https://katlas.org/wiki/Data:{notation}/PD_Presentation"
                ),
                "crossing_count": len(derivation["signs"]),
                "signs": derivation["signs"],
                "role_orders": derivation["role_orders"],
                "source_gauss_code_match": True,
                "source_candidate_replay_valid": True,
                "candidate_replay_sha256": "a" * 64,
                "unique_assignment_certified": True,
                "invariant_table_values_verified": True,
                "invariant_table_source_urls": [
                    f"https://katlas.org/wiki/{notation}"
                ],
                "invariant_table_source_sha256s": ["b" * 64],
                "orientation_validation_issue_count": 0,
            }
            path.write_text(json.dumps(assignment), encoding="utf-8")
            assignment_paths.append(path)

        report_path = tmp_path / "full-alexander-certification-report.json"
        pack_path = (
            tmp_path
            / "full_multivariable_alexander_normalization_certification_pack.json"
        )
        exit_code = main(
            [
                "full-multivariable-alexander-normalization-certification-producer",
                "--verified-signed-crossing-assignment-json",
                str(assignment_paths[0]),
                "--verified-signed-crossing-assignment-json",
                str(assignment_paths[1]),
                "--certification-report-output",
                str(report_path),
                "--fail-on-not-certified",
                "-o",
                str(pack_path),
            ]
        )
        capsys.readouterr()
        pack = json.loads(pack_path.read_text(encoding="utf-8"))
        report = json.loads(report_path.read_text(encoding="utf-8"))

        published_url = (
            "https://github.com/openai/iroll/releases/download/"
            "alexander-cert/full-alexander-certification-report.json"
        )

        def fake_published_fetch(
            *, title, revision_id, url, expected_sha256, timeout
        ):
            del timeout
            if url == published_url:
                content = report_path.read_text(encoding="utf-8")
            else:
                content = "pinned page source"
            return {
                "title": title,
                "revision_id": revision_id,
                "url": url,
                "expected_sha256": expected_sha256,
                "actual_sha256": expected_sha256,
                "byte_count": len(content.encode("utf-8")),
                "fetched": True,
                "sha256_verified": True,
                "error": None,
                "_content": content,
            }

        monkeypatch.setattr(
            cli_module,
            "_fetch_pinned_url_witness",
            fake_published_fetch,
        )
        published_pack_path = tmp_path / "published-alexander-pack.json"
        published_exit_code = main(
            [
                "full-multivariable-alexander-normalization-certification-producer",
                "--verified-signed-crossing-assignment-json",
                str(assignment_paths[0]),
                "--verified-signed-crossing-assignment-json",
                str(assignment_paths[1]),
                "--certification-report-output",
                str(report_path),
                "--certification-report-url",
                published_url,
                "--fail-on-not-certified",
                "-o",
                str(published_pack_path),
            ]
        )
        capsys.readouterr()
        published_pack = json.loads(
            published_pack_path.read_text(encoding="utf-8")
        )

        def fake_mismatched_published_fetch(
            *, title, revision_id, url, expected_sha256, timeout
        ):
            from hashlib import sha256

            del timeout
            content = "{}\n" if url == published_url else "pinned page source"
            actual_sha256 = (
                sha256(content.encode("utf-8")).hexdigest()
                if url == published_url
                else expected_sha256
            )
            return {
                "title": title,
                "revision_id": revision_id,
                "url": url,
                "expected_sha256": expected_sha256,
                "actual_sha256": actual_sha256,
                "byte_count": len(content.encode("utf-8")),
                "fetched": True,
                "sha256_verified": actual_sha256 == expected_sha256,
                "error": None,
                "_content": content,
            }

        monkeypatch.setattr(
            cli_module,
            "_fetch_pinned_url_witness",
            fake_mismatched_published_fetch,
        )
        mismatched_pack_path = tmp_path / "mismatched-published-alexander-pack.json"
        mismatched_exit_code = main(
            [
                "full-multivariable-alexander-normalization-certification-producer",
                "--verified-signed-crossing-assignment-json",
                str(assignment_paths[0]),
                "--verified-signed-crossing-assignment-json",
                str(assignment_paths[1]),
                "--certification-report-output",
                str(report_path),
                "--certification-report-url",
                published_url,
                "--fail-on-not-certified",
                "-o",
                str(mismatched_pack_path),
            ]
        )
        capsys.readouterr()
        mismatched_pack = json.loads(
            mismatched_pack_path.read_text(encoding="utf-8")
        )

        from iroll.topology.alexander_certification import (
            canonical_json_sha256,
            serialized_certification_report_sha256,
        )
        from iroll.topology.pd_fixtures import completion_evidence_artifact_audit

        tampered_pack = json.loads(json.dumps(published_pack))
        tampered_pack["certification_report"]["cases"][-1][
            "computed_polynomial"
        ] = "0"
        tampered_canonical_sha256 = canonical_json_sha256(
            tampered_pack["certification_report"]
        )
        tampered_raw_sha256 = serialized_certification_report_sha256(
            tampered_pack["certification_report"]
        )
        tampered_pack["certification_report_canonical_sha256"] = (
            tampered_canonical_sha256
        )
        tampered_pack["certification_report_published_canonical_sha256"] = (
            tampered_canonical_sha256
        )
        tampered_pack["certification_report_raw_sha256"] = tampered_raw_sha256
        tampered_pack["certification_report_sha256"] = tampered_raw_sha256
        tampered_pack["certification_report_published_witness"][
            "expected_sha256"
        ] = tampered_raw_sha256
        tampered_pack["certification_report_published_witness"][
            "actual_sha256"
        ] = tampered_raw_sha256
        tampered_audit = completion_evidence_artifact_audit(
            tampered_pack,
            artifact_type=(
                "full_multivariable_alexander_normalization_certification_pack"
            ),
        )
        missing_report_pack = json.loads(json.dumps(published_pack))
        missing_report_pack.pop("certification_report")
        missing_report_audit = completion_evidence_artifact_audit(
            missing_report_pack,
            artifact_type=(
                "full_multivariable_alexander_normalization_certification_pack"
            ),
        )
        missing_published_witness_pack = json.loads(json.dumps(published_pack))
        missing_published_witness_pack.pop(
            "certification_report_published_witness"
        )
        missing_published_witness_audit = completion_evidence_artifact_audit(
            missing_published_witness_pack,
            artifact_type=(
                "full_multivariable_alexander_normalization_certification_pack"
            ),
        )
        tampered_published_witness_pack = json.loads(json.dumps(published_pack))
        tampered_published_witness_pack[
            "certification_report_published_witness"
        ]["actual_sha256"] = "0" * 64
        tampered_published_witness_audit = completion_evidence_artifact_audit(
            tampered_published_witness_pack,
            artifact_type=(
                "full_multivariable_alexander_normalization_certification_pack"
            ),
        )
        missing_page_witness_pack = json.loads(json.dumps(published_pack))
        missing_page_witness_pack.pop("external_table_source_witnesses")
        missing_page_witness_audit = completion_evidence_artifact_audit(
            missing_page_witness_pack,
            artifact_type=(
                "full_multivariable_alexander_normalization_certification_pack"
            ),
        )
        tampered_page_witness_pack = json.loads(json.dumps(published_pack))
        tampered_page_witness_pack["external_table_source_witnesses"][0][
            "actual_sha256"
        ] = "0" * 64
        tampered_page_witness_audit = completion_evidence_artifact_audit(
            tampered_page_witness_pack,
            artifact_type=(
                "full_multivariable_alexander_normalization_certification_pack"
            ),
        )

    assert exit_code == 1
    assert report["certified"] is True
    assert report["resource_caps"] is None
    assert report["arbitrary_finite_explicit_oriented_signed_pd_algorithm"] is True
    assert report["counterexample_count"] == 0
    assert [row["notation"] for row in report["cases"]] == [
        "0_1",
        "L0a1",
        "L2a1",
        "3_1",
        "4_1",
        "L5a1",
        "L6a4",
    ]
    assert all(row["passed"] for row in report["cases"])
    assert report["checks"]["algorithm_boundary_cases_certified"] is True
    assert report["algorithm_boundary_case_count"] == 2
    assert report["passed_algorithm_boundary_case_count"] == 2
    boundary_rows = {
        row["boundary_case_id"]: row
        for row in report["algorithm_boundary_cases"]
    }
    assert boundary_rows["rectangular_2x3_r2_zero_ideal"]["passed"] is True
    assert boundary_rows["rectangular_2x3_r2_zero_ideal"]["computation"][
        "admissible_minor_summary"
    ]["matrix_size"] == [2, 3]
    split_boundary = boundary_rows[
        "nonzero_crossing_split_free_component_zero_ideal"
    ]
    assert split_boundary["passed"] is True
    assert split_boundary["diagram_crossing_count"] > 0
    assert split_boundary["diagram_component_count"] == 2
    assert split_boundary["oriented_component_traversal_count"] == 1
    assert split_boundary["computation"]["split_free_component_count"] == 1
    assert split_boundary["computation"]["split_free_component_certified"] is True
    assert split_boundary["computation"]["zero_ideal_certified"] is True
    terminal_rows = {
        row["notation"]: row
        for row in report["cases"]
        if row["case_kind"] == "zero_crossing_terminal"
    }
    assert set(terminal_rows) == {"0_1", "L0a1"}
    assert all(
        row["exact_algorithm"]
        == "zero_crossing_unlink_exact_normalization_v1"
        for row in terminal_rows.values()
    )
    assert all(
        row["checks"]["uncapped_exact_result_replay_certified"] is True
        for row in terminal_rows.values()
    )
    assert terminal_rows["0_1"]["zero_ideal_certified"] is False
    assert terminal_rows["L0a1"]["zero_ideal_certified"] is True
    assert pack["full_multivariable_alexander_normalization_certified"] is False
    assert pack["certification_report_url"] == "embedded:certification_report"
    assert pack["producer_preflight_artifact_certified"] is False
    assert "certification_report_url_http" in pack["producer_preflight_failed_checks"]
    assert "published_certification_report_witness_verified" in pack[
        "producer_preflight_failed_checks"
    ]
    assert "certification_report_url_http" in pack["producer_failed_checks"]
    assert "published_report_downloaded" in pack["producer_failed_checks"]
    assert pack["completion_claimed"] is False
    assert published_exit_code == 0, {
        "producer": published_pack["producer_failed_checks"],
        "preflight": published_pack["producer_preflight_failed_checks"],
    }
    assert published_pack["certification_report_url"] == published_url
    assert published_pack["certification_report_sha256"] == published_pack[
        "certification_report_raw_sha256"
    ]
    assert published_pack["certification_report_canonical_sha256"] != (
        published_pack["certification_report_raw_sha256"]
    )
    assert published_pack["certification_report_published_witness"][
        "sha256_verified"
    ] is True
    assert published_pack["certification_report_published_json_matches"] is True
    assert published_pack["producer_checks"]["published_report_downloaded"] is True
    assert published_pack["producer_checks"][
        "published_report_raw_bytes_match_local_report"
    ] is True
    assert published_pack["producer_checks"][
        "published_report_canonical_sha256_matches_local_report"
    ] is True
    assert published_pack["certification_report_replay_audit"][
        "algorithm_boundary_replay_match_count"
    ] == 2
    assert published_pack["producer_preflight_artifact_certified"] is True
    assert mismatched_exit_code == 1
    assert mismatched_pack["full_multivariable_alexander_normalization_certified"] is False
    assert mismatched_pack["producer_checks"][
        "published_report_raw_bytes_match_local_report"
    ] is False
    assert mismatched_pack["producer_checks"][
        "published_report_json_matches_local_report"
    ] is False
    assert mismatched_pack["producer_preflight_artifact_certified"] is False
    assert mismatched_pack["completion_claimed"] is False
    assert tampered_audit["artifact_certified"] is False
    assert "embedded_certification_report_replay_certified" in tampered_audit[
        "failed_checks"
    ]
    assert missing_report_audit["artifact_certified"] is False
    assert "embedded_certification_report_available" in missing_report_audit[
        "failed_checks"
    ]
    for witness_audit in (
        missing_published_witness_audit,
        tampered_published_witness_audit,
    ):
        assert witness_audit["artifact_certified"] is False
        assert "published_certification_report_witness_verified" in witness_audit[
            "failed_checks"
        ]
    for page_audit in (
        missing_page_witness_audit,
        tampered_page_witness_audit,
    ):
        assert page_audit["artifact_certified"] is False
        assert "external_table_page_sources_match_pinned_revisions" in page_audit[
            "failed_checks"
        ]


def test_cli_verified_signed_crossing_assignment_audit_rejects_duplicate_table_witnesses(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "verified_signed_crossing_assignment_L5a1.json"
        _write_verified_signed_crossing_assignment(
            path,
            notation="L5a1",
            crossing_count=5,
        )
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["invariant_table_source_urls"] = [
            "https://evidence.iroll.dev/tables/L5a1",
            "https://evidence.iroll.dev/tables/L5a1",
        ]
        payload["invariant_table_source_sha256s"] = ["b" * 64, "b" * 64]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "verified-signed-crossing-assignment-audit",
                str(path),
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["assignment_certified"] is False
    assert report["failed_checks"] == [
        "invariant_table_source_urls_unique",
        "invariant_table_source_sha256s_unique",
        "invariant_table_source_witness_pairs_unique",
    ]
    assert report["ci_exit_code"] == 1


def test_cli_verified_signed_crossing_assignment_audit_rejects_malformed_table_witness_items(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "verified_signed_crossing_assignment_L5a1.json"
        _write_verified_signed_crossing_assignment(
            path,
            notation="L5a1",
            crossing_count=5,
        )
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["invariant_table_source_urls"] = [
            "https://evidence.iroll.dev/tables/L5a1",
            "",
        ]
        payload["invariant_table_source_sha256s"] = ["b" * 64, 7]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "verified-signed-crossing-assignment-audit",
                str(path),
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["assignment_certified"] is False
    assert "invariant_table_source_urls_items_nonempty_strings" in report[
        "failed_checks"
    ]
    assert "invariant_table_source_sha256s_items_nonempty_strings" in report[
        "failed_checks"
    ]
    assert report["ci_exit_code"] == 1


def test_cli_verified_signed_crossing_assignment_audit_rejects_source_url_reused_as_table_witness(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "verified_signed_crossing_assignment_L5a1.json"
        _write_verified_signed_crossing_assignment(
            path,
            notation="L5a1",
            crossing_count=5,
        )
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["invariant_table_source_urls"] = [payload["source_url"]]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "verified-signed-crossing-assignment-audit",
                str(path),
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["assignment_certified"] is False
    assert report["failed_checks"] == [
        "source_url_not_invariant_table_source_urls"
    ]
    assert report["ci_exit_code"] == 1


def test_cli_verified_signed_crossing_assignment_audit_rejects_source_url_notation_mismatch(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "verified_signed_crossing_assignment_L5a1.json"
        _write_verified_signed_crossing_assignment(
            path,
            notation="L5a1",
            crossing_count=5,
        )
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["source_url"] = "https://katlas.org/wiki/L6a4"
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "verified-signed-crossing-assignment-audit",
                str(path),
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["assignment_certified"] is False
    assert report["failed_checks"] == ["source_url_matches_notation"]
    assert report["ci_exit_code"] == 1


def test_cli_verified_signed_crossing_assignment_audit_rejects_replay_digest_reused_as_table_digest(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "verified_signed_crossing_assignment_L5a1.json"
        _write_verified_signed_crossing_assignment(
            path,
            notation="L5a1",
            crossing_count=5,
        )
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["invariant_table_source_sha256s"] = [
            payload["candidate_replay_sha256"]
        ]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "verified-signed-crossing-assignment-audit",
                str(path),
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["assignment_certified"] is False
    assert report["failed_checks"] == [
        "candidate_replay_sha256_not_invariant_table_source_sha256s"
    ]
    assert report["ci_exit_code"] == 1


def test_cli_verified_signed_crossing_assignment_audit_rejects_boolean_count(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "verified_signed_crossing_assignment_L5a1.json"
        _write_verified_signed_crossing_assignment(
            path,
            notation="L5a1",
            crossing_count=1,
        )
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["crossing_count"] = True
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "verified-signed-crossing-assignment-audit",
                str(path),
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["assignment_certified"] is False
    assert "crossing_count_positive" in report["failed_checks"]
    assert "signs_match_crossing_count" in report["failed_checks"]
    assert "role_orders_match_crossing_count" in report["failed_checks"]
    assert report["assignment_evidence"]["crossing_count"] == 0
    assert report["ci_exit_code"] == 1


def test_cli_verified_signed_crossing_assignment_audit_rejects_string_count(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "verified_signed_crossing_assignment_L5a1.json"
        _write_verified_signed_crossing_assignment(
            path,
            notation="L5a1",
            crossing_count=1,
        )
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["crossing_count"] = "1"
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "verified-signed-crossing-assignment-audit",
                str(path),
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["assignment_certified"] is False
    assert "crossing_count_positive" in report["failed_checks"]
    assert report["assignment_evidence"]["crossing_count"] == 0
    assert report["ci_exit_code"] == 1


def test_cli_verified_signed_crossing_assignment_audit_rejects_crossing_count_mismatch(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "verified_signed_crossing_assignment_L5a1.json"
        _write_verified_signed_crossing_assignment(
            path,
            notation="L5a1",
            crossing_count=6,
        )

        exit_code = main(
            [
                "verified-signed-crossing-assignment-audit",
                str(path),
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["assignment_certified"] is False
    assert report["failed_checks"] == ["crossing_count_matches_notation"]
    assert report["ci_exit_code"] == 1


def test_cli_verified_signed_crossing_assignment_audit_rejects_invalid_signs(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "verified_signed_crossing_assignment_L5a1.json"
        _write_verified_signed_crossing_assignment(
            path,
            notation="L5a1",
            crossing_count=5,
        )
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["signs"] = [1, 1, 1, 1, 0]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "verified-signed-crossing-assignment-audit",
                str(path),
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["assignment_certified"] is False
    assert report["failed_checks"] == ["signs_are_plus_or_minus_one"]
    assert report["ci_exit_code"] == 1


def test_cli_verified_signed_crossing_assignment_audit_rejects_boolean_signs(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "verified_signed_crossing_assignment_L5a1.json"
        _write_verified_signed_crossing_assignment(
            path,
            notation="L5a1",
            crossing_count=5,
        )
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["signs"] = [True, 1, 1, 1, 1]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "verified-signed-crossing-assignment-audit",
                str(path),
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["assignment_certified"] is False
    assert report["failed_checks"] == ["signs_are_plus_or_minus_one"]
    assert report["ci_exit_code"] == 1


def test_cli_verified_signed_crossing_assignment_audit_rejects_invalid_role_orders(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "verified_signed_crossing_assignment_L5a1.json"
        _write_verified_signed_crossing_assignment(
            path,
            notation="L5a1",
            crossing_count=5,
        )
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["role_orders"] = [[0, 0, 1, 2]] + [[0, 1, 2, 3] for _ in range(4)]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "verified-signed-crossing-assignment-audit",
                str(path),
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["assignment_certified"] is False
    assert report["failed_checks"] == ["role_orders_are_four_role_permutations"]
    assert report["ci_exit_code"] == 1


def test_cli_verified_signed_crossing_assignment_audit_rejects_non_integer_role_orders(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "verified_signed_crossing_assignment_L5a1.json"
        _write_verified_signed_crossing_assignment(
            path,
            notation="L5a1",
            crossing_count=5,
        )
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["role_orders"] = [[False, 1, 2, "3"]] + [
            [0, 1, 2, 3] for _ in range(4)
        ]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "verified-signed-crossing-assignment-audit",
                str(path),
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["assignment_certified"] is False
    assert report["failed_checks"] == ["role_orders_are_four_role_permutations"]
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_fails_release_manifest(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "signed_release_publication_manifest.json"
        path.write_text(
            json.dumps(
                {
                    "artifact_schema_version": 1,
                    "artifact_kind": "signed_release_publication_manifest",
                    "claim_scope": "signed_release_publication",
                    "signed_release_artifacts_published": True,
                    "publication_claimed": True,
                    "platform_index_publication_claimed": True,
                    "published_artifact_count": 1,
                    "signature_count": 0,
                    "package_index_url": "https://evidence.iroll.dev",
                    "artifact_urls": [
                        "https://evidence.iroll.dev/iroll-0.1.0.whl",
                    ],
                    "artifact_sha256s": ["a" * 64],
                    "signature_urls": [],
                    "signature_sha256s": [],
                }
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--fail-on-not-certified",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert payload["artifact_kind"] == "completion_evidence_artifact_audit"
    assert payload["claim_scope"] == "completion_evidence_artifact_preflight"
    assert payload["audited_artifact_type"] == "signed_release_publication_manifest"
    assert payload["completion_evidence_artifact_filenames"] == [
        "signed_release_publication_manifest.json"
    ]
    assert payload["completion_evidence_artifact_instance_row_count"] == 1
    assert payload["completion_evidence_artifact_filenames_are_expected"] is True
    assert (
        payload[
            "completion_evidence_template_to_artifact_filenames_match_artifact_filenames"
        ]
        is True
    )
    assert (
        payload[
            "completion_evidence_artifact_filename_count_matches_instance_row_count"
        ]
        is True
    )
    assert (
        payload[
            "completion_evidence_artifact_filename_signature_matches_instance_rows"
        ]
        is True
    )
    assert payload["completion_evidence_producer_metadata_consistency_passed"] is True
    assert payload["completion_evidence_final_completion_failed_gates"] == [
        "release_artifacts"
    ]
    assert payload["completion_evidence_final_completion_blocker_codes"] == [
        "release_artifacts_not_published"
    ]
    assert payload["completion_evidence_final_completion_blocker_labels"] == [
        "release_artifacts"
    ]
    assert payload["completion_evidence_artifact_instance_rows"][0][
        "final_completion_failed_gate_signature"
    ] == "release_artifacts"
    assert payload["expected_evidence_filename_count"] == 6
    assert payload["bundle_all_inputs_command"].endswith(
        "-o completion-evidence-bundle.json"
    )
    assert payload["artifact_certified"] is False
    assert payload["failed_checks"] == [
        "signature_count",
        "signature_count_matches_published_artifact_count",
        "signature_urls_available",
        "signature_urls_items_nonempty_strings",
        "signature_url_filenames_unique",
        "signature_url_filenames_have_signature_extension",
        "signature_urls_match_artifact_url_filenames",
        "signature_sha256s_available",
        "signature_sha256s_items_nonempty_strings",
        "signature_url_sha256_pairs_unique",
    ]
    assert payload["artifact_field_coverage_complete"] is False
    assert payload["missing_artifact_fields"] == [
        "signature_urls",
        "signature_sha256s",
    ]
    assert "signature_urls" in payload["required_artifact_fields"]
    assert "signature_sha256s" in payload["required_artifact_fields"]
    assert payload["artifact_evidence"]["evidence_id"] == (
        "signed_release_publication_manifest"
    )
    assert payload["ci_fail_on_not_certified"] is True
    assert payload["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_unsigned_artifact_count(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "signed_release_publication_manifest.json"
        _write_signed_release_publication_manifest(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["signature_count"] = 1
        payload["signature_urls"] = [
            "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0.whl.sig"
        ]
        payload["signature_sha256s"] = ["c" * 64]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "signed_release_publication_manifest",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["artifact_field_coverage_complete"] is True
    assert report["missing_artifact_fields"] == []
    assert report["failed_checks"] == [
        "signature_count_matches_published_artifact_count",
        "signature_urls_match_artifact_url_filenames",
    ]
    assert report["artifact_evidence"]["published_artifact_count"] == 2
    assert report["artifact_evidence"]["signature_count"] == 1
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_duplicate_release_witnesses(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "signed_release_publication_manifest.json"
        _write_signed_release_publication_manifest(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["artifact_urls"] = [
            payload["artifact_urls"][0],
            payload["artifact_urls"][0],
        ]
        payload["artifact_sha256s"] = ["a" * 64, "a" * 64]
        payload["signature_urls"] = [
            payload["signature_urls"][0],
            payload["signature_urls"][0],
        ]
        payload["signature_sha256s"] = ["c" * 64, "c" * 64]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "signed_release_publication_manifest",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["failed_checks"] == [
        "artifact_urls_unique",
        "artifact_url_filenames_unique",
        "artifact_sha256s_unique",
        "artifact_url_sha256_pairs_unique",
        "signature_urls_unique",
        "signature_url_filenames_unique",
        "signature_sha256s_unique",
        "signature_url_sha256_pairs_unique",
    ]
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_duplicate_release_filenames(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "signed_release_publication_manifest.json"
        _write_signed_release_publication_manifest(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["artifact_urls"] = [
            "https://evidence.iroll.dev/releases/0.1.0/linux/iroll-0.1.0.whl",
            "https://evidence.iroll.dev/releases/0.1.0/windows/iroll-0.1.0.whl",
        ]
        payload["signature_urls"] = [
            "https://evidence.iroll.dev/releases/0.1.0/linux/iroll-0.1.0.whl.sig",
            "https://evidence.iroll.dev/releases/0.1.0/windows/iroll-0.1.0.whl.sig",
        ]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "signed_release_publication_manifest",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["failed_checks"] == [
        "artifact_url_filenames_unique",
        "signature_url_filenames_unique",
    ]
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_malformed_release_witness_items(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "signed_release_publication_manifest.json"
        _write_signed_release_publication_manifest(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["artifact_urls"] = [payload["artifact_urls"][0], ""]
        payload["artifact_sha256s"] = [payload["artifact_sha256s"][0], False]
        payload["signature_urls"] = [payload["signature_urls"][0], 13]
        payload["signature_sha256s"] = [payload["signature_sha256s"][0], ""]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "signed_release_publication_manifest",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert "artifact_urls_items_nonempty_strings" in report["failed_checks"]
    assert "artifact_sha256s_items_nonempty_strings" in report["failed_checks"]
    assert "signature_urls_items_nonempty_strings" in report["failed_checks"]
    assert "signature_sha256s_items_nonempty_strings" in report["failed_checks"]
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_release_url_role_reuse(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "signed_release_publication_manifest.json"
        _write_signed_release_publication_manifest(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        reused_url = "https://evidence.iroll.dev/releases/0.1.0/iroll-shared"
        payload["package_index_url"] = reused_url
        payload["artifact_urls"][0] = reused_url
        payload["signature_urls"][0] = payload["artifact_urls"][1]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "signed_release_publication_manifest",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert "package_index_url_not_artifact_or_signature_url" in report[
        "failed_checks"
    ]
    assert "artifact_urls_disjoint_from_signature_urls" in report["failed_checks"]
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_signature_url_artifact_mismatch(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "signed_release_publication_manifest.json"
        _write_signed_release_publication_manifest(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["signature_urls"][1] = (
            "https://evidence.iroll.dev/releases/0.1.0/not-the-tarball.sig"
        )
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "signed_release_publication_manifest",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["failed_checks"] == [
        "signature_urls_match_artifact_url_filenames"
    ]
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_signature_url_non_signature_extension(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "signed_release_publication_manifest.json"
        _write_signed_release_publication_manifest(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["signature_urls"][1] = (
            "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0.tar.gz.txt"
        )
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "signed_release_publication_manifest",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["failed_checks"] == [
        "signature_url_filenames_have_signature_extension"
    ]
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_release_digest_role_reuse(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "signed_release_publication_manifest.json"
        _write_signed_release_publication_manifest(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["signature_sha256s"][0] = payload["artifact_sha256s"][1]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "signed_release_publication_manifest",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["failed_checks"] == [
        "artifact_sha256s_disjoint_from_signature_sha256s"
    ]
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_boolean_release_count(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "signed_release_publication_manifest.json"
        _write_signed_release_publication_manifest(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["published_artifact_count"] = True
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "signed_release_publication_manifest",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["failed_checks"] == [
        "published_artifact_count",
        "signature_count_matches_published_artifact_count",
        "artifact_url_count_matches_published_artifact_count",
        "artifact_sha256_count_matches_published_artifact_count",
    ]
    assert report["artifact_evidence"]["published_artifact_count"] == 0
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_string_release_count(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "signed_release_publication_manifest.json"
        _write_signed_release_publication_manifest(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["signature_count"] = "2"
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "signed_release_publication_manifest",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert "signature_count" in report["failed_checks"]
    assert "signature_count_matches_published_artifact_count" in report[
        "failed_checks"
    ]
    assert report["artifact_evidence"]["signature_count"] == 0
    assert report["ci_exit_code"] == 1


def test_cli_verified_signed_crossing_assignment_readiness_reports_blockers(
    capsys,
) -> None:
    exit_code = main(["verified-signed-crossing-assignment-readiness"])
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["artifact_kind"] == (
        "verified_signed_crossing_assignment_readiness_report"
    )
    assert payload["claim_scope"] == "verified_signed_crossing_assignment_readiness"
    assert payload["required_artifact"] == "verified_signed_crossing_assignment"
    assert payload["completion_evidence_artifact_filename_count"] == 2
    assert payload["completion_evidence_artifact_filenames"] == [
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert payload["completion_evidence_artifact_instance_row_count"] == 2
    assert payload["completion_evidence_artifact_filenames_are_expected"] is True
    assert (
        payload[
            "completion_evidence_template_to_artifact_filenames_match_artifact_filenames"
        ]
        is True
    )
    assert (
        payload[
            "completion_evidence_artifact_filename_count_matches_instance_row_count"
        ]
        is True
    )
    assert (
        payload[
            "completion_evidence_artifact_filename_signature_matches_instance_rows"
        ]
        is True
    )
    assert payload["completion_evidence_producer_metadata_consistency_passed"] is True
    assert payload["expected_evidence_filename_count"] == 6
    assert "verified_signed_crossing_assignment.L6a4.json" in payload[
        "expected_evidence_filenames"
    ]
    assert payload["required_notations"] == ["L5a1", "L6a4"]
    assert payload["readiness_all_ready"] is False
    assert payload["readiness_ready_count"] == 0
    assert payload["readiness_blocker_signature"] == (
        "external_source_assignment_verified:2,"
        "invariant_table_values_verified:2,unique_sign_pattern:2"
    )
    rows = {row["notation"]: row for row in payload["readiness_rows"]}
    assert rows["L5a1"]["matching_candidate_count"] == 24
    assert rows["L5a1"]["unique_sign_pattern_count"] == 12
    assert rows["L5a1"]["complete_candidate_set"] is True
    assert rows["L6a4"]["matching_candidate_count"] == 8
    assert rows["L6a4"]["unique_sign_pattern_count"] == 8
    assert rows["L6a4"]["complete_candidate_set"] is True
    assert rows["L6a4"]["readiness_blockers"] == [
        "unique_sign_pattern",
        "invariant_table_values_verified",
        "external_source_assignment_verified",
    ]
    assert payload["completion_claimed"] is False
    assert payload["ci_exit_code"] == 0


def test_cli_verified_signed_crossing_assignment_readiness_can_fail_ci(
    capsys,
) -> None:
    exit_code = main(
        [
            "verified-signed-crossing-assignment-readiness",
            "--fail-on-not-ready",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert payload["readiness_all_ready"] is False
    assert payload["ci_fail_on_not_ready"] is True
    assert payload["ci_exit_code"] == 1


def test_cli_production_imgui_renderer_framebuffer_readiness_reports_blockers(
    capsys,
) -> None:
    exit_code = main(["production-imgui-renderer-framebuffer-readiness"])
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["artifact_kind"] == (
        "production_imgui_renderer_framebuffer_readiness_report"
    )
    assert payload["claim_scope"] == "production_imgui_renderer_framebuffer_readiness"
    assert payload["required_artifact"] == (
        "production_imgui_renderer_framebuffer_pack"
    )
    assert payload["completion_evidence_artifact_filenames"] == [
        "production_imgui_renderer_framebuffer_pack.json"
    ]
    assert payload["completion_evidence_artifact_instance_row_count"] == 1
    assert payload["completion_evidence_artifact_filenames_are_expected"] is True
    assert (
        payload[
            "completion_evidence_template_to_artifact_filenames_match_artifact_filenames"
        ]
        is True
    )
    assert (
        payload[
            "completion_evidence_artifact_filename_count_matches_instance_row_count"
        ]
        is True
    )
    assert (
        payload[
            "completion_evidence_artifact_filename_signature_matches_instance_rows"
        ]
        is True
    )
    assert payload["completion_evidence_producer_metadata_consistency_passed"] is True
    assert payload["completion_evidence_final_completion_failed_gates"] == [
        "non_diagram_requirements",
        "production_imgui_renderer",
    ]
    assert payload["completion_evidence_final_completion_blocker_codes"] == [
        "native_imgui_screenshot_framebuffer_fixtures_partial",
        "production_imgui_renderer_not_verified",
    ]
    assert payload["completion_evidence_final_completion_blocker_count"] == 2
    assert payload["expected_evidence_filename_count"] == 6
    assert payload["bundle_all_inputs_command"].endswith(
        "-o completion-evidence-bundle.json"
    )
    assert payload["readiness_all_ready"] is False
    assert payload["readiness_blocker_signature"] == (
        "estimated_nonzero_pixels,framebuffer_height,framebuffer_touched,"
        "framebuffer_width,graphics_backend_name,passed,"
        "real_graphics_backend_framebuffer_verified,render_frame_count,screenshot_url,"
        "screenshot_verified"
    )
    assert payload["readiness_blocker_codes"] == payload["readiness_blockers"]
    assert payload["readiness_blocker_code_counts"] == {
        blocker: 1 for blocker in payload["readiness_blockers"]
    }
    assert payload["readiness_blocker_count_signature"] == (
        "estimated_nonzero_pixels:1,framebuffer_height:1,framebuffer_touched:1,"
        "framebuffer_width:1,graphics_backend_name:1,passed:1,"
        "real_graphics_backend_framebuffer_verified:1,render_frame_count:1,screenshot_url:1,"
        "screenshot_verified:1"
    )
    assert payload["production_pack_available"] is False
    assert payload["production_pack_certified"] is False
    assert payload["retained_evidence_count"] == 2
    assert payload["retained_stub_framebuffer_smoke_count"] == 1
    assert payload["retained_real_graphics_backend_framebuffer_verified_count"] == 0
    assert payload["retained_screenshot_verified_count"] == 0
    assert payload["ci_exit_code"] == 0


def test_cli_production_imgui_renderer_framebuffer_readiness_accepts_pack(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "production_imgui_renderer_framebuffer_pack.json"
        path.write_text(
            json.dumps(
                {
                    "artifact_schema_version": 1,
                    "artifact_kind": "imgui_production_renderer_framebuffer_pack",
                    "claim_scope": (
                        "production_imgui_renderer_framebuffer_verification"
                    ),
                    "passed": True,
                    "render_frame_count": 2,
                    "framebuffer_touched": 1,
                    "estimated_nonzero_pixels": 8192,
                    "graphics_backend_name": "wgpu-vulkan",
                    "framebuffer_width": 128,
                    "framebuffer_height": 64,
                    "screenshot_url": (
                        "https://evidence.iroll.dev/production-imgui.png"
                    ),
                    "screenshot_sha256": "a" * 64,
                    "real_graphics_backend_framebuffer_verified": True,
                    "screenshot_verified": True,
                }
            ),
            encoding="utf-8",
        )
        exit_code = main(
            [
                "production-imgui-renderer-framebuffer-readiness",
                "--production-imgui-renderer-framebuffer-pack-json",
                str(path),
                "--fail-on-not-ready",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["readiness_all_ready"] is True
    assert payload["readiness_blockers"] == []
    assert payload["readiness_blocker_codes"] == []
    assert payload["readiness_blocker_code_counts"] == {}
    assert payload["readiness_blocker_count_signature"] == ""
    assert payload["production_pack_available"] is True
    assert payload["production_pack_certified"] is True
    assert payload["production_gate_passed"] is True
    assert payload["retained_real_graphics_backend_framebuffer_verified_count"] == 1
    assert payload["retained_screenshot_verified_count"] == 1
    assert payload["ci_fail_on_not_ready"] is True
    assert payload["ci_exit_code"] == 0


def test_cli_signed_release_publication_readiness_reports_blockers(capsys) -> None:
    exit_code = main(["signed-release-publication-readiness"])
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["artifact_kind"] == "signed_release_publication_readiness_report"
    assert payload["claim_scope"] == "signed_release_publication_readiness"
    assert payload["required_artifact"] == "signed_release_publication_manifest"
    assert payload["completion_evidence_artifact_filenames"] == [
        "signed_release_publication_manifest.json"
    ]
    assert payload["final_validation_command"].endswith("--fail-on-not-ready")
    assert payload["readiness_all_ready"] is False
    assert payload["readiness_blocker_signature"] == (
        "artifact_urls,package_index_url,platform_index_publication_claimed,"
        "publication_claimed,published_artifact_count,signature_count,"
        "signature_urls,signed_release_artifacts_published"
    )
    assert payload["readiness_blocker_codes"] == payload["readiness_blockers"]
    assert payload["readiness_blocker_code_counts"] == {
        blocker: 1 for blocker in payload["readiness_blockers"]
    }
    assert payload["readiness_blocker_count_signature"] == (
        "artifact_urls:1,package_index_url:1,"
        "platform_index_publication_claimed:1,publication_claimed:1,"
        "published_artifact_count:1,signature_count:1,signature_urls:1,"
        "signed_release_artifacts_published:1"
    )
    assert payload["release_manifest_available"] is False
    assert payload["release_manifest_certified"] is False
    assert payload["retained_evidence_count"] == 2
    assert payload["retained_unsigned_ci_release_manifest_count"] == 1
    assert payload["retained_signed_release_artifacts_published_count"] == 0
    assert payload["retained_publication_claimed_count"] == 0
    assert payload["retained_platform_index_publication_claimed_count"] == 0
    assert payload["ci_exit_code"] == 0


def test_cli_signed_release_publication_readiness_accepts_manifest(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "signed_release_publication_manifest.json"
        path.write_text(
            json.dumps(
                {
                    "artifact_schema_version": 1,
                    "artifact_kind": "signed_release_publication_manifest",
                    "claim_scope": "signed_release_publication",
                    "signed_release_artifacts_published": True,
                    "publication_claimed": True,
                    "platform_index_publication_claimed": True,
                    "published_artifact_count": 2,
                    "signature_count": 2,
                    "package_index_url": (
                        "https://evidence.iroll.dev/releases/0.1.0"
                    ),
                    "artifact_urls": [
                        "https://evidence.iroll.dev/releases/0.1.0/iroll.whl",
                        "https://evidence.iroll.dev/releases/0.1.0/iroll.tar.gz",
                    ],
                    "artifact_sha256s": ["a" * 64, "b" * 64],
                    "signature_urls": [
                        "https://evidence.iroll.dev/releases/0.1.0/iroll.whl.sig",
                        "https://evidence.iroll.dev/releases/0.1.0/iroll.tar.gz.sig",
                    ],
                    "signature_sha256s": ["c" * 64, "d" * 64],
                }
            ),
            encoding="utf-8",
        )
        exit_code = main(
            [
                "signed-release-publication-readiness",
                "--signed-release-publication-manifest-json",
                str(path),
                "--fail-on-not-ready",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["readiness_all_ready"] is True
    assert payload["readiness_blockers"] == []
    assert payload["readiness_blocker_codes"] == []
    assert payload["readiness_blocker_code_counts"] == {}
    assert payload["readiness_blocker_count_signature"] == ""
    assert payload["release_manifest_available"] is True
    assert payload["release_manifest_certified"] is True
    assert payload["release_manifest_evidence"][
        "artifact_url_sha256_pair_signature"
    ] == (
        "https://evidence.iroll.dev/releases/0.1.0/iroll.whl#"
        + "a" * 64
        + "|https://evidence.iroll.dev/releases/0.1.0/iroll.tar.gz#"
        + "b" * 64
    )
    assert payload["release_manifest_evidence"][
        "signature_url_sha256_pair_signature"
    ] == (
        "https://evidence.iroll.dev/releases/0.1.0/iroll.whl.sig#"
        + "c" * 64
        + "|https://evidence.iroll.dev/releases/0.1.0/iroll.tar.gz.sig#"
        + "d" * 64
    )
    assert payload["release_gate_passed"] is True
    assert payload["retained_signed_release_artifacts_published_count"] == 1
    assert payload["retained_publication_claimed_count"] == 1
    assert payload["retained_platform_index_publication_claimed_count"] == 1
    assert payload["ci_fail_on_not_ready"] is True
    assert payload["ci_exit_code"] == 0


def test_cli_full_homfly_pt_evaluation_readiness_reports_blockers(capsys) -> None:
    exit_code = main(["full-homfly-pt-evaluation-readiness"])
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["artifact_kind"] == "full_homfly_pt_evaluation_readiness_report"
    assert payload["claim_scope"] == "full_homfly_pt_evaluation_readiness"
    assert payload["required_artifact"] == "full_homfly_pt_evaluation_certification_pack"
    assert payload["completion_evidence_artifact_filenames"] == [
        "full_homfly_pt_evaluation_certification_pack.json"
    ]
    assert payload["expected_evidence_filename_count"] == 6
    assert payload["readiness_all_ready"] is False
    assert payload["readiness_blocker_signature"] == (
        "arbitrary_signed_pd_coverage_certified,certification_report_url,"
        "counterexample_count_zero,external_table_normalization_certified,"
        "external_table_source_urls,registered_fixture_regression_certified,"
        "skein_relation_certified"
    )
    assert payload["readiness_blocker_codes"] == payload["readiness_blockers"]
    assert payload["readiness_blocker_code_counts"] == {
        blocker: 1 for blocker in payload["readiness_blockers"]
    }
    assert payload["readiness_blocker_count_signature"] == (
        "arbitrary_signed_pd_coverage_certified:1,certification_report_url:1,"
        "counterexample_count_zero:1,external_table_normalization_certified:1,"
        "external_table_source_urls:1,registered_fixture_regression_certified:1,"
        "skein_relation_certified:1"
    )
    assert payload["certification_pack_available"] is False
    assert payload["certification_pack_certified"] is False
    assert payload["retained_evidence_count"] == 2
    assert payload["retained_repository_test_count"] == 2
    assert payload["retained_registered_fixture_scope_count"] == 1
    assert payload["retained_bounded_scope_count"] == 1
    assert payload["ci_exit_code"] == 0


def test_cli_full_homfly_pt_evaluation_readiness_accepts_pack(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "full_homfly_pt_evaluation_certification_pack.json"
        _write_full_homfly_certification_pack(path)
        exit_code = main(
            [
                "full-homfly-pt-evaluation-readiness",
                "--full-homfly-pt-evaluation-certification-pack-json",
                str(path),
                "--fail-on-not-ready",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["readiness_all_ready"] is True
    assert payload["readiness_blockers"] == []
    assert payload["readiness_blocker_codes"] == []
    assert payload["readiness_blocker_code_counts"] == {}
    assert payload["readiness_blocker_count_signature"] == ""
    assert payload["certification_pack_available"] is True
    assert payload["certification_pack_certified"] is True
    assert payload["certification_gate_passed"] is True
    assert payload["ci_fail_on_not_ready"] is True
    assert payload["ci_exit_code"] == 0


def test_cli_fixture_validation_pack_audit_rejects_homfly_pack_without_counterexamples(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "full_homfly_pt_evaluation_certification_pack.json"
        _write_full_homfly_certification_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload.pop("counterexample_count")
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--full-homfly-pt-evaluation-certification-pack-json",
                str(path),
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert report["full_homfly_pt_evaluation_certified"] is False
    assert report["final_completion_blocker_code_counts"][
        "full_homfly_pt_evaluation_not_certified"
    ] == 1
    gate_checks = {row["gate"]: row for row in report["final_completion_gate_checks"]}
    assert gate_checks["full_homfly_pt_evaluation"]["passed"] is False


def test_cli_fixture_validation_pack_audit_rejects_homfly_string_counterexamples(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "full_homfly_pt_evaluation_certification_pack.json"
        _write_full_homfly_certification_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["counterexample_count"] = "0"
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--full-homfly-pt-evaluation-certification-pack-json",
                str(path),
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert report["full_homfly_pt_evaluation_certified"] is False
    assert report["final_completion_blocker_code_counts"][
        "full_homfly_pt_evaluation_not_certified"
    ] == 1


def test_cli_fixture_validation_pack_audit_rejects_homfly_duplicate_external_table_witnesses(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "full_homfly_pt_evaluation_certification_pack.json"
        _write_full_homfly_certification_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["external_table_source_urls"] = [
            "https://evidence.iroll.dev/tables/homfly",
            "https://evidence.iroll.dev/tables/homfly",
        ]
        payload["external_table_source_sha256s"] = ["b" * 64, "b" * 64]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "full_homfly_pt_evaluation_certification_pack",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["failed_checks"] == [
        "pinned_external_table_sources_exact",
        "external_table_source_urls_unique",
        "external_table_source_url_filenames_unique",
        "external_table_source_sha256s_unique",
        "external_table_source_witness_pairs_unique",
    ]
    assert report["ci_exit_code"] == 1


def test_cli_fixture_validation_pack_audit_rejects_homfly_duplicate_external_table_filenames(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "full_homfly_pt_evaluation_certification_pack.json"
        _write_full_homfly_certification_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["external_table_source_urls"] = [
            "https://evidence.iroll.dev/tables/homfly/source.json",
            "https://mirror.iroll.dev/tables/homfly/source.json",
        ]
        payload["external_table_source_sha256s"] = ["b" * 64, "c" * 64]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "full_homfly_pt_evaluation_certification_pack",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["failed_checks"] == [
        "pinned_external_table_sources_exact",
        "external_table_source_url_filenames_unique"
    ]
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_homfly_report_url_reused_as_table_source(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "full_homfly_pt_evaluation_certification_pack.json"
        _write_full_homfly_certification_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["external_table_source_urls"] = [
            payload["certification_report_url"]
        ]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "full_homfly_pt_evaluation_certification_pack",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["failed_checks"] == [
        "pinned_external_table_sources_exact",
        "certification_report_url_not_external_table_source_urls",
        "external_table_source_sha256_count_matches_source_url_count",
        "external_table_source_witness_pairs_unique",
    ]
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_homfly_report_digest_reused_as_table_digest(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "full_homfly_pt_evaluation_certification_pack.json"
        _write_full_homfly_certification_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["external_table_source_sha256s"] = [
            payload["certification_report_sha256"]
        ]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "full_homfly_pt_evaluation_certification_pack",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["failed_checks"] == [
        "pinned_external_table_sources_exact",
        "certification_report_sha256_not_external_table_source_sha256s",
        "external_table_source_sha256_count_matches_source_url_count",
        "external_table_source_witness_pairs_unique",
    ]
    assert report["ci_exit_code"] == 1


def test_cli_full_multivariable_alexander_normalization_readiness_reports_blockers(
    capsys,
) -> None:
    exit_code = main(["full-multivariable-alexander-normalization-readiness"])
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["artifact_kind"] == (
        "full_multivariable_alexander_normalization_readiness_report"
    )
    assert payload["claim_scope"] == (
        "full_multivariable_alexander_normalization_readiness"
    )
    assert payload["required_artifact"] == (
        "full_multivariable_alexander_normalization_certification_pack"
    )
    assert payload["completion_evidence_artifact_filenames"] == [
        "full_multivariable_alexander_normalization_certification_pack.json"
    ]
    assert payload["directory_audit_command"].endswith("--fail-on-not-ready")
    assert payload["readiness_all_ready"] is False
    assert payload["readiness_blocker_signature"] == (
        "admissible_minor_normalization_certified,"
        "all_admissible_minors_consistent,certification_report_url,"
        "counterexample_count_zero,external_table_normalization_certified,"
        "external_table_source_urls,signed_pd_wirtinger_fox_certified"
    )
    assert payload["readiness_blocker_codes"] == payload["readiness_blockers"]
    assert payload["readiness_blocker_code_counts"] == {
        blocker: 1 for blocker in payload["readiness_blockers"]
    }
    assert payload["readiness_blocker_count_signature"] == (
        "admissible_minor_normalization_certified:1,"
        "all_admissible_minors_consistent:1,certification_report_url:1,"
        "counterexample_count_zero:1,external_table_normalization_certified:1,"
        "external_table_source_urls:1,signed_pd_wirtinger_fox_certified:1"
    )
    assert payload["certification_pack_available"] is False
    assert payload["certification_pack_certified"] is False
    assert payload["retained_evidence_count"] == 2
    assert payload["retained_repository_test_count"] == 2
    assert payload["retained_registered_fixture_scope_count"] == 1
    assert payload["retained_bounded_scope_count"] == 1
    assert payload["ci_exit_code"] == 0


def test_cli_full_multivariable_alexander_normalization_readiness_accepts_pack(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = (
            tmp_path
            / "full_multivariable_alexander_normalization_certification_pack.json"
        )
        _write_full_alexander_certification_pack(path)
        exit_code = main(
            [
                "full-multivariable-alexander-normalization-readiness",
                "--full-multivariable-alexander-normalization-certification-pack-json",
                str(path),
                "--fail-on-not-ready",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["readiness_all_ready"] is True
    assert payload["readiness_blockers"] == []
    assert payload["readiness_blocker_codes"] == []
    assert payload["readiness_blocker_code_counts"] == {}
    assert payload["readiness_blocker_count_signature"] == ""
    assert payload["certification_pack_available"] is True
    assert payload["certification_pack_certified"] is True
    assert payload["certification_gate_passed"] is True
    assert payload["ci_fail_on_not_ready"] is True
    assert payload["ci_exit_code"] == 0


def test_cli_fixture_validation_pack_audit_rejects_alexander_pack_without_counterexamples(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = (
            tmp_path
            / "full_multivariable_alexander_normalization_certification_pack.json"
        )
        _write_full_alexander_certification_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload.pop("counterexample_count")
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--full-multivariable-alexander-normalization-certification-pack-json",
                str(path),
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert report["full_multivariable_alexander_normalization_certified"] is False
    assert report["final_completion_blocker_code_counts"][
        "full_multivariable_alexander_normalization_not_certified"
    ] == 1
    gate_checks = {row["gate"]: row for row in report["final_completion_gate_checks"]}
    assert gate_checks["full_multivariable_alexander_normalization"]["passed"] is False


def test_cli_fixture_validation_pack_audit_rejects_alexander_string_counterexamples(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = (
            tmp_path
            / "full_multivariable_alexander_normalization_certification_pack.json"
        )
        _write_full_alexander_certification_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["counterexample_count"] = "0"
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--full-multivariable-alexander-normalization-certification-pack-json",
                str(path),
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert report["full_multivariable_alexander_normalization_certified"] is False
    assert report["final_completion_blocker_code_counts"][
        "full_multivariable_alexander_normalization_not_certified"
    ] == 1


def test_cli_fixture_validation_pack_audit_rejects_alexander_duplicate_external_table_witnesses(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = (
            tmp_path
            / "full_multivariable_alexander_normalization_certification_pack.json"
        )
        _write_full_alexander_certification_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["external_table_source_urls"] = [
            "https://evidence.iroll.dev/tables/alexander",
            "https://evidence.iroll.dev/tables/alexander",
        ]
        payload["external_table_source_sha256s"] = ["b" * 64, "b" * 64]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "full_multivariable_alexander_normalization_certification_pack",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert {
        "external_table_page_sources_match_pinned_revisions",
        "external_table_source_urls_unique",
        "external_table_source_url_filenames_unique",
        "external_table_source_sha256s_unique",
        "external_table_source_witness_pairs_unique",
    }.issubset(report["failed_checks"])
    assert report["ci_exit_code"] == 1


def test_cli_fixture_validation_pack_audit_rejects_alexander_duplicate_external_table_filenames(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = (
            tmp_path
            / "full_multivariable_alexander_normalization_certification_pack.json"
        )
        _write_full_alexander_certification_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["external_table_source_urls"] = [
            "https://evidence.iroll.dev/tables/alexander/source.json",
            "https://mirror.iroll.dev/tables/alexander/source.json",
        ]
        payload["external_table_source_sha256s"] = ["b" * 64, "c" * 64]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "full_multivariable_alexander_normalization_certification_pack",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert {
        "external_table_page_sources_match_pinned_revisions",
        "external_table_source_url_filenames_unique",
    }.issubset(report["failed_checks"])
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_alexander_report_url_reused_as_table_source(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = (
            tmp_path
            / "full_multivariable_alexander_normalization_certification_pack.json"
        )
        _write_full_alexander_certification_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["external_table_source_urls"] = [
            payload["certification_report_url"]
        ]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "full_multivariable_alexander_normalization_certification_pack",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert {
        "external_table_page_sources_match_pinned_revisions",
        "certification_report_url_not_external_table_source_urls",
    }.issubset(report["failed_checks"])
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_alexander_report_digest_reused_as_table_digest(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = (
            tmp_path
            / "full_multivariable_alexander_normalization_certification_pack.json"
        )
        _write_full_alexander_certification_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["external_table_source_sha256s"] = [
            payload["certification_report_sha256"]
        ]
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "full_multivariable_alexander_normalization_certification_pack",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert {
        "external_table_page_sources_match_pinned_revisions",
        "certification_report_sha256_not_external_table_source_sha256s",
    }.issubset(report["failed_checks"])
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_accepts_production_imgui_pack(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "production_imgui_renderer_framebuffer_pack.json"
        path.write_text(
            json.dumps(
                {
                    "artifact_schema_version": 1,
                    "artifact_kind": "imgui_production_renderer_framebuffer_pack",
                    "claim_scope": (
                        "production_imgui_renderer_framebuffer_verification"
                    ),
                    "passed": True,
                    "render_frame_count": 3,
                    "framebuffer_touched": 1,
                    "estimated_nonzero_pixels": 144,
                    "graphics_backend_name": "wgpu-vulkan",
                    "framebuffer_width": 64,
                    "framebuffer_height": 64,
                    "screenshot_url": "https://evidence.iroll.dev/production-imgui.png",
                    "screenshot_sha256": "a" * 64,
                    "real_graphics_backend_framebuffer_verified": True,
                    "screenshot_verified": True,
                }
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "production_imgui_renderer_framebuffer_pack",
                "--fail-on-not-certified",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["audited_artifact_type"] == (
        "production_imgui_renderer_framebuffer_pack"
    )
    assert payload["completion_evidence_artifact_filenames"] == [
        "production_imgui_renderer_framebuffer_pack.json"
    ]
    assert payload["completion_evidence_artifact_instance_row_count"] == 1
    assert payload["completion_evidence_artifact_filenames_are_expected"] is True
    assert (
        payload[
            "completion_evidence_template_to_artifact_filenames_match_artifact_filenames"
        ]
        is True
    )
    assert (
        payload[
            "completion_evidence_artifact_filename_count_matches_instance_row_count"
        ]
        is True
    )
    assert (
        payload[
            "completion_evidence_artifact_filename_signature_matches_instance_rows"
        ]
        is True
    )
    assert payload["completion_evidence_producer_metadata_consistency_passed"] is True
    assert payload["completion_evidence_final_completion_failed_gates"] == [
        "non_diagram_requirements",
        "production_imgui_renderer",
    ]
    assert payload["completion_evidence_final_completion_blocker_codes"] == [
        "native_imgui_screenshot_framebuffer_fixtures_partial",
        "production_imgui_renderer_not_verified",
    ]
    assert payload["completion_evidence_final_completion_blocker_count"] == 2
    assert payload["final_validation_command"].endswith("--fail-on-not-ready")
    assert payload["artifact_certified"] is True
    assert payload["artifact_field_coverage_complete"] is True
    assert payload["missing_artifact_fields"] == []
    assert payload["required_artifact_field_count"] == len(
        payload["required_artifact_fields"]
    )
    assert payload["failed_check_count"] == 0
    assert payload["artifact_evidence"]["evidence_id"] == (
        "production_imgui_renderer_framebuffer_pack"
    )
    assert payload["ci_exit_code"] == 0


def test_cli_completion_evidence_artifact_audit_rejects_zero_render_frames(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "production_imgui_renderer_framebuffer_pack.json"
        _write_imgui_production_framebuffer_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["render_frame_count"] = 0
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "production_imgui_renderer_framebuffer_pack",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["artifact_field_coverage_complete"] is True
    assert report["missing_artifact_fields"] == []
    assert report["failed_checks"] == ["render_frame_count_positive"]
    assert report["artifact_evidence"]["render_frame_count"] == 0
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_non_unit_framebuffer_touched(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "production_imgui_renderer_framebuffer_pack.json"
        _write_imgui_production_framebuffer_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["framebuffer_touched"] = 2
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "production_imgui_renderer_framebuffer_pack",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["failed_checks"] == ["framebuffer_touched_unit_flag"]
    assert report["artifact_evidence"]["framebuffer_touched"] == 2
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_test_graphics_backend_name(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "production_imgui_renderer_framebuffer_pack.json"
        _write_imgui_production_framebuffer_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["graphics_backend_name"] = "test-real-backend"
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "production_imgui_renderer_framebuffer_pack",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["failed_checks"] == ["graphics_backend_name_not_test_or_stub"]
    assert report["artifact_evidence"]["graphics_backend_name"] == "test-real-backend"
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_nonzero_pixels_below_touch_flag(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "production_imgui_renderer_framebuffer_pack.json"
        _write_imgui_production_framebuffer_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["estimated_nonzero_pixels"] = 0
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "production_imgui_renderer_framebuffer_pack",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["failed_checks"] == [
        "estimated_nonzero_pixels",
        "estimated_nonzero_pixels_covers_framebuffer_touched",
    ]
    assert report["artifact_evidence"]["estimated_nonzero_pixels"] == 0
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_nonzero_pixels_over_framebuffer_area(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "production_imgui_renderer_framebuffer_pack.json"
        _write_imgui_production_framebuffer_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["framebuffer_width"] = 8
        payload["framebuffer_height"] = 8
        payload["estimated_nonzero_pixels"] = 65
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "production_imgui_renderer_framebuffer_pack",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["failed_checks"] == [
        "estimated_nonzero_pixels_within_framebuffer_area"
    ]
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_boolean_render_frames(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "production_imgui_renderer_framebuffer_pack.json"
        _write_imgui_production_framebuffer_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["render_frame_count"] = True
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "production_imgui_renderer_framebuffer_pack",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["failed_checks"] == ["render_frame_count_positive"]
    assert report["artifact_evidence"]["render_frame_count"] == 0
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_string_render_frames(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "production_imgui_renderer_framebuffer_pack.json"
        _write_imgui_production_framebuffer_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["render_frame_count"] = "2"
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "production_imgui_renderer_framebuffer_pack",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["failed_checks"] == ["render_frame_count_positive"]
    assert report["artifact_evidence"]["render_frame_count"] == 0
    assert report["ci_exit_code"] == 1


def test_cli_completion_evidence_artifact_audit_rejects_template_placeholder(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "production_imgui_renderer_framebuffer_pack.json"
        _write_imgui_production_framebuffer_pack(path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["template_placeholder"] = True
        path.write_text(json.dumps(payload), encoding="utf-8")

        exit_code = main(
            [
                "completion-evidence-artifact-audit",
                str(path),
                "--artifact-type",
                "production_imgui_renderer_framebuffer_pack",
                "--fail-on-not-certified",
            ]
        )
        report = json.loads(capsys.readouterr().out)

    assert exit_code == 1
    assert report["artifact_certified"] is False
    assert report["completion_evidence_artifact_filenames"] == [
        "production_imgui_renderer_framebuffer_pack.json"
    ]
    assert report["ci_fail_on_not_certified"] is True
    assert report["ci_exit_code"] == 1
    assert report["failed_checks"] == ["template_placeholder_not_true"]


def test_cli_fixture_validation_pack_audit_explains_incomplete_bundle(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        bundle_path = tmp_path / "incomplete-completion-evidence-bundle.json"
        bundle_path.write_text(
            json.dumps(
                {
                    "artifact_schema_version": 1,
                    "artifact_kind": "cross_workstream_completion_evidence_bundle",
                    "claim_scope": "cross_workstream_final_completion_evidence",
                }
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "fixture-validation-pack-audit",
                "--completion-evidence-bundle-json",
                str(bundle_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    evidence = payload["completion_evidence_bundle"]
    assert evidence["available"] is True
    assert evidence["certified"] is False
    assert evidence["missing_bundle_key_count"] == 5
    assert evidence["missing_bundle_keys"] == [
        "verified_signed_crossing_assignments",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
    ]
    assert evidence["invalid_bundle_fields"] == []
    assert evidence["artifact_preflight_row_count"] == 0
    assert evidence["expected_artifact_preflight_row_count"] == 4
    assert evidence["expected_bundle_preflight_row_count_source"] == (
        "present_bundle_assignment_count_plus_single_artifacts"
    )
    assert (
        evidence[
            "expected_evidence_filename_count_matches_artifact_preflight_row_count"
        ]
        is False
    )
    assert evidence["artifact_preflight_failed_count"] == 0
    assert evidence["all_bundle_artifacts_certified"] is False
    assert evidence["missing_signed_assignment_notations"] == ["L5a1", "L6a4"]
    assert "verified_signed_crossing_assignment_required_notations" in (
        evidence["failed_checks"]
    )
    assert "all_bundle_artifacts_certified" in evidence["failed_checks"]
    assert payload["final_completion_ready"] is False
    assert payload["final_completion_blocker_count"] == 7


def test_cli_completion_evidence_templates_emit_non_certified_placeholders(
    capsys,
) -> None:
    exit_code = main(["completion-evidence-templates"])
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["artifact_kind"] == (
        "cross_workstream_completion_evidence_templates"
    )
    assert payload["claim_scope"] == (
        "cross_workstream_final_completion_evidence_templates"
    )
    assert payload["completion_claimed"] is False
    assert payload["final_completion_blocker_count"] == 7
    assert payload["final_completion_failed_gate_count"] == 6
    assert payload["final_completion_failed_gate_signature"] == (
        "signed_diagram_fixture_registration|non_diagram_requirements|"
        "full_homfly_pt_evaluation|"
        "full_multivariable_alexander_normalization|"
        "production_imgui_renderer|release_artifacts"
    )
    assert payload["final_completion_blocker_code_count"] == 6
    assert payload["final_completion_blocker_code_counts"] == {
        "full_homfly_pt_evaluation_not_certified": 1,
        "full_multivariable_alexander_normalization_not_certified": 1,
        "native_imgui_screenshot_framebuffer_fixtures_partial": 1,
        "production_imgui_renderer_not_verified": 1,
        "release_artifacts_not_published": 1,
        "signed_pd_not_registered": 2,
    }
    assert payload["template_count"] == 5
    assert payload["required_artifact_count"] == 5
    assert payload["final_completion_missing_artifact_count"] == 5
    assert payload["final_completion_missing_artifacts"] == [
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "verified_signed_crossing_assignment",
    ]
    assert payload["required_missing_artifacts"] == [
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "verified_signed_crossing_assignment",
    ]
    assert payload["required_missing_artifact_signature"] == (
        "full_homfly_pt_evaluation_certification_pack|"
        "full_multivariable_alexander_normalization_certification_pack|"
        "production_imgui_renderer_framebuffer_pack|"
        "signed_release_publication_manifest|verified_signed_crossing_assignment"
    )
    assert (
        payload["final_completion_missing_artifact_signature"]
        == payload["required_missing_artifact_signature"]
    )
    assert payload["producer_readiness_available"] is True
    assert payload["producer_readiness_count"] == 6
    assert payload["producer_readiness_ready_count"] == 0
    assert payload["producer_readiness_all_ready"] is False
    assert payload["producer_readiness_blocker_count"] == 34
    assert payload["producer_readiness_blocker_signature"] == "|".join(
        payload["producer_readiness_blockers"]
    )
    assert payload["producer_readiness_blocker_occurrence_count"] == 38
    assert payload["producer_readiness_blocker_code_counts"][
        "external_source_assignment_verified"
    ] == 1
    assert payload["producer_readiness_blocker_code_counts"][
        "unique_sign_pattern"
    ] == 1
    assert payload["repeatable_instance_coverage_required"] is True
    assert payload["required_instance_count"] == 2
    assert payload["required_instance_labels"] == ["L5a1", "L6a4"]
    assert payload["template_filenames"] == [
        "full_homfly_pt_evaluation_certification_pack.template.json",
        "full_multivariable_alexander_normalization_certification_pack.template.json",
        "production_imgui_renderer_framebuffer_pack.template.json",
        "signed_release_publication_manifest.template.json",
        "verified_signed_crossing_assignment.template.json",
    ]
    assert payload["template_to_artifact_filenames"] == [
        "full_homfly_pt_evaluation_certification_pack.json",
        "full_multivariable_alexander_normalization_certification_pack.json",
        "production_imgui_renderer_framebuffer_pack.json",
        "signed_release_publication_manifest.json",
        "verified_signed_crossing_assignment.json",
    ]
    assert payload["template_to_artifact_filename_count"] == 5
    assert (
        payload["template_to_artifact_filenames_match_expected_evidence_filenames"]
        is False
    )
    assert (
        payload["template_expansion_required_for_expected_evidence_filenames"]
        is True
    )
    assert len(payload["template_to_artifact_rows"]) == payload["template_count"]
    template_rows = {
        row["missing_artifact"]: row
        for row in payload["templates"]
    }
    assert template_rows["verified_signed_crossing_assignment"][
        "preflight_command"
    ] == (
        "iroll completion-evidence-artifact-audit "
        "<verified_signed_crossing_assignment.json> "
        "--artifact-type verified_signed_crossing_assignment "
        "--fail-on-not-certified"
    )
    assert template_rows["production_imgui_renderer_framebuffer_pack"][
        "bundle_input_example"
    ] == (
        "iroll completion-evidence-bundle "
        "--production-imgui-renderer-framebuffer-pack-json "
        "<production_imgui_renderer_framebuffer_pack.json>"
    )
    assert template_rows["production_imgui_renderer_framebuffer_pack"][
        "final_completion_failed_gates"
    ] == ["non_diagram_requirements", "production_imgui_renderer"]
    assert template_rows["production_imgui_renderer_framebuffer_pack"][
        "final_completion_blocker_codes"
    ] == [
        "native_imgui_screenshot_framebuffer_fixtures_partial",
        "production_imgui_renderer_not_verified",
    ]
    templates = {
        row["missing_artifact"]: row["template"]
        for row in payload["templates"]
    }
    assert template_rows["verified_signed_crossing_assignment"][
        "repeatable_instance_coverage_required"
    ] is True
    assert template_rows["verified_signed_crossing_assignment"][
        "required_instance_labels"
    ] == ["L5a1", "L6a4"]
    assert template_rows["verified_signed_crossing_assignment"][
        "artifact_filename"
    ] == "verified_signed_crossing_assignment.json"
    assert template_rows["verified_signed_crossing_assignment"][
        "template_to_artifact_filename"
    ] == "verified_signed_crossing_assignment.json"
    assert template_rows["verified_signed_crossing_assignment"][
        "template_to_artifact_note"
    ].startswith("copy verified_signed_crossing_assignment.template.json")
    assert templates["verified_signed_crossing_assignment"][
        "artifact_kind"
    ] == "verified_signed_crossing_assignment"
    assert templates["verified_signed_crossing_assignment"][
        "repeatable_instance_coverage_required"
    ] is True
    assert templates["verified_signed_crossing_assignment"][
        "required_instance_labels"
    ] == ["L5a1", "L6a4"]
    assert templates["verified_signed_crossing_assignment"][
        "unique_assignment_certified"
    ] is False
    assert templates["verified_signed_crossing_assignment"][
        "producer_readiness_blockers"
    ] == [
        "external_source_assignment_verified",
        "invariant_table_values_verified",
        "unique_sign_pattern",
    ]
    assert len(
        templates["verified_signed_crossing_assignment"]["producer_readiness"]
    ) == 2
    assert templates["production_imgui_renderer_framebuffer_pack"][
        "real_graphics_backend_framebuffer_verified"
    ] is False
    assert templates["production_imgui_renderer_framebuffer_pack"][
        "producer_readiness"
    ][0]["claim_scope"] == "completion_evidence_artifact_producer_readiness"
    assert templates["signed_release_publication_manifest"][
        "signed_release_artifacts_published"
    ] is False
    assert templates["full_homfly_pt_evaluation_certification_pack"][
        "counterexample_count"
    ] == 1
    assert templates[
        "full_multivariable_alexander_normalization_certification_pack"
    ]["all_admissible_minors_consistent"] is False
    assert all(template["template_placeholder"] is True for template in templates.values())


def test_cli_completion_evidence_templates_writes_template_files(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        template_dir = tmp_path / "templates"
        exit_code = main(
            [
                "completion-evidence-templates",
                "--directory",
                str(template_dir),
            ]
        )
        payload = json.loads(capsys.readouterr().out)
        template_paths = [
            Path(row["template_path"])
            for row in payload["templates"]
        ]
        template_payloads = [
            json.loads(path.read_text(encoding="utf-8"))
            for path in template_paths
        ]

    assert exit_code == 0
    assert payload["template_directory"] == str(template_dir)
    assert payload["template_file_count"] == 5
    assert all(row["template_written"] is True for row in payload["templates"])
    assert all(path.name.endswith(".template.json") for path in template_paths)
    assert all(template["template_placeholder"] is True for template in template_payloads)
    assert all(template["completion_claimed"] is False for template in template_payloads)
    assert all("producer_readiness" in template for template in template_payloads)
    assert all("producer_readiness_blockers" in template for template in template_payloads)
    assert all("required_instance_labels" in template for template in template_payloads)
    artifact_kinds = {template["artifact_kind"] for template in template_payloads}
    assert "verified_signed_crossing_assignment" in artifact_kinds
    assert "signed_release_publication_manifest" in artifact_kinds


def test_cli_completion_evidence_producer_workspace_writes_executable_index(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        workspace = tmp_path / "producer-workspace"
        exit_code = main(
            [
                "completion-evidence-producer-workspace",
                str(workspace),
            ]
        )
        stdout = capsys.readouterr().out
        index_path = workspace / "completion-evidence-producer-workspace.json"
        payload = json.loads(index_path.read_text(encoding="utf-8"))
        rows = {
            (row["missing_artifact"], row["instance_label"]): row
            for row in payload["producer_rows"]
        }

    assert exit_code == 0
    assert stdout == ""
    assert payload["artifact_kind"] == (
        "cross_workstream_completion_evidence_producer_workspace"
    )
    assert payload["completion_claimed"] is False
    assert payload["workspace_index_path"] == str(index_path)
    assert payload["template_file_count"] == 6
    assert payload["producer_row_count"] == 6
    assert payload["target_artifact_file_count"] == 6
    assert payload["present_target_artifact_file_count"] == 0
    assert payload["missing_target_artifact_file_count"] == 6
    assert payload["all_target_artifact_files_present"] is False
    assert payload["target_artifact_files_written"] is False
    assert payload["target_artifact_filenames"] == payload[
        "expected_evidence_filenames"
    ]
    assert payload["target_artifact_filename_signature"] == payload[
        "expected_evidence_filename_signature"
    ]
    assert payload["bundle_command"].endswith("completion-evidence-bundle.json")
    assert "--validate-artifacts" in payload["directory_audit_command"]
    assert payload["final_validation_command"].endswith("--fail-on-not-ready")
    assert all(row["template_written"] is True for row in payload["producer_rows"])
    assert all(row["artifact_file_exists"] is False for row in payload["producer_rows"])
    assert rows[("verified_signed_crossing_assignment", "L6a4")][
        "artifact_filename"
    ] == "verified_signed_crossing_assignment.L6a4.json"
    assert rows[("verified_signed_crossing_assignment", "L6a4")][
        "final_completion_blocker_labels"
    ] == ["L6a4"]
    assert rows[("production_imgui_renderer_framebuffer_pack", None)][
        "final_completion_failed_gates"
    ] == ["non_diagram_requirements", "production_imgui_renderer"]
    assert rows[("production_imgui_renderer_framebuffer_pack", None)][
        "preflight_command"
    ].endswith("production_imgui_renderer_framebuffer_pack.json.audit.json")
    assert (
        "--artifact-type production_imgui_renderer_framebuffer_pack"
        in rows[("production_imgui_renderer_framebuffer_pack", None)][
            "preflight_command"
        ]
    )


def test_cli_completion_evidence_templates_expands_repeatable_files(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        template_dir = tmp_path / "templates-expanded"
        exit_code = main(
            [
                "completion-evidence-templates",
                "--expand-repeatable",
                "--directory",
                str(template_dir),
            ]
        )
        payload = json.loads(capsys.readouterr().out)
        expanded_rows = [
            row for row in payload["templates"] if row["expanded_repeatable"]
        ]
        expanded_payloads = [
            json.loads(Path(row["template_path"]).read_text(encoding="utf-8"))
            for row in expanded_rows
        ]

    assert exit_code == 0
    assert payload["repeatable_expanded"] is True
    assert payload["template_count"] == 6
    assert payload["required_artifact_count"] == 5
    assert payload["template_file_count"] == 6
    assert payload["expanded_repeatable_template_count"] == 2
    assert payload["required_missing_artifact_signature"] == (
        "full_homfly_pt_evaluation_certification_pack|"
        "full_multivariable_alexander_normalization_certification_pack|"
        "production_imgui_renderer_framebuffer_pack|"
        "signed_release_publication_manifest|verified_signed_crossing_assignment"
    )
    assert payload["expected_evidence_filename_count"] == 6
    assert payload["expected_evidence_filenames"] == [
        "full_homfly_pt_evaluation_certification_pack.json",
        "full_multivariable_alexander_normalization_certification_pack.json",
        "production_imgui_renderer_framebuffer_pack.json",
        "signed_release_publication_manifest.json",
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert payload["template_to_artifact_filenames"] == [
        "full_homfly_pt_evaluation_certification_pack.json",
        "full_multivariable_alexander_normalization_certification_pack.json",
        "production_imgui_renderer_framebuffer_pack.json",
        "signed_release_publication_manifest.json",
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    assert payload["template_to_artifact_filenames"] == payload[
        "expected_evidence_filenames"
    ]
    assert payload["template_to_artifact_filename_count"] == 6
    assert (
        payload["template_to_artifact_filenames_match_expected_evidence_filenames"]
        is True
    )
    assert (
        payload["template_expansion_required_for_expected_evidence_filenames"]
        is False
    )
    assert payload["template_to_artifact_rows"][-2:][0][
        "template_filename"
    ] == "verified_signed_crossing_assignment.L5a1.template.json"
    assert payload["template_to_artifact_rows"][-1][
        "template_to_artifact_filename"
    ] == "verified_signed_crossing_assignment.L6a4.json"
    assert payload["template_to_artifact_rows"][-1][
        "final_completion_failed_gates"
    ] == ["signed_diagram_fixture_registration"]
    assert payload["template_to_artifact_rows"][-1][
        "final_completion_blocker_labels"
    ] == ["L6a4"]
    assert payload["producer_readiness_count"] == 6
    assert payload["producer_readiness_ready_count"] == 0
    assert payload["required_instance_labels"] == ["L5a1", "L6a4"]
    assert {row["blocker_label"] for row in expanded_rows} == {"L5a1", "L6a4"}
    assert {payload["notation"] for payload in expanded_payloads} == {
        "L5a1",
        "L6a4",
    }
    assert all(len(payload["producer_readiness"]) == 1 for payload in expanded_payloads)
    assert {
        payload["producer_readiness"][0]["notation"]
        for payload in expanded_payloads
    } == {"L5a1", "L6a4"}
    assert {
        payload["template_instance_label"] for payload in expanded_payloads
    } == {"L5a1", "L6a4"}
    assert {
        tuple(payload["final_completion_blocker_labels"])
        for payload in expanded_payloads
    } == {("L5a1",), ("L6a4",)}
    assert all(
        payload["final_completion_failed_gates"]
        == ["signed_diagram_fixture_registration"]
        for payload in expanded_payloads
    )
    assert all(
        payload["required_instance_labels"] == ["L5a1", "L6a4"]
        for payload in expanded_payloads
    )
    assert {
        Path(row["template_path"]).name
        for row in expanded_rows
    } == {
        "verified_signed_crossing_assignment.L5a1.template.json",
        "verified_signed_crossing_assignment.L6a4.template.json",
    }
    assert {
        row["template_to_artifact_filename"] for row in expanded_rows
    } == {
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    }
    assert all(payload["template_placeholder"] is True for payload in expanded_payloads)


def test_cli_completion_evidence_templates_do_not_close_audit_gates(
    capsys,
) -> None:
    templates_exit = main(["completion-evidence-templates"])
    templates_payload = json.loads(capsys.readouterr().out)
    templates = {
        row["missing_artifact"]: row["template"]
        for row in templates_payload["templates"]
    }
    bundle = {
        "artifact_schema_version": 1,
        "artifact_kind": "cross_workstream_completion_evidence_bundle",
        "claim_scope": "cross_workstream_final_completion_evidence",
        "bundle_inputs_complete": True,
        "bundle_input_count": 5,
        "bundle_repeatable_assignment_count": 2,
        "bundle_certified_by_audit": False,
        "completion_claimed": False,
        "verified_signed_crossing_assignments": [
            {
                **templates["verified_signed_crossing_assignment"],
                "notation": "L5a1",
            }
        ],
        "production_imgui_renderer_framebuffer_pack": templates[
            "production_imgui_renderer_framebuffer_pack"
        ],
        "signed_release_publication_manifest": templates[
            "signed_release_publication_manifest"
        ],
        "full_homfly_pt_evaluation_certification_pack": templates[
            "full_homfly_pt_evaluation_certification_pack"
        ],
        "full_multivariable_alexander_normalization_certification_pack": templates[
            "full_multivariable_alexander_normalization_certification_pack"
        ],
    }
    with workspace_tempdir() as tmp_path:
        bundle_path = tmp_path / "template-completion-evidence-bundle.json"
        bundle_path.write_text(json.dumps(bundle), encoding="utf-8")

        audit_exit = main(
            [
                "fixture-validation-pack-audit",
                "--completion-evidence-bundle-json",
                str(bundle_path),
            ]
        )
        audit_payload = json.loads(capsys.readouterr().out)

    assert templates_exit == 0
    assert audit_exit == 0
    assert audit_payload["completion_evidence_bundle_certified"] is False
    bundle_evidence = audit_payload["completion_evidence_bundle"]
    assert bundle_evidence["expected_artifact_preflight_row_count"] == 5
    assert bundle_evidence["artifact_preflight_row_count"] == 5
    assert bundle_evidence["artifact_preflight_failed_count"] == 5
    assert bundle_evidence["all_bundle_artifacts_certified"] is False
    assert bundle_evidence["missing_signed_assignment_notations"] == ["L6a4"]
    assert "verified_signed_crossing_assignment_required_notations" in (
        bundle_evidence["failed_checks"]
    )
    assert "all_bundle_artifacts_certified" in bundle_evidence["failed_checks"]
    assert audit_payload["final_completion_ready"] is False
    assert audit_payload["final_completion_blocker_count"] == 7
    assert audit_payload["production_imgui_renderer_verified"] is False
    assert audit_payload["release_artifacts_published"] is False


def test_cli_imgui_payloads_preserve_validation_pack_known_limitations_mismatch(
    capsys,
) -> None:
    report = {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "cross_workstream_validation_pack_audit",
        "required_diagram_fixture_metadata_complete": True,
        "signed_diagram_fixture_registration_complete": False,
        "open_non_diagram_requirement_count": 1,
        "final_completion_ready": False,
        "fixture_known_limitations_summary": {
            "claim_scope": "validation_pack_fixture_known_limitations_summary",
            "fixture_row_count": 7,
            "known_limitations_available_count": 6,
            "known_limitations_unavailable_count": 1,
            "known_limitations_note_count_total": 31,
            "known_limitations_requirement_satisfied_count": 6,
            "known_limitations_requirement_satisfied_count_matched": False,
            "known_limitations_unavailable_count_matched": False,
            "matched": False,
        },
    }
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "validation-pack-known-limitations-mismatch.json"
        path.write_text(json.dumps(report), encoding="utf-8")

        analysis_exit = main(["imgui-analysis-summary-payload", str(path)])
        analysis = json.loads(capsys.readouterr().out)
        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(path)]
        )
        host = json.loads(capsys.readouterr().out)

    assert analysis_exit == 0
    assert (
        analysis[
            "analysis_validation_pack_fixture_known_limitations_available_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_validation_pack_fixture_known_limitations_unavailable_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_validation_pack_fixture_known_limitations_requirement_satisfied_count"
        ]
        == 6
    )
    assert (
        analysis[
            "analysis_validation_pack_fixture_known_limitations_matched_count"
        ]
        == 0
    )
    assert (
        "fixture_known_limitations=rows=7; available=6; unavailable=1; "
        "notes=31; requirement_satisfied=6; matched=false"
    ) in analysis["analysis_summaries"][0]["notes"]

    assert host_exit == 0
    host_analysis = host["analysis"]
    assert (
        host_analysis[
            "analysis_validation_pack_fixture_known_limitations_available_count"
        ]
        == 6
    )
    assert (
        host_analysis[
            "analysis_validation_pack_fixture_known_limitations_matched_count"
        ]
        == 0
    )
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    assert (
        "matched=false"
        in host_summaries["cross_workstream_validation_pack_audit"]["notes"]
    )


def test_cli_multivariable_alexander_pd_accepts_role_order_json(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "hopf_external_role_order.json"
        path.write_text(
            json.dumps(
                {
                    "diagram": {
                        "name": "hopf-link-external-role-order",
                        "component_count": 2,
                        "signed_pd_code": [
                            {"code": [4, 1, 2, 3], "sign": 1},
                            {"code": [2, 3, 4, 1], "sign": -1},
                        ],
                    },
                    "signed_pd_revision": 37,
                    "variables": ["t1", "t2"],
                }
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "multivariable-alexander-pd",
                str(path),
                "--role-order",
                "1,0,2,3",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "multivariable_alexander_pd_report"
    assert payload["input"]["role_order"] == [1, 0, 2, 3]
    assert payload["input"]["variables"] == ["t1", "t2"]
    assert payload["skipped"] is False
    assert payload["multivariable_alexander_polynomial"] == "1"
    assert set(payload["candidate_polynomials"]) == {"1 - t1", "1 - t2"}
    assert payload["orientation_inference"]["method"] == (
        "inferred_signed_pd_global_role_order"
    )
    assert payload["result"]["orientation_inference"]["role_order"] == [1, 0, 2, 3]
    assert payload["presentation"]["source"] == "explicit_oriented_signed_pd"
    assert payload["full_admissible_minor_normalization_certified"] is False
    assert payload["full_invariant_certified"] is False
    evidence = payload["input_certification_evidence"]
    assert evidence["bounded_scanned_gcd_certified"] is True
    assert evidence["quotient_gcd_certified"] is True
    assert evidence["failed_nonzero_minor_count"] == 0
    assert payload["scanned_gcd_audit"]["candidate_is_exact_scanned_gcd"] is True
    assert payload["wirtinger_fox_audit"]["input_chain_consistent"] is True


def test_cli_multivariable_alexander_scanned_gcd_audit_accepts_result_report(
    capsys,
) -> None:
    source_result = _synthetic_nonmaximal_alexander_result()

    with workspace_tempdir() as tmp_path:
        path = tmp_path / "alexander-pd-report.json"
        path.write_text(
            json.dumps(
                {
                    "method": "multivariable_alexander_pd_report",
                    "result": source_result,
                }
            ),
            encoding="utf-8",
        )

        exit_code = main(["multivariable-alexander-scanned-gcd-audit", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "multivariable_alexander_scanned_gcd_audit"
    assert payload["input_report_method"] == "multivariable_alexander_pd_report"
    assert payload["source_method"] == source_result["method"]
    assert payload["candidate_is_exact_scanned_gcd"] is False
    assert payload["improved_candidate_polynomial"] == "1 - t2 - t1 + t1*t2"
    assert payload["quotient_gcd_certified"] is True
    assert payload["complete_scanned_gcd_certified"] is False
    assert payload["quotient_gcd_uncertainty_evidence"] is None
    assert payload["full_invariant_certified"] is False


def test_cli_multivariable_alexander_scanned_gcd_audit_reports_failed_division_witnesses(
    capsys,
) -> None:
    source_result = _synthetic_nonmaximal_alexander_result()
    source_result["method"] = "synthetic_wrong_scanned_gcd_candidate"
    source_result["multivariable_alexander_polynomial"] = "1 + t1"

    with workspace_tempdir() as tmp_path:
        path = tmp_path / "alexander-pd-report.json"
        path.write_text(
            json.dumps(
                {
                    "method": "multivariable_alexander_pd_report",
                    "result": source_result,
                }
            ),
            encoding="utf-8",
        )

        exit_code = main(["multivariable-alexander-scanned-gcd-audit", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "multivariable_alexander_scanned_gcd_audit"
    assert payload["candidate_is_exact_scanned_gcd"] is False
    assert payload["quotient_gcd_certified"] is False
    assert payload["failed_nonzero_minor_count"] >= 1
    assert payload["failed_division_witness_count"] == (
        payload["failed_nonzero_minor_count"]
    )
    assert payload["failed_division_witness_limit"] == 8
    assert len(payload["failed_division_witnesses"]) == min(
        payload["failed_nonzero_minor_count"],
        payload["failed_division_witness_limit"],
    )
    witness = payload["failed_division_witnesses"][0]
    assert witness["minor_index"] in payload["failed_minor_indices"]
    assert witness["divisible"] is False
    assert witness["quotient_polynomial"] is None


def test_cli_multivariable_alexander_minor_divisibility_audit_accepts_result_report(
    capsys,
) -> None:
    source_result = _synthetic_nonmaximal_alexander_result()

    with workspace_tempdir() as tmp_path:
        path = tmp_path / "alexander-pd-report.json"
        path.write_text(
            json.dumps(
                {
                    "method": "multivariable_alexander_pd_report",
                    "result": source_result,
                }
            ),
            encoding="utf-8",
        )

        exit_code = main(
            ["multivariable-alexander-minor-divisibility-audit", str(path)]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "multivariable_alexander_minor_divisibility_audit"
    assert payload["input_report_method"] == "multivariable_alexander_pd_report"
    assert payload["source_path"].endswith("alexander-pd-report.json")
    assert payload["source_method"] == source_result["method"]
    assert payload["all_nonzero_minors_divisible"] is True
    assert payload["checked_nonzero_minor_count"] == 2
    assert payload["failed_nonzero_minor_count"] == 0
    assert len(payload["division_records"]) == 2
    assert payload["full_invariant_certified"] is False


def test_cli_multivariable_alexander_admissible_minor_normalization_audit_accepts_result_report(
    capsys,
) -> None:
    source_result = _synthetic_nonmaximal_alexander_result()

    with workspace_tempdir() as tmp_path:
        path = tmp_path / "alexander-pd-report.json"
        path.write_text(
            json.dumps(
                {
                    "method": "multivariable_alexander_pd_report",
                    "result": source_result,
                }
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "multivariable-alexander-admissible-minor-normalization-audit",
                str(path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == (
        "multivariable_alexander_admissible_minor_normalization_audit"
    )
    assert payload["input_report_method"] == "multivariable_alexander_pd_report"
    assert payload["source_path"].endswith("alexander-pd-report.json")
    assert payload["source_method"] == source_result["method"]
    assert payload["all_nonzero_minors_laurent_unit_equivalent"] is False
    assert payload["bounded_admissible_minor_normalization_certified"] is False
    assert payload["checked_nonzero_minor_count"] == 2
    assert payload["failed_nonzero_minor_count"] == 1
    assert payload["expected_combination_count"] == 2
    assert payload["scanned_minor_count"] == 2
    assert payload["nonzero_minor_count"] == 2
    assert payload["unique_nonzero_polynomial_count"] == 2
    assert payload["normalization_mismatch_witness_count"] == 1
    assert len(payload["normalization_mismatch_witnesses"]) == 1
    class_detail = payload["admissible_minor_normalization_blocker_details"][
        "normalization_class_not_unique"
    ]
    assert class_detail["normalization_class_witness_count"] == 2
    assert {
        witness["normalized_polynomial"]
        for witness in class_detail["normalization_class_witnesses"]
    } == {
        "1 - t2 - t1 + t1*t2",
        "1 - t2 - 2t1 + 2*t1*t2 + t1^2 - t1^2*t2",
    }
    assert payload["full_admissible_minor_normalization_certified"] is False
    assert payload["full_invariant_certified"] is False


def test_cli_multivariable_alexander_wirtinger_fox_audit_accepts_result_report(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        signed_pd_path = tmp_path / "hopf_imgui_role_order.json"
        report_path = tmp_path / "alexander-pd-report.json"
        _write_hopf_imgui_with_role_order(signed_pd_path)

        compute_exit = main(
            [
                "multivariable-alexander-pd",
                str(signed_pd_path),
                "-o",
                str(report_path),
            ]
        )
        assert compute_exit == 0
        assert capsys.readouterr().out == ""

        audit_exit = main(
            ["multivariable-alexander-wirtinger-fox-audit", str(report_path)]
        )
        payload = json.loads(capsys.readouterr().out)

    assert audit_exit == 0
    assert payload["method"] == "multivariable_alexander_wirtinger_fox_audit"
    assert payload["input_report_method"] == "multivariable_alexander_pd_report"
    assert payload["presentation_valid"] is True
    assert payload["presentation_source"] == "stored_wirtinger_presentation"
    assert (
        "over^sign under_in over^-sign under_out^-1"
        in payload["presentation_convention"]
    )
    assert payload["wirtinger_relation_shape_valid"] is True
    assert payload["wirtinger_relation_shape_invalid_count"] == 0
    assert payload["wirtinger_relation_shape_witnesses"] == []
    assert payload["wirtinger_generator_component_coverage_complete"] is True
    assert payload["fox_jacobian_valid"] is True
    assert payload["fox_square_minor_scan_valid"] is True
    assert payload["input_chain_consistent"] is True
    assert payload["relation_count"] > 0
    assert payload["generator_count"] > 0
    assert payload["scanned_minor_count"] > 0
    assert payload["invalid_minor_reference_count"] == 0
    assert payload["invalid_normalization_count"] == 0
    assert payload["full_admissible_minor_normalization_certified"] is False
    assert payload["full_invariant_certified"] is False


def test_cli_multivariable_alexander_input_certification_evidence_accepts_result_report(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        signed_pd_path = tmp_path / "hopf_imgui_role_order.json"
        report_path = tmp_path / "alexander-pd-report.json"
        _write_hopf_imgui_with_role_order(signed_pd_path)

        compute_exit = main(
            [
                "multivariable-alexander-pd",
                str(signed_pd_path),
                "-o",
                str(report_path),
            ]
        )
        assert compute_exit == 0
        assert capsys.readouterr().out == ""

        evidence_exit = main(
            [
                "multivariable-alexander-input-certification-evidence",
                str(report_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert evidence_exit == 0
    assert payload["method"] == "multivariable_alexander_input_certification_evidence"
    assert payload["input_report_method"] == "multivariable_alexander_pd_report"
    assert payload["source_path"].endswith("alexander-pd-report.json")
    assert payload["bounded_scanned_gcd_certified"] is True
    assert payload["complete_scanned_gcd_certified"] is True
    assert payload["quotient_gcd_certified"] is True
    assert payload["bounded_admissible_minor_normalization_certified"] is False
    assert payload["all_nonzero_minors_laurent_unit_equivalent"] is False
    assert "admissible_minor_normalized_representative_polynomial" in payload
    assert payload["admissible_minor_normalization_evidence"]["method"] == (
        "multivariable_alexander_admissible_minor_normalization_audit"
    )
    assert payload["failed_nonzero_minor_count"] == 0
    assert payload["wirtinger_fox_input_chain_consistent"] is True
    assert payload["full_admissible_minor_normalization_certified"] is False
    assert payload["full_invariant_certified"] is False


def test_cli_homfly_terminal_reduction_audit_accepts_result_report(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        signed_pd_path = tmp_path / "hopf_imgui_role_order.json"
        report_path = tmp_path / "homfly-pd-report.json"
        _write_hopf_imgui_with_role_order(signed_pd_path)

        compute_exit = main(
            [
                "homfly-pd",
                str(signed_pd_path),
                "--max-depth",
                "8",
                "--max-nodes",
                "2048",
                "-o",
                str(report_path),
            ]
        )
        assert compute_exit == 0
        assert capsys.readouterr().out == ""

        audit_exit = main(["homfly-terminal-reduction-audit", str(report_path)])
        payload = json.loads(capsys.readouterr().out)

    assert audit_exit == 0
    assert payload["method"] == "homfly_terminal_reduction_audit"
    assert payload["input_report_method"] == "homfly_pd_report"
    assert payload["source_path"].endswith("homfly-pd-report.json")
    assert payload["skipped"] is False
    assert payload["matched_result"] is True
    assert payload["terminal_reduction_count"] > 0
    assert payload["reduction_contribution_count"] >= payload["terminal_reduction_count"]
    assert payload["failed_terminal_reduction_count"] == 0
    assert payload["frontier_count"] == 0
    assert payload["truncated"] is False
    assert payload["terminal_contribution_sum"] == payload["homfly_polynomial"]


def test_cli_homfly_input_certification_evidence_accepts_result_report(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        signed_pd_path = tmp_path / "hopf_imgui_role_order.json"
        report_path = tmp_path / "homfly-pd-report.json"
        _write_hopf_imgui_with_role_order(signed_pd_path)

        compute_exit = main(
            [
                "homfly-pd",
                str(signed_pd_path),
                "--max-depth",
                "8",
                "--max-nodes",
                "2048",
                "-o",
                str(report_path),
            ]
        )
        assert compute_exit == 0
        assert capsys.readouterr().out == ""

        evidence_exit = main(
            ["homfly-input-certification-evidence", str(report_path)]
        )
        payload = json.loads(capsys.readouterr().out)

    assert evidence_exit == 0
    assert payload["method"] == "homfly_input_certification_evidence"
    assert payload["input_report_method"] == "homfly_pd_report"
    assert payload["source_path"].endswith("homfly-pd-report.json")
    assert payload["certified_for_input"] is True
    assert payload["frontier_exhausted"] is True
    assert payload["terminal_contribution_matches_result"] is True
    assert payload["terminal_contribution_audit_skipped"] is False
    assert payload["frontier_count"] == 0
    assert payload["truncated"] is False
    _assert_cli_homfly_frontier_witness_consistency(payload)
    assert payload["full_table_normalization_certified"] is False
    assert payload["arbitrary_diagram_coverage_certified"] is False
    assert payload["certification_blockers"] == []
    assert payload["certification_blocker_count"] == 0
    assert payload["homfly_completion_blockers"] == [
        "full_table_normalization_not_certified",
        "arbitrary_diagram_coverage_not_certified",
    ]
    assert payload["homfly_completion_blocker_count"] == 2
    _assert_cli_blocker_detail_codes(
        payload,
        "homfly_completion_blocker_details",
        [
            "full_table_normalization_not_certified",
            "arbitrary_diagram_coverage_not_certified",
        ],
    )
    assert payload["homfly_completion_blocker_detail_count"] == 2
    assert payload["homfly_completion_blocker_details"][0]["cap"] == {
        "full_table_normalization_certified": False,
    }
    assert payload["homfly_completion_blocker_details"][1]["cap"] == {
        "arbitrary_diagram_coverage_certified": False,
    }
    gate = payload["arbitrary_diagram_completion_gate"]
    _assert_cli_homfly_arbitrary_completion_gate(gate)
    assert gate["evidence_scope"] == "single_signed_pd_input"
    assert gate["frontier_exhausted"] is True
    assert gate["frontier_count"] == 0
    assert payload["homfly_completion_blocker_details"][1]["witness"] == gate


def test_cli_single_input_certification_retained_pack_exports_imgui_payloads(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        signed_pd_path = tmp_path / "input-certification-hopf-imgui-role-order.json"
        homfly_path = tmp_path / "input-certification-homfly-pd.json"
        homfly_audit_path = (
            tmp_path / "input-certification-homfly-terminal-audit.json"
        )
        homfly_evidence_path = tmp_path / "input-certification-homfly-evidence.json"
        alexander_path = tmp_path / "input-certification-alexander-pd.json"
        alexander_audit_path = (
            tmp_path / "input-certification-alexander-admissible-audit.json"
        )
        alexander_evidence_path = (
            tmp_path / "input-certification-alexander-evidence.json"
        )
        analysis_path = tmp_path / "input-certification-imgui-analysis.json"
        host_path = tmp_path / "input-certification-imgui-host.json"
        _write_hopf_imgui_with_role_order(signed_pd_path)

        homfly_exit = main(
            [
                "homfly-pd",
                str(signed_pd_path),
                "--max-depth",
                "8",
                "--max-nodes",
                "2048",
                "-o",
                str(homfly_path),
            ]
        )
        assert homfly_exit == 0
        assert capsys.readouterr().out == ""

        homfly_audit_exit = main(
            [
                "homfly-terminal-reduction-audit",
                str(homfly_path),
                "-o",
                str(homfly_audit_path),
            ]
        )
        assert homfly_audit_exit == 0
        assert capsys.readouterr().out == ""

        homfly_evidence_exit = main(
            [
                "homfly-input-certification-evidence",
                str(homfly_path),
                "-o",
                str(homfly_evidence_path),
            ]
        )
        assert homfly_evidence_exit == 0
        assert capsys.readouterr().out == ""

        alexander_exit = main(
            [
                "multivariable-alexander-pd",
                str(signed_pd_path),
                "--max-minors",
                "64",
                "-o",
                str(alexander_path),
            ]
        )
        assert alexander_exit == 0
        assert capsys.readouterr().out == ""

        alexander_audit_exit = main(
            [
                "multivariable-alexander-admissible-minor-normalization-audit",
                str(alexander_path),
                "-o",
                str(alexander_audit_path),
            ]
        )
        assert alexander_audit_exit == 0
        assert capsys.readouterr().out == ""

        alexander_evidence_exit = main(
            [
                "multivariable-alexander-input-certification-evidence",
                str(alexander_path),
                "-o",
                str(alexander_evidence_path),
            ]
        )
        assert alexander_evidence_exit == 0
        assert capsys.readouterr().out == ""

        analysis_exit = main(
            [
                "imgui-analysis-summary-payload",
                str(homfly_audit_path),
                str(homfly_evidence_path),
                str(alexander_evidence_path),
                str(alexander_audit_path),
                "-o",
                str(analysis_path),
            ]
        )
        assert analysis_exit == 0
        assert capsys.readouterr().out == ""

        host_exit = main(
            [
                "imgui-host-payload",
                "--analysis-report-json",
                str(homfly_audit_path),
                "--analysis-report-json",
                str(homfly_evidence_path),
                "--analysis-report-json",
                str(alexander_evidence_path),
                "--analysis-report-json",
                str(alexander_audit_path),
                "-o",
                str(host_path),
            ]
        )
        assert host_exit == 0
        assert capsys.readouterr().out == ""

        homfly_audit = json.loads(homfly_audit_path.read_text(encoding="utf-8"))
        homfly_evidence = json.loads(
            homfly_evidence_path.read_text(encoding="utf-8")
        )
        alexander_evidence = json.loads(
            alexander_evidence_path.read_text(encoding="utf-8")
        )
        alexander_audit = json.loads(
            alexander_audit_path.read_text(encoding="utf-8")
        )
        analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
        host = json.loads(host_path.read_text(encoding="utf-8"))
        _assert_strict_json_serializable(
            homfly_audit,
            homfly_evidence,
            alexander_evidence,
            alexander_audit,
            analysis,
            host,
        )

    assert homfly_audit["method"] == "homfly_terminal_reduction_audit"
    assert homfly_audit["matched_result"] is True
    assert homfly_audit["terminal_reduction_count"] == 2
    assert homfly_audit["failed_terminal_reduction_count"] == 0
    assert homfly_audit["frontier_count"] == 0
    assert homfly_audit["truncated"] is False

    assert homfly_evidence["method"] == "homfly_input_certification_evidence"
    assert homfly_evidence["certified_for_input"] is True
    assert homfly_evidence["frontier_exhausted"] is True
    assert homfly_evidence["terminal_contribution_matches_result"] is True
    assert homfly_evidence["full_table_normalization_certified"] is False
    assert homfly_evidence["arbitrary_diagram_coverage_certified"] is False

    assert (
        alexander_evidence["method"]
        == "multivariable_alexander_input_certification_evidence"
    )
    assert alexander_evidence["bounded_scanned_gcd_certified"] is True
    assert alexander_evidence["complete_scanned_gcd_certified"] is True
    assert alexander_evidence["quotient_gcd_certified"] is True
    assert alexander_evidence["failed_nonzero_minor_count"] == 0
    assert alexander_evidence["wirtinger_fox_input_chain_consistent"] is True
    assert (
        alexander_evidence["bounded_admissible_minor_normalization_certified"]
        is False
    )
    assert alexander_evidence["full_invariant_certified"] is False

    assert (
        alexander_audit["method"]
        == "multivariable_alexander_admissible_minor_normalization_audit"
    )
    assert (
        alexander_audit["bounded_admissible_minor_normalization_certified"]
        is False
    )
    assert alexander_audit["all_nonzero_minors_laurent_unit_equivalent"] is False
    assert alexander_audit["failed_nonzero_minor_count"] == 2
    assert alexander_audit["full_invariant_certified"] is False

    assert analysis["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert analysis["analysis_summary_count"] == 4
    assert analysis["analysis_required_check_count"] == 14
    assert analysis["analysis_passed_check_count"] == 12
    assert analysis["analysis_failed_check_count"] == 2
    source_methods = {
        row["source_method"] for row in analysis["analysis_summaries"]
    }
    assert source_methods == {
        "homfly_terminal_reduction_audit",
        "homfly_input_certification_evidence",
        "multivariable_alexander_input_certification_evidence",
        "multivariable_alexander_admissible_minor_normalization_audit",
    }
    summaries = {row["source_method"]: row for row in analysis["analysis_summaries"]}
    homfly_summary = summaries["homfly_input_certification_evidence"]
    assert "full_table_normalization_certified=False" in homfly_summary["notes"]
    assert "arbitrary_diagram_coverage_certified=False" in homfly_summary["notes"]
    alexander_summary = summaries[
        "multivariable_alexander_input_certification_evidence"
    ]
    assert "full_invariant_certified=False" in alexander_summary["notes"]

    assert host["method"] == "imgui_host_payload"
    assert host["analysis"]["analysis_summary_count"] >= 4
    assert (
        host["analysis"]["analysis_required_check_count"]
        >= analysis["analysis_required_check_count"]
    )
    assert (
        host["analysis"]["analysis_passed_check_count"]
        >= analysis["analysis_passed_check_count"]
    )
    assert (
        host["analysis"]["analysis_failed_check_count"]
        >= analysis["analysis_failed_check_count"]
    )
    host_summaries = {
        row["source_method"]: row for row in host["analysis"]["analysis_summaries"]
    }
    assert summaries.keys() <= host_summaries.keys()
    host_homfly_summary = host_summaries["homfly_input_certification_evidence"]
    assert (
        "full_table_normalization_certified=False"
        in host_homfly_summary["notes"]
    )
    assert (
        "arbitrary_diagram_coverage_certified=False"
        in host_homfly_summary["notes"]
    )
    host_alexander_summary = host_summaries[
        "multivariable_alexander_input_certification_evidence"
    ]
    assert "full_invariant_certified=False" in host_alexander_summary["notes"]


def test_cli_homfly_skein_identity_audit_accepts_imgui_role_order_payload(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        signed_pd_path = tmp_path / "hopf_imgui_role_order.json"
        _write_hopf_imgui_with_role_order(signed_pd_path)

        exit_code = main(
            [
                "homfly-skein-identity-audit",
                str(signed_pd_path),
                "--max-depth",
                "12",
                "--max-nodes",
                "2048",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "homfly_skein_identity_audit"
    assert payload["claim_scope"] == "local_homfly_skein_identity_for_signed_pd_input"
    assert payload["source_signed_pd"].endswith("hopf_imgui_role_order.json")
    assert payload["input"]["input_shape"] == "imgui_signed_pd"
    assert payload["input"]["role_order"] == [1, 0, 2, 3]
    assert payload["input"]["signed_pd_revision"] == 42
    assert payload["input"]["orientation_generated_for_homfly"] is True
    assert payload["skipped"] is False
    assert payload["matched"] is True
    assert payload["truncated"] is False
    assert payload["crossing_count"] == 2
    assert payload["checked_crossing_count"] == 2
    assert all(row["difference"] == "0" for row in payload["crossing_audits"])
    assert payload["full_table_normalization_certified"] is False
    assert payload["arbitrary_diagram_coverage_certified"] is False


def test_cli_homfly_skein_identity_auto_role_order_allows_zero_crossing(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "unknot_skein_auto_role_order.json"
        path.write_text(
            json.dumps({"diagram": get_diagram_fixture("0_1").diagram().to_dict()}),
            encoding="utf-8",
        )

        exit_code = main(["homfly-skein-identity-audit", str(path), "--auto-role-order"])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "homfly_skein_identity_audit"
    assert payload["claim_scope"] == "local_homfly_skein_identity_for_signed_pd_input"
    assert payload["skipped"] is False
    assert payload["matched"] is True
    assert payload["crossing_count"] == 0
    assert payload["checked_crossing_count"] == 0
    assert payload["input"]["auto_role_order"]["requested"] is True
    assert payload["input"]["auto_role_order"]["applied"] is False
    assert payload["input"]["auto_role_order"]["status"] == "not_needed"
    assert payload["input"]["auto_role_order"]["notes"] == [
        "zero-crossing diagrams do not need role-order inference",
    ]
    assert payload["notes"] == [
        "zero-crossing diagrams have no local skein identities to audit",
    ]


def test_cli_multivariable_alexander_improves_scanned_gcd_result(capsys) -> None:
    source_result = _synthetic_nonmaximal_alexander_result()

    with workspace_tempdir() as tmp_path:
        path = tmp_path / "alexander-result.json"
        path.write_text(json.dumps(source_result), encoding="utf-8")

        exit_code = main(
            ["multivariable-alexander-improve-scanned-gcd-result", str(path)]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "multivariable_alexander_improve_scanned_gcd_result"
    assert payload["input_report_method"] == source_result["method"]
    assert payload["skipped"] is False
    assert payload["improved"] is True
    assert payload["accepted"] is True
    assert payload["improved_candidate_polynomial"] == "1 - t2 - t1 + t1*t2"
    assert payload["source_audit"]["candidate_is_exact_scanned_gcd"] is False
    assert payload["result"]["multivariable_alexander_polynomial"] == (
        "1 - t2 - t1 + t1*t2"
    )
    assert payload["improved_audit"]["candidate_is_exact_scanned_gcd"] is True
    assert payload["improved_audit"]["complete_scanned_gcd_certified"] is True
    assert payload["improved_audit"]["improved_candidate_polynomial"] is None


def test_cli_multivariable_alexander_pd_exposes_zero_crossing_terminal(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "unknot_zero_crossing.json"
        path.write_text(
            json.dumps({"diagram": get_diagram_fixture("0_1").diagram().to_dict()}),
            encoding="utf-8",
        )

        exit_code = main(["multivariable-alexander-pd", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "multivariable_alexander_pd_report"
    assert payload["result"]["method"] == "zero_crossing_unlink_normalization"
    assert payload["multivariable_alexander_polynomial"] == "1"
    assert payload["zero_crossing_unlink_certified"] is True
    assert payload["bounded_scanned_gcd_certified"] is False
    assert payload["complete_scanned_gcd_certified"] is False
    assert payload["quotient_gcd_certified"] is False
    assert payload["checked_nonzero_minor_count"] == 0
    assert payload["failed_nonzero_minor_count"] == 0
    assert payload["scanned_minor_count"] == 0
    assert payload["division_record_count"] == 0
    assert payload["truncated"] is False
    assert payload["wirtinger_fox_input_chain_consistent"] is False
    assert payload["full_admissible_minor_normalization_certified"] is False
    assert payload["full_invariant_certified"] is False
    assert payload["input_certification_evidence"]["skipped"] is True


def test_cli_signed_pd_commands_accept_imgui_role_order_payload(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "hopf_imgui_role_order.json"
        path.write_text(
            json.dumps(
                {
                    "diagram": {
                        "name": "hopf-imgui-role-order",
                        "component_count": 2,
                        "crossings": [
                            {
                                "edge_labels": [4, 1, 2, 3],
                                "sign": 1,
                                "role_order": [1, 0, 2, 3],
                                "role_order_explicit": True,
                            },
                            {
                                "edge_labels": [2, 3, 4, 1],
                                "sign": -1,
                                "role_order": [1, 0, 2, 3],
                                "role_order_explicit": True,
                            },
                        ],
                    },
                    "signed_pd_revision": 37,
                    "variables": ["t1", "t2"],
                }
            ),
            encoding="utf-8",
        )

        homfly_exit = main(
            [
                "homfly-pd",
                str(path),
                "--max-depth",
                "8",
                "--max-nodes",
                "2048",
            ]
        )
        homfly = json.loads(capsys.readouterr().out)

        alexander_exit = main(["multivariable-alexander-pd", str(path)])
        alexander = json.loads(capsys.readouterr().out)

    assert homfly_exit == 0
    assert homfly["method"] == "homfly_pd_report"
    assert homfly["claim_scope"] == (
        "iterative_recursive_frontier_exhaustion_for_one_signed_pd_input"
    )
    assert homfly["input"]["input_shape"] == "imgui_signed_pd"
    assert homfly["input"]["role_order"] == [1, 0, 2, 3]
    assert homfly["input"]["per_crossing_role_order_explicit"] == [True, True]
    assert homfly["input"]["per_crossing_role_order_explicit_count"] == 2
    assert homfly["input"]["signed_pd_revision"] == 37
    assert homfly["input"]["orientation_generated_for_homfly"] is True
    assert homfly["certified_for_input"] is True
    assert homfly["homfly_polynomial"] == "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z"
    assert homfly["max_crossings"] == 8
    assert homfly["initial_depth"] == 0
    assert homfly["max_depth"] == 8
    assert homfly["max_nodes"] == 2048
    assert homfly["frontier_exhausted"] is True
    assert homfly["input_certification_evidence"]["frontier_exhausted"] is True
    assert homfly["zero_crossing_certified"] is False
    assert homfly["recursion_nodes"] == homfly["input_certification_evidence"]["recursion_nodes"]
    assert homfly["recursion_nodes"] > 0
    assert homfly["cache_hits"] == homfly["input_certification_evidence"]["cache_hits"]
    assert homfly["terminal_reduction_count"] == (
        homfly["input_certification_evidence"]["terminal_reduction_count"]
    )
    assert homfly["terminal_reduction_count"] > 0
    assert homfly["memoized_reduction_count"] == (
        homfly["input_certification_evidence"]["memoized_reduction_count"]
    )
    assert homfly["reduction_contribution_count"] == (
        homfly["input_certification_evidence"]["reduction_contribution_count"]
    )
    assert homfly["frontier_count"] == 0
    assert homfly["frontier_reason_count"] == 0
    assert homfly["frontier_reasons"] == []
    assert homfly["truncated"] is False
    _assert_cli_homfly_frontier_witness_consistency(
        homfly["input_certification_evidence"]
    )
    assert homfly["iterative_attempt_count"] >= 1
    assert homfly["iterative_solved_depth"] is not None
    assert homfly["terminal_contribution_matches_result"] is True
    assert homfly["terminal_contribution_audit_skipped"] is False
    assert homfly["full_table_normalization_certified"] is False
    assert homfly["arbitrary_diagram_coverage_certified"] is False
    assert homfly["certification_blockers"] == []
    assert homfly["certification_blocker_count"] == 0
    assert homfly["input_certification_evidence"]["certification_blockers"] == []
    assert homfly["input_certification_evidence"][
        "certification_blocker_details"
    ] == []
    assert homfly["input_certification_evidence"][
        "certification_blocker_detail_count"
    ] == 0
    _assert_cli_homfly_pd_top_level_blocker_fields_match_evidence(homfly)
    assert homfly["certification_blocker_details"] == []
    assert homfly["certification_blocker_detail_count"] == 0
    assert homfly["homfly_completion_blockers"] == [
        "full_table_normalization_not_certified",
        "arbitrary_diagram_coverage_not_certified",
    ]
    assert homfly["homfly_completion_blocker_count"] == 2
    _assert_cli_blocker_detail_codes(
        homfly["input_certification_evidence"],
        "homfly_completion_blocker_details",
        [
            "full_table_normalization_not_certified",
            "arbitrary_diagram_coverage_not_certified",
        ],
    )
    _assert_cli_blocker_detail_codes(
        homfly,
        "homfly_completion_blocker_details",
        [
            "full_table_normalization_not_certified",
            "arbitrary_diagram_coverage_not_certified",
        ],
    )
    assert homfly["homfly_completion_blocker_detail_count"] == 2
    gate = homfly["input_certification_evidence"][
        "arbitrary_diagram_completion_gate"
    ]
    _assert_cli_homfly_arbitrary_completion_gate(gate)
    assert gate["evidence_scope"] == "single_signed_pd_input"
    assert gate["frontier_exhausted"] is True
    assert gate["frontier_count"] == 0
    assert homfly["homfly_completion_blocker_details"][1]["witness"] == gate

    assert alexander_exit == 0
    assert alexander["method"] == "multivariable_alexander_pd_report"
    assert alexander["input"]["input_shape"] == "imgui_signed_pd"
    assert alexander["input"]["role_order"] == [1, 0, 2, 3]
    assert alexander["input"]["signed_pd_revision"] == 37
    assert alexander["input"]["per_crossing_role_orders"] == [
        [1, 0, 2, 3],
        [1, 0, 2, 3],
    ]
    assert alexander["input"]["per_crossing_role_order_explicit"] == [
        True,
        True,
    ]
    assert alexander["input"]["per_crossing_role_order_explicit_count"] == 2
    assert alexander["skipped"] is False
    assert alexander["multivariable_alexander_polynomial"] == "1"
    assert alexander["orientation_inference"]["method"] == (
        "inferred_signed_pd_global_role_order"
    )
    assert alexander["full_admissible_minor_normalization_certified"] is False
    assert alexander["full_invariant_certified"] is False
    assert alexander["input_certification_evidence"][
        "bounded_scanned_gcd_certified"
    ] is True
    assert alexander["input_certification_evidence"]["quotient_gcd_certified"] is True
    assert alexander["bounded_scanned_gcd_certified"] is True
    assert alexander["complete_scanned_gcd_certified"] is True
    assert alexander["quotient_gcd_certified"] is True
    assert alexander["checked_nonzero_minor_count"] >= 1
    assert alexander["failed_nonzero_minor_count"] == 0
    assert alexander["scanned_minor_count"] >= 1
    assert alexander["division_record_count"] >= 1
    assert alexander["truncated"] is False
    assert alexander["wirtinger_fox_input_chain_consistent"] is True


def test_imgui_signed_pd_input_report_preserves_role_order_explicit_metadata() -> None:
    payload = {
        "component_count": 1,
        "crossings": [
            {
                "edge_labels": [1, 2, 1, 2],
                "sign": 1,
                "role_order": [0, 1, 2, 3],
                "role_order_explicit": False,
            },
            {
                "edge_labels": [3, 4, 3, 4],
                "sign": -1,
                "role_order": [0, 1, 2, 3],
                "role_order_explicit": True,
            },
            {
                "edge_labels": [5, 6, 5, 6],
                "sign": 1,
            },
            {
                "edge_labels": [7, 8, 7, 8],
                "sign": -1,
                "role_order": [1, 0, 2, 3],
            },
        ],
    }

    signed_pd_input = _signed_pd_input_from_payload(
        payload,
        role_order_override=(0, 1, 2, 3),
    )
    report = _signed_pd_input_report(signed_pd_input)

    assert report["input_shape"] == "imgui_signed_pd"
    assert report["per_crossing_role_orders"] == [
        [0, 1, 2, 3],
        [0, 1, 2, 3],
        [0, 1, 2, 3],
        [1, 0, 2, 3],
    ]
    assert report["per_crossing_role_order_explicit"] == [
        False,
        True,
        False,
        True,
    ]
    assert report["per_crossing_role_order_explicit_count"] == 2


def test_cli_homfly_pd_exposes_frontier_diagnostics_for_uncertified_input(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "hopf_imgui_role_order.json"
        _write_hopf_imgui_with_role_order(path)

        exit_code = main(
            [
                "homfly-pd",
                str(path),
                "--max-depth",
                "0",
                "--max-nodes",
                "2048",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "homfly_pd_report"
    assert payload["certified_for_input"] is False
    assert payload["homfly_polynomial"] is None
    assert payload["max_crossings"] == 8
    assert payload["initial_depth"] == 0
    assert payload["max_depth"] == 0
    assert payload["max_nodes"] == 2048
    assert payload["frontier_exhausted"] is False
    assert payload["zero_crossing_certified"] is False
    assert payload["recursion_nodes"] >= 1
    assert payload["cache_hits"] >= 0
    assert payload["terminal_reduction_count"] >= 0
    assert payload["memoized_reduction_count"] >= 0
    assert payload["reduction_contribution_count"] >= 0
    assert payload["frontier_count"] > 0
    assert payload["frontier_reason_count"] == 1
    assert payload["frontier_reasons"] == ["max_depth"]
    assert payload["truncated"] is False
    assert payload["iterative_attempt_count"] == 1
    assert payload["iterative_solved_depth"] is None
    assert payload["terminal_contribution_matches_result"] is False
    assert isinstance(payload["terminal_contribution_audit_skipped"], bool)
    assert payload["input_certification_evidence"]["frontier_reasons"] == ["max_depth"]
    assert payload["input_certification_evidence"]["frontier_witness_count"] == 1
    _assert_cli_homfly_frontier_witness_consistency(
        payload["input_certification_evidence"]
    )
    first_input_witness = payload["input_certification_evidence"][
        "first_frontier_witness"
    ]
    assert first_input_witness["path"] == ["root"]
    assert first_input_witness["reason"] == "max_depth"
    assert first_input_witness["cap"] == {
        "max_depth": 0,
        "max_nodes": 2048,
    }
    assert payload["certification_blockers"] == ["frontier_not_exhausted"]
    assert payload["certification_blocker_count"] == 1
    _assert_cli_homfly_pd_top_level_blocker_fields_match_evidence(payload)
    _assert_cli_blocker_detail_codes(
        payload,
        "certification_blocker_details",
        ["frontier_not_exhausted"],
    )
    assert payload["input_certification_evidence"]["certification_blockers"] == [
        "frontier_not_exhausted",
    ]
    _assert_cli_blocker_detail_codes(
        payload["input_certification_evidence"],
        "certification_blocker_details",
        ["frontier_not_exhausted"],
    )
    assert payload["input_certification_evidence"][
        "certification_blocker_details"
    ][0]["cap"] == {"max_depth": 0, "max_nodes": 2048}
    assert payload["input_certification_evidence"][
        "certification_blocker_details"
    ][0]["witness"]["frontier_reasons"] == ["max_depth"]
    assert payload["input_certification_evidence"][
        "certification_blocker_details"
    ][0]["witness"]["first_frontier_witness"] == first_input_witness
    assert payload["homfly_completion_blockers"] == [
        "full_table_normalization_not_certified",
        "arbitrary_diagram_coverage_not_certified",
    ]
    assert payload["homfly_completion_blocker_count"] == 2
    _assert_cli_blocker_detail_codes(
        payload,
        "homfly_completion_blocker_details",
        [
            "full_table_normalization_not_certified",
            "arbitrary_diagram_coverage_not_certified",
        ],
    )
    assert payload["homfly_completion_blocker_detail_count"] == 2
    gate = payload["input_certification_evidence"][
        "arbitrary_diagram_completion_gate"
    ]
    _assert_cli_homfly_arbitrary_completion_gate(gate)
    assert gate["frontier_exhausted"] is False
    assert gate["frontier_count"] == payload["frontier_count"]
    assert gate["frontier_reasons"] == ["max_depth"]
    assert gate["first_frontier_witness"] == first_input_witness
    assert gate["certification_blockers"] == ["frontier_not_exhausted"]
    assert payload["homfly_completion_blocker_details"][1]["witness"] == gate


def test_cli_signed_pd_role_order_candidates_reports_ambiguous_imgui_payload(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "hopf_imgui_without_role_order.json"
        path.write_text(
            json.dumps(
                {
                    "diagram": {
                        "name": "hopf-imgui-without-role-order",
                        "component_count": 2,
                        "crossings": [
                            {"edge_labels": [4, 1, 2, 3], "sign": 1},
                            {"edge_labels": [2, 3, 4, 1], "sign": -1},
                        ],
                    }
                }
            ),
            encoding="utf-8",
        )

        exit_code = main(["signed-pd-role-order-candidates", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "signed_pd_role_order_candidates_report"
    assert payload["input"]["input_shape"] == "imgui_signed_pd"
    assert payload["status"] == "ambiguous"
    assert payload["strict_candidate_count"] > 1
    assert payload["unique_strict_global_role_order"] is None
    assert [1, 0, 2, 3] in payload["candidate_role_orders"]
    assert all("orientation" not in candidate for candidate in payload["candidates"])


def test_cli_signed_pd_role_order_candidates_can_include_invariant_signatures(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "hopf_imgui_signature_candidates.json"
        path.write_text(
            json.dumps(
                {
                    "diagram": {
                        "name": "hopf-imgui-signature-candidates",
                        "component_count": 2,
                        "crossings": [
                            {"edge_labels": [4, 1, 2, 3], "sign": 1},
                            {"edge_labels": [2, 3, 4, 1], "sign": -1},
                        ],
                    },
                    "variables": ["t1", "t2"],
                }
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "signed-pd-role-order-candidates",
                str(path),
                "--include-invariant-signatures",
                "--signature-max-candidates",
                "2",
                "--signature-max-depth",
                "6",
                "--signature-max-nodes",
                "1024",
            ]
        )
        payload = json.loads(capsys.readouterr().out)
        report_path = tmp_path / "role-order-candidates.json"
        report_path.write_text(json.dumps(payload), encoding="utf-8")
        analysis_exit = main(["imgui-analysis-summary-payload", str(report_path)])
        analysis = json.loads(capsys.readouterr().out)
        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(report_path)]
        )
        host = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["status"] == "ambiguous"
    assert payload["unique_strict_global_role_order"] is None
    signatures = payload["invariant_signatures"]
    assert signatures["requested"] is True
    assert signatures["signature_resolution_status"] == "partially_distinguishes_candidates"
    assert signatures["signature_resolution_status_code"] == 5
    assert signatures["strict_candidate_count"] == payload["strict_candidate_count"]
    assert signatures["all_strict_candidates_evaluated"] is False
    assert signatures["evaluated_candidate_count"] == 2
    assert signatures["skipped_candidate_count"] == payload["strict_candidate_count"] - 2
    assert signatures["homfly_signature_count"] == 2
    assert signatures["combined_signature_count"] == 2
    assert signatures["variables"] == ["t1", "t2"]
    assert signatures["homfly_certified_candidate_count"] == 2
    assert signatures["homfly_frontier_count"] == 0
    assert signatures["homfly_frontier_reason_count"] == 0
    assert signatures["homfly_truncated_candidate_count"] == 0
    assert signatures["alexander_bounded_scanned_gcd_certified_candidate_count"] == 2
    assert signatures["alexander_complete_scanned_gcd_certified_candidate_count"] == 2
    assert signatures["alexander_quotient_gcd_certified_candidate_count"] == 2
    assert signatures["alexander_failed_nonzero_minor_count"] == 0
    assert signatures["alexander_truncated_candidate_count"] == 0
    signed_candidates = [
        candidate for candidate in payload["candidates"] if "invariant_signature" in candidate
    ]
    assert [candidate["role_order"] for candidate in signed_candidates] == [
        [0, 1, 2, 3],
        [0, 1, 3, 2],
    ]
    assert signed_candidates[0]["invariant_signature"]["homfly"]["polynomial"] == (
        "-a^-1*z^-1 + a*z^-1"
    )
    assert signed_candidates[1]["invariant_signature"]["homfly"]["polynomial"] == (
        "-a*z^-1 - a*z + a^3*z^-1"
    )
    assert all(
        candidate["invariant_signature"]["alexander"]["polynomial"] == "1"
        for candidate in signed_candidates
    )
    assert all(
        candidate["invariant_signature"]["homfly"]["frontier_reasons"] == []
        for candidate in signed_candidates
    )
    assert all(
        candidate["invariant_signature"]["alexander"][
            "bounded_scanned_gcd_certified"
        ]
        for candidate in signed_candidates
    )
    assert all(
        candidate["invariant_signature"]["alexander"][
            "complete_scanned_gcd_certified"
        ]
        for candidate in signed_candidates
    )
    assert all(
        candidate["invariant_signature"]["alexander"]["quotient_gcd_certified"]
        for candidate in signed_candidates
    )
    assert all(
        candidate["invariant_signature"]["alexander"]["failed_nonzero_minor_count"]
        == 0
        for candidate in signed_candidates
    )
    assert all(
        candidate["invariant_signature"]["alexander"][
            "input_certification_evidence"
        ]["bounded_scanned_gcd_certified"]
        for candidate in signed_candidates
    )
    assert all(
        candidate["invariant_signature"]["alexander"][
            "input_certification_evidence"
        ]["complete_scanned_gcd_certified"]
        for candidate in signed_candidates
    )
    assert all(group["homfly_frontier_count"] == 0 for group in signatures["groups"])
    assert all(
        group["alexander_failed_nonzero_minor_count"] == 0
        for group in signatures["groups"]
    )
    assert analysis_exit == 0
    assert "source_signed_pd_revision" not in analysis
    assert analysis["analysis_role_order_signature_strict_candidate_count"] == 16
    assert analysis["analysis_role_order_signature_evaluated_candidate_count"] == 2
    assert (
        analysis[
            "analysis_role_order_signature_all_strict_candidates_evaluated_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_role_order_signature_alexander_complete_scanned_gcd_certified_candidate_count"
        ]
        == 2
    )
    analysis_summary = analysis["analysis_summaries"][0]
    assert analysis_summary["source_method"] == "signed_pd_role_order_candidates_report"
    assert analysis_summary["accepted"] is False
    assert (
        analysis_summary["role_order_signature_all_strict_candidates_evaluated"]
        is False
    )
    assert "signature_all_strict_evaluated=false" in analysis_summary["notes"]

    assert host_exit == 0
    host_summaries = {
        row["source_method"]: row for row in host["analysis"]["analysis_summaries"]
    }
    host_summary = host_summaries["signed_pd_role_order_candidates_report"]
    assert host_summary["role_order_signature_strict_candidate_count"] == 16
    assert host_summary["role_order_signature_evaluated_candidate_count"] == 2
    assert host_summary["role_order_signature_all_strict_candidates_evaluated"] is False
    assert any(
        note == "signature resolution status: partially_distinguishes_candidates"
        for note in signatures["notes"]
    )

def _write_role_order_candidates_report(path) -> None:
    path.write_text(
        json.dumps(
            {
                "method": "signed_pd_role_order_candidates_report",
                "input": {
                    "signed_pd_revision": 42,
                },
                "status": "ambiguous",
                "candidate_count": 16,
                "strict_candidate_count": 16,
                "unique_strict_global_role_order": None,
                "invariant_signatures": {
                    "requested": True,
                    "evaluated_candidate_count": 2,
                    "skipped_candidate_count": 14,
                    "homfly_signature_count": 2,
                    "alexander_signature_count": 1,
                    "combined_signature_count": 2,
                    "homfly_certified_candidate_count": 2,
                    "homfly_frontier_count": 0,
                    "homfly_frontier_reason_count": 0,
                    "alexander_bounded_scanned_gcd_certified_candidate_count": 2,
                    "alexander_complete_scanned_gcd_certified_candidate_count": 2,
                    "alexander_quotient_gcd_certified_candidate_count": 2,
                    "alexander_failed_nonzero_minor_count": 0,
                    "groups": [],
                },
                "notes": ["multiple strict global role_order candidates matched"],
            }
        ),
        encoding="utf-8",
    )


def _write_core_benchmark_matrix_report(path) -> None:
    path.write_text(
        json.dumps(
            {
                "method": "iroll_core_benchmark_matrix",
                "point_sizes": [32],
                "backends": ["numpy", "gpu"],
                "workloads": ["crossings", "contacts"],
                "repeat": 1,
                "warmup": 0,
                "matrix_summary": {
                    "method": "iroll_core_benchmark_matrix_run_summary",
                    "expected_row_count": 4,
                    "row_count": 4,
                    "completed_count": 4,
                    "skipped_count": 0,
                    "failed_count": 0,
                    "all_requested_rows_completed": True,
                    "has_failures": False,
                },
                "speedup_evidence": {
                    "method": "iroll_core_benchmark_speedup_evidence",
                    "candidate_speedup_count": 1,
                    "release_grade_speedup_claimed": False,
                    "release_gate": {
                        "repeat": 1,
                        "minimum_repeat_for_release_claim": 3,
                        "repeat_satisfied": False,
                        "speedup_threshold": 1.25,
                        "threshold_candidate_count": 1,
                        "completed_comparison_count": 2,
                        "missing_baseline_count": 0,
                        "release_grade_speedup_claimed": False,
                        "blocking_reasons": ["repeat_below_minimum"],
                    },
                },
                "cuda_gpu_benchmark_evidence": {
                    "method": "iroll_core_cuda_gpu_benchmark_evidence",
                    "gate_scope": "local_gpu_benchmark_witness",
                    "gpu_backend_requested": True,
                    "gpu_backend_available": True,
                    "cuda_runtime_observed": True,
                    "gpu_requested_row_count": 2,
                    "gpu_completed_row_count": 2,
                    "gpu_skipped_row_count": 0,
                    "gpu_failed_row_count": 0,
                    "gpu_threshold_candidate_count": 1,
                    "hosted_cuda_ci_claimed": False,
                    "cuda_parity_claimed": False,
                    "release_grade_gpu_speedup_claimed": False,
                    "blocking_reasons": [
                        "cuda_parity_not_claimed",
                        "hosted_cuda_ci_not_observed",
                    ],
                    "blocking_reason_count": 2,
                },
                "notes": ["synthetic CLI benchmark matrix"],
            }
        ),
        encoding="utf-8",
    )


def _write_gpu_smoke_unavailable_report(path) -> None:
    path.write_text(
        json.dumps(
            {
                "available": False,
                "matched": False,
                "artifact_schema_version": 1,
                "artifact_kind": "gpu_smoke_unavailable_boundary",
                "execution_path": "optional_gpu_unavailable",
                "claim_scope": "optional_no_cuda_boundary",
                "required_capabilities": [
                    "segment_segment_distance",
                    "segment_segment_distances",
                    "segment_intersections_2d",
                ],
                "required_capability_count": 3,
                "parity_check_count": 0,
                "passed_check_count": 0,
                "failed_check_count": 0,
                "check_results": [],
                "environment_metadata": {
                    "gpu_backend_available": False,
                },
                "environment_witness": {
                    "schema_version": 1,
                    "runtime": {
                        "cuda_runtime_observed": False,
                    },
                    "simulation": {
                        "simulated_parity_failure": False,
                    },
                },
                "evidence": {
                    "gpu_dispatch_parity": False,
                    "no_cuda_boundary": True,
                    "cuda_parity": False,
                    "release_grade_speedup": False,
                },
                "gpu_release_gate": {
                    "schema_version": 1,
                    "gate_scope": "gpu_dispatch_parity_smoke",
                    "gpu_backend_available": False,
                    "cuda_runtime_observed": False,
                    "required_check_count": 3,
                    "parity_check_count": 0,
                    "passed_check_count": 0,
                    "failed_check_count": 0,
                    "required_capability_count": 3,
                    "blocking_reasons": [
                        "gpu_backend_unavailable",
                        "cuda_runtime_not_observed",
                        "required_checks_incomplete",
                    ],
                    "blocking_reason_count": 3,
                    "gpu_dispatch_parity_smoke_claimed": False,
                    "cuda_parity_claimed": False,
                    "release_grade_speedup_claimed": False,
                    "gate_passed": False,
                },
                "gpu_dispatch_parity_smoke_claimed": False,
                "cuda_parity_claimed": False,
                "release_grade_speedup_claimed": False,
                "note": "synthetic no-CUDA GPU smoke artifact",
            }
        ),
        encoding="utf-8",
    )


def _write_gpu_smoke_failure_report(path) -> None:
    path.write_text(
        json.dumps(
            {
                "available": False,
                "matched": False,
                "artifact_schema_version": 1,
                "artifact_kind": "gpu_smoke_parity_failure",
                "execution_path": "gpu_backend_parity_mismatch",
                "claim_scope": "gpu_dispatch_parity_smoke",
                "required_capabilities": [
                    "segment_segment_distance",
                    "segment_segment_distances",
                    "segment_intersections_2d",
                ],
                "required_capability_count": 3,
                "parity_check_count": 1,
                "passed_check_count": 0,
                "failed_check_count": 1,
                "check_results": [
                    {
                        "name": "gpu_numpy_parity",
                        "matched": False,
                        "reference_backend": "numpy",
                        "tested_backend": "gpu",
                        "error": "simulated parity failure",
                    }
                ],
                "environment_metadata": {
                    "gpu_backend_available": False,
                },
                "environment_witness": {
                    "schema_version": 1,
                    "runtime": {
                        "cuda_runtime_observed": False,
                    },
                    "simulation": {
                        "simulated_parity_failure": True,
                    },
                },
                "evidence": {
                    "gpu_dispatch_parity": False,
                    "no_cuda_boundary": False,
                    "cuda_parity": False,
                    "release_grade_speedup": False,
                },
                "gpu_release_gate": {
                    "schema_version": 1,
                    "gate_scope": "gpu_dispatch_parity_smoke",
                    "gpu_backend_available": False,
                    "cuda_runtime_observed": False,
                    "required_check_count": 3,
                    "parity_check_count": 1,
                    "passed_check_count": 0,
                    "failed_check_count": 1,
                    "required_capability_count": 3,
                    "blocking_reasons": [
                        "gpu_backend_unavailable",
                        "cuda_runtime_not_observed",
                        "required_checks_incomplete",
                        "required_checks_failed",
                        "simulated_parity_failure",
                    ],
                    "blocking_reason_count": 5,
                    "gpu_dispatch_parity_smoke_claimed": False,
                    "cuda_parity_claimed": False,
                    "release_grade_speedup_claimed": False,
                    "gate_passed": False,
                },
                "gpu_dispatch_parity_smoke_claimed": False,
                "cuda_parity_claimed": False,
                "release_grade_speedup_claimed": False,
                "note": "synthetic simulated GPU parity-failure artifact",
            }
        ),
        encoding="utf-8",
    )


def _write_imgui_framebuffer_smoke_report(path) -> None:
    path.write_text(
        json.dumps(
            {
                "artifact_schema_version": 1,
                "artifact_kind": "imgui_test_stub_framebuffer_smoke",
                "claim_scope": (
                    "repository_imgui_test_stub_draw_list_framebuffer_estimate"
                ),
                "real_graphics_backend_framebuffer_verified": False,
                "screenshot_verified": False,
                "imgui_abi_version": 117,
                "rust_c_abi_version": 19,
                "render_frame_count": 1,
                "last_render_geometry_nonempty": 1,
                "last_render_geometry_canvas_count": 2,
                "last_render_geometry_filled_rect_count": 2,
                "last_render_geometry_rect_count": 2,
                "last_render_geometry_polyline_count": 4,
                "last_render_geometry_marker_count": 2,
                "rect_filled_count": 2,
                "rect_count": 2,
                "polyline_count": 4,
                "circle_filled_count": 2,
                "text_count": 10,
                "framebuffer_touched": 1,
                "estimated_nonzero_pixels": 4096,
                "passed": True,
            }
        ),
        encoding="utf-8",
    )


def _write_imgui_production_framebuffer_pack(path) -> None:
    path.write_text(
        json.dumps(
            {
                "artifact_schema_version": 1,
                "artifact_kind": "imgui_production_renderer_framebuffer_pack",
                "claim_scope": "production_imgui_renderer_framebuffer_verification",
                "real_graphics_backend_framebuffer_verified": True,
                "screenshot_verified": True,
                "graphics_backend_name": "wgpu-vulkan",
                "framebuffer_width": 128,
                "framebuffer_height": 64,
                "screenshot_url": "https://evidence.iroll.dev/production-imgui.png",
                "screenshot_sha256": "a" * 64,
                "imgui_abi_version": 117,
                "rust_c_abi_version": 19,
                "render_frame_count": 2,
                "last_render_geometry_nonempty": 1,
                "last_render_geometry_canvas_count": 2,
                "last_render_geometry_filled_rect_count": 2,
                "last_render_geometry_rect_count": 2,
                "last_render_geometry_polyline_count": 4,
                "last_render_geometry_marker_count": 2,
                "rect_filled_count": 2,
                "rect_count": 2,
                "polyline_count": 4,
                "circle_filled_count": 2,
                "text_count": 10,
                "framebuffer_touched": 1,
                "estimated_nonzero_pixels": 8192,
                "passed": True,
            }
        ),
        encoding="utf-8",
    )


def _write_signed_release_publication_manifest(path) -> None:
    path.write_text(
        json.dumps(
            {
                "artifact_schema_version": 1,
                "artifact_kind": "signed_release_publication_manifest",
                "claim_scope": "signed_release_publication",
                "signed_release_artifacts_published": True,
                "publication_claimed": True,
                "platform_index_publication_claimed": True,
                "published_artifact_count": 2,
                "signature_count": 2,
                "package_index_url": "https://evidence.iroll.dev/releases/0.1.0",
                "artifact_urls": [
                    "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0-py3-none-any.whl",
                    "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0.tar.gz",
                ],
                "artifact_sha256s": ["a" * 64, "b" * 64],
                "signature_urls": [
                    "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0-py3-none-any.whl.sig",
                    "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0.tar.gz.sig",
                ],
                "signature_sha256s": ["c" * 64, "d" * 64],
            }
        ),
        encoding="utf-8",
    )


_FULL_HOMFLY_TEST_PACK_CACHE: dict | None = None


def _write_full_homfly_certification_pack(path) -> None:
    global _FULL_HOMFLY_TEST_PACK_CACHE
    if _FULL_HOMFLY_TEST_PACK_CACHE is None:
        import argparse
        from copy import deepcopy
        from unittest.mock import patch

        from iroll.cli import (
            _KNOT_ATLAS_PINNED_HOMFLY_SOURCES,
            _homfly_full_certification_pack_producer_command,
            _homfly_full_certification_report_command,
        )
        from iroll.io import dump_report

        content_by_title = {
            str(record["title"]): (
                "\n".join(str(value) for value in record["required_phrases"])
                if role == "definition"
                else str(record["expected_math_source"])
            )
            for role, record in _KNOT_ATLAS_PINNED_HOMFLY_SOURCES.items()
        }
        byte_count_by_title = {
            str(record["title"]): int(record["byte_count"])
            for record in _KNOT_ATLAS_PINNED_HOMFLY_SOURCES.values()
        }

        def fetch_source(
            url,
            expected_sha256,
            *,
            timeout,
            title=None,
            revision_id=None,
        ):
            content = content_by_title[str(title)]
            return {
                "title": title,
                "revision_id": revision_id,
                "url": url,
                "expected_sha256": expected_sha256,
                "actual_sha256": expected_sha256,
                "byte_count": byte_count_by_title[str(title)],
                "fetched": True,
                "sha256_verified": True,
                "error": None,
                "_content": content,
                "_bytes": content.encode("utf-8"),
            }

        with patch("iroll.cli._fetch_url_sha256_witness", fetch_source):
            report = _homfly_full_certification_report_command(
                argparse.Namespace(
                    network_timeout=1.0,
                    fail_on_not_certified=True,
                )
            )
        assert report.pop("_exit_code") == 0
        report_bytes = (dump_report(report) + "\n").encode("utf-8")
        report_path = path.with_name(".homfly-test-embedded-report.json")
        report_path.write_bytes(report_bytes)

        def fetch_published(
            url,
            expected_sha256,
            *,
            timeout,
            title=None,
            revision_id=None,
        ):
            return {
                "title": title,
                "revision_id": revision_id,
                "url": url,
                "expected_sha256": expected_sha256,
                "actual_sha256": expected_sha256,
                "byte_count": len(report_bytes),
                "fetched": True,
                "sha256_verified": True,
                "error": None,
                "_content": report_bytes.decode("utf-8"),
                "_bytes": report_bytes,
            }

        try:
            with patch("iroll.cli._fetch_url_sha256_witness", fetch_published):
                pack = _homfly_full_certification_pack_producer_command(
                    argparse.Namespace(
                        certification_report_json=report_path,
                        certification_report_url=(
                            "https://evidence.iroll.dev/certification/"
                            "full-homfly.json"
                        ),
                        network_timeout=1.0,
                        fail_on_not_certified=True,
                    )
                )
        finally:
            report_path.unlink(missing_ok=True)
        assert pack.pop("_exit_code") == 0
        _FULL_HOMFLY_TEST_PACK_CACHE = deepcopy(pack)

    path.write_text(
        json.dumps(_FULL_HOMFLY_TEST_PACK_CACHE),
        encoding="utf-8",
    )


_FULL_ALEXANDER_TEST_PACK_CACHE: dict | None = None


def _write_full_alexander_certification_pack(path) -> None:
    global _FULL_ALEXANDER_TEST_PACK_CACHE
    if _FULL_ALEXANDER_TEST_PACK_CACHE is None:
        from iroll.topology.alexander_certification import (
            canonical_json_sha256,
            full_alexander_pinned_sources,
            full_multivariable_alexander_normalization_certification_report,
            full_multivariable_alexander_normalization_certification_report_audit,
            serialized_certification_report_sha256,
        )

        pinned = full_alexander_pinned_sources()
        assignments = []
        data_witnesses = {}
        page_witnesses = []
        for notation in ("L5a1", "L6a4"):
            fixture = get_diagram_fixture(notation)
            derivation = fixture.source_pd_convention_assignment_audit()
            assignments.append(
                {
                    "artifact_schema_version": 1,
                    "artifact_kind": "verified_signed_crossing_assignment",
                    "claim_scope": "verified_signed_crossing_assignment",
                    "notation": notation,
                    "source_url": (
                        f"https://katlas.org/wiki/Data:{notation}/PD_Presentation"
                    ),
                    "crossing_count": len(derivation["signs"]),
                    "signs": derivation["signs"],
                    "role_orders": derivation["role_orders"],
                    "source_gauss_code_match": True,
                    "source_candidate_replay_valid": True,
                    "candidate_replay_sha256": "a" * 64,
                    "unique_assignment_certified": True,
                    "invariant_table_values_verified": True,
                    "invariant_table_source_urls": [
                        f"https://katlas.org/wiki/{notation}"
                    ],
                    "invariant_table_source_sha256s": ["b" * 64],
                    "orientation_validation_issue_count": 0,
                }
            )
            data = pinned[notation]["data"]
            data_witnesses[notation] = {
                "title": data["title"],
                "revision_id": data["revision_id"],
                "url": data["url"],
                "expected_sha256": data["sha256"],
                "actual_sha256": data["sha256"],
                "byte_count": len(data["expected_math_source"].encode("utf-8")),
                "fetched": True,
                "sha256_verified": True,
                "error": None,
                "_content": data["expected_math_source"],
            }
            page = pinned[notation]["page"]
            page_witnesses.append(
                {
                    "notation": notation,
                    "title": page["title"],
                    "revision_id": page["revision_id"],
                    "url": page["url"],
                    "expected_sha256": page["sha256"],
                    "actual_sha256": page["sha256"],
                    "byte_count": 128,
                    "fetched": True,
                    "sha256_verified": True,
                    "error": None,
                }
            )
        report = full_multivariable_alexander_normalization_certification_report(
            verified_signed_crossing_assignments=assignments,
            source_witnesses=data_witnesses,
        )
        report_audit = (
            full_multivariable_alexander_normalization_certification_report_audit(
                report
            )
        )
        raw_sha256 = serialized_certification_report_sha256(report)
        canonical_sha256 = canonical_json_sha256(report)
        report_url = (
            "https://evidence.iroll.dev/certification/full-alexander.json"
        )
        serialized_byte_count = len(
            (json.dumps(report, indent=2, sort_keys=True) + "\n").encode("utf-8")
        )
        _FULL_ALEXANDER_TEST_PACK_CACHE = {
            "artifact_schema_version": 1,
            "artifact_kind": (
                "full_multivariable_alexander_normalization_certification_pack"
            ),
            "claim_scope": "full_multivariable_alexander_normalization",
            "full_multivariable_alexander_normalization_certified": True,
            "signed_pd_wirtinger_fox_certified": True,
            "admissible_minor_normalization_certified": True,
            "all_admissible_minors_consistent": True,
            "external_table_normalization_certified": True,
            "counterexample_count": 0,
            "certification_report_url": report_url,
            "certification_report_sha256": raw_sha256,
            "certification_report_raw_sha256": raw_sha256,
            "certification_report_canonical_sha256": canonical_sha256,
            "certification_report_published_witness": {
                "title": (
                    "iroll full multivariable Alexander certification report"
                ),
                "revision_id": 0,
                "url": report_url,
                "expected_sha256": raw_sha256,
                "actual_sha256": raw_sha256,
                "byte_count": serialized_byte_count,
                "fetched": True,
                "sha256_verified": True,
                "error": None,
            },
            "certification_report_published_json_matches": True,
            "certification_report_published_canonical_sha256": canonical_sha256,
            "certification_report": report,
            "certification_report_replay_audit": report_audit,
            "external_table_source_urls": [
                pinned[notation]["page"]["url"]
                for notation in ("L5a1", "L6a4")
            ],
            "external_table_source_sha256s": [
                pinned[notation]["page"]["sha256"]
                for notation in ("L5a1", "L6a4")
            ],
            "external_table_source_witnesses": page_witnesses,
            "template_placeholder": False,
            "completion_claimed": True,
        }
    path.write_text(
        json.dumps(_FULL_ALEXANDER_TEST_PACK_CACHE),
        encoding="utf-8",
    )


def _write_verified_signed_crossing_assignment(
    path,
    *,
    notation: str,
    crossing_count: int,
) -> None:
    path.write_text(
        json.dumps(
            {
                "artifact_schema_version": 1,
                "artifact_kind": "verified_signed_crossing_assignment",
                "claim_scope": "verified_signed_crossing_assignment",
                "notation": notation,
                "source_url": f"https://katlas.org/wiki/{notation}",
                "crossing_count": crossing_count,
                "signs": [1] * crossing_count,
                "role_orders": [[0, 1, 2, 3] for _ in range(crossing_count)],
                "source_gauss_code_match": True,
                "source_candidate_replay_valid": True,
                "candidate_replay_sha256": "a" * 64,
                "unique_assignment_certified": True,
                "invariant_table_values_verified": True,
                "invariant_table_source_urls": [
                    f"https://evidence.iroll.dev/tables/{notation}"
                ],
                "invariant_table_source_sha256s": ["b" * 64],
                "orientation_validation_issue_count": 0,
            }
        ),
        encoding="utf-8",
    )


def _completion_evidence_bundle_payload() -> dict:
    with workspace_tempdir() as tmp_path:
        homfly_pack_path = tmp_path / "full-homfly-pack.json"
        alexander_pack_path = tmp_path / "full-alexander-pack.json"
        _write_full_homfly_certification_pack(homfly_pack_path)
        _write_full_alexander_certification_pack(alexander_pack_path)
        full_homfly_pack = json.loads(
            homfly_pack_path.read_text(encoding="utf-8")
        )
        full_alexander_pack = json.loads(
            alexander_pack_path.read_text(encoding="utf-8")
        )
    expected_evidence_filenames = [
        "full_homfly_pt_evaluation_certification_pack.json",
        "full_multivariable_alexander_normalization_certification_pack.json",
        "production_imgui_renderer_framebuffer_pack.json",
        "signed_release_publication_manifest.json",
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "cross_workstream_completion_evidence_bundle",
        "claim_scope": "cross_workstream_final_completion_evidence",
        "bundle_inputs_complete": True,
        "bundle_input_count": 5,
        "bundle_repeatable_assignment_count": 2,
        "bundle_certified_by_audit": False,
        "completion_claimed": False,
        "expected_evidence_filename_count": len(expected_evidence_filenames),
        "expected_evidence_filenames": expected_evidence_filenames,
        "expected_evidence_filename_signature": "|".join(
            expected_evidence_filenames
        ),
        "completion_evidence_artifact_filenames": expected_evidence_filenames,
        "completion_evidence_artifact_filename_signature": "|".join(
            expected_evidence_filenames
        ),
        "completion_evidence_artifact_instance_rows": [
            {"artifact_filename": filename}
            for filename in expected_evidence_filenames
        ],
        "completion_evidence_artifact_instance_row_count": len(
            expected_evidence_filenames
        ),
        "verified_signed_crossing_assignments": [
            {
                "artifact_schema_version": 1,
                "artifact_kind": "verified_signed_crossing_assignment",
                "claim_scope": "verified_signed_crossing_assignment",
                "notation": "L5a1",
                "source_url": "https://katlas.org/wiki/L5a1",
                "crossing_count": 5,
                "signs": [1] * 5,
                "role_orders": [[0, 1, 2, 3] for _ in range(5)],
                "source_gauss_code_match": True,
                "source_candidate_replay_valid": True,
                "candidate_replay_sha256": "a" * 64,
                "unique_assignment_certified": True,
                "invariant_table_values_verified": True,
                "invariant_table_source_urls": [
                    "https://evidence.iroll.dev/tables/L5a1"
                ],
                "invariant_table_source_sha256s": ["b" * 64],
                "orientation_validation_issue_count": 0,
            },
            {
                "artifact_schema_version": 1,
                "artifact_kind": "verified_signed_crossing_assignment",
                "claim_scope": "verified_signed_crossing_assignment",
                "notation": "L6a4",
                "source_url": "https://katlas.org/wiki/L6a4",
                "crossing_count": 6,
                "signs": [1] * 6,
                "role_orders": [[0, 1, 2, 3] for _ in range(6)],
                "source_gauss_code_match": True,
                "source_candidate_replay_valid": True,
                "candidate_replay_sha256": "a" * 64,
                "unique_assignment_certified": True,
                "invariant_table_values_verified": True,
                "invariant_table_source_urls": [
                    "https://evidence.iroll.dev/tables/L6a4"
                ],
                "invariant_table_source_sha256s": ["b" * 64],
                "orientation_validation_issue_count": 0,
            },
        ],
        "production_imgui_renderer_framebuffer_pack": {
            "artifact_schema_version": 1,
            "artifact_kind": "imgui_production_renderer_framebuffer_pack",
            "claim_scope": "production_imgui_renderer_framebuffer_verification",
            "real_graphics_backend_framebuffer_verified": True,
            "screenshot_verified": True,
            "graphics_backend_name": "wgpu-vulkan",
            "framebuffer_width": 128,
            "framebuffer_height": 64,
            "screenshot_url": "https://evidence.iroll.dev/production-imgui.png",
            "screenshot_sha256": "a" * 64,
            "render_frame_count": 2,
            "framebuffer_touched": 1,
            "estimated_nonzero_pixels": 8192,
            "passed": True,
        },
        "signed_release_publication_manifest": {
            "artifact_schema_version": 1,
            "artifact_kind": "signed_release_publication_manifest",
            "claim_scope": "signed_release_publication",
            "signed_release_artifacts_published": True,
            "publication_claimed": True,
            "platform_index_publication_claimed": True,
            "published_artifact_count": 2,
            "signature_count": 2,
            "package_index_url": "https://evidence.iroll.dev/releases/0.1.0",
            "artifact_urls": [
                "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0-py3-none-any.whl",
                "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0.tar.gz",
            ],
            "artifact_sha256s": ["a" * 64, "b" * 64],
            "signature_urls": [
                "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0-py3-none-any.whl.sig",
                "https://evidence.iroll.dev/releases/0.1.0/iroll-0.1.0.tar.gz.sig",
            ],
            "signature_sha256s": ["c" * 64, "d" * 64],
        },
        "full_homfly_pt_evaluation_certification_pack": full_homfly_pack,
        "full_multivariable_alexander_normalization_certification_pack": (
            full_alexander_pack
        ),
    }


def _write_completion_evidence_bundle(path) -> None:
    path.write_text(
        json.dumps(_completion_evidence_bundle_payload()),
        encoding="utf-8",
    )


def _write_imgui_source_open_request_smoke_report(path) -> None:
    path.write_text(
        json.dumps(
            {
                "artifact_schema_version": 1,
                "artifact_kind": "imgui_source_open_request_smoke",
                "claim_scope": "host_polled_source_open_request_contract",
                "host_action": "open_source_url",
                "opened_by_real_host": False,
                "scheme_allowed": True,
                "selected_fixture": 0,
                "selected_fixture_name": "3_1",
                "selected_fixture_source": "Knot Atlas",
                "source_url": "https://katlas.org/wiki/3_1",
                "consumed_source_url": "https://katlas.org/wiki/3_1",
                "request_consumed_by_smoke": True,
                "request_cleared_after_consumption": True,
                "final_request_pending": True,
                "selected_fixture_source_url_length": 27,
                "requested_fixture_source_url_length": 27,
                "imgui_abi_version": 117,
                "rust_c_abi_version": 19,
                "passed": True,
            }
        ),
        encoding="utf-8",
    )


def _write_imgui_signed_pd_snapshot_report(path) -> None:
    path.write_text(
        json.dumps(
            {
                "method": "imgui_signed_pd_snapshot",
                "component_count": 2,
                "signed_pd_revision": 42,
                "valid": True,
                "validation": {
                    "crossing_count": 2,
                    "component_count": 2,
                    "edge_label_slot_count": 8,
                    "unique_edge_label_count": 4,
                    "nonpositive_edge_label_count": 0,
                    "labels_with_unexpected_occurrence_count": 0,
                    "labels_with_invalid_flow_count": 0,
                    "explicit_role_order_count": 2,
                    "invalid_role_order_count": 0,
                    "oriented_component_count": 2,
                    "component_count_matches": True,
                    "valid": True,
                },
                "crossings": [
                    {
                        "edge_labels": [4, 1, 2, 3],
                        "sign": 1,
                        "role_order": [1, 0, 2, 3],
                        "role_order_explicit": True,
                    },
                    {
                        "edge_labels": [2, 3, 4, 1],
                        "sign": -1,
                        "role_order": [1, 0, 2, 3],
                        "role_order_explicit": True,
                    },
                ],
            }
        ),
        encoding="utf-8",
    )


def _write_imgui_signed_pd_recompute_scheduler_smoke_report(path) -> None:
    path.write_text(
        json.dumps(
            {
                "artifact_schema_version": 1,
                "artifact_kind": "imgui_signed_pd_recompute_scheduler_smoke",
                "claim_scope": "host_owned_signed_pd_recompute_scheduler_contract",
                "imgui_abi_version": 117,
                "rust_c_abi_version": 19,
                "handoff_input_format": "imgui_signed_pd_json",
                "handoff_result_transport": "json_file",
                "homfly_cli_command": "iroll homfly-pd",
                "alexander_cli_command": "iroll multivariable-alexander-pd",
                "host_reload_payload": "imgui-signed-pd-invariant-status-payload",
                "first_revision": 1,
                "second_revision": 2,
                "first_scope": "all",
                "first_request_revision": 1,
                "first_request_snapshot_json_length": 120,
                "first_request_snapshot_fnv1a64": 11,
                "first_result_count": 2,
                "first_revision_reloaded": True,
                "stale_scope": "all",
                "stale_request_revision": 1,
                "stale_request_snapshot_json_length": 121,
                "stale_request_snapshot_fnv1a64": 12,
                "pending_request_stale": True,
                "stale_result_count": 2,
                "stale_recompute_rejected": True,
                "stale_results_rejected": True,
                "stale_error_mentions_revision_mismatch": True,
                "current_scope": "homfly",
                "current_request_revision": 2,
                "current_request_snapshot_json_length": 122,
                "current_request_snapshot_fnv1a64": 13,
                "current_result_count": 1,
                "current_revision_rows_reloaded": True,
                "current_revision_reloaded": True,
                "final_invariant_status_count": 1,
                "final_invariant_status_signed_pd_revision": 2,
                "final_signed_pd_invariant_status_stale": False,
                "final_requested_recompute_revision": 2,
                "final_requested_recompute_stale": False,
                "requested_snapshot_json_cleared": True,
                "host_queue_drained": True,
                "passed": True,
            }
        ),
        encoding="utf-8",
    )


def _write_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_report(path) -> None:
    path.write_text(
        json.dumps(
            {
                "artifact_schema_version": 1,
                "artifact_kind": (
                    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke"
                ),
                "claim_scope": (
                    "host_owned_thread_pool_signed_pd_recompute_scheduler_contract"
                ),
                "imgui_abi_version": 117,
                "rust_c_abi_version": 19,
                "handoff_input_format": "imgui_signed_pd_json",
                "handoff_result_transport": "json_file",
                "homfly_cli_command": "iroll homfly-pd",
                "alexander_cli_command": "iroll multivariable-alexander-pd",
                "host_reload_payload": "imgui-signed-pd-invariant-status-payload",
                "first_revision": 1,
                "second_revision": 2,
                "current_loaded_revision": 2,
                "stale_scope": "all",
                "stale_request_scope": "all",
                "stale_request_revision": 1,
                "stale_request_snapshot_json_length": 110,
                "stale_request_snapshot_fnv1a64": 21,
                "stale_request_queued": True,
                "stale_request_started": True,
                "stale_request_completed": True,
                "stale_result_count": 2,
                "stale_recompute_rejected": True,
                "stale_result_rejected": True,
                "current_scope": "alexander",
                "current_request_scope": "alexander",
                "current_request_revision": 2,
                "current_request_snapshot_json_length": 111,
                "current_request_snapshot_fnv1a64": 22,
                "current_request_queued": True,
                "current_request_started": True,
                "current_request_completed": True,
                "current_result_count": 1,
                "current_revision_reloaded": True,
                "requested_snapshot_json_cleared": True,
                "progress_completed": True,
                "progress_active_after_completion": False,
                "final_invariant_status_count": 1,
                "final_invariant_status_signed_pd_revision": 2,
                "final_signed_pd_invariant_status_stale": False,
                "final_requested_recompute_revision": 0,
                "final_requested_recompute_stale": False,
                "thread_pool_worker_count": 2,
                "passed": True,
            }
        ),
        encoding="utf-8",
    )


def _write_imgui_real_kernel_loader_smoke_report(path) -> None:
    path.write_text(
        json.dumps(
            {
                "artifact_schema_version": 1,
                "artifact_kind": "imgui_real_kernel_loader_smoke",
                "claim_scope": "runtime_loader_real_rust_dynamic_library_contract",
                "imgui_abi_version": 117,
                "rust_c_abi_version": 19,
                "kernel_loader_abi_version": 6,
                "passed": True,
                "dynamic_library_loaded": True,
                "api_attached_to_panel": True,
                "kernel_api_connected": True,
                "rust_kernel_available": True,
                "backend_report_bytes": 4096,
                "invariant_result_handles_report_bytes": 2048,
                "last_kernel_result_length": 512,
                "callback_thread_pool_completed": True,
                "worker_touches_imgui_context": False,
                "distance_progress_total": 3,
                "intersection_progress_total": 2,
                "distance_callback_count": 3,
                "intersection_callback_count": 2,
                "metadata_schema_version": 1,
                "metadata_contract_version": (
                    "rust_c_abi_19_invariant_result_handles_lifecycle_metadata_v1"
                ),
                "required_metadata_field_count": 30,
                "required_metadata_fields_present": True,
                "readiness_provenance_present": True,
                "ready_for_native_result_handles": False,
                "readiness_blocked_by_required_gates": True,
                "native_result_handles_complete": False,
                "complete_result_handle_abi": False,
                "release_grade_result_handles": False,
                "python_file_recompute_boundary": True,
                "native_homfly_cpp_computation_claimed": False,
                "native_alexander_cpp_computation_claimed": False,
                "production_scheduler_completion_claimed": False,
                "signed_release_artifacts_published": False,
            }
        ),
        encoding="utf-8",
    )


def _write_unsupported_invariant_result_handle_report(
    path,
    *,
    invariant: str = "homfly",
) -> None:
    status_code = f"{invariant}_native_compute_handle_missing"
    path.write_text(
        json.dumps(
            {
                "method": "invariant_result_handle_report",
                "backend": "rust",
                "abi_version": 19,
                "result_handle_abi": "opaque_invariant_result_handle_v1",
                "report_transport_abi": "owned_string_v1",
                "handle_kind": "unsupported",
                "invariant": invariant,
                "status": "unsupported",
                "status_code": status_code,
                "blocking_status_code": status_code,
                "blocking_gate": f"{invariant}_native_compute_handle",
                "gate_status": "missing",
                "native_compute_handle_available": False,
                "native_computation_claimed": False,
                "result_available": False,
                "homfly_report_json": False,
                "alexander_report_json": False,
                "python_file_recompute_boundary": True,
                "current_boundary": "python_file_recompute",
                "host_action": "use_python_file_recompute_boundary",
                "handle_create_symbol": (
                    "iroll_invariant_result_handle_create_unsupported"
                ),
                "handle_report_symbol": (
                    "iroll_invariant_result_handle_report_json"
                ),
                "handle_free_symbol": "iroll_invariant_result_handle_free",
                "owned_string_free_symbol": "iroll_kernel_owned_string_free",
                "claim_scope": "unsupported_lifecycle_probe_only",
                "complete_result_handle_abi": False,
                "release_grade_result_handles": False,
            }
        ),
        encoding="utf-8",
    )


def _write_imgui_windows_retained_artifacts_manifest_report(path) -> None:
    evidence_groups = [
        {
            "name": "test_stub_framebuffer",
            "classification": "complete_raw_analysis_host",
            "uploaded_artifact": "iroll-imgui-test-stub-framebuffer-smoke-Windows",
            "raw_files": ["iroll-imgui-test-stub-framebuffer-smoke.json"],
            "analysis_files": [
                "iroll-imgui-test-stub-framebuffer-smoke-imgui-analysis.json"
            ],
            "host_files": ["iroll-imgui-test-stub-framebuffer-smoke-imgui-host.json"],
            "claim_scope": "repository_imgui_test_stub_draw_list_framebuffer_estimate",
            "non_claims": [
                "real_graphics_backend_framebuffer_verified=false",
                "screenshot_verified=false",
                "production_renderer_verified=false",
            ],
        },
        {
            "name": "source_open_request",
            "classification": "complete_raw_analysis_host",
            "uploaded_artifact": "iroll-imgui-test-stub-framebuffer-smoke-Windows",
            "raw_files": ["iroll-imgui-source-open-request-smoke.json"],
            "analysis_files": [
                "iroll-imgui-source-open-request-smoke-imgui-analysis.json"
            ],
            "host_files": ["iroll-imgui-source-open-request-smoke-imgui-host.json"],
            "claim_scope": "host_polled_source_open_request_contract",
            "non_claims": [
                "opened_by_real_host=false",
                "not production platform URL-opening evidence",
            ],
        },
        {
            "name": "signed_pd_recompute_scheduler",
            "classification": "complete_raw_analysis_host",
            "uploaded_artifact": "iroll-imgui-signed-pd-json-Windows",
            "raw_files": ["iroll-imgui-signed-pd-recompute-scheduler-smoke.json"],
            "analysis_files": [
                "iroll-imgui-signed-pd-recompute-scheduler-smoke-imgui-analysis.json"
            ],
            "host_files": [
                "iroll-imgui-signed-pd-recompute-scheduler-smoke-imgui-host.json"
            ],
            "claim_scope": "host_owned_signed_pd_recompute_scheduler_contract",
            "non_claims": [
                "not native HOMFLY/Alexander C++ computation evidence",
                "production_scheduler_completion_claimed=false",
            ],
        },
        {
            "name": "signed_pd_thread_pool_recompute_scheduler",
            "classification": "complete_raw_analysis_host",
            "uploaded_artifact": "iroll-imgui-signed-pd-json-Windows",
            "raw_files": [
                "iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke.json"
            ],
            "analysis_files": [
                "iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke-imgui-analysis.json"
            ],
            "host_files": [
                "iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke-imgui-host.json"
            ],
            "claim_scope": "host_owned_thread_pool_signed_pd_recompute_scheduler_contract",
            "non_claims": [
                "not native HOMFLY/Alexander C++ computation evidence",
                "production_scheduler_completion_claimed=false",
            ],
        },
        {
            "name": "signed_pd_snapshot",
            "classification": "complete_raw_analysis_host",
            "uploaded_artifact": "iroll-imgui-signed-pd-json-Windows",
            "raw_files": ["iroll-imgui-signed-pd.json"],
            "analysis_files": ["iroll-imgui-signed-pd-imgui-analysis.json"],
            "host_files": ["iroll-imgui-signed-pd-snapshot-imgui-host.json"],
            "claim_scope": "host_exported_imgui_signed_pd_snapshot_shape",
            "non_claims": [
                "not invariant computation evidence",
                "not native HOMFLY/Alexander C++ computation evidence",
            ],
        },
        {
            "name": "signed_pd_invariant_reload",
            "classification": "invariant_status_host_only",
            "uploaded_artifact": "iroll-imgui-signed-pd-json-Windows",
            "raw_files": [
                "iroll-imgui-signed-pd.json",
                "iroll-imgui-signed-pd-homfly.json",
                "iroll-imgui-signed-pd-alexander.json",
            ],
            "invariant_status_files": ["iroll-imgui-signed-pd-invariant-status.json"],
            "host_files": ["iroll-imgui-signed-pd-imgui-host.json"],
            "claim_scope": "file_oriented_signed_pd_invariant_reload",
            "non_claims": [
                "not native HOMFLY/Alexander C++ computation evidence",
                "not signed release artifacts",
            ],
        },
        {
            "name": "real_kernel_loader_smoke",
            "classification": "complete_raw_analysis_host",
            "uploaded_artifact": "iroll-imgui-real-kernel-loader-smoke-Windows",
            "raw_files": ["iroll-imgui-real-kernel-loader-smoke.json"],
            "analysis_files": [
                "iroll-imgui-real-kernel-loader-smoke-imgui-analysis.json"
            ],
            "host_files": ["iroll-imgui-real-kernel-loader-smoke-imgui-host.json"],
            "claim_scope": "runtime_loader_real_rust_dynamic_library_contract",
            "non_claims": [
                "not native HOMFLY/Alexander C++ computation evidence",
                "not release packaging evidence",
            ],
        },
    ]
    path.write_text(
        json.dumps(
            {
                "artifact_schema_version": 1,
                "artifact_kind": "imgui_windows_retained_artifacts_manifest",
                "claim_scope": "windows_dear_imgui_retained_artifact_manifest",
                "imgui_abi_version": 117,
                "rust_c_abi_version": 19,
                "retained_json_file_count": 22,
                "evidence_group_count": 7,
                "raw_analysis_host_group_count": 6,
                "invariant_status_host_group_count": 1,
                "smoke_executed_no_retained_json_count": 0,
                "production_renderer_verified": False,
                "production_scheduler_completion_claimed": False,
                "native_homfly_cpp_computation_claimed": False,
                "native_alexander_cpp_computation_claimed": False,
                "signed_release_artifacts_published": False,
                "non_claim_evidence_index": [
                    {
                        "field": "production_renderer_verified",
                        "value": False,
                        "evidence_role": "retained_ci_artifact_only",
                    },
                    {
                        "field": "production_scheduler_completion_claimed",
                        "value": False,
                        "evidence_role": "retained_ci_artifact_only",
                    },
                    {
                        "field": "native_homfly_cpp_computation_claimed",
                        "value": False,
                        "evidence_role": "retained_ci_artifact_only",
                    },
                    {
                        "field": "native_alexander_cpp_computation_claimed",
                        "value": False,
                        "evidence_role": "retained_ci_artifact_only",
                    },
                    {
                        "field": "signed_release_artifacts_published",
                        "value": False,
                        "evidence_role": "retained_ci_artifact_only",
                    },
                ],
                "evidence_groups": evidence_groups,
            }
        ),
        encoding="utf-8",
    )


def _write_hopf_imgui_with_role_order(path) -> None:
    path.write_text(
        json.dumps(
            {
                "diagram": {
                    "name": "hopf-imgui-role-order",
                    "component_count": 2,
                    "crossings": [
                        {
                            "edge_labels": [4, 1, 2, 3],
                            "sign": 1,
                            "role_order": [1, 0, 2, 3],
                            "role_order_explicit": True,
                        },
                        {
                            "edge_labels": [2, 3, 4, 1],
                            "sign": -1,
                            "role_order": [1, 0, 2, 3],
                            "role_order_explicit": True,
                        },
                    ],
                },
                "signed_pd_revision": 42,
                "variables": ["t1", "t2"],
            }
        ),
        encoding="utf-8",
    )

def _write_hopf_imgui_without_role_order(path) -> None:
    path.write_text(
        json.dumps(
            {
                "diagram": {
                    "name": "hopf-imgui-without-role-order",
                    "component_count": 2,
                    "crossings": [
                        {"edge_labels": [4, 1, 2, 3], "sign": 1},
                        {"edge_labels": [2, 3, 4, 1], "sign": -1},
                    ],
                },
                "signed_pd_revision": 42,
                "variables": ["t1", "t2"],
            }
        ),
        encoding="utf-8",
    )

def test_cli_imgui_analysis_summary_payload_accepts_role_order_report(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "role_order_candidates_report.json"
        _write_role_order_candidates_report(path)

        exit_code = main(["imgui-analysis-summary-payload", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert payload["analysis_summary_count"] == 1
    assert payload["source_signed_pd_revision"] == 42
    summary = payload["analysis_summaries"][0]
    assert summary["name"] == "signed-PD role-order candidates"
    assert summary["source_method"] == "signed_pd_role_order_candidates_report"
    assert summary["has_source_signed_pd_revision"] is True
    assert summary["source_signed_pd_revision"] == 42
    assert summary["required_check_count"] == 16
    assert summary["passed_check_count"] == 0
    assert summary["failed_check_count"] == 16
    assert "signed_pd_revision=42" in summary["notes"]
    assert "signature_evaluated=2" in summary["notes"]
    assert "signature_resolution=partially_distinguishes_candidates" in summary["notes"]
    assert "signature_all_strict_evaluated=false" in summary["notes"]
    assert summary["role_order_signature_resolution_status"] == (
        "partially_distinguishes_candidates"
    )
    assert summary["role_order_signature_resolution_status_code"] == 5
    assert summary["role_order_signature_strict_candidate_count"] == 16
    assert summary["role_order_signature_all_strict_candidates_evaluated"] is False
    assert summary["role_order_signature_all_strict_candidates_evaluated_count"] == 0
    assert "homfly_certified=2" in summary["notes"]
    assert "alexander_gcd_certified=2" in summary["notes"]
    assert "alexander_failed_nonzero_minors=0" in summary["notes"]
    assert summary["role_order_signature_evaluated_candidate_count"] == 2
    assert payload["analysis_role_order_signature_strict_candidate_count"] == 16
    assert (
        payload["analysis_role_order_signature_all_strict_candidates_evaluated_count"]
        == 0
    )
    assert payload["analysis_role_order_signature_evaluated_candidate_count"] == 2
    assert payload[
        "analysis_role_order_signature_alexander_bounded_scanned_gcd_certified_candidate_count"
    ] == 2
    assert payload[
        "analysis_role_order_signature_alexander_complete_scanned_gcd_certified_candidate_count"
    ] == 2


def test_cli_imgui_analysis_payload_leaves_root_signed_pd_revision_unset_for_conflict(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        first_path = tmp_path / "role_order_candidates_revision_42.json"
        second_path = tmp_path / "role_order_candidates_revision_43.json"
        _write_role_order_candidates_report(first_path)
        _write_role_order_candidates_report(second_path)

        second_report = json.loads(second_path.read_text(encoding="utf-8"))
        second_report["input"]["signed_pd_revision"] = 43
        second_path.write_text(json.dumps(second_report), encoding="utf-8")

        summary_exit = main(
            ["imgui-analysis-summary-payload", str(first_path), str(second_path)]
        )
        summary_payload = json.loads(capsys.readouterr().out)

        analysis_exit = main(
            [
                "imgui-analysis-payload",
                "--analysis-report-json",
                str(first_path),
                "--analysis-report-json",
                str(second_path),
            ]
        )
        analysis_payload = json.loads(capsys.readouterr().out)

        host_exit = main(
            [
                "imgui-host-payload",
                "--analysis-report-json",
                str(first_path),
                "--analysis-report-json",
                str(second_path),
            ]
        )
        host_payload = json.loads(capsys.readouterr().out)

    assert summary_exit == 0
    assert analysis_exit == 0
    assert host_exit == 0
    assert "source_signed_pd_revision" not in summary_payload
    assert "source_signed_pd_revision" not in analysis_payload
    assert "source_signed_pd_revision" not in host_payload["analysis"]

    role_summaries = [
        summary
        for summary in analysis_payload["analysis_summaries"]
        if summary["source_method"] == "signed_pd_role_order_candidates_report"
    ]
    assert len(role_summaries) == 2
    assert {summary["source_signed_pd_revision"] for summary in role_summaries} == {
        42,
        43,
    }


def test_cli_imgui_analysis_summary_payload_accepts_core_benchmark_matrix(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "benchmark_matrix.json"
        _write_core_benchmark_matrix_report(path)

        exit_code = main(["imgui-analysis-summary-payload", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_benchmark_matrix_completed_row_count"] == 4
    assert payload["analysis_benchmark_cuda_gpu_completed_row_count"] == 2
    assert (
        payload[
            "analysis_benchmark_cuda_gpu_release_grade_speedup_claimed_count"
        ]
        == 0
    )
    summary = payload["analysis_summaries"][0]
    assert summary["source_method"] == "iroll_core_benchmark_matrix"
    assert summary["certified"] is False
    assert "gate_scope=local_gpu_benchmark_witness" in summary["notes"]
    assert "hosted_cuda_ci_claimed=false" in summary["notes"]
    assert "cuda_parity_claimed=false" in summary["notes"]


def test_cli_imgui_analysis_summary_payload_accepts_gpu_smoke_artifact(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        no_cuda_path = tmp_path / "gpu-smoke-no-cuda.json"
        failure_path = tmp_path / "gpu-smoke-simulated-parity-failure.json"
        _write_gpu_smoke_unavailable_report(no_cuda_path)
        _write_gpu_smoke_failure_report(failure_path)

        exit_code = main(
            [
                "imgui-analysis-summary-payload",
                str(no_cuda_path),
                str(failure_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert payload["analysis_summary_count"] == 2
    assert payload["analysis_accepted_summary_count"] == 1
    assert payload["analysis_failed_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 1
    assert payload["analysis_failed_check_count"] == 1
    assert payload["analysis_gpu_smoke_unavailable_boundary_count"] == 1
    assert payload["analysis_gpu_smoke_parity_failure_count"] == 1
    assert payload["analysis_gpu_smoke_no_cuda_boundary_count"] == 1
    assert payload["analysis_gpu_smoke_simulated_parity_failure_count"] == 1
    assert payload["analysis_gpu_smoke_required_capability_name_count"] == 6
    assert payload["analysis_gpu_smoke_failed_check_name_count"] == 1
    assert (
        payload[
            "analysis_gpu_smoke_release_gate_gpu_backend_unavailable_blocker_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_gpu_smoke_release_gate_cuda_runtime_not_observed_blocker_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_gpu_smoke_release_gate_required_checks_incomplete_blocker_count"
        ]
        == 2
    )
    assert (
        payload[
            "analysis_gpu_smoke_release_gate_required_checks_failed_blocker_count"
        ]
        == 1
    )
    assert (
        payload[
            "analysis_gpu_smoke_release_gate_forced_unavailable_blocker_count"
        ]
        == 0
    )
    assert (
        payload[
            "analysis_gpu_smoke_release_gate_simulated_parity_failure_blocker_count"
        ]
        == 1
    )
    assert payload["analysis_gpu_smoke_cuda_parity_claimed_count"] == 0
    assert payload["analysis_gpu_smoke_release_grade_speedup_claimed_count"] == 0
    summaries = {
        summary["source_method"]: summary
        for summary in payload["analysis_summaries"]
    }
    no_cuda = summaries["gpu_smoke_unavailable_boundary"]
    assert no_cuda["claim_scope"] == "optional_no_cuda_boundary"
    assert no_cuda["accepted"] is True
    assert no_cuda["certified"] is False
    assert no_cuda["required_check_count"] == 0
    assert no_cuda["gpu_smoke_no_cuda_boundary"] is True
    assert no_cuda["gpu_smoke_cuda_runtime_observed"] is False
    assert no_cuda["gpu_smoke_required_capability_name_count"] == 3
    assert no_cuda["gpu_smoke_required_capability_names"] == (
        "segment_segment_distance|"
        "segment_segment_distances|"
        "segment_intersections_2d"
    )
    assert (
        no_cuda[
            "gpu_smoke_release_gate_gpu_backend_unavailable_blocker_count"
        ]
        == 1
    )
    assert (
        no_cuda[
            "gpu_smoke_release_gate_required_checks_incomplete_blocker_count"
        ]
        == 1
    )
    assert "gpu_smoke_artifact=kind=gpu_smoke_unavailable_boundary" in (
        no_cuda["notes"]
    )
    assert "gpu_smoke_required_capabilities=segment_segment_distance|" in (
        no_cuda["notes"]
    )
    assert "gpu_release_gate_blocker_codes=" in no_cuda["notes"]
    assert "cuda_parity_claimed=false" in no_cuda["notes"]
    assert "release_grade_speedup_claimed=false" in no_cuda["notes"]
    assert "not CUDA parity evidence" in no_cuda["notes"]
    failure = summaries["gpu_smoke_parity_failure"]
    assert failure["claim_scope"] == "gpu_dispatch_parity_smoke"
    assert failure["accepted"] is False
    assert failure["failed_check_count"] == 1
    assert failure["gpu_smoke_failed_check_name_count"] == 1
    assert failure["gpu_smoke_failed_check_names"] == "gpu_numpy_parity"
    assert failure["gpu_smoke_simulated_parity_failure"] is True
    assert (
        failure[
            "gpu_smoke_release_gate_required_checks_incomplete_blocker_count"
        ]
        == 1
    )
    assert (
        failure[
            "gpu_smoke_release_gate_required_checks_failed_blocker_count"
        ]
        == 1
    )
    assert (
        failure[
            "gpu_smoke_release_gate_simulated_parity_failure_blocker_count"
        ]
        == 1
    )
    assert "simulated_parity_failure" in failure["notes"]
    assert "gpu_smoke_failed_check_names=gpu_numpy_parity" in failure["notes"]
    assert "not CUDA parity evidence" in failure["notes"]


def test_cli_imgui_analysis_payload_accepts_imgui_framebuffer_smoke_artifact(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "iroll-imgui-test-stub-framebuffer-smoke.json"
        _write_imgui_framebuffer_smoke_report(path)

        summary_exit = main(["imgui-analysis-summary-payload", str(path)])
        summary_payload = json.loads(capsys.readouterr().out)

        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(path)]
        )
        host_payload = json.loads(capsys.readouterr().out)

    assert summary_exit == 0
    assert summary_payload["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert summary_payload["analysis_summary_count"] == 1
    assert summary_payload["analysis_imgui_framebuffer_smoke_artifact_count"] == 1
    assert summary_payload["analysis_imgui_framebuffer_smoke_passed_count"] == 1
    assert (
        summary_payload[
            "analysis_imgui_framebuffer_smoke_real_backend_verified_count"
        ]
        == 0
    )
    assert (
        summary_payload[
            "analysis_imgui_framebuffer_smoke_screenshot_verified_count"
        ]
        == 0
    )
    assert (
        summary_payload[
            "analysis_imgui_framebuffer_smoke_estimated_nonzero_pixel_count"
        ]
        == 4096
    )
    summary = summary_payload["analysis_summaries"][0]
    assert summary["source_method"] == "imgui_test_stub_framebuffer_smoke"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 3
    assert summary["passed_check_count"] == 3
    assert summary["imgui_framebuffer_smoke_real_backend_verified"] is False
    assert summary["imgui_framebuffer_smoke_screenshot_verified"] is False
    assert "repository_test_stub=true" in summary["notes"]
    assert "production_renderer_verified=false" in summary["notes"]
    assert "not production renderer screenshot/framebuffer evidence" in (
        summary["notes"]
    )

    assert host_exit == 0
    assert host_payload["method"] == "imgui_host_payload"
    host_analysis = host_payload["analysis"]
    assert host_analysis["analysis_summary_count"] == 3
    assert host_analysis["analysis_imgui_framebuffer_smoke_artifact_count"] == 1
    assert host_analysis["analysis_imgui_framebuffer_smoke_passed_count"] == 1
    assert (
        host_analysis[
            "analysis_imgui_framebuffer_smoke_real_backend_verified_count"
        ]
        == 0
    )
    assert (
        host_analysis[
            "analysis_imgui_framebuffer_smoke_screenshot_verified_count"
        ]
        == 0
    )
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    host_summary = host_summaries["imgui_test_stub_framebuffer_smoke"]
    assert host_summary["imgui_framebuffer_smoke_text_count"] == 10
    assert host_summary["imgui_framebuffer_smoke_framebuffer_touched"] is True


def test_cli_imgui_analysis_payload_accepts_production_framebuffer_pack(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "iroll-imgui-production-framebuffer-pack.json"
        _write_imgui_production_framebuffer_pack(path)

        summary_exit = main(["imgui-analysis-summary-payload", str(path)])
        summary_payload = json.loads(capsys.readouterr().out)

        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(path)]
        )
        host_payload = json.loads(capsys.readouterr().out)

    assert summary_exit == 0
    assert summary_payload["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert summary_payload["analysis_summary_count"] == 1
    assert summary_payload["analysis_imgui_framebuffer_smoke_artifact_count"] == 1
    assert (
        summary_payload[
            "analysis_imgui_framebuffer_smoke_real_backend_verified_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_framebuffer_smoke_screenshot_verified_count"
        ]
        == 1
    )
    assert summary_payload["analysis_certification_certified_count"] == 1
    summary = summary_payload["analysis_summaries"][0]
    assert summary["source_method"] == "imgui_production_renderer_framebuffer_pack"
    assert summary["accepted"] is True
    assert summary["certified"] is True
    assert summary["required_check_count"] == 5
    assert summary["passed_check_count"] == 5
    assert summary["imgui_framebuffer_smoke_real_backend_verified"] is True
    assert summary["imgui_framebuffer_smoke_screenshot_verified"] is True
    assert "repository_test_stub=false" in summary["notes"]
    assert "production_renderer_verified=true" in summary["notes"]

    assert host_exit == 0
    host_analysis = host_payload["analysis"]
    assert (
        host_analysis[
            "analysis_imgui_framebuffer_smoke_real_backend_verified_count"
        ]
        == 1
    )
    assert host_analysis["analysis_certification_certified_count"] >= 1
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    host_summary = host_summaries["imgui_production_renderer_framebuffer_pack"]
    assert host_summary["imgui_framebuffer_smoke_text_count"] == 10
    assert host_summary["certified"] is True


def test_cli_imgui_analysis_payload_accepts_imgui_source_open_request_smoke_artifact(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "iroll-imgui-source-open-request-smoke.json"
        _write_imgui_source_open_request_smoke_report(path)

        summary_exit = main(["imgui-analysis-summary-payload", str(path)])
        summary_payload = json.loads(capsys.readouterr().out)

        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(path)]
        )
        host_payload = json.loads(capsys.readouterr().out)

    assert summary_exit == 0
    assert summary_payload["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert summary_payload["analysis_summary_count"] == 1
    assert (
        summary_payload["analysis_imgui_source_open_request_smoke_artifact_count"]
        == 1
    )
    assert (
        summary_payload["analysis_imgui_source_open_request_smoke_passed_count"]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_source_open_request_smoke_opened_by_real_host_count"
        ]
        == 0
    )
    assert (
        summary_payload[
            "analysis_imgui_source_open_request_smoke_scheme_allowed_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_source_open_request_smoke_request_consumed_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_source_open_request_smoke_request_cleared_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_source_open_request_smoke_final_pending_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_source_open_request_smoke_source_url_length_total"
        ]
        == 27
    )
    summary = summary_payload["analysis_summaries"][0]
    assert summary["source_method"] == "imgui_source_open_request_smoke"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 4
    assert summary["passed_check_count"] == 4
    assert summary["imgui_source_open_request_smoke_opened_by_real_host"] is False
    assert summary["imgui_source_open_request_smoke_scheme_allowed"] is True
    assert summary["imgui_source_open_request_smoke_request_consumed"] is True
    assert (
        summary["imgui_source_open_request_smoke_host_action"]
        == "open_source_url"
    )
    assert summary["imgui_source_open_request_smoke_selected_fixture_name"] == "3_1"
    assert (
        summary["imgui_source_open_request_smoke_selected_fixture_source"]
        == "Knot Atlas"
    )
    assert (
        summary["imgui_source_open_request_smoke_source_url"]
        == "https://katlas.org/wiki/3_1"
    )
    assert (
        summary["imgui_source_open_request_smoke_consumed_source_url"]
        == "https://katlas.org/wiki/3_1"
    )
    assert (
        summary["imgui_source_open_request_smoke_consumed_source_url_matched"]
        is True
    )
    assert summary["imgui_source_open_request_smoke_request_cleared"] is True
    assert summary["imgui_source_open_request_smoke_final_pending"] is True
    assert (
        summary["imgui_source_open_request_smoke_source_url_length_total"]
        == 27
    )
    assert "host_action=open_source_url" in summary["notes"]
    assert "opened_by_real_host=false" in summary["notes"]
    assert "not production platform URL-opening evidence" in summary["notes"]

    assert host_exit == 0
    assert host_payload["method"] == "imgui_host_payload"
    host_analysis = host_payload["analysis"]
    assert host_analysis["analysis_summary_count"] == 3
    assert (
        host_analysis["analysis_imgui_source_open_request_smoke_artifact_count"]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_source_open_request_smoke_opened_by_real_host_count"
        ]
        == 0
    )
    assert (
        host_analysis[
            "analysis_imgui_source_open_request_smoke_request_cleared_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_source_open_request_smoke_final_pending_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_source_open_request_smoke_source_url_length_total"
        ]
        == 27
    )
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    host_summary = host_summaries["imgui_source_open_request_smoke"]
    assert host_summary["imgui_source_open_request_smoke_scheme_allowed"] is True
    assert host_summary["imgui_source_open_request_smoke_request_cleared"] is True
    assert host_summary["imgui_source_open_request_smoke_final_pending"] is True
    assert (
        host_summary["imgui_source_open_request_smoke_source_url_length_total"]
        == 27
    )
    assert (
        host_summary["imgui_source_open_request_smoke_host_action"]
        == "open_source_url"
    )
    assert (
        host_summary["imgui_source_open_request_smoke_selected_fixture_name"]
        == "3_1"
    )
    assert (
        host_summary["imgui_source_open_request_smoke_source_url"]
        == "https://katlas.org/wiki/3_1"
    )
    assert (
        host_summary["imgui_source_open_request_smoke_consumed_source_url_matched"]
        is True
    )


def test_cli_imgui_analysis_payload_accepts_imgui_signed_pd_snapshot_artifact(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "iroll-imgui-signed-pd.json"
        _write_imgui_signed_pd_snapshot_report(path)

        summary_exit = main(["imgui-analysis-summary-payload", str(path)])
        summary_payload = json.loads(capsys.readouterr().out)

        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(path)]
        )
        host_payload = json.loads(capsys.readouterr().out)

    assert summary_exit == 0
    assert summary_payload["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert summary_payload["analysis_summary_count"] == 1
    assert summary_payload["analysis_imgui_signed_pd_snapshot_artifact_count"] == 1
    assert summary_payload["analysis_imgui_signed_pd_snapshot_valid_count"] == 1
    assert (
        summary_payload[
            "analysis_imgui_signed_pd_snapshot_component_count_matches_count"
        ]
        == 1
    )
    assert (
        summary_payload["analysis_imgui_signed_pd_snapshot_crossing_count_total"]
        == 2
    )
    assert (
        summary_payload[
            "analysis_imgui_signed_pd_snapshot_explicit_role_order_count_total"
        ]
        == 2
    )
    assert summary_payload["source_signed_pd_revision"] == 42
    summary = summary_payload["analysis_summaries"][0]
    assert summary["source_method"] == "imgui_signed_pd_snapshot"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 6
    assert summary["passed_check_count"] == 6
    assert summary["imgui_signed_pd_snapshot_valid"] is True
    assert summary["imgui_signed_pd_snapshot_component_count_matches"] is True
    assert "component_count_matches=true" in summary["notes"]
    assert "not invariant computation evidence" in summary["notes"]

    assert host_exit == 0
    assert host_payload["method"] == "imgui_host_payload"
    host_analysis = host_payload["analysis"]
    assert host_analysis["analysis_summary_count"] == 3
    assert host_analysis["analysis_imgui_signed_pd_snapshot_artifact_count"] == 1
    assert host_analysis["analysis_imgui_signed_pd_snapshot_valid_count"] == 1
    assert (
        host_analysis["analysis_imgui_signed_pd_snapshot_crossing_count_total"]
        == 2
    )
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    host_summary = host_summaries["imgui_signed_pd_snapshot"]
    assert host_summary["imgui_signed_pd_snapshot_revision_present"] is True


def test_cli_imgui_analysis_payload_accepts_imgui_signed_pd_recompute_scheduler_smoke_artifact(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "iroll-imgui-signed-pd-recompute-scheduler-smoke.json"
        _write_imgui_signed_pd_recompute_scheduler_smoke_report(path)
        report = json.loads(path.read_text(encoding="utf-8"))
        report["final_signed_pd_invariant_status_stale"] = 0
        report["final_requested_recompute_stale"] = 0
        path.write_text(json.dumps(report), encoding="utf-8")

        summary_exit = main(["imgui-analysis-summary-payload", str(path)])
        summary_payload = json.loads(capsys.readouterr().out)

        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(path)]
        )
        host_payload = json.loads(capsys.readouterr().out)

    assert summary_exit == 0
    assert summary_payload["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert summary_payload["analysis_summary_count"] == 1
    assert (
        summary_payload[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_artifact_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_passed_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_stale_recompute_rejected_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_current_revision_reloaded_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_first_result_count_total"
        ]
        == 2
    )
    assert (
        summary_payload[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_snapshot_json_length_total"
        ]
        == 363
    )
    summary = summary_payload["analysis_summaries"][0]
    assert summary["source_method"] == "imgui_signed_pd_recompute_scheduler_smoke"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 11
    assert summary["passed_check_count"] == 11
    assert (
        summary["imgui_signed_pd_recompute_scheduler_smoke_stale_recompute_rejected"]
        is True
    )
    assert (
        summary["imgui_signed_pd_recompute_scheduler_smoke_final_status_fresh"]
        is True
    )
    assert summary["imgui_signed_pd_recompute_scheduler_smoke_first_scope"] == "all"
    assert (
        summary["imgui_signed_pd_recompute_scheduler_smoke_current_scope"]
        == "homfly"
    )
    assert (
        summary[
            "imgui_signed_pd_recompute_scheduler_smoke_handoff_input_format"
        ]
        == "imgui_signed_pd_json"
    )
    assert (
        summary["imgui_signed_pd_recompute_scheduler_smoke_host_reload_payload"]
        == "imgui-signed-pd-invariant-status-payload"
    )
    assert summary["imgui_signed_pd_recompute_scheduler_smoke_first_revision"] == 1
    assert (
        summary[
            "imgui_signed_pd_recompute_scheduler_smoke_current_request_revision"
        ]
        == 2
    )
    assert "handoff_input_format=imgui_signed_pd_json" in summary["notes"]
    assert "not native HOMFLY/Alexander C++ computation evidence" in (
        summary["notes"]
    )

    assert host_exit == 0
    assert host_payload["method"] == "imgui_host_payload"
    host_analysis = host_payload["analysis"]
    assert host_analysis["analysis_summary_count"] == 3
    assert (
        host_analysis[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_artifact_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_signed_pd_recompute_scheduler_smoke_current_result_count_total"
        ]
        == 1
    )
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    host_summary = host_summaries["imgui_signed_pd_recompute_scheduler_smoke"]
    assert (
        host_summary[
            "imgui_signed_pd_recompute_scheduler_smoke_requested_snapshot_cleared"
        ]
        is True
    )
    assert (
        host_summary["imgui_signed_pd_recompute_scheduler_smoke_current_scope"]
        == "homfly"
    )


def test_cli_imgui_analysis_payload_accepts_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = (
            tmp_path
            / "iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke.json"
        )
        _write_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_report(path)

        summary_exit = main(["imgui-analysis-summary-payload", str(path)])
        summary_payload = json.loads(capsys.readouterr().out)

        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(path)]
        )
        host_payload = json.loads(capsys.readouterr().out)

    assert summary_exit == 0
    assert summary_payload["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert summary_payload["analysis_summary_count"] == 1
    assert (
        summary_payload[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_passed_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_handoff_complete_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_worker_count_total"
        ]
        == 2
    )
    summary = summary_payload["analysis_summaries"][0]
    assert summary["source_method"] == (
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke"
    )
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 16
    assert summary["passed_check_count"] == 16
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_recompute_rejected"
        ]
        is True
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_progress_completed"
        ]
        is True
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_request_scope"
        ]
        == "alexander"
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_handoff_input_format"
        ]
        == "imgui_signed_pd_json"
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_host_reload_payload"
        ]
        == "imgui-signed-pd-invariant-status-payload"
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_loaded_revision"
        ]
        == 2
    )
    assert (
        summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_request_revision"
        ]
        == 2
    )
    assert "thread_pool_worker_count=2" in summary["notes"]
    assert "handoff_input_format=imgui_signed_pd_json" in summary["notes"]
    assert "not native HOMFLY/Alexander C++ computation evidence" in (
        summary["notes"]
    )

    assert host_exit == 0
    assert host_payload["method"] == "imgui_host_payload"
    host_analysis = host_payload["analysis"]
    assert host_analysis["analysis_summary_count"] == 3
    assert (
        host_analysis[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_result_count_total"
        ]
        == 1
    )
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    host_summary = host_summaries[
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke"
    ]
    assert (
        host_summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_requested_snapshot_cleared"
        ]
        is True
    )
    assert (
        host_summary[
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_scope"
        ]
        == "alexander"
    )


def test_cli_imgui_analysis_payload_accepts_imgui_windows_retained_artifacts_manifest(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "iroll-imgui-windows-retained-artifacts-manifest.json"
        _write_imgui_windows_retained_artifacts_manifest_report(path)

        summary_exit = main(["imgui-analysis-summary-payload", str(path)])
        summary_payload = json.loads(capsys.readouterr().out)

        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(path)]
        )
        host_payload = json.loads(capsys.readouterr().out)

    assert summary_exit == 0
    assert summary_payload["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert summary_payload["analysis_summary_count"] == 1
    assert (
        summary_payload[
            "analysis_imgui_windows_retained_artifacts_manifest_artifact_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_count_total"
        ]
        == 22
    )
    assert (
        summary_payload[
            "analysis_imgui_windows_retained_artifacts_manifest_unique_retained_json_file_count_total"
        ]
        == 22
    )
    assert (
        summary_payload[
            "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_reference_count_total"
        ]
        == 23
    )
    assert (
        summary_payload[
            "analysis_imgui_windows_retained_artifacts_manifest_shared_retained_json_file_count_total"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_count_matched_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_windows_retained_artifacts_manifest_complete_raw_analysis_host_group_count_total"
        ]
        == 6
    )
    assert (
        summary_payload[
            "analysis_imgui_windows_retained_artifacts_manifest_non_claim_false_count"
        ]
        == 5
    )
    assert (
        summary_payload[
            "analysis_imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 5
    )
    summary = summary_payload["analysis_summaries"][0]
    assert summary["source_method"] == "imgui_windows_retained_artifacts_manifest"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 9
    assert summary["passed_check_count"] == 9
    assert summary["imgui_windows_retained_artifacts_manifest_abi_matched"] is True
    assert (
        summary["imgui_windows_retained_artifacts_manifest_non_claims_preserved"]
        is True
    )
    assert "retained_json_files=22" in summary["notes"]
    assert "retained_json_file_references=23" in summary["notes"]
    assert "unique_retained_json_files=22" in summary["notes"]
    assert "shared_retained_json_files=1" in summary["notes"]
    assert (
        "imgui_windows_retained_artifacts_manifest_shared_files="
        "iroll-imgui-signed-pd.json"
    ) in summary["notes"]
    assert "retained_json_file_count_matched=true" in summary["notes"]
    assert "non_claim_evidence_index_entries=5" in summary["notes"]
    assert "not release completion evidence" in summary["notes"]

    assert host_exit == 0
    assert host_payload["method"] == "imgui_host_payload"
    host_analysis = host_payload["analysis"]
    assert host_analysis["analysis_summary_count"] == 3
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_artifact_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_retained_json_file_reference_count_total"
        ]
        == 23
    )
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_shared_retained_json_file_count_total"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_complete_raw_analysis_host_group_count_total"
        ]
        == 6
    )
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_invariant_status_host_group_count_total"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_smoke_executed_no_retained_json_count_total"
        ]
        == 0
    )
    assert (
        host_analysis[
            "analysis_imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 5
    )
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    host_summary = host_summaries["imgui_windows_retained_artifacts_manifest"]
    assert host_summary[
        "imgui_windows_retained_artifacts_manifest_non_claims_preserved"
    ] is True
    assert (
        host_summary[
            "imgui_windows_retained_artifacts_manifest_retained_json_file_count_matched_count"
        ]
        == 1
    )
    assert "shared_retained_json_files=1" in host_summary["notes"]
    assert (
        "imgui_windows_retained_artifacts_manifest_shared_files="
        "iroll-imgui-signed-pd.json"
    ) in host_summary["notes"]
    assert "complete_raw_analysis_host_groups=6" in host_summary["notes"]
    assert "non_claim_evidence_index_entries=5" in host_summary["notes"]


def test_cli_windows_retained_manifest_preserves_non_validate_table_group_file_sets(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "iroll-imgui-windows-retained-artifacts-manifest.json"
        _write_imgui_windows_retained_artifacts_manifest_report(path)

        summary_exit = main(["imgui-analysis-summary-payload", str(path)])
        summary_payload = json.loads(capsys.readouterr().out)
        manifest = json.loads(path.read_text(encoding="utf-8"))

    assert summary_exit == 0
    assert manifest["evidence_group_count"] == 7
    assert manifest["production_scheduler_completion_claimed"] is False
    assert manifest["native_homfly_cpp_computation_claimed"] is False
    assert manifest["native_alexander_cpp_computation_claimed"] is False
    assert len(manifest["non_claim_evidence_index"]) == 5
    assert all(
        item["value"] is False for item in manifest["non_claim_evidence_index"]
    )

    groups = {group["name"]: group for group in manifest["evidence_groups"]}
    expected_groups = {
        "source_open_request": {
            "raw_files": ["iroll-imgui-source-open-request-smoke.json"],
            "analysis_files": [
                "iroll-imgui-source-open-request-smoke-imgui-analysis.json"
            ],
            "host_files": ["iroll-imgui-source-open-request-smoke-imgui-host.json"],
        },
        "signed_pd_recompute_scheduler": {
            "raw_files": ["iroll-imgui-signed-pd-recompute-scheduler-smoke.json"],
            "analysis_files": [
                "iroll-imgui-signed-pd-recompute-scheduler-smoke-imgui-analysis.json"
            ],
            "host_files": [
                "iroll-imgui-signed-pd-recompute-scheduler-smoke-imgui-host.json"
            ],
        },
        "signed_pd_thread_pool_recompute_scheduler": {
            "raw_files": [
                "iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke.json"
            ],
            "analysis_files": [
                "iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke-imgui-analysis.json"
            ],
            "host_files": [
                "iroll-imgui-signed-pd-thread-pool-recompute-scheduler-smoke-imgui-host.json"
            ],
        },
        "real_kernel_loader_smoke": {
            "raw_files": ["iroll-imgui-real-kernel-loader-smoke.json"],
            "analysis_files": [
                "iroll-imgui-real-kernel-loader-smoke-imgui-analysis.json"
            ],
            "host_files": ["iroll-imgui-real-kernel-loader-smoke-imgui-host.json"],
        },
    }
    assert set(expected_groups).issubset(groups)
    for name, expected in expected_groups.items():
        group = groups[name]
        assert group["classification"] == "complete_raw_analysis_host"
        assert group["raw_files"] == expected["raw_files"]
        assert group["analysis_files"] == expected["analysis_files"]
        assert group["host_files"] == expected["host_files"]

    raw_files = [
        raw_file
        for group in manifest["evidence_groups"]
        for raw_file in group.get("raw_files", [])
    ]
    duplicated_raw_files = sorted(
        {
            raw_file
            for raw_file in raw_files
            if raw_files.count(raw_file) > 1
        }
    )
    assert duplicated_raw_files == ["iroll-imgui-signed-pd.json"]

    assert (
        summary_payload[
            "analysis_imgui_windows_retained_artifacts_manifest_unique_retained_json_file_count_total"
        ]
        == 22
    )
    assert (
        summary_payload[
            "analysis_imgui_windows_retained_artifacts_manifest_shared_retained_json_file_count_total"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 5
    )
    summary = summary_payload["analysis_summaries"][0]
    assert (
        "imgui_windows_retained_artifacts_manifest_shared_files="
        "iroll-imgui-signed-pd.json"
    ) in summary["notes"]


def test_cli_imgui_analysis_payload_accepts_imgui_real_kernel_loader_smoke_artifact(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "iroll-imgui-real-kernel-loader-smoke.json"
        _write_imgui_real_kernel_loader_smoke_report(path)

        summary_exit = main(["imgui-analysis-summary-payload", str(path)])
        summary_payload = json.loads(capsys.readouterr().out)

        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(path)]
        )
        host_payload = json.loads(capsys.readouterr().out)

    assert summary_exit == 0
    assert summary_payload["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert summary_payload["analysis_summary_count"] == 1
    assert summary_payload["analysis_imgui_real_kernel_loader_smoke_artifact_count"] == 1
    assert summary_payload["analysis_imgui_real_kernel_loader_smoke_passed_count"] == 1
    assert (
        summary_payload[
            "analysis_imgui_real_kernel_loader_smoke_dynamic_library_loaded_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_real_kernel_loader_smoke_callback_thread_pool_completed_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_imgui_real_kernel_loader_smoke_backend_report_byte_count_total"
        ]
        == 4096
    )
    assert (
        summary_payload[
            "analysis_imgui_real_kernel_loader_smoke_invariant_handles_report_byte_count_total"
        ]
        == 2048
    )
    assert (
        summary_payload[
            "analysis_imgui_real_kernel_loader_smoke_required_metadata_field_count_total"
        ]
        == 30
    )
    assert (
        summary_payload[
            "analysis_imgui_real_kernel_loader_smoke_native_homfly_cpp_computation_claimed_count"
        ]
        == 0
    )
    assert (
        summary_payload[
            "analysis_imgui_real_kernel_loader_smoke_non_claim_false_count"
        ]
        == 5
    )
    summary = summary_payload["analysis_summaries"][0]
    assert summary["source_method"] == "imgui_real_kernel_loader_smoke"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 11
    assert summary["passed_check_count"] == 11
    assert summary["imgui_real_kernel_loader_smoke_passed"] is True
    assert summary["imgui_real_kernel_loader_smoke_dynamic_library_loaded"] is True
    assert (
        summary["imgui_real_kernel_loader_smoke_callback_thread_pool_completed"]
        is True
    )
    assert summary["imgui_real_kernel_loader_smoke_non_claims_preserved"] is True
    assert summary["imgui_real_kernel_loader_smoke_metadata_schema_version"] == 1
    assert (
        summary["imgui_real_kernel_loader_smoke_metadata_contract_version"]
        == "rust_c_abi_19_invariant_result_handles_lifecycle_metadata_v1"
    )
    assert (
        summary["imgui_real_kernel_loader_smoke_required_metadata_fields_present"]
        is True
    )
    assert (
        summary["imgui_real_kernel_loader_smoke_readiness_provenance_present"]
        is True
    )
    assert (
        summary["imgui_real_kernel_loader_smoke_ready_for_native_result_handles"]
        is False
    )
    assert (
        summary[
            "imgui_real_kernel_loader_smoke_readiness_blocked_by_required_gates"
        ]
        is True
    )
    assert (
        summary["imgui_real_kernel_loader_smoke_python_file_recompute_boundary"]
        is True
    )
    assert "dynamic_library_loaded=true" in summary["notes"]
    assert "thread_pool_completed=true" in summary["notes"]
    assert "native_homfly_cpp_computation_claimed=false" in summary["notes"]
    assert "not native HOMFLY/Alexander C++ computation" in summary["notes"]

    assert host_exit == 0
    assert host_payload["method"] == "imgui_host_payload"
    host_analysis = host_payload["analysis"]
    assert host_analysis["analysis_summary_count"] == 3
    assert host_analysis["analysis_imgui_real_kernel_loader_smoke_artifact_count"] == 1
    assert (
        host_analysis[
            "analysis_imgui_real_kernel_loader_smoke_backend_report_byte_count_total"
        ]
        == 4096
    )
    assert (
        host_analysis[
            "analysis_imgui_real_kernel_loader_smoke_non_claim_false_count"
        ]
        == 5
    )
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    host_summary = host_summaries["imgui_real_kernel_loader_smoke"]
    assert host_summary["imgui_real_kernel_loader_smoke_non_claims_preserved"] is True
    assert (
        host_summary[
            "imgui_real_kernel_loader_smoke_callback_thread_pool_completed"
        ]
        is True
    )
    assert (
        host_summary["imgui_real_kernel_loader_smoke_metadata_contract_version"]
        == "rust_c_abi_19_invariant_result_handles_lifecycle_metadata_v1"
    )
    assert (
        host_summary[
            "imgui_real_kernel_loader_smoke_ready_for_native_result_handles"
        ]
        is False
    )
    assert (
        host_summary[
            "imgui_real_kernel_loader_smoke_readiness_blocked_by_required_gates"
        ]
        is True
    )


def test_cli_imgui_analysis_payload_accepts_rust_wheel_retained_manifest(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "rust-wheel-retained-manifest.json"
        path.write_text(
            json.dumps(
                {
                    "artifact_schema_version": 1,
                    "artifact_kind": "rust_wheel_retained_metadata_manifest",
                    "claim_scope": "unsigned_ci_rust_wheel_artifact_index",
                    "runner_os": "Windows",
                    "github_matrix_os": "windows-latest",
                    "rust_c_abi_version": 19,
                    "wheel_directory": "native/iroll-kernels-rust/target/wheels",
                    "wheel_count": 1,
                    "wheel_files": [
                        "iroll_kernels_rust-0.1.0-cp313-cp313-win_amd64.whl"
                    ],
                    "wheel_artifact_name": (
                        "iroll-kernels-rust-wheel-windows-latest"
                    ),
                    "unsigned_ci_artifact": True,
                    "signed_release_artifacts_published": False,
                    "publication_claimed": False,
                    "platform_index_publication_claimed": False,
                    "release_grade_speedup_claimed": False,
                    "native_homfly_cpp_computation_claimed": False,
                    "native_alexander_cpp_computation_claimed": False,
                    "non_claim_evidence_index": [
                        {
                            "field": "signed_release_artifacts_published",
                            "value": False,
                            "evidence_role": "retained_ci_artifact_only",
                        },
                        {
                            "field": "publication_claimed",
                            "value": False,
                            "evidence_role": "retained_ci_artifact_only",
                        },
                        {
                            "field": "platform_index_publication_claimed",
                            "value": False,
                            "evidence_role": "retained_ci_artifact_only",
                        },
                        {
                            "field": "release_grade_speedup_claimed",
                            "value": False,
                            "evidence_role": "retained_ci_artifact_only",
                        },
                        {
                            "field": "native_homfly_cpp_computation_claimed",
                            "value": False,
                            "evidence_role": "retained_ci_artifact_only",
                        },
                        {
                            "field": "native_alexander_cpp_computation_claimed",
                            "value": False,
                            "evidence_role": "retained_ci_artifact_only",
                        },
                    ],
                    "release_non_claim_flags": [
                        "signed_release_artifacts_published",
                        "publication_claimed",
                        "platform_index_publication_claimed",
                        "release_grade_speedup_claimed",
                        "native_homfly_cpp_computation_claimed",
                        "native_alexander_cpp_computation_claimed",
                    ],
                    "release_non_claim_flag_count": 6,
                    "release_non_claim_false_count": 6,
                    "release_non_claim_all_false": True,
                    "release_non_claim_consistency": {
                        "claim_scope": (
                            "rust_wheel_retained_manifest_release_non_claim_consistency"
                        ),
                        "flag_count": 6,
                        "false_count": 6,
                        "all_false": True,
                        "flags": [
                            "signed_release_artifacts_published",
                            "publication_claimed",
                            "platform_index_publication_claimed",
                            "release_grade_speedup_claimed",
                            "native_homfly_cpp_computation_claimed",
                            "native_alexander_cpp_computation_claimed",
                        ],
                    },
                }
            ),
            encoding="utf-8",
        )

        summary_exit = main(["imgui-analysis-summary-payload", str(path)])
        summary_payload = json.loads(capsys.readouterr().out)

        host_exit = main(
            ["imgui-host-payload", "--analysis-report-json", str(path)]
        )
        host_payload = json.loads(capsys.readouterr().out)

    assert summary_exit == 0
    assert summary_payload["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert summary_payload["analysis_summary_count"] == 1
    assert summary_payload["analysis_rust_wheel_retained_manifest_artifact_count"] == 1
    assert summary_payload["analysis_rust_wheel_retained_manifest_abi_matched_count"] == 1
    assert (
        summary_payload[
            "analysis_rust_wheel_retained_manifest_wheel_count_total"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_rust_wheel_retained_manifest_wheel_file_count_total"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_rust_wheel_retained_manifest_wheel_count_matched_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_rust_wheel_retained_manifest_unsigned_ci_artifact_count"
        ]
        == 1
    )
    assert (
        summary_payload[
            "analysis_rust_wheel_retained_manifest_non_claim_false_count"
        ]
        == 6
    )
    assert (
        summary_payload[
            "analysis_rust_wheel_retained_manifest_signed_release_artifacts_published_count"
        ]
        == 0
    )
    assert (
        summary_payload[
            "analysis_rust_wheel_retained_manifest_publication_claimed_count"
        ]
        == 0
    )
    assert (
        summary_payload[
            "analysis_rust_wheel_retained_manifest_platform_index_publication_claimed_count"
        ]
        == 0
    )
    assert (
        summary_payload[
            "analysis_rust_wheel_retained_manifest_release_grade_speedup_claimed_count"
        ]
        == 0
    )
    assert (
        summary_payload[
            "analysis_rust_wheel_retained_manifest_native_homfly_cpp_computation_claimed_count"
        ]
        == 0
    )
    assert (
        summary_payload[
            "analysis_rust_wheel_retained_manifest_native_alexander_cpp_computation_claimed_count"
        ]
        == 0
    )
    assert (
        summary_payload[
            "analysis_rust_wheel_retained_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 6
    )
    summary = summary_payload["analysis_summaries"][0]
    assert summary["source_method"] == "rust_wheel_retained_metadata_manifest"
    assert summary["claim_scope"] == "unsigned_ci_rust_wheel_artifact_index"
    assert summary["accepted"] is True
    assert summary["certified"] is False
    assert summary["required_check_count"] == 6
    assert summary["passed_check_count"] == 6
    assert summary["rust_wheel_retained_manifest_abi_matched"] is True
    assert summary["rust_wheel_retained_manifest_wheel_count_matched"] is True
    assert summary["rust_wheel_retained_manifest_unsigned_ci_artifact_count"] == 1
    assert summary["rust_wheel_retained_manifest_non_claims_preserved"] is True
    assert "wheel_count_matched=true" in summary["notes"]
    assert "rust_c_abi_matched=true" in summary["notes"]
    assert "unsigned_ci_artifact=true" in summary["notes"]
    assert "signed_release_artifacts_published=false" in summary["notes"]
    assert "publication_claimed=false" in summary["notes"]
    assert "platform_index_publication_claimed=false" in summary["notes"]
    assert "release_grade_speedup_claimed=false" in summary["notes"]
    assert "native_homfly_cpp_computation_claimed=false" in summary["notes"]
    assert "native_alexander_cpp_computation_claimed=false" in summary["notes"]
    assert (
        "release_non_claim_consistency=flags=6; false=6; all_false=true"
        in summary["notes"]
    )
    assert "non_claim_evidence_index_entries=6" in summary["notes"]
    assert "not signed release publication" in summary["notes"]

    assert host_exit == 0
    assert host_payload["method"] == "imgui_host_payload"
    host_analysis = host_payload["analysis"]
    assert host_analysis["analysis_summary_count"] == 3
    assert host_analysis["analysis_rust_wheel_retained_manifest_artifact_count"] == 1
    assert host_analysis["analysis_rust_wheel_retained_manifest_abi_matched_count"] == 1
    assert (
        host_analysis["analysis_rust_wheel_retained_manifest_wheel_count_total"]
        == 1
    )
    assert (
        host_analysis[
            "analysis_rust_wheel_retained_manifest_wheel_file_count_total"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_rust_wheel_retained_manifest_wheel_count_matched_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_rust_wheel_retained_manifest_unsigned_ci_artifact_count"
        ]
        == 1
    )
    assert (
        host_analysis[
            "analysis_rust_wheel_retained_manifest_non_claim_false_count"
        ]
        == 6
    )
    assert (
        host_analysis[
            "analysis_rust_wheel_retained_manifest_non_claim_evidence_index_entry_count_total"
        ]
        == 6
    )
    assert (
        host_analysis[
            "analysis_rust_wheel_retained_manifest_native_alexander_cpp_computation_claimed_count"
        ]
        == 0
    )
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    host_summary = host_summaries["rust_wheel_retained_metadata_manifest"]
    assert host_summary["rust_wheel_retained_manifest_abi_matched"] is True
    assert host_summary["rust_wheel_retained_manifest_wheel_count_matched"] is True
    assert (
        host_summary["rust_wheel_retained_manifest_unsigned_ci_artifact_count"]
        == 1
    )
    assert host_summary["rust_wheel_retained_manifest_non_claims_preserved"] is True
    assert "unsigned_ci_artifact=true" in host_summary["notes"]
    assert (
        "release_non_claim_consistency=flags=6; false=6; all_false=true"
        in host_summary["notes"]
    )
    assert "non_claim_evidence_index_entries=6" in host_summary["notes"]
    assert "rust_wheel_retained_metadata_manifest" not in {
        row.get("source_method")
        for row in host_payload["invariants"]["invariant_statuses"]
    }


def test_cli_imgui_invariant_status_summary_payload_accepts_unsupported_handle_report(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "unsupported-homfly-handle-report.json"
        _write_unsupported_invariant_result_handle_report(path, invariant="homfly")

        exit_code = main(["imgui-invariant-status-summary-payload", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert payload["invariant_status_count"] == 1
    assert payload["invariant_required_check_count"] == 0
    assert payload["invariant_passed_check_count"] == 0
    assert payload["invariant_failed_check_count"] == 0
    status = payload["invariant_statuses"][0]
    assert status["name"] == "HOMFLY-PT native result handle"
    assert status["value"] == "skipped"
    assert status["skipped"] is True
    assert status["required_check_count"] == 0
    assert status["passed_check_count"] == 0
    assert status["failed_check_count"] == 0
    assert "status_code=homfly_native_compute_handle_missing" in status["notes"]
    assert "blocking_gate=homfly_native_compute_handle" in status["notes"]
    assert "native_computation_claimed=false" in status["notes"]
    assert "result_available=false" in status["notes"]
    assert "current_boundary=python_file_recompute" in status["notes"]
    assert "host_action=use_python_file_recompute_boundary" in status["notes"]
    assert "claim_scope=unsupported_lifecycle_probe_only" in status["notes"]
    assert (
        "handle_report_symbol=iroll_invariant_result_handle_report_json"
        in status["notes"]
    )
    assert "native_computation_claimed=true" not in status["notes"]


def test_cli_imgui_analysis_payload_accepts_extra_core_benchmark_matrix_report(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "benchmark_matrix.json"
        _write_core_benchmark_matrix_report(path)

        exit_code = main(
            ["imgui-analysis-payload", "--analysis-report-json", str(path)]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    by_method = {
        summary["source_method"]: summary
        for summary in payload["analysis_summaries"]
    }
    assert "homfly_fixture_acceptance_report" in by_method
    assert "multivariable_alexander_fixture_acceptance_report" in by_method
    benchmark = by_method["iroll_core_benchmark_matrix"]
    assert benchmark["claim_scope"] == (
        "local_backend_benchmark_matrix_profiling_evidence"
    )
    assert benchmark["certified"] is False
    assert benchmark["benchmark_matrix_completed_row_count"] == 4
    assert benchmark["benchmark_speedup_release_grade_claimed"] is False
    assert benchmark["benchmark_cuda_gpu_completed_row_count"] == 2
    assert benchmark["benchmark_cuda_gpu_release_grade_speedup_claimed"] is False
    assert payload["analysis_benchmark_matrix_completed_row_count"] == 4
    assert (
        payload[
            "analysis_benchmark_cuda_gpu_release_grade_speedup_claimed_count"
        ]
        == 0
    )
    assert "cuda_parity_claimed=false" in benchmark["notes"]
    assert "release_grade_gpu_speedup_claimed=false" in benchmark["notes"]


def test_cli_imgui_analysis_payload_accepts_extra_gpu_smoke_artifact(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        no_cuda_path = tmp_path / "gpu-smoke-no-cuda.json"
        failure_path = tmp_path / "gpu-smoke-simulated-parity-failure.json"
        _write_gpu_smoke_unavailable_report(no_cuda_path)
        _write_gpu_smoke_failure_report(failure_path)

        exit_code = main(
            [
                "imgui-analysis-payload",
                "--analysis-report-json",
                str(no_cuda_path),
                "--analysis-report-json",
                str(failure_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert payload["analysis_gpu_smoke_unavailable_boundary_count"] == 1
    assert payload["analysis_gpu_smoke_parity_failure_count"] == 1
    assert payload["analysis_gpu_smoke_no_cuda_boundary_count"] == 1
    assert payload["analysis_gpu_smoke_simulated_parity_failure_count"] == 1
    assert payload["analysis_gpu_smoke_cuda_parity_claimed_count"] == 0
    assert payload["analysis_gpu_smoke_release_grade_speedup_claimed_count"] == 0
    summaries = {
        summary["source_method"]: summary
        for summary in payload["analysis_summaries"]
    }
    gpu_smoke = summaries["gpu_smoke_unavailable_boundary"]
    assert gpu_smoke["claim_scope"] == "optional_no_cuda_boundary"
    assert gpu_smoke["accepted"] is True
    assert gpu_smoke["certified"] is False
    assert gpu_smoke["gpu_smoke_no_cuda_boundary"] is True
    assert gpu_smoke["gpu_smoke_cuda_runtime_observed"] is False
    assert "gpu_smoke_artifact=kind=gpu_smoke_unavailable_boundary" in (
        gpu_smoke["notes"]
    )
    failure = summaries["gpu_smoke_parity_failure"]
    assert failure["claim_scope"] == "gpu_dispatch_parity_smoke"
    assert failure["accepted"] is False
    assert failure["failed_check_count"] == 1
    assert failure["gpu_smoke_simulated_parity_failure"] is True
    assert "simulated_parity_failure" in failure["notes"]
    assert "not CUDA parity evidence" in failure["notes"]


def test_cli_imgui_analysis_summary_payload_accepts_source_table_audit(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "source_table_audit.json"
        export_exit = main(
            [
                "fixture-source-table-invariant-audit",
                "L6a4",
                "--max-candidates",
                "8",
                "-o",
                str(path),
            ]
        )
        capsys.readouterr()

        exit_code = main(["imgui-analysis-summary-payload", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert export_exit == 0
    assert exit_code == 0
    assert payload["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert payload["analysis_summary_count"] == 1
    summary = payload["analysis_summaries"][0]
    assert summary["source_method"] == "diagram_fixture_source_table_invariant_audit"
    assert summary["required_check_count"] == 3
    assert summary["passed_check_count"] == 2
    assert summary["failed_check_count"] == 1
    assert "matched=jones,multivariable_alexander_numerator" in summary["notes"]
    assert "uncomputed=homfly" in summary["notes"]
    assert set(
        summary["source_table_audit_source_match_resolution_statuses"].split(",")
    ) == {
        "jones:complete_source_match",
        "homfly:not_computed",
        "multivariable_alexander_numerator:complete_source_match",
    }
    assert summary["source_table_audit_source_match_resolution_status_count"] == 3
    assert "top_candidates=8" in summary["notes"]
    assert "top_unique_sign_patterns=8" in summary["notes"]
    assert (
        "registration_blockers="
        "fixture_signs_not_registered,"
        "registered_fixture_invariant_claim_disabled,"
        "source_table_values_uncomputed,"
        "source_compatible_sign_pattern_not_unique"
        in summary["notes"]
    )
    assert summary["source_table_audit_matched_invariant_count"] == 2
    assert summary["source_table_audit_uncomputed_invariant_count"] == 1
    assert summary["source_table_audit_max_matched_candidate_count"] == 8
    assert summary["source_table_audit_max_matched_unique_sign_pattern_count"] == 8
    assert summary["source_table_audit_registration_ready_count"] == 0
    assert summary["source_table_audit_registration_blocked_count"] == 1
    assert summary["source_table_audit_registration_blocker_count"] == 4
    assert payload["analysis_source_table_audit_top_candidate_count"] == 8
    assert payload["analysis_source_table_audit_max_matched_candidate_count"] == 8
    assert payload["analysis_source_table_audit_max_matched_unique_sign_pattern_count"] == 8
    assert payload["analysis_source_table_audit_registration_ready_count"] == 0
    assert payload["analysis_source_table_audit_registration_blocked_count"] == 1
    assert payload["analysis_source_table_audit_registration_blocker_count"] == 4
    assert payload["analysis_source_table_audit_source_match_resolution_status_count"] == 3


def test_cli_imgui_payloads_accept_source_table_homfly_mismatch(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "source_table_homfly_mismatch.json"
        export_exit = main(
            [
                "fixture-source-table-invariant-audit",
                "L6a4",
                "--max-candidates",
                "8",
                "--include-homfly",
                "--homfly-max-depth",
                "8",
                "--homfly-max-nodes",
                "4096",
                "--alexander-max-minors",
                "256",
                "-o",
                str(path),
            ]
        )
        capsys.readouterr()
        raw_payload = json.loads(path.read_text(encoding="utf-8"))

        analysis_exit = main(["imgui-analysis-summary-payload", str(path)])
        analysis_payload = json.loads(capsys.readouterr().out)

        invariant_exit = main(["imgui-invariant-status-summary-payload", str(path)])
        invariant_payload = json.loads(capsys.readouterr().out)
        _assert_strict_json_serializable(
            raw_payload,
            analysis_payload,
            invariant_payload,
        )

    assert export_exit == 0
    assert analysis_exit == 0
    assert invariant_exit == 0
    assert raw_payload["mismatched_source_table_invariants"] == ["homfly"]
    assert raw_payload["uncomputed_source_table_invariants"] == []
    homfly = raw_payload["comparisons"]["homfly"]
    assert homfly["source_match_resolution_status"] == "source_missed_with_candidates"
    assert homfly["source_value_variant_resolution_status"] == "source_variant_seen"
    assert homfly["source_value_variant_resolution_status_code"] == 4
    variant_miss_summary = homfly["source_value_variant_miss_witness_summary"]
    assert variant_miss_summary["variant_miss_witness_count"] == 0
    assert variant_miss_summary["variant_miss_witness_limit"] == 8
    assert variant_miss_summary["variant_miss_witness_truncated"] is False
    assert variant_miss_summary["first_variant_miss_witness"] is None
    assert raw_payload["source_table_homfly_variant_miss_witness_count"] == 0
    assert raw_payload["source_table_registration_ready"] is False

    summary = analysis_payload["analysis_summaries"][0]
    assert summary["source_method"] == "diagram_fixture_source_table_invariant_audit"
    assert summary["source_table_audit_homfly_variant_resolution_status"] == (
        "source_variant_seen"
    )
    assert summary["source_table_audit_homfly_variant_resolution_status_code"] == 4
    assert set(
        summary["source_table_audit_source_match_resolution_statuses"].split(",")
    ) == {
        "jones:complete_source_match",
        "homfly:source_missed_with_candidates",
        "multivariable_alexander_numerator:complete_source_match",
    }
    assert summary["source_table_audit_mismatched_invariant_count"] == 1
    assert summary["source_table_audit_uncomputed_invariant_count"] == 0
    assert summary["source_table_audit_homfly_source_variant_count"] == 8
    assert summary["source_table_audit_homfly_source_variant_seen_count"] == 4
    assert summary["source_table_audit_homfly_source_variant_miss_count"] == 4
    assert summary["source_table_audit_homfly_variant_miss_witness_count"] == 0
    assert summary["source_table_audit_homfly_variant_miss_witness_limit"] == 8
    assert summary["source_table_audit_homfly_variant_miss_witness_truncated"] == 0
    assert summary["source_table_audit_registration_ready_count"] == 0
    assert summary["source_table_audit_registration_blocked_count"] == 1
    assert summary["source_table_audit_registration_blocker_count"] == 4
    assert (
        summary["source_table_audit_candidate_convergence_certified_invariant_count"]
        == 2
    )
    assert (
        summary["source_table_audit_candidate_convergence_uncertified_invariant_count"]
        == 1
    )
    assert "mismatched=homfly" in summary["notes"]
    assert "uncomputed=homfly" not in summary["notes"]
    assert analysis_payload["analysis_source_table_audit_mismatched_invariant_count"] == 1
    assert analysis_payload["analysis_source_table_audit_uncomputed_invariant_count"] == 0
    assert (
        analysis_payload[
            "analysis_source_table_audit_homfly_variant_miss_witness_count"
        ]
        == 0
    )
    assert analysis_payload["analysis_source_table_audit_registration_blocker_count"] == 4

    status = invariant_payload["invariant_statuses"][0]
    assert status["name"] == "source-table invariant audit"
    assert status["source_table_audit_homfly_variant_resolution_status"] == (
        "source_variant_seen"
    )
    assert status["source_table_audit_homfly_variant_resolution_status_code"] == 4
    assert set(
        status["source_table_audit_source_match_resolution_statuses"].split(",")
    ) == {
        "jones:complete_source_match",
        "homfly:source_missed_with_candidates",
        "multivariable_alexander_numerator:complete_source_match",
    }
    assert status["source_table_audit_mismatched_invariant_count"] == 1
    assert status["source_table_audit_uncomputed_invariant_count"] == 0
    assert status["source_table_audit_homfly_source_variant_count"] == 8
    assert status["source_table_audit_homfly_source_variant_seen_count"] == 4
    assert status["source_table_audit_homfly_source_variant_miss_count"] == 4
    assert status["source_table_audit_homfly_variant_miss_witness_count"] == 0
    assert status["source_table_audit_homfly_variant_miss_witness_limit"] == 8
    assert status["source_table_audit_homfly_variant_miss_witness_truncated"] == 0
    assert status["source_table_audit_registration_ready_count"] == 0
    assert status["source_table_audit_registration_blocked_count"] == 1
    assert status["source_table_audit_registration_blocker_count"] == 4
    assert (
        invariant_payload["invariant_source_table_audit_mismatched_invariant_count"]
        == 1
    )
    assert (
        invariant_payload["invariant_source_table_audit_uncomputed_invariant_count"]
        == 0
    )
    assert (
        invariant_payload["invariant_source_table_audit_homfly_source_variant_count"]
        == 8
    )
    assert (
        invariant_payload[
            "invariant_source_table_audit_homfly_variant_miss_witness_count"
        ]
        == 0
    )
    assert (
        invariant_payload["invariant_source_table_audit_registration_blocker_count"]
        == 4
    )


def test_cli_imgui_invariant_status_summary_payload_accepts_source_table_audit(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "source_table_audit.json"
        export_exit = main(
            [
                "fixture-source-table-invariant-audit",
                "L6a4",
                "--max-candidates",
                "8",
                "-o",
                str(path),
            ]
        )
        capsys.readouterr()

        exit_code = main(["imgui-invariant-status-summary-payload", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert export_exit == 0
    assert exit_code == 0
    assert payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert payload["invariant_status_count"] == 1
    assert payload["invariant_passed_check_count"] == 2
    assert payload["invariant_source_table_audit_registration_ready_count"] == 0
    assert payload["invariant_source_table_audit_registration_blocked_count"] == 1
    assert payload["invariant_source_table_audit_registration_blocker_count"] == 4
    assert payload["invariant_source_table_audit_source_match_resolution_status_count"] == 3
    status = payload["invariant_statuses"][0]
    assert status["name"] == "source-table invariant audit"
    assert status["value"] == "incomplete (2/3 checks, 1 failed)"
    assert status["source_table_audit_registration_ready_count"] == 0
    assert status["source_table_audit_registration_blocked_count"] == 1
    assert status["source_table_audit_registration_blocker_count"] == 4
    assert set(
        status["source_table_audit_source_match_resolution_statuses"].split(",")
    ) == {
        "jones:complete_source_match",
        "homfly:not_computed",
        "multivariable_alexander_numerator:complete_source_match",
    }
    assert status["source_table_audit_source_match_resolution_status_count"] == 3
    assert "matched=jones,multivariable_alexander_numerator" in status["notes"]
    assert "uncomputed=homfly" in status["notes"]
    assert "homfly_variant_status=not_computed" in status["notes"]
    assert "top_candidates=8" in status["notes"]
    assert "registration_ready=false" in status["notes"]
    assert (
        "registration_blockers="
        "fixture_signs_not_registered,"
        "registered_fixture_invariant_claim_disabled,"
        "source_table_values_uncomputed,"
        "source_compatible_sign_pattern_not_unique"
        in status["notes"]
    )


def test_cli_imgui_analysis_payload_accepts_extra_role_order_report(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "role_order_candidates_report.json"
        _write_role_order_candidates_report(path)

        exit_code = main(["imgui-analysis-payload", "--analysis-report-json", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    by_method = {
        summary["source_method"]: summary
        for summary in payload["analysis_summaries"]
    }
    assert "homfly_fixture_acceptance_report" in by_method
    assert "multivariable_alexander_fixture_acceptance_report" in by_method
    role_summary = by_method["signed_pd_role_order_candidates_report"]
    assert role_summary["failed_check_count"] == 16
    assert "signature_evaluated=2" in role_summary["notes"]
    assert "homfly_certified=2" in role_summary["notes"]
    assert "alexander_gcd_certified=2" in role_summary["notes"]
    assert payload["source_signed_pd_revision"] == 42
    assert payload["analysis_role_order_signature_evaluated_candidate_count"] == 2


def test_cli_imgui_host_payload_accepts_extra_core_benchmark_matrix_report(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "benchmark_matrix.json"
        _write_core_benchmark_matrix_report(path)

        exit_code = main(["imgui-host-payload", "--analysis-report-json", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    analysis = payload["analysis"]
    by_method = {
        summary["source_method"]: summary
        for summary in analysis["analysis_summaries"]
    }
    benchmark = by_method["iroll_core_benchmark_matrix"]
    assert benchmark["claim_scope"] == (
        "local_backend_benchmark_matrix_profiling_evidence"
    )
    assert benchmark["benchmark_matrix_completed_row_count"] == 4
    assert benchmark["benchmark_cuda_gpu_completed_row_count"] == 2
    assert benchmark["benchmark_cuda_gpu_release_grade_speedup_claimed"] is False
    assert analysis["analysis_benchmark_matrix_completed_row_count"] == 4
    assert analysis["analysis_benchmark_cuda_gpu_completed_row_count"] == 2
    assert (
        analysis[
            "analysis_benchmark_cuda_gpu_release_grade_speedup_claimed_count"
        ]
        == 0
    )


def test_cli_imgui_host_payload_accepts_extra_gpu_smoke_artifact(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        no_cuda_path = tmp_path / "gpu-smoke-no-cuda.json"
        failure_path = tmp_path / "gpu-smoke-simulated-parity-failure.json"
        _write_gpu_smoke_unavailable_report(no_cuda_path)
        _write_gpu_smoke_failure_report(failure_path)

        exit_code = main(
            [
                "imgui-host-payload",
                "--analysis-report-json",
                str(no_cuda_path),
                "--analysis-report-json",
                str(failure_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "imgui_host_payload"
    analysis = payload["analysis"]
    assert analysis["analysis_gpu_smoke_unavailable_boundary_count"] == 1
    assert analysis["analysis_gpu_smoke_parity_failure_count"] == 1
    assert analysis["analysis_gpu_smoke_no_cuda_boundary_count"] == 1
    assert analysis["analysis_gpu_smoke_simulated_parity_failure_count"] == 1
    assert analysis["analysis_gpu_smoke_required_capability_name_count"] == 6
    assert analysis["analysis_gpu_smoke_failed_check_name_count"] == 1
    assert (
        analysis[
            "analysis_gpu_smoke_release_gate_gpu_backend_unavailable_blocker_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_gpu_smoke_release_gate_cuda_runtime_not_observed_blocker_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_gpu_smoke_release_gate_required_checks_failed_blocker_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_gpu_smoke_release_gate_required_checks_incomplete_blocker_count"
        ]
        == 2
    )
    assert (
        analysis[
            "analysis_gpu_smoke_release_gate_forced_unavailable_blocker_count"
        ]
        == 0
    )
    assert (
        analysis[
            "analysis_gpu_smoke_release_gate_simulated_parity_failure_blocker_count"
        ]
        == 1
    )
    assert analysis["analysis_gpu_smoke_cuda_parity_claimed_count"] == 0
    assert analysis["analysis_gpu_smoke_release_grade_speedup_claimed_count"] == 0
    summaries = {
        summary["source_method"]: summary
        for summary in analysis["analysis_summaries"]
    }
    gpu_smoke = summaries["gpu_smoke_unavailable_boundary"]
    assert gpu_smoke["accepted"] is True
    assert gpu_smoke["certified"] is False
    assert gpu_smoke["gpu_smoke_no_cuda_boundary"] is True
    assert gpu_smoke["gpu_smoke_cuda_runtime_observed"] is False
    assert gpu_smoke["gpu_smoke_required_capability_name_count"] == 3
    assert gpu_smoke["gpu_smoke_required_capability_names"] == (
        "segment_segment_distance|"
        "segment_segment_distances|"
        "segment_intersections_2d"
    )
    assert (
        gpu_smoke[
            "gpu_smoke_release_gate_gpu_backend_unavailable_blocker_count"
        ]
        == 1
    )
    assert (
        gpu_smoke[
            "gpu_smoke_release_gate_required_checks_incomplete_blocker_count"
        ]
        == 1
    )
    assert "gpu_smoke_artifact=kind=gpu_smoke_unavailable_boundary" in (
        gpu_smoke["notes"]
    )
    assert "gpu_smoke_required_capabilities=segment_segment_distance|" in (
        gpu_smoke["notes"]
    )
    assert "gpu_release_gate_blocker_codes=" in gpu_smoke["notes"]
    failure = summaries["gpu_smoke_parity_failure"]
    assert failure["claim_scope"] == "gpu_dispatch_parity_smoke"
    assert failure["accepted"] is False
    assert failure["failed_check_count"] == 1
    assert failure["gpu_smoke_failed_check_name_count"] == 1
    assert failure["gpu_smoke_failed_check_names"] == "gpu_numpy_parity"
    assert failure["gpu_smoke_simulated_parity_failure"] is True
    assert (
        failure[
            "gpu_smoke_release_gate_required_checks_incomplete_blocker_count"
        ]
        == 1
    )
    assert (
        failure[
            "gpu_smoke_release_gate_required_checks_failed_blocker_count"
        ]
        == 1
    )
    assert (
        failure[
            "gpu_smoke_release_gate_simulated_parity_failure_blocker_count"
        ]
        == 1
    )
    assert "simulated_parity_failure" in failure["notes"]
    assert "gpu_smoke_failed_check_names=gpu_numpy_parity" in failure["notes"]
    assert "not CUDA parity evidence" in failure["notes"]


def test_cli_imgui_host_payload_accepts_extra_invariant_report(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "homfly-auto-role-order-ambiguous.json"
        unsupported_path = tmp_path / "unsupported-alexander-handle.json"
        path.write_text(
            json.dumps(
                {
                    "method": "homfly_pd_report",
                    "input": {
                        "signed_pd_revision": 11,
                        "auto_role_order": {
                            "requested": True,
                            "applied": False,
                            "status": "ambiguous",
                            "candidate_count": 8,
                            "strict_candidate_count": 4,
                            "unique_strict_global_role_order": None,
                            "candidate_role_orders": [
                                [0, 1, 2, 3],
                                [1, 0, 2, 3],
                                [0, 1, 3, 2],
                                [1, 0, 3, 2],
                            ],
                            "notes": [
                                "multiple strict global role_order candidates matched the diagram",
                            ],
                        }
                    },
                    "homfly_polynomial": None,
                    "skipped": True,
                    "result": None,
                    "notes": ["auto role order skipped by host boundary"],
                }
            ),
            encoding="utf-8",
        )
        _write_unsupported_invariant_result_handle_report(
            unsupported_path,
            invariant="alexander",
        )

        exit_code = main(
            [
                "imgui-host-payload",
                "--report",
                "homfly",
                "--notation",
                "0_1",
                "--invariant-report-json",
                str(path),
                "--invariant-report-json",
                str(unsupported_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "imgui_host_payload"
    invariants = payload["invariants"]
    assert invariants["method"] == "imgui_invariant_status_payload_from_reports"
    assert invariants["signed_pd_revision"] == 11
    assert invariants["invariant_signed_pd_auto_role_order_present_count"] == 1
    assert invariants["invariant_signed_pd_auto_role_order_requested_count"] == 1
    assert invariants["invariant_signed_pd_auto_role_order_applied_count"] == 0
    assert invariants["invariant_signed_pd_auto_role_order_ambiguous_count"] == 1
    assert invariants["invariant_signed_pd_auto_role_order_candidate_count"] == 8
    assert (
        invariants["invariant_signed_pd_auto_role_order_strict_candidate_count"]
        == 4
    )
    auto_rows = [
        status
        for status in invariants["invariant_statuses"]
        if status.get("signed_pd_auto_role_order_present") is True
    ]
    assert len(auto_rows) == 1
    row = auto_rows[0]
    assert row["name"] == "HOMFLY-PT"
    assert row["value"] == "skipped"
    assert row["skipped"] is True
    assert row["signed_pd_auto_role_order_requested"] is True
    assert row["signed_pd_auto_role_order_applied"] is False
    assert row["signed_pd_auto_role_order_status"] == "ambiguous"
    assert row["signed_pd_auto_role_order_candidate_count"] == 8
    assert row["signed_pd_auto_role_order_strict_candidate_count"] == 4
    assert "signed_pd_auto_role_order=status=ambiguous; applied=False" in row[
        "notes"
    ]
    unsupported_rows = [
        status
        for status in invariants["invariant_statuses"]
        if status["name"] == "multi-variable Alexander native result handle"
    ]
    assert len(unsupported_rows) == 1
    unsupported = unsupported_rows[0]
    assert unsupported["value"] == "skipped"
    assert unsupported["skipped"] is True
    assert unsupported["required_check_count"] == 0
    assert "status_code=alexander_native_compute_handle_missing" in unsupported[
        "notes"
    ]
    assert "native_computation_claimed=false" in unsupported["notes"]
    assert "result_available=false" in unsupported["notes"]
    analysis_methods = {
        summary["source_method"]
        for summary in payload["analysis"]["analysis_summaries"]
    }
    assert "homfly_pd_report" not in analysis_methods


def test_cli_imgui_invariant_status_payload_accepts_unique_applied_auto_role_order(
    capsys,
) -> None:
    report = {
        "method": "homfly_pd_report",
        "input": {
            "signed_pd_revision": 23,
            "auto_role_order": {
                "requested": True,
                "applied": True,
                "status": "unique_applied",
                "candidate_count": 1,
                "strict_candidate_count": 1,
                "unique_strict_global_role_order": [1, 0, 2, 3],
                "candidate_role_orders": [[1, 0, 2, 3]],
                "notes": [
                    "exactly one strict global role_order candidate matched the diagram",
                    "unique strict global role_order selected for this input",
                ],
            },
        },
        "homfly_polynomial": "P",
        "certified_for_input": False,
        "skipped": False,
        "result": {"method": "synthetic_unique_auto_role_order_probe"},
        "notes": ["synthetic unique-applied auto role order report"],
    }

    with workspace_tempdir() as tmp_path:
        path = tmp_path / "homfly-auto-role-order-unique-applied.json"
        path.write_text(json.dumps(report), encoding="utf-8")

        summary_exit = main(["imgui-invariant-status-summary-payload", str(path)])
        summary_payload = json.loads(capsys.readouterr().out)

        host_exit = main(["imgui-host-payload", "--invariant-report-json", str(path)])
        host_payload = json.loads(capsys.readouterr().out)

    assert summary_exit == 0
    assert host_exit == 0
    assert summary_payload["signed_pd_revision"] == 23
    assert summary_payload["invariant_signed_pd_auto_role_order_present_count"] == 1
    assert summary_payload["invariant_signed_pd_auto_role_order_applied_count"] == 1
    assert summary_payload[
        "invariant_signed_pd_auto_role_order_unique_applied_count"
    ] == 1
    assert summary_payload["invariant_signed_pd_auto_role_order_candidate_count"] == 1
    assert (
        summary_payload["invariant_signed_pd_auto_role_order_strict_candidate_count"]
        == 1
    )
    status = summary_payload["invariant_statuses"][0]
    assert status["name"] == "HOMFLY-PT"
    assert status["value"] == "P"
    assert status["skipped"] is False
    assert status["signed_pd_auto_role_order_requested"] is True
    assert status["signed_pd_auto_role_order_applied"] is True
    assert status["signed_pd_auto_role_order_status"] == "unique_applied"
    assert status["signed_pd_auto_role_order_candidate_count"] == 1
    assert status["signed_pd_auto_role_order_strict_candidate_count"] == 1
    assert (
        status["signed_pd_auto_role_order_unique_strict_global_role_order"]
        == "1,0,2,3"
    )
    assert "unique_role_order=1,0,2,3" in status["notes"]

    invariants = host_payload["invariants"]
    assert invariants["signed_pd_revision"] == 23
    assert invariants["invariant_signed_pd_auto_role_order_present_count"] == 1
    assert invariants["invariant_signed_pd_auto_role_order_applied_count"] == 1
    assert invariants["invariant_signed_pd_auto_role_order_unique_applied_count"] == 1
    assert any(
        row.get("signed_pd_auto_role_order_status") == "unique_applied"
        for row in invariants["invariant_statuses"]
    )

def test_cli_imgui_host_payload_accepts_extra_role_order_analysis_report(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "role_order_candidates_report.json"
        _write_role_order_candidates_report(path)

        exit_code = main(["imgui-host-payload", "--analysis-report-json", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    analysis = payload["analysis"]
    by_method = {
        summary["source_method"]: summary
        for summary in analysis["analysis_summaries"]
    }
    assert "signed_pd_role_order_candidates_report" in by_method
    assert by_method["signed_pd_role_order_candidates_report"]["required_check_count"] == 16
    assert analysis["source_signed_pd_revision"] == 42
    assert analysis["analysis_failed_check_count"] >= 16


def test_cli_imgui_host_payload_accepts_extra_improved_alexander_report(
    capsys,
) -> None:
    improved_report = {
        "method": "multivariable_alexander_improve_scanned_gcd_result",
        "source_polynomial": "1 - t1",
        "improved_candidate_polynomial": "1 - t2 - t1 + t1*t2",
        "accepted": True,
        "skipped": False,
        "result": {
            "method": (
                "synthetic_nonmaximal_scanned_gcd_candidate"
                "_improved_by_scanned_quotient_gcd"
            ),
            "multivariable_alexander_polynomial": "1 - t2 - t1 + t1*t2",
        },
        "improved_audit": {
            "candidate_is_exact_scanned_gcd": True,
            "complete_scanned_gcd_certified": True,
            "complete_combination_scan": True,
            "nonzero_minor_coverage_complete": True,
            "truncated": False,
            "quotient_gcd_certified": True,
            "quotient_gcd_polynomial": "1",
            "quotient_gcd_method": "fox_square_minor_quotient_unit_gcd",
            "checked_nonzero_minor_count": 2,
            "failed_nonzero_minor_count": 0,
            "scanned_minor_count": 2,
            "division_record_count": 2,
        },
        "notes": ["improved result is bounded scanned-minor evidence"],
    }
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "alexander-improved.json"
        path.write_text(json.dumps(improved_report), encoding="utf-8")

        exit_code = main(["imgui-host-payload", "--analysis-report-json", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    analysis = payload["analysis"]
    by_method = {
        summary["source_method"]: summary
        for summary in analysis["analysis_summaries"]
    }
    improved = by_method["multivariable_alexander_improve_scanned_gcd_result"]
    assert improved["required_check_count"] == 4
    assert improved["passed_check_count"] == 4
    assert improved["bounded_scanned_gcd_improved_candidate_count"] == 1
    assert analysis["analysis_bounded_scanned_gcd_checked_nonzero_minor_count"] >= 2
    assert analysis["analysis_bounded_scanned_gcd_complete_certified_count"] >= 1
    assert "full_invariant_certified=False" in improved["notes"]


def test_cli_imgui_host_payload_accepts_extra_alexander_input_evidence(
    capsys,
) -> None:
    evidence = _synthetic_alexander_input_certification_evidence()
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "alexander-input-certification-evidence.json"
        path.write_text(json.dumps(evidence), encoding="utf-8")

        exit_code = main(["imgui-host-payload", "--analysis-report-json", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    analysis = payload["analysis"]
    by_method = {
        summary["source_method"]: summary
        for summary in analysis["analysis_summaries"]
    }
    alexander_evidence = by_method[
        "multivariable_alexander_input_certification_evidence"
    ]
    assert alexander_evidence["required_check_count"] == 4
    assert alexander_evidence["passed_check_count"] == 4
    assert alexander_evidence["bounded_scanned_gcd_scanned_minor_count"] == 2
    assert alexander_evidence["wirtinger_fox_relation_count"] == 2
    assert analysis["analysis_bounded_scanned_gcd_checked_nonzero_minor_count"] >= 2
    assert "bounded_scanned_gcd_certified=True" in alexander_evidence["notes"]
    assert "admissible_minor_normalization=representative=1" in (
        alexander_evidence["notes"]
    )


def test_cli_imgui_host_payload_accepts_extra_alexander_minor_divisibility_audit(
    capsys,
) -> None:
    audit = _synthetic_alexander_minor_divisibility_audit()
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "alexander-minor-divisibility-audit.json"
        path.write_text(json.dumps(audit), encoding="utf-8")

        exit_code = main(["imgui-host-payload", "--analysis-report-json", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    analysis = payload["analysis"]
    by_method = {
        summary["source_method"]: summary
        for summary in analysis["analysis_summaries"]
    }
    minor_audit = by_method["multivariable_alexander_minor_divisibility_audit"]
    assert minor_audit["required_check_count"] == 3
    assert minor_audit["passed_check_count"] == 3
    assert minor_audit["bounded_scanned_gcd_checked_nonzero_minor_count"] == 2
    assert minor_audit["bounded_scanned_gcd_complete_scan_count"] == 1
    assert analysis["analysis_bounded_scanned_gcd_division_record_count"] >= 2
    assert "all_nonzero_minors_divisible=True" in minor_audit["notes"]


def test_cli_imgui_host_payload_accepts_extra_homfly_terminal_audit(
    capsys,
) -> None:
    audit = {
        "method": "homfly_terminal_reduction_audit",
        "claim_scope": (
            "exact_sum_of_recorded_terminal_and_memoized_reduction_contributions"
        ),
        "evaluation_method": "certified_iterative_recursive_homfly",
        "homfly_polynomial": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
        "terminal_contribution_sum": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
        "terminal_reduction_count": 3,
        "memoized_reduction_count": 1,
        "reduction_contribution_count": 4,
        "failed_terminal_reduction_count": 0,
        "cache_hits": 1,
        "frontier_count": 0,
        "truncated": False,
        "matched_result": True,
        "skipped": False,
    }
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "homfly-terminal-reduction-audit.json"
        path.write_text(json.dumps(audit), encoding="utf-8")

        exit_code = main(["imgui-host-payload", "--analysis-report-json", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    analysis = payload["analysis"]
    by_method = {
        summary["source_method"]: summary
        for summary in analysis["analysis_summaries"]
    }
    terminal_audit = by_method["homfly_terminal_reduction_audit"]
    assert terminal_audit["required_check_count"] == 3
    assert terminal_audit["passed_check_count"] == 3
    assert terminal_audit["input_certification_terminal_reduction_count"] == 3
    assert (
        analysis[
            "analysis_input_certification_terminal_contribution_matched_count"
        ]
        >= 1
    )
    assert "arbitrary_diagram_coverage_certified=False" in terminal_audit["notes"]


def test_cli_imgui_host_payload_accepts_extra_homfly_input_evidence(
    capsys,
) -> None:
    evidence = _synthetic_homfly_input_certification_evidence()
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "homfly-input-certification-evidence.json"
        path.write_text(json.dumps(evidence), encoding="utf-8")

        exit_code = main(["imgui-host-payload", "--analysis-report-json", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    analysis = payload["analysis"]
    by_method = {
        summary["source_method"]: summary
        for summary in analysis["analysis_summaries"]
    }
    homfly_evidence = by_method["homfly_input_certification_evidence"]
    assert homfly_evidence["required_check_count"] == 4
    assert homfly_evidence["passed_check_count"] == 4
    assert homfly_evidence["input_certification_recursion_node_count"] == 12
    assert homfly_evidence["input_certification_iterative_solved_count"] == 1
    assert (
        analysis["analysis_input_certification_terminal_reduction_count"] >= 3
    )
    assert "frontier_exhausted=True" in homfly_evidence["notes"]


def test_cli_imgui_payloads_preserve_compact_evidence_from_report_json(
    capsys,
) -> None:
    homfly_report = _synthetic_homfly_compact_evidence_report()
    alexander_report = _synthetic_alexander_compact_witness_report()
    homfly_expected = {
        "certification_blocker_detail_count": 1,
        "homfly_completion_blocker_detail_count": 1,
        "frontier_witness_summary_count": 1,
        "frontier_witness_summary_truncated": 0,
        "frontier_witness_summary_reason_count": 1,
        "frontier_witness_summary_recursive_path_prefix_count": 1,
        "frontier_witness_summary_source_kind_count": 1,
        "frontier_witness_summary_branch_count": 1,
        "frontier_witness_summary_min_depth": 4,
        "frontier_witness_summary_max_depth": 4,
        "frontier_witness_summary_min_branch_depth": 1,
        "frontier_witness_summary_max_branch_depth": 1,
        "frontier_witness_summary_pressure_total_frontier_count": 1,
        "frontier_witness_summary_pressure_visible_witness_count": 1,
        "frontier_witness_summary_pressure_missing_frontier_count": 0,
        "frontier_witness_summary_pressure_all_frontiers_have_visible_witness": 1,
        "frontier_witness_summary_pressure_reason_count": 1,
        "homfly_completion_blocker_provenance_matched": 1,
        "homfly_completion_blocker_provenance_non_claim_matched": 1,
        "homfly_completion_blocker_provenance_gate_pressure_matched": 1,
        "homfly_completion_blocker_provenance_frontier_pressure_matched": 1,
        "homfly_completion_blocker_provenance_frontier_witness_matched": 1,
        "homfly_completion_blocker_provenance_terminal_audit_matched": 1,
        "homfly_completion_blocker_provenance_source_field_count": 3,
        "failed_division_witness_count": 0,
        "quotient_gcd_uncertainty_present": 0,
        "normalization_class_witness_count": 0,
        "admissible_minor_normalization_blocker_reason_count": 0,
        "admissible_minor_normalization_blocker_witness_available_count": 0,
        "admissible_minor_normalization_blocker_missing_witness_reason_count": 0,
        "admissible_minor_normalization_blocker_witness_source_count": 0,
        "admissible_minor_normalization_blocker_witness_source_available_count": 0,
        "admissible_minor_normalization_blocker_witness_source_missing_count": 0,
        "admissible_minor_normalization_gate_count": 0,
        "admissible_minor_normalization_gate_passed_count": 0,
        "admissible_minor_normalization_gate_failed_count": 0,
        "admissible_minor_normalization_gate_summary_consistent": 0,
        "admissible_minor_normalization_failed_gate_blocker_count": 0,
        "admissible_minor_normalization_failed_gate_blocker_provenance_consistent": 0,
        "admissible_minor_normalization_failed_gate_blocker_provenance_row_count": 0,
        "admissible_minor_normalization_failed_gate_blocker_provenance_gate_count": 0,
        "admissible_minor_normalization_failed_gate_blocker_provenance_attribution_count": 0,
        "admissible_minor_normalization_failed_gate_blocker_provenance_reason_count": 0,
        "admissible_minor_normalization_failed_gate_blocker_provenance_source_available_count": 0,
        "admissible_minor_normalization_failed_gate_blocker_provenance_source_missing_count": 0,
        "admissible_minor_normalization_failed_gate_blocker_provenance_missing_source_count": 0,
        "admissible_minor_normalization_failed_gate_blocker_provenance_inconsistent_source_count": 0,
    }
    alexander_expected = {
        "certification_blocker_detail_count": 0,
        "homfly_completion_blocker_detail_count": 0,
        "frontier_witness_summary_count": 0,
        "frontier_witness_summary_truncated": 0,
        "frontier_witness_summary_reason_count": 0,
        "frontier_witness_summary_recursive_path_prefix_count": 0,
        "frontier_witness_summary_source_kind_count": 0,
        "frontier_witness_summary_branch_count": 0,
        "frontier_witness_summary_min_depth": 0,
        "frontier_witness_summary_max_depth": 0,
        "frontier_witness_summary_min_branch_depth": 0,
        "frontier_witness_summary_max_branch_depth": 0,
        "frontier_witness_summary_pressure_total_frontier_count": 0,
        "frontier_witness_summary_pressure_visible_witness_count": 0,
        "frontier_witness_summary_pressure_missing_frontier_count": 0,
        "frontier_witness_summary_pressure_all_frontiers_have_visible_witness": 0,
        "frontier_witness_summary_pressure_reason_count": 0,
        "homfly_completion_blocker_provenance_matched": 0,
        "homfly_completion_blocker_provenance_non_claim_matched": 0,
        "homfly_completion_blocker_provenance_gate_pressure_matched": 0,
        "homfly_completion_blocker_provenance_frontier_pressure_matched": 0,
        "homfly_completion_blocker_provenance_frontier_witness_matched": 0,
        "homfly_completion_blocker_provenance_terminal_audit_matched": 0,
        "homfly_completion_blocker_provenance_source_field_count": 0,
        "failed_division_witness_count": 1,
        "quotient_gcd_uncertainty_present": 1,
        "normalization_class_witness_count": 2,
        "admissible_minor_normalization_blocker_reason_count": 3,
        "admissible_minor_normalization_blocker_witness_available_count": 1,
        "admissible_minor_normalization_blocker_missing_witness_reason_count": 2,
        "admissible_minor_normalization_blocker_witness_source_count": 4,
        "admissible_minor_normalization_blocker_witness_source_available_count": 2,
        "admissible_minor_normalization_blocker_witness_source_missing_count": 2,
        "admissible_minor_normalization_gate_count": 5,
        "admissible_minor_normalization_gate_passed_count": 2,
        "admissible_minor_normalization_gate_failed_count": 3,
        "admissible_minor_normalization_gate_summary_consistent": 1,
        "admissible_minor_normalization_failed_gate_blocker_count": 3,
        "admissible_minor_normalization_failed_gate_blocker_provenance_consistent": 1,
        "admissible_minor_normalization_failed_gate_blocker_provenance_row_count": 3,
        "admissible_minor_normalization_failed_gate_blocker_provenance_gate_count": 3,
        "admissible_minor_normalization_failed_gate_blocker_provenance_attribution_count": 3,
        "admissible_minor_normalization_failed_gate_blocker_provenance_reason_count": 3,
        "admissible_minor_normalization_failed_gate_blocker_provenance_source_available_count": 2,
        "admissible_minor_normalization_failed_gate_blocker_provenance_source_missing_count": 1,
        "admissible_minor_normalization_failed_gate_blocker_provenance_missing_source_count": 1,
        "admissible_minor_normalization_failed_gate_blocker_provenance_inconsistent_source_count": 0,
    }
    aggregate_expected = {
        key: homfly_expected[key] + alexander_expected[key]
        for key in homfly_expected
    }

    with workspace_tempdir() as tmp_path:
        homfly_path = tmp_path / "homfly-compact-evidence.json"
        alexander_path = tmp_path / "alexander-compact-witness.json"
        homfly_path.write_text(json.dumps(homfly_report), encoding="utf-8")
        alexander_path.write_text(json.dumps(alexander_report), encoding="utf-8")

        analysis_exit = main(
            [
                "imgui-analysis-payload",
                "--report",
                "homfly",
                "--notation",
                "0_1",
                "--analysis-report-json",
                str(homfly_path),
                "--analysis-report-json",
                str(alexander_path),
            ]
        )
        analysis = json.loads(capsys.readouterr().out)

        host_exit = main(
            [
                "imgui-host-payload",
                "--report",
                "homfly",
                "--notation",
                "0_1",
                "--analysis-report-json",
                str(homfly_path),
                "--analysis-report-json",
                str(alexander_path),
            ]
        )
        host = json.loads(capsys.readouterr().out)

        invariant_exit = main(
            [
                "imgui-invariant-status-summary-payload",
                str(homfly_path),
                str(alexander_path),
            ]
        )
        invariants = json.loads(capsys.readouterr().out)

    assert analysis_exit == 0
    summaries = {
        summary["source_method"]: summary
        for summary in analysis["analysis_summaries"]
    }
    homfly_summary = summaries["homfly_input_certification_evidence"]
    alexander_summary = summaries[
        "multivariable_alexander_input_certification_evidence"
    ]
    for key, value in homfly_expected.items():
        assert homfly_summary[key] == value
    for key, value in alexander_expected.items():
        assert alexander_summary[key] == value
    assert "blocker_witness_sources" not in alexander_summary
    for key, value in aggregate_expected.items():
        assert analysis[f"analysis_{key}"] >= value
    assert "certification_blocker_detail_count=1" in homfly_summary["notes"]
    assert "first_certification_blocker_detail_code=frontier_not_exhausted" in (
        homfly_summary["notes"]
    )
    assert "homfly_completion_blocker_detail_count=1" in homfly_summary["notes"]
    assert "frontier_exhausted=False" in homfly_summary["notes"]
    assert "frontier_witness_summary=witnesses=1" in homfly_summary["notes"]
    assert "recursive_path_prefix_count=1" in homfly_summary["notes"]
    assert "source_kind_count=1" in homfly_summary["notes"]
    assert "branch_count=1" in homfly_summary["notes"]
    assert "depth=4..4" in homfly_summary["notes"]
    assert "frontier_witness_pressure=total_frontiers=1" in homfly_summary["notes"]
    assert "visible_witnesses=1" in homfly_summary["notes"]
    assert "missing_frontiers=0" in homfly_summary["notes"]
    assert "all_visible=True" in homfly_summary["notes"]
    assert "homfly_completion_blocker_provenance=matched=True" in (
        homfly_summary["notes"]
    )
    assert "source_fields=3" in homfly_summary["notes"]
    assert "alexander_witness_evidence=failed_division_witness_count=1" in (
        alexander_summary["notes"]
    )
    assert "quotient_gcd_uncertainty_present=1" in alexander_summary["notes"]
    assert "first_failed_division_minor=3" in alexander_summary["notes"]
    assert "first_normalization_class_witness=1 - t1" in alexander_summary["notes"]
    assert (
        "admissible_minor_normalization_blocker_witness_summary=reason_count=3"
        in alexander_summary["notes"]
    )
    assert "witness_available_count=1" in alexander_summary["notes"]
    assert "missing_witness_reason_count=2" in alexander_summary["notes"]
    assert "witness_source_count=4" in alexander_summary["notes"]
    assert "witness_source_available_count=2" in alexander_summary["notes"]
    assert "witness_source_missing_count=2" in alexander_summary["notes"]
    assert "blocker_witness_sources" not in alexander_summary["notes"]
    assert (
        "first_admissible_minor_normalization_blocker_witness_source_kind="
        "normalization_class_witness"
        in alexander_summary["notes"]
    )
    assert (
        "first_admissible_minor_normalization_blocker_witness_source_status=available"
        in alexander_summary["notes"]
    )
    assert "summary_consistency_matched=True" in alexander_summary["notes"]
    assert (
        "summary_consistency_blocker_witness_source_count_matched=True"
        in alexander_summary["notes"]
    )
    assert "admissible_minor_normalization_gate_summary=gates=5" in (
        alexander_summary["notes"]
    )
    assert "passed=2" in alexander_summary["notes"]
    assert "failed=3" in alexander_summary["notes"]
    assert "consistent=True" in alexander_summary["notes"]
    assert "failed_gate_blockers=3" in alexander_summary["notes"]
    assert "admissible_minor_normalization_gate_provenance=consistent=True" in (
        alexander_summary["notes"]
    )
    assert "source_missing=1" in alexander_summary["notes"]
    assert "full_invariant_certified=False" in alexander_summary["notes"]

    assert host_exit == 0
    host_analysis = host["analysis"]
    host_summaries = {
        summary["source_method"]: summary
        for summary in host_analysis["analysis_summaries"]
    }
    for key, value in homfly_expected.items():
        assert host_summaries["homfly_input_certification_evidence"][key] == value
    for key, value in alexander_expected.items():
        assert host_summaries[
            "multivariable_alexander_input_certification_evidence"
        ][key] == value
    for key, value in aggregate_expected.items():
        assert host_analysis[f"analysis_{key}"] >= value
        assert host[f"analysis_{key}"] == host_analysis[f"analysis_{key}"]
        assert isinstance(host[f"invariant_{key}"], int)

    assert invariant_exit == 0
    statuses = {status["name"]: status for status in invariants["invariant_statuses"]}
    for key, value in homfly_expected.items():
        assert statuses["HOMFLY-PT input evidence"][key] == value
    for key, value in alexander_expected.items():
        assert statuses["multi-variable Alexander input evidence"][key] == value
    assert "blocker_witness_sources" not in statuses[
        "multi-variable Alexander input evidence"
    ]
    for key, value in aggregate_expected.items():
        assert invariants[f"invariant_{key}"] == value


def test_cli_imgui_file_payloads_default_missing_compact_evidence_to_zero(
    capsys,
) -> None:
    homfly_report = _synthetic_homfly_compact_evidence_report()
    alexander_report = _synthetic_alexander_compact_witness_report()
    for key in (
        "certification_blocker_detail_count",
        "certification_blocker_details",
        "homfly_completion_blocker_detail_count",
        "homfly_completion_blocker_details",
        "frontier_witness_summary",
        "arbitrary_diagram_completion_gate",
    ):
        homfly_report.pop(key, None)
    for key in (
        "failed_division_witness_count",
        "failed_division_witness_limit",
        "failed_division_witnesses",
        "quotient_gcd_uncertainty_evidence",
        "admissible_minor_normalization_blocker_details",
        "bounded_admissible_minor_normalization_blocker_witness_summary",
        "bounded_admissible_minor_normalization_gate_summary",
    ):
        alexander_report.pop(key, None)
    compact_keys = (
        "certification_blocker_detail_count",
        "homfly_completion_blocker_detail_count",
        "frontier_witness_summary_count",
        "frontier_witness_summary_truncated",
        "frontier_witness_summary_reason_count",
        "frontier_witness_summary_recursive_path_prefix_count",
        "frontier_witness_summary_source_kind_count",
        "frontier_witness_summary_branch_count",
        "frontier_witness_summary_min_depth",
        "frontier_witness_summary_max_depth",
        "frontier_witness_summary_min_branch_depth",
        "frontier_witness_summary_max_branch_depth",
        "frontier_witness_summary_pressure_total_frontier_count",
        "frontier_witness_summary_pressure_visible_witness_count",
        "frontier_witness_summary_pressure_missing_frontier_count",
        "frontier_witness_summary_pressure_all_frontiers_have_visible_witness",
        "frontier_witness_summary_pressure_reason_count",
        "homfly_completion_blocker_provenance_matched",
        "homfly_completion_blocker_provenance_non_claim_matched",
        "homfly_completion_blocker_provenance_gate_pressure_matched",
        "homfly_completion_blocker_provenance_frontier_pressure_matched",
        "homfly_completion_blocker_provenance_frontier_witness_matched",
        "homfly_completion_blocker_provenance_terminal_audit_matched",
        "homfly_completion_blocker_provenance_source_field_count",
        "homfly_reduction_contribution_count",
        "homfly_reduction_contribution_witness_count",
        "homfly_reduction_contribution_witness_limit",
        "homfly_reduction_contribution_witness_truncated_count",
        "homfly_reduction_contribution_parsed_count",
        "homfly_reduction_contribution_unparsed_count",
        "homfly_reduction_contribution_consistency_matched_count",
        "homfly_reduction_contribution_consistency_mismatch_count",
        "failed_division_witness_count",
        "quotient_gcd_uncertainty_present",
        "normalization_class_witness_count",
        "admissible_minor_normalization_blocker_reason_count",
        "admissible_minor_normalization_blocker_witness_available_count",
        "admissible_minor_normalization_blocker_missing_witness_reason_count",
        "admissible_minor_normalization_blocker_witness_source_count",
        "admissible_minor_normalization_blocker_witness_source_available_count",
        "admissible_minor_normalization_blocker_witness_source_missing_count",
        "admissible_minor_normalization_gate_count",
        "admissible_minor_normalization_gate_passed_count",
        "admissible_minor_normalization_gate_failed_count",
        "admissible_minor_normalization_gate_summary_consistent",
        "admissible_minor_normalization_failed_gate_blocker_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_consistent",
        "admissible_minor_normalization_failed_gate_blocker_provenance_row_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_gate_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_attribution_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_reason_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_source_available_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_source_missing_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_missing_source_count",
        "admissible_minor_normalization_failed_gate_blocker_provenance_inconsistent_source_count",
    )

    with workspace_tempdir() as tmp_path:
        homfly_path = tmp_path / "old-homfly-evidence.json"
        alexander_path = tmp_path / "old-alexander-evidence.json"
        homfly_path.write_text(json.dumps(homfly_report), encoding="utf-8")
        alexander_path.write_text(json.dumps(alexander_report), encoding="utf-8")

        analysis_exit = main(
            [
                "imgui-analysis-summary-payload",
                str(homfly_path),
                str(alexander_path),
            ]
        )
        analysis = json.loads(capsys.readouterr().out)

        host_exit = main(
            [
                "imgui-host-payload",
                "--report",
                "homfly",
                "--notation",
                "0_1",
                "--analysis-report-json",
                str(homfly_path),
                "--analysis-report-json",
                str(alexander_path),
            ]
        )
        host = json.loads(capsys.readouterr().out)

        invariant_exit = main(
            [
                "imgui-invariant-status-summary-payload",
                str(homfly_path),
                str(alexander_path),
            ]
        )
        invariants = json.loads(capsys.readouterr().out)

    assert analysis_exit == 0
    assert analysis["analysis_summary_count"] == 2
    for key in compact_keys:
        assert analysis[f"analysis_{key}"] == 0
    for summary in analysis["analysis_summaries"]:
        for key in compact_keys:
            assert summary[key] == 0
        assert "first_certification_blocker_detail_" not in summary["notes"]
        assert "first_homfly_completion_blocker_detail_" not in summary["notes"]
        assert "frontier_witness_summary=" not in summary["notes"]
        assert "first_failed_division_" not in summary["notes"]
        assert "first_normalization_class_witness" not in summary["notes"]
        assert "admissible_minor_normalization_blocker_witness_summary=" not in (
            summary["notes"]
        )
        assert "first_admissible_minor_normalization_blocker_witness_source" not in (
            summary["notes"]
        )
        assert "frontier_witness_pressure=" not in summary["notes"]
        assert "admissible_minor_normalization_gate_summary=" not in (
            summary["notes"]
        )

    assert host_exit == 0
    host_summaries = {
        summary["source_method"]: summary
        for summary in host["analysis"]["analysis_summaries"]
    }
    for source_method in (
        "homfly_input_certification_evidence",
        "multivariable_alexander_input_certification_evidence",
    ):
        summary = host_summaries[source_method]
        for key in compact_keys:
            assert summary[key] == 0
        assert "first_certification_blocker_detail_" not in summary["notes"]
        assert "first_homfly_completion_blocker_detail_" not in summary["notes"]
        assert "frontier_witness_summary=" not in summary["notes"]
        assert "first_failed_division_" not in summary["notes"]
        assert "first_normalization_class_witness" not in summary["notes"]
        assert "admissible_minor_normalization_blocker_witness_summary=" not in (
            summary["notes"]
        )
        assert "first_admissible_minor_normalization_blocker_witness_source" not in (
            summary["notes"]
        )
        assert "frontier_witness_pressure=" not in summary["notes"]
        assert "admissible_minor_normalization_gate_summary=" not in (
            summary["notes"]
        )

    assert invariant_exit == 0
    for key in compact_keys:
        assert invariants[f"invariant_{key}"] == 0
    for status in invariants["invariant_statuses"]:
        for key in compact_keys:
            assert status[key] == 0
        assert "first_certification_blocker_detail_" not in status["notes"]
        assert "first_homfly_completion_blocker_detail_" not in status["notes"]
        assert "frontier_witness_summary=" not in status["notes"]
        assert "first_failed_division_" not in status["notes"]
        assert "first_normalization_class_witness" not in status["notes"]
        assert "admissible_minor_normalization_blocker_witness_summary=" not in (
            status["notes"]
        )
        assert "first_admissible_minor_normalization_blocker_witness_source" not in (
            status["notes"]
        )
        assert "frontier_witness_pressure=" not in status["notes"]
        assert "admissible_minor_normalization_gate_summary=" not in (
            status["notes"]
        )


def test_cli_imgui_host_payload_accepts_extra_homfly_skein_identity_audit(
    capsys,
) -> None:
    audit = _synthetic_homfly_skein_identity_audit()
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "homfly-skein-identity-audit.json"
        path.write_text(json.dumps(audit), encoding="utf-8")

        exit_code = main(["imgui-host-payload", "--analysis-report-json", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    analysis = payload["analysis"]
    by_method = {
        summary["source_method"]: summary
        for summary in analysis["analysis_summaries"]
    }
    skein = by_method["homfly_skein_identity_audit"]
    assert skein["required_check_count"] == 2
    assert skein["passed_check_count"] == 2
    assert skein["failed_check_count"] == 0
    assert "skein_checked=2" in skein["notes"]
    assert analysis["analysis_required_check_count"] >= 2
    assert analysis["analysis_passed_check_count"] >= 2


def test_cli_imgui_analysis_payload_generates_role_order_report_from_signed_pd(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "hopf_imgui_without_role_order.json"
        _write_hopf_imgui_without_role_order(path)

        exit_code = main(
            [
                "imgui-analysis-payload",
                "--report",
                "homfly",
                "--notation",
                "L2a1",
                "--analysis-signed-pd-role-order-candidates",
                str(path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    by_method = {
        summary["source_method"]: summary
        for summary in payload["analysis_summaries"]
    }
    assert "homfly_fixture_acceptance_report" in by_method
    role_summary = by_method["signed_pd_role_order_candidates_report"]
    assert role_summary["has_source_signed_pd_revision"] is True
    assert role_summary["source_signed_pd_revision"] == 42
    assert role_summary["required_check_count"] == 16
    assert role_summary["passed_check_count"] == 0
    assert role_summary["failed_check_count"] == 16
    assert "strict=16" in role_summary["notes"]
    assert "signed_pd_revision=42" in role_summary["notes"]


def test_cli_imgui_analysis_payload_generates_source_table_audit(capsys) -> None:
    exit_code = main(
        [
            "imgui-analysis-payload",
            "--report",
            "homfly",
            "--notation",
            "0_1",
            "--analysis-source-table-invariant-audit",
            "L6a4",
            "--analysis-source-table-max-candidates",
            "8",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    by_method = {
        summary["source_method"]: summary
        for summary in payload["analysis_summaries"]
    }
    assert "homfly_fixture_acceptance_report" in by_method
    source_summary = by_method["diagram_fixture_source_table_invariant_audit"]
    assert source_summary["required_check_count"] == 3
    assert source_summary["passed_check_count"] == 2
    assert source_summary["failed_check_count"] == 1
    assert "source-table audit L6a4" in source_summary["notes"]
    assert "uncomputed=homfly" in source_summary["notes"]
    assert "homfly_variant_status=not_computed" in source_summary["notes"]
    assert source_summary["source_table_audit_source_match_resolution_statuses"] == (
        "jones:complete_source_match,"
        "homfly:not_computed,"
        "multivariable_alexander_numerator:complete_source_match"
    )
    assert source_summary["source_table_audit_source_match_resolution_status_count"] == 3
    assert "top_candidates=8" in source_summary["notes"]
    assert "top_unique_sign_patterns=8" in source_summary["notes"]
    assert source_summary["source_table_audit_matched_invariant_count"] == 2
    assert source_summary["source_table_audit_uncomputed_invariant_count"] == 1
    assert source_summary["source_table_audit_max_matched_candidate_count"] == 8
    assert source_summary["source_table_audit_max_matched_unique_sign_pattern_count"] == 8
    assert payload["analysis_source_table_audit_top_candidate_count"] == 8
    assert payload["analysis_source_table_audit_max_matched_candidate_count"] == 8
    assert payload["analysis_source_table_audit_max_matched_unique_sign_pattern_count"] == 8
    assert payload["analysis_source_table_audit_source_match_resolution_status_count"] == 3


def test_cli_imgui_host_payload_generates_signed_pd_role_order_signatures(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "hopf_imgui_signature_candidates.json"
        _write_hopf_imgui_without_role_order(path)

        exit_code = main(
            [
                "imgui-host-payload",
                "--report",
                "homfly",
                "--notation",
                "L2a1",
                "--analysis-signed-pd-role-order-candidates",
                str(path),
                "--analysis-role-order-signatures",
                "--analysis-role-order-signature-max-candidates",
                "2",
                "--analysis-role-order-signature-max-depth",
                "6",
                "--analysis-role-order-signature-max-nodes",
                "1024",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    by_method = {
        summary["source_method"]: summary
        for summary in payload["analysis"]["analysis_summaries"]
    }
    role_summary = by_method["signed_pd_role_order_candidates_report"]
    assert role_summary["required_check_count"] == 16
    assert "signature_evaluated=2" in role_summary["notes"]
    assert "signature_resolution=partially_distinguishes_candidates" in role_summary["notes"]
    assert role_summary["role_order_signature_resolution_status"] == (
        "partially_distinguishes_candidates"
    )
    assert role_summary["role_order_signature_resolution_status_code"] == 5
    assert role_summary["role_order_signature_strict_candidate_count"] == 16
    assert role_summary["role_order_signature_all_strict_candidates_evaluated"] is False
    assert role_summary["role_order_signature_all_strict_candidates_evaluated_count"] == 0
    assert "signature_groups=2" in role_summary["notes"]
    assert "homfly_certified=2" in role_summary["notes"]
    assert "alexander_gcd_certified=2" in role_summary["notes"]
    assert payload["analysis"][
        "analysis_role_order_signature_evaluated_candidate_count"
    ] == 2


def test_cli_imgui_host_payload_generates_source_table_audit(capsys) -> None:
    exit_code = main(
        [
            "imgui-host-payload",
            "--analysis-source-table-invariant-audit",
            "L6a4",
            "--analysis-source-table-max-candidates",
            "8",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    by_method = {
        summary["source_method"]: summary
        for summary in payload["analysis"]["analysis_summaries"]
    }
    source_summary = by_method["diagram_fixture_source_table_invariant_audit"]
    assert source_summary["required_check_count"] == 3
    assert source_summary["passed_check_count"] == 2
    assert source_summary["failed_check_count"] == 1
    assert "uncomputed=homfly" in source_summary["notes"]
    assert "homfly_variant_status=not_computed" in source_summary["notes"]
    assert source_summary["source_table_audit_source_match_resolution_status_count"] == 3
    assert source_summary["source_table_audit_uncomputed_invariant_count"] == 1
    assert source_summary["source_table_audit_max_matched_candidate_count"] == 8
    assert source_summary["source_table_audit_max_matched_unique_sign_pattern_count"] == 8
    assert payload["analysis"]["analysis_source_table_audit_top_candidate_count"] == 8
    assert payload["analysis"]["analysis_source_table_audit_max_matched_candidate_count"] == 8
    assert payload["analysis"]["analysis_source_table_audit_max_matched_unique_sign_pattern_count"] == 8
    assert payload["analysis"][
        "analysis_source_table_audit_source_match_resolution_status_count"
    ] == 3
    assert payload["analysis"]["analysis_failed_check_count"] >= 1


def test_cli_imgui_host_payload_generates_source_table_homfly_mismatch(
    capsys,
) -> None:
    exit_code = main(
        [
            "imgui-host-payload",
            "--analysis-source-table-invariant-audit",
            "L6a4",
            "--analysis-source-table-max-candidates",
            "8",
            "--analysis-source-table-include-homfly",
            "--analysis-source-table-homfly-max-depth",
            "8",
            "--analysis-source-table-homfly-max-nodes",
            "4096",
            "--analysis-source-table-alexander-max-minors",
            "256",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    by_method = {
        summary["source_method"]: summary
        for summary in payload["analysis"]["analysis_summaries"]
    }
    source_summary = by_method["diagram_fixture_source_table_invariant_audit"]
    assert source_summary["required_check_count"] == 3
    assert source_summary["passed_check_count"] == 2
    assert source_summary["failed_check_count"] == 1
    assert "mismatched=homfly" in source_summary["notes"]
    assert "homfly_variant_status=source_variant_seen" in source_summary["notes"]
    assert source_summary["source_table_audit_source_match_resolution_statuses"] == (
        "jones:complete_source_match,"
        "homfly:source_missed_with_candidates,"
        "multivariable_alexander_numerator:complete_source_match"
    )
    assert source_summary["source_table_audit_source_match_resolution_status_count"] == 3
    assert "homfly_variants_seen=4/8" in source_summary["notes"]
    assert "homfly_unit_normalized_variants_seen=4/8" in source_summary["notes"]
    assert "max_matched_candidates=8" in source_summary["notes"]
    assert "max_matched_unique_sign_patterns=8" in source_summary["notes"]
    assert "uncomputed=homfly" not in source_summary["notes"]
    assert source_summary["source_table_audit_mismatched_invariant_count"] == 1
    assert source_summary["source_table_audit_max_matched_candidate_count"] == 8
    assert source_summary["source_table_audit_max_matched_unique_sign_pattern_count"] == 8
    assert source_summary["source_table_audit_homfly_source_variant_count"] == 8
    assert source_summary["source_table_audit_homfly_source_variant_seen_count"] == 4
    assert source_summary["source_table_audit_homfly_source_variant_miss_count"] == 4
    assert source_summary["source_table_audit_homfly_candidate_unique_value_count"] == 3
    assert source_summary["source_table_audit_homfly_candidate_unit_normalized_value_count"] == 3
    assert source_summary["source_table_audit_homfly_variant_resolution_status"] == "source_variant_seen"
    assert source_summary["source_table_audit_homfly_variant_resolution_status_code"] == 4
    assert (
        source_summary[
            "source_table_audit_homfly_source_unit_normalized_variant_count"
        ]
        == 8
    )
    assert (
        source_summary[
            "source_table_audit_homfly_source_unit_normalized_variant_seen_count"
        ]
        == 4
    )
    assert (
        source_summary[
            "source_table_audit_homfly_source_unit_normalized_variant_miss_count"
        ]
        == 4
    )
    assert payload["analysis"][
        "analysis_source_table_audit_mismatched_invariant_count"
    ] == 1
    assert payload["analysis"][
        "analysis_source_table_audit_homfly_source_variant_count"
    ] == 8
    assert payload["analysis"][
        "analysis_source_table_audit_homfly_source_variant_seen_count"
    ] == 4
    assert payload["analysis"][
        "analysis_source_table_audit_homfly_source_variant_miss_count"
    ] == 4
    assert payload["analysis"][
        "analysis_source_table_audit_homfly_source_unit_normalized_variant_count"
    ] == 8
    assert payload["analysis"][
        "analysis_source_table_audit_homfly_source_unit_normalized_variant_seen_count"
    ] == 4
    assert payload["analysis"][
        "analysis_source_table_audit_homfly_source_unit_normalized_variant_miss_count"
    ] == 4
    assert payload["analysis"][
        "analysis_source_table_audit_homfly_candidate_unique_value_count"
    ] == 3
    assert payload["analysis"][
        "analysis_source_table_audit_homfly_candidate_unit_normalized_value_count"
    ] == 3
    assert payload["analysis"][
        "analysis_source_table_audit_source_match_resolution_status_count"
    ] == 3
    assert payload["analysis"]["analysis_failed_check_count"] >= 1


def test_cli_imgui_invariant_status_summary_payload_accepts_pd_reports(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        homfly_path = tmp_path / "homfly_pd_report.json"
        alexander_path = tmp_path / "alexander_pd_report.json"
        homfly_path.write_text(
            json.dumps(
                {
                    "method": "homfly_pd_report",
                    "claim_scope": "iterative_recursive_frontier_exhaustion_for_one_signed_pd_input",
                    "homfly_polynomial": "P",
                    "certified_for_input": True,
                    "skipped": False,
                    "input_certification_evidence": {
                        "frontier_count": 2,
                        "frontier_exhausted": False,
                        "max_crossings": 8,
                        "initial_depth": 0,
                        "max_depth": 4,
                        "max_nodes": 128,
                        "truncated": True,
                        "frontier_reasons": ["max_depth", "max_nodes"],
                    },
                    "notes": ["bounded HOMFLY row"],
                }
            ),
            encoding="utf-8",
        )
        alexander_path.write_text(
            json.dumps(
                {
                    "method": "multivariable_alexander_pd_report",
                    "multivariable_alexander_polynomial": "1",
                    "candidate_polynomials": ["1 - t1", "1 - t2"],
                    "full_invariant_certified": False,
                    "input_certification_evidence": {
                        "bounded_scanned_gcd_certified": True,
                        "complete_scanned_gcd_certified": True,
                        "quotient_gcd_certified": True,
                        "quotient_gcd_polynomial": "1",
                        "quotient_gcd_method": "fox_square_minor_quotient_unit_gcd",
                        "checked_nonzero_minor_count": 4,
                        "failed_nonzero_minor_count": 0,
                        "truncated": False,
                    },
                    "skipped": False,
                    "notes": ["bounded Alexander row"],
                }
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "imgui-invariant-status-summary-payload",
                str(homfly_path),
                str(alexander_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "imgui_invariant_status_payload_from_reports"
    statuses = {status["name"]: status for status in payload["invariant_statuses"]}
    assert statuses["HOMFLY-PT"]["value"] == "P"
    assert "frontier=2; truncated=True" in statuses["HOMFLY-PT"]["notes"]
    assert "frontier_exhausted=False" in statuses["HOMFLY-PT"]["notes"]
    assert (
        "run_caps=max_crossings=8; initial_depth=0; max_depth=4; max_nodes=128"
        in statuses["HOMFLY-PT"]["notes"]
    )
    assert "frontier_reasons=max_depth, max_nodes" in statuses["HOMFLY-PT"]["notes"]
    assert statuses["multi-variable Alexander"]["value"] == "1"
    assert "bounded_scanned_gcd_certified=True" in statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert "complete_scanned_gcd_certified=True" in statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert "quotient_gcd=1 via fox_square_minor_quotient_unit_gcd" in statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert payload["invariant_passed_check_count"] == 2


def test_cli_imgui_invariant_status_summary_payload_preserves_source_replay_reports(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        export_exit = main(
            [
                "fixture-source-invariant-candidates",
                "L6a4",
                "--no-homfly",
                "--no-alexander",
                "--max-candidates",
                "1",
            ]
        )
        exported = json.loads(capsys.readouterr().out)
        replay_path = tmp_path / "source-candidate-signed-pd.json"
        replay_path.write_text(
            json.dumps(exported["candidates"][0]["signed_pd_input"]),
            encoding="utf-8",
        )
        homfly_report_path = tmp_path / "homfly-report.json"
        alexander_report_path = tmp_path / "alexander-report.json"

        homfly_exit = main(
            [
                "homfly-pd",
                str(replay_path),
                "--max-depth",
                "0",
                "--max-nodes",
                "16",
                "-o",
                str(homfly_report_path),
            ]
        )
        capsys.readouterr()

        alexander_exit = main(
            [
                "multivariable-alexander-pd",
                str(replay_path),
                "--max-matrix-size",
                "6",
                "--max-minors",
                "256",
                "-o",
                str(alexander_report_path),
            ]
        )
        capsys.readouterr()

        summary_exit = main(
            [
                "imgui-invariant-status-summary-payload",
                str(homfly_report_path),
                str(alexander_report_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert export_exit == 0
    assert homfly_exit == 0
    assert alexander_exit == 0
    assert summary_exit == 0
    assert payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert payload["invariant_source_candidate_replay_count"] == 2
    assert payload["invariant_source_candidate_replay_source_notations"] == "L6a4"
    assert payload["invariant_source_candidate_replay_sign_count"] == 12
    assert payload["invariant_source_candidate_replay_role_order_count"] == 12
    rows = {row["name"]: row for row in payload["invariant_statuses"]}
    assert rows["HOMFLY-PT"]["source_candidate_replay_present"] is True
    assert "source_candidate_replay=claim_scope=source_gauss_matched_signed_pd_candidate_replay" in rows[
        "HOMFLY-PT"
    ]["notes"]
    assert rows["multi-variable Alexander"][
        "source_candidate_replay_source_url"
    ] == "https://katlas.org/wiki/L6a4"
    assert rows["multi-variable Alexander"]["value"] == (
        "1 - t3 - t2 + t2*t3 - t1 + t1*t3 + t1*t2 - t1*t2*t3"
    )


def test_cli_imgui_invariant_status_summary_payload_accepts_improved_alexander_result(
    capsys,
) -> None:
    improved_report = {
        "method": "multivariable_alexander_improve_scanned_gcd_result",
        "source_polynomial": "1 - t1",
        "improved_candidate_polynomial": "1 - t2 - t1 + t1*t2",
        "accepted": True,
        "skipped": False,
        "result": {
            "method": (
                "synthetic_nonmaximal_scanned_gcd_candidate"
                "_improved_by_scanned_quotient_gcd"
            ),
            "multivariable_alexander_polynomial": "1 - t2 - t1 + t1*t2",
        },
        "improved_audit": {
            "candidate_is_exact_scanned_gcd": True,
            "complete_scanned_gcd_certified": True,
            "quotient_gcd_certified": True,
            "quotient_gcd_polynomial": "1",
            "quotient_gcd_method": "fox_square_minor_quotient_unit_gcd",
            "checked_nonzero_minor_count": 2,
            "failed_nonzero_minor_count": 0,
        },
        "notes": ["improved result is bounded scanned-minor evidence"],
    }
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "alexander-improved.json"
        path.write_text(json.dumps(improved_report), encoding="utf-8")

        exit_code = main(["imgui-invariant-status-summary-payload", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert payload["invariant_passed_check_count"] == 1
    status = payload["invariant_statuses"][0]
    assert status["name"] == "multi-variable Alexander improved scanned gcd"
    assert status["value"] == "1 - t2 - t1 + t1*t2"
    assert "source_polynomial=1 - t1" in status["notes"]
    assert "exact_scanned_gcd=True" in status["notes"]


def test_cli_imgui_invariant_status_summary_payload_accepts_alexander_direct_audits(
    capsys,
) -> None:
    minor_audit = _synthetic_alexander_minor_divisibility_audit()
    scanned_gcd_audit = {
        "method": "multivariable_alexander_scanned_gcd_audit",
        "claim_scope": "bounded_scanned_fox_minor_exact_gcd",
        "multivariable_alexander_polynomial": "1",
        "candidate_is_exact_scanned_gcd": True,
        "complete_scanned_gcd_certified": True,
        "quotient_gcd_certified": True,
        "quotient_gcd_polynomial": "1",
        "quotient_gcd_method": "fox_square_minor_quotient_unit_gcd",
        "checked_nonzero_minor_count": 2,
        "failed_nonzero_minor_count": 0,
        "skipped": False,
    }
    input_evidence = _synthetic_alexander_input_certification_evidence()
    wirtinger_fox_audit = {
        "method": "multivariable_alexander_wirtinger_fox_audit",
        "claim_scope": "input_wirtinger_presentation_and_fox_matrix_consistency",
        "presentation_valid": True,
        "wirtinger_relation_shape_valid": True,
        "wirtinger_relation_shape_invalid_count": 0,
        "wirtinger_relation_shape_witnesses": [],
        "wirtinger_generator_component_coverage_complete": True,
        "wirtinger_generator_component_counts": [
            {"component": 0, "generator_count": 1},
            {"component": 1, "generator_count": 1},
        ],
        "fox_jacobian_valid": True,
        "fox_square_minor_scan_valid": True,
        "input_chain_consistent": True,
        "relation_count": 2,
        "generator_count": 2,
        "scanned_minor_count": 2,
        "skipped": False,
    }
    with workspace_tempdir() as tmp_path:
        paths = []
        for filename, report in (
            ("alexander-minor-divisibility-audit.json", minor_audit),
            ("alexander-scanned-gcd-audit.json", scanned_gcd_audit),
            ("alexander-input-evidence.json", input_evidence),
            ("alexander-wirtinger-fox-audit.json", wirtinger_fox_audit),
        ):
            path = tmp_path / filename
            path.write_text(json.dumps(report), encoding="utf-8")
            paths.append(path)

        exit_code = main(
            [
                "imgui-invariant-status-summary-payload",
                *(str(path) for path in paths),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert payload["invariant_status_count"] == 4
    assert payload["invariant_passed_check_count"] == 4
    statuses = {status["name"]: status for status in payload["invariant_statuses"]}
    assert statuses["multi-variable Alexander minor divisibility"]["value"] == "1 - t1"
    assert "all_nonzero_minors_divisible=True" in statuses[
        "multi-variable Alexander minor divisibility"
    ]["notes"]
    assert statuses["multi-variable Alexander scanned gcd"]["value"] == "1"
    assert "exact_scanned_gcd=True" in statuses[
        "multi-variable Alexander scanned gcd"
    ]["notes"]
    assert statuses["multi-variable Alexander input evidence"]["value"] == "1"
    assert "bounded_scanned_gcd_certified=True" in statuses[
        "multi-variable Alexander input evidence"
    ]["notes"]
    assert statuses["multi-variable Alexander Wirtinger/Fox"]["value"] == "consistent"
    assert "input_chain_consistent=True" in statuses[
        "multi-variable Alexander Wirtinger/Fox"
    ]["notes"]


def test_cli_imgui_invariant_status_summary_payload_accepts_homfly_direct_audits(
    capsys,
) -> None:
    input_evidence = _synthetic_homfly_input_certification_evidence()
    terminal_audit = {
        "method": "homfly_terminal_reduction_audit",
        "claim_scope": (
            "exact_sum_of_recorded_terminal_and_memoized_reduction_contributions"
        ),
        "homfly_polynomial": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
        "terminal_contribution_sum": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
        "matched_result": True,
        "terminal_reduction_count": 3,
        "reduction_contribution_count": 4,
        "parsed_reduction_contribution_count": 4,
        "unparsed_reduction_contribution_count": 0,
        "reduction_contribution_witness_count": 2,
        "reduction_contribution_witness_limit": 8,
        "reduction_contribution_witnesses_truncated": False,
        "first_reduction_contribution_witness": {
            "index": 0,
            "reduction_kind": "terminal",
            "contribution": "1",
        },
        "reduction_contribution_witnesses": [
            {"index": 0, "reduction_kind": "terminal", "contribution": "1"},
            {"index": 1, "reduction_kind": "memoized_subtree", "contribution": "a"},
        ],
        "reduction_contribution_witness_consistency": {
            "matched": True,
            "mismatch_count": 0,
        },
        "failed_terminal_reduction_count": 0,
        "frontier_count": 0,
        "truncated": False,
        "skipped": False,
    }
    skein_audit = _synthetic_homfly_skein_identity_audit()

    with workspace_tempdir() as tmp_path:
        paths = []
        for filename, report in (
            ("homfly-input-evidence.json", input_evidence),
            ("homfly-terminal-reduction-audit.json", terminal_audit),
            ("homfly-skein-identity-audit.json", skein_audit),
        ):
            path = tmp_path / filename
            path.write_text(json.dumps(report), encoding="utf-8")
            paths.append(path)

        exit_code = main(
            [
                "imgui-invariant-status-summary-payload",
                *(str(path) for path in paths),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert payload["invariant_status_count"] == 3
    assert payload["invariant_passed_check_count"] == 3
    statuses = {status["name"]: status for status in payload["invariant_statuses"]}
    assert statuses["HOMFLY-PT input evidence"]["value"] == (
        "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z"
    )
    assert "certified_for_input=True" in statuses[
        "HOMFLY-PT input evidence"
    ]["notes"]
    assert "terminal_contribution_skipped=False" in statuses[
        "HOMFLY-PT input evidence"
    ]["notes"]
    assert "terminal_contribution_matched=True" in statuses[
        "HOMFLY-PT input evidence"
    ]["notes"]
    assert statuses["HOMFLY-PT terminal reduction"]["value"] == (
        "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z"
    )
    terminal_status = statuses["HOMFLY-PT terminal reduction"]
    assert "matched_result=True" in terminal_status["notes"]
    assert (
        "homfly_reduction_contribution_witnesses=witnesses=2/8"
        in terminal_status["notes"]
    )
    assert terminal_status["homfly_reduction_contribution_count"] == 4
    assert terminal_status["homfly_reduction_contribution_witness_count"] == 2
    assert terminal_status["homfly_reduction_contribution_witness_limit"] == 8
    assert (
        terminal_status[
            "homfly_reduction_contribution_consistency_matched_count"
        ]
        == 1
    )
    assert payload["invariant_homfly_reduction_contribution_count"] == 8
    assert payload["invariant_homfly_reduction_contribution_witness_count"] == 4
    assert payload["invariant_homfly_reduction_contribution_witness_limit"] == 16
    assert (
        payload["invariant_homfly_reduction_contribution_consistency_matched_count"]
        == 2
    )
    assert statuses["HOMFLY-PT skein identity"]["value"] == "matched"
    assert "checked_crossings=2" in statuses["HOMFLY-PT skein identity"]["notes"]


def test_cli_imgui_analysis_summary_payload_accepts_improved_alexander_result(
    capsys,
) -> None:
    improved_report = {
        "method": "multivariable_alexander_improve_scanned_gcd_result",
        "source_polynomial": "1 - t1",
        "improved_candidate_polynomial": "1 - t2 - t1 + t1*t2",
        "accepted": True,
        "skipped": False,
        "result": {
            "method": (
                "synthetic_nonmaximal_scanned_gcd_candidate"
                "_improved_by_scanned_quotient_gcd"
            ),
            "multivariable_alexander_polynomial": "1 - t2 - t1 + t1*t2",
        },
        "improved_audit": {
            "candidate_is_exact_scanned_gcd": True,
            "complete_scanned_gcd_certified": True,
            "complete_combination_scan": True,
            "nonzero_minor_coverage_complete": True,
            "truncated": False,
            "quotient_gcd_certified": True,
            "quotient_gcd_polynomial": "1",
            "quotient_gcd_method": "fox_square_minor_quotient_unit_gcd",
            "checked_nonzero_minor_count": 2,
            "failed_nonzero_minor_count": 0,
            "scanned_minor_count": 2,
            "division_record_count": 2,
        },
        "notes": ["improved result is bounded scanned-minor evidence"],
    }
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "alexander-improved.json"
        path.write_text(json.dumps(improved_report), encoding="utf-8")

        exit_code = main(["imgui-analysis-summary-payload", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 4
    assert payload["analysis_passed_check_count"] == 4
    assert payload["analysis_bounded_scanned_gcd_checked_nonzero_minor_count"] == 2
    assert payload["analysis_bounded_scanned_gcd_complete_certified_count"] == 1
    summary = payload["analysis_summaries"][0]
    assert summary["name"] == "multi-variable Alexander improved scanned gcd"
    assert summary["claim_scope"] == "bounded_scanned_fox_minor_improved_candidate"
    assert "improved_candidate=1 - t2 - t1 + t1*t2" in summary["notes"]


def test_cli_imgui_analysis_summary_payload_accepts_alexander_audit_reports(
    capsys,
) -> None:
    scanned_gcd_audit = {
        "method": "multivariable_alexander_scanned_gcd_audit",
        "claim_scope": "bounded_scanned_fox_minor_exact_gcd",
        "candidate_is_exact_scanned_gcd": True,
        "complete_scanned_gcd_certified": True,
        "complete_combination_scan": True,
        "nonzero_minor_coverage_complete": True,
        "truncated": False,
        "quotient_gcd_certified": True,
        "quotient_gcd_polynomial": "1",
        "quotient_gcd_method": "fox_square_minor_quotient_unit_gcd",
        "checked_nonzero_minor_count": 2,
        "failed_nonzero_minor_count": 0,
        "scanned_minor_count": 2,
        "division_record_count": 2,
        "skipped": False,
    }
    wirtinger_fox_audit = {
        "method": "multivariable_alexander_wirtinger_fox_audit",
        "claim_scope": "input_wirtinger_presentation_and_fox_matrix_consistency",
        "presentation_valid": True,
        "wirtinger_relation_shape_valid": True,
        "wirtinger_relation_shape_invalid_count": 0,
        "wirtinger_relation_shape_witnesses": [],
        "wirtinger_generator_component_coverage_complete": True,
        "wirtinger_generator_component_counts": [
            {"component": 0, "generator_count": 1},
            {"component": 1, "generator_count": 1},
        ],
        "fox_jacobian_valid": True,
        "fox_square_minor_scan_valid": True,
        "input_chain_consistent": True,
        "relation_count": 2,
        "generator_count": 2,
        "scanned_minor_count": 2,
        "invalid_minor_reference_count": 0,
        "invalid_normalization_count": 0,
        "invalid_minor_reference_witness_count": 0,
        "invalid_minor_reference_witness_limit": 8,
        "invalid_minor_reference_witness_truncated": False,
        "invalid_minor_reference_witnesses": [],
        "invalid_normalization_witness_count": 0,
        "invalid_normalization_witness_limit": 8,
        "invalid_normalization_witness_truncated": False,
        "invalid_normalization_witnesses": [],
        "complete_combination_scan": True,
        "truncated": False,
        "skipped": False,
    }
    with workspace_tempdir() as tmp_path:
        scanned_path = tmp_path / "alexander-scanned-gcd-audit.json"
        wirtinger_path = tmp_path / "alexander-wirtinger-fox-audit.json"
        scanned_path.write_text(json.dumps(scanned_gcd_audit), encoding="utf-8")
        wirtinger_path.write_text(json.dumps(wirtinger_fox_audit), encoding="utf-8")

        exit_code = main(
            [
                "imgui-analysis-summary-payload",
                str(scanned_path),
                str(wirtinger_path),
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["analysis_summary_count"] == 2
    assert payload["analysis_accepted_summary_count"] == 2
    assert payload["analysis_rejected_summary_count"] == 0
    assert payload["analysis_certified_summary_count"] == 0
    assert payload["analysis_uncertified_summary_count"] == 2
    assert payload["analysis_failed_summary_count"] == 0
    assert payload["analysis_required_check_count"] == 6
    assert payload["analysis_passed_check_count"] == 6
    assert payload["analysis_failed_check_count"] == 0
    assert payload["analysis_bounded_scanned_gcd_checked_nonzero_minor_count"] == 2
    assert payload["analysis_bounded_scanned_gcd_complete_certified_count"] == 1
    assert payload["analysis_wirtinger_fox_scanned_minor_count"] == 2
    assert payload["analysis_wirtinger_fox_relation_shape_witness_count"] == 0
    assert (
        payload[
            "analysis_wirtinger_fox_generator_component_coverage_complete_count"
        ]
        == 1
    )
    summaries = {row["source_method"]: row for row in payload["analysis_summaries"]}
    assert summaries["multivariable_alexander_scanned_gcd_audit"][
        "accepted"
    ] is True
    wirtinger_summary = summaries["multivariable_alexander_wirtinger_fox_audit"]
    assert wirtinger_summary["accepted"] is True
    assert (
        "fox_minor_invalid_witnesses=reference=0/8"
        in wirtinger_summary["notes"]
    )
    assert "wirtinger_relation_shape=valid=True" in wirtinger_summary["notes"]
    assert "wirtinger_generator_components=coverage_complete=True" in (
        wirtinger_summary["notes"]
    )


def test_cli_imgui_analysis_summary_payload_accepts_alexander_minor_divisibility_audit(
    capsys,
) -> None:
    audit = _synthetic_alexander_minor_divisibility_audit()

    with workspace_tempdir() as tmp_path:
        path = tmp_path / "alexander-minor-divisibility-audit.json"
        path.write_text(json.dumps(audit), encoding="utf-8")

        exit_code = main(["imgui-analysis-summary-payload", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 3
    assert payload["analysis_passed_check_count"] == 3
    assert payload["analysis_failed_check_count"] == 0
    assert payload["analysis_bounded_scanned_gcd_checked_nonzero_minor_count"] == 2
    assert payload["analysis_bounded_scanned_gcd_failed_nonzero_minor_count"] == 0
    assert payload["analysis_bounded_scanned_gcd_division_record_count"] == 2
    assert payload["analysis_bounded_scanned_gcd_complete_scan_count"] == 1
    summary = payload["analysis_summaries"][0]
    assert summary["source_method"] == (
        "multivariable_alexander_minor_divisibility_audit"
    )
    assert summary["accepted"] is True
    assert "all_nonzero_minors_divisible=True" in summary["notes"]
    assert "full_invariant_certified=False" in summary["notes"]


def test_cli_imgui_analysis_summary_payload_accepts_alexander_input_evidence(
    capsys,
) -> None:
    evidence = _synthetic_alexander_input_certification_evidence()

    with workspace_tempdir() as tmp_path:
        path = tmp_path / "alexander-input-certification-evidence.json"
        path.write_text(json.dumps(evidence), encoding="utf-8")

        exit_code = main(["imgui-analysis-summary-payload", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 4
    assert payload["analysis_passed_check_count"] == 4
    assert payload["analysis_failed_check_count"] == 0
    assert payload["analysis_bounded_scanned_gcd_scanned_minor_count"] == 2
    assert payload["analysis_wirtinger_fox_relation_count"] == 2
    assert payload["analysis_wirtinger_fox_relation_shape_witness_count"] == 0
    assert (
        payload[
            "analysis_wirtinger_fox_generator_component_coverage_complete_count"
        ]
        == 1
    )
    summary = payload["analysis_summaries"][0]
    assert summary["source_method"] == (
        "multivariable_alexander_input_certification_evidence"
    )
    assert summary["accepted"] is True
    assert "wirtinger_fox_input_chain_consistent=True" in summary["notes"]
    assert "wirtinger_relation_shape=valid=True" in summary["notes"]


def test_cli_imgui_analysis_summary_payload_accepts_homfly_terminal_audit(
    capsys,
) -> None:
    audit = {
        "method": "homfly_terminal_reduction_audit",
        "claim_scope": (
            "exact_sum_of_recorded_terminal_and_memoized_reduction_contributions"
        ),
        "evaluation_method": "certified_iterative_recursive_homfly",
        "homfly_polynomial": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
        "terminal_contribution_sum": "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
        "terminal_reduction_count": 3,
        "memoized_reduction_count": 1,
        "reduction_contribution_count": 4,
        "parsed_reduction_contribution_count": 4,
        "unparsed_reduction_contribution_count": 0,
        "reduction_contribution_witness_count": 2,
        "reduction_contribution_witness_limit": 8,
        "reduction_contribution_witnesses_truncated": False,
        "first_reduction_contribution_witness": {
            "index": 0,
            "reduction_kind": "terminal",
            "contribution": "1",
        },
        "reduction_contribution_witnesses": [
            {"index": 0, "reduction_kind": "terminal", "contribution": "1"},
            {"index": 1, "reduction_kind": "memoized_subtree", "contribution": "a"},
        ],
        "reduction_contribution_witness_consistency": {
            "matched": True,
            "mismatch_count": 0,
        },
        "failed_terminal_reduction_count": 0,
        "cache_hits": 1,
        "frontier_count": 0,
        "truncated": False,
        "matched_result": True,
        "skipped": False,
    }

    with workspace_tempdir() as tmp_path:
        path = tmp_path / "homfly-terminal-reduction-audit.json"
        path.write_text(json.dumps(audit), encoding="utf-8")

        exit_code = main(["imgui-analysis-summary-payload", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 3
    assert payload["analysis_passed_check_count"] == 3
    assert payload["analysis_failed_check_count"] == 0
    assert (
        payload[
            "analysis_input_certification_terminal_contribution_matched_count"
        ]
        == 1
    )
    assert payload["analysis_homfly_reduction_contribution_count"] == 4
    assert payload["analysis_homfly_reduction_contribution_witness_count"] == 2
    assert payload["analysis_homfly_reduction_contribution_witness_limit"] == 8
    assert (
        payload["analysis_homfly_reduction_contribution_consistency_matched_count"]
        == 1
    )
    summary = payload["analysis_summaries"][0]
    assert summary["source_method"] == "homfly_terminal_reduction_audit"
    assert summary["accepted"] is True
    assert summary["homfly_reduction_contribution_count"] == 4
    assert summary["homfly_reduction_contribution_witness_count"] == 2
    assert summary["homfly_reduction_contribution_witness_limit"] == 8
    assert summary["homfly_reduction_contribution_consistency_matched_count"] == 1
    assert "terminal_reductions=3" in summary["notes"]
    assert (
        "homfly_reduction_contribution_witnesses=witnesses=2/8"
        in summary["notes"]
    )


def test_cli_imgui_analysis_summary_payload_accepts_homfly_input_evidence(
    capsys,
) -> None:
    evidence = _synthetic_homfly_input_certification_evidence()

    with workspace_tempdir() as tmp_path:
        path = tmp_path / "homfly-input-certification-evidence.json"
        path.write_text(json.dumps(evidence), encoding="utf-8")

        exit_code = main(["imgui-analysis-summary-payload", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 4
    assert payload["analysis_passed_check_count"] == 4
    assert payload["analysis_failed_check_count"] == 0
    assert payload["analysis_input_certification_recursion_node_count"] == 12
    assert payload["analysis_homfly_reduction_contribution_count"] == 4
    assert payload["analysis_homfly_reduction_contribution_witness_count"] == 2
    assert payload["analysis_homfly_reduction_contribution_witness_limit"] == 8
    summary = payload["analysis_summaries"][0]
    assert summary["source_method"] == "homfly_input_certification_evidence"
    assert summary["accepted"] is True
    assert summary["homfly_reduction_contribution_count"] == 4
    assert summary["homfly_reduction_contribution_witness_count"] == 2
    assert summary["homfly_reduction_contribution_consistency_matched_count"] == 1
    assert "terminal_contribution_skipped=False" in summary["notes"]
    assert "terminal_contribution_matched=True" in summary["notes"]


def test_cli_imgui_analysis_summary_payload_accepts_homfly_skein_identity_audit(
    capsys,
) -> None:
    audit = _synthetic_homfly_skein_identity_audit()

    with workspace_tempdir() as tmp_path:
        path = tmp_path / "homfly-skein-identity-audit.json"
        path.write_text(json.dumps(audit), encoding="utf-8")

        exit_code = main(["imgui-analysis-summary-payload", str(path)])
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["analysis_summary_count"] == 1
    assert payload["analysis_required_check_count"] == 2
    assert payload["analysis_passed_check_count"] == 2
    assert payload["analysis_failed_check_count"] == 0
    summary = payload["analysis_summaries"][0]
    assert summary["source_method"] == "homfly_skein_identity_audit"
    assert summary["accepted"] is True
    assert "skein_matched=2" in summary["notes"]


def test_cli_imgui_signed_pd_invariant_status_payload_computes_both_rows(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "hopf_imgui_role_order.json"
        status_path = tmp_path / "hopf_imgui_status.json"
        _write_hopf_imgui_with_role_order(path)

        exit_code = main(
            [
                "imgui-signed-pd-invariant-status-payload",
                str(path),
                "--max-depth",
                "8",
                "--max-nodes",
                "2048",
                "-o",
                str(status_path),
            ]
        )
        capsys.readouterr()
        assert status_path.exists()
        payload = json.loads(status_path.read_text(encoding="utf-8"))
        _assert_strict_json_serializable(payload)

    assert exit_code == 0
    assert payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert payload["invariant_status_count"] == 2
    assert payload["invariant_passed_check_count"] == 2
    assert payload["invariant_signed_pd_role_order_metadata_count"] == 2
    assert payload["invariant_signed_pd_role_order_count"] == 4
    assert payload["invariant_signed_pd_role_order_explicit_count"] == 4
    statuses = {status["name"]: status for status in payload["invariant_statuses"]}
    assert statuses["HOMFLY-PT"]["value"] == "-a^-3*z^-1 + a^-1*z^-1 + a^-1*z"
    assert statuses["HOMFLY-PT"]["skipped"] is False
    assert statuses["HOMFLY-PT"]["signed_pd_role_order_metadata_present"] is True
    assert statuses["HOMFLY-PT"]["signed_pd_role_order_count"] == 2
    assert statuses["HOMFLY-PT"]["signed_pd_role_order_explicit_count"] == 2
    assert "signed_pd_role_order_provenance=role_orders=2; explicit=2" in (
        statuses["HOMFLY-PT"]["notes"]
    )
    assert "frontier_exhausted=True" in statuses["HOMFLY-PT"]["notes"]
    assert (
        "run_caps=max_crossings=8; initial_depth=0; max_depth=8; max_nodes=2048"
        in statuses["HOMFLY-PT"]["notes"]
    )
    assert "terminal_contribution_skipped=False" in statuses["HOMFLY-PT"]["notes"]
    assert "terminal_contribution_matched=True" in statuses["HOMFLY-PT"]["notes"]
    assert statuses["multi-variable Alexander"]["value"] == "1"
    assert statuses["multi-variable Alexander"]["skipped"] is False
    assert "bounded_scanned_gcd_certified=True" in statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert "complete_scanned_gcd_certified=True" in statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert "quotient_gcd_certified=True" in statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert "admissible_minor_scan=expected=" in statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert "rows_nonzero=" in statuses["multi-variable Alexander"]["notes"]
    assert "columns_nonzero=" in statuses["multi-variable Alexander"]["notes"]
    assert (
        statuses["multi-variable Alexander"]["signed_pd_role_order_metadata_present"]
        is True
    )
    assert statuses["multi-variable Alexander"]["signed_pd_role_order_count"] == 2
    assert (
        statuses["multi-variable Alexander"]["signed_pd_role_order_explicit_count"]
        == 2
    )
    assert "signed_pd_role_order_provenance=role_orders=2; explicit=2" in statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert payload["source_signed_pd"].endswith("hopf_imgui_role_order.json")
    assert payload["signed_pd_revision"] == 42


def test_cli_imgui_invariant_status_payload_leaves_revision_unset_for_conflict(
    capsys,
) -> None:
    homfly_report = {
        "method": "homfly_pd_report",
        "input": {"signed_pd_revision": 17},
        "homfly_polynomial": None,
        "skipped": True,
        "result": None,
        "notes": ["synthetic HOMFLY skip"],
    }
    alexander_report = {
        "method": "multivariable_alexander_pd_report",
        "source_signed_pd_revision": 18,
        "signed_pd_revision": 18,
        "multivariable_alexander_polynomial": "1",
        "skipped": False,
        "result": {"method": "synthetic"},
        "notes": ["synthetic Alexander result"],
    }

    with workspace_tempdir() as tmp_path:
        homfly_path = tmp_path / "homfly-revision-17.json"
        alexander_path = tmp_path / "alexander-revision-18.json"
        homfly_path.write_text(json.dumps(homfly_report), encoding="utf-8")
        alexander_path.write_text(json.dumps(alexander_report), encoding="utf-8")

        summary_exit = main(
            [
                "imgui-invariant-status-summary-payload",
                str(homfly_path),
                str(alexander_path),
            ]
        )
        summary_payload = json.loads(capsys.readouterr().out)

        host_exit = main(
            [
                "imgui-host-payload",
                "--invariant-report-json",
                str(homfly_path),
                "--invariant-report-json",
                str(alexander_path),
            ]
        )
        host_payload = json.loads(capsys.readouterr().out)

    assert summary_exit == 0
    assert host_exit == 0
    assert "signed_pd_revision" not in summary_payload
    assert "signed_pd_revision" not in host_payload["invariants"]

    statuses = {
        status["name"]: status for status in summary_payload["invariant_statuses"]
    }
    assert statuses["HOMFLY-PT"]["value"] == "skipped"
    assert statuses["HOMFLY-PT"]["skipped"] is True
    assert statuses["multi-variable Alexander"]["value"] == "1"
    assert statuses["multi-variable Alexander"]["skipped"] is False


def test_cli_imgui_signed_pd_auto_role_order_keeps_zero_crossing_rows(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "unknot_imgui_auto_role_order.json"
        path.write_text(
            json.dumps(
                {
                    "name": "unknot-imgui-auto-role-order",
                    "component_count": 1,
                    "crossings": [],
                    "signed_pd_revision": 7,
                }
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "imgui-signed-pd-invariant-status-payload",
                str(path),
                "--auto-role-order",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert payload["invariant_status_count"] == 2
    assert payload["invariant_signed_pd_role_order_metadata_count"] == 2
    assert payload["invariant_signed_pd_role_order_count"] == 0
    assert payload["invariant_signed_pd_role_order_explicit_count"] == 0
    assert payload["invariant_signed_pd_auto_role_order_present_count"] == 2
    assert payload["invariant_signed_pd_auto_role_order_requested_count"] == 2
    assert payload["invariant_signed_pd_auto_role_order_applied_count"] == 0
    assert payload["invariant_signed_pd_auto_role_order_not_needed_count"] == 2
    assert payload["invariant_signed_pd_auto_role_order_unique_applied_count"] == 0
    assert payload["invariant_signed_pd_auto_role_order_ambiguous_count"] == 0
    assert payload["invariant_signed_pd_auto_role_order_no_strict_candidate_count"] == 0
    assert payload["invariant_signed_pd_auto_role_order_candidate_count"] == 0
    assert payload["invariant_signed_pd_auto_role_order_strict_candidate_count"] == 0
    assert payload["signed_pd_revision"] == 7
    statuses = {status["name"]: status for status in payload["invariant_statuses"]}
    assert statuses["HOMFLY-PT"]["value"] == "1"
    assert statuses["HOMFLY-PT"]["skipped"] is False
    assert statuses["HOMFLY-PT"]["signed_pd_role_order_metadata_present"] is True
    assert statuses["HOMFLY-PT"]["signed_pd_role_order_count"] == 0
    assert statuses["HOMFLY-PT"]["signed_pd_role_order_explicit_count"] == 0
    assert statuses["HOMFLY-PT"]["signed_pd_auto_role_order_present"] is True
    assert statuses["HOMFLY-PT"]["signed_pd_auto_role_order_requested"] is True
    assert statuses["HOMFLY-PT"]["signed_pd_auto_role_order_applied"] is False
    assert statuses["HOMFLY-PT"]["signed_pd_auto_role_order_status"] == "not_needed"
    assert statuses["HOMFLY-PT"]["signed_pd_auto_role_order_candidate_count"] == 0
    assert (
        statuses["HOMFLY-PT"]["signed_pd_auto_role_order_strict_candidate_count"]
        == 0
    )
    assert "signed_pd_auto_role_order=status=not_needed; applied=False" in (
        statuses["HOMFLY-PT"]["notes"]
    )
    assert "zero-crossing unlink normalization is closed" in statuses["HOMFLY-PT"][
        "notes"
    ]
    assert statuses["multi-variable Alexander"]["value"] == "1"
    assert statuses["multi-variable Alexander"]["skipped"] is False
    assert (
        statuses["multi-variable Alexander"]["signed_pd_role_order_metadata_present"]
        is True
    )
    assert statuses["multi-variable Alexander"]["signed_pd_role_order_count"] == 0
    assert (
        statuses["multi-variable Alexander"]["signed_pd_role_order_explicit_count"]
        == 0
    )
    assert (
        statuses["multi-variable Alexander"]["signed_pd_auto_role_order_present"]
        is True
    )
    assert (
        statuses["multi-variable Alexander"]["signed_pd_auto_role_order_requested"]
        is True
    )
    assert (
        statuses["multi-variable Alexander"]["signed_pd_auto_role_order_applied"]
        is False
    )
    assert (
        statuses["multi-variable Alexander"]["signed_pd_auto_role_order_status"]
        == "not_needed"
    )
    assert (
        statuses["multi-variable Alexander"][
            "signed_pd_auto_role_order_candidate_count"
        ]
        == 0
    )
    assert (
        statuses["multi-variable Alexander"][
            "signed_pd_auto_role_order_strict_candidate_count"
        ]
        == 0
    )
    assert "signed_pd_auto_role_order=status=not_needed; applied=False" in statuses[
        "multi-variable Alexander"
    ]["notes"]
    assert "zero_crossing_unlink_certified=True" in statuses[
        "multi-variable Alexander"
    ]["notes"]

def test_cli_auto_role_order_skips_ambiguous_imgui_payload(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "hopf_imgui_auto_ambiguous.json"
        path.write_text(
            json.dumps(
                {
                    "diagram": {
                        "name": "hopf-imgui-auto-ambiguous",
                        "component_count": 2,
                        "crossings": [
                            {"edge_labels": [4, 1, 2, 3], "sign": 1},
                            {"edge_labels": [2, 3, 4, 1], "sign": -1},
                        ],
                    },
                    "variables": ["t1", "t2"],
                    "signed_pd_revision": 29,
                }
            ),
            encoding="utf-8",
        )

        homfly_exit = main(["homfly-pd", str(path), "--auto-role-order"])
        homfly = json.loads(capsys.readouterr().out)

        alexander_exit = main(
            ["multivariable-alexander-pd", str(path), "--auto-role-order"]
        )
        alexander = json.loads(capsys.readouterr().out)

        homfly_report_path = tmp_path / "homfly-auto-role-order-ambiguous.json"
        alexander_report_path = tmp_path / "alexander-auto-role-order-ambiguous.json"
        homfly_report_path.write_text(json.dumps(homfly), encoding="utf-8")
        alexander_report_path.write_text(json.dumps(alexander), encoding="utf-8")

        imgui_exit = main(
            [
                "imgui-invariant-status-summary-payload",
                str(homfly_report_path),
                str(alexander_report_path),
            ]
        )
        imgui_payload = json.loads(capsys.readouterr().out)

    assert homfly_exit == 0
    assert homfly["method"] == "homfly_pd_report"
    assert homfly["skipped"] is True
    assert homfly["result"] is None
    assert homfly["homfly_polynomial"] is None
    assert homfly["input"]["signed_pd_revision"] == 29
    assert homfly["input"]["auto_role_order"]["requested"] is True
    assert homfly["input"]["auto_role_order"]["applied"] is False
    assert homfly["input"]["auto_role_order"]["status"] == "ambiguous"
    assert homfly["input"]["auto_role_order"]["strict_candidate_count"] > 1
    assert homfly["input_certification_evidence"]["certification_blockers"] == [
        "role_order_or_convention_ambiguity_skipped",
    ]
    _assert_cli_blocker_detail_codes(
        homfly["input_certification_evidence"],
        "certification_blocker_details",
        ["role_order_or_convention_ambiguity_skipped"],
    )
    assert homfly["input_certification_evidence"][
        "certification_blocker_details"
    ][0]["scope"] == "signed_pd_input"
    _assert_cli_homfly_pd_top_level_blocker_fields_match_evidence(homfly)
    assert homfly["certification_blockers"] == [
        "role_order_or_convention_ambiguity_skipped",
    ]
    assert homfly["certification_blocker_count"] == 1
    _assert_cli_blocker_detail_codes(
        homfly,
        "certification_blocker_details",
        ["role_order_or_convention_ambiguity_skipped"],
    )
    assert homfly["certification_blocker_detail_count"] == 1
    assert homfly["homfly_completion_blockers"] == [
        "full_table_normalization_not_certified",
        "arbitrary_diagram_coverage_not_certified",
    ]
    assert homfly["homfly_completion_blocker_count"] == 2
    _assert_cli_blocker_detail_codes(
        homfly["input_certification_evidence"],
        "homfly_completion_blocker_details",
        [
            "full_table_normalization_not_certified",
            "arbitrary_diagram_coverage_not_certified",
        ],
    )
    _assert_cli_blocker_detail_codes(
        homfly,
        "homfly_completion_blocker_details",
        [
            "full_table_normalization_not_certified",
            "arbitrary_diagram_coverage_not_certified",
        ],
    )
    assert homfly["homfly_completion_blocker_detail_count"] == 2
    gate = homfly["input_certification_evidence"][
        "arbitrary_diagram_completion_gate"
    ]
    _assert_cli_homfly_arbitrary_completion_gate(gate)
    assert gate["evidence_scope"] == "single_signed_pd_input"
    assert gate["convention_blockers"] == [
        "role_order_or_convention_ambiguity_skipped",
    ]
    assert gate["certification_blockers"] == [
        "role_order_or_convention_ambiguity_skipped",
    ]
    assert homfly["homfly_completion_blocker_details"][1]["witness"] == gate

    assert alexander_exit == 0
    assert alexander["method"] == "multivariable_alexander_pd_report"
    assert alexander["skipped"] is True
    assert alexander["result"] is None
    assert alexander["multivariable_alexander_polynomial"] is None
    assert alexander["input"]["signed_pd_revision"] == 29
    assert alexander["input"]["auto_role_order"]["requested"] is True
    assert alexander["input"]["auto_role_order"]["applied"] is False
    assert alexander["input"]["auto_role_order"]["status"] == "ambiguous"
    assert alexander["input"]["auto_role_order"]["strict_candidate_count"] > 1

    assert imgui_exit == 0
    assert imgui_payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert imgui_payload["signed_pd_revision"] == 29
    assert imgui_payload["invariant_status_count"] == 2
    assert imgui_payload["invariant_signed_pd_auto_role_order_present_count"] == 2
    assert imgui_payload["invariant_signed_pd_auto_role_order_requested_count"] == 2
    assert imgui_payload["invariant_signed_pd_auto_role_order_applied_count"] == 0
    assert imgui_payload["invariant_signed_pd_auto_role_order_not_needed_count"] == 0
    assert imgui_payload["invariant_signed_pd_auto_role_order_unique_applied_count"] == 0
    assert imgui_payload["invariant_signed_pd_auto_role_order_ambiguous_count"] == 2
    assert (
        imgui_payload["invariant_signed_pd_auto_role_order_no_strict_candidate_count"]
        == 0
    )
    assert imgui_payload["invariant_signed_pd_auto_role_order_candidate_count"] == (
        homfly["input"]["auto_role_order"]["candidate_count"]
        + alexander["input"]["auto_role_order"]["candidate_count"]
    )
    assert imgui_payload["invariant_signed_pd_auto_role_order_strict_candidate_count"] == (
        homfly["input"]["auto_role_order"]["strict_candidate_count"]
        + alexander["input"]["auto_role_order"]["strict_candidate_count"]
    )
    imgui_statuses = {
        status["name"]: status for status in imgui_payload["invariant_statuses"]
    }
    assert imgui_statuses["HOMFLY-PT"]["value"] == "skipped"
    assert imgui_statuses["HOMFLY-PT"]["skipped"] is True
    assert imgui_statuses["HOMFLY-PT"]["signed_pd_auto_role_order_present"] is True
    assert imgui_statuses["HOMFLY-PT"]["signed_pd_auto_role_order_requested"] is True
    assert imgui_statuses["HOMFLY-PT"]["signed_pd_auto_role_order_applied"] is False
    assert (
        imgui_statuses["HOMFLY-PT"]["signed_pd_auto_role_order_status"]
        == "ambiguous"
    )
    assert (
        imgui_statuses["HOMFLY-PT"]["signed_pd_auto_role_order_strict_candidate_count"]
        == homfly["input"]["auto_role_order"]["strict_candidate_count"]
    )
    assert "signed_pd_auto_role_order=status=ambiguous; applied=False" in (
        imgui_statuses["HOMFLY-PT"]["notes"]
    )
    assert imgui_statuses["multi-variable Alexander"]["value"] == "skipped"
    assert imgui_statuses["multi-variable Alexander"]["skipped"] is True
    assert (
        imgui_statuses["multi-variable Alexander"][
            "signed_pd_auto_role_order_present"
        ]
        is True
    )
    assert (
        imgui_statuses["multi-variable Alexander"][
            "signed_pd_auto_role_order_requested"
        ]
        is True
    )
    assert (
        imgui_statuses["multi-variable Alexander"]["signed_pd_auto_role_order_applied"]
        is False
    )
    assert (
        imgui_statuses["multi-variable Alexander"]["signed_pd_auto_role_order_status"]
        == "ambiguous"
    )
    assert (
        imgui_statuses["multi-variable Alexander"][
            "signed_pd_auto_role_order_strict_candidate_count"
        ]
        == alexander["input"]["auto_role_order"]["strict_candidate_count"]
    )
    assert "signed_pd_auto_role_order=status=ambiguous; applied=False" in (
        imgui_statuses["multi-variable Alexander"]["notes"]
    )


def test_cli_auto_role_order_does_not_skip_zero_crossing_inputs(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "unknot_auto_role_order.json"
        path.write_text(
            json.dumps({"diagram": get_diagram_fixture("0_1").diagram().to_dict()}),
            encoding="utf-8",
        )

        homfly_exit = main(["homfly-pd", str(path), "--auto-role-order"])
        homfly = json.loads(capsys.readouterr().out)

        alexander_exit = main(
            ["multivariable-alexander-pd", str(path), "--auto-role-order"]
        )
        alexander = json.loads(capsys.readouterr().out)

    assert homfly_exit == 0
    assert homfly["method"] == "homfly_pd_report"
    assert homfly["skipped"] is False
    assert homfly["homfly_polynomial"] == "1"
    assert homfly["zero_crossing_certified"] is True
    assert homfly["input"]["auto_role_order"]["requested"] is True
    assert homfly["input"]["auto_role_order"]["applied"] is False
    assert homfly["input"]["auto_role_order"]["status"] == "not_needed"
    assert homfly["input"]["auto_role_order"]["strict_candidate_count"] == 0
    assert homfly["input"]["auto_role_order"]["notes"] == [
        "zero-crossing diagrams do not need role-order inference",
    ]

    assert alexander_exit == 0
    assert alexander["method"] == "multivariable_alexander_pd_report"
    assert alexander["skipped"] is False
    assert alexander["multivariable_alexander_polynomial"] == "1"
    assert alexander["zero_crossing_unlink_certified"] is True
    assert alexander["result"]["method"] == "zero_crossing_unlink_normalization"
    assert alexander["input"]["auto_role_order"]["requested"] is True
    assert alexander["input"]["auto_role_order"]["applied"] is False
    assert alexander["input"]["auto_role_order"]["status"] == "not_needed"
    assert alexander["input"]["auto_role_order"]["strict_candidate_count"] == 0
    assert alexander["input"]["auto_role_order"]["notes"] == [
        "zero-crossing diagrams do not need role-order inference",
    ]

def test_cli_multivariable_alexander_signed_pd_coverage_prints_full_report(capsys) -> None:
    exit_code = main(
        [
            "multivariable-alexander-signed-pd-coverage",
            "--notation",
            "L2a1",
            "--max-matrix-size",
            "4",
            "--max-minors",
            "64",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "multivariable_alexander_signed_pd_coverage_report"
    assert payload["claim_scope"] == (
        "generated_small_signed_pd_wirtinger_fox_scanned_gcd_coverage"
    )
    assert payload["source_notations"] == ["L2a1"]
    assert payload["case_count"] == 7
    assert payload["non_fixture_case_count"] == 6
    assert payload["unique_oriented_diagram_count"] == 5
    assert payload["nonzero_evaluated_case_count"] == 7
    assert payload["nonzero_unique_evaluation_count"] == 5
    assert payload["nonzero_reused_evaluation_count"] == 2
    cache_evidence = payload["nonzero_evaluation_cache_evidence"]
    assert cache_evidence["nonzero_evaluation_accounting_complete"] is True
    assert cache_evidence["nonzero_cache_reuse_observed"] is True
    assert cache_evidence["accounted_case_count"] == payload["case_count"]
    assert cache_evidence["full_admissible_minor_normalization_certified"] is False
    assert cache_evidence["full_invariant_certified"] is False
    _assert_cli_alexander_source_notation_summary_consistency(payload)
    assert payload["accepted_case_count"] == 7
    assert payload["uncertified_case_count"] == 0
    assert payload["result_skipped_case_count"] == 0
    assert payload["truncated_case_count"] == 0
    assert payload["relation_error_count"] == 0
    assert payload["minor_divisibility_matched_case_count"] == 7
    assert payload["bounded_scanned_gcd_certified_case_count"] == 7
    assert payload["wirtinger_fox_matched_case_count"] == 7
    assert payload["failed_nonzero_minor_count"] == 0
    assert payload["accepted"] is True
    assert payload["full_admissible_minor_normalization_certified"] is False
    assert payload["full_invariant_certified"] is False
    assert payload["source_notation_summary"][0]["source_notation"] == "L2a1"
    assert payload["source_notation_summary"][0]["case_count"] == payload[
        "case_count"
    ]
    assert payload["source_notation_summary"][0][
        "bounded_scanned_gcd_certified_case_count"
    ] == payload["bounded_scanned_gcd_certified_case_count"]
    assert len(payload["cases"]) == 7
    assert {case["branch"] for case in payload["cases"]} == {
        "root",
        "positive",
        "negative",
        "smoothed",
    }


def test_cli_fixture_source_invariant_candidates_exports_convergence_report(capsys) -> None:
    exit_code = main(
        [
            "fixture-source-invariant-candidates",
            "L6a4",
            "--no-homfly",
            "--no-alexander",
            "--max-candidates",
            "8",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "diagram_fixture_source_invariant_candidate_diagnostics"
    assert payload["notation"] == "L6a4"
    assert payload["target_pairwise_linking"] == [0.0, 0.0, 0.0]
    assert payload["matching_candidate_count"] == 8
    assert payload["returned_candidate_count"] == 8
    assert payload["candidate_convergence"]["complete_candidate_set"] is True
    assert payload["candidate_convergence"]["stable_invariants"] == ["jones"]
    assert payload["candidate_convergence"]["invariants"]["jones"][
        "unique_value_count"
    ] == 1
    assert payload["signed_pd_replay_summary"][
        "claim_scope"
    ] == "source_candidate_replay_self_consistency"
    assert payload["signed_pd_replay_summary"]["checked_candidate_count"] == 8
    assert payload["signed_pd_replay_summary"]["valid_replay_count"] == 8
    assert payload["signed_pd_replay_summary"][
        "all_returned_candidates_have_valid_replay"
    ] is True
    assert payload["signed_pd_replay_summary"]["orientation_issue_count"] == 0


def test_cli_source_invariant_candidates_retained_pack_exports_imgui_payloads(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        raw_path = tmp_path / "source-invariant-l6a4-candidates.json"
        analysis_path = (
            tmp_path / "source-invariant-l6a4-candidates-imgui-analysis.json"
        )
        host_path = tmp_path / "source-invariant-l6a4-candidates-imgui-host.json"

        raw_exit = main(
            [
                "fixture-source-invariant-candidates",
                "L6a4",
                "--max-candidates",
                "8",
                "-o",
                str(raw_path),
            ]
        )
        assert raw_exit == 0
        assert capsys.readouterr().out == ""

        analysis_exit = main(
            [
                "imgui-analysis-summary-payload",
                str(raw_path),
                "-o",
                str(analysis_path),
            ]
        )
        assert analysis_exit == 0
        assert capsys.readouterr().out == ""

        host_exit = main(
            [
                "imgui-host-payload",
                "--analysis-report-json",
                str(raw_path),
                "-o",
                str(host_path),
            ]
        )
        assert host_exit == 0
        assert capsys.readouterr().out == ""

        raw = json.loads(raw_path.read_text(encoding="utf-8"))
        analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
        host = json.loads(host_path.read_text(encoding="utf-8"))
        _assert_strict_json_serializable(raw, analysis, host)

    assert raw["method"] == "diagram_fixture_source_invariant_candidate_diagnostics"
    assert raw["notation"] == "L6a4"
    assert raw["target_pairwise_linking"] == [0.0, 0.0, 0.0]
    assert raw["returned_candidate_count"] == 8
    convergence = raw["candidate_convergence"]
    assert convergence["complete_candidate_set"] is True
    assert convergence["returned_candidate_count"] == 8
    assert convergence["matching_candidate_count"] == 8
    assert convergence["invariants"]["jones"][
        "stable_across_complete_candidates"
    ] is True
    assert convergence["invariants"]["jones"]["unique_value_count"] == 1
    assert convergence["invariants"]["multivariable_alexander"][
        "stable_across_complete_candidates"
    ] is True
    assert (
        convergence["invariants"]["multivariable_alexander"]["unique_value_count"]
        == 1
    )
    assert convergence["invariants"]["homfly"][
        "stable_across_complete_candidates"
    ] is False
    assert convergence["invariants"]["homfly"]["unique_value_count"] == 3
    assert raw["signed_pd_replay_summary"]["checked_candidate_count"] == 8
    assert raw["signed_pd_replay_summary"]["valid_replay_count"] == 8
    assert raw["signed_pd_replay_summary"][
        "all_returned_candidates_have_valid_replay"
    ] is True

    assert analysis["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert analysis["analysis_summary_count"] == 1
    assert (
        analysis[
            "analysis_source_candidate_replay_summary_checked_candidate_count"
        ]
        == 8
    )
    assert (
        analysis["analysis_source_candidate_replay_summary_valid_replay_count"]
        == 8
    )
    assert (
        analysis["analysis_source_candidate_replay_summary_invalid_replay_count"]
        == 0
    )
    assert (
        analysis["analysis_source_candidate_replay_summary_all_valid_count"]
        == 1
    )
    summary = analysis["analysis_summaries"][0]
    assert (
        summary["source_method"]
        == "diagram_fixture_source_invariant_candidate_diagnostics"
    )
    assert summary["required_check_count"] == 1
    assert summary["passed_check_count"] == 0
    assert summary["failed_check_count"] == 1
    assert summary["certified"] is False
    assert summary["source_candidate_replay_summary_checked_candidate_count"] == 8
    assert summary["source_candidate_replay_summary_valid_replay_count"] == 8
    assert summary["source_candidate_replay_summary_invalid_replay_count"] == 0
    assert summary["source_candidate_replay_summary_all_valid_count"] == 1
    assert "source_candidate_replay_summary=checked=8; valid=8" in summary["notes"]
    assert "not registered as fixture invariants" in summary["notes"]

    assert host["method"] == "imgui_host_payload"
    assert (
        host["analysis"][
            "analysis_source_candidate_replay_summary_checked_candidate_count"
        ]
        == 8
    )
    assert (
        host["analysis"]["analysis_source_candidate_replay_summary_all_valid_count"]
        == 1
    )
    by_method = {
        item["source_method"]: item
        for item in host["analysis"]["analysis_summaries"]
    }
    host_summary = by_method["diagram_fixture_source_invariant_candidate_diagnostics"]
    assert host_summary["failed_check_count"] == 1
    assert host_summary["certified"] is False
    assert "signed candidates are diagnostics" in host_summary["notes"]


def test_cli_whitehead_source_invariant_candidates_retained_pack_exports_imgui_payloads(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        raw_path = tmp_path / "source-invariant-l5a1-candidates.json"
        analysis_path = (
            tmp_path / "source-invariant-l5a1-candidates-imgui-analysis.json"
        )
        host_path = tmp_path / "source-invariant-l5a1-candidates-imgui-host.json"

        raw_exit = main(
            [
                "fixture-source-invariant-candidates",
                "L5a1",
                "--no-homfly",
                "--max-candidates",
                "24",
                "-o",
                str(raw_path),
            ]
        )
        assert raw_exit == 0
        assert capsys.readouterr().out == ""

        analysis_exit = main(
            [
                "imgui-analysis-summary-payload",
                str(raw_path),
                "-o",
                str(analysis_path),
            ]
        )
        assert analysis_exit == 0
        assert capsys.readouterr().out == ""

        host_exit = main(
            [
                "imgui-host-payload",
                "--analysis-report-json",
                str(raw_path),
                "-o",
                str(host_path),
            ]
        )
        assert host_exit == 0
        assert capsys.readouterr().out == ""

        raw = json.loads(raw_path.read_text(encoding="utf-8"))
        analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
        host = json.loads(host_path.read_text(encoding="utf-8"))
        _assert_strict_json_serializable(raw, analysis, host)

    assert raw["method"] == "diagram_fixture_source_invariant_candidate_diagnostics"
    assert raw["notation"] == "L5a1"
    assert raw["target_pairwise_linking"] == [0.0]
    assert raw["matching_candidate_count"] == 24
    assert raw["returned_candidate_count"] == 24
    assert raw["signed_pd_replay_summary"]["checked_candidate_count"] == 24
    assert raw["signed_pd_replay_summary"]["valid_replay_count"] == 24
    assert raw["signed_pd_replay_summary"][
        "all_returned_candidates_have_valid_replay"
    ] is True
    convergence = raw["candidate_convergence"]
    assert convergence["complete_candidate_set"] is True
    assert convergence["stable_invariants"] == []
    assert convergence["candidate_group_count"] == 20
    assert convergence["invariants"]["jones"]["computed_candidate_count"] == 12
    assert convergence["invariants"]["jones"]["missing_candidate_count"] == 12
    assert convergence["invariants"]["jones"]["unique_value_count"] == 1
    assert (
        convergence["invariants"]["jones"]["stable_across_complete_candidates"]
        is False
    )
    assert (
        convergence["invariants"]["multivariable_alexander"][
            "computed_candidate_count"
        ]
        == 16
    )
    assert (
        convergence["invariants"]["multivariable_alexander"][
            "missing_candidate_count"
        ]
        == 8
    )
    assert (
        convergence["invariants"]["multivariable_alexander"][
            "skipped_candidate_count"
        ]
        == 8
    )
    assert (
        convergence["invariants"]["multivariable_alexander"]["unique_value_count"]
        == 2
    )
    assert (
        convergence["invariants"]["multivariable_alexander"][
            "stable_across_complete_candidates"
        ]
        is False
    )
    assert convergence["invariants"]["homfly"]["computed_candidate_count"] == 0
    assert convergence["invariants"]["homfly"]["missing_candidate_count"] == 24

    assert analysis["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert analysis["analysis_summary_count"] == 1
    assert (
        analysis[
            "analysis_source_candidate_replay_summary_checked_candidate_count"
        ]
        == 24
    )
    assert (
        analysis["analysis_source_candidate_replay_summary_valid_replay_count"]
        == 24
    )
    assert (
        analysis["analysis_source_candidate_replay_summary_invalid_replay_count"]
        == 0
    )
    assert (
        analysis["analysis_source_candidate_replay_summary_all_valid_count"]
        == 1
    )
    summary = analysis["analysis_summaries"][0]
    assert (
        summary["source_method"]
        == "diagram_fixture_source_invariant_candidate_diagnostics"
    )
    assert summary["required_check_count"] == 1
    assert summary["passed_check_count"] == 0
    assert summary["failed_check_count"] == 1
    assert summary["certified"] is False
    assert summary["source_candidate_replay_summary_checked_candidate_count"] == 24
    assert summary["source_candidate_replay_summary_valid_replay_count"] == 24
    assert summary["source_candidate_replay_summary_invalid_replay_count"] == 0
    assert summary["source_candidate_replay_summary_all_valid_count"] == 1
    assert "source_candidate_replay_summary=checked=24; valid=24" in summary["notes"]
    assert "not registered as fixture invariants" in summary["notes"]
    assert "signed candidates are diagnostics" in summary["notes"]

    assert host["method"] == "imgui_host_payload"
    assert (
        host["analysis"][
            "analysis_source_candidate_replay_summary_checked_candidate_count"
        ]
        == 24
    )
    assert (
        host["analysis"]["analysis_source_candidate_replay_summary_all_valid_count"]
        == 1
    )
    host_summary = {
        item["source_method"]: item
        for item in host["analysis"]["analysis_summaries"]
    }["diagram_fixture_source_invariant_candidate_diagnostics"]
    assert host_summary["failed_check_count"] == 1
    assert host_summary["certified"] is False
    assert "signed candidates are diagnostics" in host_summary["notes"]
    assert "external source convention validation" in host_summary["notes"]


def test_cli_source_candidate_replay_round_trips_to_pd_recompute(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        export_exit = main(
            [
                "fixture-source-invariant-candidates",
                "L6a4",
                "--no-homfly",
                "--no-alexander",
                "--max-candidates",
                "1",
            ]
        )
        exported = json.loads(capsys.readouterr().out)
        replay_path = tmp_path / "source-candidate-signed-pd.json"
        replay_path.write_text(
            json.dumps(exported["candidates"][0]["signed_pd_input"]),
            encoding="utf-8",
        )

        alexander_exit = main(
            [
                "multivariable-alexander-pd",
                str(replay_path),
                "--max-matrix-size",
                "6",
                "--max-minors",
                "256",
            ]
        )
        alexander = json.loads(capsys.readouterr().out)

        homfly_exit = main(
            [
                "homfly-pd",
                str(replay_path),
                "--max-depth",
                "0",
                "--max-nodes",
                "16",
            ]
        )
        homfly = json.loads(capsys.readouterr().out)

        imgui_exit = main(
            [
                "imgui-signed-pd-invariant-status-payload",
                str(replay_path),
                "--max-depth",
                "0",
                "--max-nodes",
                "16",
                "--max-matrix-size",
                "6",
                "--max-minors",
                "256",
            ]
        )
        imgui_payload = json.loads(capsys.readouterr().out)

    assert export_exit == 0
    assert alexander_exit == 0
    assert homfly_exit == 0
    assert imgui_exit == 0
    assert alexander["method"] == "multivariable_alexander_pd_report"
    assert homfly["method"] == "homfly_pd_report"
    for payload in (alexander, homfly):
        replay = payload["input"]["source_candidate_replay"]
        assert payload["input"]["orientation_supplied"] is True
        assert replay["present"] is True
        assert replay["claim_scope"] == "source_gauss_matched_signed_pd_candidate_replay"
        assert replay["source_notation"] == "L6a4"
        assert replay["source"] == "Knot Atlas"
        assert replay["orientation_validation_issues"] == []

    assert alexander["result"]["skipped"] is False
    assert alexander["bounded_scanned_gcd_certified"] is True
    assert alexander["multivariable_alexander_polynomial"] == (
        "1 - t3 - t2 + t2*t3 - t1 + t1*t3 + t1*t2 - t1*t2*t3"
    )
    assert (
        alexander["input_certification_evidence"][
            "wirtinger_fox_input_chain_consistent"
        ]
        is True
    )
    assert homfly["frontier_count"] == 1
    assert homfly["certified_for_input"] is False

    assert imgui_payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert imgui_payload["invariant_status_count"] == 2
    assert imgui_payload["invariant_source_candidate_replay_count"] == 2
    assert imgui_payload["invariant_source_candidate_replay_source_notation_count"] == 1
    assert imgui_payload["invariant_source_candidate_replay_source_notations"] == "L6a4"
    assert imgui_payload["invariant_source_candidate_replay_sign_count"] == 12
    assert imgui_payload["invariant_source_candidate_replay_role_order_count"] == 12
    rows = {row["name"]: row for row in imgui_payload["invariant_statuses"]}
    assert "source_candidate_replay=claim_scope=source_gauss_matched_signed_pd_candidate_replay" in rows[
        "HOMFLY-PT"
    ]["notes"]
    assert "source_notation=L6a4" in rows["HOMFLY-PT"]["notes"]
    assert "source_url=https://katlas.org/wiki/L6a4" in rows[
        "multi-variable Alexander"
    ]["notes"]
    assert "pairwise_linking=0.0,0.0,0.0" in rows[
        "multi-variable Alexander"
    ]["notes"]


def test_cli_fixture_source_table_invariant_audit_exports_source_matches(capsys) -> None:
    exit_code = main(
        [
            "fixture-source-table-invariant-audit",
            "L6a4",
            "--max-candidates",
            "8",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "diagram_fixture_source_table_invariant_audit"
    assert payload["notation"] == "L6a4"
    assert payload["registered_fixture_invariant_claim"] is False
    assert payload["source"] == "Knot Atlas"
    assert payload["source_url"] == "https://katlas.org/wiki/L6a4"
    assert payload["matched_source_table_invariants"] == [
        "jones",
        "multivariable_alexander_numerator",
    ]
    assert payload["uncomputed_source_table_invariants"] == ["homfly"]
    assert payload["uncomputed_source_table_invariant_count"] == 1
    assert payload["mismatched_source_table_invariants"] == []
    assert payload["mismatched_source_table_invariant_count"] == 0
    assert payload["unstable_source_table_invariants"] == []
    assert payload["unstable_source_table_invariant_count"] == 0
    assert payload["source_table_registration_ready"] is False
    assert payload["source_table_registration_blockers"] == [
        "fixture_signs_not_registered",
        "registered_fixture_invariant_claim_disabled",
        "source_table_values_uncomputed",
        "source_compatible_sign_pattern_not_unique",
    ]
    assert payload["source_table_registration_blocker_count"] == 4
    assert payload["source_table_registration_blocker_details"][
        "source_table_values_uncomputed"
    ] == ["homfly"]
    convergence_summary = payload["source_table_candidate_convergence_summary"]
    assert convergence_summary["method"] == (
        "diagram_fixture_source_table_candidate_convergence_summary"
    )
    assert convergence_summary["complete_candidate_set"] is True
    assert convergence_summary["partial_source_table_convergence_certified"] is True
    assert convergence_summary["full_source_table_convergence_certified"] is False
    assert convergence_summary["certified_invariants"] == [
        "jones",
        "multivariable_alexander_numerator",
    ]
    assert convergence_summary["uncertified_invariants"] == ["homfly"]
    assert convergence_summary["source_value_seen_invariants"] == [
        "jones",
        "multivariable_alexander_numerator",
    ]
    assert convergence_summary["source_value_seen_invariant_count"] == 2
    assert convergence_summary["source_value_seen_but_uncertified_invariants"] == []
    assert convergence_summary[
        "source_value_seen_but_uncertified_invariant_count"
    ] == 0
    assert payload["source_table_candidate_convergence_partial_certified"] is True
    assert payload["source_table_candidate_convergence_full_certified"] is False
    assert payload["source_table_candidate_convergence_certified_invariant_count"] == 2
    assert payload["source_table_candidate_convergence_uncertified_invariant_count"] == 1
    assert (
        payload[
            "source_table_candidate_convergence_source_value_seen_invariant_count"
        ]
        == 2
    )
    assert (
        payload[
            "source_table_candidate_convergence_source_value_seen_but_uncertified_invariant_count"
        ]
        == 0
    )
    assert payload["comparisons"]["jones"]["complete_candidate_source_match"] is True
    assert payload["comparisons"]["multivariable_alexander_numerator"][
        "complete_candidate_source_match"
    ] is True
    homfly = payload["comparisons"]["homfly"]
    assert homfly["complete_candidate_source_match"] is False
    assert homfly["source_value_variant_resolution_status"] == "not_computed"
    assert homfly["source_value_variant_resolution_status_code"] == 2
    assert payload["source_table_candidate_count"] == 8
    assert payload["source_table_candidate_unique_sign_pattern_count"] == 8
    assert payload["source_table_computed_source_compatible_candidate_count"] == 8
    assert payload["source_table_computed_source_compatible_unique_sign_pattern_count"] == 8
    assert payload["source_table_complete_source_compatible_candidate_count"] == 0
    assert payload["source_table_complete_source_compatible_unique_sign_pattern_count"] == 0
    assert payload["source_table_top_candidate_count"] == 8
    assert payload["source_table_top_candidate_unique_sign_pattern_count"] == 8
    assert payload["source_table_max_matched_source_value_count"] == 2
    assert payload["source_table_max_matched_candidate_total_count"] == 8
    assert payload["source_table_max_matched_candidate_total_unique_sign_pattern_count"] == 8
    assert payload["source_table_max_matched_candidate_count"] == 8
    assert payload["source_table_max_matched_candidate_unique_sign_pattern_count"] == 8
    match_summary = payload["candidate_source_table_match_summary"]
    assert match_summary["candidate_unique_sign_pattern_count"] == 8
    assert match_summary["computed_source_compatible_unique_sign_pattern_count"] == 8
    assert match_summary["complete_source_compatible_unique_sign_pattern_count"] == 0
    assert match_summary["top_candidate_count"] == 8
    assert match_summary["top_candidate_unique_sign_pattern_count"] == 8
    assert match_summary["max_matched_candidate_total_count"] == 8
    assert match_summary["max_matched_candidate_total_unique_sign_pattern_count"] == 8
    assert match_summary["top_candidate_unique_sign_patterns"][0] == [
        -1,
        -1,
        -1,
        1,
        1,
        1,
    ]


def test_cli_source_table_invariant_audit_retained_pack_exports_imgui_payloads(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        l6_raw_path = tmp_path / "source-table-l6a4-audit.json"
        l6_analysis_path = tmp_path / "source-table-l6a4-audit-imgui-analysis.json"
        l6_host_path = tmp_path / "source-table-l6a4-audit-imgui-host.json"
        l5_raw_path = tmp_path / "source-table-l5a1-audit.json"
        l5_analysis_path = tmp_path / "source-table-l5a1-audit-imgui-analysis.json"
        l5_host_path = tmp_path / "source-table-l5a1-audit-imgui-host.json"

        l6_export_exit = main(
            [
                "fixture-source-table-invariant-audit",
                "L6a4",
                "--max-candidates",
                "8",
                "-o",
                str(l6_raw_path),
            ]
        )
        assert l6_export_exit == 0
        assert capsys.readouterr().out == ""

        l6_analysis_exit = main(
            [
                "imgui-analysis-summary-payload",
                str(l6_raw_path),
                "-o",
                str(l6_analysis_path),
            ]
        )
        assert l6_analysis_exit == 0
        assert capsys.readouterr().out == ""

        l6_host_exit = main(
            [
                "imgui-host-payload",
                "--analysis-report-json",
                str(l6_raw_path),
                "-o",
                str(l6_host_path),
            ]
        )
        assert l6_host_exit == 0
        assert capsys.readouterr().out == ""

        l5_export_exit = main(
            [
                "fixture-source-table-invariant-audit",
                "L5a1",
                "--max-candidates",
                "24",
                "-o",
                str(l5_raw_path),
            ]
        )
        assert l5_export_exit == 0
        assert capsys.readouterr().out == ""

        l5_analysis_exit = main(
            [
                "imgui-analysis-summary-payload",
                str(l5_raw_path),
                "-o",
                str(l5_analysis_path),
            ]
        )
        assert l5_analysis_exit == 0
        assert capsys.readouterr().out == ""

        l5_host_exit = main(
            [
                "imgui-host-payload",
                "--analysis-report-json",
                str(l5_raw_path),
                "-o",
                str(l5_host_path),
            ]
        )
        assert l5_host_exit == 0
        assert capsys.readouterr().out == ""

        l6_raw = json.loads(l6_raw_path.read_text(encoding="utf-8"))
        l6_analysis = json.loads(l6_analysis_path.read_text(encoding="utf-8"))
        l6_host = json.loads(l6_host_path.read_text(encoding="utf-8"))
        l5_raw = json.loads(l5_raw_path.read_text(encoding="utf-8"))
        l5_analysis = json.loads(l5_analysis_path.read_text(encoding="utf-8"))
        l5_host = json.loads(l5_host_path.read_text(encoding="utf-8"))
        _assert_strict_json_serializable(
            l6_raw,
            l6_analysis,
            l6_host,
            l5_raw,
            l5_analysis,
            l5_host,
        )

    assert l6_raw["method"] == "diagram_fixture_source_table_invariant_audit"
    assert l6_raw["notation"] == "L6a4"
    assert l6_raw["registered_fixture_invariant_claim"] is False
    assert l6_raw["source_table_registration_ready"] is False
    assert l6_raw["source_table_registration_blocker_count"] == 4
    convergence_summary = l6_raw["source_table_candidate_convergence_summary"]
    assert convergence_summary["partial_source_table_convergence_certified"] is True
    assert convergence_summary["full_source_table_convergence_certified"] is False
    assert convergence_summary["certified_invariant_count"] == 2
    assert convergence_summary["uncertified_invariant_count"] == 1
    assert convergence_summary["source_value_seen_invariant_count"] == 2
    assert convergence_summary["source_value_seen_but_uncertified_invariant_count"] == 0

    assert l6_analysis["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert l6_analysis["analysis_summary_count"] == 1
    assert (
        l6_analysis[
            "analysis_source_table_audit_source_match_resolution_status_count"
        ]
        == 3
    )
    assert l6_analysis["analysis_source_table_audit_registration_blocker_count"] == 4
    assert (
        l6_analysis[
            "analysis_source_table_audit_candidate_convergence_partial_certified_count"
        ]
        == 1
    )
    assert (
        l6_analysis[
            "analysis_source_table_audit_candidate_convergence_full_certified_count"
        ]
        == 0
    )
    assert (
        l6_analysis[
            "analysis_source_table_audit_candidate_convergence_certified_invariant_count"
        ]
        == 2
    )
    assert (
        l6_analysis[
            "analysis_source_table_audit_candidate_convergence_uncertified_invariant_count"
        ]
        == 1
    )
    assert (
        l6_analysis[
            "analysis_source_table_audit_candidate_convergence_source_value_seen_count"
        ]
        == 2
    )
    assert (
        l6_analysis[
            "analysis_source_table_audit_candidate_convergence_source_value_seen_but_uncertified_count"
        ]
        == 0
    )
    l6_summary = l6_analysis["analysis_summaries"][0]
    assert l6_summary["source_method"] == "diagram_fixture_source_table_invariant_audit"
    assert l6_summary["source_table_audit_source_match_resolution_status_count"] == 3
    assert l6_summary["source_table_audit_registration_blocker_count"] == 4
    assert l6_summary["source_table_audit_candidate_convergence_partial_certified_count"] == 1
    assert l6_summary["source_table_audit_candidate_convergence_full_certified_count"] == 0
    assert l6_summary["source_table_audit_candidate_convergence_certified_invariant_count"] == 2
    assert l6_summary["source_table_audit_candidate_convergence_uncertified_invariant_count"] == 1
    assert l6_summary["source_table_audit_candidate_convergence_source_value_seen_count"] == 2
    assert (
        l6_summary[
            "source_table_audit_candidate_convergence_source_value_seen_but_uncertified_count"
        ]
        == 0
    )
    assert "registration_ready=false" in l6_summary["notes"]
    assert "source_url=https://katlas.org/wiki/L6a4" in l6_summary["notes"]

    assert l6_host["method"] == "imgui_host_payload"
    l6_host_analysis = l6_host["analysis"]
    assert (
        l6_host_analysis[
            "analysis_source_table_audit_source_match_resolution_status_count"
        ]
        == 3
    )
    assert (
        l6_host_analysis["analysis_source_table_audit_registration_blocker_count"]
        == 4
    )
    assert (
        l6_host_analysis[
            "analysis_source_table_audit_candidate_convergence_partial_certified_count"
        ]
        == 1
    )
    assert (
        l6_host_analysis[
            "analysis_source_table_audit_candidate_convergence_full_certified_count"
        ]
        == 0
    )
    assert (
        l6_host_analysis[
            "analysis_source_table_audit_candidate_convergence_certified_invariant_count"
        ]
        == 2
    )
    assert (
        l6_host_analysis[
            "analysis_source_table_audit_candidate_convergence_uncertified_invariant_count"
        ]
        == 1
    )
    assert (
        l6_host_analysis[
            "analysis_source_table_audit_candidate_convergence_source_value_seen_count"
        ]
        == 2
    )
    assert (
        l6_host_analysis[
            "analysis_source_table_audit_candidate_convergence_source_value_seen_but_uncertified_count"
        ]
        == 0
    )
    l6_host_summaries = {
        row["source_method"]: row for row in l6_host_analysis["analysis_summaries"]
    }
    l6_host_summary = l6_host_summaries["diagram_fixture_source_table_invariant_audit"]
    assert (
        l6_host_summary["source_method"]
        == "diagram_fixture_source_table_invariant_audit"
    )
    assert l6_host_summary["source_table_audit_registration_blocker_count"] == 4
    assert (
        l6_host_summary[
            "source_table_audit_candidate_convergence_partial_certified_count"
        ]
        == 1
    )
    assert (
        l6_host_summary["source_table_audit_candidate_convergence_full_certified_count"]
        == 0
    )
    assert (
        l6_host_summary[
            "source_table_audit_candidate_convergence_certified_invariant_count"
        ]
        == 2
    )
    assert (
        l6_host_summary[
            "source_table_audit_candidate_convergence_uncertified_invariant_count"
        ]
        == 1
    )
    assert (
        l6_host_summary[
            "source_table_audit_candidate_convergence_source_value_seen_count"
        ]
        == 2
    )
    assert (
        l6_host_summary[
            "source_table_audit_candidate_convergence_source_value_seen_but_uncertified_count"
        ]
        == 0
    )

    assert l5_raw["method"] == "diagram_fixture_source_table_invariant_audit"
    assert l5_raw["notation"] == "L5a1"
    assert l5_raw["source_url"] == "https://katlas.org/wiki/L5a1"
    assert l5_raw["registered_fixture_invariant_claim"] is False
    assert l5_raw["source_table_registration_ready"] is False
    assert l5_raw["source_table_registration_blocker_count"] == 4

    assert l5_analysis["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert l5_analysis["analysis_summary_count"] == 1
    assert (
        l5_analysis[
            "analysis_source_table_audit_source_match_resolution_status_count"
        ]
        == 3
    )
    assert l5_analysis["analysis_source_table_audit_registration_blocker_count"] == 4
    assert (
        l5_analysis[
            "analysis_source_table_alexander_skipped_common_gcd_attempt_candidate_count"
        ]
        == 8
    )
    assert (
        l5_analysis[
            "analysis_source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count"
        ]
        == 8
    )
    assert (
        l5_analysis[
            "analysis_source_table_alexander_source_divisibility_checked_candidate_count"
        ]
        == 8
    )
    assert (
        l5_analysis[
            "analysis_source_table_alexander_source_divisibility_source_division_failed_candidate_count"
        ]
        == 8
    )
    l5_summary = l5_analysis["analysis_summaries"][0]
    assert l5_summary["source_method"] == "diagram_fixture_source_table_invariant_audit"
    assert l5_summary["source_table_audit_registration_blocker_count"] == 4
    assert (
        l5_summary[
            "source_table_alexander_skipped_common_gcd_attempt_candidate_count"
        ]
        == 8
    )
    assert (
        l5_summary[
            "source_table_alexander_source_divisibility_source_division_failed_candidate_count"
        ]
        == 8
    )
    assert (
        l5_summary["source_table_alexander_source_divisibility_candidate_indices"]
        == "4,5,10,11,12,13,18,19"
    )
    assert (
        l5_summary[
            "source_table_alexander_source_divisibility_first_failed_candidate_index"
        ]
        == 4
    )
    assert (
        l5_summary[
            "source_table_alexander_source_divisibility_first_failed_notation"
        ]
        == "L5a1"
    )
    assert (
        l5_summary[
            "source_table_alexander_source_divisibility_first_failed_input_polynomial"
        ]
        == "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2"
    )
    assert "registration_ready=false" in l5_summary["notes"]
    assert "source_url=https://katlas.org/wiki/L5a1" in l5_summary["notes"]

    assert l5_host["method"] == "imgui_host_payload"
    l5_host_analysis = l5_host["analysis"]
    assert (
        l5_host_analysis["analysis_source_table_audit_registration_blocker_count"]
        == 4
    )
    assert (
        l5_host_analysis[
            "analysis_source_table_alexander_skipped_common_gcd_attempt_candidate_count"
        ]
        == 8
    )
    assert (
        l5_host_analysis[
            "analysis_source_table_alexander_source_divisibility_source_division_failed_candidate_count"
        ]
        == 8
    )
    l5_host_summaries = {
        row["source_method"]: row for row in l5_host_analysis["analysis_summaries"]
    }
    l5_host_summary = l5_host_summaries[
        "diagram_fixture_source_table_invariant_audit"
    ]
    assert (
        l5_host_summary[
            "source_table_alexander_source_divisibility_candidate_indices"
        ]
        == "4,5,10,11,12,13,18,19"
    )
    assert (
        l5_host_summary[
            "source_table_alexander_source_divisibility_first_failed_candidate_index"
        ]
        == 4
    )
    assert (
        l5_host_summary[
            "source_table_alexander_source_divisibility_first_failed_notation"
        ]
        == "L5a1"
    )
    assert (
        l5_host_summary[
            "source_table_alexander_source_divisibility_first_failed_input_polynomial"
        ]
        == "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2"
    )


def test_cli_fixture_source_table_invariant_audit_exports_alexander_skipped_attempts(
    capsys,
) -> None:
    exit_code = main(
        [
            "fixture-source-table-invariant-audit",
            "L5a1",
            "--max-candidates",
            "24",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "diagram_fixture_source_table_invariant_audit"
    assert payload["notation"] == "L5a1"
    assert payload["complete_candidate_set"] is True
    summary = payload["source_table_alexander_skipped_common_gcd_attempt_summary"]
    assert payload["source_table_alexander_skipped_common_gcd_attempt_candidate_count"] == 8
    assert (
        payload[
            "source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count"
        ]
        == 8
    )
    assert payload["source_table_alexander_skipped_common_gcd_attempt_statuses"] == [
        "not_certified",
    ]
    assert payload["source_table_alexander_skipped_common_gcd_attempt_status_counts"] == [
        {"status": "not_certified", "candidate_count": 8},
    ]
    assert summary["candidate_with_attempt_evidence_count"] == 8
    assert summary["candidate_without_attempt_evidence_count"] == 0
    assert summary["not_certified_candidate_count"] == 8
    assert summary["all_attempts_not_certified"] is True
    assert summary["input_polynomial_count_min"] == 25
    assert summary["input_polynomial_count_max"] == 25
    assert summary["unique_input_polynomial_count_min"] == 10
    assert summary["unique_input_polynomial_count_max"] == 10
    assert summary["candidate_method_count"] == 8
    assert summary["bounded_search_limit_variant_count"] == 1
    assert summary["bounded_search_limits"]["max_candidate_terms"] == 14
    assert summary["direct_divisor_attempt_evidence_count"] == 8
    assert summary["direct_divisor_candidate_count_min"] == 10
    assert summary["direct_divisor_candidate_count_max"] == 10
    assert summary["direct_divisor_divides_all_candidate_count_min"] == 0
    assert summary["direct_divisor_divides_all_candidate_count_max"] == 0
    assert summary["direct_divisor_failed_candidate_count_min"] == 10
    assert summary["direct_divisor_failed_candidate_count_max"] == 10
    assert summary["direct_divisor_all_candidates_failed"] is True
    assert summary["direct_divisor_first_failure"]["candidate_polynomial"] == (
        "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2"
    )
    assert summary["support_signature_evidence_count"] == 8
    assert summary["support_signature_variant_count"] == 1
    assert summary["support_signature_input_count_min"] == 25
    assert summary["support_signature_input_count_max"] == 25
    assert summary["support_signature_counts"] == [
        {
            "variables": ["t1", "t2"],
            "candidate_count": 8,
            "input_count_min": 25,
            "input_count_max": 25,
        }
    ]
    assert (
        payload[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 8
    )
    assert (
        payload[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count"
        ]
        == 1
    )
    assert (
        payload[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count"
        ]
        == 8
    )
    assert (
        payload[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max"
        ]
        == 10
    )
    assert (
        payload[
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed"
        ]
        is True
    )
    source_divisibility = (
        payload["source_table_alexander_source_numerator_divisibility_summary"]
    )
    assert source_divisibility["source_value"] == "1 - t2 - t1 + t1*t2"
    assert source_divisibility["checked_candidate_count"] == 8
    assert source_divisibility["source_divides_all_candidate_count"] == 0
    assert source_divisibility["source_division_failed_candidate_count"] == 8
    assert source_divisibility["statuses"] == [
        "source_does_not_divide_all_inputs",
    ]
    assert source_divisibility["failed_input_count_min"] == 10
    assert source_divisibility["failed_input_count_max"] == 10
    assert source_divisibility["first_failed_candidate_index"] == 4
    assert source_divisibility["first_failed_input_polynomial"] == (
        "2 - 2t2 - t1 + 2*t1*t2 - t1*t2^2"
    )
    assert (
        payload["comparisons"]["multivariable_alexander_numerator"][
            "skipped_common_gcd_attempt_summary"
        ]
        == summary
    )
    assert (
        payload["comparisons"]["multivariable_alexander_numerator"][
            "source_numerator_divisibility_summary"
        ]
        == source_divisibility
    )


def test_cli_homfly_small_diagram_coverage_prints_full_report(capsys) -> None:
    exit_code = main(
        [
            "homfly-small-diagram-coverage",
            "--notation",
            "L2a1",
            "--max-depth",
            "8",
            "--max-nodes",
            "2048",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "homfly_small_diagram_coverage_report"
    assert payload["claim_scope"] == "generated_small_signed_pd_frontier_exhaustion"
    assert payload["source_notations"] == ["L2a1"]
    assert payload["case_count"] == 7
    assert payload["non_fixture_case_count"] == 6
    assert payload["unique_diagram_count"] == 5
    assert payload["unique_oriented_diagram_count"] == 5
    assert payload["duplicate_diagram_case_count"] == 2
    assert payload["multi_path_diagram_count"] == 1
    assert payload["max_diagram_case_count"] == 3
    assert payload["polynomial_variant_diagram_count"] >= 0
    assert payload["max_homfly_polynomial_count_per_diagram"] >= 1
    assert payload["oriented_polynomial_conflict_count"] == 0
    assert payload["max_homfly_polynomial_count_per_oriented_diagram"] == 1
    assert payload["certified_case_count"] == 7
    assert payload["uncertified_case_count"] == 0
    assert payload["frontier_count"] == 0
    assert payload["frontier_reason_count"] == 0
    assert payload["frontier_reasons"] == []
    assert payload["frontier_reason_counts"] == []
    assert payload["frontier_witness_summary"]["witness_count"] == 0
    assert payload["frontier_witness_summary"]["reason_counts"] == []
    assert payload["frontier_witness_summary"]["witness_summary_truncated"] is False
    assert payload["branch_depth_counts"] == [
        {"branch_depth": 0, "case_count": 1},
        {"branch_depth": 1, "case_count": 6},
    ]
    assert payload["certified_branch_depth_counts"] == payload["branch_depth_counts"]
    assert payload["frontier_branch_depth_counts"] == []
    assert payload["truncated_branch_depth_counts"] == []
    assert payload["truncated_case_count"] == 0
    assert payload["accepted"] is True
    assert payload["full_table_normalization_certified"] is False
    assert payload["arbitrary_diagram_coverage_certified"] is False
    _assert_cli_homfly_frontier_witness_consistency(payload)
    _assert_cli_blocker_detail_codes(
        payload,
        "homfly_completion_blocker_details",
        [
            "full_table_normalization_not_certified",
            "arbitrary_diagram_coverage_not_certified",
        ],
    )
    assert payload["homfly_completion_blocker_detail_count"] == 2
    _assert_cli_homfly_source_notation_summary_consistency(payload)
    case_consistency = payload["case_evidence_consistency"]
    assert case_consistency["matched"] is True
    assert case_consistency["checked_case_count"] == payload["case_count"]
    assert case_consistency["evidence_aggregate_totals"] == (
        case_consistency["report_aggregate_totals"]
    )
    _assert_cli_homfly_blocker_detail_code_count_consistency(payload)
    gate = payload["arbitrary_diagram_completion_gate"]
    _assert_cli_homfly_arbitrary_completion_gate(gate)
    assert gate["evidence_scope"] == "generated_small_signed_pd_coverage"
    assert gate["case_count"] == payload["case_count"]
    assert gate["frontier_count"] == 0
    assert gate["case_evidence_consistency_matched"] is True
    assert payload["homfly_completion_blocker_details"][1]["witness"] == gate

    with workspace_tempdir() as tmp_path:
        report_path = tmp_path / "homfly-small-coverage.json"
        coverage_exit = main(
            [
                "homfly-small-diagram-coverage",
                "--notation",
                "L2a1",
                "--max-depth",
                "8",
                "--max-nodes",
                "2048",
                "-o",
                str(report_path),
            ]
        )
        capsys.readouterr()
        invariant_exit = main(
            ["imgui-invariant-status-summary-payload", str(report_path)]
        )
        invariant_payload = json.loads(capsys.readouterr().out)

    assert coverage_exit == 0
    assert invariant_exit == 0
    assert invariant_payload["method"] == "imgui_invariant_status_payload_from_reports"
    assert invariant_payload["invariant_status_count"] == 1
    status = invariant_payload["invariant_statuses"][0]
    assert status["homfly_case_evidence_consistency_available_count"] == 1
    assert status["homfly_case_evidence_consistency_matched_count"] == 1
    assert status["homfly_case_evidence_consistency_case_count"] == 7
    assert status["homfly_case_evidence_maturity_path_counts_matched_count"] == 1
    assert (
        invariant_payload[
            "invariant_homfly_case_evidence_consistency_available_count"
        ]
        == 1
    )
    assert (
        invariant_payload[
            "invariant_homfly_case_evidence_consistency_matched_count"
        ]
        == 1
    )
    assert (
        invariant_payload["invariant_homfly_case_evidence_consistency_case_count"]
        == 7
    )
    assert "homfly_case_evidence_consistency=matched=True" in status["notes"]

    assert payload["source_notation_summary"][0]["source_notation"] == "L2a1"
    assert payload["source_notation_summary"][0]["case_count"] == payload[
        "case_count"
    ]
    _assert_cli_homfly_frontier_witness_consistency(
        payload["source_notation_summary"][0]
    )
    assert payload["source_notation_summary"][0]["unique_diagram_count"] == payload[
        "unique_diagram_count"
    ]
    assert len(payload["cases"]) == 7
    assert {case["branch"] for case in payload["cases"]} == {
        "root",
        "positive",
        "negative",
        "smoothed",
    }
    multiplicity = payload["diagram_multiplicity_summary"]
    assert multiplicity["unique_diagram_count"] == 5
    assert multiplicity["duplicate_diagram_case_count"] == 2
    assert multiplicity["polynomial_variant_diagram_count"] >= 0
    assert multiplicity["max_homfly_polynomial_count_per_diagram"] >= 1
    assert multiplicity["oriented_polynomial_conflict_count"] == 0
    assert multiplicity["max_homfly_polynomial_count_per_oriented_diagram"] == 1
    assert multiplicity["diagrams"][0]["case_ids"] == [
        "L2a1:root:root",
        "L2a1:0:positive",
        "L2a1:1:negative",
    ]


def test_cli_homfly_small_diagram_coverage_preserves_frontier_cases(
    capsys,
) -> None:
    exit_code = main(
        [
            "homfly-small-diagram-coverage",
            "--notation",
            "L2a1",
            "--branch-depth",
            "1",
            "--max-depth",
            "0",
            "--max-nodes",
            "128",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "homfly_small_diagram_coverage_report"
    assert payload["source_notations"] == ["L2a1"]
    assert payload["branch_depth"] == 1
    assert payload["max_depth"] == 0
    assert payload["max_nodes"] == 128
    assert payload["case_count"] == 7
    assert payload["certified_case_count"] == 1
    assert payload["uncertified_case_count"] == 6
    assert payload["frontier_case_count"] == 6
    assert payload["frontier_count"] == 6
    assert payload["frontier_reason_count"] == 1
    assert payload["frontier_reasons"] == ["max_depth"]
    assert payload["frontier_reason_counts"] == [
        {"frontier_reason": "max_depth", "case_count": 6, "frontier_count": 6},
    ]
    assert payload["frontier_witness_count"] == 6
    assert payload["frontier_witness_limit"] == 8
    assert payload["frontier_witnesses_truncated"] is False
    assert payload["first_frontier_witness"] == payload["frontier_witnesses"][0]
    assert payload["frontier_witness_summary"]["witness_count"] == 6
    assert payload["frontier_witness_summary"]["reason_counts"] == [
        {"reason": "max_depth", "witness_count": 6},
    ]
    assert payload["frontier_witness_summary"]["min_depth"] == 0
    assert payload["frontier_witness_summary"]["max_depth"] == 0
    assert payload["frontier_witness_summary"]["witness_summary_truncated"] is False
    _assert_cli_homfly_frontier_witness_consistency(payload)
    first_report_witness = payload["first_frontier_witness"]
    assert first_report_witness["case_id"] == "L2a1:root:root"
    assert first_report_witness["recursive_path"] == ["root"]
    assert first_report_witness["reason"] == "max_depth"
    assert first_report_witness["cap"] == {
        "max_depth": 0,
        "max_nodes": 128,
    }
    assert payload["frontier_branch_depth_counts"] == [
        {"branch_depth": 0, "case_count": 1},
        {"branch_depth": 1, "case_count": 5},
    ]
    assert payload["truncated_branch_depth_counts"] == []
    assert payload["truncated_case_count"] == 0
    assert payload["accepted"] is False
    assert payload["full_table_normalization_certified"] is False
    assert payload["arbitrary_diagram_coverage_certified"] is False
    _assert_cli_blocker_detail_codes(
        payload,
        "homfly_completion_blocker_details",
        [
            "full_table_normalization_not_certified",
            "arbitrary_diagram_coverage_not_certified",
        ],
    )
    case_consistency = payload["case_evidence_consistency"]
    assert case_consistency["matched"] is True
    assert case_consistency["report_aggregate_totals"]["frontier_count"] == 6
    assert case_consistency["evidence_frontier_reason_counts"] == payload[
        "frontier_reason_counts"
    ]
    _assert_cli_homfly_blocker_detail_code_count_consistency(payload)
    gate = payload["arbitrary_diagram_completion_gate"]
    _assert_cli_homfly_arbitrary_completion_gate(gate)
    assert gate["frontier_exhausted"] is False
    assert gate["frontier_count"] == 6
    assert gate["frontier_case_count"] == 6
    assert gate["frontier_reasons"] == ["max_depth"]
    assert gate["first_frontier_witness"] == first_report_witness
    assert gate["certification_blockers"] == ["frontier_not_exhausted"]
    assert payload["homfly_completion_blocker_details"][1]["witness"] == gate

    source_summary = payload["source_notation_summary"][0]
    assert source_summary["source_notation"] == "L2a1"
    assert source_summary["frontier_case_count"] == 6
    assert source_summary["frontier_count"] == 6
    assert source_summary["frontier_reasons"] == ["max_depth"]
    assert source_summary["first_frontier_witness"] == first_report_witness
    assert source_summary["frontier_witness_summary"] == payload[
        "frontier_witness_summary"
    ]
    _assert_cli_homfly_frontier_witness_consistency(source_summary)
    assert source_summary["accepted"] is False

    frontier_cases = [case for case in payload["cases"] if case["frontier_count"] > 0]
    assert len(frontier_cases) == 6
    assert all(case["frontier_reasons"] == ["max_depth"] for case in frontier_cases)
    assert all(case["frontier_witness_count"] == 1 for case in frontier_cases)
    assert all(
        case["input_certification_evidence"]["frontier_reasons"] == ["max_depth"]
        for case in frontier_cases
    )
    assert all(
        case["first_frontier_witness"]
        == case["input_certification_evidence"]["first_frontier_witness"]
        for case in frontier_cases
    )
    assert all(
        [
            row["code"]
            for row in case["input_certification_evidence"][
                "certification_blocker_details"
            ]
        ]
        == ["frontier_not_exhausted"]
        for case in frontier_cases
    )
    first_frontier_detail = frontier_cases[0]["input_certification_evidence"][
        "certification_blocker_details"
    ][0]
    assert first_frontier_detail["cap"] == {
        "max_depth": 0,
        "max_nodes": 128,
    }
    assert first_frontier_detail["witness"]["frontier_reasons"] == ["max_depth"]
    assert first_frontier_detail["witness"]["first_frontier_witness"] == (
        frontier_cases[0]["first_frontier_witness"]
    )
    assert all(
        case["input_certification_evidence"]["full_table_normalization_certified"]
        is False
        for case in payload["cases"]
    )
    assert all(
        case["input_certification_evidence"]["arbitrary_diagram_coverage_certified"]
        is False
        for case in payload["cases"]
    )


def test_cli_imgui_payloads_preserve_homfly_frontier_cases_from_report_json(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        report_path = tmp_path / "homfly_small_frontier.json"
        coverage_exit = main(
            [
                "homfly-small-diagram-coverage",
                "--notation",
                "L2a1",
                "--branch-depth",
                "1",
                "--max-depth",
                "0",
                "--max-nodes",
                "128",
            ]
        )
        coverage = json.loads(capsys.readouterr().out)
        report_path.write_text(json.dumps(coverage), encoding="utf-8")

        analysis_exit = main(
            [
                "imgui-analysis-payload",
                "--report",
                "homfly",
                "--notation",
                "L2a1",
                "--analysis-report-json",
                str(report_path),
            ]
        )
        analysis = json.loads(capsys.readouterr().out)

        host_exit = main(
            [
                "imgui-host-payload",
                "--report",
                "homfly",
                "--notation",
                "L2a1",
                "--analysis-report-json",
                str(report_path),
            ]
        )
        host = json.loads(capsys.readouterr().out)

    assert coverage_exit == 0
    assert coverage["frontier_case_count"] == 6
    assert coverage["frontier_count"] == 6
    assert coverage["frontier_reasons"] == ["max_depth"]

    assert analysis_exit == 0
    assert analysis["analysis_generated_frontier_case_count"] == 6
    assert analysis["analysis_input_certification_frontier_count"] == 6
    assert analysis["analysis_failed_check_count"] == 6
    analysis_summaries = {
        row["source_method"]: row for row in analysis["analysis_summaries"]
    }
    analysis_coverage = analysis_summaries["homfly_small_diagram_coverage_report"]
    assert analysis_coverage["generated_frontier_case_count"] == 6
    assert analysis_coverage["input_certification_frontier_count"] == 6
    assert analysis_coverage["input_certification_frontier_reason_count"] == 1
    assert "frontier_cases=6" in analysis_coverage["notes"]

    assert host_exit == 0
    host_analysis = host["analysis"]
    assert host_analysis["analysis_generated_frontier_case_count"] == 6
    assert host_analysis["analysis_input_certification_frontier_count"] == 6
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    host_coverage = host_summaries["homfly_small_diagram_coverage_report"]
    assert host_coverage["generated_frontier_case_count"] == 6
    assert host_coverage["input_certification_frontier_count"] == 6
    assert "frontier_cases=6" in host_coverage["notes"]
    assert host["invariants"]["invariant_status_count"] == 1
    assert host["fixture_comparisons"]["fixture_comparison_count"] == 1


def test_cli_imgui_payloads_generate_homfly_frontier_cases_with_caps(
    capsys,
) -> None:
    analysis_exit = main(
        [
            "imgui-analysis-payload",
            "--report",
            "homfly",
            "--notation",
            "L2a1",
            "--include-homfly-small-coverage",
            "--branch-depth",
            "1",
            "--homfly-coverage-max-depth",
            "0",
            "--homfly-coverage-max-nodes",
            "128",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    host_exit = main(
        [
            "imgui-host-payload",
            "--report",
            "homfly",
            "--notation",
            "L2a1",
            "--include-homfly-small-coverage",
            "--branch-depth",
            "1",
            "--homfly-coverage-max-depth",
            "0",
            "--homfly-coverage-max-nodes",
            "128",
        ]
    )
    host = json.loads(capsys.readouterr().out)

    assert analysis_exit == 0
    assert payload["analysis_summary_count"] == 2
    assert payload["analysis_generated_frontier_case_count"] == 6
    assert payload["analysis_input_certification_frontier_count"] == 6
    assert payload["analysis_failed_check_count"] == 6
    assert payload["analysis_certification_uncertified_count"] == 6

    summaries = {row["source_method"]: row for row in payload["analysis_summaries"]}
    coverage = summaries["homfly_small_diagram_coverage_report"]
    assert coverage["required_check_count"] == 7
    assert coverage["passed_check_count"] == 1
    assert coverage["failed_check_count"] == 6
    assert coverage["certification_uncertified_count"] == 6
    assert coverage["generated_frontier_case_count"] == 6
    assert coverage["input_certification_frontier_count"] == 6
    assert coverage["input_certification_frontier_reason_count"] == 1
    assert "frontier_cases=6" in coverage["notes"]
    assert "source_notation_certified_cases=L2a1:1/7" in coverage["notes"]

    assert host_exit == 0
    host_analysis = host["analysis"]
    assert host_analysis["analysis_generated_frontier_case_count"] == 6
    assert host_analysis["analysis_input_certification_frontier_count"] == 6
    assert host_analysis["analysis_failed_check_count"] == 6
    host_summaries = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }
    host_coverage = host_summaries["homfly_small_diagram_coverage_report"]
    assert host_coverage["generated_frontier_case_count"] == 6
    assert host_coverage["input_certification_frontier_count"] == 6
    assert "frontier_cases=6" in host_coverage["notes"]


def test_cli_imgui_analysis_payload_passes_alexander_coverage_caps(capsys) -> None:
    exit_code = main(
        [
            "imgui-analysis-payload",
            "--report",
            "alexander",
            "--notation",
            "L2a1",
            "--include-alexander-signed-pd-coverage",
            "--branch-depth",
            "1",
            "--alexander-coverage-max-matrix-size",
            "3",
            "--alexander-coverage-max-minors",
            "1",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    summaries = {row["source_method"]: row for row in payload["analysis_summaries"]}
    coverage = summaries["multivariable_alexander_signed_pd_coverage_report"]
    assert coverage["required_check_count"] == 7
    assert coverage["passed_check_count"] == 2
    assert coverage["failed_check_count"] == 5
    assert coverage["certification_uncertified_count"] == 5
    assert coverage["bounded_scanned_gcd_scanned_minor_count"] == 7
    assert coverage["bounded_scanned_gcd_truncated_count"] == 5
    assert coverage["wirtinger_fox_scanned_minor_count"] == 7
    assert coverage["wirtinger_fox_truncated_count"] == 5
    assert "scanned_minors=7" in coverage["notes"]
    assert "source_notation_accepted_cases=L2a1:2/7" in coverage["notes"]


def test_cli_imgui_payloads_preserve_homfly_max_node_frontier_reason(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        report_path = tmp_path / "homfly-small-max-node-frontier.json"
        coverage_exit = main(
            [
                "homfly-small-diagram-coverage",
                "--notation",
                "L2a1",
                "--branch-depth",
                "1",
                "--max-depth",
                "8",
                "--max-nodes",
                "1",
            ]
        )
        coverage = json.loads(capsys.readouterr().out)
        report_path.write_text(json.dumps(coverage), encoding="utf-8")

        analysis_exit = main(
            [
                "imgui-analysis-payload",
                "--report",
                "homfly",
                "--notation",
                "L2a1",
                "--analysis-report-json",
                str(report_path),
            ]
        )
        analysis = json.loads(capsys.readouterr().out)

        host_exit = main(
            [
                "imgui-host-payload",
                "--report",
                "homfly",
                "--notation",
                "L2a1",
                "--analysis-report-json",
                str(report_path),
            ]
        )
        host = json.loads(capsys.readouterr().out)

    assert coverage_exit == 0
    assert coverage["frontier_case_count"] == 6
    assert coverage["frontier_reason_count"] == 1
    assert coverage["frontier_reasons"] == ["max_nodes"]
    assert coverage["frontier_reason_counts"] == [
        {"frontier_reason": "max_nodes", "case_count": 6, "frontier_count": 12}
    ]

    assert analysis_exit == 0
    assert analysis["analysis_generated_frontier_case_count"] == 6
    assert analysis["analysis_input_certification_frontier_reason_count"] == 1
    analysis_coverage = {
        row["source_method"]: row for row in analysis["analysis_summaries"]
    }["homfly_small_diagram_coverage_report"]
    assert analysis_coverage["generated_frontier_case_count"] == 6
    assert "frontier_reason_counts=max_nodes:6/12" in analysis_coverage["notes"]
    assert (
        "truncated_source_kind_counts=fixture_root:1,one_step_skein_branch:5"
        in analysis_coverage["notes"]
    )

    assert host_exit == 0
    host_analysis = host["analysis"]
    assert host_analysis["analysis_generated_frontier_case_count"] == 6
    assert host_analysis["analysis_input_certification_frontier_reason_count"] == 1
    host_coverage = {
        row["source_method"]: row for row in host_analysis["analysis_summaries"]
    }["homfly_small_diagram_coverage_report"]
    assert "frontier_reason_counts=max_nodes:6/12" in host_coverage["notes"]
    assert (
        "truncated_source_kind_counts=fixture_root:1,one_step_skein_branch:5"
        in host_coverage["notes"]
    )

def test_cli_generated_coverage_commands_accept_branch_depth(capsys) -> None:
    homfly_exit = main(
        [
            "homfly-small-diagram-coverage",
            "--notation",
            "L2a1",
            "--branch-depth",
            "2",
        ]
    )
    homfly = json.loads(capsys.readouterr().out)

    assert homfly_exit == 0
    assert homfly["branch_depth"] == 2
    assert homfly["max_generated_branch_depth"] == 2
    assert homfly["case_count"] == 37
    assert homfly["unique_diagram_count"] == 7
    assert homfly["unique_oriented_diagram_count"] == 9
    assert homfly["duplicate_diagram_case_count"] == 30
    assert homfly["multi_path_diagram_count"] == 7
    assert homfly["polynomial_variant_diagram_count"] >= 0
    assert homfly["max_homfly_polynomial_count_per_diagram"] >= 1
    assert homfly["oriented_polynomial_conflict_count"] == 0
    assert homfly["max_homfly_polynomial_count_per_oriented_diagram"] == 1
    assert homfly["certified_case_count"] == 37
    assert homfly["frontier_reason_count"] == 0
    assert homfly["accepted"] is True
    assert homfly["source_notation_summary"][0]["branch_depth_counts"] == [
        {"branch_depth": 0, "case_count": 1},
        {"branch_depth": 1, "case_count": 6},
        {"branch_depth": 2, "case_count": 30},
    ]

    alexander_exit = main(
        [
            "multivariable-alexander-signed-pd-coverage",
            "--notation",
            "L2a1",
            "--branch-depth",
            "2",
        ]
    )
    alexander = json.loads(capsys.readouterr().out)

    assert alexander_exit == 0
    assert alexander["branch_depth"] == 2
    assert alexander["max_generated_branch_depth"] == 2
    assert alexander["case_count"] == 37
    assert alexander["unique_oriented_diagram_count"] == 9
    assert alexander["accepted"] is True
    assert alexander["accepted_case_count"] == 37
    assert alexander["uncertified_case_count"] == 0
    assert alexander["result_skipped_case_count"] == 0
    assert alexander["zero_crossing_unlink_certified_case_count"] == 2
    assert alexander["scanned_minor_count"] == 118
    assert alexander["source_notation_summary"][0]["branch_depth_counts"] == [
        {"branch_depth": 0, "case_count": 1},
        {"branch_depth": 1, "case_count": 6},
        {"branch_depth": 2, "case_count": 30},
    ]
    assert alexander["source_notation_summary"][0][
        "zero_crossing_unlink_certified_case_count"
    ] == 2


def test_cli_generated_l2a1_coverage_retained_pack_exports_imgui_payloads(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        homfly_path = tmp_path / "homfly-small-coverage-l2a1.json"
        alexander_path = tmp_path / "alexander-signed-pd-coverage-l2a1.json"
        analysis_path = tmp_path / "generated-coverage-l2a1-imgui-analysis.json"
        host_path = tmp_path / "generated-coverage-l2a1-imgui-host.json"

        homfly_exit = main(
            [
                "homfly-small-diagram-coverage",
                "--notation",
                "L2a1",
                "--branch-depth",
                "1",
                "--max-depth",
                "8",
                "--max-nodes",
                "2048",
                "-o",
                str(homfly_path),
            ]
        )
        assert homfly_exit == 0
        assert capsys.readouterr().out == ""

        alexander_exit = main(
            [
                "multivariable-alexander-signed-pd-coverage",
                "--notation",
                "L2a1",
                "--branch-depth",
                "1",
                "--max-minors",
                "64",
                "-o",
                str(alexander_path),
            ]
        )
        assert alexander_exit == 0
        assert capsys.readouterr().out == ""

        analysis_exit = main(
            [
                "imgui-analysis-summary-payload",
                str(homfly_path),
                str(alexander_path),
                "-o",
                str(analysis_path),
            ]
        )
        assert analysis_exit == 0
        assert capsys.readouterr().out == ""

        host_exit = main(
            [
                "imgui-host-payload",
                "--analysis-report-json",
                str(homfly_path),
                "--analysis-report-json",
                str(alexander_path),
                "-o",
                str(host_path),
            ]
        )
        assert host_exit == 0
        assert capsys.readouterr().out == ""

        homfly = json.loads(homfly_path.read_text(encoding="utf-8"))
        alexander = json.loads(alexander_path.read_text(encoding="utf-8"))
        analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
        host = json.loads(host_path.read_text(encoding="utf-8"))
        _assert_strict_json_serializable(homfly, alexander, analysis, host)

    assert homfly["method"] == "homfly_small_diagram_coverage_report"
    assert homfly["claim_scope"] == "generated_small_signed_pd_frontier_exhaustion"
    assert homfly["source_notations"] == ["L2a1"]
    assert homfly["branch_depth"] == 1
    assert homfly["case_count"] == 7
    assert homfly["frontier_count"] == 0
    assert homfly["truncated_case_count"] == 0
    assert homfly["arbitrary_diagram_coverage_certified"] is False
    assert homfly["full_table_normalization_certified"] is False

    assert alexander["method"] == "multivariable_alexander_signed_pd_coverage_report"
    assert (
        alexander["claim_scope"]
        == "generated_small_signed_pd_wirtinger_fox_scanned_gcd_coverage"
    )
    assert alexander["source_notations"] == ["L2a1"]
    assert alexander["branch_depth"] == 1
    assert alexander["case_count"] == 7
    assert alexander["accepted_case_count"] == 7
    assert alexander["arbitrary_diagram_coverage_certified"] is False
    assert alexander["full_invariant_certified"] is False

    assert analysis["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert analysis["analysis_summary_count"] == 2
    summaries = {row["source_method"]: row for row in analysis["analysis_summaries"]}
    homfly_summary = summaries["homfly_small_diagram_coverage_report"]
    assert homfly_summary["required_check_count"] == 7
    assert homfly_summary["passed_check_count"] == 7
    assert homfly_summary["failed_check_count"] == 0
    assert homfly_summary["certification_certified_count"] == 7
    assert homfly_summary["generated_case_count"] == 7
    assert "branch_depth=1" in homfly_summary["notes"]
    assert "arbitrary signed-diagram coverage" in homfly_summary["notes"]

    alexander_summary = summaries[
        "multivariable_alexander_signed_pd_coverage_report"
    ]
    assert alexander_summary["required_check_count"] == 7
    assert alexander_summary["passed_check_count"] == 7
    assert alexander_summary["failed_check_count"] == 0
    assert alexander_summary["certification_certified_count"] == 7
    assert alexander_summary["generated_case_count"] == 7
    assert alexander_summary["bounded_scanned_gcd_scanned_minor_count"] == 26
    assert alexander_summary["bounded_scanned_gcd_failed_nonzero_minor_count"] == 0
    assert "scanned_minors=26" in alexander_summary["notes"]
    assert "not full admissible-minor normalization" in alexander_summary["notes"]

    assert host["method"] == "imgui_host_payload"
    host_summaries = {
        row["source_method"]: row for row in host["analysis"]["analysis_summaries"]
    }
    assert "homfly_small_diagram_coverage_report" in host_summaries
    assert "multivariable_alexander_signed_pd_coverage_report" in host_summaries
    homfly_host_summary = host_summaries["homfly_small_diagram_coverage_report"]
    assert homfly_host_summary["required_check_count"] == 7
    assert homfly_host_summary["passed_check_count"] == 7
    assert homfly_host_summary["failed_check_count"] == 0
    assert homfly_host_summary["certification_certified_count"] == 7
    assert homfly_host_summary["generated_case_count"] == 7
    assert "branch_depth=1" in homfly_host_summary["notes"]
    assert "arbitrary signed-diagram coverage" in homfly_host_summary["notes"]

    alexander_host_summary = host_summaries[
        "multivariable_alexander_signed_pd_coverage_report"
    ]
    assert alexander_host_summary["required_check_count"] == 7
    assert alexander_host_summary["passed_check_count"] == 7
    assert alexander_host_summary["failed_check_count"] == 0
    assert alexander_host_summary["certification_certified_count"] == 7
    assert alexander_host_summary["generated_case_count"] == 7
    assert alexander_host_summary["bounded_scanned_gcd_scanned_minor_count"] == 26
    assert (
        alexander_host_summary["bounded_scanned_gcd_failed_nonzero_minor_count"]
        == 0
    )
    assert "scanned_minors=26" in alexander_host_summary["notes"]
    assert "not full admissible-minor normalization" in alexander_host_summary["notes"]


def test_cli_analyze_link_writes_output_file(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        first, second = hopf_link_points(count=128)
        first_path = tmp_path / "first.json"
        second_path = tmp_path / "second.json"
        output_path = tmp_path / "report.json"
        first_path.write_text(json.dumps(first.tolist()), encoding="utf-8")
        second_path.write_text(json.dumps(second.tolist()), encoding="utf-8")

        exit_code = main(
            [
                "analyze-link",
                str(first_path),
                str(second_path),
                "--closed",
                "--direction",
                "0.3,0.5,1",
                "--output",
                str(output_path),
            ]
        )

        assert exit_code == 0
        assert capsys.readouterr().out == ""
        payload = json.loads(output_path.read_text(encoding="utf-8"))
        _assert_strict_json_serializable(payload)
        assert abs(payload["topology"]["linking_matrix"][0][1]) == 1.0
        assert payload["topology"]["link_type"] == "hopf_link"


def test_cli_analyze_link_preserves_pairwise_zero_candidate_summary(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        first = circle_points(count=96)
        second = circle_points(count=96).copy()
        second[:, 0] += 1.5
        second[:, 1] += 1.5
        first_path = tmp_path / "first.json"
        second_path = tmp_path / "second.json"
        output_path = tmp_path / "report.json"
        first_path.write_text(json.dumps(first.tolist()), encoding="utf-8")
        second_path.write_text(json.dumps(second.tolist()), encoding="utf-8")

        exit_code = main(
            [
                "analyze-link",
                str(first_path),
                str(second_path),
                "--closed",
                "--direction",
                "0,0,1",
                "--output",
                str(output_path),
            ]
        )

        assert exit_code == 0
        assert capsys.readouterr().out == ""
        payload = json.loads(output_path.read_text(encoding="utf-8"))
        _assert_strict_json_serializable(payload)
        classification = payload["topology"]["classification"]
        assert classification["link_type"] == "pairwise_unlink_candidate"
        summary = classification["table_candidate_summary"]
        assert "whitehead_link" in summary["nontrivial_link_types"]
        assert "L5a1" in summary["nontrivial_notations"]
        assert summary["source_table_nontrivial_candidate_count"] >= 1
        assert "L5a1" in summary["source_table_nontrivial_candidate_notations"]
        assert summary["source_table_distinguishing_evidence_available"] is True
        assert summary["stronger_invariants_required"] is True
        assert (
            summary[
                "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
            ]
            == 8
        )
        assert (
            summary[
                "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max"
            ]
            == 25
        )


def test_cli_imgui_geometry_payload_converts_existing_report(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        first, second = hopf_link_points(count=64)
        first_path = tmp_path / "first.json"
        second_path = tmp_path / "second.json"
        report_path = tmp_path / "report.json"
        first_path.write_text(json.dumps(first.tolist()), encoding="utf-8")
        second_path.write_text(json.dumps(second.tolist()), encoding="utf-8")

        analyze_exit = main(
            [
                "analyze-link",
                str(first_path),
                str(second_path),
                "--closed",
                "--direction",
                "0.3,0.5,1",
                "--output",
                str(report_path),
            ]
        )
        assert analyze_exit == 0
        assert capsys.readouterr().out == ""

        payload_exit = main(["imgui-geometry-payload", str(report_path)])
        payload = json.loads(capsys.readouterr().out)

    assert payload_exit == 0
    assert payload["method"] == "imgui_geometry_payload_from_report"
    assert payload["source_kind"] == "link"
    assert payload["component_count"] == 2
    assert payload["geometry_point_count"] == 128
    assert payload["component_point_counts"] == [64, 64]
    assert payload["component_closed"] == [1, 1]
    assert len(payload["flat_points"]) == 128 * 3
    assert payload["projected_crossing_count"] > 0
    assert payload["contact_count"] == 0


def test_cli_imgui_geometry_payload_preserves_pairwise_zero_classification_summary(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        first = circle_points(count=96)
        second = circle_points(count=96).copy()
        second[:, 0] += 1.5
        second[:, 1] += 1.5
        first_path = tmp_path / "first.json"
        second_path = tmp_path / "second.json"
        report_path = tmp_path / "report.json"
        first_path.write_text(json.dumps(first.tolist()), encoding="utf-8")
        second_path.write_text(json.dumps(second.tolist()), encoding="utf-8")

        analyze_exit = main(
            [
                "analyze-link",
                str(first_path),
                str(second_path),
                "--closed",
                "--direction",
                "0,0,1",
                "--output",
                str(report_path),
            ]
        )
        assert analyze_exit == 0
        assert capsys.readouterr().out == ""

        payload_exit = main(["imgui-geometry-payload", str(report_path)])
        payload = json.loads(capsys.readouterr().out)

    assert payload_exit == 0
    summary = payload["classification_summary"]
    assert summary["method"] == "imgui_classification_summary_from_report"
    assert summary["link_type"] == "pairwise_unlink_candidate"
    assert "whitehead_link" in summary["nontrivial_link_types"]
    assert "L5a1" in summary["nontrivial_notations"]
    assert summary["source_table_nontrivial_candidate_count"] >= 1
    assert "L5a1" in summary["source_table_nontrivial_candidate_notations"]
    assert summary["source_table_distinguishing_evidence_available"] is True
    assert summary["stronger_invariants_required"] is True
    assert summary["source_table_registration_blocker_codes"] == [
        "fixture_signs_not_registered",
        "registered_fixture_invariant_claim_disabled",
        "source_compatible_sign_pattern_not_unique",
        "source_table_values_uncomputed",
    ]
    assert summary["source_table_registration_blocker_code_counts"] == [
        {"code": "fixture_signs_not_registered", "count": 1},
        {"code": "registered_fixture_invariant_claim_disabled", "count": 1},
        {"code": "source_compatible_sign_pattern_not_unique", "count": 1},
        {"code": "source_table_values_uncomputed", "count": 1},
    ]
    assert summary["source_table_registration_blocker_count_signature"] == (
        "fixture_signs_not_registered:1,"
        "registered_fixture_invariant_claim_disabled:1,"
        "source_compatible_sign_pattern_not_unique:1,"
        "source_table_values_uncomputed:1"
    )
    assert (
        "source_table_registration_blockers=fixture_signs_not_registered:1,"
        "registered_fixture_invariant_claim_disabled:1,"
        "source_compatible_sign_pattern_not_unique:1,"
        "source_table_values_uncomputed:1"
    ) in summary["notes"]
    assert summary["source_table_source_match_resolution_status_count"] == 3
    assert set(summary["source_table_source_match_resolution_statuses"]) == {
        "L5a1:jones:source_seen_with_incomplete_candidates",
        "L5a1:homfly:not_computed",
        "L5a1:multivariable_alexander_numerator:source_seen_with_incomplete_candidates",
    }
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count"
        ]
        == 1
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min"
        ]
        == 25
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max"
        ]
        == 25
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 8
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max"
        ]
        == 25
    )


def test_cli_imgui_link_classification_summary_payload_flattens_for_c_abi(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        first = circle_points(count=96)
        second = circle_points(count=96).copy()
        second[:, 0] += 1.5
        second[:, 1] += 1.5
        first_path = tmp_path / "first.json"
        second_path = tmp_path / "second.json"
        report_path = tmp_path / "report.json"
        first_path.write_text(json.dumps(first.tolist()), encoding="utf-8")
        second_path.write_text(json.dumps(second.tolist()), encoding="utf-8")

        analyze_exit = main(
            [
                "analyze-link",
                str(first_path),
                str(second_path),
                "--closed",
                "--direction",
                "0,0,1",
                "--output",
                str(report_path),
            ]
        )
        assert analyze_exit == 0
        assert capsys.readouterr().out == ""

        payload_exit = main(
            ["imgui-link-classification-summary-payload", str(report_path)]
        )
        payload = json.loads(capsys.readouterr().out)

    assert payload_exit == 0
    assert payload["method"] == "imgui_link_classification_summary_payload_from_report"
    assert payload["has_link_classification_summary"] is True
    summary = payload["link_classification_summary"]
    assert summary["method"] == "imgui_classification_summary_from_report"
    assert summary["link_type"] == "pairwise_unlink_candidate"
    assert "whitehead_link" in summary["nontrivial_link_types"]
    assert "L5a1" in summary["nontrivial_notations"]
    assert summary["source_table_nontrivial_candidate_count"] >= 1
    assert "L5a1" in summary["source_table_nontrivial_candidate_notations"]
    assert summary["source_table_distinguishing_evidence_available"] is True
    assert summary["stronger_invariants_required"] is True
    assert summary["source_table_registration_blocker_codes"] == (
        "fixture_signs_not_registered,"
        "registered_fixture_invariant_claim_disabled,"
        "source_compatible_sign_pattern_not_unique,"
        "source_table_values_uncomputed"
    )
    assert summary["source_table_registration_blocker_code_count"] == 4
    assert summary["source_table_registration_blocker_count_signature"] == (
        "fixture_signs_not_registered:1,"
        "registered_fixture_invariant_claim_disabled:1,"
        "source_compatible_sign_pattern_not_unique:1,"
        "source_table_values_uncomputed:1"
    )
    assert (
        "source_table_registration_blockers=fixture_signs_not_registered:1,"
        "registered_fixture_invariant_claim_disabled:1,"
        "source_compatible_sign_pattern_not_unique:1,"
        "source_table_values_uncomputed:1"
    ) in summary["notes"]


def test_cli_imgui_link_classification_summary_payload_preserves_borromean_candidate(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        first = circle_points(count=96)
        second = circle_points(count=96).copy()
        third = circle_points(count=96).copy()
        second[:, 0] += 2.0
        third[:, 1] += 2.0
        first_path = tmp_path / "first.json"
        second_path = tmp_path / "second.json"
        third_path = tmp_path / "third.json"
        report_path = tmp_path / "report.json"
        first_path.write_text(json.dumps(first.tolist()), encoding="utf-8")
        second_path.write_text(json.dumps(second.tolist()), encoding="utf-8")
        third_path.write_text(json.dumps(third.tolist()), encoding="utf-8")

        analyze_exit = main(
            [
                "analyze-link",
                str(first_path),
                str(second_path),
                str(third_path),
                "--closed",
                "--direction",
                "0,0,1",
                "--output",
                str(report_path),
            ]
        )
        assert analyze_exit == 0
        assert capsys.readouterr().out == ""

        payload_exit = main(
            ["imgui-link-classification-summary-payload", str(report_path)]
        )
        payload = json.loads(capsys.readouterr().out)

    assert payload_exit == 0
    assert payload["has_link_classification_summary"] is True
    summary = payload["link_classification_summary"]
    assert summary["link_type"] == "pairwise_unlink_candidate"
    assert summary["component_count"] == 3
    assert summary["candidate_count"] == 1
    assert summary["nontrivial_link_types"] == "borromean_rings"
    assert summary["nontrivial_notations"] == "L6a4"
    assert summary["source_table_nontrivial_candidate_notations"] == "L6a4"
    assert summary["source_table_distinguishing_evidence_available"] is True
    assert summary["stronger_invariants_required"] is True
    assert summary["source_table_registration_blocker_codes"] == (
        "fixture_signs_not_registered,"
        "registered_fixture_invariant_claim_disabled,"
        "source_compatible_sign_pattern_not_unique,"
        "source_table_values_uncomputed"
    )
    assert summary["source_table_registration_blocker_code_count"] == 4
    assert summary["source_table_registration_blocker_count_signature"] == (
        "fixture_signs_not_registered:1,"
        "registered_fixture_invariant_claim_disabled:1,"
        "source_compatible_sign_pattern_not_unique:1,"
        "source_table_values_uncomputed:1"
    )
    assert summary["source_table_source_match_resolution_status_count"] == 3
    assert set(
        summary["source_table_source_match_resolution_statuses"].split(",")
    ) == {
        "L6a4:jones:complete_source_match",
        "L6a4:homfly:not_computed",
        "L6a4:multivariable_alexander_numerator:complete_source_match",
    }
    assert summary["source_table_homfly_variant_resolution_statuses"] == "not_computed"
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count"
        ]
        == 0
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count"
        ]
        == 0
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min"
        ]
        == 0
    )
    assert (
        summary[
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max"
        ]
        == 0
    )


def test_cli_imgui_acceptance_payload_commands_export_host_payloads(capsys) -> None:
    analysis_exit = main(
        [
            "imgui-analysis-payload",
            "--report",
            "homfly",
            "--notation",
            "0_1",
        ]
    )
    analysis = json.loads(capsys.readouterr().out)

    assert analysis_exit == 0
    assert analysis["method"] == "imgui_analysis_payload_from_acceptance_reports"
    assert analysis["analysis_summary_count"] == 1
    assert analysis["analysis_certification_applicable_count"] == 1
    assert analysis["analysis_certification_certified_count"] == 1
    assert analysis["analysis_certification_uncertified_count"] == 0
    assert (
        analysis[
            "analysis_source_table_audit_registration_summary_consistency_available_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_source_table_audit_registration_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        analysis[
            "analysis_source_table_audit_registration_summary_consistency_mismatch_count"
        ]
        == 0
    )
    analysis_summary = analysis["analysis_summaries"][0]
    assert (
        analysis_summary[
            "source_table_audit_registration_summary_consistency_available_count"
        ]
        == 1
    )
    assert (
        analysis_summary[
            "source_table_audit_registration_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        analysis_summary[
            "source_table_audit_registration_summary_consistency_status"
        ]
        == "matched"
    )

    coverage_exit = main(
        [
            "imgui-analysis-payload",
            "--report",
            "homfly",
            "--notation",
            "L2a1",
            "--include-homfly-small-coverage",
        ]
    )
    coverage = json.loads(capsys.readouterr().out)

    assert coverage_exit == 0
    assert coverage["analysis_summary_count"] == 2
    summaries_by_method = {
        row["source_method"]: row for row in coverage["analysis_summaries"]
    }
    small_coverage = summaries_by_method["homfly_small_diagram_coverage_report"]
    assert small_coverage["required_check_count"] == 7
    assert small_coverage["passed_check_count"] == 7
    assert small_coverage["failed_check_count"] == 0
    assert small_coverage["certification_applicable_count"] == 7
    assert small_coverage["certification_certified_count"] == 7
    assert small_coverage["certification_uncertified_count"] == 0
    assert "generated_cases=7" in small_coverage["notes"]
    assert "non_fixture_cases=6" in small_coverage["notes"]
    assert "branch_depth=1" in small_coverage["notes"]
    assert small_coverage["generated_unique_evaluation_count"] > 0
    assert small_coverage["generated_reused_evaluation_count"] >= 0
    assert "unique_evaluations=" in small_coverage["notes"]
    assert "reused_evaluations=" in small_coverage["notes"]
    assert "source_notation_certified_cases=L2a1:7/7" in small_coverage["notes"]
    assert "solved_depth_counts=" in small_coverage["notes"]
    assert "source_notation_solved_depth_counts=L2a1[" in small_coverage["notes"]

    alexander_coverage_exit = main(
        [
            "imgui-analysis-payload",
            "--report",
            "alexander",
            "--notation",
            "L2a1",
            "--include-alexander-signed-pd-coverage",
        ]
    )
    alexander_coverage = json.loads(capsys.readouterr().out)

    assert alexander_coverage_exit == 0
    assert alexander_coverage["analysis_summary_count"] == 2
    alexander_summaries = {
        row["source_method"]: row
        for row in alexander_coverage["analysis_summaries"]
    }
    signed_pd_coverage = alexander_summaries[
        "multivariable_alexander_signed_pd_coverage_report"
    ]
    assert signed_pd_coverage["required_check_count"] == 7
    assert signed_pd_coverage["passed_check_count"] == 7
    assert signed_pd_coverage["failed_check_count"] == 0
    assert signed_pd_coverage["bounded_scanned_gcd_failed_nonzero_minor_count"] == 0
    assert signed_pd_coverage["wirtinger_fox_truncated_count"] == 0
    assert signed_pd_coverage["generated_unique_evaluation_count"] > 0
    assert signed_pd_coverage["generated_reused_evaluation_count"] >= 0
    assert "generated_cases=7" in signed_pd_coverage["notes"]
    assert "non_fixture_cases=6" in signed_pd_coverage["notes"]
    assert "nonzero_unique_evaluations=" in signed_pd_coverage["notes"]
    assert "nonzero_reused_evaluations=" in signed_pd_coverage["notes"]
    assert "scanned_minors=26" in signed_pd_coverage["notes"]
    assert "source_notation_accepted_cases=L2a1:7/7" in signed_pd_coverage["notes"]
    assert "source_notation_scanned_minors=L2a1:26" in signed_pd_coverage["notes"]

    depth_two_exit = main(
        [
            "imgui-analysis-payload",
            "--report",
            "homfly",
            "--notation",
            "L2a1",
            "--include-homfly-small-coverage",
            "--branch-depth",
            "2",
        ]
    )
    depth_two = json.loads(capsys.readouterr().out)

    assert depth_two_exit == 0
    depth_two_summaries = {
        row["source_method"]: row for row in depth_two["analysis_summaries"]
    }
    assert (
        depth_two_summaries["homfly_small_diagram_coverage_report"][
            "required_check_count"
        ]
        == 37
    )
    assert depth_two["analysis_certification_certified_count"] == 38
    assert "generated_cases=37" in depth_two_summaries[
        "homfly_small_diagram_coverage_report"
    ]["notes"]
    assert "branch_depth=2" in depth_two_summaries[
        "homfly_small_diagram_coverage_report"
    ]["notes"]
    assert "source_notation_certified_cases=L2a1:37/37" in depth_two_summaries[
        "homfly_small_diagram_coverage_report"
    ]["notes"]
    assert "solved_depth_counts=" in depth_two_summaries[
        "homfly_small_diagram_coverage_report"
    ]["notes"]
    assert "source_notation_solved_depth_counts=L2a1[" in depth_two_summaries[
        "homfly_small_diagram_coverage_report"
    ]["notes"]
    fixture_exit = main(
        [
            "imgui-fixture-comparison-payload",
            "--report",
            "alexander",
            "--notation",
            "L2a1",
        ]
    )
    fixtures = json.loads(capsys.readouterr().out)

    assert fixture_exit == 0
    assert fixtures["method"] == (
        "imgui_fixture_comparison_payload_from_acceptance_reports"
    )
    assert fixtures["fixture_comparison_count"] == 1
    fixture = fixtures["fixture_comparisons"][0]
    assert fixture["fixture_name"] == "L2a1"
    assert fixture["bounded_scanned_gcd_certified"] is True
    assert fixture["full_invariant_certified"] is False

    invariant_exit = main(
        [
            "imgui-invariant-status-payload",
            "--report",
            "homfly",
            "--notation",
            "0_1",
        ]
    )
    invariants = json.loads(capsys.readouterr().out)

    assert invariant_exit == 0
    assert invariants["method"] == (
        "imgui_invariant_status_payload_from_acceptance_reports"
    )
    assert invariants["invariant_status_count"] == 1
    assert invariants["invariant_statuses"][0]["name"] == "HOMFLY-PT"
    assert (
        invariants[
            "invariant_source_table_audit_registration_summary_consistency_available_count"
        ]
        == 1
    )
    assert (
        invariants[
            "invariant_source_table_audit_registration_summary_consistency_matched_count"
        ]
        == 1
    )
    assert (
        invariants[
            "invariant_source_table_audit_registration_summary_consistency_mismatch_count"
        ]
        == 0
    )
    assert (
        invariants["invariant_statuses"][0][
            "source_table_audit_registration_summary_consistency_status"
        ]
        == "matched"
    )

    signed_exit = main(
        [
            "imgui-signed-pd-payload",
            "--report",
            "homfly",
            "--notation",
            "L2a1",
        ]
    )
    signed_pd = json.loads(capsys.readouterr().out)

    assert signed_exit == 0
    assert signed_pd["method"] == "imgui_signed_pd_payload_from_acceptance_reports"
    assert signed_pd["signed_pd_diagram_count"] == 1
    assert signed_pd["signed_pd_crossing_count"] == 2

    backend_exit = main(["imgui-kernel-backend-status-payload"])
    backend = json.loads(capsys.readouterr().out)

    assert backend_exit == 0
    assert backend["method"] == "imgui_kernel_backend_status_payload_from_backend_report"
    assert backend["kernel_backend_status_count"] >= 2
    assert isinstance(
        backend[
            "kernel_backend_invariant_result_handles_native_result_handles_complete_count"
        ],
        int,
    )
    assert isinstance(
        backend[
            "kernel_backend_invariant_result_handles_complete_result_handle_abi_count"
        ],
        int,
    )
    assert isinstance(
        backend[
            "kernel_backend_invariant_result_handles_release_grade_result_handles_count"
        ],
        int,
    )
    assert isinstance(
        backend[
            "kernel_backend_invariant_result_handles_readiness_provenance_present_count"
        ],
        int,
    )
    assert isinstance(
        backend[
            "kernel_backend_invariant_result_handles_ready_for_native_result_handles_count"
        ],
        int,
    )
    assert isinstance(
        backend[
            "kernel_backend_invariant_result_handles_readiness_blocked_by_required_gates_count"
        ],
        int,
    )
    assert isinstance(
        backend[
            "kernel_backend_invariant_result_handles_readiness_provenance_note_length_max"
        ],
        int,
    )
    assert {row["name"] for row in backend["kernel_backend_statuses"]} >= {
        "numpy",
        "gpu",
    }
    for row in backend["kernel_backend_statuses"]:
        assert isinstance(row["owned_string_contract_schema_version"], int)
        assert isinstance(row["owned_string_contract_abi_version"], int)
        assert isinstance(row["owned_string_contract_version_length"], int)
        assert isinstance(row["owned_string_contract_free_required"], bool)
        assert isinstance(
            row["owned_string_contract_free_accepts_zero_initialized"],
            bool,
        )
        assert isinstance(row["owned_string_contract_borrowed_across_calls"], bool)
        assert isinstance(
            row["invariant_result_handles_native_result_handles_complete"],
            bool,
        )
        assert isinstance(
            row["invariant_result_handles_complete_result_handle_abi"],
            bool,
        )
        assert isinstance(
            row["invariant_result_handles_release_grade_result_handles"],
            bool,
        )
        assert isinstance(
            row["invariant_result_handles_readiness_provenance_present"],
            bool,
        )
        assert isinstance(
            row["invariant_result_handles_ready_for_native_result_handles"],
            bool,
        )
        assert isinstance(
            row["invariant_result_handles_readiness_blocked_by_required_gates"],
            bool,
        )
        assert isinstance(
            row["invariant_result_handles_readiness_provenance_note_length"],
            int,
        )


def test_cli_imgui_analysis_payload_accepts_alexander_depth_two_coverage(capsys) -> None:
    exit_code = main(
        [
            "imgui-analysis-payload",
            "--report",
            "alexander",
            "--notation",
            "3_1",
            "--include-alexander-signed-pd-coverage",
            "--branch-depth",
            "2",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["analysis_summary_count"] == 2
    summaries = {row["source_method"]: row for row in payload["analysis_summaries"]}
    signed_pd_coverage = summaries[
        "multivariable_alexander_signed_pd_coverage_report"
    ]
    assert signed_pd_coverage["required_check_count"] == 82
    assert signed_pd_coverage["passed_check_count"] == 82
    assert signed_pd_coverage["failed_check_count"] == 0
    assert signed_pd_coverage["certification_applicable_count"] == 82
    assert signed_pd_coverage["certification_certified_count"] == 82
    assert signed_pd_coverage["bounded_scanned_gcd_scanned_minor_count"] == 549
    assert signed_pd_coverage["bounded_scanned_gcd_checked_nonzero_minor_count"] == 549
    assert signed_pd_coverage["bounded_scanned_gcd_complete_scan_count"] == 82
    assert (
        signed_pd_coverage["bounded_scanned_gcd_nonzero_minor_coverage_complete_count"]
        == 76
    )
    assert signed_pd_coverage["bounded_scanned_gcd_failed_nonzero_minor_count"] == 0
    assert signed_pd_coverage["wirtinger_fox_scanned_minor_count"] == 549
    assert signed_pd_coverage["wirtinger_fox_complete_scan_count"] == 82
    assert signed_pd_coverage["wirtinger_fox_truncated_count"] == 0
    assert "generated_cases=82" in signed_pd_coverage["notes"]
    assert "scanned_minors=549" in signed_pd_coverage["notes"]
    assert "failed_nonzero_minors=0" in signed_pd_coverage["notes"]
    assert "source_notation_accepted_cases=3_1:82/82" in signed_pd_coverage["notes"]
    assert "source_notation_scanned_minors=3_1:549" in signed_pd_coverage["notes"]
    assert (
        ALEXANDER_SOURCE_NOTATION_SUMMARY_CONSISTENCY_NOTE
        in signed_pd_coverage["notes"]
    )
    assert payload["analysis_certification_certified_count"] == 83


def test_cli_imgui_host_payload_accepts_depth_two_generated_coverage(capsys) -> None:
    exit_code = main(
        [
            "imgui-host-payload",
            "--report",
            "homfly",
            "--report",
            "alexander",
            "--notation",
            "3_1",
            "--include-homfly-small-coverage",
            "--include-alexander-signed-pd-coverage",
            "--branch-depth",
            "2",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["method"] == "imgui_host_payload"
    analysis = payload["analysis"]
    assert analysis["analysis_summary_count"] == 4
    assert analysis["analysis_required_check_count"] == 172
    assert analysis["analysis_passed_check_count"] == 172
    assert analysis["analysis_failed_check_count"] == 0
    assert analysis["analysis_certification_certified_count"] == 166
    summaries = {row["source_method"]: row for row in analysis["analysis_summaries"]}
    homfly_coverage = summaries["homfly_small_diagram_coverage_report"]
    assert homfly_coverage["required_check_count"] == 82
    assert homfly_coverage["passed_check_count"] == 82
    assert homfly_coverage["certification_certified_count"] == 82
    assert homfly_coverage["input_certification_frontier_count"] == 0
    assert homfly_coverage["input_certification_frontier_reason_count"] == 0
    assert homfly_coverage["input_certification_truncated_count"] == 0
    assert homfly_coverage["input_certification_iterative_solved_count"] == 82
    assert homfly_coverage["input_certification_iterative_max_solved_depth"] == 4
    assert homfly_coverage["generated_unique_evaluation_count"] > 0
    assert homfly_coverage["generated_reused_evaluation_count"] > 0
    assert homfly_coverage["homfly_case_evidence_consistency_available_count"] == 1
    assert homfly_coverage["homfly_case_evidence_consistency_matched_count"] == 1
    assert homfly_coverage["homfly_case_evidence_consistency_case_count"] == 82
    assert (
        homfly_coverage[
            "homfly_case_evidence_maturity_path_counts_matched_count"
        ]
        == 1
    )
    assert analysis["analysis_homfly_case_evidence_consistency_matched_count"] == 1
    assert "generated_cases=82" in homfly_coverage["notes"]
    assert "homfly_case_evidence_consistency=matched=True" in homfly_coverage["notes"]
    assert "branch_depth=2" in homfly_coverage["notes"]
    assert "unique_diagrams=11" in homfly_coverage["notes"]
    assert "source_notation_certified_cases=3_1:82/82" in homfly_coverage["notes"]
    assert (
        HOMFLY_SOURCE_NOTATION_SUMMARY_CONSISTENCY_NOTE
        in homfly_coverage["notes"]
    )
    alexander_coverage = summaries[
        "multivariable_alexander_signed_pd_coverage_report"
    ]
    assert alexander_coverage["required_check_count"] == 82
    assert alexander_coverage["passed_check_count"] == 82
    assert alexander_coverage["certification_certified_count"] == 82
    assert alexander_coverage["bounded_scanned_gcd_scanned_minor_count"] == 549
    assert alexander_coverage["bounded_scanned_gcd_failed_nonzero_minor_count"] == 0
    assert alexander_coverage["wirtinger_fox_scanned_minor_count"] == 549
    assert alexander_coverage["wirtinger_fox_truncated_count"] == 0
    assert alexander_coverage["generated_unique_evaluation_count"] > 0
    assert alexander_coverage["generated_reused_evaluation_count"] > 0
    assert "source_notation_accepted_cases=3_1:82/82" in alexander_coverage["notes"]
    assert "source_notation_scanned_minors=3_1:549" in alexander_coverage["notes"]
    assert (
        ALEXANDER_SOURCE_NOTATION_SUMMARY_CONSISTENCY_NOTE
        in alexander_coverage["notes"]
    )
    assert payload["invariants"]["invariant_status_count"] == 2
    assert payload["fixture_comparisons"]["fixture_comparison_count"] == 2
    assert payload["signed_pd"]["signed_pd_diagram_count"] == 2


def test_cli_imgui_analysis_payload_accepts_default_depth_two_generated_coverage(
    capsys,
) -> None:
    exit_code = main(
        [
            "imgui-analysis-payload",
            "--include-homfly-small-coverage",
            "--include-alexander-signed-pd-coverage",
            "--branch-depth",
            "2",
        ]
    )
    payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["analysis_summary_count"] == 4
    assert payload["analysis_required_check_count"] == 559
    assert payload["analysis_passed_check_count"] == 555
    assert payload["analysis_failed_check_count"] == 4
    assert payload["analysis_certification_applicable_count"] == 536
    assert payload["analysis_certification_certified_count"] == 532
    assert payload["analysis_certification_uncertified_count"] == 4
    assert payload["analysis_input_certification_iterative_attempt_count"] == 1160
    assert payload["analysis_input_certification_iterative_solved_count"] == 269
    assert payload["analysis_input_certification_iterative_max_solved_depth"] == 13
    assert payload["analysis_bounded_scanned_gcd_scanned_minor_count"] == 2508
    assert payload["analysis_bounded_scanned_gcd_checked_nonzero_minor_count"] == 2412
    assert payload["analysis_bounded_scanned_gcd_complete_scan_count"] == 261
    assert (
        payload["analysis_bounded_scanned_gcd_nonzero_minor_coverage_complete_count"]
        == 233
    )
    assert payload["analysis_bounded_scanned_gcd_quotient_gcd_certified_count"] == 261
    assert payload["analysis_bounded_scanned_gcd_complete_certified_count"] == 233
    assert payload["analysis_generated_source_notation_count"] == 6
    assert payload["analysis_generated_unique_evaluation_count"] > 0
    assert payload["analysis_generated_reused_evaluation_count"] > 0
    assert payload["analysis_generated_source_summary_consistency_matched"] is True
    assert payload["analysis_generated_source_summary_count_totals_matched"] is True
    assert (
        payload["analysis_generated_source_summary_distribution_totals_matched"]
        is True
    )
    assert (
        payload["analysis_generated_source_summary_frontier_reason_counts_matched"]
        is True
    )
    assert (
        payload[
            "analysis_generated_source_summary_source_notation_count_matches_fixture_count"
        ]
        is True
    )
    summaries = {row["source_method"]: row for row in payload["analysis_summaries"]}
    assert summaries["homfly_small_diagram_coverage_report"][
        "required_check_count"
    ] == 264
    assert "generated_cases=264" in summaries[
        "homfly_small_diagram_coverage_report"
    ]["notes"]
    assert "branch_depth=2" in summaries[
        "homfly_small_diagram_coverage_report"
    ]["notes"]
    assert "unique_evaluations=" in summaries[
        "homfly_small_diagram_coverage_report"
    ]["notes"]
    assert (
        "source_notation_certified_cases=L2a1:37/37,3_1:82/82,4_1:145/145"
        in summaries["homfly_small_diagram_coverage_report"]["notes"]
    )
    assert (
        HOMFLY_SOURCE_NOTATION_SUMMARY_CONSISTENCY_NOTE
        in summaries["homfly_small_diagram_coverage_report"]["notes"]
    )
    assert summaries["multivariable_alexander_signed_pd_coverage_report"][
        "required_check_count"
    ] == 264
    assert "generated_cases=264" in summaries[
        "multivariable_alexander_signed_pd_coverage_report"
    ]["notes"]
    assert "scanned_minors=2479" in summaries[
        "multivariable_alexander_signed_pd_coverage_report"
    ]["notes"]
    assert "nonzero_unique_evaluations=" in summaries[
        "multivariable_alexander_signed_pd_coverage_report"
    ]["notes"]
    assert (
        "source_notation_accepted_cases=L2a1:37/37,3_1:82/82,4_1:141/145"
        in summaries["multivariable_alexander_signed_pd_coverage_report"]["notes"]
    )
    assert (
        "source_notation_scanned_minors=L2a1:118,3_1:549,4_1:1812"
        in summaries["multivariable_alexander_signed_pd_coverage_report"]["notes"]
    )
    assert (
        ALEXANDER_SOURCE_NOTATION_SUMMARY_CONSISTENCY_NOTE
        in summaries["multivariable_alexander_signed_pd_coverage_report"]["notes"]
    )


def test_cli_imgui_host_payload_bundles_geometry_and_acceptance_sections(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        first, second = hopf_link_points(count=32)
        first_path = tmp_path / "first.json"
        second_path = tmp_path / "second.json"
        report_path = tmp_path / "report.json"
        first_path.write_text(json.dumps(first.tolist()), encoding="utf-8")
        second_path.write_text(json.dumps(second.tolist()), encoding="utf-8")

        analyze_exit = main(
            [
                "analyze-link",
                str(first_path),
                str(second_path),
                "--closed",
                "--direction",
                "0.3,0.5,1",
                "--output",
                str(report_path),
            ]
        )
        assert analyze_exit == 0
        assert capsys.readouterr().out == ""

        bundle_exit = main(
            [
                "imgui-host-payload",
                "--geometry-report",
                str(report_path),
                "--report",
                "homfly",
                "--notation",
                "L2a1",
                "--include-homfly-small-coverage",
                "--include-alexander-signed-pd-coverage",
            ]
        )
        bundle = json.loads(capsys.readouterr().out)

    assert bundle_exit == 0
    assert bundle["method"] == "imgui_host_payload"
    assert bundle["geometry"]["method"] == "imgui_geometry_payload_from_report"
    assert bundle["geometry"]["component_count"] == 2
    assert bundle["analysis"]["analysis_summary_count"] == 3
    bundle_summaries = {
        row["source_method"]: row for row in bundle["analysis"]["analysis_summaries"]
    }
    assert "homfly_fixture_acceptance_report" in bundle_summaries
    assert (
        bundle_summaries["homfly_small_diagram_coverage_report"]["required_check_count"]
        == 7
    )
    alexander_coverage = bundle_summaries[
        "multivariable_alexander_signed_pd_coverage_report"
    ]
    assert alexander_coverage["required_check_count"] == 7
    assert alexander_coverage["bounded_scanned_gcd_scanned_minor_count"] == 26
    assert alexander_coverage["bounded_scanned_gcd_complete_scan_count"] == 7
    assert alexander_coverage["bounded_scanned_gcd_quotient_gcd_certified_count"] == 7
    assert alexander_coverage["bounded_scanned_gcd_complete_certified_count"] == 5
    assert alexander_coverage["wirtinger_fox_scanned_minor_count"] == 26
    assert bundle["analysis"]["analysis_certification_certified_count"] == 15
    assert bundle["invariants"]["method"] == (
        "imgui_invariant_status_payload_from_acceptance_reports"
    )
    assert bundle["invariants"]["invariant_status_count"] == 1
    assert bundle["fixture_comparisons"]["fixture_comparison_count"] == 1
    assert bundle["signed_pd"]["signed_pd_diagram_count"] == 1
    assert bundle["kernel_backends"]["kernel_backend_status_count"] >= 2


def test_cli_imgui_host_payload_preserves_geometry_classification_summary(
    capsys,
) -> None:
    with workspace_tempdir() as tmp_path:
        first = circle_points(count=96)
        second = circle_points(count=96).copy()
        second[:, 0] += 1.5
        second[:, 1] += 1.5
        first_path = tmp_path / "first.json"
        second_path = tmp_path / "second.json"
        report_path = tmp_path / "report.json"
        first_path.write_text(json.dumps(first.tolist()), encoding="utf-8")
        second_path.write_text(json.dumps(second.tolist()), encoding="utf-8")

        analyze_exit = main(
            [
                "analyze-link",
                str(first_path),
                str(second_path),
                "--closed",
                "--direction",
                "0,0,1",
                "--output",
                str(report_path),
            ]
        )
        assert analyze_exit == 0
        assert capsys.readouterr().out == ""

        bundle_exit = main(
            [
                "imgui-host-payload",
                "--geometry-report",
                str(report_path),
                "--report",
                "homfly",
                "--notation",
                "L2a1",
            ]
        )
        bundle = json.loads(capsys.readouterr().out)

    assert bundle_exit == 0
    summary = bundle["geometry"]["classification_summary"]
    assert summary["method"] == "imgui_classification_summary_from_report"
    assert summary["link_type"] == "pairwise_unlink_candidate"
    assert summary["stronger_invariants_required"] is True
    assert summary["source_table_distinguishing_evidence_available"] is True
    assert "whitehead_link" in summary["nontrivial_link_types"]
    assert "L5a1" in summary["source_table_nontrivial_candidate_notations"]
    assert "source_table_values_uncomputed" in summary[
        "source_table_registration_blocker_codes"
    ]
    link_classification = bundle["link_classification"]
    assert (
        link_classification["method"]
        == "imgui_link_classification_summary_payload_from_report"
    )
    assert link_classification["has_link_classification_summary"] is True
    native_summary = link_classification["link_classification_summary"]
    assert native_summary["link_type"] == "pairwise_unlink_candidate"
    assert "whitehead_link" in native_summary["nontrivial_link_types"]
    assert "L5a1" in native_summary["source_table_nontrivial_candidate_notations"]
    assert native_summary["source_table_distinguishing_evidence_available"] is True
    assert native_summary["stronger_invariants_required"] is True
    assert "source_table_values_uncomputed" in native_summary[
        "source_table_registration_blocker_codes"
    ]
    assert (
        "source_table_registration_blockers=fixture_signs_not_registered:1,"
        "registered_fixture_invariant_claim_disabled:1,"
        "source_compatible_sign_pattern_not_unique:1,"
        "source_table_values_uncomputed:1"
    ) in native_summary["notes"]


def test_load_ribbon_json() -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "ribbon.json"
        points = [[0, 0, 0], [1, 0, 0]]
        directors = [[0, 1, 0], [0, 1, 0]]
        path.write_text(
            json.dumps({"name": "ribbon", "points": points, "directors": directors}),
            encoding="utf-8",
        )

        ribbon = load_ribbon_json(path)

        assert ribbon.name == "ribbon"
        assert ribbon.point_count == 2


def test_cli_analyze_ribbon_prints_json(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        path = tmp_path / "ribbon.json"
        points = [[0, 0, 0], [1, 0, 0], [2, 0, 0]]
        directors = [[0, 1, 0], [0, 0, 1], [0, -1, 0]]
        path.write_text(
            json.dumps({"points": points, "directors": directors}),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "analyze-ribbon",
                str(path),
                "--name",
                "half-turn",
                "--backend",
                "numpy",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert payload["input"]["name"] == "half-turn"
    assert np.isclose(payload["topology"]["twist"], 0.5)


def test_cli_render_report_writes_static_html(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        report_path = tmp_path / "report.json"
        html_path = tmp_path / "report.html"
        report_path.write_text(
            json.dumps(
                {
                    "input": {"name": "demo", "closed": True, "point_count": 3},
                    "topology": {
                        "writhe": 0.0,
                        "crossing_count": 0,
                        "crossings": [],
                        "classification": {
                            "knot_type": "unknot",
                            "method": "fixture",
                            "confidence": "high",
                        },
                    },
                    "warnings": [],
                    "runtime": {"requested_backend": "numpy"},
                    "version": "0.1.0",
                }
            ),
            encoding="utf-8",
        )

        exit_code = main(
            [
                "render-report",
                str(report_path),
                "--output",
                str(html_path),
                "--title",
                "Demo",
            ]
        )
        payload = json.loads(capsys.readouterr().out)

        assert exit_code == 0
        assert payload["format"] == "html"
        assert "Demo" in html_path.read_text(encoding="utf-8")


def test_cli_render_report_rejects_non_finite_json(capsys) -> None:
    with workspace_tempdir() as tmp_path:
        report_path = tmp_path / "report.json"
        html_path = tmp_path / "report.html"
        report_path.write_text(
            """
{
  "input": {"name": "demo"},
  "topology": {"writhe": NaN},
  "version": "0.1.0"
}
""".strip(),
            encoding="utf-8",
        )

        try:
            main(["render-report", str(report_path), "--output", str(html_path)])
        except ValueError as exc:
            assert "Out of range float values" in str(exc)
        else:
            raise AssertionError("render-report accepted non-finite JSON")

        assert capsys.readouterr().out == ""
        assert not html_path.exists()
