"""NumPy/scalar distance kernels."""

from __future__ import annotations

import numpy as np
from numpy.typing import ArrayLike

from iroll.core.types import FloatArray


def segment_segment_distance(
    a0: ArrayLike,
    a1: ArrayLike,
    b0: ArrayLike,
    b1: ArrayLike,
    *,
    eps: float = 1e-12,
) -> tuple[float, float, float, FloatArray, FloatArray]:
    """Return distance, segment parameters, and closest points for two 3D segments."""

    p0 = np.asarray(a0, dtype=np.float64)
    p1 = np.asarray(a1, dtype=np.float64)
    q0 = np.asarray(b0, dtype=np.float64)
    q1 = np.asarray(b1, dtype=np.float64)

    u = p1 - p0
    v = q1 - q0
    w = p0 - q0
    a = float(np.dot(u, u))
    b = float(np.dot(u, v))
    c = float(np.dot(v, v))
    d = float(np.dot(u, w))
    e = float(np.dot(v, w))
    denominator = a * c - b * b

    if a <= eps and c <= eps:
        s = 0.0
        t = 0.0
    elif a <= eps:
        s = 0.0
        t = _clamp(e / c if c > eps else 0.0)
    elif c <= eps:
        s = _clamp(-d / a)
        t = 0.0
    elif denominator > eps:
        s = _clamp((b * e - c * d) / denominator)
        t = (b * s + e) / c
        if t < 0.0:
            t = 0.0
            s = _clamp(-d / a)
        elif t > 1.0:
            t = 1.0
            s = _clamp((b - d) / a)
    else:
        s = 0.0
        t = _clamp(e / c if c > eps else 0.0)

    closest_a = p0 + s * u
    closest_b = q0 + t * v
    distance = float(np.linalg.norm(closest_a - closest_b))
    return distance, float(s), float(t), closest_a, closest_b


def segment_segment_distances(
    a0: ArrayLike,
    a1: ArrayLike,
    b0: ArrayLike,
    b1: ArrayLike,
    *,
    eps: float = 1e-12,
) -> tuple[FloatArray, FloatArray, FloatArray, FloatArray, FloatArray]:
    """Return vectorized distances and closest points for segment pairs."""

    p0 = _as_segment_array(a0, "a0")
    p1 = _as_segment_array(a1, "a1")
    q0 = _as_segment_array(b0, "b0")
    q1 = _as_segment_array(b1, "b1")
    _check_matching_batch_lengths(p0, p1, q0, q1)

    u = p1 - p0
    v = q1 - q0
    w = p0 - q0
    a = np.einsum("ij,ij->i", u, u)
    b = np.einsum("ij,ij->i", u, v)
    c = np.einsum("ij,ij->i", v, v)
    d = np.einsum("ij,ij->i", u, w)
    e = np.einsum("ij,ij->i", v, w)
    denominator = a * c - b * b

    count = len(p0)
    s = np.zeros(count, dtype=np.float64)
    t = np.zeros(count, dtype=np.float64)

    a_degenerate = a <= eps
    c_degenerate = c <= eps
    only_a_degenerate = a_degenerate & ~c_degenerate
    only_c_degenerate = c_degenerate & ~a_degenerate
    general = ~(a_degenerate | c_degenerate)
    nonparallel = general & (denominator > eps)
    parallel = general & ~nonparallel

    t[only_a_degenerate] = _clamp_array(_safe_divide(e[only_a_degenerate], c[only_a_degenerate]))
    s[only_c_degenerate] = _clamp_array(
        _safe_divide(-d[only_c_degenerate], a[only_c_degenerate])
    )

    initial_s = np.zeros(count, dtype=np.float64)
    initial_t = np.zeros(count, dtype=np.float64)
    initial_s[nonparallel] = _clamp_array(
        _safe_divide(
            b[nonparallel] * e[nonparallel] - c[nonparallel] * d[nonparallel],
            denominator[nonparallel],
        )
    )
    initial_t[nonparallel] = _safe_divide(
        b[nonparallel] * initial_s[nonparallel] + e[nonparallel],
        c[nonparallel],
    )
    t_before = nonparallel & (initial_t < 0.0)
    t_after = nonparallel & (initial_t > 1.0)
    t_inside = nonparallel & ~(t_before | t_after)
    s[t_before] = _clamp_array(_safe_divide(-d[t_before], a[t_before]))
    t[t_before] = 0.0
    s[t_after] = _clamp_array(_safe_divide(b[t_after] - d[t_after], a[t_after]))
    t[t_after] = 1.0
    s[t_inside] = initial_s[t_inside]
    t[t_inside] = initial_t[t_inside]

    t[parallel] = _clamp_array(_safe_divide(e[parallel], c[parallel]))

    closest_a = p0 + s[:, None] * u
    closest_b = q0 + t[:, None] * v
    distances = np.linalg.norm(closest_a - closest_b, axis=1)
    return distances, s, t, closest_a, closest_b


def segment_bbox_candidate_pairs_3d(
    min_x: ArrayLike,
    max_x: ArrayLike,
    min_y: ArrayLike,
    max_y: ArrayLike,
    min_z: ArrayLike,
    max_z: ArrayLike,
    component_ids: ArrayLike,
    segment_ids: ArrayLike,
    component_segment_counts: ArrayLike,
    component_closed: ArrayLike,
    order_rank: ArrayLike,
    *,
    threshold: float,
    include_adjacent: bool = False,
) -> tuple[np.ndarray, np.ndarray]:
    """Return upper-triangle 3D bbox-overlap contact candidate pairs."""

    if threshold < 0.0:
        raise ValueError("threshold must be non-negative")
    min_x_array = _as_vector(min_x, "min_x", dtype=np.float64)
    max_x_array = _as_vector(max_x, "max_x", dtype=np.float64)
    min_y_array = _as_vector(min_y, "min_y", dtype=np.float64)
    max_y_array = _as_vector(max_y, "max_y", dtype=np.float64)
    min_z_array = _as_vector(min_z, "min_z", dtype=np.float64)
    max_z_array = _as_vector(max_z, "max_z", dtype=np.float64)
    component_array = _as_vector(component_ids, "component_ids", dtype=np.int64)
    segment_array = _as_vector(segment_ids, "segment_ids", dtype=np.int64)
    rank_array = _as_vector(order_rank, "order_rank", dtype=np.int64)
    _check_matching_batch_lengths(
        min_x_array,
        max_x_array,
        min_y_array,
        max_y_array,
        min_z_array,
        max_z_array,
        component_array,
        segment_array,
        rank_array,
    )

    count = len(min_x_array)
    if count < 2:
        return np.asarray([], dtype=np.int64), np.asarray([], dtype=np.int64)

    component_segment_counts_array = _as_vector(
        component_segment_counts,
        "component_segment_counts",
        dtype=np.int64,
    )
    component_closed_array = _as_vector(
        component_closed,
        "component_closed",
        dtype=np.bool_,
    )
    rows, columns = np.triu_indices(count, k=1)
    bbox_overlap = (
        (max_x_array[rows] + threshold >= min_x_array[columns])
        & (max_x_array[columns] + threshold >= min_x_array[rows])
        & (max_y_array[rows] + threshold >= min_y_array[columns])
        & (max_y_array[columns] + threshold >= min_y_array[rows])
        & (max_z_array[rows] + threshold >= min_z_array[columns])
        & (max_z_array[columns] + threshold >= min_z_array[rows])
    )

    if include_adjacent:
        valid = bbox_overlap
    else:
        same_component = component_array[rows] == component_array[columns]
        segment_distance = np.abs(segment_array[rows] - segment_array[columns])
        adjacent = same_component & (segment_distance <= 1)
        closed_pair = same_component & component_closed_array[component_array[rows]]
        closing_adjacent = (
            closed_pair
            & (
                segment_distance
                >= component_segment_counts_array[component_array[rows]] - 1
            )
        )
        valid = bbox_overlap & ~(adjacent | closing_adjacent)

    rows = rows[valid]
    columns = columns[valid]
    if len(rows) == 0:
        return np.asarray([], dtype=np.int64), np.asarray([], dtype=np.int64)

    left_first = rank_array[rows] < rank_array[columns]
    left = np.where(left_first, rows, columns).astype(np.int64)
    right = np.where(left_first, columns, rows).astype(np.int64)
    order = np.lexsort((rank_array[left], rank_array[right]))
    return left[order], right[order]


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


def _as_segment_array(values: ArrayLike, name: str) -> FloatArray:
    array = np.asarray(values, dtype=np.float64)
    if array.ndim != 2 or array.shape[1] != 3:
        raise ValueError(f"{name} must have shape (n, 3)")
    return array


def _as_vector(values: ArrayLike, name: str, *, dtype) -> np.ndarray:
    array = np.asarray(values, dtype=dtype)
    if array.ndim != 1:
        raise ValueError(f"{name} must be a one-dimensional array")
    return array


def _check_matching_batch_lengths(*arrays: np.ndarray) -> None:
    lengths = {len(array) for array in arrays}
    if len(lengths) != 1:
        raise ValueError("segment endpoint arrays must have the same length")


def _safe_divide(numerator: FloatArray, denominator: FloatArray) -> FloatArray:
    return np.divide(
        numerator,
        denominator,
        out=np.zeros_like(numerator, dtype=np.float64),
        where=denominator != 0.0,
    )


def _clamp_array(values: FloatArray) -> FloatArray:
    return np.clip(values, 0.0, 1.0)
