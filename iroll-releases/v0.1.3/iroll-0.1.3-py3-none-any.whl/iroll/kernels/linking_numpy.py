"""NumPy Gaussian linking number kernel."""

from __future__ import annotations

import numpy as np
from numpy.typing import ArrayLike

from iroll.core.types import as_points3d


def compute_gaussian_linking_number(
    points_a: ArrayLike,
    points_b: ArrayLike,
    *,
    closed_a: bool = True,
    closed_b: bool = True,
    chunk_size: int = 128,
    eps: float = 1e-12,
) -> float:
    starts_a, ends_a = _segments(points_a, closed=closed_a)
    starts_b, ends_b = _segments(points_b, closed=closed_b)
    vectors_a = ends_a - starts_a
    vectors_b = ends_b - starts_b
    midpoints_a = 0.5 * (starts_a + ends_a)
    midpoints_b = 0.5 * (starts_b + ends_b)

    total = 0.0
    for start in range(0, len(vectors_a), chunk_size):
        stop = min(start + chunk_size, len(vectors_a))
        diff = midpoints_a[start:stop, None, :] - midpoints_b[None, :, :]
        cross = np.cross(vectors_a[start:stop, None, :], vectors_b[None, :, :])
        numerator = np.einsum("ijk,ijk->ij", cross, diff)
        denominator = np.linalg.norm(diff, axis=2) ** 3
        values = np.divide(
            numerator,
            denominator,
            out=np.zeros_like(numerator),
            where=denominator > eps,
        )
        total += float(values.sum())

    return total / (4.0 * np.pi)


def _segments(points: ArrayLike, *, closed: bool) -> tuple[np.ndarray, np.ndarray]:
    points = as_points3d(points)
    if closed:
        return points, np.roll(points, -1, axis=0)
    return points[:-1], points[1:]
