"""NumPy 2D segment intersection kernels."""

from __future__ import annotations

import numpy as np
from numpy.typing import ArrayLike

from iroll.core.types import FloatArray


def segment_intersections_2d(
    p0: ArrayLike,
    p1: ArrayLike,
    q0: ArrayLike,
    q1: ArrayLike,
    *,
    eps: float = 1e-10,
) -> tuple[np.ndarray, FloatArray, FloatArray, FloatArray, FloatArray]:
    """Return batched strict interior intersections for 2D segment pairs."""

    p0_array = _as_segment_array(p0, "p0")
    p1_array = _as_segment_array(p1, "p1")
    q0_array = _as_segment_array(q0, "q0")
    q1_array = _as_segment_array(q1, "q1")
    _check_matching_batch_lengths(p0_array, p1_array, q0_array, q1_array)

    r = p1_array - p0_array
    s = q1_array - q0_array
    denominator = _cross2d(r, s)
    delta = q0_array - p0_array
    t = _safe_divide(_cross2d(delta, s), denominator)
    u = _safe_divide(_cross2d(delta, r), denominator)
    hit = (
        (np.abs(denominator) > eps)
        & (t > eps)
        & (t < 1.0 - eps)
        & (u > eps)
        & (u < 1.0 - eps)
    )
    points = p0_array + t[:, None] * r
    return hit, t, u, np.ascontiguousarray(points), denominator


def segment_bbox_candidate_pairs_2d(
    min_x: ArrayLike,
    max_x: ArrayLike,
    min_y: ArrayLike,
    max_y: ArrayLike,
    component_ids: ArrayLike,
    segment_ids: ArrayLike,
    component_segment_counts: ArrayLike,
    component_closed: ArrayLike,
    order_rank: ArrayLike,
    *,
    eps: float = 1e-10,
) -> tuple[np.ndarray, np.ndarray]:
    """Return strict upper-triangle 2D bbox-overlap candidate segment pairs."""

    min_x_array = _as_vector(min_x, "min_x", dtype=np.float64)
    max_x_array = _as_vector(max_x, "max_x", dtype=np.float64)
    min_y_array = _as_vector(min_y, "min_y", dtype=np.float64)
    max_y_array = _as_vector(max_y, "max_y", dtype=np.float64)
    component_array = _as_vector(component_ids, "component_ids", dtype=np.int64)
    segment_array = _as_vector(segment_ids, "segment_ids", dtype=np.int64)
    rank_array = _as_vector(order_rank, "order_rank", dtype=np.int64)
    _check_matching_batch_lengths(
        min_x_array,
        max_x_array,
        min_y_array,
        max_y_array,
        component_array,
        segment_array,
        rank_array,
    )

    count = len(min_x_array)
    if count < 2:
        return np.asarray([], dtype=np.int64), np.asarray([], dtype=np.int64)

    component_segment_counts_array = _as_vector(
        component_segment_counts,
        "component_segment_counts",
        dtype=np.int64,
    )
    component_closed_array = _as_vector(
        component_closed,
        "component_closed",
        dtype=np.bool_,
    )
    rows, columns = np.triu_indices(count, k=1)
    bbox_overlap = (
        (max_x_array[rows] + eps >= min_x_array[columns])
        & (max_x_array[columns] + eps >= min_x_array[rows])
        & (max_y_array[rows] + eps >= min_y_array[columns])
        & (max_y_array[columns] + eps >= min_y_array[rows])
    )

    same_component = component_array[rows] == component_array[columns]
    segment_distance = np.abs(segment_array[rows] - segment_array[columns])
    adjacent = same_component & (segment_distance <= 1)
    closed_pair = same_component & component_closed_array[component_array[rows]]
    closing_adjacent = (
        closed_pair
        & (
            segment_distance
            >= component_segment_counts_array[component_array[rows]] - 1
        )
    )
    valid = bbox_overlap & ~(adjacent | closing_adjacent)
    rows = rows[valid]
    columns = columns[valid]
    if len(rows) == 0:
        return np.asarray([], dtype=np.int64), np.asarray([], dtype=np.int64)

    left_first = rank_array[rows] < rank_array[columns]
    left = np.where(left_first, rows, columns).astype(np.int64)
    right = np.where(left_first, columns, rows).astype(np.int64)
    order = np.lexsort((rank_array[left], rank_array[right]))
    return left[order], right[order]


def _as_segment_array(values: ArrayLike, name: str) -> FloatArray:
    array = np.asarray(values, dtype=np.float64)
    if array.ndim != 2 or array.shape[1] != 2:
        raise ValueError(f"{name} must have shape (n, 2)")
    return array


def _as_vector(values: ArrayLike, name: str, *, dtype) -> np.ndarray:
    array = np.asarray(values, dtype=dtype)
    if array.ndim != 1:
        raise ValueError(f"{name} must be a one-dimensional array")
    return array


def _check_matching_batch_lengths(*arrays: np.ndarray) -> None:
    lengths = {len(array) for array in arrays}
    if len(lengths) != 1:
        raise ValueError("segment endpoint arrays must have the same length")


def _cross2d(left: FloatArray, right: FloatArray) -> FloatArray:
    return left[:, 0] * right[:, 1] - left[:, 1] * right[:, 0]


def _safe_divide(numerator: FloatArray, denominator: FloatArray) -> FloatArray:
    return np.divide(
        numerator,
        denominator,
        out=np.zeros_like(numerator, dtype=np.float64),
        where=denominator != 0.0,
    )
