"""NumPy writhe kernel."""

from __future__ import annotations

import numpy as np
from numpy.typing import ArrayLike

from iroll.core.types import as_points3d


def compute_writhe(
    points: ArrayLike,
    *,
    closed: bool = False,
    chunk_size: int = 128,
    eps: float = 1e-12,
) -> float:
    starts, ends = _segments(points, closed=closed)
    vectors = ends - starts
    midpoints = 0.5 * (starts + ends)
    count = len(vectors)
    if count < 2:
        return 0.0

    total = 0.0
    all_indices = np.arange(count)[None, :]
    for start in range(0, count, chunk_size):
        stop = min(start + chunk_size, count)
        chunk_indices = np.arange(start, stop)[:, None]
        diff = midpoints[start:stop, None, :] - midpoints[None, :, :]
        cross = np.cross(vectors[start:stop, None, :], vectors[None, :, :])
        numerator = np.einsum("ijk,ijk->ij", cross, diff)
        denominator = np.linalg.norm(diff, axis=2) ** 3

        mask = _self_or_adjacent_mask(chunk_indices, all_indices, count=count, closed=closed)
        values = np.divide(
            numerator,
            denominator,
            out=np.zeros_like(numerator),
            where=(denominator > eps) & ~mask,
        )
        total += float(values.sum())

    return total / (4.0 * np.pi)


def _segments(points: ArrayLike, *, closed: bool) -> tuple[np.ndarray, np.ndarray]:
    points = as_points3d(points)
    if closed:
        return points, np.roll(points, -1, axis=0)
    return points[:-1], points[1:]


def _self_or_adjacent_mask(
    rows: np.ndarray,
    columns: np.ndarray,
    *,
    count: int,
    closed: bool,
) -> np.ndarray:
    distance = np.abs(rows - columns)
    mask = distance <= 1
    if closed:
        mask |= distance >= count - 1
    return mask
