"""Public 2D intersection kernel facade."""

from __future__ import annotations

from numpy.typing import ArrayLike

from iroll.kernels.backend import (
    KernelBackend,
    KernelBackendError,
    load_gpu_module,
    load_rust_module,
)
from iroll.kernels.intersections_numpy import (
    segment_bbox_candidate_pairs_2d as segment_bbox_candidate_pairs_2d_numpy,
    segment_intersections_2d as segment_intersections_2d_numpy,
)


def segment_intersections_2d(
    p0: ArrayLike,
    p1: ArrayLike,
    q0: ArrayLike,
    q1: ArrayLike,
    *,
    backend: KernelBackend = "numpy",
    eps: float = 1e-10,
):
    if backend == "rust":
        rust_module = load_rust_module()
        if rust_module is None or not hasattr(rust_module, "segment_intersections_2d"):
            raise KernelBackendError("Rust 2D intersection kernel is not installed")
        return rust_module.segment_intersections_2d(p0, p1, q0, q1, eps=eps)
    if backend == "gpu":
        gpu_module = load_gpu_module()
        if gpu_module is None or not hasattr(gpu_module, "segment_intersections_2d"):
            raise KernelBackendError("GPU 2D intersection kernel is not installed")
        return gpu_module.segment_intersections_2d(p0, p1, q0, q1, eps=eps)
    if backend in {"auto", "numpy"}:
        return segment_intersections_2d_numpy(p0, p1, q0, q1, eps=eps)
    raise ValueError("backend must be 'auto', 'numpy', 'rust', or 'gpu'")


def segment_bbox_candidate_pairs_2d(
    min_x: ArrayLike,
    max_x: ArrayLike,
    min_y: ArrayLike,
    max_y: ArrayLike,
    component_ids: ArrayLike,
    segment_ids: ArrayLike,
    component_segment_counts: ArrayLike,
    component_closed: ArrayLike,
    order_rank: ArrayLike,
    *,
    backend: KernelBackend = "numpy",
    eps: float = 1e-10,
):
    if backend == "rust":
        rust_module = load_rust_module()
        if rust_module is None or not hasattr(rust_module, "segment_bbox_candidate_pairs_2d"):
            raise KernelBackendError("Rust 2D candidate-pair kernel is not installed")
        return rust_module.segment_bbox_candidate_pairs_2d(
            min_x,
            max_x,
            min_y,
            max_y,
            component_ids,
            segment_ids,
            component_segment_counts,
            component_closed,
            order_rank,
            eps=eps,
        )
    if backend == "gpu":
        gpu_module = load_gpu_module()
        if gpu_module is None or not hasattr(gpu_module, "segment_bbox_candidate_pairs_2d"):
            raise KernelBackendError("GPU 2D candidate-pair kernel is not installed")
        return gpu_module.segment_bbox_candidate_pairs_2d(
            min_x,
            max_x,
            min_y,
            max_y,
            component_ids,
            segment_ids,
            component_segment_counts,
            component_closed,
            order_rank,
            eps=eps,
        )
    if backend in {"auto", "numpy"}:
        return segment_bbox_candidate_pairs_2d_numpy(
            min_x,
            max_x,
            min_y,
            max_y,
            component_ids,
            segment_ids,
            component_segment_counts,
            component_closed,
            order_rank,
            eps=eps,
        )
    raise ValueError("backend must be 'auto', 'numpy', 'rust', or 'gpu'")
