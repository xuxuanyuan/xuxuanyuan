"""Public linking number kernel facade."""

from __future__ import annotations

from numpy.typing import ArrayLike

from iroll.kernels.backend import (
    KernelBackend,
    load_gpu_module,
    load_rust_module,
    resolve_backend,
)
from iroll.kernels.linking_numpy import (
    compute_gaussian_linking_number as compute_gaussian_linking_number_numpy,
)


def compute_gaussian_linking_number(
    points_a: ArrayLike,
    points_b: ArrayLike,
    *,
    closed_a: bool = True,
    closed_b: bool = True,
    backend: KernelBackend = "auto",
    chunk_size: int = 128,
    eps: float = 1e-12,
) -> float:
    rust_module = load_rust_module()
    gpu_module = load_gpu_module()
    selected = resolve_backend(
        backend,
        rust_available=rust_module is not None,
        gpu_available=gpu_module is not None,
    )
    if selected == "rust":
        return float(
            rust_module.compute_gaussian_linking_number(  # type: ignore[union-attr]
                points_a,
                points_b,
                closed_a=closed_a,
                closed_b=closed_b,
                eps=eps,
            )
        )
    if selected == "gpu":
        return float(
            gpu_module.compute_gaussian_linking_number(  # type: ignore[union-attr]
                points_a,
                points_b,
                closed_a=closed_a,
                closed_b=closed_b,
                eps=eps,
            )
        )
    return compute_gaussian_linking_number_numpy(
        points_a,
        points_b,
        closed_a=closed_a,
        closed_b=closed_b,
        chunk_size=chunk_size,
        eps=eps,
    )
