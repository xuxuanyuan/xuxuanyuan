"""Public writhe kernel facade."""

from __future__ import annotations

from numpy.typing import ArrayLike

from iroll.kernels.backend import (
    KernelBackend,
    load_gpu_module,
    load_rust_module,
    resolve_backend,
)
from iroll.kernels.writhe_numpy import compute_writhe as compute_writhe_numpy


def compute_writhe(
    points: ArrayLike,
    *,
    closed: bool = False,
    backend: KernelBackend = "auto",
    chunk_size: int = 128,
    eps: float = 1e-12,
) -> float:
    rust_module = load_rust_module()
    gpu_module = load_gpu_module()
    selected = resolve_backend(
        backend,
        rust_available=rust_module is not None,
        gpu_available=gpu_module is not None,
    )
    if selected == "rust":
        return float(
            rust_module.compute_writhe(  # type: ignore[union-attr]
                points,
                closed=closed,
                eps=eps,
            )
        )
    if selected == "gpu":
        return float(
            gpu_module.compute_writhe(  # type: ignore[union-attr]
                points,
                closed=closed,
                eps=eps,
            )
        )
    return compute_writhe_numpy(
        points,
        closed=closed,
        chunk_size=chunk_size,
        eps=eps,
    )
