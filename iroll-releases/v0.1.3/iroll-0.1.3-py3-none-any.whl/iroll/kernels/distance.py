"""Public distance kernel facade."""

from __future__ import annotations

from numpy.typing import ArrayLike

from iroll.kernels.backend import (
    KernelBackend,
    KernelBackendError,
    load_gpu_module,
    load_rust_module,
    resolve_backend,
)
from iroll.kernels.distance_numpy import (
    segment_bbox_candidate_pairs_3d as segment_bbox_candidate_pairs_3d_numpy,
    segment_segment_distance as segment_distance_numpy,
    segment_segment_distances as segment_distances_numpy,
)


def segment_segment_distance(
    a0: ArrayLike,
    a1: ArrayLike,
    b0: ArrayLike,
    b1: ArrayLike,
    *,
    backend: KernelBackend = "auto",
    eps: float = 1e-12,
):
    rust_module = load_rust_module()
    gpu_module = load_gpu_module()
    selected = resolve_backend(
        backend,
        rust_available=rust_module is not None,
        gpu_available=gpu_module is not None,
    )
    if selected == "rust":
        return rust_module.segment_segment_distance(  # type: ignore[union-attr]
            a0,
            a1,
            b0,
            b1,
            eps=eps,
        )
    if selected == "gpu":
        return gpu_module.segment_segment_distance(  # type: ignore[union-attr]
            a0,
            a1,
            b0,
            b1,
            eps=eps,
        )
    return segment_distance_numpy(a0, a1, b0, b1, eps=eps)


def segment_segment_distances(
    a0: ArrayLike,
    a1: ArrayLike,
    b0: ArrayLike,
    b1: ArrayLike,
    *,
    backend: KernelBackend = "auto",
    eps: float = 1e-12,
):
    rust_module = load_rust_module()
    gpu_module = load_gpu_module()
    selected = resolve_backend(
        backend,
        rust_available=rust_module is not None,
        gpu_available=gpu_module is not None,
    )
    if selected == "gpu" and hasattr(gpu_module, "segment_segment_distances"):
        return gpu_module.segment_segment_distances(  # type: ignore[union-attr]
            a0,
            a1,
            b0,
            b1,
            eps=eps,
        )
    if selected == "rust" and hasattr(rust_module, "segment_segment_distances"):
        return rust_module.segment_segment_distances(  # type: ignore[union-attr]
            a0,
            a1,
            b0,
            b1,
            eps=eps,
        )
    if selected == "rust":
        return _segment_distances_scalar_loop(
            a0,
            a1,
            b0,
            b1,
            backend="rust",
            eps=eps,
        )
    return segment_distances_numpy(a0, a1, b0, b1, eps=eps)


def segment_bbox_candidate_pairs_3d(
    min_x: ArrayLike,
    max_x: ArrayLike,
    min_y: ArrayLike,
    max_y: ArrayLike,
    min_z: ArrayLike,
    max_z: ArrayLike,
    component_ids: ArrayLike,
    segment_ids: ArrayLike,
    component_segment_counts: ArrayLike,
    component_closed: ArrayLike,
    order_rank: ArrayLike,
    *,
    threshold: float,
    include_adjacent: bool = False,
    backend: KernelBackend = "numpy",
):
    if backend == "rust":
        rust_module = load_rust_module()
        if rust_module is None or not hasattr(rust_module, "segment_bbox_candidate_pairs_3d"):
            raise KernelBackendError("Rust 3D candidate-pair kernel is not installed")
        return rust_module.segment_bbox_candidate_pairs_3d(  # type: ignore[union-attr]
            min_x,
            max_x,
            min_y,
            max_y,
            min_z,
            max_z,
            component_ids,
            segment_ids,
            component_segment_counts,
            component_closed,
            order_rank,
            threshold=threshold,
            include_adjacent=include_adjacent,
        )
    if backend == "gpu":
        gpu_module = load_gpu_module()
        if gpu_module is None or not hasattr(gpu_module, "segment_bbox_candidate_pairs_3d"):
            raise KernelBackendError("GPU 3D candidate-pair kernel is not installed")
        return gpu_module.segment_bbox_candidate_pairs_3d(  # type: ignore[union-attr]
            min_x,
            max_x,
            min_y,
            max_y,
            min_z,
            max_z,
            component_ids,
            segment_ids,
            component_segment_counts,
            component_closed,
            order_rank,
            threshold=threshold,
            include_adjacent=include_adjacent,
        )
    if backend in {"auto", "numpy"}:
        return segment_bbox_candidate_pairs_3d_numpy(
            min_x,
            max_x,
            min_y,
            max_y,
            min_z,
            max_z,
            component_ids,
            segment_ids,
            component_segment_counts,
            component_closed,
            order_rank,
            threshold=threshold,
            include_adjacent=include_adjacent,
        )
    raise ValueError("backend must be 'auto', 'numpy', 'rust', or 'gpu'")


def _segment_distances_scalar_loop(
    a0: ArrayLike,
    a1: ArrayLike,
    b0: ArrayLike,
    b1: ArrayLike,
    *,
    backend: KernelBackend,
    eps: float,
):
    import numpy as np

    p0 = np.asarray(a0, dtype=np.float64)
    p1 = np.asarray(a1, dtype=np.float64)
    q0 = np.asarray(b0, dtype=np.float64)
    q1 = np.asarray(b1, dtype=np.float64)
    distances = []
    parameters_a = []
    parameters_b = []
    closest_a = []
    closest_b = []
    for endpoints in zip(p0, p1, q0, q1):
        distance, parameter_a, parameter_b, point_a, point_b = segment_segment_distance(
            *endpoints,
            backend=backend,
            eps=eps,
        )
        distances.append(distance)
        parameters_a.append(parameter_a)
        parameters_b.append(parameter_b)
        closest_a.append(point_a)
        closest_b.append(point_b)
    return (
        np.asarray(distances, dtype=np.float64),
        np.asarray(parameters_a, dtype=np.float64),
        np.asarray(parameters_b, dtype=np.float64),
        np.asarray(closest_a, dtype=np.float64),
        np.asarray(closest_b, dtype=np.float64),
    )
