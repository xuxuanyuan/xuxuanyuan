"""Backend selection for numeric kernels."""

from __future__ import annotations

from types import ModuleType
from typing import Literal

KernelBackend = Literal["auto", "numpy", "rust", "gpu"]


class KernelBackendError(RuntimeError):
    """Raised when a requested numeric backend is unavailable."""


def resolve_backend(
    backend: KernelBackend,
    *,
    rust_available: bool,
    gpu_available: bool = False,
) -> Literal["numpy", "rust", "gpu"]:
    if backend == "numpy":
        return "numpy"
    if backend == "rust":
        if rust_available:
            return "rust"
        raise KernelBackendError("Rust kernels are not installed")
    if backend == "gpu":
        if gpu_available:
            return "gpu"
        raise KernelBackendError("GPU kernels are not installed")
    if backend == "auto":
        return "rust" if rust_available else "numpy"
    raise ValueError("backend must be 'auto', 'numpy', 'rust', or 'gpu'")


def load_rust_module() -> ModuleType | None:
    try:
        import iroll_kernels_rust  # type: ignore[import-not-found]
    except ImportError:
        return None
    return iroll_kernels_rust


def load_gpu_module() -> ModuleType | None:
    try:
        import iroll_kernels_gpu  # type: ignore[import-not-found]
    except ImportError:
        return None
    return iroll_kernels_gpu
