"""Numeric kernels with pure NumPy fallback implementations."""

from iroll.kernels.backend import KernelBackendError
from iroll.kernels.diagnostics import (
    backend_report,
    rust_native_extension_path,
    rust_unsupported_invariant_result_handle_report,
)
from iroll.kernels.distance import (
    segment_bbox_candidate_pairs_3d,
    segment_segment_distance,
    segment_segment_distances,
)
from iroll.kernels.intersections import (
    segment_bbox_candidate_pairs_2d,
    segment_intersections_2d,
)
from iroll.kernels.linking import compute_gaussian_linking_number
from iroll.kernels.writhe import compute_writhe

__all__ = [
    "KernelBackendError",
    "backend_report",
    "compute_gaussian_linking_number",
    "compute_writhe",
    "rust_native_extension_path",
    "rust_unsupported_invariant_result_handle_report",
    "segment_bbox_candidate_pairs_2d",
    "segment_bbox_candidate_pairs_3d",
    "segment_intersections_2d",
    "segment_segment_distance",
    "segment_segment_distances",
]
