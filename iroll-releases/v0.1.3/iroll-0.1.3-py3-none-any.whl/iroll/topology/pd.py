"""Planar diagram utilities and small-diagram polynomial invariants."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from itertools import permutations, product
from typing import Iterable, Literal

from iroll.topology.polynomial import LaurentPolynomial, format_laurent_dict


SIGNED_PD_POSITION_ROLES = ("under_in", "over_in", "under_out", "over_out")


@dataclass(frozen=True)
class PDCrossing:
    code: tuple[int, int, int, int]
    sign: int = 1

    def __post_init__(self) -> None:
        if len(self.code) != 4:
            raise ValueError("PD crossing code must have four edge labels")
        if self.sign not in {-1, 1}:
            raise ValueError("PD crossing sign must be -1 or 1")

    def to_dict(self) -> dict:
        return {
            "code": list(self.code),
            "sign": self.sign,
        }

    @classmethod
    def from_value(cls, value: "PDCrossing | dict | Iterable[int]") -> "PDCrossing":
        if isinstance(value, PDCrossing):
            return value
        if isinstance(value, dict):
            return cls(tuple(int(item) for item in value["code"]), sign=int(value.get("sign", 1)))
        return cls(tuple(int(item) for item in value))


@dataclass(frozen=True)
class PDCrossingOrientation:
    under_in: int
    under_out: int
    over_in: int
    over_out: int

    @property
    def edge_labels(self) -> tuple[int, int, int, int]:
        return (self.under_in, self.under_out, self.over_in, self.over_out)

    def to_dict(self) -> dict:
        return {
            "under_in": self.under_in,
            "under_out": self.under_out,
            "over_in": self.over_in,
            "over_out": self.over_out,
        }

    @classmethod
    def from_value(cls, value: "PDCrossingOrientation | dict") -> "PDCrossingOrientation":
        if isinstance(value, PDCrossingOrientation):
            return value
        return cls(
            under_in=int(value["under_in"]),
            under_out=int(value["under_out"]),
            over_in=int(value["over_in"]),
            over_out=int(value["over_out"]),
        )


@dataclass(frozen=True)
class PDOrientation:
    crossings: tuple[PDCrossingOrientation, ...]
    edge_components: tuple[tuple[int, int], ...] = ()
    convention: str = "explicit_pd_edge_orientation_v1"

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "crossings",
            tuple(PDCrossingOrientation.from_value(crossing) for crossing in self.crossings),
        )
        object.__setattr__(
            self,
            "edge_components",
            tuple((int(label), int(component)) for label, component in self.edge_components),
        )

    def to_dict(self) -> dict:
        return {
            "convention": self.convention,
            "crossings": [crossing.to_dict() for crossing in self.crossings],
            "edge_components": [
                {"edge": label, "component": component}
                for label, component in self.edge_components
            ],
        }

    @classmethod
    def from_dict(cls, payload: dict) -> "PDOrientation":
        raw_components = payload.get("edge_components", [])
        components = tuple(
            (
                int(item["edge"] if isinstance(item, dict) else item[0]),
                int(item["component"] if isinstance(item, dict) else item[1]),
            )
            for item in raw_components
        )
        return cls(
            tuple(PDCrossingOrientation.from_value(item) for item in payload.get("crossings", [])),
            edge_components=components,
            convention=payload.get("convention", "explicit_pd_edge_orientation_v1"),
        )

    @classmethod
    def from_signed_pd_roles(
        cls,
        diagram: "PlanarDiagram",
        *,
        role_order: tuple[int, int, int, int] = (0, 1, 2, 3),
    ) -> "PDOrientation":
        """Infer explicit orientation metadata from iroll's signed-PD roles.

        The current signed-PD fixture convention stores each crossing code as
        `(under_in, over_in, under_out, over_out)`. This helper makes that
        convention executable and derives component ids by following the two
        oriented strands through every crossing.

        `role_order` is a conservative fixture-reconciliation escape hatch:
        it maps canonical roles `(under_in, over_in, under_out, over_out)` to
        crossing-code positions. The default preserves iroll's documented
        position-role convention.
        """

        role_order = _validate_role_order(role_order)
        crossings = tuple(
            _crossing_orientation_from_role_order(crossing, role_order=role_order)
            for crossing in diagram.crossings
        )
        edge_components = _infer_oriented_edge_components(diagram, role_order=role_order)
        return cls(
            crossings,
            edge_components=edge_components,
            convention=_role_order_convention(role_order),
        )

    @classmethod
    def from_signed_pd_role_orders(
        cls,
        diagram: "PlanarDiagram",
        role_orders: Iterable[Iterable[int]],
        *,
        convention: str | None = None,
    ) -> "PDOrientation":
        """Infer orientation metadata from per-crossing signed-PD role orders.

        Each role order maps canonical roles `(under_in, over_in, under_out,
        over_out)` to the four positions of the corresponding crossing code.
        This is the host/fixture path for external cyclic PD sources where one
        global position convention is not sufficient.
        """

        normalized_orders = tuple(_validate_role_order(order) for order in role_orders)
        if len(normalized_orders) != diagram.crossing_count:
            raise ValueError("signed-PD role_orders must match diagram crossing count")
        crossings = tuple(
            _crossing_orientation_from_role_order(crossing, role_order=role_order)
            for crossing, role_order in zip(diagram.crossings, normalized_orders)
        )
        edge_components = _infer_oriented_edge_components_from_orientations(
            diagram,
            crossings,
        )
        return cls(
            crossings,
            edge_components=edge_components,
            convention=convention or _role_orders_convention(normalized_orders),
        )

    @classmethod
    def role_permutation_candidates(
        cls,
        diagram: "PlanarDiagram",
        *,
        include_component_mismatches: bool = False,
    ) -> tuple[dict, ...]:
        """Return signed-PD role permutations that induce valid orientations.

        This does not choose a mathematical convention. It is intended for
        fixture audits where a PD source may store crossing positions in a
        different role order than iroll's documented default.

        By default candidates must also match `diagram.component_count`. When
        `include_component_mismatches` is true, flow-valid permutations are
        reported with `strict=False` so fixture diagnostics can expose why a
        source convention is still unresolved.
        """

        candidates = []
        for role_order in permutations(range(4)):
            crossings = tuple(
                _crossing_orientation_from_role_order(
                    crossing,
                    role_order=role_order,  # type: ignore[arg-type]
                )
                for crossing in diagram.crossings
            )
            flow_orientation = cls(
                crossings,
                convention=_role_order_convention(role_order),
            )
            flow_diagram = PlanarDiagram(
                diagram.crossings,
                component_count=None,
                name=diagram.name,
                convention=diagram.convention,
            )
            if flow_orientation.validation_issues(flow_diagram):
                continue
            traversals = flow_orientation.oriented_component_traversals(flow_diagram)
            component_count = len(traversals)
            component_count_matches = (
                diagram.component_count is None
                or component_count == diagram.component_count
            )
            if not component_count_matches and not include_component_mismatches:
                continue

            orientation = flow_orientation
            strict = False
            notes = []
            try:
                strict_orientation = cls.from_signed_pd_roles(
                    diagram,
                    role_order=role_order,  # type: ignore[arg-type]
                )
            except ValueError:
                if component_count_matches:
                    notes.append("strict signed-PD role inference failed unexpectedly")
            else:
                strict_issues = strict_orientation.validation_issues(diagram)
                if not strict_issues:
                    orientation = strict_orientation
                    strict = True
                    traversals = orientation.oriented_component_traversals(diagram)
                elif component_count_matches:
                    notes.extend(strict_issues)
            if not strict and component_count_matches:
                continue
            if not component_count_matches:
                notes.append(
                    "flow-valid role permutation induces "
                    f"{component_count} oriented components, but diagram declares "
                    f"{diagram.component_count}"
                )
            candidates.append(
                {
                    "role_order": role_order,
                    "role_mapping": _role_mapping_for_order(role_order),
                    "orientation": orientation,
                    "component_count": component_count,
                    "component_count_matches": component_count_matches,
                    "strict": strict,
                    "traversals": traversals,
                    "notes": notes,
                }
            )
        return tuple(candidates)

    @classmethod
    def local_role_assignment_summary(
        cls,
        diagram: "PlanarDiagram",
        *,
        max_samples: int = 8,
        max_assignments: int = 500_000,
        include_component_mismatches: bool = False,
    ) -> dict:
        """Audit per-crossing signed-PD role assignments for small fixtures.

        Unlike `role_permutation_candidates`, this lets each crossing use its
        own position-role order. It is diagnostic only: multiple valid local
        assignments mean the fixture still needs an explicit source convention
        before HOMFLY or Alexander evaluation should choose one.
        """

        if max_samples < 0:
            raise ValueError("max_samples must be non-negative")
        role_orders = tuple(permutations(range(4)))
        assignment_count = len(role_orders) ** diagram.crossing_count
        if assignment_count > max_assignments:
            return _flow_pruned_local_role_assignment_summary(
                cls,
                diagram,
                role_orders=role_orders,
                assignment_count=assignment_count,
                max_samples=max_samples,
                max_flow_assignments=max_assignments,
                include_component_mismatches=include_component_mismatches,
            )

        flow_diagram = PlanarDiagram(
            diagram.crossings,
            component_count=None,
            name=diagram.name,
            convention=diagram.convention,
        )
        candidate_count = 0
        samples = []
        for role_assignment in product(role_orders, repeat=diagram.crossing_count):
            raw_orientation = cls(
                tuple(
                    _crossing_orientation_from_role_order(
                        crossing,
                        role_order=role_order,  # type: ignore[arg-type]
                    )
                    for crossing, role_order in zip(diagram.crossings, role_assignment)
                ),
                convention="signed_pd_local_role_assignment_v1",
            )
            if raw_orientation.validation_issues(flow_diagram):
                continue
            traversals = raw_orientation.oriented_component_traversals(flow_diagram)
            component_count_matches = (
                diagram.component_count is None
                or len(traversals) == diagram.component_count
            )
            if not component_count_matches and not include_component_mismatches:
                continue

            edge_components = tuple(
                sorted(
                    (int(label), int(component_index))
                    for component_index, traversal in enumerate(traversals)
                    for label in traversal["edges"]
                )
            )
            orientation = cls(
                raw_orientation.crossings,
                edge_components=edge_components,
                convention="signed_pd_local_role_assignment_v1",
            )
            issues = orientation.validation_issues(diagram)
            strict = not issues
            if not strict and not include_component_mismatches:
                continue

            candidate_count += 1
            if len(samples) < max_samples:
                notes = list(issues)
                if not component_count_matches:
                    notes.append(
                        "local role assignment component count does not match diagram.component_count"
                    )
                samples.append(
                    {
                        "role_orders": [list(order) for order in role_assignment],
                        "component_count": len(traversals),
                        "component_count_matches": component_count_matches,
                        "strict": strict,
                        "traversals": traversals,
                        "notes": notes,
                    }
                )

        return {
            "method": "signed_pd_local_role_assignment_summary",
            "assignment_count": assignment_count,
            "candidate_count": candidate_count,
            "sample_count": len(samples),
            "samples": samples,
            "truncated": candidate_count > len(samples),
            "skipped": False,
            "notes": [
                "per-crossing role assignments are diagnostics and are not selected automatically",
            ],
        }

    def component_for_edge(self, label: int, *, default: int | None = None) -> int:
        mapping = dict(self.edge_components)
        if label in mapping:
            return mapping[label]
        if default is not None:
            return default
        raise KeyError(label)

    def oriented_successor_map(self, diagram: "PlanarDiagram") -> dict[int, int]:
        issues = self.validation_issues(diagram)
        if issues:
            raise ValueError("; ".join(issues))
        return _orientation_successor_map(self.crossings)

    def oriented_component_traversals(self, diagram: "PlanarDiagram") -> tuple[dict, ...]:
        """Return deterministic edge-label cycles induced by this orientation."""

        issues = self.validation_issues(diagram)
        if issues:
            raise ValueError("; ".join(issues))
        successor = _orientation_successor_map(self.crossings)
        component_by_edge = dict(self.edge_components)
        traversals = []
        seen: set[int] = set()
        for start in diagram.edge_labels:
            if start in seen:
                continue
            current = start
            edges = []
            while current not in seen:
                seen.add(current)
                edges.append(current)
                current = successor[current]
            if current != start:
                raise ValueError("orientation successor map does not form closed component cycles")
            component_values = {
                component_by_edge[label]
                for label in edges
                if label in component_by_edge
            }
            component = min(component_values) if component_values else len(traversals)
            traversals.append(
                {
                    "component": component,
                    "edges": edges,
                    "length": len(edges),
                }
            )
        return tuple(
            sorted(
                traversals,
                key=lambda item: (int(item["component"]), list(item["edges"])),
            )
        )

    def validation_issues(self, diagram: "PlanarDiagram") -> list[str]:
        issues: list[str] = []
        if len(self.crossings) != diagram.crossing_count:
            issues.append("orientation crossing count must match diagram crossing count")
            return issues
        diagram_labels = set(diagram.edge_labels)
        component_map: dict[int, int] = {}
        duplicate_component_labels: list[int] = []
        negative_component_labels: list[int] = []
        out_of_range_component_labels: list[int] = []
        for label, component in self.edge_components:
            if component < 0:
                negative_component_labels.append(label)
            if diagram.component_count is not None and component >= diagram.component_count:
                out_of_range_component_labels.append(label)
            if label in component_map:
                duplicate_component_labels.append(label)
            component_map[label] = component
        if duplicate_component_labels:
            issues.append(
                "edge_components must assign each edge label at most once; "
                f"duplicates {sorted(set(duplicate_component_labels))}"
            )
        if negative_component_labels:
            issues.append(
                "edge_components must use non-negative component ids; "
                f"invalid labels {sorted(set(negative_component_labels))}"
            )
        if out_of_range_component_labels:
            issues.append(
                "edge_components must be below diagram.component_count; "
                f"invalid labels {sorted(set(out_of_range_component_labels))}"
            )
        component_labels = set(component_map)
        unknown_component_labels = sorted(component_labels - diagram_labels)
        if unknown_component_labels:
            issues.append(f"edge_components contain labels not in diagram: {unknown_component_labels}")
        incoming_counts = {label: 0 for label in diagram_labels}
        outgoing_counts = {label: 0 for label in diagram_labels}
        for index, (crossing, orientation) in enumerate(zip(diagram.crossings, self.crossings)):
            crossing_labels = set(crossing.code)
            role_labels = set(orientation.edge_labels)
            if role_labels != crossing_labels:
                issues.append(
                    f"orientation crossing {index} labels must match PD crossing labels"
                )
                continue
            for label in (orientation.under_in, orientation.over_in):
                incoming_counts[label] += 1
            for label in (orientation.under_out, orientation.over_out):
                outgoing_counts[label] += 1
        bad_flow_labels = [
            (
                label,
                incoming_counts[label],
                outgoing_counts[label],
            )
            for label in sorted(diagram_labels)
            if incoming_counts[label] != 1 or outgoing_counts[label] != 1
        ]
        if bad_flow_labels:
            issues.append(
                "orientation must assign each edge label exactly once as incoming "
                f"and once as outgoing; invalid flow counts {bad_flow_labels}"
            )
        if diagram.component_count not in {None, 1}:
            missing = sorted(diagram_labels - component_labels)
            if missing:
                issues.append(
                    "edge_components must include every edge label for multi-component diagrams; "
                    f"missing {missing}"
                )
        if not issues:
            successor = _orientation_successor_map(self.crossings)
            cycles = _successor_cycles(successor, sorted(diagram_labels))
            if diagram.component_count is not None and len(cycles) > diagram.component_count:
                issues.append(
                    "orientation component cycle count must not exceed diagram.component_count; "
                    f"inferred {len(cycles)}, expected at most {diagram.component_count}"
                )
            for cycle in cycles if component_map else []:
                component_values = {
                    component_map[label]
                    for label in cycle
                    if label in component_map
                }
                if len(component_values) > 1:
                    issues.append(
                        "edge_components must be constant along each oriented component; "
                        f"cycle {cycle} has components {sorted(component_values)}"
                    )
        return issues


@dataclass(frozen=True)
class PlanarDiagram:
    crossings: tuple[PDCrossing, ...]
    component_count: int | None = None
    name: str | None = None
    convention: str = "signed_pd"

    def __post_init__(self) -> None:
        crossings = tuple(PDCrossing.from_value(crossing) for crossing in self.crossings)
        labels = [label for crossing in crossings for label in crossing.code]
        counts = {label: labels.count(label) for label in sorted(set(labels))}
        invalid = {label: count for label, count in counts.items() if count != 2}
        if invalid:
            raise ValueError(
                "standard PD edge labels must appear exactly twice; "
                f"invalid counts: {invalid}"
            )
        object.__setattr__(self, "crossings", crossings)

    @property
    def crossing_count(self) -> int:
        return len(self.crossings)

    @property
    def edge_labels(self) -> list[int]:
        return sorted({label for crossing in self.crossings for label in crossing.code})

    @property
    def writhe(self) -> int:
        return sum(crossing.sign for crossing in self.crossings)

    def pd_code(self) -> list[list[int]]:
        return [list(crossing.code) for crossing in self.crossings]

    def signed_pd_code(self) -> list[dict]:
        return [crossing.to_dict() for crossing in self.crossings]

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "convention": self.convention,
            "component_count": self.component_count,
            "crossing_count": self.crossing_count,
            "edge_labels": self.edge_labels,
            "writhe": self.writhe,
            "pd_code": self.pd_code(),
            "signed_pd_code": self.signed_pd_code(),
            "canonical_key": self.canonical_key(),
            "split_components": self.edge_component_sets(),
        }

    @classmethod
    def from_dict(cls, payload: dict) -> "PlanarDiagram":
        crossings = payload.get("signed_pd_code") or payload.get("pd_code") or []
        return cls(
            tuple(PDCrossing.from_value(crossing) for crossing in crossings),
            component_count=payload.get("component_count"),
            name=payload.get("name"),
            convention=payload.get("convention", "signed_pd"),
        )

    def canonical_key(self) -> tuple[tuple[int, tuple[int, int, int, int]], ...]:
        relabeled = self.relabel_edges()
        return tuple((crossing.sign, crossing.code) for crossing in relabeled.crossings)

    def relabel_edges(self) -> "PlanarDiagram":
        relabeled, _ = self.relabel_edges_with_mapping()
        return relabeled

    def relabel_edges_with_mapping(self) -> tuple["PlanarDiagram", dict[int, int]]:
        mapping: dict[int, int] = {}
        next_label = 1
        relabeled = []
        for crossing in self.crossings:
            new_code = []
            for label in crossing.code:
                if label not in mapping:
                    mapping[label] = next_label
                    next_label += 1
                new_code.append(mapping[label])
            relabeled.append(PDCrossing(tuple(new_code), sign=crossing.sign))
        return (
            PlanarDiagram(
                tuple(relabeled),
                component_count=self.component_count,
                name=self.name,
                convention=self.convention,
            ),
            mapping,
        )

    def switch_crossing(self, index: int) -> "PlanarDiagram":
        crossings = list(self.crossings)
        crossing = crossings[index]
        crossings[index] = PDCrossing(crossing.code, sign=-crossing.sign)
        return PlanarDiagram(
            tuple(crossings),
            component_count=self.component_count,
            name=self.name,
            convention=self.convention,
        )

    def with_crossing_sign(self, index: int, sign: int) -> "PlanarDiagram":
        crossings = list(self.crossings)
        crossing = crossings[index]
        crossings[index] = PDCrossing(crossing.code, sign=sign)
        return PlanarDiagram(
            tuple(crossings),
            component_count=self.component_count,
            name=self.name,
            convention=self.convention,
        )

    def smooth_crossing(self, index: int, *, smoothing: str = "A") -> "PlanarDiagram":
        if smoothing not in {"A", "B"}:
            raise ValueError("smoothing must be 'A' or 'B'")
        crossing = self.crossings[index]
        a, b, c, d = crossing.code
        pairs = [(a, b), (c, d)] if smoothing == "A" else [(a, d), (b, c)]
        remaining = [
            other
            for other_index, other in enumerate(self.crossings)
            if other_index != index
        ]
        return _smooth_remaining_crossings(
            remaining,
            pairs=pairs,
            component_count=self.component_count,
            name=self.name,
            convention=self.convention,
        )

    def oriented_smooth_crossing(
        self,
        index: int,
        *,
        orientation: PDOrientation,
    ) -> "PlanarDiagram":
        smoothed, _ = self.oriented_smooth_crossing_with_orientation(
            index,
            orientation=orientation,
        )
        return smoothed

    def oriented_smooth_crossing_with_orientation(
        self,
        index: int,
        *,
        orientation: PDOrientation,
    ) -> tuple["PlanarDiagram", PDOrientation]:
        issues = orientation.validation_issues(self)
        if issues:
            raise ValueError("; ".join(issues))
        crossing_orientation = orientation.crossings[index]
        original_successor = _orientation_successor_map(orientation.crossings)
        original_cycles = _successor_cycles(original_successor, self.edge_labels)
        extra_free_components = (
            max(0, self.component_count - len(original_cycles))
            if self.component_count is not None
            else 0
        )
        pairs = [
            (crossing_orientation.under_in, crossing_orientation.over_out),
            (crossing_orientation.over_in, crossing_orientation.under_out),
        ]
        remaining_crossings = [
            other
            for other_index, other in enumerate(self.crossings)
            if other_index != index
        ]
        remaining_orientations = [
            other
            for other_index, other in enumerate(orientation.crossings)
            if other_index != index
        ]
        smoothed, label_mapping = _smooth_remaining_crossings_with_mapping(
            remaining_crossings,
            pairs=pairs,
            component_count=self.component_count,
            name=self.name,
            convention=self.convention,
        )

        propagated_crossings = tuple(
            PDCrossingOrientation(
                under_in=label_mapping[old_orientation.under_in],
                under_out=label_mapping[old_orientation.under_out],
                over_in=label_mapping[old_orientation.over_in],
                over_out=label_mapping[old_orientation.over_out],
            )
            for old_orientation in remaining_orientations
        )
        smoothed_successor: dict[int, int] = {
            crossing_orientation.under_in: crossing_orientation.over_out,
            crossing_orientation.over_in: crossing_orientation.under_out,
        }
        for old_orientation in remaining_orientations:
            smoothed_successor[old_orientation.under_in] = old_orientation.under_out
            smoothed_successor[old_orientation.over_in] = old_orientation.over_out
        smoothed_old_cycles = _successor_cycles(
            smoothed_successor,
            sorted(smoothed_successor),
        )
        old_label_components = {
            label: component_index
            for component_index, cycle in enumerate(smoothed_old_cycles)
            for label in cycle
        }
        propagated_component_map: dict[int, int] = {}
        for old_label, new_label in label_mapping.items():
            component = old_label_components[old_label]
            propagated_component_map[new_label] = min(
                component,
                propagated_component_map.get(new_label, component),
            )
        propagated_components = tuple(sorted(propagated_component_map.items()))
        smoothed = PlanarDiagram(
            smoothed.crossings,
            component_count=len(smoothed_old_cycles) + extra_free_components,
            name=smoothed.name,
            convention=smoothed.convention,
        )
        propagated_orientation = PDOrientation(
            propagated_crossings,
            edge_components=propagated_components,
            convention=orientation.convention,
        )
        return smoothed, propagated_orientation

    def edge_component_sets(self) -> list[list[int]]:
        if not self.crossings:
            return []
        parents: dict[int, int] = {}

        def find(label: int) -> int:
            parents.setdefault(label, label)
            if parents[label] != label:
                parents[label] = find(parents[label])
            return parents[label]

        def union(first: int, second: int) -> None:
            first_root = find(first)
            second_root = find(second)
            if first_root != second_root:
                parents[second_root] = first_root

        for crossing in self.crossings:
            first = crossing.code[0]
            for label in crossing.code[1:]:
                union(first, label)

        components: dict[int, list[int]] = {}
        for label in self.edge_labels:
            components.setdefault(find(label), []).append(label)
        return [sorted(labels) for _, labels in sorted(components.items())]

    def is_split(self) -> bool:
        return len(self.edge_component_sets()) > 1


def build_planar_diagram(
    crossings: Iterable[PDCrossing | dict | Iterable[int]],
    *,
    signs: Iterable[int] | None = None,
    component_count: int | None = None,
    name: str | None = None,
) -> PlanarDiagram:
    if signs is None:
        return PlanarDiagram(
            tuple(PDCrossing.from_value(crossing) for crossing in crossings),
            component_count=component_count,
            name=name,
        )

    signed_crossings = [
        PDCrossing(PDCrossing.from_value(crossing).code, sign=int(sign))
        for crossing, sign in zip(crossings, signs)
    ]
    return PlanarDiagram(
        tuple(signed_crossings),
        component_count=component_count,
        name=name,
    )


def mirror_signed_pd(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None = None,
    name: str | None = None,
) -> tuple[PlanarDiagram, PDOrientation]:
    """Mirror a signed PD under iroll's oriented diagram convention.

    In iroll's signed-PD model, the PD edge order and oriented traversal
    metadata describe the planar embedding. Mirroring changes every crossing
    sign but does not relabel the oriented arcs. Skein crossing switches use a
    different local mutation that swaps under/over roles for one crossing.
    """

    effective_orientation = orientation
    if effective_orientation is None:
        effective_orientation = (
            PDOrientation((), convention="signed_pd_mirror_zero_crossing")
            if diagram.crossing_count == 0
            else PDOrientation.from_signed_pd_roles(diagram)
        )
    issues = effective_orientation.validation_issues(diagram)
    if issues:
        raise ValueError("; ".join(issues))

    mirrored_name = name if name is not None else (
        f"mirror-{diagram.name}" if diagram.name else None
    )
    mirrored_diagram = PlanarDiagram(
        tuple(
            PDCrossing(crossing.code, sign=-crossing.sign)
            for crossing in diagram.crossings
        ),
        component_count=diagram.component_count,
        name=mirrored_name,
        convention=diagram.convention,
    )
    mirrored_pd_orientation = PDOrientation(
        effective_orientation.crossings,
        edge_components=effective_orientation.edge_components,
        convention=f"mirror_of_{effective_orientation.convention}",
    )
    mirrored_issues = mirrored_pd_orientation.validation_issues(mirrored_diagram)
    if mirrored_issues:
        raise ValueError("; ".join(mirrored_issues))
    return mirrored_diagram, mirrored_pd_orientation


def disjoint_union(
    diagrams: Iterable[PlanarDiagram],
    *,
    name: str | None = None,
) -> PlanarDiagram:
    crossings: list[PDCrossing] = []
    component_count = 0
    next_label = 1
    for diagram in diagrams:
        relabeled = diagram.relabel_edges()
        mapping = {label: label + next_label - 1 for label in relabeled.edge_labels}
        crossings.extend(
            PDCrossing(
                tuple(mapping[label] for label in crossing.code),
                sign=crossing.sign,
            )
            for crossing in relabeled.crossings
        )
        next_label += len(relabeled.edge_labels)
        if relabeled.component_count is not None:
            component_count += relabeled.component_count
    return PlanarDiagram(
        tuple(crossings),
        component_count=component_count or None,
        name=name,
    )


def kauffman_bracket(
    diagram: PlanarDiagram,
    *,
    max_crossings: int = 12,
) -> dict[int, int] | None:
    """Return the Kauffman bracket as a Laurent polynomial in A.

    Exponents are integer powers of A. The smoothing convention is documented
    in docs/mathematical-definitions.md and is intentionally tied to the
    signed-PD representation, not iroll's older internal PD-style summary.
    """

    if diagram.crossing_count > max_crossings:
        return None
    if diagram.crossing_count == 0:
        return {0: 1}

    total = LaurentPolynomial.constant(0, variable="A")
    delta = LaurentPolynomial.from_dict({2: -1, -2: -1}, variable="A")
    for state in product([0, 1], repeat=diagram.crossing_count):
        parents: dict[int, int] = {}

        def find(label: int) -> int:
            parents.setdefault(label, label)
            if parents[label] != label:
                parents[label] = find(parents[label])
            return parents[label]

        def union(first: int, second: int) -> None:
            first_root = find(first)
            second_root = find(second)
            if first_root != second_root:
                parents[second_root] = first_root

        exponent = 0
        labels: set[int] = set()
        for smoothing, crossing in zip(state, diagram.crossings):
            a, b, c, d = crossing.code
            labels.update(crossing.code)
            if smoothing == 0:
                union(a, b)
                union(c, d)
                exponent += 1
            else:
                union(a, d)
                union(b, c)
                exponent -= 1

        loop_count = len({find(label) for label in labels})
        term = LaurentPolynomial.monomial(1, exponent, variable="A")
        if loop_count > 0:
            term = term * (delta ** (loop_count - 1))
        total = _laurent_add(total, term)
    return total.to_dict()


def jones_polynomial_from_pd(
    diagram: PlanarDiagram,
    *,
    max_crossings: int = 12,
) -> str | None:
    """Return a Jones polynomial in t for a small signed planar diagram."""

    bracket = kauffman_bracket(diagram, max_crossings=max_crossings)
    if bracket is None:
        return None
    normalized = LaurentPolynomial.from_dict(bracket, variable="A").shift(
        -3 * diagram.writhe
    ).scale(-1 if (-3 * diagram.writhe) % 2 else 1)
    t_terms: dict[int, int] = {}
    for a_exponent, coefficient in normalized.terms:
        if a_exponent % 4 != 0:
            return None
        t_exponent = -a_exponent // 4
        t_terms[t_exponent] = t_terms.get(t_exponent, 0) + coefficient
    return format_laurent(t_terms, variable="t", order="ascending")


def polynomial_result_from_pd(
    diagram: PlanarDiagram,
    *,
    max_crossings: int = 12,
) -> dict:
    jones = jones_polynomial_from_pd(diagram, max_crossings=max_crossings)
    bracket = kauffman_bracket(diagram, max_crossings=max_crossings)
    return {
        "method": "kauffman_bracket_state_sum",
        "max_crossings": max_crossings,
        "crossing_count": diagram.crossing_count,
        "writhe": diagram.writhe,
        "kauffman_bracket_A": (
            format_laurent(bracket, variable="A", order="ascending")
            if bracket is not None
            else None
        ),
        "jones_polynomial": jones,
        "skipped": bracket is None or jones is None,
        "notes": [] if jones is not None else [
            "Jones polynomial skipped or convention produced non-integral t exponents",
        ],
    }


def format_laurent(
    terms: dict[int, int] | None,
    *,
    variable: str,
    order: Literal["ascending", "descending"] = "ascending",
) -> str | None:
    if terms is None:
        return None
    return format_laurent_dict(terms, variable=variable, order=order)


def _smooth_remaining_crossings(
    crossings: list[PDCrossing],
    *,
    pairs: list[tuple[int, int]],
    component_count: int | None,
    name: str | None,
    convention: str,
) -> PlanarDiagram:
    smoothed, _ = _smooth_remaining_crossings_with_mapping(
        crossings,
        pairs=pairs,
        component_count=component_count,
        name=name,
        convention=convention,
    )
    return smoothed


def _smooth_remaining_crossings_with_mapping(
    crossings: list[PDCrossing],
    *,
    pairs: list[tuple[int, int]],
    component_count: int | None,
    name: str | None,
    convention: str,
) -> tuple[PlanarDiagram, dict[int, int]]:
    parents: dict[int, int] = {}

    def find(label: int) -> int:
        parents.setdefault(label, label)
        if parents[label] != label:
            parents[label] = find(parents[label])
        return parents[label]

    def union(first: int, second: int) -> None:
        first_root = find(first)
        second_root = find(second)
        if first_root != second_root:
            parents[second_root] = first_root

    for first, second in pairs:
        union(first, second)

    smoothed = []
    for crossing in crossings:
        smoothed.append(
            PDCrossing(
                tuple(find(label) for label in crossing.code),
                sign=crossing.sign,
            )
        )
    raw_diagram = PlanarDiagram(
        tuple(smoothed),
        component_count=component_count,
        name=name,
        convention=convention,
    )
    relabeled, root_mapping = raw_diagram.relabel_edges_with_mapping()
    old_labels = {
        label
        for crossing in crossings
        for label in crossing.code
    } | {label for pair in pairs for label in pair}
    old_to_new = {
        label: root_mapping[root]
        for label in old_labels
        if (root := find(label)) in root_mapping
    }
    return relabeled, old_to_new


def _flow_pruned_local_role_assignment_summary(
    orientation_cls: type[PDOrientation],
    diagram: PlanarDiagram,
    *,
    role_orders: tuple[tuple[int, int, int, int], ...],
    assignment_count: int,
    max_samples: int,
    max_flow_assignments: int,
    include_component_mismatches: bool,
) -> dict:
    """Search local role assignments with flow-count pruning.

    The full local search is `24^crossing_count`. This diagnostic path avoids
    materializing combinations that cannot make every edge label appear once
    incoming and once outgoing.
    """

    flow_diagram = PlanarDiagram(
        diagram.crossings,
        component_count=None,
        name=diagram.name,
        convention=diagram.convention,
    )
    labels = diagram.edge_labels
    remaining_after: list[Counter[int]] = []
    for index in range(diagram.crossing_count + 1):
        remaining = Counter()
        for crossing in diagram.crossings[index:]:
            remaining.update(crossing.code)
        remaining_after.append(remaining)

    incoming_counts = {label: 0 for label in labels}
    outgoing_counts = {label: 0 for label in labels}
    chosen_orders: list[tuple[int, int, int, int]] = []
    chosen_crossings: list[PDCrossingOrientation] = []
    candidate_count = 0
    flow_assignment_count = 0
    samples: list[dict] = []
    truncated = False

    def has_possible_flow(next_index: int) -> bool:
        remaining = remaining_after[next_index]
        for label in labels:
            if incoming_counts[label] > 1 or outgoing_counts[label] > 1:
                return False
            if incoming_counts[label] + remaining[label] < 1:
                return False
            if outgoing_counts[label] + remaining[label] < 1:
                return False
        return True

    def record_assignment() -> None:
        nonlocal candidate_count, flow_assignment_count, truncated
        if truncated:
            return
        if any(
            incoming_counts[label] != 1 or outgoing_counts[label] != 1
            for label in labels
        ):
            return
        flow_assignment_count += 1
        if flow_assignment_count > max_flow_assignments:
            truncated = True
            return

        raw_orientation = orientation_cls(
            tuple(chosen_crossings),
            convention="signed_pd_local_role_assignment_v1",
        )
        try:
            traversals = raw_orientation.oriented_component_traversals(flow_diagram)
        except ValueError:
            return
        component_count_matches = (
            diagram.component_count is None
            or len(traversals) == diagram.component_count
        )
        if not component_count_matches and not include_component_mismatches:
            return

        edge_components = tuple(
            sorted(
                (int(label), int(component_index))
                for component_index, traversal in enumerate(traversals)
                for label in traversal["edges"]
            )
        )
        orientation = orientation_cls(
            raw_orientation.crossings,
            edge_components=edge_components,
            convention="signed_pd_local_role_assignment_v1",
        )
        issues = orientation.validation_issues(diagram)
        strict = not issues
        if not strict and not include_component_mismatches:
            return

        candidate_count += 1
        if len(samples) < max_samples:
            notes = list(issues)
            if not component_count_matches:
                notes.append(
                    "local role assignment component count does not match diagram.component_count"
                )
            samples.append(
                {
                    "role_orders": [list(order) for order in chosen_orders],
                    "component_count": len(traversals),
                    "component_count_matches": component_count_matches,
                    "strict": strict,
                    "traversals": traversals,
                    "notes": notes,
                }
            )

    def search(crossing_index: int) -> None:
        if truncated:
            return
        if crossing_index == diagram.crossing_count:
            record_assignment()
            return
        crossing = diagram.crossings[crossing_index]
        for role_order in role_orders:
            orientation = _crossing_orientation_from_role_order(
                crossing,
                role_order=role_order,
            )
            incoming_counts[orientation.under_in] += 1
            incoming_counts[orientation.over_in] += 1
            outgoing_counts[orientation.under_out] += 1
            outgoing_counts[orientation.over_out] += 1
            if has_possible_flow(crossing_index + 1):
                chosen_orders.append(role_order)
                chosen_crossings.append(orientation)
                search(crossing_index + 1)
                chosen_crossings.pop()
                chosen_orders.pop()
            incoming_counts[orientation.under_in] -= 1
            incoming_counts[orientation.over_in] -= 1
            outgoing_counts[orientation.under_out] -= 1
            outgoing_counts[orientation.over_out] -= 1

    search(0)
    return {
        "method": "signed_pd_local_role_assignment_summary",
        "search_strategy": "flow_pruned_bounded",
        "assignment_count": assignment_count,
        "max_flow_assignments": max_flow_assignments,
        "flow_assignment_count": flow_assignment_count,
        "candidate_count": candidate_count,
        "sample_count": len(samples),
        "samples": samples,
        "truncated": truncated or candidate_count > len(samples),
        "skipped": False,
        "notes": [
            "per-crossing role assignments are diagnostics and are not selected automatically",
            "search used flow-count pruning because assignment_count exceeds max_assignments",
        ],
    }


def _orientation_successor_map(
    crossings: Iterable[PDCrossingOrientation],
) -> dict[int, int]:
    successor: dict[int, int] = {}
    for orientation in crossings:
        successor[orientation.under_in] = orientation.under_out
        successor[orientation.over_in] = orientation.over_out
    return successor


def _successor_cycles(
    successor: dict[int, int],
    labels: list[int],
) -> list[list[int]]:
    cycles: list[list[int]] = []
    seen: set[int] = set()
    for start in labels:
        if start in seen:
            continue
        current = start
        cycle = []
        while current not in seen:
            seen.add(current)
            cycle.append(current)
            current = successor[current]
        if current != start:
            raise ValueError("orientation successor map does not form closed component cycles")
        cycles.append(cycle)
    return cycles


def _validate_role_order(role_order: Iterable[int]) -> tuple[int, int, int, int]:
    order = tuple(int(position) for position in role_order)
    if len(order) != 4 or set(order) != {0, 1, 2, 3}:
        raise ValueError("signed-PD role_order must be a permutation of (0, 1, 2, 3)")
    return order  # type: ignore[return-value]


def _role_mapping_for_order(role_order: Iterable[int]) -> tuple[dict, ...]:
    order = _validate_role_order(role_order)
    return tuple(
        {"role": role, "position": position}
        for role, position in zip(SIGNED_PD_POSITION_ROLES, order)
    )


def _role_order_convention(role_order: Iterable[int]) -> str:
    order = _validate_role_order(role_order)
    return (
        "signed_pd_position_roles_v1"
        if order == (0, 1, 2, 3)
        else "signed_pd_role_permutation_v1"
    )


def _role_orders_convention(
    role_orders: Iterable[tuple[int, int, int, int]],
) -> str:
    orders = tuple(role_orders)
    if not orders or all(order == (0, 1, 2, 3) for order in orders):
        return "signed_pd_position_roles_v1"
    if len(set(orders)) == 1:
        return "signed_pd_role_permutation_v1"
    return "signed_pd_per_crossing_role_orders_v1"


def _crossing_orientation_from_role_order(
    crossing: PDCrossing,
    *,
    role_order: tuple[int, int, int, int],
) -> PDCrossingOrientation:
    under_in, over_in, under_out, over_out = (
        crossing.code[position]
        for position in role_order
    )
    return PDCrossingOrientation(
        under_in=under_in,
        under_out=under_out,
        over_in=over_in,
        over_out=over_out,
    )


def _infer_oriented_edge_components(
    diagram: PlanarDiagram,
    *,
    role_order: tuple[int, int, int, int] = (0, 1, 2, 3),
) -> tuple[tuple[int, int], ...]:
    role_order = _validate_role_order(role_order)
    crossings = tuple(
        _crossing_orientation_from_role_order(crossing, role_order=role_order)
        for crossing in diagram.crossings
    )
    return _infer_oriented_edge_components_from_orientations(diagram, crossings)


def _infer_oriented_edge_components_from_orientations(
    diagram: PlanarDiagram,
    orientations: Iterable[PDCrossingOrientation],
) -> tuple[tuple[int, int], ...]:
    labels = diagram.edge_labels
    if not labels:
        return ()
    parents = {label: label for label in labels}

    def find(label: int) -> int:
        if parents[label] != label:
            parents[label] = find(parents[label])
        return parents[label]

    def union(first: int, second: int) -> None:
        first_root = find(first)
        second_root = find(second)
        if first_root != second_root:
            parents[second_root] = first_root

    for orientation in orientations:
        union(orientation.under_in, orientation.under_out)
        union(orientation.over_in, orientation.over_out)

    roots = sorted({find(label) for label in labels})
    component_for_root = {root: index for index, root in enumerate(roots)}
    edge_components = tuple(
        (label, component_for_root[find(label)])
        for label in labels
    )
    if diagram.component_count is not None and len(roots) != diagram.component_count:
        raise ValueError(
            "inferred signed-PD component count does not match diagram.component_count; "
            f"inferred {len(roots)}, expected {diagram.component_count}"
        )
    return edge_components


def _laurent_add(left: LaurentPolynomial, right: LaurentPolynomial) -> LaurentPolynomial:
    return left + right
