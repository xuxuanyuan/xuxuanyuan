"""Sparse Laurent polynomial helpers for topology invariants."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable, Mapping


@dataclass(frozen=True)
class LaurentPolynomial:
    terms: tuple[tuple[int, int], ...] = ()
    variable: str = "t"

    def __post_init__(self) -> None:
        object.__setattr__(self, "terms", _normalize_univariate(self.terms))

    @classmethod
    def constant(cls, value: int, *, variable: str = "t") -> "LaurentPolynomial":
        return cls(((0, int(value)),), variable=variable)

    @classmethod
    def monomial(
        cls,
        coefficient: int,
        exponent: int,
        *,
        variable: str = "t",
    ) -> "LaurentPolynomial":
        return cls(((int(exponent), int(coefficient)),), variable=variable)

    @classmethod
    def from_dict(
        cls,
        terms: Mapping[int, int],
        *,
        variable: str = "t",
    ) -> "LaurentPolynomial":
        return cls(tuple((int(exp), int(coeff)) for exp, coeff in terms.items()), variable=variable)

    @property
    def is_zero(self) -> bool:
        return not self.terms

    def to_dict(self) -> dict[int, int]:
        return dict(self.terms)

    def __add__(self, other: "LaurentPolynomial") -> "LaurentPolynomial":
        self._check_variable(other)
        result = self.to_dict()
        for exponent, coefficient in other.terms:
            result[exponent] = result.get(exponent, 0) + coefficient
        return LaurentPolynomial.from_dict(result, variable=self.variable)

    def __sub__(self, other: "LaurentPolynomial") -> "LaurentPolynomial":
        return self + (-other)

    def __neg__(self) -> "LaurentPolynomial":
        return LaurentPolynomial(
            tuple((exponent, -coefficient) for exponent, coefficient in self.terms),
            variable=self.variable,
        )

    def __mul__(self, other: "LaurentPolynomial") -> "LaurentPolynomial":
        self._check_variable(other)
        result: dict[int, int] = {}
        for left_exp, left_coeff in self.terms:
            for right_exp, right_coeff in other.terms:
                exponent = left_exp + right_exp
                result[exponent] = result.get(exponent, 0) + left_coeff * right_coeff
        return LaurentPolynomial.from_dict(result, variable=self.variable)

    def __pow__(self, exponent: int) -> "LaurentPolynomial":
        if exponent < 0:
            if len(self.terms) != 1:
                raise ValueError("negative powers are supported only for monomials")
            term_exponent, coefficient = self.terms[0]
            if coefficient not in {-1, 1}:
                raise ValueError("negative powers require unit monomial coefficient")
            sign = coefficient if exponent % 2 else 1
            return LaurentPolynomial.monomial(
                sign,
                term_exponent * exponent,
                variable=self.variable,
            )

        result = LaurentPolynomial.constant(1, variable=self.variable)
        base = self
        power = exponent
        while power:
            if power & 1:
                result = result * base
            base = base * base
            power >>= 1
        return result

    def scale(self, factor: int) -> "LaurentPolynomial":
        return LaurentPolynomial(
            tuple((exponent, coefficient * factor) for exponent, coefficient in self.terms),
            variable=self.variable,
        )

    def shift(self, exponent: int) -> "LaurentPolynomial":
        return LaurentPolynomial(
            tuple((old_exp + exponent, coefficient) for old_exp, coefficient in self.terms),
            variable=self.variable,
        )

    def normalize_unit(self) -> "LaurentPolynomial":
        normalized, _record = self.normalize_unit_with_record()
        return normalized

    def normalize_unit_with_record(self) -> tuple["LaurentPolynomial", dict]:
        if self.is_zero:
            return self, {
                "method": "deterministic_laurent_unit_normalization",
                "variable": self.variable,
                "is_zero": True,
                "unit_sign": 1,
                "unit_exponent": 0,
                "minimum_exponent": 0,
                "leading_coefficient_before_sign": 0,
            }
        min_exp = min(exponent for exponent, _ in self.terms)
        unit_exponent = -min_exp
        shifted = self.shift(unit_exponent)
        leading = shifted.terms[0][1]
        unit_sign = -1 if leading < 0 else 1
        normalized = shifted.scale(unit_sign)
        return normalized, {
            "method": "deterministic_laurent_unit_normalization",
            "variable": self.variable,
            "is_zero": False,
            "unit_sign": unit_sign,
            "unit_exponent": unit_exponent,
            "minimum_exponent": min_exp,
            "leading_coefficient_before_sign": leading,
        }

    def format(self, *, order: str = "ascending") -> str:
        return format_laurent_dict(self.to_dict(), variable=self.variable, order=order)

    def _check_variable(self, other: "LaurentPolynomial") -> None:
        if self.variable != other.variable:
            raise ValueError("Laurent variables must match")


@dataclass(frozen=True)
class MultivariateLaurentPolynomial:
    terms: tuple[tuple[tuple[int, ...], int], ...] = ()
    variables: tuple[str, ...] = ("t",)

    def __post_init__(self) -> None:
        normalized = _normalize_multivariate(self.terms, variable_count=len(self.variables))
        object.__setattr__(self, "terms", normalized)

    @classmethod
    def constant(
        cls,
        value: int,
        *,
        variables: Iterable[str] = ("t",),
    ) -> "MultivariateLaurentPolynomial":
        variables_tuple = tuple(variables)
        return cls(((tuple(0 for _ in variables_tuple), int(value)),), variables=variables_tuple)

    @classmethod
    def monomial(
        cls,
        coefficient: int,
        exponents: Iterable[int],
        *,
        variables: Iterable[str] = ("t",),
    ) -> "MultivariateLaurentPolynomial":
        return cls(((tuple(int(exp) for exp in exponents), int(coefficient)),), variables=tuple(variables))

    @classmethod
    def from_dict(
        cls,
        terms: Mapping[tuple[int, ...], int],
        *,
        variables: Iterable[str] = ("t",),
    ) -> "MultivariateLaurentPolynomial":
        return cls(
            tuple((tuple(int(exp) for exp in exponents), int(coeff)) for exponents, coeff in terms.items()),
            variables=tuple(variables),
        )

    @property
    def is_zero(self) -> bool:
        return not self.terms

    def to_dict(self) -> dict[tuple[int, ...], int]:
        return dict(self.terms)

    def __add__(self, other: "MultivariateLaurentPolynomial") -> "MultivariateLaurentPolynomial":
        self._check_variables(other)
        result = self.to_dict()
        for exponents, coefficient in other.terms:
            result[exponents] = result.get(exponents, 0) + coefficient
        return MultivariateLaurentPolynomial.from_dict(result, variables=self.variables)

    def __sub__(self, other: "MultivariateLaurentPolynomial") -> "MultivariateLaurentPolynomial":
        return self + (-other)

    def __neg__(self) -> "MultivariateLaurentPolynomial":
        return MultivariateLaurentPolynomial(
            tuple((exponents, -coefficient) for exponents, coefficient in self.terms),
            variables=self.variables,
        )

    def __mul__(self, other: "MultivariateLaurentPolynomial") -> "MultivariateLaurentPolynomial":
        self._check_variables(other)
        result: dict[tuple[int, ...], int] = {}
        for left_exp, left_coeff in self.terms:
            for right_exp, right_coeff in other.terms:
                exponents = tuple(a + b for a, b in zip(left_exp, right_exp))
                result[exponents] = result.get(exponents, 0) + left_coeff * right_coeff
        return MultivariateLaurentPolynomial.from_dict(result, variables=self.variables)

    def scale(self, factor: int) -> "MultivariateLaurentPolynomial":
        return MultivariateLaurentPolynomial(
            tuple((exponents, coefficient * factor) for exponents, coefficient in self.terms),
            variables=self.variables,
        )

    def shift(self, exponents: Iterable[int]) -> "MultivariateLaurentPolynomial":
        shift_tuple = tuple(int(exp) for exp in exponents)
        if len(shift_tuple) != len(self.variables):
            raise ValueError("monomial shift dimension must match variables")
        return MultivariateLaurentPolynomial(
            tuple(
                (
                    tuple(old + shift for old, shift in zip(old_exponents, shift_tuple)),
                    coefficient,
                )
                for old_exponents, coefficient in self.terms
            ),
            variables=self.variables,
        )

    def map_exponents(
        self,
        mapper: Callable[[tuple[int, ...]], tuple[int, ...]],
    ) -> "MultivariateLaurentPolynomial":
        return MultivariateLaurentPolynomial(
            tuple((tuple(mapper(exponents)), coefficient) for exponents, coefficient in self.terms),
            variables=self.variables,
        )

    def normalize_unit(self) -> "MultivariateLaurentPolynomial":
        normalized, _record = self.normalize_unit_with_record()
        return normalized

    def normalize_unit_with_record(self) -> tuple["MultivariateLaurentPolynomial", dict]:
        if self.is_zero:
            return self, {
                "method": "deterministic_laurent_unit_normalization",
                "variables": list(self.variables),
                "is_zero": True,
                "unit_sign": 1,
                "unit_exponents": [0 for _ in self.variables],
                "minimum_exponents": [0 for _ in self.variables],
                "leading_coefficient_before_sign": 0,
            }
        min_exponents = tuple(
            min(exponents[index] for exponents, _ in self.terms)
            for index in range(len(self.variables))
        )
        unit_exponents = tuple(-exp for exp in min_exponents)
        shifted = self.shift(unit_exponents)
        leading_coeff = shifted.terms[0][1]
        unit_sign = -1 if leading_coeff < 0 else 1
        normalized = shifted.scale(unit_sign)
        return normalized, {
            "method": "deterministic_laurent_unit_normalization",
            "variables": list(self.variables),
            "is_zero": False,
            "unit_sign": unit_sign,
            "unit_exponents": list(unit_exponents),
            "minimum_exponents": list(min_exponents),
            "leading_coefficient_before_sign": leading_coeff,
        }

    def format(self, *, order: str = "lex") -> str:
        return format_multivariate_laurent_dict(
            self.to_dict(),
            variables=self.variables,
            order=order,
        )

    def _check_variables(self, other: "MultivariateLaurentPolynomial") -> None:
        if self.variables != other.variables:
            raise ValueError("multivariate Laurent variables must match")


def format_laurent_dict(
    terms: Mapping[int, int],
    *,
    variable: str,
    order: str = "ascending",
) -> str:
    cleaned = {int(exp): int(coeff) for exp, coeff in terms.items() if coeff}
    if not cleaned:
        return "0"
    exponents = sorted(cleaned, reverse=order == "descending")
    parts = []
    for exponent in exponents:
        parts.append(_format_term(cleaned[exponent], _format_power(variable, exponent)))
    return _join_terms(parts)


def format_multivariate_laurent_dict(
    terms: Mapping[tuple[int, ...], int],
    *,
    variables: Iterable[str],
    order: str = "lex",
) -> str:
    variables_tuple = tuple(variables)
    cleaned = {
        tuple(int(exp) for exp in exponents): int(coeff)
        for exponents, coeff in terms.items()
        if coeff
    }
    if not cleaned:
        return "0"
    exponents_list = sorted(cleaned, reverse=order == "reverse_lex")
    parts = []
    for exponents in exponents_list:
        power = _format_multivariate_power(variables_tuple, exponents)
        parts.append(_format_term(cleaned[exponents], power))
    return _join_terms(parts)


def parse_multivariate_laurent_polynomial(
    text: str,
    *,
    variables: Iterable[str],
) -> MultivariateLaurentPolynomial:
    variables_tuple = tuple(variables)
    compact = "".join(text.split())
    if compact == "0":
        return MultivariateLaurentPolynomial.constant(0, variables=variables_tuple)
    if not compact:
        raise ValueError("polynomial text must not be empty")

    terms: dict[tuple[int, ...], int] = {}
    for token in _split_laurent_terms(compact):
        coefficient, exponents = _parse_multivariate_laurent_term(
            token,
            variables=variables_tuple,
        )
        terms[exponents] = terms.get(exponents, 0) + coefficient
    return MultivariateLaurentPolynomial.from_dict(terms, variables=variables_tuple)


def _normalize_univariate(terms: Iterable[tuple[int, int]]) -> tuple[tuple[int, int], ...]:
    combined: dict[int, int] = {}
    for exponent, coefficient in terms:
        combined[int(exponent)] = combined.get(int(exponent), 0) + int(coefficient)
    return tuple(sorted((exp, coeff) for exp, coeff in combined.items() if coeff))


def _normalize_multivariate(
    terms: Iterable[tuple[tuple[int, ...], int]],
    *,
    variable_count: int,
) -> tuple[tuple[tuple[int, ...], int], ...]:
    combined: dict[tuple[int, ...], int] = {}
    for exponents, coefficient in terms:
        exponent_tuple = tuple(int(exp) for exp in exponents)
        if len(exponent_tuple) != variable_count:
            raise ValueError("term exponent dimension must match variables")
        combined[exponent_tuple] = combined.get(exponent_tuple, 0) + int(coefficient)
    return tuple(sorted((exp, coeff) for exp, coeff in combined.items() if coeff))


def _format_power(variable: str, exponent: int) -> str:
    if exponent == 0:
        return ""
    if exponent == 1:
        return variable
    return f"{variable}^{exponent}"


def _format_multivariate_power(variables: tuple[str, ...], exponents: tuple[int, ...]) -> str:
    parts = [
        _format_power(variable, exponent)
        for variable, exponent in zip(variables, exponents)
        if exponent
    ]
    return "*".join(parts)


def _format_term(coefficient: int, power: str) -> tuple[str, str]:
    sign = "-" if coefficient < 0 else "+"
    magnitude = abs(coefficient)
    if not power:
        body = str(magnitude)
    elif magnitude == 1:
        body = power
    else:
        body = f"{magnitude}*{power}" if "*" in power else f"{magnitude}{power}"
    return sign, body


def _join_terms(parts: list[tuple[str, str]]) -> str:
    first_sign, first_body = parts[0]
    text = first_body if first_sign == "+" else f"-{first_body}"
    for sign, body in parts[1:]:
        text += f" {sign} {body}"
    return text


def _split_laurent_terms(text: str) -> list[str]:
    terms: list[str] = []
    start = 0
    for index, char in enumerate(text):
        if index == 0:
            continue
        if char in {"+", "-"} and text[index - 1] != "^":
            terms.append(text[start:index])
            start = index
    terms.append(text[start:])
    if any(term in {"", "+", "-"} for term in terms):
        raise ValueError(f"invalid Laurent polynomial term in {text!r}")
    return terms


def _parse_multivariate_laurent_term(
    token: str,
    *,
    variables: tuple[str, ...],
) -> tuple[int, tuple[int, ...]]:
    sign = 1
    body = token
    if body[0] == "+":
        body = body[1:]
    elif body[0] == "-":
        sign = -1
        body = body[1:]
    if not body:
        raise ValueError(f"invalid Laurent polynomial term {token!r}")

    coefficient = sign
    exponents = [0 for _ in variables]
    for factor in body.split("*"):
        if not factor:
            raise ValueError(f"invalid Laurent polynomial factor in {token!r}")
        prefix_length = 0
        while prefix_length < len(factor) and factor[prefix_length].isdigit():
            prefix_length += 1
        numeric_prefix = factor[:prefix_length]
        remainder = factor[prefix_length:]
        if numeric_prefix and not remainder:
            coefficient *= int(numeric_prefix)
            continue
        if numeric_prefix:
            coefficient *= int(numeric_prefix)
            factor = remainder
        variable, exponent = _parse_power_factor(factor, variables=variables)
        exponents[variables.index(variable)] += exponent
    return coefficient, tuple(exponents)


def _parse_power_factor(
    factor: str,
    *,
    variables: tuple[str, ...],
) -> tuple[str, int]:
    for variable in sorted(variables, key=len, reverse=True):
        if factor == variable:
            return variable, 1
        prefix = f"{variable}^"
        if factor.startswith(prefix):
            exponent_text = factor[len(prefix) :]
            if not exponent_text:
                break
            return variable, int(exponent_text)
    raise ValueError(f"unknown Laurent polynomial factor {factor!r}")
