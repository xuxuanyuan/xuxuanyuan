"""Projection of 3D points to a 2D diagram plane."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import ArrayLike

from iroll.core.types import FloatArray, as_points3d, normalize_vectors

DEFAULT_PROJECTION_DIRECTIONS = [
    [0.3, 0.5, 1.0],
    [1.0, 0.0, 1.0],
    [1.0, -0.25, 0.75],
    [-0.5, 1.0, 0.75],
    [0.75, 1.0, -0.5],
    [1.0, 1.0, 1.0],
    [0.0, 0.0, 1.0],
    [0.0, 1.0, 0.0],
    [1.0, 0.0, 0.0],
]


@dataclass(frozen=True)
class ProjectionResult:
    points2d: FloatArray
    depth: FloatArray
    direction: FloatArray
    basis_u: FloatArray
    basis_v: FloatArray

    def to_dict(self) -> dict[str, list[float]]:
        return {
            "direction": self.direction.tolist(),
            "basis_u": self.basis_u.tolist(),
            "basis_v": self.basis_v.tolist(),
        }


def project_points(points: ArrayLike, direction: ArrayLike | None = None) -> ProjectionResult:
    points = as_points3d(points)
    direction_array = _choose_direction(points) if direction is None else _as_direction(direction)
    basis_u, basis_v = _orthonormal_basis(direction_array)
    points2d = np.column_stack([points @ basis_u, points @ basis_v])
    depth = points @ direction_array
    return ProjectionResult(
        points2d=np.ascontiguousarray(points2d),
        depth=np.ascontiguousarray(depth),
        direction=direction_array,
        basis_u=basis_u,
        basis_v=basis_v,
    )


def choose_direction_for_components(
    component_points: list[FloatArray],
    direction: ArrayLike | None = None,
) -> FloatArray:
    if direction is not None:
        return _as_direction(direction)
    return _choose_direction(np.vstack(component_points))


def _as_direction(direction: ArrayLike) -> FloatArray:
    array = np.asarray(direction, dtype=np.float64)
    if array.shape != (3,):
        raise ValueError("projection direction must have shape (3,)")
    normalized = normalize_vectors(array)
    if np.linalg.norm(normalized) <= 0.0:
        raise ValueError("projection direction cannot be zero")
    return np.ascontiguousarray(normalized)


def _choose_direction(points: FloatArray) -> FloatArray:
    candidates = np.asarray(DEFAULT_PROJECTION_DIRECTIONS, dtype=np.float64)
    best = _as_direction(candidates[0])
    best_score = -1.0
    for candidate in candidates:
        direction = _as_direction(candidate)
        basis_u, basis_v = _orthonormal_basis(direction)
        projected = np.column_stack([points @ basis_u, points @ basis_v])
        extent = projected.max(axis=0) - projected.min(axis=0)
        score = float(extent[0] * extent[1])
        if score > best_score:
            best = direction
            best_score = score
    return best


def _orthonormal_basis(direction: FloatArray) -> tuple[FloatArray, FloatArray]:
    axis = np.eye(3)[int(np.argmin(np.abs(direction)))]
    basis_u = normalize_vectors(np.cross(axis, direction))
    basis_v = normalize_vectors(np.cross(direction, basis_u))
    return np.ascontiguousarray(basis_u), np.ascontiguousarray(basis_v)
