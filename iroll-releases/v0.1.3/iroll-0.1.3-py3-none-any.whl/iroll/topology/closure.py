"""Closure strategies for open curves."""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass

import numpy as np

from iroll.core.curve import Polyline3D
from iroll.core.types import FloatArray


@dataclass(frozen=True)
class ClosureSpec:
    method: str = "direct"
    samples: int = 1
    seed: int | None = None
    scale: float = 10.0

    @classmethod
    def from_value(cls, value: dict | str | None) -> "ClosureSpec":
        if value is None:
            return cls()
        if isinstance(value, str):
            return cls(method=value)
        return cls(
            method=value.get("method", "direct"),
            samples=int(value.get("samples", 1)),
            seed=value.get("seed"),
            scale=float(value.get("scale", 10.0)),
        )


def close_curve(
    curve: Polyline3D,
    *,
    method: str = "direct",
    seed: int | None = None,
    scale: float = 10.0,
) -> Polyline3D:
    """Return a closed curve using one closure strategy."""

    return next(iter_closed_curves(curve, method=method, samples=1, seed=seed, scale=scale))


def iter_closed_curves(
    curve: Polyline3D,
    *,
    method: str = "direct",
    samples: int = 1,
    seed: int | None = None,
    scale: float = 10.0,
) -> Iterator[Polyline3D]:
    if samples < 1:
        raise ValueError("samples must be at least 1")
    if scale <= 0.0:
        raise ValueError("scale must be positive")
    if curve.closed:
        for _ in range(samples):
            yield curve
        return

    if method == "direct":
        for _ in range(samples):
            yield _direct_closure(curve)
        return
    if method == "ray":
        for _ in range(samples):
            yield _ray_closure(curve, scale=scale)
        return
    if method == "random_sphere":
        rng = np.random.default_rng(seed)
        for _ in range(samples):
            yield _random_sphere_closure(curve, rng=rng, scale=scale)
        return
    raise ValueError("method must be 'direct', 'ray', or 'random_sphere'")


def _direct_closure(curve: Polyline3D) -> Polyline3D:
    return Polyline3D(
        curve.points,
        closed=True,
        name=_closure_name(curve, "direct"),
        metadata={**curve.metadata, "closure_method": "direct"},
    )


def _ray_closure(curve: Polyline3D, *, scale: float) -> Polyline3D:
    distance = _closure_distance(curve.points, scale=scale)
    start_tangent = _unit(curve.points[1] - curve.points[0])
    end_tangent = _unit(curve.points[-1] - curve.points[-2])
    start_far = curve.points[0] - distance * start_tangent
    end_far = curve.points[-1] + distance * end_tangent
    points = np.vstack([curve.points, end_far, start_far])
    return Polyline3D(
        points,
        closed=True,
        name=_closure_name(curve, "ray"),
        metadata={**curve.metadata, "closure_method": "ray"},
    )


def _random_sphere_closure(
    curve: Polyline3D,
    *,
    rng: np.random.Generator,
    scale: float,
) -> Polyline3D:
    center = curve.points.mean(axis=0)
    radius = _closure_distance(curve.points, scale=scale)
    far_point = center + radius * _random_unit_vector(rng)
    points = np.vstack([curve.points, far_point])
    return Polyline3D(
        points,
        closed=True,
        name=_closure_name(curve, "random_sphere"),
        metadata={**curve.metadata, "closure_method": "random_sphere"},
    )


def _closure_distance(points: FloatArray, *, scale: float) -> float:
    extent = points.max(axis=0) - points.min(axis=0)
    diagonal = float(np.linalg.norm(extent))
    return max(diagonal, 1.0) * scale


def _random_unit_vector(rng: np.random.Generator) -> FloatArray:
    vector = rng.normal(size=3)
    return _unit(vector)


def _unit(vector: FloatArray) -> FloatArray:
    norm = float(np.linalg.norm(vector))
    if norm <= 1e-12:
        return np.array([1.0, 0.0, 0.0], dtype=np.float64)
    return np.asarray(vector, dtype=np.float64) / norm


def _closure_name(curve: Polyline3D, method: str) -> str | None:
    if curve.name is None:
        return None
    return f"{curve.name}:{method}"
