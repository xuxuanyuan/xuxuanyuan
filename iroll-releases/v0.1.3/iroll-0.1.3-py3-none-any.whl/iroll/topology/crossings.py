"""Projected crossing detection."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np
from numpy.typing import ArrayLike

from iroll.core.curve import Polyline3D
from iroll.core.link import Link3D
from iroll.core.types import FloatArray
from iroll.kernels.backend import KernelBackend
from iroll.kernels.intersections import (
    segment_bbox_candidate_pairs_2d,
    segment_intersections_2d,
)
from iroll.topology.projection import choose_direction_for_components, project_points


@dataclass(frozen=True)
class Crossing:
    component_a: int
    segment_a: int
    parameter_a: float
    component_b: int
    segment_b: int
    parameter_b: float
    point2d: FloatArray
    point3d_a: FloatArray
    point3d_b: FloatArray
    over_component: int
    over_segment: int
    sign: int

    def to_dict(self) -> dict[str, int | list[float]]:
        return {
            "component_a": self.component_a,
            "segment_a": self.segment_a,
            "parameter_a": self.parameter_a,
            "component_b": self.component_b,
            "segment_b": self.segment_b,
            "parameter_b": self.parameter_b,
            "point2d": self.point2d.tolist(),
            "point3d_a": self.point3d_a.tolist(),
            "point3d_b": self.point3d_b.tolist(),
            "over_component": self.over_component,
            "over_segment": self.over_segment,
            "sign": self.sign,
        }


def find_curve_crossings(
    curve: Polyline3D,
    *,
    direction: ArrayLike | None = None,
    eps: float = 1e-10,
    backend: KernelBackend = "numpy",
) -> list[Crossing]:
    return find_crossings([curve], direction=direction, eps=eps, backend=backend)


def find_link_crossings(
    link: Link3D,
    *,
    direction: ArrayLike | None = None,
    eps: float = 1e-10,
    backend: KernelBackend = "numpy",
) -> list[Crossing]:
    return find_crossings(link.components, direction=direction, eps=eps, backend=backend)


def find_crossings(
    components: Sequence[Polyline3D],
    *,
    direction: ArrayLike | None = None,
    eps: float = 1e-10,
    backend: KernelBackend = "numpy",
) -> list[Crossing]:
    if backend not in {"auto", "numpy", "rust", "gpu"}:
        raise ValueError("backend must be 'auto', 'numpy', 'rust', or 'gpu'")

    direction_array = choose_direction_for_components(
        [component.points for component in components],
        direction=direction,
    )
    projections = [project_points(component.points, direction_array) for component in components]
    segments = _collect_segments(components, projections)
    if backend in {"gpu", "rust"}:
        candidate_pairs = _candidate_pairs_kernel(
            segments,
            components,
            eps=eps,
            backend=backend,
        )
    else:
        candidate_pairs = list(_candidate_pairs(segments, components, eps=eps))
    if not candidate_pairs:
        return []

    p0 = np.asarray([pair[0]["p0"] for pair in candidate_pairs], dtype=np.float64)
    p1 = np.asarray([pair[0]["p1"] for pair in candidate_pairs], dtype=np.float64)
    q0 = np.asarray([pair[1]["p0"] for pair in candidate_pairs], dtype=np.float64)
    q1 = np.asarray([pair[1]["p1"] for pair in candidate_pairs], dtype=np.float64)
    intersection_backend: KernelBackend = backend if backend in {"gpu", "rust"} else "numpy"
    hit, parameters_a, parameters_b, points2d, denominators = segment_intersections_2d(
        p0,
        p1,
        q0,
        q1,
        backend=intersection_backend,
        eps=eps,
    )

    crossings: list[Crossing] = []
    for pair_index, (segment_a, segment_b) in enumerate(candidate_pairs):
        if not bool(hit[pair_index]):
            continue

        t = float(parameters_a[pair_index])
        u = float(parameters_b[pair_index])
        point2d = np.ascontiguousarray(points2d[pair_index])
        denominator = float(denominators[pair_index])
        depth_a = segment_a["z0"] + t * (segment_a["z1"] - segment_a["z0"])
        depth_b = segment_b["z0"] + u * (segment_b["z1"] - segment_b["z0"])
        if abs(depth_a - depth_b) <= eps:
            continue

        point3d_a = segment_a["q0"] + t * (segment_a["q1"] - segment_a["q0"])
        point3d_b = segment_b["q0"] + u * (segment_b["q1"] - segment_b["q0"])
        if depth_a > depth_b:
            over_component = segment_a["component"]
            over_segment = segment_a["segment"]
            sign = 1 if denominator > 0.0 else -1
        else:
            over_component = segment_b["component"]
            over_segment = segment_b["segment"]
            sign = -1 if denominator > 0.0 else 1

        crossings.append(
            Crossing(
                component_a=segment_a["component"],
                segment_a=segment_a["segment"],
                parameter_a=t,
                component_b=segment_b["component"],
                segment_b=segment_b["segment"],
                parameter_b=u,
                point2d=point2d,
                point3d_a=point3d_a,
                point3d_b=point3d_b,
                over_component=over_component,
                over_segment=over_segment,
                sign=sign,
            )
        )
    return crossings


def _collect_segments(
    components: Sequence[Polyline3D],
    projections: Sequence,
) -> list[dict[str, int | FloatArray | float]]:
    segments = []
    for component_index, (component, projection) in enumerate(zip(components, projections)):
        for segment_index, (start, end) in enumerate(_segment_indices(component)):
            segments.append(
                {
                    "component": component_index,
                    "segment": segment_index,
                    "start": start,
                    "end": end,
                    "p0": projection.points2d[start],
                    "p1": projection.points2d[end],
                    "min_x": float(
                        min(projection.points2d[start][0], projection.points2d[end][0])
                    ),
                    "max_x": float(
                        max(projection.points2d[start][0], projection.points2d[end][0])
                    ),
                    "min_y": float(
                        min(projection.points2d[start][1], projection.points2d[end][1])
                    ),
                    "max_y": float(
                        max(projection.points2d[start][1], projection.points2d[end][1])
                    ),
                    "z0": float(projection.depth[start]),
                    "z1": float(projection.depth[end]),
                    "q0": component.points[start],
                    "q1": component.points[end],
                }
            )
    return segments


def _segment_indices(component: Polyline3D) -> list[tuple[int, int]]:
    count = component.point_count
    segment_count = count if component.closed else count - 1
    return [(index, (index + 1) % count) for index in range(segment_count)]


def _candidate_pairs(
    segments: list[dict[str, int | FloatArray | float]],
    components: Sequence[Polyline3D],
    *,
    eps: float,
):
    active: list[dict[str, int | FloatArray | float]] = []
    for segment in sorted(segments, key=lambda item: float(item["min_x"])):
        min_x = float(segment["min_x"])
        active = [item for item in active if float(item["max_x"]) + eps >= min_x]
        for candidate in active:
            if _skip_pair(candidate, segment, components):
                continue
            if not _bbox_overlaps(candidate, segment, eps=eps):
                continue
            yield candidate, segment
        active.append(segment)


def _candidate_pairs_kernel(
    segments: list[dict[str, int | FloatArray | float]],
    components: Sequence[Polyline3D],
    *,
    eps: float,
    backend: KernelBackend,
) -> list[tuple[dict[str, int | FloatArray | float], dict[str, int | FloatArray | float]]]:
    if len(segments) < 2:
        return []
    order_rank = _segment_order_rank(segments)
    left_indices, right_indices = segment_bbox_candidate_pairs_2d(
        np.asarray([segment["min_x"] for segment in segments], dtype=np.float64),
        np.asarray([segment["max_x"] for segment in segments], dtype=np.float64),
        np.asarray([segment["min_y"] for segment in segments], dtype=np.float64),
        np.asarray([segment["max_y"] for segment in segments], dtype=np.float64),
        np.asarray([segment["component"] for segment in segments], dtype=np.int64),
        np.asarray([segment["segment"] for segment in segments], dtype=np.int64),
        np.asarray([component.segment_count for component in components], dtype=np.int64),
        np.asarray([component.closed for component in components], dtype=bool),
        order_rank,
        backend=backend,
        eps=eps,
    )
    return [
        (segments[int(left)], segments[int(right)])
        for left, right in zip(left_indices, right_indices)
    ]


def _segment_order_rank(
    segments: list[dict[str, int | FloatArray | float]],
) -> np.ndarray:
    rank = np.empty(len(segments), dtype=np.int64)
    for order, (index, _) in enumerate(
        sorted(
            enumerate(segments),
            key=lambda item: float(item[1]["min_x"]),
        )
    ):
        rank[index] = order
    return rank


def _bbox_overlaps(
    segment_a: dict[str, int | FloatArray | float],
    segment_b: dict[str, int | FloatArray | float],
    *,
    eps: float,
) -> bool:
    return not (
        float(segment_a["max_x"]) + eps < float(segment_b["min_x"])
        or float(segment_b["max_x"]) + eps < float(segment_a["min_x"])
        or float(segment_a["max_y"]) + eps < float(segment_b["min_y"])
        or float(segment_b["max_y"]) + eps < float(segment_a["min_y"])
    )


def _skip_pair(
    segment_a: dict[str, int | FloatArray | float],
    segment_b: dict[str, int | FloatArray | float],
    components: Sequence[Polyline3D],
) -> bool:
    component_a = int(segment_a["component"])
    component_b = int(segment_b["component"])
    if component_a != component_b:
        return False

    index_a = int(segment_a["segment"])
    index_b = int(segment_b["segment"])
    if index_a == index_b:
        return True

    component = components[component_a]
    distance = abs(index_a - index_b)
    if distance == 1:
        return True
    return component.closed and distance == component.segment_count - 1


def _segment_intersection(
    p: FloatArray,
    p2: FloatArray,
    q: FloatArray,
    q2: FloatArray,
    *,
    eps: float,
) -> tuple[float, float, FloatArray, float] | None:
    r = p2 - p
    s = q2 - q
    denominator = _cross2d(r, s)
    if abs(denominator) <= eps:
        return None

    delta = q - p
    t = _cross2d(delta, s) / denominator
    u = _cross2d(delta, r) / denominator
    if not (eps < t < 1.0 - eps and eps < u < 1.0 - eps):
        return None

    point = p + t * r
    return float(t), float(u), np.ascontiguousarray(point), float(denominator)


def _cross2d(a: FloatArray, b: FloatArray) -> float:
    return float(a[0] * b[1] - a[1] * b[0])
