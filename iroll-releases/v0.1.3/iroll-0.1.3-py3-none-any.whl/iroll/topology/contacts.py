"""Near-contact detection for 3D curve segments."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np

from iroll.core.curve import Polyline3D
from iroll.core.link import Link3D
from iroll.core.types import FloatArray
from iroll.kernels import segment_bbox_candidate_pairs_3d, segment_segment_distances


@dataclass(frozen=True)
class SegmentContact:
    component_a: int
    segment_a: int
    parameter_a: float
    component_b: int
    segment_b: int
    parameter_b: float
    distance: float
    point3d_a: FloatArray
    point3d_b: FloatArray

    def to_dict(self) -> dict[str, int | float | list[float]]:
        return {
            "component_a": self.component_a,
            "segment_a": self.segment_a,
            "parameter_a": self.parameter_a,
            "component_b": self.component_b,
            "segment_b": self.segment_b,
            "parameter_b": self.parameter_b,
            "distance": self.distance,
            "point3d_a": self.point3d_a.tolist(),
            "point3d_b": self.point3d_b.tolist(),
        }


def find_curve_contacts(
    curve: Polyline3D,
    *,
    threshold: float,
    include_adjacent: bool = False,
    max_contacts: int | None = None,
    backend: str = "auto",
    eps: float = 1e-12,
) -> list[SegmentContact]:
    return find_contacts(
        [curve],
        threshold=threshold,
        include_adjacent=include_adjacent,
        max_contacts=max_contacts,
        backend=backend,
        eps=eps,
    )


def find_link_contacts(
    link: Link3D,
    *,
    threshold: float,
    include_adjacent: bool = False,
    max_contacts: int | None = None,
    backend: str = "auto",
    eps: float = 1e-12,
) -> list[SegmentContact]:
    return find_contacts(
        link.components,
        threshold=threshold,
        include_adjacent=include_adjacent,
        max_contacts=max_contacts,
        backend=backend,
        eps=eps,
    )


def summarize_contacts(contacts: Sequence[SegmentContact], *, threshold: float) -> dict:
    return {
        "threshold": threshold,
        "count": len(contacts),
        "minimum_distance": None if not contacts else contacts[0].distance,
        "contacts": [contact.to_dict() for contact in contacts],
    }


def find_contacts(
    components: Sequence[Polyline3D],
    *,
    threshold: float,
    include_adjacent: bool = False,
    max_contacts: int | None = None,
    backend: str = "auto",
    eps: float = 1e-12,
) -> list[SegmentContact]:
    if threshold < 0.0:
        raise ValueError("threshold must be non-negative")
    if max_contacts is not None and max_contacts < 1:
        raise ValueError("max_contacts must be at least 1")

    segments = _collect_segments(components)
    contacts: list[SegmentContact] = []
    if backend in {"gpu", "rust"}:
        candidate_pairs = _candidate_pairs_kernel(
            segments,
            components,
            threshold=threshold,
            include_adjacent=include_adjacent,
            backend=backend,
        )
    else:
        candidate_pairs = list(_candidate_pairs(
            segments,
            components,
            threshold=threshold,
            include_adjacent=include_adjacent,
        ))
    if not candidate_pairs:
        return []

    distances, parameters_a, parameters_b, points_a, points_b = segment_segment_distances(
        np.asarray([segment_a["p0"] for segment_a, _ in candidate_pairs], dtype=np.float64),
        np.asarray([segment_a["p1"] for segment_a, _ in candidate_pairs], dtype=np.float64),
        np.asarray([segment_b["p0"] for _, segment_b in candidate_pairs], dtype=np.float64),
        np.asarray([segment_b["p1"] for _, segment_b in candidate_pairs], dtype=np.float64),
        backend=backend,
        eps=eps,
    )
    for index, (segment_a, segment_b) in enumerate(candidate_pairs):
        distance = float(distances[index])
        if distance <= threshold + eps:
            parameter_a = float(parameters_a[index])
            parameter_b = float(parameters_b[index])
            point_a = np.asarray(points_a[index], dtype=np.float64)
            point_b = np.asarray(points_b[index], dtype=np.float64)
            contacts.append(
                SegmentContact(
                    component_a=int(segment_a["component"]),
                    segment_a=int(segment_a["segment"]),
                    parameter_a=parameter_a,
                    component_b=int(segment_b["component"]),
                    segment_b=int(segment_b["segment"]),
                    parameter_b=parameter_b,
                    distance=distance,
                    point3d_a=point_a,
                    point3d_b=point_b,
                )
            )

    contacts.sort(key=lambda contact: contact.distance)
    if max_contacts is not None:
        return contacts[:max_contacts]
    return contacts


def _collect_segments(
    components: Sequence[Polyline3D],
) -> list[dict[str, int | FloatArray | float]]:
    segments = []
    for component_index, component in enumerate(components):
        for segment_index, (start, end) in enumerate(_segment_indices(component)):
            p0 = component.points[start]
            p1 = component.points[end]
            minimum = np.minimum(p0, p1)
            maximum = np.maximum(p0, p1)
            segments.append(
                {
                    "component": component_index,
                    "segment": segment_index,
                    "p0": p0,
                    "p1": p1,
                    "min_x": float(minimum[0]),
                    "max_x": float(maximum[0]),
                    "min_y": float(minimum[1]),
                    "max_y": float(maximum[1]),
                    "min_z": float(minimum[2]),
                    "max_z": float(maximum[2]),
                }
            )
    return segments


def _segment_indices(component: Polyline3D) -> list[tuple[int, int]]:
    count = component.point_count
    segment_count = count if component.closed else count - 1
    return [(index, (index + 1) % count) for index in range(segment_count)]


def _candidate_pairs(
    segments: list[dict[str, int | FloatArray | float]],
    components: Sequence[Polyline3D],
    *,
    threshold: float,
    include_adjacent: bool,
):
    active: list[dict[str, int | FloatArray | float]] = []
    for segment in sorted(segments, key=lambda item: float(item["min_x"])):
        min_x = float(segment["min_x"])
        active = [
            item for item in active if float(item["max_x"]) + threshold >= min_x
        ]
        for candidate in active:
            if not include_adjacent and _skip_pair(candidate, segment, components):
                continue
            if not _bbox_overlaps(candidate, segment, threshold=threshold):
                continue
            yield candidate, segment
        active.append(segment)


def _candidate_pairs_kernel(
    segments: list[dict[str, int | FloatArray | float]],
    components: Sequence[Polyline3D],
    *,
    threshold: float,
    include_adjacent: bool,
    backend: str,
) -> list[tuple[dict[str, int | FloatArray | float], dict[str, int | FloatArray | float]]]:
    if len(segments) < 2:
        return []
    order_rank = _segment_order_rank(segments)
    left_indices, right_indices = segment_bbox_candidate_pairs_3d(
        np.asarray([segment["min_x"] for segment in segments], dtype=np.float64),
        np.asarray([segment["max_x"] for segment in segments], dtype=np.float64),
        np.asarray([segment["min_y"] for segment in segments], dtype=np.float64),
        np.asarray([segment["max_y"] for segment in segments], dtype=np.float64),
        np.asarray([segment["min_z"] for segment in segments], dtype=np.float64),
        np.asarray([segment["max_z"] for segment in segments], dtype=np.float64),
        np.asarray([segment["component"] for segment in segments], dtype=np.int64),
        np.asarray([segment["segment"] for segment in segments], dtype=np.int64),
        np.asarray([component.segment_count for component in components], dtype=np.int64),
        np.asarray([component.closed for component in components], dtype=bool),
        order_rank,
        threshold=threshold,
        include_adjacent=include_adjacent,
        backend=backend,
    )
    return [
        (segments[int(left)], segments[int(right)])
        for left, right in zip(left_indices, right_indices)
    ]


def _segment_order_rank(
    segments: list[dict[str, int | FloatArray | float]],
) -> np.ndarray:
    rank = np.empty(len(segments), dtype=np.int64)
    for order, (index, _) in enumerate(
        sorted(
            enumerate(segments),
            key=lambda item: float(item[1]["min_x"]),
        )
    ):
        rank[index] = order
    return rank


def _skip_pair(
    segment_a: dict[str, int | FloatArray | float],
    segment_b: dict[str, int | FloatArray | float],
    components: Sequence[Polyline3D],
) -> bool:
    component_a = int(segment_a["component"])
    component_b = int(segment_b["component"])
    if component_a != component_b:
        return False

    index_a = int(segment_a["segment"])
    index_b = int(segment_b["segment"])
    if index_a == index_b:
        return True

    component = components[component_a]
    distance = abs(index_a - index_b)
    if distance == 1:
        return True
    return component.closed and distance == component.segment_count - 1


def _bbox_overlaps(
    segment_a: dict[str, int | FloatArray | float],
    segment_b: dict[str, int | FloatArray | float],
    *,
    threshold: float,
) -> bool:
    return not (
        float(segment_a["max_x"]) + threshold < float(segment_b["min_x"])
        or float(segment_b["max_x"]) + threshold < float(segment_a["min_x"])
        or float(segment_a["max_y"]) + threshold < float(segment_b["min_y"])
        or float(segment_b["max_y"]) + threshold < float(segment_a["min_y"])
        or float(segment_a["max_z"]) + threshold < float(segment_b["min_z"])
        or float(segment_b["max_z"]) + threshold < float(segment_a["min_z"])
    )
