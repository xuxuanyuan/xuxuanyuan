"""Replay helpers for the full HOMFLY-PT certification artifact.

The final completion pack embeds the parsed report.  This module deliberately
recomputes the finite regression rows and audits every recorded Laurent replay
instead of trusting summary booleans copied into the pack.
"""

from __future__ import annotations

from copy import deepcopy
from hashlib import sha256
from inspect import getsource, signature
from importlib import import_module
import json
import re
from typing import Any, Mapping, Sequence
from urllib.parse import urlencode

from iroll.topology.homfly import (
    homfly_complete_evaluation_from_pd,
    homfly_unlink_polynomial,
)
from iroll.topology.pd import PDOrientation, PlanarDiagram
from iroll.topology.polynomial import parse_multivariate_laurent_polynomial


_PINNED_HOMFLY_SOURCES: dict[str, dict[str, Any]] = {
    "definition": {
        "title": "The HOMFLY-PT Polynomial",
        "revision_id": 1719527,
        "sha256": "80314ccd11edaaaf62ce41bdb16ef836756dcac4688121571623a44e05d4a43b",
        "byte_count": 4316,
        "url_slug": "HOMFLY-definition",
        "required_phrases": (
            "aH\\left(\\overcrossing\\right)-a^{-1}H\\left(\\undercrossing\\right)=zH\\left(\\smoothing\\right)",
            "initial condition <math>H(\\bigcirc)</math>=1",
            "specializes to the Jones polynomial at <math>a=q^{-1}</math>",
        ),
    },
    "4_1": {
        "title": "Data:4_1/HOMFLYPT Polynomial",
        "revision_id": 1719324,
        "sha256": "4947db1fe80cab48b8ae1183802df2e4181646b60a8502c92d12abd3d56b5e8d",
        "byte_count": 31,
        "url_slug": "HOMFLY-4_1",
        "expected_math_source": r"<math>a^2+ a^{-2} -z^2-1</math>",
        "expected_polynomial": "a^-2 - 1 - z^2 + a^2",
    },
    "L5a1": {
        "title": "Data:L5a1/HOMFLYPT Polynomial",
        "revision_id": 64048,
        "sha256": "9d1fe93a45cfdd2ec596760913d25162c194246864bddaef57316210c5519e74",
        "byte_count": 67,
        "url_slug": "HOMFLY-L5a1",
        "expected_math_source": (
            r"<math>-z a^3+z^3 a+2 z a+a z^{-1} -z a^{-1} - a^{-1} z^{-1} </math>"
        ),
        "expected_polynomial": (
            "-a^3*z + a*z^3 + 2a*z + a*z^-1 - a^-1*z - a^-1*z^-1"
        ),
    },
    "L6a4": {
        "title": "Data:L6a4/HOMFLYPT Polynomial",
        "revision_id": 1718118,
        "sha256": "92f541fd98781658d454ea832e43c53b8df04a743a64ca6a43552512214a06ab",
        "byte_count": 81,
        "url_slug": "HOMFLY-L6a4",
        "expected_math_source": (
            r"<math>-a^2 z^2-z^2 a^{-2} +a^2 z^{-2} + a^{-2} z^{-2} +z^4+2 z^2-2 z^{-2} </math>"
        ),
        "expected_polynomial": (
            "-a^2*z^2 - a^-2*z^2 + a^2*z^-2 + a^-2*z^-2 + "
            "z^4 + 2z^2 - 2z^-2"
        ),
    },
}

_CASE_NOTATIONS = ("0_1", "L0a1", "L2a1", "3_1", "4_1", "L5a1", "L6a4")
_REPORT_CHECK_NAMES = (
    "all_pinned_source_sha256s_verified",
    "definition_semantics_verified",
    "all_external_source_values_verified",
    "implementation_contract_verified",
    "all_registered_fixture_regressions_certified",
    "all_transition_termination_measures_certified",
    "all_exact_skein_replays_certified",
    "all_terminal_normalizations_certified",
    "external_table_normalization_certified",
    "resource_cutoffs_absent",
    "frontiers_empty",
)


def full_homfly_pinned_sources() -> dict[str, dict[str, Any]]:
    """Return the immutable source declarations used by producer and audit."""

    records = deepcopy(_PINNED_HOMFLY_SOURCES)
    for record in records.values():
        record["url"] = homfly_pinned_source_url(record)
    return records


def homfly_pinned_source_url(record: Mapping[str, Any]) -> str:
    """Return the distinct raw-revision URL retained by the certificate."""

    return f"https://katlas.org/index.php/{record['url_slug']}?" + urlencode(
        {
            "title": str(record["title"]),
            "oldid": int(record["revision_id"]),
            "action": "raw",
        }
    )


def canonical_json_sha256(value: Any) -> str:
    """Hash a parsed JSON value using the completion-evidence encoding."""

    payload = json.dumps(
        value,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return sha256(payload).hexdigest()


def serialized_certification_report_sha256(value: Any) -> str:
    """Hash the deterministic UTF-8/LF report bytes emitted by the CLI."""

    return sha256(serialized_certification_report_bytes(value)).hexdigest()


def serialized_certification_report_bytes(value: Any) -> bytes:
    """Return deterministic UTF-8/LF bytes for a parsed report."""

    return (
        json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    ).encode("utf-8")


def homfly_implementation_bundle_witness() -> dict[str, Any]:
    """Bind every local module that implements the arbitrary-PD solver path."""

    module_names = (
        "iroll.topology.homfly",
        "iroll.topology.pd",
        "iroll.topology.polynomial",
    )
    modules = []
    for module_name in module_names:
        module = import_module(module_name)
        module_path = getattr(module, "__file__", None)
        if not isinstance(module_path, str) or not module_path.endswith(".py"):
            raise RuntimeError(f"source path unavailable for {module_name}")
        with open(module_path, "rb") as source_file:
            source_bytes = source_file.read()
        source_text = source_bytes.decode("utf-8")
        source_lf_bytes = source_text.replace("\r\n", "\n").replace(
            "\r", "\n"
        ).encode("utf-8")
        modules.append(
            {
                "module": module_name,
                "source_filename": module_path.replace("\\", "/").rsplit("/", 1)[-1],
                "source_encoding": "utf-8",
                "source_newline_normalization": "CRLF_or_CR_to_LF",
                "source_lf_sha256": sha256(source_lf_bytes).hexdigest(),
                "source_lf_byte_count": len(source_lf_bytes),
            }
        )
    return {
        "scope": "complete_homfly_arbitrary_signed_pd_runtime_modules",
        "module_count": len(modules),
        "modules": modules,
        "bundle_sha256": canonical_json_sha256(modules),
    }


def homfly_polynomial_equal(first: Any, second: Any) -> bool:
    if not isinstance(first, str) or not isinstance(second, str):
        return False
    try:
        return parse_multivariate_laurent_polynomial(
            first, variables=("a", "z")
        ) == parse_multivariate_laurent_polynomial(second, variables=("a", "z"))
    except ValueError:
        return False


def homfly_complete_certification_case(notation: str) -> dict[str, Any]:
    """Recompute one deterministic finite regression row."""

    # Imported lazily so pd_fixtures can call the report audit without a module
    # initialization cycle.
    from iroll.topology.pd_fixtures import get_diagram_fixture

    fixture = get_diagram_fixture(notation)
    assignment_audit = None
    if notation in {"L5a1", "L6a4"}:
        assignment_audit = fixture.source_pd_convention_assignment_audit()
        replay = assignment_audit.get("candidate_replay") or {}
        diagram = PlanarDiagram.from_dict(dict(replay["diagram"]))
        orientation = PDOrientation.from_dict(dict(replay["orientation"]))
        expected = str(fixture.source_table_homfly_iroll_normalized or "")
    else:
        diagram = fixture.diagram()
        orientation = fixture.orientation() if diagram.crossing_count else None
        expected = str(fixture.expected_homfly or "")

    evaluation = homfly_complete_evaluation_from_pd(
        diagram,
        orientation=orientation,
    )
    observed = evaluation.get("homfly_polynomial")
    polynomial_matched = homfly_polynomial_equal(observed, expected)
    assignment_certified = (
        assignment_audit is None
        or assignment_audit.get("assignment_unique_under_source_convention") is True
    )
    case_checks = {
        "orientation_valid": (
            orientation is None or not orientation.validation_issues(diagram)
        ),
        "source_assignment_certified_when_required": assignment_certified,
        "complete_evaluation_certified_for_input": (
            evaluation.get("certified_for_input") is True
        ),
        "resource_cutoffs_not_used": (
            evaluation.get("resource_cutoffs_used") is False
        ),
        "frontier_empty": _strict_int(evaluation.get("frontier_count")) == 0,
        "not_truncated": evaluation.get("truncated") is False,
        "termination_measure_certified": (
            evaluation.get("termination_measure_certified") is True
        ),
        "skein_replay_certified": (
            evaluation.get("skein_replay_certified") is True
        ),
        "terminal_normalization_certified": (
            evaluation.get("terminal_normalization_certified") is True
        ),
        "expected_polynomial_matched": polynomial_matched,
    }
    failed_checks = [name for name, passed in case_checks.items() if not passed]
    return {
        "notation": notation,
        "crossing_count": diagram.crossing_count,
        "component_count": diagram.component_count,
        "expected_homfly": expected,
        "observed_homfly": observed,
        "polynomial_matched": polynomial_matched,
        "case_certified": not failed_checks,
        "case_check_count": len(case_checks),
        "case_failed_check_count": len(failed_checks),
        "case_failed_checks": failed_checks,
        "case_checks": case_checks,
        "evaluation_sha256": canonical_json_sha256(evaluation),
        "evaluation": evaluation,
        "source_assignment_audit": assignment_audit,
    }


def homfly_complete_evaluation_trace_audit(evaluation: Any) -> dict[str, Any]:
    """Independently replay measures, skein arithmetic, and unlink terminals."""

    if not isinstance(evaluation, Mapping):
        return _audit_result({"evaluation_payload_object": False})

    raw_states = evaluation.get("states")
    raw_transitions = evaluation.get("transitions")
    raw_terminals = evaluation.get("terminals")
    states = raw_states if isinstance(raw_states, list) else []
    transitions = raw_transitions if isinstance(raw_transitions, list) else []
    terminals = raw_terminals if isinstance(raw_terminals, list) else []
    state_by_id: dict[int, Mapping[str, Any]] = {}
    state_rows_valid = True
    for row in states:
        state_id = _strict_int(row.get("state_id")) if isinstance(row, Mapping) else None
        if state_id is None or state_id < 0 or state_id in state_by_id:
            state_rows_valid = False
            continue
        state_by_id[state_id] = row
    state_ids_contiguous = sorted(state_by_id) == list(range(len(states)))

    transition_ids: list[int] = []
    transition_measures_valid = True
    transition_replays_valid = True
    transition_state_links_valid = True
    transition_coefficients_valid = True
    child_witnesses_valid = True
    state_measure_polynomials = {
        (
            _measure_tuple(row.get("termination_measure")),
            _polynomial_terms(row.get("homfly_polynomial")),
        )
        for row in state_by_id.values()
    }
    for transition in transitions:
        if not isinstance(transition, Mapping):
            transition_measures_valid = False
            transition_replays_valid = False
            transition_state_links_valid = False
            continue
        state_id = _strict_int(transition.get("state_id"))
        if state_id is None:
            transition_state_links_valid = False
            continue
        transition_ids.append(state_id)
        state = state_by_id.get(state_id)
        parent = _measure_tuple(transition.get("parent_measure"))
        switch = _measure_tuple(transition.get("switch_measure"))
        smooth = _measure_tuple(transition.get("smooth_measure"))
        measure_valid = bool(
            parent is not None
            and switch is not None
            and smooth is not None
            and switch[0] == parent[0]
            and switch[1] < parent[1]
            and smooth[0] == parent[0] - 1
            and switch < parent
            and smooth < parent
            and transition.get("switch_measure_decreased") is True
            and transition.get("smooth_measure_decreased") is True
        )
        transition_measures_valid &= measure_valid

        parent_sign = _strict_int(transition.get("parent_sign"))
        expected_switch_coefficient = "a^-2" if parent_sign == 1 else "a^2"
        expected_smooth_coefficient = "a^-1*z" if parent_sign == 1 else "-a*z"
        coefficients_valid = bool(
            parent_sign in {-1, 1}
            and homfly_polynomial_equal(
                transition.get("switch_coefficient"), expected_switch_coefficient
            )
            and homfly_polynomial_equal(
                transition.get("smooth_coefficient"), expected_smooth_coefficient
            )
        )
        transition_coefficients_valid &= coefficients_valid

        parsed = [
            _parse_polynomial(transition.get(field))
            for field in (
                "switch_coefficient",
                "smooth_coefficient",
                "switch_polynomial",
                "smooth_polynomial",
                "recombined_polynomial",
                "parent_polynomial",
            )
        ]
        if any(value is None for value in parsed):
            replay_valid = False
        else:
            switch_coefficient, smooth_coefficient, switch_poly, smooth_poly, recombined, parent_poly = parsed
            replay = switch_coefficient * switch_poly + smooth_coefficient * smooth_poly
            replay_valid = bool(
                replay == recombined
                and recombined == parent_poly
                and transition.get("skein_replay_matched") is True
            )
        transition_replays_valid &= replay_valid

        state_link_valid = bool(
            state is not None
            and state.get("terminal") is False
            and _measure_tuple(state.get("termination_measure")) == parent
            and homfly_polynomial_equal(
                state.get("homfly_polynomial"), transition.get("parent_polynomial")
            )
        )
        transition_state_links_valid &= state_link_valid
        child_witnesses_valid &= bool(
            (
                switch,
                _polynomial_terms(transition.get("switch_polynomial")),
            )
            in state_measure_polynomials
            and (
                smooth,
                _polynomial_terms(transition.get("smooth_polynomial")),
            )
            in state_measure_polynomials
        )

    terminal_ids: list[int] = []
    terminal_normalizations_valid = True
    terminal_state_links_valid = True
    for terminal in terminals:
        if not isinstance(terminal, Mapping):
            terminal_normalizations_valid = False
            terminal_state_links_valid = False
            continue
        state_id = _strict_int(terminal.get("state_id"))
        component_count = _strict_int(terminal.get("component_count"))
        if state_id is None:
            terminal_state_links_valid = False
            continue
        terminal_ids.append(state_id)
        state = state_by_id.get(state_id)
        expected = (
            homfly_unlink_polynomial(component_count)
            if component_count is not None and component_count > 0
            else None
        )
        normalization_valid = bool(
            expected is not None
            and homfly_polynomial_equal(
                terminal.get("normalization_polynomial"), expected
            )
            and terminal.get("normalization_matched") is True
        )
        terminal_normalizations_valid &= normalization_valid
        terminal_state_links_valid &= bool(
            state is not None
            and state.get("terminal") is True
            and state.get("terminal_kind") == terminal.get("terminal_kind")
            and _strict_int(state.get("component_count")) == component_count
            and _measure_tuple(state.get("termination_measure"))
            == (
                _strict_int(state.get("crossing_count")),
                _strict_int(state.get("bad_crossing_count")),
            )
            and _strict_int(state.get("bad_crossing_count")) == 0
            and homfly_polynomial_equal(state.get("homfly_polynomial"), expected)
        )

    partition_valid = bool(
        len(set(transition_ids)) == len(transition_ids)
        and len(set(terminal_ids)) == len(terminal_ids)
        and set(transition_ids).isdisjoint(terminal_ids)
        and set(transition_ids) | set(terminal_ids) == set(state_by_id)
    )
    root = state_by_id.get(0)
    root_valid = bool(
        root is not None
        and homfly_polynomial_equal(
            root.get("homfly_polynomial"), evaluation.get("homfly_polynomial")
        )
        and _strict_int(root.get("crossing_count"))
        == _strict_int(evaluation.get("crossing_count"))
    )
    checks = {
        "evaluation_payload_object": True,
        "evaluation_shape": all(
            (
                evaluation.get("method")
                == "complete_descending_diagram_skein_evaluation",
                evaluation.get("algorithm_scope")
                == "arbitrary_finite_valid_oriented_signed_pd",
                evaluation.get("termination_order")
                == "lexicographic(crossing_count,bad_crossing_count)",
                evaluation.get("resource_cutoffs_used") is False,
                evaluation.get("worst_case_complexity") == "exponential",
                evaluation.get("frontier_count") == 0,
                evaluation.get("truncated") is False,
                evaluation.get("skipped") is False,
                evaluation.get("certified_for_input") is True,
            )
        ),
        "state_count_matches_rows": (
            _strict_int(evaluation.get("state_count")) == len(states)
            and bool(states)
        ),
        "transition_count_matches_rows": (
            _strict_int(evaluation.get("transition_count")) == len(transitions)
        ),
        "terminal_count_matches_rows": (
            _strict_int(evaluation.get("terminal_count")) == len(terminals)
            and bool(terminals)
        ),
        "state_rows_valid_and_contiguous": state_rows_valid and state_ids_contiguous,
        "state_transition_terminal_partition_valid": partition_valid,
        "transition_measures_strictly_decrease": transition_measures_valid,
        "transition_coefficients_match_parent_sign": transition_coefficients_valid,
        "transition_skein_replays_exact": transition_replays_valid,
        "transition_parent_state_links_exact": transition_state_links_valid,
        "transition_child_state_witnesses_present": child_witnesses_valid,
        "terminal_unlink_normalizations_exact": terminal_normalizations_valid,
        "terminal_state_links_exact": terminal_state_links_valid,
        "root_state_matches_evaluation": root_valid,
        "evaluation_summary_flags_match_replay": all(
            (
                evaluation.get("termination_measure_certified")
                is bool(transition_measures_valid),
                evaluation.get("skein_replay_certified")
                is bool(transition_replays_valid),
                evaluation.get("terminal_normalization_certified")
                is bool(terminal_normalizations_valid),
            )
        ),
    }
    return _audit_result(checks)


def full_homfly_pt_evaluation_certification_report_audit(
    report: Any,
) -> dict[str, Any]:
    """Audit a parsed full report without trusting its summary booleans."""

    if not isinstance(report, Mapping):
        return _audit_result({"report_payload_object": False})

    raw_cases = report.get("cases")
    cases = raw_cases if isinstance(raw_cases, list) else []
    case_notations = [
        str(row.get("notation") or "") if isinstance(row, Mapping) else ""
        for row in cases
    ]
    replayed_cases = [
        homfly_complete_certification_case(notation) for notation in _CASE_NOTATIONS
    ]
    replayed_by_notation = {row["notation"]: row for row in replayed_cases}
    case_trace_audits = [
        homfly_complete_evaluation_trace_audit(
            row.get("evaluation") if isinstance(row, Mapping) else None
        )
        for row in cases
    ]
    cases_exact = bool(
        case_notations == list(_CASE_NOTATIONS)
        and len(cases) == len(replayed_cases)
        and all(
            canonical_json_sha256(row) == canonical_json_sha256(expected)
            for row, expected in zip(cases, replayed_cases)
        )
    )
    case_evaluation_digests_valid = all(
        isinstance(row, Mapping)
        and isinstance(row.get("evaluation"), Mapping)
        and row.get("evaluation_sha256")
        == canonical_json_sha256(row["evaluation"])
        for row in cases
    )

    implementation_source = getsource(homfly_complete_evaluation_from_pd)
    implementation_bytes = implementation_source.encode("utf-8")
    implementation_parameters = list(
        signature(homfly_complete_evaluation_from_pd).parameters
    )
    implementation_bundle = homfly_implementation_bundle_witness()
    expected_implementation_checks = {
        "only_diagram_and_orientation_parameters": (
            implementation_parameters == ["diagram", "orientation"]
        ),
        "explicit_work_list_present": "while stack:" in implementation_source,
        "switch_measure_comparison_present": (
            "switch_measure < parent_measure" in implementation_source
        ),
        "smooth_measure_comparison_present": (
            "smooth_measure < parent_measure" in implementation_source
        ),
        "no_depth_or_node_cutoff_parameter": all(
            name not in implementation_parameters
            for name in ("max_crossings", "max_depth", "max_nodes")
        ),
        "free_circle_component_count_retained": (
            "diagram.component_count" in implementation_source
        ),
        "implementation_bundle_covers_complete_runtime_modules": (
            implementation_bundle["module_count"] == 3
            and [row["module"] for row in implementation_bundle["modules"]]
            == [
                "iroll.topology.homfly",
                "iroll.topology.pd",
                "iroll.topology.polynomial",
            ]
        ),
    }

    pinned = full_homfly_pinned_sources()
    raw_witnesses = report.get("source_witnesses")
    witnesses = raw_witnesses if isinstance(raw_witnesses, list) else []
    source_witnesses_match = len(witnesses) == len(pinned) and all(
        isinstance(witness, Mapping)
        and witness.get("role") == role
        and witness.get("title") == pinned[role]["title"]
        and witness.get("revision_id") == pinned[role]["revision_id"]
        and witness.get("url") == pinned[role]["url"]
        and witness.get("expected_sha256") == pinned[role]["sha256"]
        and witness.get("actual_sha256") == pinned[role]["sha256"]
        and witness.get("fetched") is True
        and witness.get("sha256_verified") is True
        and witness.get("byte_count") == pinned[role]["byte_count"]
        and witness.get("error") is None
        for role, witness in zip(pinned, witnesses)
    )

    raw_external_rows = report.get("external_normalization_rows")
    external_rows = raw_external_rows if isinstance(raw_external_rows, list) else []
    external_rows_match = len(external_rows) == 3
    for notation, row in zip(("4_1", "L5a1", "L6a4"), external_rows):
        case = replayed_by_notation[notation]
        external_rows_match &= bool(
            isinstance(row, Mapping)
            and row.get("notation") == notation
            and row.get("url") == pinned[notation]["url"]
            and row.get("revision_id") == pinned[notation]["revision_id"]
            and row.get("sha256") == pinned[notation]["sha256"]
            and row.get("source_revision_sha256_verified") is True
            and row.get("source_math_matches_pinned_declaration") is True
            and homfly_polynomial_equal(
                row.get("expected_polynomial"),
                pinned[notation]["expected_polynomial"],
            )
            and homfly_polynomial_equal(
                row.get("computed_polynomial"), case["observed_homfly"]
            )
            and row.get("computed_polynomial_matches_external_table") is True
            and row.get("complete_evaluation_certified_for_input") is True
        )

    expected_report_checks = {
        name: True for name in _REPORT_CHECK_NAMES
    }
    report_checks = report.get("report_checks")
    checks = {
        "report_payload_object": True,
        "report_shape": all(
            (
                report.get("artifact_schema_version") == 1,
                report.get("artifact_kind")
                == "full_homfly_pt_evaluation_certification_report",
                report.get("claim_scope")
                == "full_homfly_pt_evaluation_mathematical_and_external_normalization_certificate",
                report.get("method")
                == "cutoff_free_descending_diagram_skein_certification",
                report.get("algorithm_scope")
                == "arbitrary_finite_valid_oriented_signed_pd",
                report.get("certified") is True,
                report.get("completion_claimed") is True,
                report.get("arbitrary_signed_pd_coverage_certified") is True,
                report.get("external_table_normalization_certified") is True,
                report.get("skein_relation_certified") is True,
                report.get("registered_fixture_regression_certified") is True,
                report.get("counterexample_count") == 0,
                report.get("counterexamples") == [],
            )
        ),
        "report_checks_exact": (
            report_checks == expected_report_checks
            and report.get("report_check_count") == len(expected_report_checks)
            and report.get("report_failed_check_count") == 0
            and report.get("report_failed_checks") == []
        ),
        "implementation_source_sha256_matches_runtime": (
            report.get("implementation_function")
            == "iroll.topology.homfly.homfly_complete_evaluation_from_pd"
            and report.get("implementation_parameters") == implementation_parameters
            and report.get("implementation_source_sha256")
            == sha256(implementation_bytes).hexdigest()
            and report.get("implementation_source_utf8_byte_count")
            == len(implementation_bytes)
            and report.get("implementation_contract_checks")
            == expected_implementation_checks
            and all(expected_implementation_checks.values())
        ),
        "implementation_bundle_sha256_matches_runtime": (
            report.get("implementation_bundle") == implementation_bundle
            and report.get("implementation_bundle_sha256")
            == implementation_bundle["bundle_sha256"]
        ),
        "formal_termination_argument_shape": (
            isinstance(report.get("formal_termination_argument"), Mapping)
            and report["formal_termination_argument"].get("domain")
            == "finite valid oriented signed planar diagrams"
            and report["formal_termination_argument"].get("measure")
            == "lexicographic(crossing_count,bad_crossing_count) in N x N"
            and "well founded"
            in str(report["formal_termination_argument"].get("well_foundedness"))
            and "exponential"
            in str(report["formal_termination_argument"].get("resource_boundary"))
        ),
        "pinned_source_witnesses_exact": source_witnesses_match,
        "external_normalization_rows_exact": external_rows_match,
        "case_notation_set_and_order_exact": case_notations == list(_CASE_NOTATIONS),
        "case_count_matches_rows": report.get("case_count") == len(cases) == 7,
        "case_evaluation_digests_valid": case_evaluation_digests_valid,
        "case_traces_independently_certified": (
            len(case_trace_audits) == 7
            and all(audit.get("certified") is True for audit in case_trace_audits)
        ),
        "case_rows_match_current_implementation_replay": cases_exact,
        "total_state_count_matches_cases": (
            _strict_int(report.get("total_state_count"))
            == sum(
                _strict_int(row["evaluation"].get("state_count")) or 0
                for row in cases
                if isinstance(row, Mapping)
                and isinstance(row.get("evaluation"), Mapping)
            )
        ),
        "total_transition_count_matches_cases": (
            _strict_int(report.get("total_transition_count"))
            == sum(
                _strict_int(row["evaluation"].get("transition_count")) or 0
                for row in cases
                if isinstance(row, Mapping)
                and isinstance(row.get("evaluation"), Mapping)
            )
        ),
        "total_terminal_count_matches_cases": (
            _strict_int(report.get("total_terminal_count"))
            == sum(
                _strict_int(row["evaluation"].get("terminal_count")) or 0
                for row in cases
                if isinstance(row, Mapping)
                and isinstance(row.get("evaluation"), Mapping)
            )
        ),
    }
    result = _audit_result(checks)
    result.update(
        {
            "case_trace_audits": case_trace_audits,
            "case_count": len(cases),
            "source_witness_count": len(witnesses),
            "implementation_source_sha256": sha256(implementation_bytes).hexdigest(),
            "implementation_bundle_sha256": implementation_bundle[
                "bundle_sha256"
            ],
        }
    )
    return result


def _parse_polynomial(value: Any):
    if not isinstance(value, str):
        return None
    try:
        return parse_multivariate_laurent_polynomial(value, variables=("a", "z"))
    except ValueError:
        return None


def _polynomial_terms(value: Any):
    polynomial = _parse_polynomial(value)
    return polynomial.terms if polynomial is not None else None


def _measure_tuple(value: Any) -> tuple[int, int] | None:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return None
    if len(value) != 2:
        return None
    first = _strict_int(value[0])
    second = _strict_int(value[1])
    if first is None or second is None or first < 0 or second < 0:
        return None
    return (first, second)


def _strict_int(value: Any) -> int | None:
    return value if isinstance(value, int) and not isinstance(value, bool) else None


def _positive_int(value: Any) -> bool:
    parsed = _strict_int(value)
    return parsed is not None and parsed > 0


def _audit_result(checks: Mapping[str, bool]) -> dict[str, Any]:
    normalized = {str(name): passed is True for name, passed in checks.items()}
    failed = [name for name, passed in normalized.items() if not passed]
    return {
        "certified": not failed,
        "check_count": len(normalized),
        "passed_check_count": len(normalized) - len(failed),
        "failed_check_count": len(failed),
        "failed_checks": failed,
        "checks": normalized,
    }
