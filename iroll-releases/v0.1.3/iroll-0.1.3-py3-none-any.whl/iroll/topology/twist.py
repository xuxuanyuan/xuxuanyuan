"""Discrete twist approximation for ribbons."""

from __future__ import annotations

import numpy as np
from numpy.typing import ArrayLike

from iroll.core.types import FloatArray, as_points3d, normalize_vectors


def compute_twist(
    points: ArrayLike,
    directors: ArrayLike,
    *,
    closed: bool = False,
    eps: float = 1e-12,
) -> float:
    points = as_points3d(points)
    directors = np.asarray(directors, dtype=np.float64)
    if directors.shape != points.shape:
        raise ValueError("directors must have the same shape as points")

    axes = _segment_axes(points, closed=closed)
    if len(axes) == 0:
        return 0.0

    total = 0.0
    for index, axis in enumerate(axes):
        next_index = (index + 1) % len(points)
        if not closed and index == len(points) - 1:
            break

        first = _project_to_axis_plane(directors[index], axis, eps=eps)
        second = _project_to_axis_plane(directors[next_index], axis, eps=eps)
        if np.linalg.norm(first) <= eps or np.linalg.norm(second) <= eps:
            continue

        cross = np.cross(first, second)
        sine = float(np.dot(cross, axis))
        cosine = float(np.dot(first, second))
        total += float(np.arctan2(sine, cosine))

    return total / (2.0 * np.pi)


def _segment_axes(points: FloatArray, *, closed: bool) -> FloatArray:
    if closed:
        vectors = np.roll(points, -1, axis=0) - points
    else:
        vectors = points[1:] - points[:-1]
    return normalize_vectors(vectors)


def _project_to_axis_plane(vector: FloatArray, axis: FloatArray, *, eps: float) -> FloatArray:
    projected = vector - np.dot(vector, axis) * axis
    normalized = normalize_vectors(projected)
    if np.linalg.norm(normalized) <= eps:
        return np.zeros(3, dtype=np.float64)
    return normalized
