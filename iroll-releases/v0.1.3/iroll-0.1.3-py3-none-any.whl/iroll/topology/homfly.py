"""HOMFLY-PT result helpers and bounded skein-trace utilities."""

from __future__ import annotations

from functools import lru_cache
from typing import Iterable

from iroll.topology.knot_table import lookup_link, lookup_knot
from iroll.topology.pd import (
    PDOrientation,
    PlanarDiagram,
    jones_polynomial_from_pd,
    mirror_signed_pd,
)
from iroll.topology.polynomial import (
    MultivariateLaurentPolynomial,
    parse_multivariate_laurent_polynomial,
)


_HOMFLY_FRONTIER_WITNESS_LIMIT = 8
_HOMFLY_REDUCTION_CONTRIBUTION_WITNESS_LIMIT = 8
_HOMFLY_MATURITY_ZERO_CROSSING_UNLINK = "zero_crossing_unlink_terminal"
_HOMFLY_MATURITY_RECURSIVE_FRONTIER_EXHAUSTED = (
    "recursive_switching_to_descending_frontier_exhausted"
)
_HOMFLY_MATURITY_SOURCE_TABLE_DIAGNOSTIC = "source_table_diagnostic_only"
_HOMFLY_MATURITY_NOT_CERTIFIED = "not_certified"
_HOMFLY_MATURITY_CERTIFIED_PATHS = {
    _HOMFLY_MATURITY_ZERO_CROSSING_UNLINK,
    _HOMFLY_MATURITY_RECURSIVE_FRONTIER_EXHAUSTED,
}


def _bounded_homfly_maturity_path(
    *,
    source_table_diagnostic_only: bool = False,
    zero_crossing_certified: bool = False,
    certified_for_input: bool = False,
    frontier_exhausted: bool = False,
    skipped: bool = False,
    truncated: bool = False,
    frontier_count: int = 0,
) -> str:
    if source_table_diagnostic_only:
        return _HOMFLY_MATURITY_SOURCE_TABLE_DIAGNOSTIC
    if zero_crossing_certified:
        return _HOMFLY_MATURITY_ZERO_CROSSING_UNLINK
    if (
        certified_for_input
        and frontier_exhausted
        and not skipped
        and not truncated
        and int(frontier_count or 0) == 0
    ):
        return _HOMFLY_MATURITY_RECURSIVE_FRONTIER_EXHAUSTED
    return _HOMFLY_MATURITY_NOT_CERTIFIED


def _bounded_homfly_maturity_path_certified(path: str) -> bool:
    return path in _HOMFLY_MATURITY_CERTIFIED_PATHS

def _bounded_homfly_maturity_path_evidence_record(
    *,
    bounded_homfly_maturity_path: str,
    source_table_diagnostic_only: bool = False,
    zero_crossing_certified: bool = False,
    certified_for_input: bool = False,
    frontier_exhausted: bool = False,
    skipped: bool = False,
    truncated: bool = False,
    frontier_count: int = 0,
    certification_blocker_count: int = 0,
) -> dict:
    expected_path = _bounded_homfly_maturity_path(
        source_table_diagnostic_only=source_table_diagnostic_only,
        zero_crossing_certified=zero_crossing_certified,
        certified_for_input=certified_for_input,
        frontier_exhausted=frontier_exhausted,
        skipped=skipped,
        truncated=truncated,
        frontier_count=frontier_count,
    )
    path = str(bounded_homfly_maturity_path or _HOMFLY_MATURITY_NOT_CERTIFIED)
    return {
        "method": "homfly_bounded_maturity_path_evidence",
        "claim_scope": "bounded_maturity_path_classification_diagnostics",
        "bounded_homfly_maturity_path": path,
        "expected_bounded_homfly_maturity_path": expected_path,
        "bounded_homfly_maturity_path_matches_expected": path == expected_path,
        "bounded_homfly_maturity_path_certified": (
            _bounded_homfly_maturity_path_certified(path)
        ),
        "source_table_diagnostic_only": source_table_diagnostic_only,
        "zero_crossing_certified": zero_crossing_certified,
        "certified_for_input": certified_for_input,
        "frontier_exhausted": frontier_exhausted,
        "skipped": skipped,
        "truncated": truncated,
        "frontier_count": int(frontier_count or 0),
        "certification_blocker_count": int(certification_blocker_count or 0),
        "full_table_normalization_certified": False,
        "arbitrary_diagram_coverage_certified": False,
        "notes": [
            "diagnostic record for bounded HOMFLY maturity-path classification",
            "not a full table-normalization or arbitrary-diagram coverage claim",
        ],
    }



def homfly_polynomial_for_knot(
    *,
    determinant: int,
    alexander_polynomial: str | None = None,
    crossing_count: int | None = None,
) -> dict:
    entry = lookup_knot(
        determinant=determinant,
        alexander_polynomial=alexander_polynomial,
        crossing_count=crossing_count,
    )
    if entry is not None and entry.homfly_polynomial is not None:
        return {
            "homfly_polynomial": entry.homfly_polynomial,
            "method": "built_in_knot_table",
            "table_match": entry.to_dict(),
            "skipped": False,
            "notes": [],
        }
    return _skipped("HOMFLY-PT requires a table match or future skein recursion")


def homfly_polynomial_for_link(link_type: str) -> dict:
    entry = lookup_link(link_type=link_type)
    if entry is not None and entry.homfly_polynomial is not None:
        return {
            "homfly_polynomial": entry.homfly_polynomial,
            "method": "built_in_link_table",
            "table_match": entry.to_dict(),
            "skipped": False,
            "notes": [],
        }
    result = _skipped("HOMFLY-PT requires a table match or future skein recursion")
    result["table_match"] = entry.to_dict() if entry is not None else None
    return result


def homfly_polynomial_from_pd(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None = None,
    max_crossings: int = 8,
    max_depth: int = 2,
    max_nodes: int = 64,
) -> dict:
    if diagram.crossing_count == 0:
        component_count = diagram.component_count or 1
        return {
            "homfly_polynomial": homfly_unlink_polynomial(component_count),
            "method": "zero_crossing_unlink_normalization",
            "table_match": None,
            "skipped": False,
            "notes": [
                "normalization uses P(unknot)=1 and split-union factor ((a - a^-1) / z)^(components-1)",
            ],
        }
    if diagram.crossing_count > max_crossings:
        result = _skipped("HOMFLY-PT skein trace skipped for crossing_count > max_crossings")
        result["max_crossings"] = max_crossings
        return result

    root_orientation = _homfly_orientation_or_inferred(diagram, orientation)
    recursive = homfly_recursive_evaluation_from_pd(
        diagram,
        orientation=root_orientation,
        max_crossings=max_crossings,
        max_depth=max_depth + max_crossings,
        max_nodes=max_nodes,
    )
    if not recursive["skipped"] and recursive["homfly_polynomial"] is not None:
        return {
            "homfly_polynomial": recursive["homfly_polynomial"],
            "method": "bounded_recursive_switching_to_descending",
            "table_match": None,
            "skipped": False,
            "recursive_evaluation": recursive,
            "notes": recursive["notes"],
        }

    expansion = homfly_skein_expansion_from_pd(
        diagram,
        orientation=root_orientation,
        max_crossings=max_crossings,
        max_depth=max_depth,
        max_nodes=max_nodes,
    )
    if not expansion["skipped"] and expansion["homfly_polynomial"] is not None:
        return {
            "homfly_polynomial": expansion["homfly_polynomial"],
            "method": "bounded_skein_expansion_terminal_sum",
            "table_match": None,
            "skipped": False,
            "expansion": expansion,
            "notes": expansion["notes"],
        }

    trace = homfly_skein_trace_from_pd(
        diagram,
        orientation=root_orientation,
        max_crossings=max_crossings,
        max_depth=max_depth,
        max_nodes=max_nodes,
    )
    result = _skipped(
        "bounded HOMFLY-PT skein expansion generated, but non-terminal frontier diagrams remain"
    )
    result["method"] = "bounded_skein_expansion_without_evaluation"
    result["trace"] = trace
    result["expansion"] = expansion
    return result


def homfly_certified_evaluation_from_pd(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None = None,
    max_crossings: int = 8,
    max_depth: int | None = None,
    max_nodes: int | None = None,
) -> dict:
    """Evaluate HOMFLY and certify when the recursive frontier is exhausted.

    This certifies only the provided input diagram under the documented iroll
    signed-PD/orientation convention. It is not an external table-normalization
    certificate and not a claim of arbitrary-diagram coverage.
    """

    effective_max_depth = (
        max(16, diagram.crossing_count * 4 + 4)
        if max_depth is None
        else max_depth
    )
    effective_max_nodes = (
        max(256, 2 ** min(diagram.crossing_count + 4, 16))
        if max_nodes is None
        else max_nodes
    )

    if diagram.crossing_count == 0:
        component_count = diagram.component_count or 1
        return {
            "homfly_polynomial": homfly_unlink_polynomial(component_count),
            "method": "certified_zero_crossing_unlink_normalization",
            "normalization": "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1",
            "max_crossings": max_crossings,
            "max_depth": effective_max_depth,
            "max_nodes": effective_max_nodes,
            "frontier_reasons": [],
            "frontier_reason_count": 0,
            "frontier_witness_count": 0,
            "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
            "frontier_witnesses_truncated": False,
            "frontier_witnesses": [],
            "first_frontier_witness": None,
            "frontier_witness_summary": _homfly_frontier_witness_summary_record(
                {
                    "frontier_count": 0,
                    "frontier_witness_count": 0,
                    "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
                    "frontier_witnesses_truncated": False,
                    "frontier_witnesses": [],
                    "first_frontier_witness": None,
                }
            ),
            "certified_for_input": True,
            "full_table_normalization_certified": False,
            "arbitrary_diagram_coverage_certified": False,
            "recursive_evaluation": None,
            "skipped": False,
            "notes": [
                "zero-crossing unlink normalization is closed for this input diagram",
                "this is not an external table-normalization certificate",
            ],
        }

    recursive = homfly_recursive_evaluation_from_pd(
        diagram,
        orientation=orientation,
        max_crossings=max_crossings,
        max_depth=effective_max_depth,
        max_nodes=effective_max_nodes,
    )
    certified = (
        not recursive["skipped"]
        and recursive.get("homfly_polynomial") is not None
        and recursive.get("frontier_count", 0) == 0
        and not recursive.get("truncated", False)
    )
    notes = [
        "recursive switching-to-descending evaluation exhausted the frontier for this input diagram"
        if certified
        else "recursive switching-to-descending evaluation did not exhaust the frontier for this input diagram",
        "this is not an external table-normalization certificate",
        "this is not a claim of arbitrary signed-diagram HOMFLY coverage",
    ]
    if recursive.get("notes"):
        notes.extend(str(note) for note in recursive["notes"])
    frontier_reasons = list(recursive.get("frontier_reasons", []))
    frontier_witnesses = _homfly_frontier_witnesses_from_recursive(recursive)
    frontier_witness_summary = _homfly_frontier_witness_summary_record(
        {
            "frontier_count": int(recursive.get("frontier_count", 0) or 0),
            "frontier_witness_count": len(frontier_witnesses),
            "frontier_witness_limit": int(
                recursive.get(
                    "frontier_witness_limit",
                    _HOMFLY_FRONTIER_WITNESS_LIMIT,
                )
                or _HOMFLY_FRONTIER_WITNESS_LIMIT
            ),
            "frontier_witnesses_truncated": bool(
                recursive.get(
                    "frontier_witnesses_truncated",
                    int(recursive.get("frontier_count", 0) or 0)
                    > len(frontier_witnesses),
                )
            ),
            "frontier_witnesses": frontier_witnesses,
            "first_frontier_witness": (
                frontier_witnesses[0] if frontier_witnesses else None
            ),
        }
    )
    return {
        "homfly_polynomial": recursive["homfly_polynomial"] if certified else None,
        "method": (
            "certified_recursive_switching_to_descending"
            if certified
            else "uncertified_recursive_switching_to_descending"
        ),
        "normalization": recursive["normalization"],
        "max_crossings": max_crossings,
        "max_depth": effective_max_depth,
        "max_nodes": effective_max_nodes,
        "frontier_reasons": frontier_reasons,
        "frontier_reason_count": len(frontier_reasons),
        "frontier_witness_count": len(frontier_witnesses),
        "frontier_witness_limit": int(
            recursive.get(
                "frontier_witness_limit",
                _HOMFLY_FRONTIER_WITNESS_LIMIT,
            )
            or _HOMFLY_FRONTIER_WITNESS_LIMIT
        ),
        "frontier_witnesses_truncated": bool(
            recursive.get(
                "frontier_witnesses_truncated",
                int(recursive.get("frontier_count", 0) or 0)
                > len(frontier_witnesses),
            )
        ),
        "frontier_witnesses": frontier_witnesses,
        "first_frontier_witness": (
            frontier_witnesses[0] if frontier_witnesses else None
        ),
        "frontier_witness_summary": frontier_witness_summary,
        "certified_for_input": certified,
        "full_table_normalization_certified": False,
        "arbitrary_diagram_coverage_certified": False,
        "recursive_evaluation": recursive,
        "skipped": not certified,
        "notes": notes,
    }


def homfly_iterative_certified_evaluation_from_pd(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None = None,
    max_crossings: int = 8,
    initial_depth: int = 0,
    max_depth: int | None = None,
    max_nodes: int | None = None,
) -> dict:
    """Run recursive HOMFLY evaluation with increasing depth limits.

    This is still bounded and input-scoped. It reduces manual depth tuning for
    small signed-PD inputs, but it is not a proof of arbitrary-diagram coverage.
    """

    effective_max_depth = (
        max(16, diagram.crossing_count * 4 + 4)
        if max_depth is None
        else max_depth
    )
    effective_max_nodes = (
        max(256, 2 ** min(diagram.crossing_count + 4, 16))
        if max_nodes is None
        else max_nodes
    )
    if initial_depth < 0:
        raise ValueError("initial_depth must be non-negative")
    if effective_max_depth < initial_depth:
        raise ValueError("max_depth must be greater than or equal to initial_depth")

    if diagram.crossing_count == 0:
        result = homfly_certified_evaluation_from_pd(
            diagram,
            orientation=orientation,
            max_crossings=max_crossings,
            max_depth=effective_max_depth,
            max_nodes=effective_max_nodes,
        )
        result.update(
            {
                "method": "certified_iterative_zero_crossing_unlink_normalization",
                "initial_depth": initial_depth,
                "attempt_count": 0,
                "depth_attempts": [],
                "solved_depth": 0,
                "solved_max_nodes": effective_max_nodes,
                "frontier_reasons": [],
                "frontier_reason_count": 0,
                "frontier_witness_count": 0,
                "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
                "frontier_witnesses_truncated": False,
                "frontier_witnesses": [],
                "first_frontier_witness": None,
                "frontier_witness_summary": _homfly_frontier_witness_summary_record(
                    {
                        "frontier_count": 0,
                        "frontier_witness_count": 0,
                        "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
                        "frontier_witnesses_truncated": False,
                        "frontier_witnesses": [],
                        "first_frontier_witness": None,
                    }
                ),
            }
        )
        result["notes"] = [
            "zero-crossing unlink normalization is closed before recursive deepening is needed",
            *result.get("notes", []),
        ]
        return result

    attempts: list[dict] = []
    solved_recursive: dict | None = None
    last_recursive: dict | None = None
    for depth_limit in range(initial_depth, effective_max_depth + 1):
        recursive = homfly_recursive_evaluation_from_pd(
            diagram,
            orientation=orientation,
            max_crossings=max_crossings,
            max_depth=depth_limit,
            max_nodes=effective_max_nodes,
        )
        last_recursive = recursive
        attempts.append(_homfly_iterative_attempt_summary(recursive))
        solved = (
            not recursive["skipped"]
            and recursive.get("homfly_polynomial") is not None
            and recursive.get("frontier_count", 0) == 0
            and not recursive.get("truncated", False)
        )
        if solved:
            solved_recursive = recursive
            break

    certified = solved_recursive is not None
    selected_recursive = solved_recursive or last_recursive
    solved_depth = (
        int(solved_recursive["max_depth"]) if solved_recursive is not None else None
    )
    notes = [
        "iterative recursive HOMFLY evaluation exhausted the frontier for this input diagram"
        if certified
        else "iterative recursive HOMFLY evaluation did not exhaust the frontier for this input diagram",
        "this is not an external table-normalization certificate",
        "this is still bounded and does not claim arbitrary signed-diagram HOMFLY coverage",
    ]
    if selected_recursive and selected_recursive.get("notes"):
        notes.extend(str(note) for note in selected_recursive["notes"])
    frontier_reasons = _homfly_frontier_reasons(
        selected_recursive.get("frontier", []) if selected_recursive else []
    )
    frontier_witnesses = (
        _homfly_frontier_witnesses_from_recursive(selected_recursive)
        if selected_recursive
        else []
    )
    frontier_witness_limit = (
        int(
            selected_recursive.get(
                "frontier_witness_limit",
                _HOMFLY_FRONTIER_WITNESS_LIMIT,
            )
            or _HOMFLY_FRONTIER_WITNESS_LIMIT
        )
        if selected_recursive
        else _HOMFLY_FRONTIER_WITNESS_LIMIT
    )
    frontier_witnesses_truncated = (
        bool(
            selected_recursive.get(
                "frontier_witnesses_truncated",
                int(selected_recursive.get("frontier_count", 0) or 0)
                > len(frontier_witnesses),
            )
        )
        if selected_recursive
        else False
    )
    frontier_witness_summary = _homfly_frontier_witness_summary_record(
        {
            "frontier_count": int(
                selected_recursive.get("frontier_count", 0) or 0
            )
            if selected_recursive
            else 0,
            "frontier_witness_count": len(frontier_witnesses),
            "frontier_witness_limit": frontier_witness_limit,
            "frontier_witnesses_truncated": frontier_witnesses_truncated,
            "frontier_witnesses": frontier_witnesses,
            "first_frontier_witness": (
                frontier_witnesses[0] if frontier_witnesses else None
            ),
        }
    )
    return {
        "homfly_polynomial": (
            solved_recursive["homfly_polynomial"] if solved_recursive else None
        ),
        "method": (
            "certified_iterative_recursive_switching_to_descending"
            if certified
            else "uncertified_iterative_recursive_switching_to_descending"
        ),
        "normalization": "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1",
        "max_crossings": max_crossings,
        "initial_depth": initial_depth,
        "max_depth": effective_max_depth,
        "max_nodes": effective_max_nodes,
        "attempt_count": len(attempts),
        "depth_attempts": attempts,
        "solved_depth": solved_depth,
        "solved_max_nodes": effective_max_nodes if certified else None,
        "frontier_reasons": frontier_reasons,
        "frontier_reason_count": len(frontier_reasons),
        "frontier_witness_count": len(frontier_witnesses),
        "frontier_witness_limit": frontier_witness_limit,
        "frontier_witnesses_truncated": frontier_witnesses_truncated,
        "frontier_witnesses": frontier_witnesses,
        "first_frontier_witness": (
            frontier_witnesses[0] if frontier_witnesses else None
        ),
        "frontier_witness_summary": frontier_witness_summary,
        "certified_for_input": certified,
        "full_table_normalization_certified": False,
        "arbitrary_diagram_coverage_certified": False,
        "recursive_evaluation": selected_recursive,
        "skipped": not certified,
        "notes": notes,
    }


def _homfly_iterative_attempt_summary(recursive: dict) -> dict:
    return {
        "max_depth": int(recursive.get("max_depth", 0) or 0),
        "max_nodes": int(recursive.get("max_nodes", 0) or 0),
        "recursion_nodes": int(recursive.get("recursion_nodes", 0) or 0),
        "cache_hits": int(recursive.get("cache_hits", 0) or 0),
        "terminal_reduction_count": len(recursive.get("terminal_reductions", [])),
        "memoized_reduction_count": len(recursive.get("memoized_reductions", [])),
        "frontier_count": int(recursive.get("frontier_count", 0) or 0),
        "truncated": bool(recursive.get("truncated", False)),
        "skipped": bool(recursive.get("skipped", True)),
        "homfly_polynomial": recursive.get("homfly_polynomial"),
        "frontier_reasons": _homfly_frontier_reasons(
            recursive.get("frontier", [])
        ),
    }


def _homfly_frontier_reasons(frontier: Iterable[dict]) -> list[str]:
    return sorted(
        {
            str(item.get("reason", ""))
            for item in frontier
            if item.get("reason")
        }
    )


def _homfly_frontier_witnesses_from_frontier(
    frontier: Iterable[dict],
    *,
    max_depth: int | None,
    max_nodes: int | None,
    recursion_nodes: int | None = None,
    limit: int = _HOMFLY_FRONTIER_WITNESS_LIMIT,
) -> list[dict]:
    witnesses: list[dict] = []
    for index, item in enumerate(frontier):
        if len(witnesses) >= limit:
            break
        if not isinstance(item, dict):
            continue
        path = item.get("path")
        if not isinstance(path, list):
            move = item.get("move")
            path = [str(move)] if move is not None else []
        component_count = item.get("component_count")
        witness = {
            "frontier_index": index,
            "path": [str(step) for step in path],
            "depth": int(item.get("depth", 0) or 0),
            "move": str(item["move"]) if item.get("move") is not None else None,
            "reason": str(item.get("reason", "")),
            "crossing_count": int(item.get("crossing_count", 0) or 0),
            "component_count": (
                int(component_count) if component_count is not None else None
            ),
            "has_orientation": bool(item.get("has_orientation", False)),
            "cap": {"max_depth": max_depth, "max_nodes": max_nodes},
        }
        if recursion_nodes is not None:
            witness["recursion_nodes"] = int(recursion_nodes)
        if item.get("coefficient") is not None:
            witness["coefficient"] = str(item["coefficient"])
        if "canonical_key" in item:
            witness["canonical_key"] = item["canonical_key"]
        witnesses.append(witness)
    return witnesses


def _homfly_frontier_witnesses_from_recursive(recursive: dict) -> list[dict]:
    stored = recursive.get("frontier_witnesses")
    if isinstance(stored, list) and stored:
        return [
            dict(witness)
            for witness in stored[:_HOMFLY_FRONTIER_WITNESS_LIMIT]
            if isinstance(witness, dict)
        ]
    return _homfly_frontier_witnesses_from_frontier(
        recursive.get("frontier", []),
        max_depth=recursive.get("max_depth"),
        max_nodes=recursive.get("max_nodes"),
        recursion_nodes=int(recursive.get("recursion_nodes", 0) or 0),
    )


def _homfly_generated_frontier_witnesses(
    cases: Iterable[dict],
    *,
    limit: int = _HOMFLY_FRONTIER_WITNESS_LIMIT,
) -> list[dict]:
    witnesses: list[dict] = []
    for case in cases:
        if len(witnesses) >= limit:
            break
        if not isinstance(case, dict):
            continue
        if int(case.get("frontier_count", 0) or 0) <= 0:
            continue
        case_witnesses = [
            witness
            for witness in case.get("frontier_witnesses", []) or []
            if isinstance(witness, dict)
        ]
        if not case_witnesses and isinstance(case.get("first_frontier_witness"), dict):
            case_witnesses = [case["first_frontier_witness"]]
        for witness in case_witnesses:
            if len(witnesses) >= limit:
                break
            row = {
                "case_id": case.get("case_id"),
                "source_notation": case.get("source_notation"),
                "source_kind": case.get("source_kind"),
                "branch": case.get("branch"),
                "branch_depth": int(case.get("branch_depth", 0) or 0),
                "branch_path": list(case.get("branch_path", []) or []),
                "frontier_count": int(case.get("frontier_count", 0) or 0),
                "frontier_reasons": list(case.get("frontier_reasons", []) or []),
                "frontier_index": witness.get("frontier_index"),
                "recursive_path": list(witness.get("path", []) or []),
                "recursive_depth": witness.get("depth"),
                "recursive_move": witness.get("move"),
                "reason": witness.get("reason"),
                "crossing_count": witness.get(
                    "crossing_count",
                    case.get("crossing_count"),
                ),
                "component_count": witness.get(
                    "component_count",
                    case.get("component_count"),
                ),
                "cap": witness.get("cap"),
            }
            if witness.get("recursion_nodes") is not None:
                row["recursion_nodes"] = witness["recursion_nodes"]
            if witness.get("canonical_key") is not None:
                row["canonical_key"] = witness["canonical_key"]
            witnesses.append(row)
    return witnesses


def _homfly_optional_int(value) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _homfly_witness_path(witness: dict, *fields: str) -> list[str]:
    for field in fields:
        raw_path = witness.get(field)
        if isinstance(raw_path, list):
            return [str(step) for step in raw_path]
    return []


def _homfly_witness_count_records(
    counts: dict,
    key: str,
) -> list[dict]:
    return [
        {key: value, "witness_count": counts[value]}
        for value in sorted(counts)
    ]


def _homfly_witness_path_prefix_records(
    counts: dict[tuple[str, ...], int],
) -> list[dict]:
    return [
        {"path_prefix": list(value), "witness_count": counts[value]}
        for value in sorted(counts)
    ]


def _homfly_frontier_reason_total_map(
    records: Iterable[dict] | None,
) -> dict[str, int]:
    totals: dict[str, int] = {}
    for record in records or []:
        if not isinstance(record, dict):
            continue
        reason = record.get("frontier_reason", record.get("reason"))
        if reason is None:
            continue
        value = str(reason)
        totals[value] = totals.get(value, 0) + int(
            record.get("frontier_count", 0) or 0
        )
    return totals


def _homfly_frontier_pressure_record(
    *,
    frontier_count: int,
    witness_count: int,
    witness_reason_counts: dict[str, int],
    frontier_reason_counts: Iterable[dict] | None,
    first_witness_reason: str | None,
) -> dict:
    frontier_reason_totals = _homfly_frontier_reason_total_map(
        frontier_reason_counts
    )
    reason_values = sorted(
        set(witness_reason_counts) | set(frontier_reason_totals)
    )
    reason_records = []
    first_unwitnessed_reason = None
    for reason in reason_values:
        reason_frontier_count = (
            frontier_reason_totals[reason]
            if reason in frontier_reason_totals
            else None
        )
        reason_witness_count = witness_reason_counts.get(reason, 0)
        reason_unwitnessed_count = (
            max(reason_frontier_count - reason_witness_count, 0)
            if reason_frontier_count is not None
            else None
        )
        reason_all_witnessed = (
            reason_unwitnessed_count == 0
            if reason_unwitnessed_count is not None
            else None
        )
        if first_unwitnessed_reason is None and (
            reason_unwitnessed_count is not None
            and reason_unwitnessed_count > 0
        ):
            first_unwitnessed_reason = reason
        reason_records.append(
            {
                "reason": reason,
                "frontier_count": reason_frontier_count,
                "witness_count": reason_witness_count,
                "unwitnessed_frontier_count": reason_unwitnessed_count,
                "all_frontier_witnessed": reason_all_witnessed,
            }
        )

    unwitnessed_frontier_count = max(frontier_count - witness_count, 0)
    return {
        "frontier_count": frontier_count,
        "witness_count": witness_count,
        "unwitnessed_frontier_count": unwitnessed_frontier_count,
        "all_frontier_witnessed": unwitnessed_frontier_count == 0,
        "frontier_reason_counts_available": (
            frontier_count == 0 or bool(frontier_reason_totals)
        ),
        "first_witness_reason": first_witness_reason,
        "first_unwitnessed_reason": first_unwitnessed_reason,
        "reason_counts": reason_records,
        "reason_count": len(reason_records),
    }


def _homfly_frontier_witness_summary_record(payload: dict) -> dict:
    """Summarize only the already-capped frontier witness list."""

    witness_list = (
        [
            witness
            for witness in payload.get("frontier_witnesses", []) or []
            if isinstance(witness, dict)
        ]
        if isinstance(payload.get("frontier_witnesses", []), list)
        else []
    )
    witness_limit = int(
        payload.get("frontier_witness_limit", _HOMFLY_FRONTIER_WITNESS_LIMIT)
        or _HOMFLY_FRONTIER_WITNESS_LIMIT
    )
    reason_counts: dict[str, int] = {}
    source_kind_counts: dict[str, int] = {}
    branch_counts: dict[str, int] = {}
    recursive_path_prefix_counts: dict[tuple[str, ...], int] = {}
    branch_path_prefix_counts: dict[tuple[str, ...], int] = {}
    depths: list[int] = []
    branch_depths: list[int] = []
    first_witness_reason = None

    for witness in witness_list:
        reason = witness.get("reason")
        if reason:
            reason_value = str(reason)
            reason_counts[reason_value] = reason_counts.get(reason_value, 0) + 1
            if first_witness_reason is None:
                first_witness_reason = reason_value

        source_kind = witness.get("source_kind")
        if source_kind is not None:
            source_value = str(source_kind)
            source_kind_counts[source_value] = (
                source_kind_counts.get(source_value, 0) + 1
            )

        branch = witness.get("branch")
        if branch is not None:
            branch_value = str(branch)
            branch_counts[branch_value] = branch_counts.get(branch_value, 0) + 1

        depth = _homfly_optional_int(
            witness.get("recursive_depth", witness.get("depth"))
        )
        if depth is not None:
            depths.append(depth)

        branch_depth = _homfly_optional_int(witness.get("branch_depth"))
        if branch_depth is not None:
            branch_depths.append(branch_depth)

        recursive_path = _homfly_witness_path(witness, "recursive_path", "path")
        if recursive_path:
            prefix = tuple(recursive_path[:2])
            recursive_path_prefix_counts[prefix] = (
                recursive_path_prefix_counts.get(prefix, 0) + 1
            )

        branch_path = _homfly_witness_path(witness, "branch_path")
        if branch_path:
            prefix = tuple(branch_path[:2])
            branch_path_prefix_counts[prefix] = (
                branch_path_prefix_counts.get(prefix, 0) + 1
            )

    return {
        "method": "homfly_frontier_witness_summary",
        "claim_scope": "capped_frontier_witness_diagnostics",
        "frontier_count": int(payload.get("frontier_count", 0) or 0),
        "witness_count": len(witness_list),
        "frontier_witness_limit": witness_limit,
        "witness_summary_truncated": bool(
            payload.get("frontier_witnesses_truncated", False)
        ),
        "reason_counts": _homfly_witness_count_records(
            reason_counts,
            "reason",
        ),
        "reason_count": len(reason_counts),
        "min_depth": min(depths) if depths else None,
        "max_depth": max(depths) if depths else None,
        "recursive_path_prefix_counts": _homfly_witness_path_prefix_records(
            recursive_path_prefix_counts
        ),
        "recursive_path_prefix_count": len(recursive_path_prefix_counts),
        "source_kind_counts": _homfly_witness_count_records(
            source_kind_counts,
            "source_kind",
        ),
        "source_kind_count": len(source_kind_counts),
        "branch_counts": _homfly_witness_count_records(
            branch_counts,
            "branch",
        ),
        "branch_count": len(branch_counts),
        "min_branch_depth": min(branch_depths) if branch_depths else None,
        "max_branch_depth": max(branch_depths) if branch_depths else None,
        "branch_path_prefix_counts": _homfly_witness_path_prefix_records(
            branch_path_prefix_counts
        ),
        "run_cap_frontier_pressure": _homfly_frontier_pressure_record(
            frontier_count=int(payload.get("frontier_count", 0) or 0),
            witness_count=len(witness_list),
            witness_reason_counts=reason_counts,
            frontier_reason_counts=payload.get("frontier_reason_counts"),
            first_witness_reason=first_witness_reason,
        ),
        "notes": [
            "computed only from capped frontier_witnesses; it does not scan omitted frontier entries or expand the HOMFLY coverage claim",
        ],
    }


def _homfly_reduction_contribution_witness(
    index: int,
    reduction_kind: str,
    reduction: object,
) -> dict:
    witness = {
        "index": index,
        "reduction_kind": reduction_kind,
    }
    if not isinstance(reduction, dict):
        witness["contribution"] = None
        witness["reason"] = "recorded reduction is not a mapping"
        return witness

    for field in (
        "node",
        "depth",
        "move",
        "terminal_kind",
        "component_count",
        "coefficient",
        "polynomial",
        "contribution",
        "has_orientation",
    ):
        if field in reduction:
            witness[field] = reduction[field]
    return witness


def _homfly_reduction_kind_count_records(
    reductions: Iterable[tuple[str, object]],
) -> list[dict]:
    counts: dict[str, int] = {}
    for reduction_kind, _reduction in reductions:
        counts[reduction_kind] = counts.get(reduction_kind, 0) + 1
    return [
        {"reduction_kind": reduction_kind, "reduction_count": counts[reduction_kind]}
        for reduction_kind in sorted(counts)
    ]


def _homfly_reduction_kind_sum_records(
    contribution_sums: dict[str, MultivariateLaurentPolynomial],
) -> list[dict]:
    return [
        {
            "reduction_kind": reduction_kind,
            "contribution_sum": contribution_sums[reduction_kind].format(),
        }
        for reduction_kind in sorted(contribution_sums)
    ]


def _homfly_count_records_from_mappings(
    rows: Iterable[object],
    *,
    key_field: str,
    count_field: str,
) -> list[dict]:
    counts: dict[str, int] = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        key = row.get(key_field)
        if key in (None, ""):
            continue
        key_text = str(key)
        counts[key_text] = counts.get(key_text, 0) + 1
    return [
        {key_field: key, count_field: counts[key]}
        for key in sorted(counts)
    ]


def _homfly_reduction_contribution_witness_summary_record(
    payload: dict,
) -> dict:
    witness_list = (
        list(payload.get("reduction_contribution_witnesses", []) or [])
        if isinstance(payload.get("reduction_contribution_witnesses", []), list)
        else []
    )
    witness_count = int(payload.get("reduction_contribution_witness_count", 0) or 0)
    witness_limit = int(
        payload.get(
            "reduction_contribution_witness_limit",
            _HOMFLY_REDUCTION_CONTRIBUTION_WITNESS_LIMIT,
        )
        or _HOMFLY_REDUCTION_CONTRIBUTION_WITNESS_LIMIT
    )
    contribution_count = int(payload.get("reduction_contribution_count", 0) or 0)
    parsed_count = int(payload.get("parsed_reduction_contribution_count", 0) or 0)
    unparsed_count = int(
        payload.get("unparsed_reduction_contribution_count", 0) or 0
    )
    first_witness = payload.get("first_reduction_contribution_witness")
    first_kind = (
        str(first_witness.get("reduction_kind"))
        if isinstance(first_witness, dict)
        and first_witness.get("reduction_kind") not in (None, "")
        else None
    )
    first_index = (
        int(first_witness.get("index"))
        if isinstance(first_witness, dict)
        and isinstance(first_witness.get("index"), int)
        and not isinstance(first_witness.get("index"), bool)
        else None
    )
    return {
        "method": "homfly_reduction_contribution_witness_summary",
        "reduction_contribution_count": contribution_count,
        "parsed_reduction_contribution_count": parsed_count,
        "unparsed_reduction_contribution_count": unparsed_count,
        "reduction_contribution_witness_count": witness_count,
        "reduction_contribution_witness_list_count": len(witness_list),
        "reduction_contribution_witness_limit": witness_limit,
        "reduction_contribution_witnesses_truncated": bool(
            payload.get("reduction_contribution_witnesses_truncated", False)
        ),
        "visible_reduction_kind_counts": _homfly_count_records_from_mappings(
            witness_list,
            key_field="reduction_kind",
            count_field="visible_witness_count",
        ),
        "visible_reduction_kind_count": len(
            {
                str(row.get("reduction_kind"))
                for row in witness_list
                if isinstance(row, dict)
                and row.get("reduction_kind") not in (None, "")
            }
        ),
        "first_reduction_kind": first_kind,
        "first_reduction_index": first_index,
        "notes": [
            "computed only from recorded capped terminal/memoized reduction witnesses; it does not scan omitted reductions or expand the HOMFLY coverage claim",
        ],
    }


def _homfly_reduction_contribution_witness_consistency_record(
    payload: dict,
    *,
    context: dict | None = None,
) -> dict:
    witness_list = (
        list(payload.get("reduction_contribution_witnesses", []) or [])
        if isinstance(payload.get("reduction_contribution_witnesses", []), list)
        else []
    )
    witness_count = int(payload.get("reduction_contribution_witness_count", 0) or 0)
    witness_limit = int(
        payload.get(
            "reduction_contribution_witness_limit",
            _HOMFLY_REDUCTION_CONTRIBUTION_WITNESS_LIMIT,
        )
        or _HOMFLY_REDUCTION_CONTRIBUTION_WITNESS_LIMIT
    )
    contribution_count = int(payload.get("reduction_contribution_count", 0) or 0)
    parsed_count = int(payload.get("parsed_reduction_contribution_count", 0) or 0)
    unparsed_count = int(
        payload.get("unparsed_reduction_contribution_count", 0) or 0
    )
    first_witness = payload.get("first_reduction_contribution_witness")
    expected_first_witness = witness_list[0] if witness_list else None
    witnesses_truncated = bool(
        payload.get("reduction_contribution_witnesses_truncated", False)
    )
    expected_truncated_from_count = contribution_count > witness_count
    expected_truncated_from_list = contribution_count > len(witness_list)
    expected_visible_kind_counts = _homfly_count_records_from_mappings(
        witness_list,
        key_field="reduction_kind",
        count_field="visible_witness_count",
    )
    summary = payload.get("reduction_contribution_witness_summary")
    if not isinstance(summary, dict):
        summary = None
    summary_visible_kind_counts = (
        list(summary.get("visible_reduction_kind_counts", []) or [])
        if isinstance(summary, dict)
        and isinstance(summary.get("visible_reduction_kind_counts", []), list)
        else []
    )
    kind_count_total = sum(
        int(row.get("reduction_count", 0) or 0)
        for row in payload.get("reduction_kind_counts", []) or []
        if isinstance(row, dict)
    )
    kind_sum_kinds = {
        str(row.get("reduction_kind"))
        for row in payload.get("reduction_kind_contribution_sums", []) or []
        if isinstance(row, dict) and row.get("reduction_kind") not in (None, "")
    }
    parsed_kind_count_kinds = {
        str(row.get("reduction_kind"))
        for row in payload.get("reduction_kind_counts", []) or []
        if isinstance(row, dict)
        and int(row.get("reduction_count", 0) or 0) > 0
    }
    if unparsed_count:
        kind_sums_subset_of_counts = kind_sum_kinds.issubset(parsed_kind_count_kinds)
    else:
        kind_sums_subset_of_counts = kind_sum_kinds == parsed_kind_count_kinds
    context_fields = {
        key: value
        for key, value in (context or {}).items()
        if value is not None
    }
    witness_count_matches_list_count = witness_count == len(witness_list)
    witness_count_within_limit = witness_count <= witness_limit
    witness_list_count_within_limit = len(witness_list) <= witness_limit
    first_witness_matches_list = first_witness == expected_first_witness
    truncated_matches_witness_count = (
        witnesses_truncated == expected_truncated_from_count
    )
    truncated_matches_witness_list = (
        witnesses_truncated == expected_truncated_from_list
    )
    parsed_unparsed_matches_total = parsed_count + unparsed_count == contribution_count
    kind_counts_match_total = kind_count_total == contribution_count
    summary_matches_witness_shape = summary is None or (
        int(summary.get("reduction_contribution_witness_count", -1) or 0)
        == witness_count
        and int(summary.get("reduction_contribution_witness_list_count", -1) or 0)
        == len(witness_list)
        and int(summary.get("reduction_contribution_witness_limit", -1) or 0)
        == witness_limit
        and bool(summary.get("reduction_contribution_witnesses_truncated", False))
        == witnesses_truncated
        and summary_visible_kind_counts == expected_visible_kind_counts
    )
    mismatch_witnesses = []

    def add_mismatch(kind: str, field: str, report_value, source_value) -> None:
        witness = _homfly_consistency_mismatch_witness(
            kind=kind,
            field=field,
            report_value=report_value,
            source_value=source_value,
        )
        witness.update(context_fields)
        mismatch_witnesses.append(witness)

    if not witness_count_matches_list_count:
        add_mismatch(
            "reduction_contribution_witness_count",
            "reduction_contribution_witness_count",
            witness_count,
            len(witness_list),
        )
    if not witness_count_within_limit:
        add_mismatch(
            "reduction_contribution_witness_limit",
            "reduction_contribution_witness_count",
            witness_count,
            {"reduction_contribution_witness_limit": witness_limit},
        )
    if not witness_list_count_within_limit:
        add_mismatch(
            "reduction_contribution_witness_limit",
            "reduction_contribution_witnesses",
            len(witness_list),
            {"reduction_contribution_witness_limit": witness_limit},
        )
    if not first_witness_matches_list:
        add_mismatch(
            "first_reduction_contribution_witness",
            "first_reduction_contribution_witness",
            first_witness,
            expected_first_witness,
        )
    if not truncated_matches_witness_count:
        add_mismatch(
            "reduction_contribution_witnesses_truncated",
            "reduction_contribution_witnesses_truncated",
            witnesses_truncated,
            expected_truncated_from_count,
        )
    if not truncated_matches_witness_list:
        add_mismatch(
            "reduction_contribution_witnesses_truncated",
            "reduction_contribution_witnesses_truncated",
            witnesses_truncated,
            expected_truncated_from_list,
        )
    if not parsed_unparsed_matches_total:
        add_mismatch(
            "reduction_contribution_parse_counts",
            "parsed_reduction_contribution_count",
            {"parsed": parsed_count, "unparsed": unparsed_count},
            contribution_count,
        )
    if not kind_counts_match_total:
        add_mismatch(
            "reduction_kind_counts",
            "reduction_kind_counts",
            kind_count_total,
            contribution_count,
        )
    if not kind_sums_subset_of_counts:
        add_mismatch(
            "reduction_kind_contribution_sums",
            "reduction_kind_contribution_sums",
            sorted(kind_sum_kinds),
            sorted(parsed_kind_count_kinds),
        )
    if not summary_matches_witness_shape:
        add_mismatch(
            "reduction_contribution_witness_summary",
            "reduction_contribution_witness_summary",
            summary,
            {
                "reduction_contribution_witness_count": witness_count,
                "reduction_contribution_witness_list_count": len(witness_list),
                "reduction_contribution_witness_limit": witness_limit,
                "reduction_contribution_witnesses_truncated": witnesses_truncated,
                "visible_reduction_kind_counts": expected_visible_kind_counts,
            },
        )

    matched = (
        witness_count_matches_list_count
        and witness_count_within_limit
        and witness_list_count_within_limit
        and first_witness_matches_list
        and truncated_matches_witness_count
        and truncated_matches_witness_list
        and parsed_unparsed_matches_total
        and kind_counts_match_total
        and kind_sums_subset_of_counts
        and summary_matches_witness_shape
    )
    return {
        "method": "homfly_reduction_contribution_witness_consistency",
        "matched": matched,
        "reduction_contribution_count": contribution_count,
        "parsed_reduction_contribution_count": parsed_count,
        "unparsed_reduction_contribution_count": unparsed_count,
        "reduction_contribution_witness_count": witness_count,
        "reduction_contribution_witness_list_count": len(witness_list),
        "reduction_contribution_witness_limit": witness_limit,
        "reduction_contribution_witnesses_truncated": witnesses_truncated,
        "expected_first_reduction_contribution_witness": expected_first_witness,
        "expected_reduction_contribution_witnesses_truncated_from_count": (
            expected_truncated_from_count
        ),
        "expected_reduction_contribution_witnesses_truncated_from_list": (
            expected_truncated_from_list
        ),
        "witness_count_matches_list_count": witness_count_matches_list_count,
        "witness_count_within_limit": witness_count_within_limit,
        "witness_list_count_within_limit": witness_list_count_within_limit,
        "first_reduction_contribution_witness_matches_list": (
            first_witness_matches_list
        ),
        "truncated_matches_witness_count": truncated_matches_witness_count,
        "truncated_matches_witness_list": truncated_matches_witness_list,
        "parsed_unparsed_matches_total": parsed_unparsed_matches_total,
        "reduction_kind_counts_match_total": kind_counts_match_total,
        "reduction_kind_contribution_sums_match_kind_counts": (
            kind_sums_subset_of_counts
        ),
        "summary_matches_witness_shape": summary_matches_witness_shape,
        "mismatch_count": len(mismatch_witnesses),
        "first_mismatch": mismatch_witnesses[0] if mismatch_witnesses else None,
        "mismatch_witnesses": mismatch_witnesses[:8],
        "notes": [
            "checks bounded terminal/memoized reduction witness count/list/first/truncation and kind-summary fields without expanding the HOMFLY coverage claim",
        ],
    }

def homfly_terminal_reduction_audit(result: dict | None) -> dict:
    """Audit whether recorded HOMFLY reductions sum to the result."""

    variables = ("a", "z")
    base = {
        "method": "homfly_terminal_reduction_audit",
        "claim_scope": "exact_sum_of_recorded_terminal_and_memoized_reduction_contributions",
        "evaluation_method": None,
        "homfly_polynomial": None,
        "terminal_contribution_sum": None,
        "terminal_reduction_count": 0,
        "memoized_reduction_count": 0,
        "reduction_contribution_count": 0,
        "parsed_reduction_contribution_count": 0,
        "unparsed_reduction_contribution_count": 0,
        "reduction_kind_counts": [],
        "reduction_kind_contribution_sums": [],
        "reduction_contribution_witness_limit": (
            _HOMFLY_REDUCTION_CONTRIBUTION_WITNESS_LIMIT
        ),
        "reduction_contribution_witness_count": 0,
        "reduction_contribution_witnesses_truncated": False,
        "reduction_contribution_witnesses": [],
        "first_reduction_contribution_witness": None,
        "failed_terminal_reduction_count": 0,
        "failed_terminal_reductions": [],
        "cache_hits": 0,
        "frontier_count": 0,
        "truncated": False,
        "matched_result": False,
        "skipped": True,
        "notes": [],
    }
    base["reduction_contribution_witness_summary"] = (
        _homfly_reduction_contribution_witness_summary_record(base)
    )
    base["reduction_contribution_witness_consistency"] = (
        _homfly_reduction_contribution_witness_consistency_record(base)
    )

    if result is None:
        return {**base, "notes": ["no HOMFLY result supplied"]}

    recursive = result.get("recursive_evaluation")
    if not isinstance(recursive, dict):
        return {
            **base,
            "evaluation_method": result.get("method"),
            "homfly_polynomial": result.get("homfly_polynomial"),
            "notes": [
                "result does not include recursive reductions to audit",
            ],
        }

    terminal_reductions = list(recursive.get("terminal_reductions", []))
    memoized_reductions = list(recursive.get("memoized_reductions", []))
    frontier_count = int(
        recursive.get("frontier_count", len(recursive.get("frontier", []))) or 0
    )
    truncated = bool(recursive.get("truncated", False))
    cache_hits = int(recursive.get("cache_hits", 0) or 0)
    final_text = recursive.get("homfly_polynomial") or result.get("homfly_polynomial")
    reductions = [
        ("terminal", reduction)
        for reduction in terminal_reductions
    ] + [
        ("memoized_subtree", reduction)
        for reduction in memoized_reductions
    ]
    reduction_witnesses = [
        _homfly_reduction_contribution_witness(index, reduction_kind, reduction)
        for index, (reduction_kind, reduction) in enumerate(
            reductions[:_HOMFLY_REDUCTION_CONTRIBUTION_WITNESS_LIMIT]
        )
    ]
    reduction_kind_counts = _homfly_reduction_kind_count_records(reductions)

    total = MultivariateLaurentPolynomial.constant(0, variables=variables)
    contribution_sums: dict[str, MultivariateLaurentPolynomial] = {}
    failures = []
    for index, (reduction_kind, reduction) in enumerate(reductions):
        contribution = reduction.get("contribution") if isinstance(reduction, dict) else None
        if contribution is None:
            failures.append(
                {
                    "index": index,
                    "reduction_kind": reduction_kind,
                    "contribution": None,
                    "reason": "recorded reduction has no contribution field",
                }
            )
            continue
        try:
            parsed = parse_multivariate_laurent_polynomial(
                str(contribution),
                variables=variables,
            )
        except ValueError as exc:
            failures.append(
                {
                    "index": index,
                    "reduction_kind": reduction_kind,
                    "contribution": str(contribution),
                    "reason": str(exc),
                }
            )
            continue
        total = total + parsed
        if reduction_kind not in contribution_sums:
            contribution_sums[reduction_kind] = MultivariateLaurentPolynomial.constant(
                0,
                variables=variables,
            )
        contribution_sums[reduction_kind] = contribution_sums[reduction_kind] + parsed

    reduction_fields = {
        "terminal_reduction_count": len(terminal_reductions),
        "memoized_reduction_count": len(memoized_reductions),
        "reduction_contribution_count": len(reductions),
        "parsed_reduction_contribution_count": len(reductions) - len(failures),
        "unparsed_reduction_contribution_count": len(failures),
        "reduction_kind_counts": reduction_kind_counts,
        "reduction_kind_contribution_sums": _homfly_reduction_kind_sum_records(
            contribution_sums
        ),
        "reduction_contribution_witness_limit": (
            _HOMFLY_REDUCTION_CONTRIBUTION_WITNESS_LIMIT
        ),
        "reduction_contribution_witness_count": len(reduction_witnesses),
        "reduction_contribution_witnesses_truncated": (
            len(reductions) > len(reduction_witnesses)
        ),
        "reduction_contribution_witnesses": reduction_witnesses,
        "first_reduction_contribution_witness": (
            reduction_witnesses[0] if reduction_witnesses else None
        ),
        "failed_terminal_reduction_count": len(failures),
        "failed_terminal_reductions": failures,
        "cache_hits": cache_hits,
        "frontier_count": frontier_count,
        "truncated": truncated,
    }
    reduction_fields["reduction_contribution_witness_summary"] = (
        _homfly_reduction_contribution_witness_summary_record(reduction_fields)
    )
    reduction_fields["reduction_contribution_witness_consistency"] = (
        _homfly_reduction_contribution_witness_consistency_record(reduction_fields)
    )
    recorded_sum = total.format() if reductions else None

    if final_text is None:
        return {
            **base,
            "evaluation_method": result.get("method"),
            "terminal_contribution_sum": recorded_sum,
            **reduction_fields,
            "notes": [
                "HOMFLY result is incomplete; recorded reduction sum is partial and cannot certify a final polynomial",
            ],
        }
    if cache_hits and not memoized_reductions:
        return {
            **base,
            "evaluation_method": result.get("method"),
            "homfly_polynomial": str(final_text),
            "terminal_contribution_sum": recorded_sum,
            **reduction_fields,
            "notes": [
                "recursive evaluation used memoized subtrees but did not record memoized contributions",
            ],
        }

    try:
        final_polynomial = parse_multivariate_laurent_polynomial(
            str(final_text),
            variables=variables,
        )
    except ValueError as exc:
        return {
            **base,
            "evaluation_method": result.get("method"),
            "homfly_polynomial": str(final_text),
            "terminal_contribution_sum": recorded_sum,
            **reduction_fields,
            "skipped": False,
            "notes": [f"final HOMFLY polynomial could not be parsed: {exc}"],
        }

    matched = not failures and total == final_polynomial
    notes = [] if matched else [
        "recorded terminal and memoized reduction contributions do not sum to the final HOMFLY polynomial",
    ]
    if frontier_count or truncated:
        notes.append(
            "recursive evaluation still has frontier/truncation metadata; audit is limited to recorded reductions"
        )

    return {
        **base,
        "evaluation_method": result.get("method"),
        "homfly_polynomial": final_polynomial.format(),
        "terminal_contribution_sum": total.format(),
        **reduction_fields,
        "matched_result": matched,
        "skipped": False,
        "notes": notes,
    }

def _homfly_completion_blockers(
    *,
    full_table_normalization_certified: bool,
    arbitrary_diagram_coverage_certified: bool,
) -> list[str]:
    blockers = []
    if not full_table_normalization_certified:
        blockers.append("full_table_normalization_not_certified")
    if not arbitrary_diagram_coverage_certified:
        blockers.append("arbitrary_diagram_coverage_not_certified")
    return blockers


def _homfly_completion_blocker_details(
    *,
    full_table_normalization_certified: bool,
    arbitrary_diagram_coverage_certified: bool,
    arbitrary_diagram_completion_gate: dict | None = None,
) -> list[dict]:
    details = []
    if not full_table_normalization_certified:
        details.append(
            {
                "code": "full_table_normalization_not_certified",
                "severity": "blocking",
                "scope": "homfly_completion",
                "reason": (
                    "external HOMFLY table normalization has not been certified"
                ),
                "cap": {"full_table_normalization_certified": False},
            }
        )
    if not arbitrary_diagram_coverage_certified:
        detail = {
            "code": "arbitrary_diagram_coverage_not_certified",
            "severity": "blocking",
            "scope": "homfly_completion",
            "reason": (
                "generated/input-scoped evidence does not certify arbitrary signed-PD coverage"
            ),
            "cap": {"arbitrary_diagram_coverage_certified": False},
        }
        if arbitrary_diagram_completion_gate is not None:
            detail["witness"] = arbitrary_diagram_completion_gate
            provenance = arbitrary_diagram_completion_gate.get(
                "completion_blocker_provenance"
            )
            if isinstance(provenance, dict):
                detail["provenance"] = provenance
        details.append(detail)
    return details


def _homfly_blocker_code_counts(codes: Iterable[str]) -> list[dict]:
    counts: dict[str, int] = {}
    for code in codes:
        value = str(code)
        counts[value] = counts.get(value, 0) + 1
    return [
        {"code": code, "blocker_count": counts[code]}
        for code in sorted(counts)
    ]


def _homfly_blocker_detail_code_counts(details: Iterable[dict]) -> list[dict]:
    counts: dict[str, int] = {}
    for detail in details:
        if not isinstance(detail, dict) or detail.get("code") is None:
            continue
        code = str(detail["code"])
        counts[code] = counts.get(code, 0) + 1
    return [
        {"code": code, "detail_count": counts[code]}
        for code in sorted(counts)
    ]


def _homfly_scale_blocker_detail_code_counts(
    rows: Iterable[dict],
    factor: int,
) -> list[dict]:
    return [
        {
            "code": str(row.get("code")),
            "detail_count": int(row.get("detail_count", 0) or 0) * int(factor),
        }
        for row in rows
        if isinstance(row, dict) and row.get("code") is not None
    ]


def _homfly_scale_blocker_code_counts(
    rows: Iterable[dict],
    factor: int,
) -> list[dict]:
    return [
        {
            "code": str(row.get("code")),
            "blocker_count": int(row.get("blocker_count", 0) or 0) * int(factor),
        }
        for row in rows
        if isinstance(row, dict) and row.get("code") is not None
    ]


def _homfly_code_count_map(rows: Iterable[dict], count_key: str) -> dict[str, int]:
    counts: dict[str, int] = {}
    for row in rows:
        if not isinstance(row, dict) or row.get("code") is None:
            continue
        code = str(row["code"])
        counts[code] = counts.get(code, 0) + int(row.get(count_key, 0) or 0)
    return counts


def _homfly_normalized_code_count_records(
    rows: Iterable[dict],
    count_key: str,
) -> list[dict]:
    counts = _homfly_code_count_map(rows, count_key)
    return [
        {"code": code, count_key: counts[code]}
        for code in sorted(counts)
    ]


def _homfly_gate_pressure_reason_map(
    rows: Iterable[dict],
    *,
    reason_key: str,
    count_key: str,
) -> dict[str, int]:
    counts: dict[str, int] = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        reason = row.get(reason_key)
        count = row.get(count_key)
        if reason is None or count is None:
            continue
        reason_value = str(reason)
        counts[reason_value] = counts.get(reason_value, 0) + int(count or 0)
    return counts


def _homfly_gate_pressure_consistency_record(gate: dict) -> dict:
    frontier_count = int(gate.get("frontier_count", 0) or 0)
    visible_witness_count = int(gate.get("frontier_witness_count", 0) or 0)
    missing_witness_count = max(frontier_count - visible_witness_count, 0)
    frontier_reason_counts = [
        row
        for row in gate.get("frontier_reason_counts", []) or []
        if isinstance(row, dict)
    ]
    frontier_reasons = sorted(
        {str(reason) for reason in gate.get("frontier_reasons", []) or []}
    )
    summary = (
        gate.get("frontier_witness_summary")
        if isinstance(gate.get("frontier_witness_summary"), dict)
        else {}
    )
    pressure = (
        summary.get("run_cap_frontier_pressure")
        if isinstance(summary.get("run_cap_frontier_pressure"), dict)
        else {}
    )
    pressure_reason_counts = [
        row
        for row in pressure.get("reason_counts", []) or []
        if isinstance(row, dict)
    ]
    frontier_reason_map = _homfly_gate_pressure_reason_map(
        frontier_reason_counts,
        reason_key="frontier_reason",
        count_key="frontier_count",
    )
    pressure_frontier_reason_map = _homfly_gate_pressure_reason_map(
        pressure_reason_counts,
        reason_key="reason",
        count_key="frontier_count",
    )
    pressure_witness_reason_map = _homfly_gate_pressure_reason_map(
        pressure_reason_counts,
        reason_key="reason",
        count_key="witness_count",
    )
    summary_witness_reason_map = _homfly_gate_pressure_reason_map(
        summary.get("reason_counts", []) or [],
        reason_key="reason",
        count_key="witness_count",
    )
    pressure_reason_names = {
        str(row["reason"])
        for row in pressure_reason_counts
        if row.get("reason") is not None
    }
    blocker_codes = {
        str(code) for code in gate.get("certification_blockers", []) or []
    }
    terminal_audit_applicable = gate.get("terminal_contribution_audit_applicable")
    terminal_audit_skipped = gate.get("terminal_contribution_audit_skipped")
    terminal_contribution_matches_result = gate.get(
        "terminal_contribution_matches_result"
    )
    terminal_audit_applicability_matched = (
        (
            terminal_audit_applicable is None
            and terminal_audit_skipped is None
        )
        or (
            terminal_audit_applicable is True
            and terminal_audit_skipped is False
        )
        or (
            terminal_audit_applicable is False
            and terminal_audit_skipped is True
        )
    )
    terminal_mismatch_blocker_expected = (
        terminal_audit_applicable is True
        and terminal_contribution_matches_result is False
    )
    terminal_mismatch_blocker_present = (
        "terminal_contribution_mismatch" in blocker_codes
    )
    terminal_mismatch_blocker_matched = (
        terminal_mismatch_blocker_present
        is terminal_mismatch_blocker_expected
    )
    terminal_audit_consistency_matched = (
        terminal_audit_applicability_matched
        and terminal_mismatch_blocker_matched
    )
    blocker_count_sum = sum(
        int(row.get("blocker_count", 0) or 0)
        for row in gate.get("certification_blocker_code_counts", []) or []
        if isinstance(row, dict)
    )
    blocker_detail_count_sum = sum(
        int(row.get("detail_count", 0) or 0)
        for row in gate.get("certification_blocker_detail_code_counts", []) or []
        if isinstance(row, dict)
    )
    summary_counts_matched = (
        summary.get("frontier_count") == frontier_count
        and summary.get("witness_count") == visible_witness_count
        and summary.get("frontier_witness_limit")
        == gate.get("frontier_witness_limit")
        and summary.get("witness_summary_truncated")
        is bool(gate.get("frontier_witnesses_truncated", False))
    )
    pressure_counts_matched = (
        pressure.get("frontier_count") == frontier_count
        and pressure.get("witness_count") == visible_witness_count
        and pressure.get("unwitnessed_frontier_count") == missing_witness_count
    )
    pressure_flags_matched = (
        pressure.get("all_frontier_witnessed")
        is (missing_witness_count == 0)
        and pressure.get("frontier_reason_counts_available")
        is (frontier_count == 0 or bool(frontier_reason_map))
    )
    reason_counts_matched = (
        pressure_frontier_reason_map == frontier_reason_map
        and pressure_witness_reason_map == summary_witness_reason_map
    )
    frontier_blocker_reasons = sorted(
        set(frontier_reasons)
        | pressure_reason_names
        | {
            str(reason)
            for reason in (
                pressure.get("first_witness_reason"),
                pressure.get("first_unwitnessed_reason"),
            )
            if reason is not None
        }
    )
    frontier_blocker_matched = (
        frontier_count == 0 or "frontier_not_exhausted" in blocker_codes
    )
    frontier_blocker_reason_matched = (
        frontier_count == 0
        or (frontier_blocker_matched and bool(frontier_blocker_reasons))
    )
    truncation_blocker_matched = (
        not bool(gate.get("truncated", False))
        or "truncated_recursive_evaluation" in blocker_codes
    )
    blocker_counts_matched = blocker_count_sum == int(
        gate.get("certification_blocker_count", 0) or 0
    )
    blocker_detail_counts_matched = blocker_detail_count_sum == int(
        gate.get("certification_blocker_detail_count", 0) or 0
    )
    evidence_consistency_values = [
        gate.get("source_summary_consistency_matched"),
        gate.get("case_evidence_consistency_matched"),
        gate.get("blocker_detail_code_count_consistency_matched"),
    ]
    evidence_consistency_matched = all(
        value is not False for value in evidence_consistency_values
    )
    coverage_certified = bool(
        gate.get("arbitrary_diagram_coverage_certified", False)
    )
    completion_blocked = bool(gate.get("blocked", False))
    non_claim_matched = completion_blocked and not coverage_certified
    completion_blocker_provenance_matched = (
        non_claim_matched
        and pressure_counts_matched
        and pressure_flags_matched
        and reason_counts_matched
        and blocker_counts_matched
        and blocker_detail_counts_matched
        and evidence_consistency_matched
        and terminal_audit_consistency_matched
    )
    matched = all(
        (
            summary_counts_matched,
            pressure_counts_matched,
            pressure_flags_matched,
            reason_counts_matched,
            frontier_blocker_matched,
            frontier_blocker_reason_matched,
            truncation_blocker_matched,
            blocker_counts_matched,
            blocker_detail_counts_matched,
            evidence_consistency_matched,
            terminal_audit_consistency_matched,
            non_claim_matched,
            completion_blocker_provenance_matched,
        )
    )

    return {
        "method": "homfly_gate_pressure_consistency",
        "matched": matched,
        "frontier_count": frontier_count,
        "visible_witness_count": visible_witness_count,
        "missing_witness_count": missing_witness_count,
        "summary_counts_matched": summary_counts_matched,
        "pressure_counts_matched": pressure_counts_matched,
        "pressure_flags_matched": pressure_flags_matched,
        "reason_counts_matched": reason_counts_matched,
        "frontier_blocker_matched": frontier_blocker_matched,
        "frontier_blocker_reason_matched": frontier_blocker_reason_matched,
        "frontier_blocker_reasons": frontier_blocker_reasons,
        "truncation_blocker_matched": truncation_blocker_matched,
        "blocker_counts_matched": blocker_counts_matched,
        "blocker_detail_counts_matched": blocker_detail_counts_matched,
        "evidence_consistency_matched": evidence_consistency_matched,
        "terminal_contribution_audit_applicable": terminal_audit_applicable,
        "terminal_contribution_audit_skipped": terminal_audit_skipped,
        "terminal_contribution_matches_result": (
            terminal_contribution_matches_result
        ),
        "terminal_audit_applicability_matched": (
            terminal_audit_applicability_matched
        ),
        "terminal_mismatch_blocker_expected": (
            terminal_mismatch_blocker_expected
        ),
        "terminal_mismatch_blocker_present": terminal_mismatch_blocker_present,
        "terminal_mismatch_blocker_matched": terminal_mismatch_blocker_matched,
        "terminal_audit_consistency_matched": (
            terminal_audit_consistency_matched
        ),
        "completion_blocked": completion_blocked,
        "arbitrary_diagram_coverage_certified": coverage_certified,
        "expected_completion_blocker": "arbitrary_diagram_coverage_not_certified",
        "non_claim_matched": non_claim_matched,
        "completion_blocker_provenance_matched": (
            completion_blocker_provenance_matched
        ),
    }


def _homfly_completion_blocker_provenance_record(gate: dict) -> dict:
    completion_blocker_code = "arbitrary_diagram_coverage_not_certified"
    pressure_consistency = (
        gate.get("gate_pressure_consistency")
        if isinstance(gate.get("gate_pressure_consistency"), dict)
        else {}
    )
    witness_consistency = (
        gate.get("frontier_witness_consistency")
        if isinstance(gate.get("frontier_witness_consistency"), dict)
        else {}
    )
    summary = (
        gate.get("frontier_witness_summary")
        if isinstance(gate.get("frontier_witness_summary"), dict)
        else {}
    )
    pressure = (
        summary.get("run_cap_frontier_pressure")
        if isinstance(summary.get("run_cap_frontier_pressure"), dict)
        else {}
    )
    frontier_count = int(gate.get("frontier_count", 0) or 0)
    visible_witness_count = int(gate.get("frontier_witness_count", 0) or 0)
    missing_witness_count = max(frontier_count - visible_witness_count, 0)
    coverage_certified = bool(
        gate.get("arbitrary_diagram_coverage_certified", False)
    )
    completion_blocked = bool(gate.get("blocked", False))
    non_claim_matched = completion_blocked and not coverage_certified
    pressure_counts_matched = (
        pressure.get("frontier_count") == frontier_count
        and pressure.get("witness_count") == visible_witness_count
        and pressure.get("unwitnessed_frontier_count") == missing_witness_count
    )
    certification_blocker_count_matched = (
        pressure_consistency.get("blocker_counts_matched") is True
    )
    certification_blocker_detail_count_matched = (
        pressure_consistency.get("blocker_detail_counts_matched") is True
    )
    terminal_audit_consistency_matched = (
        pressure_consistency.get("terminal_audit_consistency_matched") is True
    )
    terminal_mismatch_blocker_matched = (
        pressure_consistency.get("terminal_mismatch_blocker_matched") is True
    )
    gate_pressure_consistency_matched = (
        pressure_consistency.get("matched") is True
        and pressure_consistency.get("expected_completion_blocker")
        == completion_blocker_code
    )
    frontier_witness_consistency_matched = (
        witness_consistency.get("matched") is True
    )
    matched = all(
        (
            non_claim_matched,
            pressure_counts_matched,
            gate_pressure_consistency_matched,
            frontier_witness_consistency_matched,
            certification_blocker_count_matched,
            certification_blocker_detail_count_matched,
            terminal_audit_consistency_matched,
            terminal_mismatch_blocker_matched,
        )
    )

    return {
        "method": "homfly_completion_blocker_provenance",
        "claim_scope": "bounded_non_claim_completion_blocker_provenance",
        "matched": matched,
        "completion_blocker_code": completion_blocker_code,
        "completion_blocker_detail": {
            "code": completion_blocker_code,
            "severity": "blocking",
            "scope": "homfly_completion",
            "expected_witness_field": "arbitrary_diagram_completion_gate",
            "expected_provenance_field": "completion_blocker_provenance",
        },
        "completion_blocked": completion_blocked,
        "arbitrary_diagram_coverage_certified": coverage_certified,
        "non_claim_matched": non_claim_matched,
        "gate_pressure_consistency_matched": gate_pressure_consistency_matched,
        "frontier_pressure_counts_matched": pressure_counts_matched,
        "frontier_witness_consistency_matched": (
            frontier_witness_consistency_matched
        ),
        "certification_blocker_count_matched": (
            certification_blocker_count_matched
        ),
        "certification_blocker_detail_count_matched": (
            certification_blocker_detail_count_matched
        ),
        "terminal_audit_consistency_matched": (
            terminal_audit_consistency_matched
        ),
        "terminal_mismatch_blocker_matched": terminal_mismatch_blocker_matched,
        "frontier_pressure": {
            "frontier_count": frontier_count,
            "visible_witness_count": visible_witness_count,
            "missing_witness_count": missing_witness_count,
            "frontier_reasons": [
                str(reason) for reason in gate.get("frontier_reasons", []) or []
            ],
            "frontier_blocker_reasons": list(
                pressure_consistency.get("frontier_blocker_reasons", []) or []
            ),
            "first_witness_reason": pressure.get("first_witness_reason"),
            "first_unwitnessed_reason": pressure.get("first_unwitnessed_reason"),
            "all_frontier_witnessed": pressure.get("all_frontier_witnessed"),
            "reason_count": pressure.get("reason_count"),
        },
        "frontier_witness": {
            "frontier_witness_count": visible_witness_count,
            "frontier_witness_limit": int(
                gate.get(
                    "frontier_witness_limit",
                    _HOMFLY_FRONTIER_WITNESS_LIMIT,
                )
                or _HOMFLY_FRONTIER_WITNESS_LIMIT
            ),
            "frontier_witnesses_truncated": bool(
                gate.get("frontier_witnesses_truncated", False)
            ),
            "first_frontier_witness": gate.get("first_frontier_witness"),
        },
        "terminal_contribution_audit": {
            "terminal_contribution_audit_applicable": gate.get(
                "terminal_contribution_audit_applicable"
            ),
            "terminal_contribution_audit_skipped": gate.get(
                "terminal_contribution_audit_skipped"
            ),
            "terminal_contribution_matches_result": gate.get(
                "terminal_contribution_matches_result"
            ),
            "terminal_audit_applicability_matched": (
                pressure_consistency.get(
                    "terminal_audit_applicability_matched"
                )
            ),
            "terminal_mismatch_blocker_expected": (
                pressure_consistency.get("terminal_mismatch_blocker_expected")
            ),
            "terminal_mismatch_blocker_present": (
                pressure_consistency.get("terminal_mismatch_blocker_present")
            ),
            "terminal_mismatch_blocker_matched": (
                pressure_consistency.get("terminal_mismatch_blocker_matched")
            ),
        },
        "certification_blocker_codes": [
            str(code) for code in gate.get("certification_blockers", []) or []
        ],
        "certification_blocker_count": int(
            gate.get("certification_blocker_count", 0) or 0
        ),
        "certification_blocker_detail_count": int(
            gate.get("certification_blocker_detail_count", 0) or 0
        ),
        "source_fields": [
            "arbitrary_diagram_completion_gate.blocked",
            "arbitrary_diagram_completion_gate.arbitrary_diagram_coverage_certified",
            "arbitrary_diagram_completion_gate.gate_pressure_consistency",
            "arbitrary_diagram_completion_gate.frontier_witness_summary.run_cap_frontier_pressure",
            "arbitrary_diagram_completion_gate.frontier_witnesses",
            "arbitrary_diagram_completion_gate.terminal_contribution_audit_applicable",
            "arbitrary_diagram_completion_gate.terminal_contribution_matches_result",
            "arbitrary_diagram_completion_gate.certification_blockers",
        ],
        "notes": [
            "links the arbitrary-diagram completion blocker to bounded gate/frontier diagnostics without certifying arbitrary signed-PD coverage",
        ],
    }


def _homfly_arbitrary_diagram_completion_gate(
    *,
    evidence_scope: str,
    source_method: str | None,
    source_claim_scope: str | None,
    result_present: bool,
    frontier_exhausted: bool,
    frontier_count: int,
    frontier_case_count: int | None = None,
    frontier_reasons: Iterable[str] = (),
    frontier_reason_counts: Iterable[dict] | None = None,
    frontier_witnesses: Iterable[dict] | None = None,
    truncated: bool = False,
    truncated_case_count: int | None = None,
    terminal_contribution_matches_result: bool | None = None,
    terminal_contribution_audit_skipped: bool | None = None,
    certification_blockers: Iterable[str] = (),
    certification_blocker_detail_count: int = 0,
    certification_blocker_code_counts: Iterable[dict] | None = None,
    certification_blocker_detail_code_counts: Iterable[dict] | None = None,
    case_count: int | None = None,
    certified_case_count: int | None = None,
    uncertified_case_count: int | None = None,
    skipped_case_count: int | None = None,
    max_crossings: int | None = None,
    max_depth: int | None = None,
    max_nodes: int | None = None,
    branch_depth: int | None = None,
    source_notations: Iterable[str] | None = None,
    source_summary_consistency_matched: bool | None = None,
    case_evidence_consistency_matched: bool | None = None,
    blocker_detail_code_count_consistency_matched: bool | None = None,
) -> dict:
    blocker_codes = [str(code) for code in certification_blockers]
    frontier_reason_list = sorted({str(reason) for reason in frontier_reasons})
    frontier_reason_count_records = (
        [dict(record) for record in frontier_reason_counts if isinstance(record, dict)]
        if frontier_reason_counts is not None
        else []
    )
    frontier_witness_list = [
        dict(witness)
        for witness in (frontier_witnesses or [])
        if isinstance(witness, dict)
    ][:_HOMFLY_FRONTIER_WITNESS_LIMIT]
    frontier_witness_count = len(frontier_witness_list)
    frontier_witnesses_truncated = int(frontier_count or 0) > frontier_witness_count
    first_frontier_witness = (
        frontier_witness_list[0] if frontier_witness_list else None
    )
    frontier_witness_consistency = _homfly_frontier_witness_consistency_record(
        {
            "frontier_count": int(frontier_count or 0),
            "frontier_witness_count": frontier_witness_count,
            "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
            "frontier_witnesses_truncated": frontier_witnesses_truncated,
            "frontier_witnesses": frontier_witness_list,
            "first_frontier_witness": first_frontier_witness,
            "frontier_reason_counts": frontier_reason_count_records,
        }
    )
    frontier_witness_summary = _homfly_frontier_witness_summary_record(
        {
            "frontier_count": int(frontier_count or 0),
            "frontier_witness_count": frontier_witness_count,
            "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
            "frontier_witnesses_truncated": frontier_witnesses_truncated,
            "frontier_witnesses": frontier_witness_list,
            "first_frontier_witness": first_frontier_witness,
            "frontier_reason_counts": frontier_reason_count_records,
        }
    )
    convention_blockers = [
        code
        for code in blocker_codes
        if code == "role_order_or_convention_ambiguity_skipped"
        or "convention" in code
        or "role_order" in code
    ]
    run_caps = {
        "max_crossings": max_crossings,
        "max_depth": max_depth,
        "max_nodes": max_nodes,
        "branch_depth": branch_depth,
    }
    terminal_audit_applicable = (
        None
        if terminal_contribution_audit_skipped is None
        else not terminal_contribution_audit_skipped
    )
    gate = {
        "method": "homfly_arbitrary_signed_pd_completion_gate",
        "claim_scope": "arbitrary_signed_pd_homfly_completion_gate",
        "source_method": source_method,
        "source_claim_scope": source_claim_scope,
        "evidence_scope": evidence_scope,
        "result_present": result_present,
        "arbitrary_diagram_coverage_certified": False,
        "blocked": True,
        "frontier_exhausted": frontier_exhausted,
        "frontier_count": int(frontier_count or 0),
        "frontier_case_count": frontier_case_count,
        "frontier_reason_count": len(frontier_reason_list),
        "frontier_reasons": frontier_reason_list,
        "frontier_reason_counts": frontier_reason_count_records,
        "frontier_witness_count": frontier_witness_count,
        "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
        "frontier_witnesses_truncated": frontier_witnesses_truncated,
        "frontier_witnesses": frontier_witness_list,
        "first_frontier_witness": first_frontier_witness,
        "frontier_witness_consistency": frontier_witness_consistency,
        "frontier_witness_summary": frontier_witness_summary,
        "truncated": bool(truncated),
        "truncated_case_count": truncated_case_count,
        "terminal_contribution_audit_applicable": terminal_audit_applicable,
        "terminal_contribution_audit_skipped": terminal_contribution_audit_skipped,
        "terminal_contribution_matches_result": terminal_contribution_matches_result,
        "certification_blockers": blocker_codes,
        "certification_blocker_count": len(blocker_codes),
        "certification_blocker_detail_count": int(
            certification_blocker_detail_count or 0
        ),
        "certification_blocker_code_counts": (
            list(certification_blocker_code_counts)
            if certification_blocker_code_counts is not None
            else _homfly_blocker_code_counts(blocker_codes)
        ),
        "certification_blocker_detail_code_counts": (
            list(certification_blocker_detail_code_counts)
            if certification_blocker_detail_code_counts is not None
            else []
        ),
        "convention_blockers": convention_blockers,
        "convention_blocker_count": len(convention_blockers),
        "case_count": case_count,
        "certified_case_count": certified_case_count,
        "uncertified_case_count": uncertified_case_count,
        "skipped_case_count": skipped_case_count,
        "run_caps": run_caps,
        "source_notations": list(source_notations) if source_notations is not None else None,
        "source_summary_consistency_matched": source_summary_consistency_matched,
        "case_evidence_consistency_matched": case_evidence_consistency_matched,
        "blocker_detail_code_count_consistency_matched": (
            blocker_detail_code_count_consistency_matched
        ),
        "required_for_completion": [
            "external_table_normalization_certificate",
            "arbitrary_signed_pd_coverage_proof",
        ],
        "notes": [
            "bounded input or generated-case evidence is not an arbitrary signed-PD coverage proof",
        ],
    }
    gate["gate_pressure_consistency"] = _homfly_gate_pressure_consistency_record(
        gate
    )
    gate["completion_blocker_provenance"] = (
        _homfly_completion_blocker_provenance_record(gate)
    )
    return gate


def _homfly_result_notes_for_blockers(result: dict) -> str:
    notes = [str(note) for note in result.get("notes", [])]
    recursive = result.get("recursive_evaluation")
    if isinstance(recursive, dict):
        notes.extend(str(note) for note in recursive.get("notes", []))
    return " ".join([str(result.get("method", "")), *notes]).lower()


def _homfly_input_certification_blockers(
    *,
    result: dict | None,
    certified_for_input: bool,
    frontier_exhausted: bool,
    frontier_count: int,
    frontier_reasons: list[str],
    truncated: bool,
    skipped: bool,
    terminal_audit: dict,
) -> list[str]:
    if result is None:
        return ["no_homfly_result"]

    blockers = []
    if frontier_count > 0 or frontier_reasons:
        if not frontier_exhausted:
            blockers.append("frontier_not_exhausted")
    if truncated:
        blockers.append("truncated_recursive_evaluation")
    if not terminal_audit.get("skipped", True) and not terminal_audit.get(
        "matched_result",
        False,
    ):
        blockers.append("terminal_contribution_mismatch")

    note_text = _homfly_result_notes_for_blockers(result)
    role_or_convention_skipped = skipped and any(
        token in note_text
        for token in (
            "role-order",
            "role_order",
            "role order",
            "orientation",
            "convention ambiguity",
            "ambiguous convention",
        )
    )
    if role_or_convention_skipped:
        blockers.append("role_order_or_convention_ambiguity_skipped")
    elif skipped and not certified_for_input and not blockers:
        blockers.append("evaluation_skipped")
    elif not certified_for_input and not blockers:
        blockers.append("input_not_certified")

    return blockers


def _homfly_input_certification_blocker_details(
    *,
    blockers: list[str],
    result: dict | None,
    certified_for_input: bool,
    frontier_exhausted: bool,
    frontier_count: int,
    frontier_reasons: list[str],
    truncated: bool,
    skipped: bool,
    terminal_audit: dict,
    frontier_witnesses: list[dict] | None = None,
) -> list[dict]:
    max_depth = result.get("max_depth") if isinstance(result, dict) else None
    max_nodes = result.get("max_nodes") if isinstance(result, dict) else None
    evaluation_method = result.get("method") if isinstance(result, dict) else None
    frontier_witness_list = list(frontier_witnesses or [])
    rows = []
    for code in blockers:
        if code == "no_homfly_result":
            rows.append(
                {
                    "code": code,
                    "severity": "blocking",
                    "scope": "input_certification",
                    "reason": "no HOMFLY result payload was supplied",
                    "witness": {"result_present": False},
                }
            )
        elif code == "frontier_not_exhausted":
            rows.append(
                {
                    "code": code,
                    "severity": "blocking",
                    "scope": "input_certification",
                    "reason": (
                        "recursive HOMFLY frontier still has unresolved branches"
                    ),
                    "cap": {"max_depth": max_depth, "max_nodes": max_nodes},
                    "witness": {
                        "frontier_count": frontier_count,
                        "frontier_reasons": list(frontier_reasons),
                        "frontier_exhausted": frontier_exhausted,
                        "frontier_witness_count": len(frontier_witness_list),
                        "first_frontier_witness": (
                            frontier_witness_list[0]
                            if frontier_witness_list
                            else None
                        ),
                    },
                }
            )
        elif code == "truncated_recursive_evaluation":
            rows.append(
                {
                    "code": code,
                    "severity": "blocking",
                    "scope": "input_certification",
                    "reason": (
                        "recursive HOMFLY evaluation hit a configured bound before completion"
                    ),
                    "cap": {"max_depth": max_depth, "max_nodes": max_nodes},
                    "witness": {
                        "truncated": truncated,
                        "frontier_count": frontier_count,
                    },
                }
            )
        elif code == "terminal_contribution_mismatch":
            rows.append(
                {
                    "code": code,
                    "severity": "blocking",
                    "scope": "input_certification",
                    "reason": (
                        "recorded terminal and memoized reductions do not sum to the final HOMFLY polynomial"
                    ),
                    "witness": {
                        "terminal_contribution_sum": terminal_audit.get(
                            "terminal_contribution_sum"
                        ),
                        "homfly_polynomial": terminal_audit.get(
                            "homfly_polynomial"
                        ),
                        "failed_terminal_reduction_count": int(
                            terminal_audit.get(
                                "failed_terminal_reduction_count",
                                0,
                            )
                            or 0
                        ),
                        "reduction_contribution_count": int(
                            terminal_audit.get("reduction_contribution_count", 0) or 0
                        ),
                        "parsed_reduction_contribution_count": int(
                            terminal_audit.get(
                                "parsed_reduction_contribution_count",
                                0,
                            )
                            or 0
                        ),
                        "unparsed_reduction_contribution_count": int(
                            terminal_audit.get(
                                "unparsed_reduction_contribution_count",
                                0,
                            )
                            or 0
                        ),
                        "reduction_kind_counts": list(
                            terminal_audit.get("reduction_kind_counts", []) or []
                        ),
                        "reduction_kind_contribution_sums": list(
                            terminal_audit.get(
                                "reduction_kind_contribution_sums",
                                [],
                            )
                            or []
                        ),
                        "first_reduction_contribution_witness": terminal_audit.get(
                            "first_reduction_contribution_witness"
                        ),
                    },
                }
            )
        elif code == "role_order_or_convention_ambiguity_skipped":
            rows.append(
                {
                    "code": code,
                    "severity": "blocking",
                    "scope": "signed_pd_input",
                    "reason": (
                        "signed-PD role order or convention ambiguity skipped HOMFLY evaluation"
                    ),
                    "witness": {
                        "evaluation_method": evaluation_method,
                        "skipped": skipped,
                    },
                }
            )
        elif code == "evaluation_skipped":
            rows.append(
                {
                    "code": code,
                    "severity": "blocking",
                    "scope": "input_certification",
                    "reason": "HOMFLY evaluation was skipped before certification",
                    "witness": {
                        "evaluation_method": evaluation_method,
                        "skipped": skipped,
                    },
                }
            )
        elif code == "input_not_certified":
            rows.append(
                {
                    "code": code,
                    "severity": "blocking",
                    "scope": "input_certification",
                    "reason": (
                        "HOMFLY result did not satisfy input-level certification"
                    ),
                    "witness": {
                        "certified_for_input": certified_for_input,
                        "frontier_exhausted": frontier_exhausted,
                        "truncated": truncated,
                    },
                }
            )
        else:
            rows.append(
                {
                    "code": code,
                    "severity": "blocking",
                    "scope": "input_certification",
                    "reason": "unclassified HOMFLY certification blocker",
                    "witness": {
                        "evaluation_method": evaluation_method,
                        "certified_for_input": certified_for_input,
                    },
                }
            )
    return rows


def homfly_input_certification_evidence(result: dict | None) -> dict:
    """Summarize input-level HOMFLY certification evidence from a result payload.

    The helper does not evaluate HOMFLY. It turns the existing
    ``homfly_certified_evaluation_from_pd`` or ``homfly_iterative_certified_evaluation_from_pd`` payload into a stable report/UI
    shape that distinguishes input-level recursion exhaustion from table
    normalization or arbitrary-diagram coverage.
    """

    if result is None:
        homfly_completion_blockers = _homfly_completion_blockers(
            full_table_normalization_certified=False,
            arbitrary_diagram_coverage_certified=False,
        )
        certification_blockers = ["no_homfly_result"]
        terminal_audit = homfly_terminal_reduction_audit(None)
        certification_blocker_details = (
            _homfly_input_certification_blocker_details(
                blockers=certification_blockers,
                result=None,
                certified_for_input=False,
                frontier_exhausted=False,
                frontier_count=0,
                frontier_reasons=[],
                truncated=False,
                skipped=True,
                terminal_audit=terminal_audit,
            )
        )
        certification_blocker_code_counts = _homfly_blocker_code_counts(
            certification_blockers
        )
        certification_blocker_detail_code_counts = (
            _homfly_blocker_detail_code_counts(certification_blocker_details)
        )
        arbitrary_diagram_completion_gate = _homfly_arbitrary_diagram_completion_gate(
            evidence_scope="missing_homfly_result",
            source_method=None,
            source_claim_scope=None,
            result_present=False,
            frontier_exhausted=False,
            frontier_count=0,
            frontier_case_count=0,
            frontier_reasons=[],
            truncated=False,
            truncated_case_count=0,
            terminal_contribution_matches_result=False,
            terminal_contribution_audit_skipped=True,
            certification_blockers=certification_blockers,
            certification_blocker_detail_count=len(certification_blocker_details),
            certification_blocker_code_counts=certification_blocker_code_counts,
            certification_blocker_detail_code_counts=(
                certification_blocker_detail_code_counts
            ),
            case_count=0,
            certified_case_count=0,
            uncertified_case_count=0,
            skipped_case_count=0,
        )
        homfly_completion_blocker_details = _homfly_completion_blocker_details(
            full_table_normalization_certified=False,
            arbitrary_diagram_coverage_certified=False,
            arbitrary_diagram_completion_gate=arbitrary_diagram_completion_gate,
        )
        homfly_completion_blocker_code_counts = _homfly_blocker_code_counts(
            homfly_completion_blockers
        )
        homfly_completion_blocker_detail_code_counts = (
            _homfly_blocker_detail_code_counts(homfly_completion_blocker_details)
        )
        frontier_witness_consistency = _homfly_frontier_witness_consistency_record(
            {
                "frontier_count": 0,
                "frontier_witness_count": 0,
                "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
                "frontier_witnesses_truncated": False,
                "frontier_witnesses": [],
                "first_frontier_witness": None,
            }
        )
        frontier_witness_summary = _homfly_frontier_witness_summary_record(
            {
                "frontier_count": 0,
                "frontier_witness_count": 0,
                "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
                "frontier_witnesses_truncated": False,
                "frontier_witnesses": [],
                "first_frontier_witness": None,
            }
        )
        return {
            "method": "homfly_input_certification_evidence",
            "claim_scope": "recursive_frontier_exhaustion_for_one_signed_pd_input",
            "evaluation_method": None,
            "homfly_polynomial": None,
            "max_crossings": None,
            "max_depth": None,
            "max_nodes": None,
            "initial_depth": None,
            "iterative_attempt_count": 0,
            "iterative_solved_depth": None,
            "iterative_depth_attempts": [],
            "certified_for_input": False,
            "frontier_exhausted": False,
            "zero_crossing_certified": False,
            "bounded_homfly_maturity_path": _HOMFLY_MATURITY_NOT_CERTIFIED,
            "bounded_homfly_maturity_path_certified": False,
            "bounded_homfly_maturity_path_evidence": (
                _bounded_homfly_maturity_path_evidence_record(
                    bounded_homfly_maturity_path=(
                        _HOMFLY_MATURITY_NOT_CERTIFIED
                    ),
                    skipped=True,
                    certification_blocker_count=len(certification_blockers),
                )
            ),
            "full_table_normalization_certified": False,
            "arbitrary_diagram_coverage_certified": False,
            "recursion_nodes": 0,
            "cache_hits": 0,
            "terminal_reduction_count": 0,
            "memoized_reduction_count": 0,
            "reduction_contribution_count": 0,
            "parsed_reduction_contribution_count": 0,
            "unparsed_reduction_contribution_count": 0,
            "reduction_kind_counts": [],
            "reduction_kind_contribution_sums": [],
            "reduction_contribution_witness_count": 0,
            "reduction_contribution_witness_limit": (
                _HOMFLY_REDUCTION_CONTRIBUTION_WITNESS_LIMIT
            ),
            "reduction_contribution_witnesses_truncated": False,
            "reduction_contribution_witnesses": [],
            "first_reduction_contribution_witness": None,
            "reduction_contribution_witness_summary": terminal_audit[
                "reduction_contribution_witness_summary"
            ],
            "reduction_contribution_witness_consistency": terminal_audit[
                "reduction_contribution_witness_consistency"
            ],
            "terminal_contribution_sum": None,
            "terminal_contribution_matches_result": False,
            "terminal_contribution_audit_skipped": True,
            "terminal_contribution_audit": terminal_audit,
            "frontier_count": 0,
            "frontier_reason_count": 0,
            "frontier_reasons": [],
            "frontier_witness_count": 0,
            "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
            "frontier_witnesses_truncated": False,
            "frontier_witnesses": [],
            "first_frontier_witness": None,
            "frontier_witness_consistency": frontier_witness_consistency,
            "frontier_witness_summary": frontier_witness_summary,
            "truncated": False,
            "arbitrary_diagram_completion_gate": arbitrary_diagram_completion_gate,
            "certification_blockers": certification_blockers,
            "certification_blocker_count": len(certification_blockers),
            "certification_blocker_code_counts": certification_blocker_code_counts,
            "certification_blocker_details": certification_blocker_details,
            "certification_blocker_detail_count": len(
                certification_blocker_details
            ),
            "certification_blocker_detail_code_counts": (
                certification_blocker_detail_code_counts
            ),
            "homfly_completion_blockers": homfly_completion_blockers,
            "homfly_completion_blocker_count": len(homfly_completion_blockers),
            "homfly_completion_blocker_code_counts": (
                homfly_completion_blocker_code_counts
            ),
            "homfly_completion_blocker_details": homfly_completion_blocker_details,
            "homfly_completion_blocker_detail_count": len(
                homfly_completion_blocker_details
            ),
            "homfly_completion_blocker_detail_code_counts": (
                homfly_completion_blocker_detail_code_counts
            ),
            "skipped": True,
            "notes": ["no HOMFLY result supplied"],
        }

    recursive = result.get("recursive_evaluation")
    zero_crossing_certified = (
        result.get("method")
        in {
            "certified_zero_crossing_unlink_normalization",
            "certified_iterative_zero_crossing_unlink_normalization",
        }
        and bool(result.get("certified_for_input", False))
        and recursive is None
    )
    if isinstance(recursive, dict):
        frontier_count = int(
            recursive.get("frontier_count", len(recursive.get("frontier", [])))
            or 0
        )
        truncated = bool(recursive.get("truncated", False))
        recursion_nodes = int(recursive.get("recursion_nodes", 0) or 0)
        cache_hits = int(recursive.get("cache_hits", 0) or 0)
        terminal_reduction_count = len(recursive.get("terminal_reductions", []))
        memoized_reduction_count = len(recursive.get("memoized_reductions", []))
        frontier_reasons = list(
            recursive.get(
                "frontier_reasons",
                _homfly_frontier_reasons(recursive.get("frontier", [])),
            )
        )
        frontier_witnesses = _homfly_frontier_witnesses_from_recursive(recursive)
        frontier_witness_limit = int(
            recursive.get(
                "frontier_witness_limit",
                _HOMFLY_FRONTIER_WITNESS_LIMIT,
            )
            or _HOMFLY_FRONTIER_WITNESS_LIMIT
        )
        frontier_witnesses_truncated = bool(
            recursive.get(
                "frontier_witnesses_truncated",
                frontier_count > len(frontier_witnesses),
            )
        )
    else:
        frontier_count = 0
        truncated = False
        recursion_nodes = 0
        cache_hits = 0
        terminal_reduction_count = 0
        memoized_reduction_count = 0
        frontier_reasons = list(result.get("frontier_reasons", []))
        frontier_witnesses = [
            dict(witness)
            for witness in (
                result.get("frontier_witnesses") or []
            )[:_HOMFLY_FRONTIER_WITNESS_LIMIT]
            if isinstance(witness, dict)
        ]
        frontier_witness_limit = int(
            result.get("frontier_witness_limit", _HOMFLY_FRONTIER_WITNESS_LIMIT)
            or _HOMFLY_FRONTIER_WITNESS_LIMIT
        )
        frontier_witnesses_truncated = bool(
            result.get(
                "frontier_witnesses_truncated",
                frontier_count > len(frontier_witnesses),
            )
        )

    iterative_depth_attempts = list(result.get("depth_attempts", []))
    iterative_attempt_count = int(
        result.get("attempt_count", len(iterative_depth_attempts)) or 0
    )
    iterative_solved_depth = result.get("solved_depth")
    certified_for_input = bool(result.get("certified_for_input", False))
    skipped = bool(result.get("skipped", False))
    frontier_exhausted = zero_crossing_certified or (
        certified_for_input
        and not skipped
        and not truncated
        and frontier_count == 0
    )
    notes = [str(note) for note in result.get("notes", [])]
    notes.append(
        "input evidence is limited to this supplied signed-PD payload and does not certify table normalization"
    )
    terminal_audit = homfly_terminal_reduction_audit(result)
    full_table_normalization_certified = bool(
        result.get("full_table_normalization_certified", False)
    )
    arbitrary_diagram_coverage_certified = bool(
        result.get("arbitrary_diagram_coverage_certified", False)
    )
    certification_blockers = _homfly_input_certification_blockers(
        result=result,
        certified_for_input=certified_for_input,
        frontier_exhausted=frontier_exhausted,
        frontier_count=frontier_count,
        frontier_reasons=frontier_reasons,
        truncated=truncated,
        skipped=skipped,
        terminal_audit=terminal_audit,
    )
    homfly_completion_blockers = _homfly_completion_blockers(
        full_table_normalization_certified=full_table_normalization_certified,
        arbitrary_diagram_coverage_certified=arbitrary_diagram_coverage_certified,
    )
    certification_blocker_details = _homfly_input_certification_blocker_details(
        blockers=certification_blockers,
        result=result,
        certified_for_input=certified_for_input,
        frontier_exhausted=frontier_exhausted,
        frontier_count=frontier_count,
        frontier_reasons=frontier_reasons,
        truncated=truncated,
        skipped=skipped,
        terminal_audit=terminal_audit,
        frontier_witnesses=frontier_witnesses,
    )
    certification_blocker_code_counts = _homfly_blocker_code_counts(
        certification_blockers
    )
    certification_blocker_detail_code_counts = (
        _homfly_blocker_detail_code_counts(certification_blocker_details)
    )
    first_frontier_witness = (
        frontier_witnesses[0] if frontier_witnesses else None
    )
    frontier_witness_consistency = _homfly_frontier_witness_consistency_record(
        {
            "frontier_count": frontier_count,
            "frontier_witness_count": len(frontier_witnesses),
            "frontier_witness_limit": frontier_witness_limit,
            "frontier_witnesses_truncated": frontier_witnesses_truncated,
            "frontier_witnesses": frontier_witnesses,
            "first_frontier_witness": first_frontier_witness,
        }
    )
    frontier_witness_summary = _homfly_frontier_witness_summary_record(
        {
            "frontier_count": frontier_count,
            "frontier_witness_count": len(frontier_witnesses),
            "frontier_witness_limit": frontier_witness_limit,
            "frontier_witnesses_truncated": frontier_witnesses_truncated,
            "frontier_witnesses": frontier_witnesses,
            "first_frontier_witness": first_frontier_witness,
        }
    )
    arbitrary_diagram_completion_gate = _homfly_arbitrary_diagram_completion_gate(
        evidence_scope="single_signed_pd_input",
        source_method=result.get("method"),
        source_claim_scope=result.get(
            "claim_scope",
            "recursive_frontier_exhaustion_for_one_signed_pd_input",
        ),
        result_present=True,
        frontier_exhausted=frontier_exhausted,
        frontier_count=frontier_count,
        frontier_case_count=1 if frontier_count > 0 else 0,
        frontier_reasons=frontier_reasons,
        frontier_witnesses=frontier_witnesses,
        truncated=truncated,
        truncated_case_count=1 if truncated else 0,
        terminal_contribution_matches_result=bool(
            terminal_audit["matched_result"]
        ),
        terminal_contribution_audit_skipped=bool(terminal_audit["skipped"]),
        certification_blockers=certification_blockers,
        certification_blocker_detail_count=len(certification_blocker_details),
        certification_blocker_code_counts=certification_blocker_code_counts,
        certification_blocker_detail_code_counts=(
            certification_blocker_detail_code_counts
        ),
        case_count=1,
        certified_case_count=1 if certified_for_input else 0,
        uncertified_case_count=0 if certified_for_input else 1,
        skipped_case_count=1 if skipped else 0,
        max_crossings=result.get("max_crossings"),
        max_depth=result.get("max_depth"),
        max_nodes=result.get("max_nodes"),
    )
    homfly_completion_blocker_details = _homfly_completion_blocker_details(
        full_table_normalization_certified=full_table_normalization_certified,
        arbitrary_diagram_coverage_certified=arbitrary_diagram_coverage_certified,
        arbitrary_diagram_completion_gate=arbitrary_diagram_completion_gate,
    )
    homfly_completion_blocker_code_counts = _homfly_blocker_code_counts(
        homfly_completion_blockers
    )
    homfly_completion_blocker_detail_code_counts = (
        _homfly_blocker_detail_code_counts(homfly_completion_blocker_details)
    )
    input_certification_blocker_free = not certification_blockers
    recursive_frontier_certified_method = str(result.get("method")) in {
        "certified_recursive_switching_to_descending",
        "certified_iterative_recursive_switching_to_descending",
    }
    bounded_homfly_maturity_zero_crossing_certified = (
        zero_crossing_certified and input_certification_blocker_free
    )
    bounded_homfly_maturity_certified_for_input = (
        recursive_frontier_certified_method
        and certified_for_input
        and input_certification_blocker_free
    )
    bounded_homfly_maturity_path = _bounded_homfly_maturity_path(
        zero_crossing_certified=bounded_homfly_maturity_zero_crossing_certified,
        certified_for_input=bounded_homfly_maturity_certified_for_input,
        frontier_exhausted=frontier_exhausted,
        skipped=skipped,
        truncated=truncated,
        frontier_count=frontier_count,
    )
    bounded_homfly_maturity_path_certified = (
        _bounded_homfly_maturity_path_certified(bounded_homfly_maturity_path)
    )
    bounded_homfly_maturity_path_evidence = (
        _bounded_homfly_maturity_path_evidence_record(
            bounded_homfly_maturity_path=bounded_homfly_maturity_path,
            zero_crossing_certified=(
                bounded_homfly_maturity_zero_crossing_certified
            ),
            certified_for_input=bounded_homfly_maturity_certified_for_input,
            frontier_exhausted=frontier_exhausted,
            skipped=skipped,
            truncated=truncated,
            frontier_count=frontier_count,
            certification_blocker_count=len(certification_blockers),
        )
    )

    return {
        "method": "homfly_input_certification_evidence",
        "claim_scope": "recursive_frontier_exhaustion_for_one_signed_pd_input",
        "evaluation_method": result.get("method"),
        "homfly_polynomial": result.get("homfly_polynomial"),
        "max_crossings": result.get("max_crossings"),
        "max_depth": result.get("max_depth"),
        "max_nodes": result.get("max_nodes"),
        "initial_depth": result.get("initial_depth"),
        "iterative_attempt_count": iterative_attempt_count,
        "iterative_solved_depth": iterative_solved_depth,
        "iterative_depth_attempts": iterative_depth_attempts,
        "certified_for_input": certified_for_input,
        "frontier_exhausted": frontier_exhausted,
        "zero_crossing_certified": zero_crossing_certified,
        "bounded_homfly_maturity_path": bounded_homfly_maturity_path,
        "bounded_homfly_maturity_path_certified": (
            bounded_homfly_maturity_path_certified
        ),
        "bounded_homfly_maturity_path_evidence": (
            bounded_homfly_maturity_path_evidence
        ),
        "full_table_normalization_certified": full_table_normalization_certified,
        "arbitrary_diagram_coverage_certified": (
            arbitrary_diagram_coverage_certified
        ),
        "recursion_nodes": recursion_nodes,
        "cache_hits": cache_hits,
        "terminal_reduction_count": terminal_reduction_count,
        "memoized_reduction_count": memoized_reduction_count,
        "reduction_contribution_count": terminal_audit[
            "reduction_contribution_count"
        ],
        "parsed_reduction_contribution_count": terminal_audit[
            "parsed_reduction_contribution_count"
        ],
        "unparsed_reduction_contribution_count": terminal_audit[
            "unparsed_reduction_contribution_count"
        ],
        "reduction_kind_counts": terminal_audit["reduction_kind_counts"],
        "reduction_kind_contribution_sums": terminal_audit[
            "reduction_kind_contribution_sums"
        ],
        "reduction_contribution_witness_count": terminal_audit[
            "reduction_contribution_witness_count"
        ],
        "reduction_contribution_witness_limit": terminal_audit[
            "reduction_contribution_witness_limit"
        ],
        "reduction_contribution_witnesses_truncated": terminal_audit[
            "reduction_contribution_witnesses_truncated"
        ],
        "reduction_contribution_witnesses": terminal_audit[
            "reduction_contribution_witnesses"
        ],
        "first_reduction_contribution_witness": terminal_audit[
            "first_reduction_contribution_witness"
        ],
        "reduction_contribution_witness_summary": terminal_audit[
            "reduction_contribution_witness_summary"
        ],
        "reduction_contribution_witness_consistency": terminal_audit[
            "reduction_contribution_witness_consistency"
        ],
        "terminal_contribution_sum": terminal_audit["terminal_contribution_sum"],
        "terminal_contribution_matches_result": bool(
            terminal_audit["matched_result"]
        ),
        "terminal_contribution_audit_skipped": bool(terminal_audit["skipped"]),
        "terminal_contribution_audit": terminal_audit,
        "frontier_count": frontier_count,
        "frontier_reason_count": len(frontier_reasons),
        "frontier_reasons": frontier_reasons,
        "frontier_witness_count": len(frontier_witnesses),
        "frontier_witness_limit": frontier_witness_limit,
        "frontier_witnesses_truncated": frontier_witnesses_truncated,
        "frontier_witnesses": frontier_witnesses,
        "first_frontier_witness": first_frontier_witness,
        "frontier_witness_consistency": frontier_witness_consistency,
        "frontier_witness_summary": frontier_witness_summary,
        "truncated": truncated,
        "arbitrary_diagram_completion_gate": arbitrary_diagram_completion_gate,
        "certification_blockers": certification_blockers,
        "certification_blocker_count": len(certification_blockers),
        "certification_blocker_code_counts": certification_blocker_code_counts,
        "certification_blocker_details": certification_blocker_details,
        "certification_blocker_detail_count": len(certification_blocker_details),
        "certification_blocker_detail_code_counts": (
            certification_blocker_detail_code_counts
        ),
        "homfly_completion_blockers": homfly_completion_blockers,
        "homfly_completion_blocker_count": len(homfly_completion_blockers),
        "homfly_completion_blocker_code_counts": (
            homfly_completion_blocker_code_counts
        ),
        "homfly_completion_blocker_details": homfly_completion_blocker_details,
        "homfly_completion_blocker_detail_count": len(
            homfly_completion_blocker_details
        ),
        "homfly_completion_blocker_detail_code_counts": (
            homfly_completion_blocker_detail_code_counts
        ),
        "skipped": skipped,
        "notes": notes,
    }


def homfly_unlink_polynomial(component_count: int) -> str:
    return _homfly_unlink_polynomial(component_count).format()


def homfly_mirror_polynomial(polynomial: str) -> str:
    """Return the HOMFLY-PT polynomial for the mirror under iroll's convention."""

    return _transform_homfly_polynomial(
        polynomial,
        invert_a=True,
        negate_z=True,
    )


def homfly_polynomial_convention_variants(polynomial: str) -> list[dict]:
    """Return common HOMFLY source-table convention transforms for diagnostics."""

    variants = []
    for name, invert_a, negate_z, invert_z in (
        ("identity", False, False, False),
        ("invert_a", True, False, False),
        ("negate_z", False, True, False),
        ("mirror_invert_a_negate_z", True, True, False),
        ("invert_z", False, False, True),
        ("invert_a_invert_z", True, False, True),
        ("negate_z_invert_z", False, True, True),
        ("mirror_invert_a_negate_z_invert_z", True, True, True),
    ):
        variants.append(
            {
                "name": name,
                "invert_a": invert_a,
                "negate_z": negate_z,
                "invert_z": invert_z,
                "polynomial": _transform_homfly_polynomial(
                    polynomial,
                    invert_a=invert_a,
                    negate_z=negate_z,
                    invert_z=invert_z,
                ),
            }
        )
    return variants


def _transform_homfly_polynomial(
    polynomial: str,
    *,
    invert_a: bool,
    negate_z: bool,
    invert_z: bool = False,
) -> str:
    parsed = parse_multivariate_laurent_polynomial(polynomial, variables=("a", "z"))
    transformed_terms: dict[tuple[int, int], int] = {}
    for (a_exponent, z_exponent), coefficient in parsed.terms:
        z_sign = -1 if negate_z and z_exponent % 2 else 1
        transformed_exponents = (
            -a_exponent if invert_a else a_exponent,
            -z_exponent if invert_z else z_exponent,
        )
        transformed_terms[transformed_exponents] = (
            transformed_terms.get(transformed_exponents, 0) + z_sign * coefficient
        )
    return MultivariateLaurentPolynomial.from_dict(
        transformed_terms,
        variables=("a", "z"),
    ).format()


def homfly_fixture_comparison(
    notation: str,
    *,
    max_depth: int = 8,
    max_nodes: int = 512,
) -> dict:
    """Compare algorithmic HOMFLY output against a standard diagram fixture."""

    from iroll.topology.pd_fixtures import get_diagram_fixture

    fixture = get_diagram_fixture(notation)
    fixture_payload = fixture.to_dict()
    if not fixture.has_signed_pd:
        source_orientation_diagnostics = _fixture_source_orientation_diagnostics(
            fixture,
        )
        source_pairwise_candidate_diagnostics = (
            fixture.source_pairwise_candidate_diagnostics(
                max_orientation_samples=64,
                max_candidates=8,
            )
        )
        return {
            "method": "homfly_fixture_comparison",
            "notation": fixture.notation,
            "fixture": fixture_payload,
            "expected_homfly": fixture.expected_homfly,
            "observed_homfly": None,
            "matched": False,
            "skipped": True,
            "result": None,
            "source_orientation_diagnostics": source_orientation_diagnostics,
            "source_pairwise_candidate_diagnostics": (
                source_pairwise_candidate_diagnostics
            ),
            "notes": [
                "fixture does not have a signed-PD diagram",
                *source_orientation_diagnostics["notes"],
                *source_pairwise_candidate_diagnostics["notes"],
            ],
        }
    if fixture.expected_homfly is None:
        return {
            "method": "homfly_fixture_comparison",
            "notation": fixture.notation,
            "fixture": fixture_payload,
            "expected_homfly": None,
            "observed_homfly": None,
            "matched": False,
            "skipped": True,
            "result": None,
            "certified_for_input": False,
            "full_table_normalization_certified": False,
            "arbitrary_diagram_coverage_certified": False,
            "notes": ["fixture does not register an expected HOMFLY polynomial"],
        }

    diagram = fixture.diagram()
    orientation = fixture.orientation()
    result = homfly_iterative_certified_evaluation_from_pd(
        diagram,
        orientation=orientation,
        initial_depth=0,
        max_depth=max_depth,
        max_nodes=max_nodes,
    )
    observed = result.get("homfly_polynomial")
    skipped = bool(result.get("skipped", False))
    matched = (not skipped) and observed == fixture.expected_homfly
    return {
        "method": "homfly_fixture_comparison",
        "notation": fixture.notation,
        "fixture": fixture_payload,
        "expected_homfly": fixture.expected_homfly,
        "observed_homfly": observed,
        "matched": matched,
        "skipped": skipped,
        "result": result,
        "certified_for_input": bool(result.get("certified_for_input", False)),
        "full_table_normalization_certified": bool(
            result.get("full_table_normalization_certified", False)
        ),
        "arbitrary_diagram_coverage_certified": bool(
            result.get("arbitrary_diagram_coverage_certified", False)
        ),
        "notes": [
            f"expected source: {fixture.expected_homfly_source}"
            if fixture.expected_homfly_source
            else "expected source is not registered",
            *list(result.get("notes", [])),
        ],
    }


def _generated_skein_branch_inputs(
    *,
    source_notation: str,
    diagram: PlanarDiagram,
    orientation: PDOrientation,
    branch_depth: int,
) -> tuple[list[dict], list[dict]]:
    """Return fixture root plus bounded generated HOMFLY skein branch inputs."""

    if branch_depth < 1:
        raise ValueError("branch_depth must be at least 1")

    root = {
        "source_notation": source_notation,
        "source_kind": "fixture_root",
        "crossing_index": None,
        "branch": "root",
        "branch_depth": 0,
        "branch_path": [],
        "parent_case_id": None,
        "case_id": f"{source_notation}:root:root",
        "diagram": diagram,
        "orientation": orientation,
    }
    records = [root]
    frontier = [root]
    errors: list[dict] = []

    for depth in range(1, branch_depth + 1):
        next_frontier: list[dict] = []
        for parent in frontier:
            parent_diagram = parent["diagram"]
            parent_orientation = parent["orientation"]
            for crossing_index in range(parent_diagram.crossing_count):
                try:
                    relation = homfly_skein_relation(
                        parent_diagram,
                        crossing_index,
                        orientation=parent_orientation,
                    )
                except ValueError as exc:
                    error_path = [
                        *parent["branch_path"],
                        f"{crossing_index}:error",
                    ]
                    errors.append(
                        {
                            "source_notation": source_notation,
                            "source_kind": (
                                "skein_relation_error"
                                if depth == 1
                                else "multi_step_skein_relation_error"
                            ),
                            "crossing_index": crossing_index,
                            "branch": None,
                            "branch_depth": depth,
                            "branch_path": error_path,
                            "parent_case_id": parent["case_id"],
                            "case_id": f"{source_notation}:{'|'.join(error_path)}",
                            "diagram": parent_diagram,
                            "orientation": parent_orientation,
                            "error": str(exc),
                        }
                    )
                    continue

                for branch in ("positive", "negative", "smoothed"):
                    step = f"{crossing_index}:{branch}"
                    branch_path = [*parent["branch_path"], step]
                    if depth == 1 and parent["source_kind"] == "fixture_root":
                        case_id = f"{source_notation}:{crossing_index}:{branch}"
                        source_kind = "one_step_skein_branch"
                    else:
                        case_id = f"{source_notation}:{'|'.join(branch_path)}"
                        source_kind = "multi_step_skein_branch"
                    record = {
                        "source_notation": source_notation,
                        "source_kind": source_kind,
                        "crossing_index": crossing_index,
                        "branch": branch,
                        "branch_depth": depth,
                        "branch_path": branch_path,
                        "parent_case_id": parent["case_id"],
                        "case_id": case_id,
                        "diagram": relation[branch],
                        "orientation": relation[f"{branch}_orientation"],
                    }
                    records.append(record)
                    next_frontier.append(record)
        frontier = next_frontier

    return records, errors

def homfly_mirror_fixture_comparison(
    notation: str,
    *,
    max_depth: int = 8,
    max_nodes: int = 512,
) -> dict:
    """Audit the current HOMFLY mirror convention against a signed-PD fixture."""

    from iroll.topology.pd_fixtures import get_diagram_fixture

    fixture = get_diagram_fixture(notation)
    if not fixture.has_signed_pd or fixture.expected_homfly is None:
        return {
            "method": "homfly_mirror_fixture_comparison",
            "notation": fixture.notation,
            "skipped": True,
            "matched": False,
            "mirror_transform_convention": "P_mirror(a,z) = P(a^-1,-z)",
            "original_homfly": None,
            "mirrored_homfly": None,
            "expected_mirror_homfly": None,
            "registered_expected_homfly": fixture.expected_homfly,
            "registered_expected_mirror_homfly": None,
            "registered_expected_mirror_invariant": False,
            "candidate_mirror_transforms": [],
            "notes": ["fixture lacks signed-PD data or a registered HOMFLY value"],
        }

    diagram = fixture.diagram()
    orientation = fixture.orientation()
    original = homfly_certified_evaluation_from_pd(
        diagram,
        orientation=orientation,
        max_depth=max_depth,
        max_nodes=max_nodes,
    )
    mirrored_diagram, mirrored_orientation = mirror_signed_pd(
        diagram,
        orientation=orientation,
    )
    mirrored = homfly_certified_evaluation_from_pd(
        mirrored_diagram,
        orientation=mirrored_orientation,
        max_depth=max_depth,
        max_nodes=max_nodes,
    )
    original_homfly = original.get("homfly_polynomial")
    mirrored_homfly = mirrored.get("homfly_polynomial")
    expected_mirror = (
        homfly_mirror_polynomial(str(original_homfly))
        if original_homfly is not None
        else None
    )
    registered_expected_mirror = homfly_mirror_polynomial(
        fixture.expected_homfly,
    )
    candidate_transforms = []
    if original_homfly is not None:
        for convention, invert_a, negate_z in (
            ("invert_a_negate_z", True, True),
            ("invert_a_keep_z", True, False),
        ):
            transformed = _transform_homfly_polynomial(
                str(original_homfly),
                invert_a=invert_a,
                negate_z=negate_z,
            )
            candidate_transforms.append(
                {
                    "convention": convention,
                    "homfly_polynomial": transformed,
                    "matched_observed_mirror": transformed == mirrored_homfly,
                }
            )
    matched = (
        original_homfly is not None
        and mirrored_homfly is not None
        and expected_mirror == mirrored_homfly
    )
    return {
        "method": "homfly_mirror_fixture_comparison",
        "notation": fixture.notation,
        "skipped": False,
        "matched": matched,
        "mirror_transform_convention": "P_mirror(a,z) = P(a^-1,-z)",
        "original_homfly": original_homfly,
        "mirrored_homfly": mirrored_homfly,
        "expected_mirror_homfly": expected_mirror,
        "registered_expected_homfly": fixture.expected_homfly,
        "registered_expected_mirror_homfly": registered_expected_mirror,
        "registered_expected_mirror_invariant": (
            fixture.expected_homfly == registered_expected_mirror
        ),
        "candidate_mirror_transforms": candidate_transforms,
        "original_result": original,
        "mirrored_result": mirrored,
        "mirror_diagram": mirrored_diagram.to_dict(),
        "mirror_orientation": mirrored_orientation.to_dict()
        if mirrored_orientation is not None
        else None,
        "notes": [] if matched else ["mirrored signed-PD HOMFLY did not match the expected mirror transform"],
    }

def homfly_small_diagram_coverage_report(
    notations: Iterable[str] | None = None,
    *,
    max_depth: int = 16,
    max_nodes: int = 4096,
    branch_depth: int = 1,
) -> dict:
    """Audit recursive HOMFLY closure on generated small signed-PD diagrams.

    The report expands each selected signed fixture by a bounded number of
    local skein steps and certifies every generated branch only when the
    recursive evaluator exhausts its frontier. This is broader than fixture
    value comparison, but it remains a generated small-diagram coverage audit
    rather than arbitrary-diagram theorem or external table-normalization
    evidence.
    """

    from iroll.topology.pd_fixtures import get_diagram_fixture

    selected_notations = tuple(notations) if notations is not None else (
        "L2a1",
        "3_1",
        "4_1",
    )
    cases: list[dict] = []
    relation_error_count = 0
    evaluation_cache: dict[tuple[str, str, int, int], dict] = {}
    reused_evaluation_count = 0
    fixture_normalization_rows: list[dict] = []

    for notation in selected_notations:
        fixture = get_diagram_fixture(notation)
        fixture_normalization_rows.append(
            _homfly_fixture_normalization_metadata_row(fixture)
        )
        if not fixture.has_signed_pd:
            cases.append(
                {
                    "source_notation": fixture.notation,
                    "source_kind": "fixture_without_signed_pd",
                    "crossing_index": None,
                    "branch": None,
                    "branch_depth": 0,
                    "branch_path": [],
                    "parent_case_id": None,
                    "case_id": f"{fixture.notation}:skipped",
                    "crossing_count": int(len(fixture.pd_code or ())),
                    "component_count": fixture.component_count,
                    "has_orientation": False,
                    "diagram_key": None,
                    "orientation_key": None,
                    "homfly_polynomial": None,
                    "certified_for_input": False,
                    "bounded_homfly_maturity_path": _HOMFLY_MATURITY_NOT_CERTIFIED,
                    "bounded_homfly_maturity_path_certified": False,
                    "skipped": True,
                    "frontier_count": 0,
                    "frontier_reason_count": 0,
                    "frontier_reasons": [],
                    "frontier_witness_count": 0,
                    "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
                    "frontier_witnesses_truncated": False,
                    "frontier_witnesses": [],
                    "first_frontier_witness": None,
                    "frontier_witness_consistency": (
                        _homfly_frontier_witness_consistency_record(
                            {
                                "frontier_count": 0,
                                "frontier_witness_count": 0,
                                "frontier_witness_limit": (
                                    _HOMFLY_FRONTIER_WITNESS_LIMIT
                                ),
                                "frontier_witnesses_truncated": False,
                                "frontier_witnesses": [],
                                "first_frontier_witness": None,
                            },
                            context={"case_id": f"{fixture.notation}:skipped"},
                        )
                    ),
                    "frontier_witness_summary": (
                        _homfly_frontier_witness_summary_record(
                            {
                                "frontier_count": 0,
                                "frontier_witness_count": 0,
                                "frontier_witness_limit": (
                                    _HOMFLY_FRONTIER_WITNESS_LIMIT
                                ),
                                "frontier_witnesses_truncated": False,
                                "frontier_witnesses": [],
                                "first_frontier_witness": None,
                            }
                        )
                    ),
                    "truncated": False,
                    "solved_depth": None,
                    "attempt_count": 0,
                    "result_method": "skipped",
                    "input_certification_evidence": homfly_input_certification_evidence(None),
                    "notes": ["fixture does not have a signed-PD diagram"],
                }
            )
            continue

        diagram = fixture.diagram()
        orientation = fixture.orientation()
        branch_inputs, relation_errors = _generated_skein_branch_inputs(
            source_notation=fixture.notation,
            diagram=diagram,
            orientation=orientation,
            branch_depth=branch_depth,
        )
        relation_error_count += len(relation_errors)
        for branch_input in branch_inputs:
            evaluation_key = _homfly_small_coverage_evaluation_key(
                branch_input["diagram"],
                branch_input["orientation"],
                max_depth=max_depth,
                max_nodes=max_nodes,
            )
            evaluation = evaluation_cache.get(evaluation_key)
            if evaluation is None:
                evaluation = _homfly_small_coverage_evaluation_fields(
                    branch_input["diagram"],
                    branch_input["orientation"],
                    max_depth=max_depth,
                    max_nodes=max_nodes,
                )
                evaluation_cache[evaluation_key] = evaluation
            else:
                reused_evaluation_count += 1
            cases.append(
                _homfly_small_coverage_case(
                    source_notation=fixture.notation,
                    source_kind=branch_input["source_kind"],
                    crossing_index=branch_input["crossing_index"],
                    branch=branch_input["branch"],
                    branch_depth=branch_input["branch_depth"],
                    branch_path=branch_input["branch_path"],
                    parent_case_id=branch_input["parent_case_id"],
                    case_id=branch_input["case_id"],
                    diagram=branch_input["diagram"],
                    orientation=branch_input["orientation"],
                    max_depth=max_depth,
                    max_nodes=max_nodes,
                    evaluation=evaluation,
                )
            )
        for error in relation_errors:
            cases.append(
                {
                    "source_notation": fixture.notation,
                    "source_kind": error["source_kind"],
                    "crossing_index": error["crossing_index"],
                    "branch": None,
                    "branch_depth": error["branch_depth"],
                    "branch_path": error["branch_path"],
                    "parent_case_id": error["parent_case_id"],
                    "case_id": error["case_id"],
                    "crossing_count": error["diagram"].crossing_count,
                    "component_count": error["diagram"].component_count,
                    "has_orientation": True,
                    "diagram_key": repr(error["diagram"].canonical_key()),
                    "orientation_key": repr(_orientation_key(error["orientation"])),
                    "homfly_polynomial": None,
                    "certified_for_input": False,
                    "bounded_homfly_maturity_path": _HOMFLY_MATURITY_NOT_CERTIFIED,
                    "bounded_homfly_maturity_path_certified": False,
                    "skipped": True,
                    "frontier_count": 0,
                    "frontier_reason_count": 0,
                    "frontier_reasons": [],
                    "frontier_witness_count": 0,
                    "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
                    "frontier_witnesses_truncated": False,
                    "frontier_witnesses": [],
                    "first_frontier_witness": None,
                    "frontier_witness_consistency": (
                        _homfly_frontier_witness_consistency_record(
                            {
                                "frontier_count": 0,
                                "frontier_witness_count": 0,
                                "frontier_witness_limit": (
                                    _HOMFLY_FRONTIER_WITNESS_LIMIT
                                ),
                                "frontier_witnesses_truncated": False,
                                "frontier_witnesses": [],
                                "first_frontier_witness": None,
                            },
                            context={"case_id": error["case_id"]},
                        )
                    ),
                    "frontier_witness_summary": (
                        _homfly_frontier_witness_summary_record(
                            {
                                "frontier_count": 0,
                                "frontier_witness_count": 0,
                                "frontier_witness_limit": (
                                    _HOMFLY_FRONTIER_WITNESS_LIMIT
                                ),
                                "frontier_witnesses_truncated": False,
                                "frontier_witnesses": [],
                                "first_frontier_witness": None,
                            }
                        )
                    ),
                    "truncated": False,
                    "solved_depth": None,
                    "attempt_count": 0,
                    "result_method": "skipped",
                    "input_certification_evidence": homfly_input_certification_evidence(None),
                    "notes": [error["error"]],
                }
            )

    case_count = len(cases)
    frontier_cases = [
        case for case in cases if int(case.get("frontier_count", 0) or 0) > 0
    ]
    truncated_cases = [case for case in cases if case["truncated"]]
    attempt_count = sum(int(case["attempt_count"]) for case in cases)
    certified_count = sum(1 for case in cases if case["certified_for_input"])
    bounded_homfly_maturity_path_counts = _case_count_records_by_string_field(
        cases,
        "bounded_homfly_maturity_path",
        "bounded_homfly_maturity_path",
    )
    bounded_homfly_maturity_path_certified_count = sum(
        1
        for case in cases
        if case.get("bounded_homfly_maturity_path_certified", False)
    )
    skipped_count = sum(1 for case in cases if case["skipped"])
    truncated_count = len(truncated_cases)
    frontier_count = sum(int(case["frontier_count"]) for case in cases)
    frontier_case_count = len(frontier_cases)
    frontier_reasons = sorted(
        {
            str(reason)
            for case in cases
            for reason in case.get("frontier_reasons", [])
        }
    )
    frontier_witnesses = _homfly_generated_frontier_witnesses(cases)
    non_fixture_case_count = sum(
        1 for case in cases if case["source_kind"] != "fixture_root"
    )
    solved_depths = [
        int(case["solved_depth"])
        for case in cases
        if case["solved_depth"] is not None
    ]
    unique_diagram_keys = {
        case["diagram_key"]
        for case in cases
        if case["diagram_key"] is not None
    }
    diagram_multiplicity_summary = _homfly_diagram_multiplicity_summary(cases)
    source_notation_summary = _homfly_source_notation_coverage_summary(
        cases,
        selected_notations,
    )
    fixture_normalization_metadata = _homfly_fixture_normalization_metadata(
        fixture_normalization_rows
    )
    source_notation_summary = _homfly_source_summary_with_fixture_metadata(
        source_notation_summary,
        fixture_normalization_metadata,
    )
    accepted = (
        case_count > 0
        and certified_count == case_count
        and skipped_count == 0
        and truncated_count == 0
        and frontier_count == 0
        and relation_error_count == 0
    )
    homfly_completion_blockers = _homfly_completion_blockers(
        full_table_normalization_certified=False,
        arbitrary_diagram_coverage_certified=False,
    )
    homfly_completion_blocker_details = _homfly_completion_blocker_details(
        full_table_normalization_certified=False,
        arbitrary_diagram_coverage_certified=False,
    )
    homfly_completion_blocker_code_counts = _homfly_blocker_code_counts(
        homfly_completion_blockers
    )
    homfly_completion_blocker_detail_code_counts = (
        _homfly_blocker_detail_code_counts(homfly_completion_blocker_details)
    )
    input_certification_evidences = [
        case.get("input_certification_evidence")
        for case in cases
        if isinstance(case.get("input_certification_evidence"), dict)
    ]
    terminal_audit_applicable = [
        evidence
        for evidence in input_certification_evidences
        if not evidence.get("terminal_contribution_audit_skipped", True)
    ]
    aggregate_certification_blockers = sorted(
        {
            str(code)
            for evidence in input_certification_evidences
            for code in evidence.get("certification_blockers", [])
        }
    )
    aggregate_certification_blocker_detail_count = sum(
        int(evidence.get("certification_blocker_detail_count", 0) or 0)
        for evidence in input_certification_evidences
    )
    aggregate_certification_blocker_detail_code_counts = (
        _homfly_blocker_detail_code_counts(
            row
            for evidence in input_certification_evidences
            for row in evidence.get("certification_blocker_details", [])
        )
    )
    first_frontier_witness = (
        frontier_witnesses[0] if frontier_witnesses else None
    )
    frontier_reason_counts = _homfly_frontier_reason_count_records(cases)
    frontier_witness_consistency = _homfly_frontier_witness_consistency_record(
        {
            "frontier_count": frontier_count,
            "frontier_witness_count": len(frontier_witnesses),
            "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
            "frontier_witnesses_truncated": frontier_count > len(frontier_witnesses),
            "frontier_witnesses": frontier_witnesses,
            "first_frontier_witness": first_frontier_witness,
            "frontier_reason_counts": frontier_reason_counts,
        }
    )
    frontier_witness_summary = _homfly_frontier_witness_summary_record(
        {
            "frontier_count": frontier_count,
            "frontier_witness_count": len(frontier_witnesses),
            "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
            "frontier_witnesses_truncated": frontier_count > len(frontier_witnesses),
            "frontier_witnesses": frontier_witnesses,
            "first_frontier_witness": first_frontier_witness,
            "frontier_reason_counts": frontier_reason_counts,
        }
    )

    report = {
        "method": "homfly_small_diagram_coverage_report",
        "claim_scope": "generated_small_signed_pd_frontier_exhaustion",
        "source_notations": list(selected_notations),
        "fixture_count": len(selected_notations),
        "case_count": case_count,
        "non_fixture_case_count": non_fixture_case_count,
        "unique_diagram_count": len(unique_diagram_keys),
        "unique_oriented_diagram_count": (
            diagram_multiplicity_summary["unique_oriented_diagram_count"]
        ),
        "duplicate_diagram_case_count": (
            diagram_multiplicity_summary["duplicate_diagram_case_count"]
        ),
        "multi_path_diagram_count": (
            diagram_multiplicity_summary["multi_path_diagram_count"]
        ),
        "max_diagram_case_count": (
            diagram_multiplicity_summary["max_case_count_per_diagram"]
        ),
        "polynomial_variant_diagram_count": (
            diagram_multiplicity_summary["polynomial_variant_diagram_count"]
        ),
        "max_homfly_polynomial_count_per_diagram": (
            diagram_multiplicity_summary["max_homfly_polynomial_count_per_diagram"]
        ),
        "oriented_polynomial_conflict_count": (
            diagram_multiplicity_summary["oriented_polynomial_conflict_count"]
        ),
        "max_homfly_polynomial_count_per_oriented_diagram": (
            diagram_multiplicity_summary[
                "max_homfly_polynomial_count_per_oriented_diagram"
            ]
        ),
        "certified_case_count": certified_count,
        "bounded_homfly_maturity_path_counts": (
            bounded_homfly_maturity_path_counts
        ),
        "bounded_homfly_maturity_path_distinct_count": len(
            bounded_homfly_maturity_path_counts
        ),
        "bounded_homfly_maturity_path_certified_count": (
            bounded_homfly_maturity_path_certified_count
        ),
        "attempt_count": attempt_count,
        "uncertified_case_count": case_count - certified_count,
        "skipped_case_count": skipped_count,
        "truncated_case_count": truncated_count,
        "frontier_count": frontier_count,
        "frontier_case_count": frontier_case_count,
        "frontier_reason_count": len(frontier_reasons),
        "frontier_reasons": frontier_reasons,
        "frontier_reason_counts": frontier_reason_counts,
        "frontier_witness_count": len(frontier_witnesses),
        "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
        "frontier_witnesses_truncated": frontier_count > len(frontier_witnesses),
        "frontier_witnesses": frontier_witnesses,
        "first_frontier_witness": first_frontier_witness,
        "frontier_witness_consistency": frontier_witness_consistency,
        "frontier_witness_summary": frontier_witness_summary,
        "relation_error_count": relation_error_count,
        "max_crossing_count": max(
            (int(case["crossing_count"]) for case in cases),
            default=0,
        ),
        "max_depth": max_depth,
        "max_nodes": max_nodes,
        "branch_depth": branch_depth,
        "unique_evaluation_count": len(evaluation_cache),
        "reused_evaluation_count": reused_evaluation_count,
        "max_generated_branch_depth": max(
            (int(case.get("branch_depth", 0) or 0) for case in cases),
            default=0,
        ),
        "max_solved_depth": max(solved_depths) if solved_depths else None,
        "solved_depth_counts": _case_count_records_by_optional_int_field(
            cases,
            "solved_depth",
            "solved_depth",
        ),
        "branch_depth_counts": _case_count_records_by_int_field(
            cases,
            "branch_depth",
            "branch_depth",
        ),
        "certified_branch_depth_counts": _case_count_records_by_int_field(
            (case for case in cases if case["certified_for_input"]),
            "branch_depth",
            "branch_depth",
        ),
        "uncertified_branch_depth_counts": _case_count_records_by_int_field(
            (case for case in cases if not case["certified_for_input"]),
            "branch_depth",
            "branch_depth",
        ),
        "frontier_branch_depth_counts": _case_count_records_by_int_field(
            frontier_cases,
            "branch_depth",
            "branch_depth",
        ),
        "truncated_branch_depth_counts": _case_count_records_by_int_field(
            truncated_cases,
            "branch_depth",
            "branch_depth",
        ),
        "source_kind_counts": _case_count_records_by_string_field(
            cases,
            "source_kind",
            "source_kind",
        ),
        "frontier_source_kind_counts": _case_count_records_by_string_field(
            frontier_cases,
            "source_kind",
            "source_kind",
        ),
        "truncated_source_kind_counts": _case_count_records_by_string_field(
            truncated_cases,
            "source_kind",
            "source_kind",
        ),
        "branch_counts": _case_count_records_by_string_field(
            cases,
            "branch",
            "branch",
        ),
        "frontier_branch_counts": _case_count_records_by_string_field(
            frontier_cases,
            "branch",
            "branch",
        ),
        "truncated_branch_counts": _case_count_records_by_string_field(
            truncated_cases,
            "branch",
            "branch",
        ),
        "accepted": accepted,
        "full_table_normalization_certified": False,
        "arbitrary_diagram_coverage_certified": False,
        "homfly_completion_blockers": homfly_completion_blockers,
        "homfly_completion_blocker_count": len(homfly_completion_blockers),
        "homfly_completion_blocker_code_counts": (
            homfly_completion_blocker_code_counts
        ),
        "homfly_completion_blocker_details": homfly_completion_blocker_details,
        "homfly_completion_blocker_detail_count": len(
            homfly_completion_blocker_details
        ),
        "homfly_completion_blocker_detail_code_counts": (
            homfly_completion_blocker_detail_code_counts
        ),
        "fixture_normalization_metadata": fixture_normalization_metadata,
        "diagram_multiplicity_summary": diagram_multiplicity_summary,
        "source_notation_summary": source_notation_summary,
        "cases": cases,
        "notes": [
            "generated cases include fixture roots and bounded positive/negative/smoothed skein branch paths",
            "diagram multiplicity records when several generated branch paths reach the same canonical signed-PD diagram",
            "each case is certified only when recursive HOMFLY evaluation exhausts its frontier without truncation",
            "this is generated small-diagram coverage evidence, not external table normalization or arbitrary signed-diagram coverage",
        ],
    }
    report["source_notation_summary_consistency"] = (
        _homfly_source_notation_summary_consistency_record(report)
    )
    report["fixture_normalization_metadata_consistency"] = (
        _homfly_fixture_normalization_metadata_consistency_record(report)
    )
    report["case_evidence_consistency"] = (
        _homfly_generated_case_evidence_consistency_record(report)
    )
    arbitrary_diagram_completion_gate = _homfly_arbitrary_diagram_completion_gate(
        evidence_scope="generated_small_signed_pd_coverage",
        source_method=report["method"],
        source_claim_scope=report["claim_scope"],
        result_present=True,
        frontier_exhausted=frontier_count == 0 and frontier_case_count == 0,
        frontier_count=frontier_count,
        frontier_case_count=frontier_case_count,
        frontier_reasons=frontier_reasons,
        frontier_reason_counts=report["frontier_reason_counts"],
        frontier_witnesses=frontier_witnesses,
        truncated=truncated_count > 0,
        truncated_case_count=truncated_count,
        terminal_contribution_matches_result=(
            all(
                evidence.get("terminal_contribution_matches_result", False)
                for evidence in terminal_audit_applicable
            )
            if terminal_audit_applicable
            else None
        ),
        terminal_contribution_audit_skipped=not bool(terminal_audit_applicable),
        certification_blockers=aggregate_certification_blockers,
        certification_blocker_detail_count=(
            aggregate_certification_blocker_detail_count
        ),
        certification_blocker_code_counts=_homfly_blocker_code_counts(
            aggregate_certification_blockers
        ),
        certification_blocker_detail_code_counts=(
            aggregate_certification_blocker_detail_code_counts
        ),
        case_count=case_count,
        certified_case_count=certified_count,
        uncertified_case_count=case_count - certified_count,
        skipped_case_count=skipped_count,
        max_depth=max_depth,
        max_nodes=max_nodes,
        branch_depth=branch_depth,
        source_notations=selected_notations,
        source_summary_consistency_matched=report[
            "source_notation_summary_consistency"
        ]["matched"],
        case_evidence_consistency_matched=report["case_evidence_consistency"][
            "matched"
        ],
        blocker_detail_code_count_consistency_matched=report[
            "case_evidence_consistency"
        ]["blocker_detail_code_count_consistency"]["matched"],
    )
    report["arbitrary_diagram_completion_gate"] = (
        arbitrary_diagram_completion_gate
    )
    report["homfly_completion_blocker_details"] = (
        _homfly_completion_blocker_details(
            full_table_normalization_certified=False,
            arbitrary_diagram_coverage_certified=False,
            arbitrary_diagram_completion_gate=arbitrary_diagram_completion_gate,
        )
    )
    report["homfly_completion_blocker_detail_count"] = len(
        report["homfly_completion_blocker_details"]
    )
    report["homfly_completion_blocker_detail_code_counts"] = (
        _homfly_blocker_detail_code_counts(
            report["homfly_completion_blocker_details"]
        )
    )
    return report


def _homfly_fixture_normalization_metadata_row(fixture) -> dict:
    return {
        "source_notation": fixture.notation,
        "fixture_name": fixture.name,
        "fixture_kind": fixture.kind,
        "fixture_source": fixture.source,
        "fixture_source_url": fixture.source_url,
        "fixture_expected_homfly_source": fixture.expected_homfly_source,
        "fixture_expected_homfly_note_count": len(fixture.expected_homfly_notes),
        "fixture_expected_homfly_notes": list(fixture.expected_homfly_notes),
        "fixture_convention_note_count": len(fixture.convention_notes),
        "fixture_convention_notes": list(fixture.convention_notes),
        "fixture_has_signed_pd": fixture.has_signed_pd,
        "fixture_has_expected_homfly": fixture.expected_homfly is not None,
        "fixture_full_table_normalization_certified": False,
        "fixture_arbitrary_diagram_coverage_certified": False,
        "fixture_normalization_claim_scope": "fixture_root_metadata_only",
    }


def _homfly_fixture_normalization_metadata(rows: Iterable[dict]) -> dict:
    metadata_rows = [dict(row) for row in rows]
    return {
        "method": "homfly_fixture_normalization_metadata",
        "claim_scope": "fixture_root_metadata_only",
        "metadata_row_count": len(metadata_rows),
        "expected_homfly_source_count": sum(
            1
            for row in metadata_rows
            if row.get("fixture_expected_homfly_source")
        ),
        "source_url_count": sum(
            1 for row in metadata_rows if row.get("fixture_source_url")
        ),
        "signed_pd_fixture_count": sum(
            1 for row in metadata_rows if row.get("fixture_has_signed_pd")
        ),
        "expected_homfly_fixture_count": sum(
            1 for row in metadata_rows if row.get("fixture_has_expected_homfly")
        ),
        "full_table_normalization_certified": False,
        "full_table_normalization_certified_count": 0,
        "arbitrary_diagram_coverage_certified": False,
        "arbitrary_diagram_coverage_certified_count": 0,
        "rows": metadata_rows,
        "notes": [
            "fixture metadata identifies root sources and expected-value provenance only",
            "it is not an external HOMFLY table-normalization certificate",
        ],
    }


def _homfly_source_summary_with_fixture_metadata(
    source_rows: Iterable[dict],
    metadata: dict,
) -> list[dict]:
    metadata_by_notation = {
        str(row.get("source_notation")): row
        for row in metadata.get("rows", [])
        if isinstance(row, dict) and row.get("source_notation") is not None
    }
    output: list[dict] = []
    for row in source_rows:
        merged = dict(row)
        metadata_row = metadata_by_notation.get(str(row.get("source_notation")))
        if metadata_row is not None:
            for key in (
                "fixture_source",
                "fixture_source_url",
                "fixture_expected_homfly_source",
                "fixture_expected_homfly_note_count",
                "fixture_convention_note_count",
                "fixture_has_signed_pd",
                "fixture_has_expected_homfly",
                "fixture_full_table_normalization_certified",
                "fixture_arbitrary_diagram_coverage_certified",
                "fixture_normalization_claim_scope",
            ):
                merged[key] = metadata_row.get(key)
        output.append(merged)
    return output


def _homfly_fixture_normalization_metadata_consistency_record(report: dict) -> dict:
    metadata = report.get("fixture_normalization_metadata")
    metadata_rows = (
        [
            row
            for row in metadata.get("rows", [])
            if isinstance(row, dict)
        ]
        if isinstance(metadata, dict)
        else []
    )
    source_rows = [
        row
        for row in report.get("source_notation_summary", [])
        if isinstance(row, dict)
    ]
    metadata_by_notation = {
        str(row.get("source_notation")): row
        for row in metadata_rows
        if row.get("source_notation") is not None
    }
    source_by_notation = {
        str(row.get("source_notation")): row
        for row in source_rows
        if row.get("source_notation") is not None
    }
    fields = (
        "fixture_source",
        "fixture_source_url",
        "fixture_expected_homfly_source",
        "fixture_expected_homfly_note_count",
        "fixture_convention_note_count",
        "fixture_has_signed_pd",
        "fixture_has_expected_homfly",
        "fixture_full_table_normalization_certified",
        "fixture_arbitrary_diagram_coverage_certified",
        "fixture_normalization_claim_scope",
    )
    mismatch_witnesses: list[dict] = []
    missing_metadata_notations = sorted(
        notation
        for notation in source_by_notation
        if notation not in metadata_by_notation
    )
    extra_metadata_notations = sorted(
        notation
        for notation in metadata_by_notation
        if notation not in source_by_notation
    )
    for notation in sorted(set(metadata_by_notation) & set(source_by_notation)):
        metadata_row = metadata_by_notation[notation]
        source_row = source_by_notation[notation]
        for field in fields:
            if metadata_row.get(field) == source_row.get(field):
                continue
            witness = _homfly_consistency_mismatch_witness(
                kind="fixture_normalization_metadata",
                field=field,
                report_value=metadata_row.get(field),
                source_value=source_row.get(field),
            )
            witness["source_notation"] = notation
            mismatch_witnesses.append(witness)
    metadata_row_count_matches_source_notation_count = (
        len(metadata_rows) == len(source_rows)
    )
    matched = (
        metadata_row_count_matches_source_notation_count
        and not missing_metadata_notations
        and not extra_metadata_notations
        and not mismatch_witnesses
    )
    return {
        "method": "homfly_fixture_normalization_metadata_consistency",
        "metadata_row_count": len(metadata_rows),
        "source_notation_count": len(source_rows),
        "metadata_row_count_matches_source_notation_count": (
            metadata_row_count_matches_source_notation_count
        ),
        "missing_metadata_count": len(missing_metadata_notations),
        "missing_metadata_notations": missing_metadata_notations,
        "extra_metadata_count": len(extra_metadata_notations),
        "extra_metadata_notations": extra_metadata_notations,
        "mismatch_count": len(mismatch_witnesses),
        "first_mismatch": mismatch_witnesses[0] if mismatch_witnesses else None,
        "mismatch_witnesses": mismatch_witnesses[:8],
        "matched": matched,
        "notes": [
            "checks source_notation_summary fixture metadata against the top-level fixture metadata rows",
        ],
    }


def _homfly_diagram_multiplicity_summary(cases: Iterable[dict]) -> dict:
    groups: dict[str, list[dict]] = {}
    oriented_keys: set[tuple[str, str | None]] = set()
    oriented_polynomial_sets: dict[tuple[str, str | None], set[str]] = {}
    for case in cases:
        diagram_key = case.get("diagram_key")
        if diagram_key is None:
            continue
        key = str(diagram_key)
        groups.setdefault(key, []).append(case)
        orientation_key = case.get("orientation_key")
        oriented_key = (
            key,
            str(orientation_key) if orientation_key is not None else None,
        )
        oriented_keys.add(oriented_key)
        homfly_polynomial = case.get("homfly_polynomial")
        if homfly_polynomial is not None:
            oriented_polynomial_sets.setdefault(oriented_key, set()).add(
                str(homfly_polynomial)
            )

    records = []
    duplicate_case_count = 0
    for diagram_key, rows in groups.items():
        case_count = len(rows)
        if case_count > 1:
            duplicate_case_count += case_count - 1
        polynomials = sorted(
            {
                str(row["homfly_polynomial"])
                for row in rows
                if row.get("homfly_polynomial") is not None
            }
        )
        records.append(
            {
                "diagram_key": diagram_key,
                "case_count": case_count,
                "source_notations": sorted(
                    {str(row.get("source_notation")) for row in rows}
                ),
                "source_kinds": sorted(
                    {str(row.get("source_kind")) for row in rows}
                ),
                "case_ids": [str(row.get("case_id")) for row in rows],
                "branch_paths": [
                    list(row.get("branch_path", []))
                    for row in rows
                ],
                "branch_depths": sorted(
                    {int(row.get("branch_depth", 0) or 0) for row in rows}
                ),
                "orientation_key_count": len(
                    {
                        str(row.get("orientation_key"))
                        for row in rows
                        if row.get("orientation_key") is not None
                    }
                ),
                "homfly_polynomials": polynomials,
                "homfly_polynomial_count": len(polynomials),
                "certified_case_count": sum(
                    1 for row in rows if row.get("certified_for_input")
                ),
                "skipped_case_count": sum(1 for row in rows if row.get("skipped")),
                "truncated_case_count": sum(1 for row in rows if row.get("truncated")),
            }
        )

    records.sort(key=lambda item: (-item["case_count"], item["diagram_key"]))
    polynomial_variant_diagram_count = sum(
        1 for row in records if row["homfly_polynomial_count"] > 1
    )
    max_homfly_polynomial_count_per_diagram = max(
        (row["homfly_polynomial_count"] for row in records),
        default=0,
    )
    oriented_polynomial_conflict_count = sum(
        1 for values in oriented_polynomial_sets.values() if len(values) > 1
    )
    max_homfly_polynomial_count_per_oriented_diagram = max(
        (len(values) for values in oriented_polynomial_sets.values()),
        default=0,
    )
    return {
        "method": "homfly_generated_diagram_multiplicity_summary",
        "claim_scope": "generated_small_signed_pd_canonical_diagram_multiplicity",
        "case_count_with_diagram_key": sum(len(rows) for rows in groups.values()),
        "unique_diagram_count": len(groups),
        "unique_oriented_diagram_count": len(oriented_keys),
        "duplicate_diagram_case_count": duplicate_case_count,
        "multi_path_diagram_count": sum(
            1 for rows in groups.values() if len(rows) > 1
        ),
        "max_case_count_per_diagram": max(
            (len(rows) for rows in groups.values()),
            default=0,
        ),
        "polynomial_variant_diagram_count": polynomial_variant_diagram_count,
        "max_homfly_polynomial_count_per_diagram": (
            max_homfly_polynomial_count_per_diagram
        ),
        "oriented_polynomial_conflict_count": oriented_polynomial_conflict_count,
        "max_homfly_polynomial_count_per_oriented_diagram": (
            max_homfly_polynomial_count_per_oriented_diagram
        ),
        "diagrams": records,
        "notes": [
            "groups are keyed by PlanarDiagram.canonical_key() and keep orientation multiplicity separate",
            "canonical polynomial variants are reported separately from same-oriented diagram conflicts",
            "multiplicity is generated coverage evidence only and does not certify arbitrary signed-diagram coverage",
        ],
    }


def _case_count_records_by_int_field(
    cases: Iterable[dict],
    field: str,
    output_key: str,
) -> list[dict]:
    counts: dict[int, int] = {}
    for case in cases:
        value = int(case.get(field, 0) or 0)
        counts[value] = counts.get(value, 0) + 1
    return [
        {output_key: value, "case_count": counts[value]}
        for value in sorted(counts)
    ]


def _case_count_records_by_optional_int_field(
    cases: Iterable[dict],
    field: str,
    output_key: str,
) -> list[dict]:
    counts: dict[int, int] = {}
    for case in cases:
        value = case.get(field)
        if value is None:
            continue
        int_value = int(value)
        counts[int_value] = counts.get(int_value, 0) + 1
    return [
        {output_key: value, "case_count": counts[value]}
        for value in sorted(counts)
    ]


def _case_count_records_by_string_field(
    cases: Iterable[dict],
    field: str,
    output_key: str,
) -> list[dict]:
    counts: dict[str, int] = {}
    for case in cases:
        raw_value = case.get(field)
        value = str(raw_value) if raw_value is not None else "none"
        counts[value] = counts.get(value, 0) + 1
    return [
        {output_key: value, "case_count": counts[value]}
        for value in sorted(counts)
    ]


def _homfly_frontier_reason_count_records(cases: Iterable[dict]) -> list[dict]:
    case_counts: dict[str, int] = {}
    frontier_counts: dict[str, int] = {}
    for case in cases:
        case_frontier_count = int(case.get("frontier_count", 0) or 0)
        for reason in case.get("frontier_reasons", []):
            value = str(reason)
            case_counts[value] = case_counts.get(value, 0) + 1
            frontier_counts[value] = (
                frontier_counts.get(value, 0) + case_frontier_count
            )
    return [
        {
            "frontier_reason": value,
            "case_count": case_counts[value],
            "frontier_count": frontier_counts[value],
        }
        for value in sorted(case_counts)
    ]


def _homfly_merge_case_count_records(
    records: Iterable[dict],
    output_key: str,
) -> list[dict]:
    counts: dict[int | str, int] = {}
    for record in records:
        if output_key not in record:
            continue
        value = record[output_key]
        counts[value] = counts.get(value, 0) + int(record.get("case_count", 0) or 0)
    return [
        {output_key: value, "case_count": counts[value]}
        for value in sorted(counts)
    ]


def _homfly_merge_frontier_reason_count_records(
    records: Iterable[dict],
) -> list[dict]:
    case_counts: dict[str, int] = {}
    frontier_counts: dict[str, int] = {}
    for record in records:
        if "frontier_reason" not in record:
            continue
        value = str(record["frontier_reason"])
        case_counts[value] = case_counts.get(value, 0) + int(
            record.get("case_count", 0) or 0
        )
        frontier_counts[value] = frontier_counts.get(value, 0) + int(
            record.get("frontier_count", 0) or 0
        )
    return [
        {
            "frontier_reason": value,
            "case_count": case_counts[value],
            "frontier_count": frontier_counts[value],
        }
        for value in sorted(case_counts)
    ]


def _homfly_consistency_mismatch_tags(field: str) -> list[str]:
    tags = []
    if "source" in field:
        tags.append("source")
    if "frontier" in field:
        tags.append("frontier")
    if "truncated" in field:
        tags.append("truncation")
    if "branch" in field:
        tags.append("branch")
    if "certified" in field or "uncertified" in field:
        tags.append("certification")
    if "solved_depth" in field:
        tags.append("solved_depth")
    if "count" in field:
        tags.append("count")
    return tags


def _homfly_consistency_mismatch_witness(
    *,
    kind: str,
    field: str,
    report_value,
    source_value,
) -> dict:
    return {
        "kind": kind,
        "field": field,
        "tags": _homfly_consistency_mismatch_tags(field),
        "report_value": report_value,
        "source_value": source_value,
    }


def _homfly_frontier_witness_consistency_record(
    payload: dict,
    *,
    context: dict | None = None,
) -> dict:
    witness_list = (
        list(payload.get("frontier_witnesses", []) or [])
        if isinstance(payload.get("frontier_witnesses", []), list)
        else []
    )
    witness_count = int(payload.get("frontier_witness_count", 0) or 0)
    witness_limit = int(
        payload.get("frontier_witness_limit", _HOMFLY_FRONTIER_WITNESS_LIMIT)
        or _HOMFLY_FRONTIER_WITNESS_LIMIT
    )
    frontier_count = int(payload.get("frontier_count", 0) or 0)
    first_witness = payload.get("first_frontier_witness")
    expected_first_witness = witness_list[0] if witness_list else None
    witnesses_truncated = bool(payload.get("frontier_witnesses_truncated", False))
    expected_truncated_from_count = frontier_count > witness_count
    expected_truncated_from_list = frontier_count > len(witness_list)
    context_fields = {
        key: value
        for key, value in (context or {}).items()
        if value is not None
    }

    witness_count_matches_list_count = witness_count == len(witness_list)
    witness_count_within_limit = witness_count <= witness_limit
    witness_list_count_within_limit = len(witness_list) <= witness_limit
    first_frontier_witness_matches_list = first_witness == expected_first_witness
    truncated_matches_witness_count = (
        witnesses_truncated == expected_truncated_from_count
    )
    truncated_matches_witness_list = (
        witnesses_truncated == expected_truncated_from_list
    )

    mismatch_witnesses = []

    def add_mismatch(kind: str, field: str, report_value, source_value) -> None:
        witness = _homfly_consistency_mismatch_witness(
            kind=kind,
            field=field,
            report_value=report_value,
            source_value=source_value,
        )
        witness.update(context_fields)
        mismatch_witnesses.append(witness)

    if not witness_count_matches_list_count:
        add_mismatch(
            "frontier_witness_count",
            "frontier_witness_count",
            witness_count,
            len(witness_list),
        )
    if not witness_count_within_limit:
        add_mismatch(
            "frontier_witness_limit",
            "frontier_witness_count",
            witness_count,
            {"frontier_witness_limit": witness_limit},
        )
    if not witness_list_count_within_limit:
        add_mismatch(
            "frontier_witness_limit",
            "frontier_witnesses",
            len(witness_list),
            {"frontier_witness_limit": witness_limit},
        )
    if not first_frontier_witness_matches_list:
        add_mismatch(
            "first_frontier_witness",
            "first_frontier_witness",
            first_witness,
            expected_first_witness,
        )
    if not truncated_matches_witness_count:
        add_mismatch(
            "frontier_witnesses_truncated",
            "frontier_witnesses_truncated",
            witnesses_truncated,
            expected_truncated_from_count,
        )
    if not truncated_matches_witness_list:
        add_mismatch(
            "frontier_witnesses_truncated",
            "frontier_witnesses_truncated",
            witnesses_truncated,
            expected_truncated_from_list,
        )

    matched = (
        witness_count_matches_list_count
        and witness_count_within_limit
        and witness_list_count_within_limit
        and first_frontier_witness_matches_list
        and truncated_matches_witness_count
        and truncated_matches_witness_list
    )
    return {
        "method": "homfly_frontier_witness_consistency",
        "matched": matched,
        "frontier_count": frontier_count,
        "frontier_witness_count": witness_count,
        "frontier_witness_list_count": len(witness_list),
        "frontier_witness_limit": witness_limit,
        "frontier_witnesses_truncated": witnesses_truncated,
        "expected_first_frontier_witness": expected_first_witness,
        "expected_frontier_witnesses_truncated_from_count": (
            expected_truncated_from_count
        ),
        "expected_frontier_witnesses_truncated_from_list": (
            expected_truncated_from_list
        ),
        "witness_count_matches_list_count": witness_count_matches_list_count,
        "witness_count_within_limit": witness_count_within_limit,
        "witness_list_count_within_limit": witness_list_count_within_limit,
        "first_frontier_witness_matches_list": (
            first_frontier_witness_matches_list
        ),
        "truncated_matches_witness_count": truncated_matches_witness_count,
        "truncated_matches_witness_list": truncated_matches_witness_list,
        "mismatch_count": len(mismatch_witnesses),
        "first_mismatch": mismatch_witnesses[0] if mismatch_witnesses else None,
        "mismatch_witnesses": mismatch_witnesses[:8],
        "notes": [
            "checks bounded frontier witness count/list/first/truncation fields without expanding the HOMFLY coverage claim",
        ],
    }


def _homfly_source_notation_summary_consistency_record(report: dict) -> dict:
    source_rows = [
        row
        for row in report.get("source_notation_summary", [])
        if isinstance(row, dict)
    ]
    count_fields = (
        "case_count",
        "non_fixture_case_count",
        "certified_case_count",
        "uncertified_case_count",
        "skipped_case_count",
        "truncated_case_count",
        "frontier_count",
        "frontier_case_count",
        "attempt_count",
    )
    distribution_fields = (
        ("solved_depth_counts", "solved_depth"),
        ("branch_depth_counts", "branch_depth"),
        ("certified_branch_depth_counts", "branch_depth"),
        ("uncertified_branch_depth_counts", "branch_depth"),
        ("frontier_branch_depth_counts", "branch_depth"),
        ("truncated_branch_depth_counts", "branch_depth"),
        ("source_kind_counts", "source_kind"),
        ("frontier_source_kind_counts", "source_kind"),
        ("truncated_source_kind_counts", "source_kind"),
        ("branch_counts", "branch"),
        ("bounded_homfly_maturity_path_counts", "bounded_homfly_maturity_path"),
        ("frontier_branch_counts", "branch"),
        ("truncated_branch_counts", "branch"),
    )

    report_count_totals = {
        field: int(report.get(field, 0) or 0)
        for field in count_fields
    }
    source_count_totals = {
        field: sum(int(row.get(field, 0) or 0) for row in source_rows)
        for field in count_fields
    }
    count_matches = {
        field: report_count_totals[field] == source_count_totals[field]
        for field in count_fields
    }

    report_distribution_totals = {
        field: list(report.get(field, []) or [])
        for field, _output_key in distribution_fields
    }
    source_distribution_totals = {
        field: _homfly_merge_case_count_records(
            (
                record
                for row in source_rows
                for record in (row.get(field, []) or [])
            ),
            output_key,
        )
        for field, output_key in distribution_fields
    }
    distribution_matches = {
        field: report_distribution_totals[field] == source_distribution_totals[field]
        for field, _output_key in distribution_fields
    }

    report_frontier_reason_counts = list(report.get("frontier_reason_counts", []) or [])
    source_frontier_reason_counts = _homfly_merge_frontier_reason_count_records(
        record
        for row in source_rows
        for record in (row.get("frontier_reason_counts", []) or [])
    )
    frontier_reason_counts_matched = (
        report_frontier_reason_counts == source_frontier_reason_counts
    )
    report_frontier_witness_limit = int(
        report.get("frontier_witness_limit", _HOMFLY_FRONTIER_WITNESS_LIMIT)
        or _HOMFLY_FRONTIER_WITNESS_LIMIT
    )
    source_frontier_witnesses: list[dict] = []
    for row in source_rows:
        if len(source_frontier_witnesses) >= report_frontier_witness_limit:
            break
        for witness in row.get("frontier_witnesses", []) or []:
            if len(source_frontier_witnesses) >= report_frontier_witness_limit:
                break
            if isinstance(witness, dict):
                source_frontier_witnesses.append(dict(witness))
    report_frontier_witness_summary = (
        dict(report.get("frontier_witness_summary"))
        if isinstance(report.get("frontier_witness_summary"), dict)
        else _homfly_frontier_witness_summary_record(report)
    )
    source_frontier_witness_summary = _homfly_frontier_witness_summary_record(
        {
            "frontier_count": source_count_totals["frontier_count"],
            "frontier_witness_count": len(source_frontier_witnesses),
            "frontier_witness_limit": report_frontier_witness_limit,
            "frontier_witnesses_truncated": (
                source_count_totals["frontier_count"]
                > len(source_frontier_witnesses)
            ),
            "frontier_witnesses": source_frontier_witnesses,
            "first_frontier_witness": (
                source_frontier_witnesses[0]
                if source_frontier_witnesses
                else None
            ),
            "frontier_reason_counts": source_frontier_reason_counts,
        }
    )
    frontier_witness_summary_matched = (
        report_frontier_witness_summary == source_frontier_witness_summary
    )
    source_notation_count_matches_fixture_count = len(source_rows) == int(
        report.get("fixture_count", 0) or 0
    )
    count_totals_matched = all(count_matches.values())
    distribution_totals_matched = all(distribution_matches.values())
    matched = (
        source_notation_count_matches_fixture_count
        and count_totals_matched
        and distribution_totals_matched
        and frontier_reason_counts_matched
        and frontier_witness_summary_matched
    )
    mismatch_witnesses = []
    if not source_notation_count_matches_fixture_count:
        mismatch_witnesses.append(
            _homfly_consistency_mismatch_witness(
                kind="source_notation_count",
                field="source_notation_count",
                report_value=int(report.get("fixture_count", 0) or 0),
                source_value=len(source_rows),
            )
        )
    for field in count_fields:
        if not count_matches[field]:
            mismatch_witnesses.append(
                _homfly_consistency_mismatch_witness(
                    kind="count_total",
                    field=field,
                    report_value=report_count_totals[field],
                    source_value=source_count_totals[field],
                )
            )
    for field, _output_key in distribution_fields:
        if not distribution_matches[field]:
            mismatch_witnesses.append(
                _homfly_consistency_mismatch_witness(
                    kind="distribution_total",
                    field=field,
                    report_value=report_distribution_totals[field],
                    source_value=source_distribution_totals[field],
                )
            )
    if not frontier_reason_counts_matched:
        mismatch_witnesses.append(
            _homfly_consistency_mismatch_witness(
                kind="frontier_reason_counts",
                field="frontier_reason_counts",
                report_value=report_frontier_reason_counts,
                source_value=source_frontier_reason_counts,
            )
        )
    if not frontier_witness_summary_matched:
        mismatch_witnesses.append(
            _homfly_consistency_mismatch_witness(
                kind="frontier_witness_summary",
                field="frontier_witness_summary",
                report_value=report_frontier_witness_summary,
                source_value=source_frontier_witness_summary,
            )
        )
    return {
        "method": "homfly_source_notation_summary_consistency",
        "source_notation_count": len(source_rows),
        "source_notation_count_matches_fixture_count": (
            source_notation_count_matches_fixture_count
        ),
        "count_totals_matched": count_totals_matched,
        "distribution_totals_matched": distribution_totals_matched,
        "frontier_reason_counts_matched": frontier_reason_counts_matched,
        "frontier_witness_summary_matched": frontier_witness_summary_matched,
        "matched": matched,
        "mismatch_count": len(mismatch_witnesses),
        "first_mismatch": mismatch_witnesses[0] if mismatch_witnesses else None,
        "mismatch_witnesses": mismatch_witnesses,
        "report_count_totals": report_count_totals,
        "source_count_totals": source_count_totals,
        "count_matches": count_matches,
        "report_distribution_totals": report_distribution_totals,
        "source_distribution_totals": source_distribution_totals,
        "distribution_matches": distribution_matches,
        "report_frontier_reason_counts": report_frontier_reason_counts,
        "source_frontier_reason_counts": source_frontier_reason_counts,
        "report_frontier_witness_summary": report_frontier_witness_summary,
        "source_frontier_witness_summary": source_frontier_witness_summary,
        "notes": [
            "checks generated coverage report totals against per-source summary totals without expanding the bounded evidence claim",
        ],
    }


def _homfly_generated_case_evidence_consistency_record(report: dict) -> dict:
    cases = [
        case
        for case in report.get("cases", [])
        if isinstance(case, dict)
    ]
    field_specs = (
        ("homfly_polynomial", "homfly_polynomial"),
        ("certified_for_input", "certified_for_input"),
        ("bounded_homfly_maturity_path", "bounded_homfly_maturity_path"),
        (
            "bounded_homfly_maturity_path_certified",
            "bounded_homfly_maturity_path_certified",
        ),
        ("skipped", "skipped"),
        ("frontier_count", "frontier_count"),
        ("frontier_reason_count", "frontier_reason_count"),
        ("frontier_reasons", "frontier_reasons"),
        ("frontier_witness_count", "frontier_witness_count"),
        ("frontier_witness_limit", "frontier_witness_limit"),
        ("frontier_witnesses_truncated", "frontier_witnesses_truncated"),
        ("frontier_witnesses", "frontier_witnesses"),
        ("first_frontier_witness", "first_frontier_witness"),
        ("frontier_witness_summary", "frontier_witness_summary"),
        ("truncated", "truncated"),
        ("attempt_count", "iterative_attempt_count"),
        ("solved_depth", "iterative_solved_depth"),
    )
    field_matches = {case_field: True for case_field, _ in field_specs}
    mismatch_witnesses = []
    checked_case_count = 0
    missing_evidence_count = 0

    def add_mismatch(
        *,
        kind: str,
        field: str,
        report_value,
        source_value,
        case_id: str | None = None,
    ) -> dict:
        witness = _homfly_consistency_mismatch_witness(
            kind=kind,
            field=field,
            report_value=report_value,
            source_value=source_value,
        )
        if case_id is not None:
            witness["case_id"] = case_id
        mismatch_witnesses.append(witness)
        return witness

    report_completion_blockers = list(report.get("homfly_completion_blockers", []))
    report_completion_detail_codes = [
        str(row.get("code"))
        for row in report.get("homfly_completion_blocker_details", [])
        if isinstance(row, dict)
    ]
    report_completion_blocker_code_counts = _homfly_blocker_code_counts(
        report_completion_blockers
    )
    report_completion_detail_code_counts = _homfly_blocker_detail_code_counts(
        report.get("homfly_completion_blocker_details", [])
    )
    stored_report_completion_blocker_code_counts = (
        _homfly_normalized_code_count_records(
            report.get(
                "homfly_completion_blocker_code_counts",
                report_completion_blocker_code_counts,
            )
            or report_completion_blocker_code_counts,
            "blocker_count",
        )
    )
    stored_report_completion_detail_code_counts = (
        _homfly_normalized_code_count_records(
            report.get(
                "homfly_completion_blocker_detail_code_counts",
                report_completion_detail_code_counts,
            )
            or report_completion_detail_code_counts,
            "detail_count",
        )
    )
    evidence_rows = []
    completion_blocker_codes_matched = True
    completion_blocker_detail_codes_matched = True
    blocker_code_count_mismatch_witnesses = []
    case_completion_blocker_detail_code_count_mismatches = []
    top_level_completion_blocker_code_counts_matched = (
        stored_report_completion_blocker_code_counts
        == report_completion_blocker_code_counts
    )
    top_level_completion_blocker_detail_code_counts_matched = (
        stored_report_completion_detail_code_counts
        == report_completion_detail_code_counts
    )
    evidence_reported_code_count_fields_matched = True
    case_completion_blocker_code_counts_matched = True
    case_completion_blocker_detail_code_counts_matched = True
    case_frontier_witness_consistency_matched = True
    evidence_frontier_witness_consistency_matched = True
    frontier_witness_consistency_mismatch_witnesses = []

    def add_blocker_count_mismatch(
        *,
        kind: str,
        field: str,
        report_value,
        source_value,
        case_id: str | None = None,
    ) -> None:
        blocker_code_count_mismatch_witnesses.append(
            add_mismatch(
                kind=kind,
                field=field,
                report_value=report_value,
                source_value=source_value,
                case_id=case_id,
            )
        )

    def add_frontier_witness_consistency_mismatches(
        consistency: dict,
        *,
        kind: str,
        case_id: str | None,
    ) -> None:
        for mismatch in consistency.get("mismatch_witnesses", []) or []:
            if not isinstance(mismatch, dict):
                continue
            witness = dict(mismatch)
            witness["kind"] = kind
            witness["frontier_witness_consistency_kind"] = mismatch.get("kind")
            if case_id is not None:
                witness["case_id"] = case_id
            mismatch_witnesses.append(witness)
            frontier_witness_consistency_mismatch_witnesses.append(witness)

    if not top_level_completion_blocker_code_counts_matched:
        add_blocker_count_mismatch(
            kind="report_completion_blocker_code_counts",
            field="homfly_completion_blocker_code_counts",
            report_value=report_completion_blocker_code_counts,
            source_value=stored_report_completion_blocker_code_counts,
        )
    if not top_level_completion_blocker_detail_code_counts_matched:
        add_blocker_count_mismatch(
            kind="report_completion_blocker_detail_code_counts",
            field="homfly_completion_blocker_detail_code_counts",
            report_value=report_completion_detail_code_counts,
            source_value=stored_report_completion_detail_code_counts,
        )

    for case in cases:
        evidence = case.get("input_certification_evidence")
        case_id = str(case.get("case_id")) if case.get("case_id") is not None else None
        context = {
            "case_id": case_id,
            "source_notation": case.get("source_notation"),
            "branch_path": list(case.get("branch_path", []) or []),
        }
        case_frontier_witness_consistency = (
            _homfly_frontier_witness_consistency_record(case, context=context)
        )
        if not case_frontier_witness_consistency["matched"]:
            case_frontier_witness_consistency_matched = False
            add_frontier_witness_consistency_mismatches(
                case_frontier_witness_consistency,
                kind="case_frontier_witness_consistency",
                case_id=case_id,
            )
        if not isinstance(evidence, dict):
            missing_evidence_count += 1
            add_mismatch(
                kind="case_evidence",
                field="input_certification_evidence",
                report_value=True,
                source_value=False,
                case_id=case_id,
            )
            continue

        checked_case_count += 1
        evidence_rows.append(evidence)
        evidence_frontier_witness_consistency = (
            _homfly_frontier_witness_consistency_record(evidence, context=context)
        )
        if not evidence_frontier_witness_consistency["matched"]:
            evidence_frontier_witness_consistency_matched = False
            add_frontier_witness_consistency_mismatches(
                evidence_frontier_witness_consistency,
                kind="case_evidence_frontier_witness_consistency",
                case_id=case_id,
            )
        evidence_completion_blocker_code_counts = _homfly_blocker_code_counts(
            evidence.get("homfly_completion_blockers", [])
        )
        evidence_completion_detail_code_counts = (
            _homfly_blocker_detail_code_counts(
                evidence.get("homfly_completion_blocker_details", [])
            )
        )
        stored_evidence_completion_blocker_code_counts = (
            _homfly_normalized_code_count_records(
                evidence.get(
                    "homfly_completion_blocker_code_counts",
                    evidence_completion_blocker_code_counts,
                )
                or evidence_completion_blocker_code_counts,
                "blocker_count",
            )
        )
        stored_evidence_completion_detail_code_counts = (
            _homfly_normalized_code_count_records(
                evidence.get(
                    "homfly_completion_blocker_detail_code_counts",
                    evidence_completion_detail_code_counts,
                )
                or evidence_completion_detail_code_counts,
                "detail_count",
            )
        )
        evidence_certification_blocker_code_counts = _homfly_blocker_code_counts(
            evidence.get("certification_blockers", [])
        )
        evidence_certification_detail_code_counts = (
            _homfly_blocker_detail_code_counts(
                evidence.get("certification_blocker_details", [])
            )
        )
        stored_evidence_certification_blocker_code_counts = (
            _homfly_normalized_code_count_records(
                evidence.get(
                    "certification_blocker_code_counts",
                    evidence_certification_blocker_code_counts,
                )
                or evidence_certification_blocker_code_counts,
                "blocker_count",
            )
        )
        stored_evidence_certification_detail_code_counts = (
            _homfly_normalized_code_count_records(
                evidence.get(
                    "certification_blocker_detail_code_counts",
                    evidence_certification_detail_code_counts,
                )
                or evidence_certification_detail_code_counts,
                "detail_count",
            )
        )
        if (
            stored_evidence_completion_blocker_code_counts
            != evidence_completion_blocker_code_counts
        ):
            evidence_reported_code_count_fields_matched = False
            add_blocker_count_mismatch(
                kind="case_completion_blocker_code_count_field",
                field="homfly_completion_blocker_code_counts",
                report_value=evidence_completion_blocker_code_counts,
                source_value=stored_evidence_completion_blocker_code_counts,
                case_id=case_id,
            )
        if (
            stored_evidence_completion_detail_code_counts
            != evidence_completion_detail_code_counts
        ):
            evidence_reported_code_count_fields_matched = False
            add_blocker_count_mismatch(
                kind="case_completion_blocker_detail_code_count_field",
                field="homfly_completion_blocker_detail_code_counts",
                report_value=evidence_completion_detail_code_counts,
                source_value=stored_evidence_completion_detail_code_counts,
                case_id=case_id,
            )
        if (
            stored_evidence_certification_blocker_code_counts
            != evidence_certification_blocker_code_counts
        ):
            evidence_reported_code_count_fields_matched = False
            add_blocker_count_mismatch(
                kind="case_certification_blocker_code_count_field",
                field="certification_blocker_code_counts",
                report_value=evidence_certification_blocker_code_counts,
                source_value=stored_evidence_certification_blocker_code_counts,
                case_id=case_id,
            )
        if (
            stored_evidence_certification_detail_code_counts
            != evidence_certification_detail_code_counts
        ):
            evidence_reported_code_count_fields_matched = False
            add_blocker_count_mismatch(
                kind="case_certification_blocker_detail_code_count_field",
                field="certification_blocker_detail_code_counts",
                report_value=evidence_certification_detail_code_counts,
                source_value=stored_evidence_certification_detail_code_counts,
                case_id=case_id,
            )
        if (
            evidence_completion_blocker_code_counts
            != report_completion_blocker_code_counts
        ):
            case_completion_blocker_code_counts_matched = False
            add_blocker_count_mismatch(
                kind="case_completion_blocker_code_counts",
                field="homfly_completion_blocker_code_counts",
                report_value=report_completion_blocker_code_counts,
                source_value=evidence_completion_blocker_code_counts,
                case_id=case_id,
            )
        if evidence_completion_detail_code_counts != report_completion_detail_code_counts:
            case_completion_blocker_detail_code_counts_matched = False
            mismatch = {
                "case_id": case_id,
                "expected": report_completion_detail_code_counts,
                "observed": evidence_completion_detail_code_counts,
            }
            case_completion_blocker_detail_code_count_mismatches.append(mismatch)
            add_blocker_count_mismatch(
                kind="case_completion_blocker_detail_code_counts",
                field="homfly_completion_blocker_detail_code_counts",
                report_value=report_completion_detail_code_counts,
                source_value=evidence_completion_detail_code_counts,
                case_id=case_id,
            )
        if list(evidence.get("homfly_completion_blockers", [])) != report_completion_blockers:
            completion_blocker_codes_matched = False
            add_mismatch(
                kind="case_completion_blockers",
                field="homfly_completion_blockers",
                report_value=report_completion_blockers,
                source_value=list(evidence.get("homfly_completion_blockers", [])),
                case_id=case_id,
            )
        evidence_detail_codes = [
            str(row.get("code"))
            for row in evidence.get("homfly_completion_blocker_details", [])
            if isinstance(row, dict)
        ]
        if evidence_detail_codes != report_completion_detail_codes:
            completion_blocker_detail_codes_matched = False
            add_mismatch(
                kind="case_completion_blocker_details",
                field="homfly_completion_blocker_details",
                report_value=report_completion_detail_codes,
                source_value=evidence_detail_codes,
                case_id=case_id,
            )

        for case_field, evidence_field in field_specs:
            case_value = case.get(case_field)
            evidence_value = evidence.get(evidence_field)
            if case_value != evidence_value:
                field_matches[case_field] = False
                add_mismatch(
                    kind="case_evidence_field",
                    field=case_field,
                    report_value=case_value,
                    source_value=evidence_value,
                    case_id=case_id,
                )

    evidence_frontier_cases = [
        evidence
        for evidence in evidence_rows
        if int(evidence.get("frontier_count", 0) or 0) > 0
    ]
    aggregate_report_totals = {
        "case_count": int(report.get("case_count", 0) or 0),
        "certified_case_count": int(report.get("certified_case_count", 0) or 0),
        "skipped_case_count": int(report.get("skipped_case_count", 0) or 0),
        "truncated_case_count": int(report.get("truncated_case_count", 0) or 0),
        "frontier_count": int(report.get("frontier_count", 0) or 0),
        "frontier_case_count": int(report.get("frontier_case_count", 0) or 0),
    }
    aggregate_evidence_totals = {
        "case_count": checked_case_count,
        "certified_case_count": sum(
            1 for evidence in evidence_rows if evidence.get("certified_for_input")
        ),
        "skipped_case_count": sum(
            1 for evidence in evidence_rows if evidence.get("skipped")
        ),
        "truncated_case_count": sum(
            1 for evidence in evidence_rows if evidence.get("truncated")
        ),
        "frontier_count": sum(
            int(evidence.get("frontier_count", 0) or 0)
            for evidence in evidence_rows
        ),
        "frontier_case_count": len(evidence_frontier_cases),
    }
    aggregate_matches = {
        field: aggregate_report_totals[field] == aggregate_evidence_totals[field]
        for field in aggregate_report_totals
    }
    for field, matched in aggregate_matches.items():
        if not matched:
            add_mismatch(
                kind="case_evidence_aggregate",
                field=field,
                report_value=aggregate_report_totals[field],
                source_value=aggregate_evidence_totals[field],
            )

    evidence_frontier_reason_counts = _homfly_frontier_reason_count_records(
        evidence_rows
    )
    frontier_reason_counts_matched = (
        list(report.get("frontier_reason_counts", []) or [])
        == evidence_frontier_reason_counts
    )
    if not frontier_reason_counts_matched:
        add_mismatch(
            kind="case_evidence_frontier_reason_counts",
            field="frontier_reason_counts",
            report_value=list(report.get("frontier_reason_counts", []) or []),
            source_value=evidence_frontier_reason_counts,
        )

    report_maturity_path_counts = list(
        report.get("bounded_homfly_maturity_path_counts", []) or []
    )
    evidence_maturity_path_counts = _case_count_records_by_string_field(
        evidence_rows,
        "bounded_homfly_maturity_path",
        "bounded_homfly_maturity_path",
    )
    report_maturity_path_distinct_count = int(
        report.get("bounded_homfly_maturity_path_distinct_count", 0) or 0
    )
    evidence_maturity_path_distinct_count = len(evidence_maturity_path_counts)
    report_maturity_path_certified_count = int(
        report.get("bounded_homfly_maturity_path_certified_count", 0) or 0
    )
    evidence_maturity_path_certified_count = sum(
        1
        for evidence in evidence_rows
        if evidence.get("bounded_homfly_maturity_path_certified", False)
    )
    bounded_homfly_maturity_path_counts_matched = (
        report_maturity_path_counts == evidence_maturity_path_counts
    )
    bounded_homfly_maturity_path_distinct_count_matched = (
        report_maturity_path_distinct_count
        == evidence_maturity_path_distinct_count
    )
    bounded_homfly_maturity_path_certified_count_matched = (
        report_maturity_path_certified_count
        == evidence_maturity_path_certified_count
    )
    if not bounded_homfly_maturity_path_counts_matched:
        add_mismatch(
            kind="case_evidence_maturity_path_counts",
            field="bounded_homfly_maturity_path_counts",
            report_value=report_maturity_path_counts,
            source_value=evidence_maturity_path_counts,
        )
    if not bounded_homfly_maturity_path_distinct_count_matched:
        add_mismatch(
            kind="case_evidence_maturity_path_distinct_count",
            field="bounded_homfly_maturity_path_distinct_count",
            report_value=report_maturity_path_distinct_count,
            source_value=evidence_maturity_path_distinct_count,
        )
    if not bounded_homfly_maturity_path_certified_count_matched:
        add_mismatch(
            kind="case_evidence_maturity_path_certified_count",
            field="bounded_homfly_maturity_path_certified_count",
            report_value=report_maturity_path_certified_count,
            source_value=evidence_maturity_path_certified_count,
        )
    evidence_completion_blocker_code_counts = _homfly_blocker_code_counts(
        code
        for evidence in evidence_rows
        for code in evidence.get("homfly_completion_blockers", [])
    )
    evidence_completion_detail_code_counts = _homfly_blocker_detail_code_counts(
        row
        for evidence in evidence_rows
        for row in evidence.get("homfly_completion_blocker_details", [])
    )
    expected_evidence_completion_blocker_code_counts = (
        _homfly_scale_blocker_code_counts(
            report_completion_blocker_code_counts,
            checked_case_count,
        )
    )
    expected_evidence_completion_detail_code_counts = (
        _homfly_scale_blocker_detail_code_counts(
            report_completion_detail_code_counts,
            checked_case_count,
        )
    )
    completion_blocker_code_count_totals_matched = (
        evidence_completion_blocker_code_counts
        == expected_evidence_completion_blocker_code_counts
    )
    completion_blocker_detail_code_count_totals_matched = (
        evidence_completion_detail_code_counts
        == expected_evidence_completion_detail_code_counts
    )
    if not completion_blocker_code_count_totals_matched:
        add_blocker_count_mismatch(
            kind="aggregate_completion_blocker_code_counts",
            field="homfly_completion_blocker_code_counts",
            report_value=expected_evidence_completion_blocker_code_counts,
            source_value=evidence_completion_blocker_code_counts,
        )
    if not completion_blocker_detail_code_count_totals_matched:
        add_blocker_count_mismatch(
            kind="aggregate_completion_blocker_detail_code_counts",
            field="homfly_completion_blocker_detail_code_counts",
            report_value=expected_evidence_completion_detail_code_counts,
            source_value=evidence_completion_detail_code_counts,
        )

    evidence_certification_blocker_code_counts = _homfly_blocker_code_counts(
        code
        for evidence in evidence_rows
        for code in evidence.get("certification_blockers", [])
    )
    evidence_certification_detail_code_counts = (
        _homfly_blocker_detail_code_counts(
            row
            for evidence in evidence_rows
            for row in evidence.get("certification_blocker_details", [])
        )
    )
    certification_blocker_detail_code_counts_matched = (
        _homfly_code_count_map(
            evidence_certification_blocker_code_counts,
            "blocker_count",
        )
        == _homfly_code_count_map(
            evidence_certification_detail_code_counts,
            "detail_count",
        )
    )
    if not certification_blocker_detail_code_counts_matched:
        add_blocker_count_mismatch(
            kind="aggregate_certification_blocker_detail_code_counts",
            field="certification_blocker_detail_code_counts",
            report_value=evidence_certification_blocker_code_counts,
            source_value=evidence_certification_detail_code_counts,
        )

    blocker_detail_code_count_consistency_matched = (
        missing_evidence_count == 0
        and top_level_completion_blocker_code_counts_matched
        and top_level_completion_blocker_detail_code_counts_matched
        and evidence_reported_code_count_fields_matched
        and case_completion_blocker_code_counts_matched
        and case_completion_blocker_detail_code_counts_matched
        and completion_blocker_code_count_totals_matched
        and completion_blocker_detail_code_count_totals_matched
        and certification_blocker_detail_code_counts_matched
    )
    blocker_detail_code_count_consistency = {
        "method": "homfly_blocker_detail_code_count_consistency",
        "matched": blocker_detail_code_count_consistency_matched,
        "checked_case_count": checked_case_count,
        "missing_evidence_count": missing_evidence_count,
        "top_level_completion_blocker_code_counts_matched": (
            top_level_completion_blocker_code_counts_matched
        ),
        "top_level_completion_blocker_detail_code_counts_matched": (
            top_level_completion_blocker_detail_code_counts_matched
        ),
        "evidence_reported_code_count_fields_matched": (
            evidence_reported_code_count_fields_matched
        ),
        "case_completion_blocker_code_counts_matched": (
            case_completion_blocker_code_counts_matched
        ),
        "case_completion_blocker_detail_code_counts_matched": (
            case_completion_blocker_detail_code_counts_matched
        ),
        "completion_blocker_code_count_totals_matched": (
            completion_blocker_code_count_totals_matched
        ),
        "completion_blocker_detail_code_count_totals_matched": (
            completion_blocker_detail_code_count_totals_matched
        ),
        "certification_blocker_detail_code_counts_matched": (
            certification_blocker_detail_code_counts_matched
        ),
        "report_completion_blocker_code_counts": (
            report_completion_blocker_code_counts
        ),
        "stored_report_completion_blocker_code_counts": (
            stored_report_completion_blocker_code_counts
        ),
        "report_completion_blocker_detail_code_counts": (
            report_completion_detail_code_counts
        ),
        "stored_report_completion_blocker_detail_code_counts": (
            stored_report_completion_detail_code_counts
        ),
        "expected_case_completion_blocker_code_counts": (
            expected_evidence_completion_blocker_code_counts
        ),
        "evidence_completion_blocker_code_counts": (
            evidence_completion_blocker_code_counts
        ),
        "expected_case_completion_blocker_detail_code_counts": (
            expected_evidence_completion_detail_code_counts
        ),
        "evidence_completion_blocker_detail_code_counts": (
            evidence_completion_detail_code_counts
        ),
        "evidence_certification_blocker_code_counts": (
            evidence_certification_blocker_code_counts
        ),
        "evidence_certification_blocker_detail_code_counts": (
            evidence_certification_detail_code_counts
        ),
        "case_completion_blocker_detail_code_count_mismatch_count": len(
            case_completion_blocker_detail_code_count_mismatches
        ),
        "case_completion_blocker_detail_code_count_mismatches": (
            case_completion_blocker_detail_code_count_mismatches[:8]
        ),
        "mismatch_count": len(blocker_code_count_mismatch_witnesses),
        "first_mismatch": (
            blocker_code_count_mismatch_witnesses[0]
            if blocker_code_count_mismatch_witnesses
            else None
        ),
        "mismatch_witnesses": blocker_code_count_mismatch_witnesses[:8],
        "notes": [
            "checks HOMFLY completion blocker detail code counts across the report and nested input-certification evidence",
            "certification blocker detail code counts are aggregated from generated case evidence only",
        ],
    }

    frontier_witness_consistency_matched = (
        missing_evidence_count == 0
        and case_frontier_witness_consistency_matched
        and evidence_frontier_witness_consistency_matched
    )
    frontier_witness_consistency = {
        "method": "homfly_case_frontier_witness_consistency",
        "matched": frontier_witness_consistency_matched,
        "checked_case_count": checked_case_count,
        "missing_evidence_count": missing_evidence_count,
        "case_frontier_witness_consistency_matched": (
            case_frontier_witness_consistency_matched
        ),
        "evidence_frontier_witness_consistency_matched": (
            evidence_frontier_witness_consistency_matched
        ),
        "mismatch_count": len(frontier_witness_consistency_mismatch_witnesses),
        "first_mismatch": (
            frontier_witness_consistency_mismatch_witnesses[0]
            if frontier_witness_consistency_mismatch_witnesses
            else None
        ),
        "mismatch_witnesses": (
            frontier_witness_consistency_mismatch_witnesses[:8]
        ),
        "notes": [
            "checks generated cases and nested input-certification evidence for bounded frontier witness count/list/first/truncation consistency",
        ],
    }

    matched = (
        missing_evidence_count == 0
        and all(field_matches.values())
        and all(aggregate_matches.values())
        and frontier_reason_counts_matched
        and bounded_homfly_maturity_path_counts_matched
        and bounded_homfly_maturity_path_distinct_count_matched
        and bounded_homfly_maturity_path_certified_count_matched
        and completion_blocker_codes_matched
        and completion_blocker_detail_codes_matched
        and frontier_witness_consistency_matched
        and blocker_detail_code_count_consistency_matched
    )
    return {
        "method": "homfly_generated_case_evidence_consistency",
        "matched": matched,
        "case_count": len(cases),
        "checked_case_count": checked_case_count,
        "missing_evidence_count": missing_evidence_count,
        "field_matches": field_matches,
        "aggregate_totals_matched": all(aggregate_matches.values()),
        "aggregate_matches": aggregate_matches,
        "report_aggregate_totals": aggregate_report_totals,
        "evidence_aggregate_totals": aggregate_evidence_totals,
        "frontier_reason_counts_matched": frontier_reason_counts_matched,
        "report_frontier_reason_counts": list(
            report.get("frontier_reason_counts", []) or []
        ),
        "evidence_frontier_reason_counts": evidence_frontier_reason_counts,
        "bounded_homfly_maturity_path_counts_matched": (
            bounded_homfly_maturity_path_counts_matched
        ),
        "bounded_homfly_maturity_path_distinct_count_matched": (
            bounded_homfly_maturity_path_distinct_count_matched
        ),
        "bounded_homfly_maturity_path_certified_count_matched": (
            bounded_homfly_maturity_path_certified_count_matched
        ),
        "report_bounded_homfly_maturity_path_counts": (
            report_maturity_path_counts
        ),
        "evidence_bounded_homfly_maturity_path_counts": (
            evidence_maturity_path_counts
        ),
        "report_bounded_homfly_maturity_path_distinct_count": (
            report_maturity_path_distinct_count
        ),
        "evidence_bounded_homfly_maturity_path_distinct_count": (
            evidence_maturity_path_distinct_count
        ),
        "report_bounded_homfly_maturity_path_certified_count": (
            report_maturity_path_certified_count
        ),
        "evidence_bounded_homfly_maturity_path_certified_count": (
            evidence_maturity_path_certified_count
        ),
        "frontier_witness_consistency": frontier_witness_consistency,
        "frontier_witness_consistency_matched": (
            frontier_witness_consistency_matched
        ),
        "completion_blocker_codes_matched": completion_blocker_codes_matched,
        "completion_blocker_detail_codes_matched": (
            completion_blocker_detail_codes_matched
        ),
        "blocker_detail_code_count_consistency": (
            blocker_detail_code_count_consistency
        ),
        "mismatch_count": len(mismatch_witnesses),
        "first_mismatch": mismatch_witnesses[0] if mismatch_witnesses else None,
        "mismatch_witnesses": mismatch_witnesses[:8],
        "notes": [
            "checks generated case rows against their nested HOMFLY input-certification evidence",
        ],
    }


def _homfly_source_notation_coverage_summary(
    cases: Iterable[dict],
    source_notations: Iterable[str],
) -> list[dict]:
    case_list = list(cases)
    rows: list[dict] = []
    for notation in source_notations:
        notation_cases = [
            case for case in case_list if case.get("source_notation") == notation
        ]
        case_count = len(notation_cases)
        frontier_cases = [
            case
            for case in notation_cases
            if int(case.get("frontier_count", 0) or 0) > 0
        ]
        truncated_cases = [case for case in notation_cases if case.get("truncated")]
        certified_count = sum(
            1 for case in notation_cases if case.get("certified_for_input")
        )
        skipped_count = sum(1 for case in notation_cases if case.get("skipped"))
        truncated_count = sum(1 for case in notation_cases if case.get("truncated"))
        frontier_count = sum(
            int(case.get("frontier_count", 0) or 0) for case in notation_cases
        )
        frontier_case_count = sum(
            1
            for case in notation_cases
            if int(case.get("frontier_count", 0) or 0) > 0
        )
        frontier_reasons = sorted(
            {
                str(reason)
                for case in notation_cases
                for reason in case.get("frontier_reasons", [])
            }
        )
        frontier_reason_counts = _homfly_frontier_reason_count_records(
            notation_cases
        )
        frontier_witnesses = _homfly_generated_frontier_witnesses(notation_cases)
        first_frontier_witness = (
            frontier_witnesses[0] if frontier_witnesses else None
        )
        frontier_witnesses_truncated = frontier_count > len(frontier_witnesses)
        frontier_witness_consistency = _homfly_frontier_witness_consistency_record(
            {
                "frontier_count": frontier_count,
                "frontier_witness_count": len(frontier_witnesses),
                "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
                "frontier_witnesses_truncated": frontier_witnesses_truncated,
                "frontier_witnesses": frontier_witnesses,
                "first_frontier_witness": first_frontier_witness,
            },
            context={"source_notation": str(notation)},
        )
        frontier_witness_summary = _homfly_frontier_witness_summary_record(
            {
                "frontier_count": frontier_count,
                "frontier_witness_count": len(frontier_witnesses),
                "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
                "frontier_witnesses_truncated": frontier_witnesses_truncated,
                "frontier_witnesses": frontier_witnesses,
                "first_frontier_witness": first_frontier_witness,
                "frontier_reason_counts": frontier_reason_counts,
            }
        )
        solved_depths = [
            int(case["solved_depth"])
            for case in notation_cases
            if case.get("solved_depth") is not None
        ]
        multiplicity = _homfly_diagram_multiplicity_summary(notation_cases)
        rows.append(
            {
                "source_notation": str(notation),
                "case_count": case_count,
                "non_fixture_case_count": sum(
                    1
                    for case in notation_cases
                    if case.get("source_kind") != "fixture_root"
                ),
                "certified_case_count": certified_count,
                "bounded_homfly_maturity_path_counts": (
                    _case_count_records_by_string_field(
                        notation_cases,
                        "bounded_homfly_maturity_path",
                        "bounded_homfly_maturity_path",
                    )
                ),
                "bounded_homfly_maturity_path_certified_count": sum(
                    1
                    for case in notation_cases
                    if case.get("bounded_homfly_maturity_path_certified", False)
                ),
                "uncertified_case_count": case_count - certified_count,
                "skipped_case_count": skipped_count,
                "truncated_case_count": truncated_count,
                "frontier_count": frontier_count,
                "frontier_case_count": frontier_case_count,
                "frontier_reason_count": len(frontier_reasons),
                "frontier_reasons": frontier_reasons,
                "frontier_reason_counts": frontier_reason_counts,
                "frontier_witness_count": len(frontier_witnesses),
                "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
                "frontier_witnesses_truncated": frontier_witnesses_truncated,
                "frontier_witnesses": frontier_witnesses,
                "first_frontier_witness": first_frontier_witness,
                "frontier_witness_consistency": frontier_witness_consistency,
                "frontier_witness_summary": frontier_witness_summary,
                "attempt_count": sum(
                    int(case.get("attempt_count", 0) or 0)
                    for case in notation_cases
                ),
                "max_crossing_count": max(
                    (
                        int(case.get("crossing_count", 0) or 0)
                        for case in notation_cases
                    ),
                    default=0,
                ),
                "max_generated_branch_depth": max(
                    (
                        int(case.get("branch_depth", 0) or 0)
                        for case in notation_cases
                    ),
                    default=0,
                ),
                "max_solved_depth": max(solved_depths) if solved_depths else None,
                "solved_depth_counts": _case_count_records_by_optional_int_field(
                    notation_cases,
                    "solved_depth",
                    "solved_depth",
                ),
                "unique_diagram_count": multiplicity["unique_diagram_count"],
                "unique_oriented_diagram_count": multiplicity[
                    "unique_oriented_diagram_count"
                ],
                "duplicate_diagram_case_count": multiplicity[
                    "duplicate_diagram_case_count"
                ],
                "multi_path_diagram_count": multiplicity["multi_path_diagram_count"],
                "max_diagram_case_count": multiplicity["max_case_count_per_diagram"],
                "polynomial_variant_diagram_count": multiplicity[
                    "polynomial_variant_diagram_count"
                ],
                "max_homfly_polynomial_count_per_diagram": multiplicity[
                    "max_homfly_polynomial_count_per_diagram"
                ],
                "oriented_polynomial_conflict_count": multiplicity[
                    "oriented_polynomial_conflict_count"
                ],
                "max_homfly_polynomial_count_per_oriented_diagram": multiplicity[
                    "max_homfly_polynomial_count_per_oriented_diagram"
                ],
                "branch_depth_counts": _case_count_records_by_int_field(
                    notation_cases,
                    "branch_depth",
                    "branch_depth",
                ),
                "certified_branch_depth_counts": _case_count_records_by_int_field(
                    (
                        case
                        for case in notation_cases
                        if case.get("certified_for_input")
                    ),
                    "branch_depth",
                    "branch_depth",
                ),
                "uncertified_branch_depth_counts": _case_count_records_by_int_field(
                    (
                        case
                        for case in notation_cases
                        if not case.get("certified_for_input")
                    ),
                    "branch_depth",
                    "branch_depth",
                ),
                "frontier_branch_depth_counts": _case_count_records_by_int_field(
                    frontier_cases,
                    "branch_depth",
                    "branch_depth",
                ),
                "truncated_branch_depth_counts": _case_count_records_by_int_field(
                    truncated_cases,
                    "branch_depth",
                    "branch_depth",
                ),
                "source_kind_counts": _case_count_records_by_string_field(
                    notation_cases,
                    "source_kind",
                    "source_kind",
                ),
                "frontier_source_kind_counts": _case_count_records_by_string_field(
                    frontier_cases,
                    "source_kind",
                    "source_kind",
                ),
                "truncated_source_kind_counts": _case_count_records_by_string_field(
                    truncated_cases,
                    "source_kind",
                    "source_kind",
                ),
                "branch_counts": _case_count_records_by_string_field(
                    notation_cases,
                    "branch",
                    "branch",
                ),
                "frontier_branch_counts": _case_count_records_by_string_field(
                    frontier_cases,
                    "branch",
                    "branch",
                ),
                "truncated_branch_counts": _case_count_records_by_string_field(
                    truncated_cases,
                    "branch",
                    "branch",
                ),
                "accepted": bool(notation_cases)
                and certified_count == case_count
                and skipped_count == 0
                and truncated_count == 0
                and frontier_count == 0,
            }
        )
    return rows

def _homfly_small_coverage_evaluation_key(
    diagram: PlanarDiagram,
    orientation: PDOrientation | None,
    *,
    max_depth: int,
    max_nodes: int,
) -> tuple[str, str, int, int]:
    return (
        repr(diagram.canonical_key()),
        repr(_orientation_key(orientation)),
        int(max_depth),
        int(max_nodes),
    )


def _homfly_small_coverage_evaluation_fields(
    diagram: PlanarDiagram,
    orientation: PDOrientation | None,
    *,
    max_depth: int,
    max_nodes: int,
) -> dict:
    result = homfly_iterative_certified_evaluation_from_pd(
        diagram,
        orientation=orientation,
        initial_depth=0,
        max_depth=max_depth,
        max_nodes=max_nodes,
    )
    evidence = homfly_input_certification_evidence(result)
    return {
        "crossing_count": diagram.crossing_count,
        "component_count": diagram.component_count,
        "has_orientation": orientation is not None,
        "diagram_key": repr(diagram.canonical_key()),
        "orientation_key": repr(_orientation_key(orientation)),
        "homfly_polynomial": result.get("homfly_polynomial"),
        "certified_for_input": bool(result.get("certified_for_input", False)),
        "bounded_homfly_maturity_path": str(
            evidence.get(
                "bounded_homfly_maturity_path",
                _HOMFLY_MATURITY_NOT_CERTIFIED,
            )
        ),
        "bounded_homfly_maturity_path_certified": bool(
            evidence.get("bounded_homfly_maturity_path_certified", False)
        ),
        "skipped": bool(result.get("skipped", True)),
        "frontier_count": int(evidence.get("frontier_count", 0) or 0),
        "frontier_reason_count": int(evidence.get("frontier_reason_count", 0) or 0),
        "frontier_reasons": list(evidence.get("frontier_reasons", [])),
        "frontier_witness_count": int(
            evidence.get("frontier_witness_count", 0) or 0
        ),
        "frontier_witness_limit": int(
            evidence.get(
                "frontier_witness_limit",
                _HOMFLY_FRONTIER_WITNESS_LIMIT,
            )
            or _HOMFLY_FRONTIER_WITNESS_LIMIT
        ),
        "frontier_witnesses_truncated": bool(
            evidence.get("frontier_witnesses_truncated", False)
        ),
        "frontier_witnesses": list(evidence.get("frontier_witnesses") or []),
        "first_frontier_witness": evidence.get("first_frontier_witness"),
        "frontier_witness_consistency": evidence.get(
            "frontier_witness_consistency",
            _homfly_frontier_witness_consistency_record(evidence),
        ),
        "frontier_witness_summary": evidence.get(
            "frontier_witness_summary",
            _homfly_frontier_witness_summary_record(evidence),
        ),
        "truncated": bool(evidence.get("truncated", False)),
        "solved_depth": result.get("solved_depth"),
        "attempt_count": int(result.get("attempt_count", 0) or 0),
        "result_method": result.get("method"),
        "input_certification_evidence": evidence,
        "notes": list(result.get("notes", [])),
    }


def _homfly_small_coverage_case(
    *,
    source_notation: str,
    source_kind: str,
    crossing_index: int | None,
    branch: str | None,
    branch_depth: int,
    branch_path: list[str],
    parent_case_id: str | None,
    case_id: str,
    diagram: PlanarDiagram,
    orientation: PDOrientation | None,
    max_depth: int,
    max_nodes: int,
    evaluation: dict | None = None,
) -> dict:
    if evaluation is None:
        evaluation = _homfly_small_coverage_evaluation_fields(
            diagram,
            orientation,
            max_depth=max_depth,
            max_nodes=max_nodes,
        )
    return {
        "source_notation": source_notation,
        "source_kind": source_kind,
        "crossing_index": crossing_index,
        "branch": branch,
        "branch_depth": branch_depth,
        "branch_path": list(branch_path),
        "parent_case_id": parent_case_id,
        "case_id": case_id,
        **evaluation,
    }


@lru_cache(maxsize=None)
def _cached_homfly_fixture_source_table_invariant_audit_for_acceptance(
    notation: str,
    max_candidates: int,
    homfly_max_depth: int,
    homfly_max_nodes: int,
) -> dict | None:
    from iroll.topology.pd_fixtures import get_diagram_fixture

    fixture = get_diagram_fixture(notation)
    if (
        fixture.has_signed_pd
        or fixture.expected_homfly is not None
        or not fixture.pd_code
        or not fixture.gauss_code
        or not fixture.source_table_homfly_iroll_normalized
    ):
        return None
    return fixture.source_table_invariant_audit(
        max_candidates=max_candidates,
        compute_homfly=True,
        compute_alexander=True,
        homfly_max_depth=homfly_max_depth,
        homfly_max_nodes=homfly_max_nodes,
    )


def _homfly_source_table_registration_fields_from_audit(
    audit: dict | None,
) -> dict:
    if not isinstance(audit, dict):
        return {
            "source_table_registration_ready": None,
            "source_table_registration_blockers": [],
            "source_table_registration_blocker_count": 0,
            "source_table_registration_blocker_details": {},
        }
    raw_blockers = audit.get("source_table_registration_blockers", [])
    blockers = (
        [str(blocker) for blocker in raw_blockers if blocker not in (None, "")]
        if isinstance(raw_blockers, list)
        else []
    )
    raw_count = audit.get("source_table_registration_blocker_count")
    blocker_count = int(raw_count) if isinstance(raw_count, int) else len(blockers)
    ready_value = audit.get("source_table_registration_ready")
    ready = bool(ready_value) if isinstance(ready_value, bool) else len(blockers) == 0
    details = audit.get("source_table_registration_blocker_details")
    return {
        "source_table_registration_ready": ready,
        "source_table_registration_blockers": blockers,
        "source_table_registration_blocker_count": blocker_count,
        "source_table_registration_blocker_details": (
            details if isinstance(details, dict) else {}
        ),
    }


def _homfly_source_table_registration_summary_consistency_record(
    rows: Iterable[dict],
    *,
    checked_count: int,
    ready_count: int,
    blocked_count: int,
    blocker_count: int,
    blocker_counts: list[dict],
    blocked_notations: list[str],
    ready_notations: list[str],
) -> dict:
    row_list = list(rows)
    registration_rows = [
        row
        for row in row_list
        if isinstance(row.get("source_table_registration_ready"), bool)
    ]
    row_ready_rows = [
        row
        for row in registration_rows
        if row["source_table_registration_ready"]
    ]
    row_blocked_rows = [
        row
        for row in registration_rows
        if not row["source_table_registration_ready"]
    ]
    row_blocker_count = sum(
        int(row.get("source_table_registration_blocker_count", 0) or 0)
        for row in registration_rows
    )
    row_blocker_count_map: dict[str, int] = {}
    row_blocker_count_mismatches: list[dict] = []
    row_blocker_detail_mismatches: list[dict] = []

    for row in registration_rows:
        notation = str(row.get("notation", ""))
        blockers = [
            str(blocker)
            for blocker in row.get("source_table_registration_blockers", []) or []
            if blocker not in (None, "")
        ]
        row_count = int(row.get("source_table_registration_blocker_count", 0) or 0)
        if row_count != len(blockers):
            row_blocker_count_mismatches.append(
                {
                    "kind": "row_blocker_count",
                    "field": "source_table_registration_blocker_count",
                    "notation": notation,
                    "report_value": row_count,
                    "source_value": len(blockers),
                }
            )
        for blocker in blockers:
            row_blocker_count_map[blocker] = (
                row_blocker_count_map.get(blocker, 0) + 1
            )

        details = row.get("source_table_registration_blocker_details")
        if not isinstance(details, dict):
            if details not in (None, {}):
                row_blocker_detail_mismatches.append(
                    {
                        "kind": "row_blocker_details_type",
                        "field": "source_table_registration_blocker_details",
                        "notation": notation,
                        "report_value": details,
                        "source_value": {},
                    }
                )
            continue
        blocker_set = set(blockers)
        orphan_detail_keys = sorted(
            str(key)
            for key in details
            if str(key) not in blocker_set
        )
        if orphan_detail_keys:
            row_blocker_detail_mismatches.append(
                {
                    "kind": "row_blocker_detail_without_blocker",
                    "field": "source_table_registration_blocker_details",
                    "notation": notation,
                    "report_value": orphan_detail_keys,
                    "source_value": blockers,
                }
            )

    row_blocker_counts = [
        {
            "blocker": blocker,
            "fixture_count": row_blocker_count_map[blocker],
        }
        for blocker in sorted(row_blocker_count_map)
    ]
    row_blocked_notations = [str(row["notation"]) for row in row_blocked_rows]
    row_ready_notations = [str(row["notation"]) for row in row_ready_rows]

    checked_count_matches_rows = checked_count == len(registration_rows)
    ready_count_matches_rows = ready_count == len(row_ready_rows)
    blocked_count_matches_rows = blocked_count == len(row_blocked_rows)
    blocker_count_matches_rows = blocker_count == row_blocker_count
    blocker_counts_match_rows = blocker_counts == row_blocker_counts
    blocked_notations_match_rows = blocked_notations == row_blocked_notations
    ready_notations_match_rows = ready_notations == row_ready_notations
    row_blocker_count_matches_list = not row_blocker_count_mismatches
    row_blocker_details_cover_blockers = not row_blocker_detail_mismatches

    mismatch_witnesses: list[dict] = []

    def add_mismatch(
        *,
        kind: str,
        field: str,
        report_value,
        source_value,
    ) -> None:
        mismatch_witnesses.append(
            {
                "kind": kind,
                "field": field,
                "report_value": report_value,
                "source_value": source_value,
            }
        )

    if not checked_count_matches_rows:
        add_mismatch(
            kind="checked_count",
            field="source_table_registration_checked_count",
            report_value=checked_count,
            source_value=len(registration_rows),
        )
    if not ready_count_matches_rows:
        add_mismatch(
            kind="ready_count",
            field="source_table_registration_ready_count",
            report_value=ready_count,
            source_value=len(row_ready_rows),
        )
    if not blocked_count_matches_rows:
        add_mismatch(
            kind="blocked_count",
            field="source_table_registration_blocked_count",
            report_value=blocked_count,
            source_value=len(row_blocked_rows),
        )
    if not blocker_count_matches_rows:
        add_mismatch(
            kind="blocker_count",
            field="source_table_registration_blocker_count",
            report_value=blocker_count,
            source_value=row_blocker_count,
        )
    if not blocker_counts_match_rows:
        add_mismatch(
            kind="blocker_counts",
            field="source_table_registration_blocker_counts",
            report_value=blocker_counts,
            source_value=row_blocker_counts,
        )
    if not blocked_notations_match_rows:
        add_mismatch(
            kind="blocked_notations",
            field="source_table_registration_blocked_notations",
            report_value=blocked_notations,
            source_value=row_blocked_notations,
        )
    if not ready_notations_match_rows:
        add_mismatch(
            kind="ready_notations",
            field="source_table_registration_ready_notations",
            report_value=ready_notations,
            source_value=row_ready_notations,
        )
    mismatch_witnesses.extend(row_blocker_count_mismatches)
    mismatch_witnesses.extend(row_blocker_detail_mismatches)

    matched = all(
        (
            checked_count_matches_rows,
            ready_count_matches_rows,
            blocked_count_matches_rows,
            blocker_count_matches_rows,
            blocker_counts_match_rows,
            blocked_notations_match_rows,
            ready_notations_match_rows,
            row_blocker_count_matches_list,
            row_blocker_details_cover_blockers,
        )
    )
    return {
        "method": "homfly_source_table_registration_summary_consistency",
        "claim_scope": "bounded_source_table_registration_summary_audit",
        "matched": matched,
        "checked_count_matches_rows": checked_count_matches_rows,
        "ready_count_matches_rows": ready_count_matches_rows,
        "blocked_count_matches_rows": blocked_count_matches_rows,
        "blocker_count_matches_rows": blocker_count_matches_rows,
        "blocker_counts_match_rows": blocker_counts_match_rows,
        "blocked_notations_match_rows": blocked_notations_match_rows,
        "ready_notations_match_rows": ready_notations_match_rows,
        "row_blocker_count_matches_list": row_blocker_count_matches_list,
        "row_blocker_details_cover_blockers": row_blocker_details_cover_blockers,
        "report_checked_count": checked_count,
        "reported_checked_count": checked_count,
        "row_checked_count": len(registration_rows),
        "report_ready_count": ready_count,
        "reported_ready_count": ready_count,
        "row_ready_count": len(row_ready_rows),
        "report_blocked_count": blocked_count,
        "reported_blocked_count": blocked_count,
        "row_blocked_count": len(row_blocked_rows),
        "report_blocker_count": blocker_count,
        "reported_blocker_count": blocker_count,
        "row_blocker_count": row_blocker_count,
        "report_blocker_counts": blocker_counts,
        "reported_blocker_counts": blocker_counts,
        "row_blocker_counts": row_blocker_counts,
        "report_blocked_notations": blocked_notations,
        "reported_blocked_notations": blocked_notations,
        "row_blocked_notations": row_blocked_notations,
        "report_ready_notations": ready_notations,
        "reported_ready_notations": ready_notations,
        "row_ready_notations": row_ready_notations,
        "row_blocker_count_mismatches": row_blocker_count_mismatches[:8],
        "row_blocker_detail_mismatches": row_blocker_detail_mismatches[:8],
        "mismatch_count": len(mismatch_witnesses),
        "first_mismatch": mismatch_witnesses[0] if mismatch_witnesses else None,
        "mismatch_witnesses": mismatch_witnesses[:8],
        "notes": [
            "checks HOMFLY source-table registration root aggregate fields against row-level registration diagnostics",
            "this is bounded source-table audit provenance and does not claim complete arbitrary HOMFLY coverage",
        ],
    }


def homfly_fixture_acceptance_report(
    notations: Iterable[str] | None = None,
    *,
    include_unregistered: bool = False,
    max_depth: int = 12,
    max_nodes: int = 2048,
    source_table_max_candidates: int = 8,
    source_table_homfly_max_depth: int = 8,
    source_table_homfly_max_nodes: int = 4096,
) -> dict:
    """Aggregate HOMFLY fixture comparison, mirror, and skein audit evidence."""

    from iroll.topology.pd_fixtures import (
        get_diagram_fixture,
        standard_diagram_fixtures,
    )

    fixtures = (
        [get_diagram_fixture(notation) for notation in notations]
        if notations is not None
        else standard_diagram_fixtures()
    )
    if not include_unregistered:
        fixtures = [
            fixture
            for fixture in fixtures
            if fixture.expected_homfly is not None
        ]

    rows = []
    for fixture in fixtures:
        comparison = homfly_fixture_comparison(
            fixture.notation,
            max_depth=max_depth,
            max_nodes=max_nodes,
        )
        comparison_passed = (
            not comparison["skipped"] and comparison["matched"]
        )
        input_certification_applicable = fixture.expected_homfly is not None
        certified_for_input = bool(comparison.get("certified_for_input", False))
        input_certification_evidence = homfly_input_certification_evidence(
            comparison.get("result")
        )
        full_table_normalization_certified = bool(
            comparison.get("full_table_normalization_certified", False)
        )
        source_table_audit = (
            _cached_homfly_fixture_source_table_invariant_audit_for_acceptance(
                fixture.notation,
                source_table_max_candidates,
                source_table_homfly_max_depth,
                source_table_homfly_max_nodes,
            )
            if include_unregistered
            and fixture.expected_homfly is None
            else None
        )
        source_table_registration_fields = (
            _homfly_source_table_registration_fields_from_audit(
                source_table_audit
            )
        )

        mirror_audit = None
        mirror_applicable = (
            fixture.has_signed_pd
            and fixture.expected_homfly is not None
            and len(fixture.pd_code or ()) > 0
        )
        if mirror_applicable:
            mirror_audit = homfly_mirror_fixture_comparison(
                fixture.notation,
                max_depth=max_depth,
                max_nodes=max_nodes,
            )
        mirror_passed = (
            mirror_audit is None
            or (not mirror_audit["skipped"] and mirror_audit["matched"])
        )

        skein_audit = None
        skein_applicable = fixture.has_signed_pd and fixture.expected_homfly is not None
        if skein_applicable:
            try:
                skein_audit = homfly_skein_identity_audit_from_pd(
                    fixture.diagram(),
                    orientation=fixture.orientation(),
                    max_depth=max_depth,
                    max_nodes=max_nodes,
                )
            except ValueError as exc:
                skein_audit = {
                    "method": "homfly_skein_identity_audit",
                    "matched": False,
                    "skipped": True,
                    "notes": [
                        "fixture orientation failed during acceptance report",
                        str(exc),
                    ],
                }
        skein_passed = (
            skein_audit is None
            or (not skein_audit["skipped"] and skein_audit["matched"])
        )

        required_check_count = 1 + int(mirror_applicable) + int(skein_applicable)
        passed_check_count = int(comparison_passed)
        if mirror_applicable and mirror_passed:
            passed_check_count += 1
        if skein_applicable and skein_passed:
            passed_check_count += 1
        failed_check_count = required_check_count - passed_check_count
        accepted = comparison_passed and mirror_passed and skein_passed
        row_bounded_homfly_maturity_path = str(
            input_certification_evidence.get(
                "bounded_homfly_maturity_path",
                _HOMFLY_MATURITY_NOT_CERTIFIED,
            )
        )
        if source_table_audit is not None and not input_certification_applicable:
            row_bounded_homfly_maturity_path = (
                _HOMFLY_MATURITY_SOURCE_TABLE_DIAGNOSTIC
            )
        row_bounded_homfly_maturity_path_certified = (
            _bounded_homfly_maturity_path_certified(
                row_bounded_homfly_maturity_path
            )
        )
        rows.append(
            {
                "notation": fixture.notation,
                "name": fixture.name,
                "kind": fixture.kind,
                "component_count": fixture.component_count,
                "source": fixture.source,
                "source_url": fixture.source_url,
                "expected_homfly": fixture.expected_homfly,
                "expected_homfly_source": fixture.expected_homfly_source,
                "comparison_matched": comparison_passed,
                "source_table_invariant_audit_applicable": (
                    source_table_audit is not None
                ),
                "source_table_invariant_audit": source_table_audit,
                **source_table_registration_fields,
                "input_certification_applicable": input_certification_applicable,
                "certified_for_input": certified_for_input,
                "bounded_homfly_maturity_path": row_bounded_homfly_maturity_path,
                "bounded_homfly_maturity_path_certified": (
                    row_bounded_homfly_maturity_path_certified
                ),
                "input_certification_evidence": input_certification_evidence,
                "full_table_normalization_certified": (
                    full_table_normalization_certified
                ),
                "mirror_applicable": mirror_applicable,
                "mirror_matched": mirror_passed if mirror_applicable else None,
                "skein_applicable": skein_applicable,
                "skein_matched": skein_passed if skein_applicable else None,
                "required_check_count": required_check_count,
                "passed_check_count": passed_check_count,
                "failed_check_count": failed_check_count,
                "accepted": accepted,
                "comparison": comparison,
                "mirror_audit": mirror_audit,
                "skein_identity_audit": skein_audit,
                "notes": []
                if accepted
                else [
                    "fixture does not yet satisfy every HOMFLY acceptance-report check",
                ],
            }
        )

    comparison_checked = sum(1 for row in rows if row["expected_homfly"] is not None)
    comparison_matched = sum(1 for row in rows if row["comparison_matched"])
    mirror_checked = sum(1 for row in rows if row["mirror_applicable"])
    mirror_matched = sum(1 for row in rows if row["mirror_matched"] is True)
    skein_checked = sum(1 for row in rows if row["skein_applicable"])
    skein_matched = sum(1 for row in rows if row["skein_matched"] is True)
    required_check_count = sum(row["required_check_count"] for row in rows)
    passed_check_count = sum(row["passed_check_count"] for row in rows)
    failed_check_count = sum(row["failed_check_count"] for row in rows)
    accepted_count = sum(1 for row in rows if row["accepted"])
    input_certification_applicable_count = sum(
        1 for row in rows if row["input_certification_applicable"]
    )
    certified_input_count = sum(1 for row in rows if row["certified_for_input"])
    uncertified_input_count = (
        input_certification_applicable_count - certified_input_count
    )
    input_certification_rows = [
        row for row in rows if row["input_certification_applicable"]
    ]
    input_certification_recursion_node_count = sum(
        int(row["input_certification_evidence"]["recursion_nodes"])
        for row in input_certification_rows
    )
    input_certification_terminal_reduction_count = sum(
        int(row["input_certification_evidence"]["terminal_reduction_count"])
        for row in input_certification_rows
    )
    input_certification_frontier_count = sum(
        int(row["input_certification_evidence"]["frontier_count"])
        for row in input_certification_rows
    )
    input_certification_truncated_count = sum(
        1
        for row in input_certification_rows
        if row["input_certification_evidence"]["truncated"]
    )
    input_certification_zero_crossing_count = sum(
        1
        for row in input_certification_rows
        if row["input_certification_evidence"]["zero_crossing_certified"]
    )
    input_certification_iterative_attempt_count = sum(
        int(row["input_certification_evidence"]["iterative_attempt_count"])
        for row in input_certification_rows
    )
    input_certification_iterative_solved_count = sum(
        1
        for row in input_certification_rows
        if row["input_certification_evidence"]["iterative_solved_depth"] is not None
    )
    iterative_solved_depths = [
        int(row["input_certification_evidence"]["iterative_solved_depth"])
        for row in input_certification_rows
        if row["input_certification_evidence"]["iterative_solved_depth"] is not None
    ]
    input_certification_iterative_max_solved_depth = (
        max(iterative_solved_depths) if iterative_solved_depths else 0
    )
    input_certification_terminal_contribution_audit_applicable_count = sum(
        1
        for row in input_certification_rows
        if not row["input_certification_evidence"][
            "terminal_contribution_audit_skipped"
        ]
    )
    input_certification_terminal_contribution_matched_count = sum(
        1
        for row in input_certification_rows
        if row["input_certification_evidence"][
            "terminal_contribution_matches_result"
        ]
    )
    input_certification_terminal_contribution_failed_count = (
        input_certification_terminal_contribution_audit_applicable_count
        - input_certification_terminal_contribution_matched_count
    )
    source_table_invariant_audit_applicable_count = sum(
        1 for row in rows if row["source_table_invariant_audit_applicable"]
    )
    source_table_registration_rows = [
        row
        for row in rows
        if isinstance(row.get("source_table_registration_ready"), bool)
    ]
    source_table_registration_ready_count = sum(
        1
        for row in source_table_registration_rows
        if row["source_table_registration_ready"]
    )
    source_table_registration_blocked_rows = [
        row
        for row in source_table_registration_rows
        if not row["source_table_registration_ready"]
    ]
    source_table_registration_blocker_count = sum(
        int(row.get("source_table_registration_blocker_count", 0) or 0)
        for row in source_table_registration_rows
    )
    source_table_registration_blocker_count_map: dict[str, int] = {}
    for row in source_table_registration_rows:
        for blocker in row.get("source_table_registration_blockers", []):
            blocker_key = str(blocker)
            if not blocker_key:
                continue
            source_table_registration_blocker_count_map[blocker_key] = (
                source_table_registration_blocker_count_map.get(blocker_key, 0)
                + 1
            )
    source_table_registration_blocker_counts = [
        {
            "blocker": blocker,
            "fixture_count": source_table_registration_blocker_count_map[blocker],
        }
        for blocker in sorted(source_table_registration_blocker_count_map)
    ]
    source_table_registration_blockers = [
        row["blocker"] for row in source_table_registration_blocker_counts
    ]
    source_table_registration_blocked_notations = [
        row["notation"] for row in source_table_registration_blocked_rows
    ]
    source_table_registration_ready_notations = [
        row["notation"]
        for row in source_table_registration_rows
        if row["source_table_registration_ready"]
    ]
    source_table_registration_summary_consistency = (
        _homfly_source_table_registration_summary_consistency_record(
            rows,
            checked_count=len(source_table_registration_rows),
            ready_count=source_table_registration_ready_count,
            blocked_count=len(source_table_registration_blocked_rows),
            blocker_count=source_table_registration_blocker_count,
            blocker_counts=source_table_registration_blocker_counts,
            blocked_notations=source_table_registration_blocked_notations,
            ready_notations=source_table_registration_ready_notations,
        )
    )
    incomplete = [row["notation"] for row in rows if not row["accepted"]]
    homfly_completion_blockers = _homfly_completion_blockers(
        full_table_normalization_certified=False,
        arbitrary_diagram_coverage_certified=False,
    )
    homfly_completion_blocker_details = _homfly_completion_blocker_details(
        full_table_normalization_certified=False,
        arbitrary_diagram_coverage_certified=False,
    )
    homfly_completion_blocker_code_counts = _homfly_blocker_code_counts(
        homfly_completion_blockers
    )
    homfly_completion_blocker_detail_code_counts = (
        _homfly_blocker_detail_code_counts(homfly_completion_blocker_details)
    )
    bounded_homfly_maturity_path_counts = [
        {
            "bounded_homfly_maturity_path": path,
            "fixture_count": sum(
                1
                for row in rows
                if str(row.get("bounded_homfly_maturity_path")) == path
            ),
        }
        for path in sorted(
            {
                str(row.get("bounded_homfly_maturity_path"))
                for row in rows
            }
        )
    ]
    bounded_homfly_maturity_path_certified_count = sum(
        1
        for row in rows
        if row.get("bounded_homfly_maturity_path_certified", False)
    )

    return {
        "method": "homfly_fixture_acceptance_report",
        "claim_scope": "registered_fixture_acceptance_under_iroll_convention",
        "input_certification_scope": (
            "iterative_recursive_frontier_exhaustion_for_registered_signed_pd_inputs"
        ),
        "bounded_homfly_maturity_path_counts": (
            bounded_homfly_maturity_path_counts
        ),
        "bounded_homfly_maturity_path_distinct_count": len(
            bounded_homfly_maturity_path_counts
        ),
        "bounded_homfly_maturity_path_certified_count": (
            bounded_homfly_maturity_path_certified_count
        ),
        "full_table_normalization_certified": False,
        "arbitrary_diagram_coverage_certified": False,
        "homfly_completion_blockers": homfly_completion_blockers,
        "homfly_completion_blocker_count": len(homfly_completion_blockers),
        "homfly_completion_blocker_code_counts": (
            homfly_completion_blocker_code_counts
        ),
        "homfly_completion_blocker_details": homfly_completion_blocker_details,
        "homfly_completion_blocker_detail_count": len(
            homfly_completion_blocker_details
        ),
        "homfly_completion_blocker_detail_code_counts": (
            homfly_completion_blocker_detail_code_counts
        ),
        "include_unregistered": include_unregistered,
        "fixture_count": len(rows),
        "accepted": accepted_count == len(rows),
        "accepted_count": accepted_count,
        "incomplete_notations": incomplete,
        "comparison_checked_count": comparison_checked,
        "comparison_matched_count": comparison_matched,
        "mirror_checked_count": mirror_checked,
        "mirror_matched_count": mirror_matched,
        "skein_checked_count": skein_checked,
        "skein_matched_count": skein_matched,
        "input_certification_applicable_count": (
            input_certification_applicable_count
        ),
        "certified_input_count": certified_input_count,
        "uncertified_input_count": uncertified_input_count,
        "input_certification_recursion_node_count": (
            input_certification_recursion_node_count
        ),
        "input_certification_terminal_reduction_count": (
            input_certification_terminal_reduction_count
        ),
        "input_certification_frontier_count": input_certification_frontier_count,
        "input_certification_truncated_count": input_certification_truncated_count,
        "input_certification_zero_crossing_count": (
            input_certification_zero_crossing_count
        ),
        "input_certification_iterative_attempt_count": (
            input_certification_iterative_attempt_count
        ),
        "input_certification_iterative_solved_count": (
            input_certification_iterative_solved_count
        ),
        "input_certification_iterative_max_solved_depth": (
            input_certification_iterative_max_solved_depth
        ),
        "input_certification_terminal_contribution_audit_applicable_count": (
            input_certification_terminal_contribution_audit_applicable_count
        ),
        "input_certification_terminal_contribution_matched_count": (
            input_certification_terminal_contribution_matched_count
        ),
        "input_certification_terminal_contribution_failed_count": (
            input_certification_terminal_contribution_failed_count
        ),
        "source_table_invariant_audit_applicable_count": (
            source_table_invariant_audit_applicable_count
        ),
        "source_table_registration_checked_count": len(
            source_table_registration_rows
        ),
        "source_table_registration_ready_count": (
            source_table_registration_ready_count
        ),
        "source_table_registration_blocked_count": len(
            source_table_registration_blocked_rows
        ),
        "source_table_registration_blocker_count": (
            source_table_registration_blocker_count
        ),
        "source_table_registration_blockers": source_table_registration_blockers,
        "source_table_registration_blocker_counts": (
            source_table_registration_blocker_counts
        ),
        "source_table_registration_blocked_notations": (
            source_table_registration_blocked_notations
        ),
        "source_table_registration_ready_notations": (
            source_table_registration_ready_notations
        ),
        "source_table_registration_summary_consistency": (
            source_table_registration_summary_consistency
        ),
        "required_check_count": required_check_count,
        "passed_check_count": passed_check_count,
        "failed_check_count": failed_check_count,
        "fixtures": rows,
        "notes": [
            "this report aggregates algorithmic fixture comparison, mirror, and local skein evidence",
            "input certification means the recursive HOMFLY frontier was exhausted for that registered signed-PD fixture",
            "it is not external HOMFLY table normalization and does not claim arbitrary signed-diagram coverage",
        ],
    }


def homfly_skein_identity_audit_from_pd(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None = None,
    max_crossings: int = 8,
    max_depth: int = 16,
    max_nodes: int = 512,
) -> dict:
    """Check the HOMFLY skein identity at every crossing of a signed PD."""

    if diagram.crossing_count == 0:
        return {
            "method": "homfly_skein_identity_audit",
            "normalization": "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1",
            "crossing_count": 0,
            "checked_crossing_count": 0,
            "matched": True,
            "skipped": False,
            "truncated": False,
            "crossing_audits": [],
            "notes": ["zero-crossing diagrams have no local skein identities to audit"],
        }
    if diagram.crossing_count > max_crossings:
        return {
            "method": "homfly_skein_identity_audit",
            "normalization": "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1",
            "crossing_count": diagram.crossing_count,
            "checked_crossing_count": 0,
            "max_crossings": max_crossings,
            "matched": False,
            "skipped": True,
            "truncated": False,
            "crossing_audits": [],
            "notes": ["crossing_count exceeds max_crossings"],
        }

    root_orientation = _homfly_orientation_or_inferred(diagram, orientation)
    if root_orientation is None:
        return {
            "method": "homfly_skein_identity_audit",
            "normalization": "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1",
            "crossing_count": diagram.crossing_count,
            "checked_crossing_count": 0,
            "max_crossings": max_crossings,
            "matched": False,
            "skipped": True,
            "truncated": False,
            "crossing_audits": [],
            "notes": [
                "valid orientation metadata is required before auditing signed-PD HOMFLY skein identities",
            ],
        }

    issues = root_orientation.validation_issues(diagram)
    if issues:
        return {
            "method": "homfly_skein_identity_audit",
            "normalization": "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1",
            "crossing_count": diagram.crossing_count,
            "checked_crossing_count": 0,
            "max_crossings": max_crossings,
            "matched": False,
            "skipped": True,
            "truncated": False,
            "orientation_issues": issues,
            "crossing_audits": [],
            "notes": ["orientation metadata failed validation"],
        }

    variables = ("a", "z")
    a = MultivariateLaurentPolynomial.monomial(1, (1, 0), variables=variables)
    a_inverse = MultivariateLaurentPolynomial.monomial(-1, (-1, 0), variables=variables)
    z = MultivariateLaurentPolynomial.monomial(1, (0, 1), variables=variables)
    crossing_audits = []

    for crossing_index in range(diagram.crossing_count):
        try:
            relation = homfly_skein_relation(
                diagram,
                crossing_index,
                orientation=root_orientation,
            )
        except ValueError as exc:
            crossing_audits.append(
                {
                    "crossing_index": crossing_index,
                    "matched": False,
                    "skipped": True,
                    "truncated": False,
                    "notes": [str(exc)],
                }
            )
            continue

        positive = _homfly_audit_branch(
            relation["positive"],
            relation["positive_orientation"],
            max_crossings=max_crossings,
            max_depth=max_depth,
            max_nodes=max_nodes,
        )
        negative = _homfly_audit_branch(
            relation["negative"],
            relation["negative_orientation"],
            max_crossings=max_crossings,
            max_depth=max_depth,
            max_nodes=max_nodes,
        )
        smoothed = _homfly_audit_branch(
            relation["smoothed"],
            relation["smoothed_orientation"],
            max_crossings=max_crossings,
            max_depth=max_depth,
            max_nodes=max_nodes,
        )
        branch_records = {
            "positive": positive["summary"],
            "negative": negative["summary"],
            "smoothed": smoothed["summary"],
        }
        skipped = (
            positive["polynomial"] is None
            or negative["polynomial"] is None
            or smoothed["polynomial"] is None
        )
        truncated = any(
            bool(record.get("truncated"))
            for record in branch_records.values()
        )
        if skipped:
            crossing_audits.append(
                {
                    "crossing_index": crossing_index,
                    "matched": False,
                    "skipped": True,
                    "truncated": truncated,
                    "branches": branch_records,
                    "notes": [
                        "at least one skein branch did not produce a completed HOMFLY polynomial",
                    ],
                }
            )
            continue

        lhs = a * positive["polynomial"] + a_inverse * negative["polynomial"]
        rhs = z * smoothed["polynomial"]
        difference = lhs - rhs
        crossing_audits.append(
            {
                "crossing_index": crossing_index,
                "matched": difference.is_zero,
                "skipped": False,
                "truncated": truncated,
                "branches": branch_records,
                "lhs": lhs.format(),
                "rhs": rhs.format(),
                "difference": difference.format(),
                "notes": []
                if difference.is_zero
                else ["skein identity did not match for this crossing"],
            }
        )

    skipped = any(item["skipped"] for item in crossing_audits)
    matched = bool(crossing_audits) and all(item["matched"] for item in crossing_audits)
    truncated = any(item["truncated"] for item in crossing_audits)
    return {
        "method": "homfly_skein_identity_audit",
        "normalization": "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1",
        "crossing_count": diagram.crossing_count,
        "checked_crossing_count": sum(1 for item in crossing_audits if not item["skipped"]),
        "max_crossings": max_crossings,
        "max_depth": max_depth,
        "max_nodes": max_nodes,
        "matched": matched,
        "skipped": skipped,
        "truncated": truncated,
        "crossing_audits": crossing_audits,
        "notes": [
            "each audited crossing is checked by exact sparse Laurent arithmetic in a,z",
            "this verifies internal skein consistency for completed branches but does not provide external table normalization",
        ],
    }


def _homfly_audit_branch(
    diagram: PlanarDiagram,
    orientation: PDOrientation | None,
    *,
    max_crossings: int,
    max_depth: int,
    max_nodes: int,
) -> dict:
    result = homfly_polynomial_from_pd(
        diagram,
        orientation=orientation,
        max_crossings=max_crossings,
        max_depth=max_depth,
        max_nodes=max_nodes,
    )
    polynomial_text = result["homfly_polynomial"]
    recursive = result.get("recursive_evaluation") or {}
    expansion = result.get("expansion") or {}
    summary = {
        "method": result["method"],
        "skipped": bool(result["skipped"]),
        "homfly_polynomial": polynomial_text,
        "crossing_count": diagram.crossing_count,
        "has_orientation": orientation is not None,
        "recursion_nodes": recursive.get("recursion_nodes"),
        "frontier_count": recursive.get("frontier_count", expansion.get("frontier_count")),
        "truncated": bool(recursive.get("truncated") or expansion.get("truncated")),
        "notes": list(result.get("notes", [])),
    }
    if result["skipped"] or polynomial_text is None:
        return {"summary": summary, "polynomial": None}
    return {
        "summary": summary,
        "polynomial": parse_multivariate_laurent_polynomial(
            polynomial_text,
            variables=("a", "z"),
        ),
    }


def _homfly_mirror_transform_candidates(
    polynomial: str | None,
    observed_mirror: str | None,
) -> list[dict]:
    if polynomial is None:
        return []
    candidates = [
        (
            "invert_a_negate_z",
            "P(a^-1,-z)",
            _transform_homfly_polynomial(
                polynomial,
                invert_a=True,
                negate_z=True,
            ),
        ),
        (
            "invert_a_keep_z",
            "P(a^-1,z)",
            _transform_homfly_polynomial(
                polynomial,
                invert_a=True,
                negate_z=False,
            ),
        ),
    ]
    return [
        {
            "convention": convention,
            "substitution": substitution,
            "polynomial": transformed,
            "matched_observed_mirror": observed_mirror == transformed,
        }
        for convention, substitution, transformed in candidates
    ]


def homfly_recursive_evaluation_from_pd(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None = None,
    max_crossings: int = 8,
    max_depth: int = 16,
    max_nodes: int = 256,
) -> dict:
    """Bounded HOMFLY recursion using descending diagrams as unlink terminals."""

    variables = ("a", "z")
    if diagram.crossing_count > max_crossings:
        return {
            "homfly_polynomial": None,
            "method": "skipped",
            "normalization": "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1",
            "max_crossings": max_crossings,
            "max_depth": max_depth,
            "max_nodes": max_nodes,
            "recursion_nodes": 0,
            "cache_hits": 0,
            "terminal_reductions": [],
            "memoized_reductions": [],
            "frontier": [],
            "frontier_count": 0,
            "frontier_reason_count": 1,
            "frontier_reasons": ["crossing_count exceeds max_crossings"],
            "frontier_witness_count": 0,
            "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
            "frontier_witnesses_truncated": False,
            "frontier_witnesses": [],
            "first_frontier_witness": None,
            "frontier_witness_summary": _homfly_frontier_witness_summary_record(
                {
                    "frontier_count": 0,
                    "frontier_witness_count": 0,
                    "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
                    "frontier_witnesses_truncated": False,
                    "frontier_witnesses": [],
                    "first_frontier_witness": None,
                }
            ),
            "truncated": False,
            "skipped": True,
            "notes": ["crossing_count exceeds max_crossings"],
        }

    root_orientation = _homfly_orientation_or_inferred(diagram, orientation)
    nodes: list[dict] = []
    terminal_reductions: list[dict] = []
    memoized_reductions: list[dict] = []
    frontier: list[dict] = []
    memo: dict[tuple, MultivariateLaurentPolynomial] = {}
    cache_hits = 0
    truncated = False

    def evaluate(
        current: PlanarDiagram,
        current_orientation: PDOrientation | None,
        depth: int,
        move: str,
        path_coefficient: MultivariateLaurentPolynomial,
        path: list[str],
    ) -> MultivariateLaurentPolynomial | None:
        nonlocal cache_hits, truncated
        key = (current.canonical_key(), _orientation_key(current_orientation))
        if key in memo:
            cache_hits += 1
            cached_polynomial = memo[key]
            memoized_reductions.append(
                {
                    "depth": depth,
                    "move": move,
                    "coefficient": path_coefficient.format(),
                    "polynomial": cached_polynomial.format(),
                    "contribution": (
                        path_coefficient * cached_polynomial
                    ).format(),
                    "canonical_key": key[0],
                    "has_orientation": current_orientation is not None,
                }
            )
            return cached_polynomial
        if len(nodes) >= max_nodes:
            truncated = True
            frontier.append(
                _expansion_frontier_term(
                    current,
                    current_orientation,
                    coefficient=path_coefficient,
                    move=move,
                    depth=depth,
                    reason="max_nodes",
                    path=path,
                )
            )
            return None

        terminal = homfly_descending_terminal_from_pd(
            current,
            orientation=current_orientation,
        )
        node_id = len(nodes)
        nodes.append(
            {
                "id": node_id,
                "depth": depth,
                "move": move,
                "crossing_count": current.crossing_count,
                "writhe": current.writhe,
                "terminal": bool(terminal["terminal"]),
                "terminal_kind": terminal["terminal_kind"],
                "selected_crossing": None,
                "has_orientation": current_orientation is not None,
            }
        )
        if terminal["terminal"]:
            component_count = int(terminal["component_count"] or 1)
            polynomial = _homfly_unlink_polynomial(component_count)
            terminal_reductions.append(
                {
                    "node": node_id,
                    "depth": depth,
                    "move": move,
                    "terminal_kind": terminal["terminal_kind"],
                    "component_count": component_count,
                    "coefficient": path_coefficient.format(),
                    "polynomial": polynomial.format(),
                    "contribution": (path_coefficient * polynomial).format(),
                }
            )
            memo[key] = polynomial
            return polynomial
        if terminal["skipped"]:
            frontier.append(
                _expansion_frontier_term(
                    current,
                    current_orientation,
                    coefficient=path_coefficient,
                    move=move,
                    depth=depth,
                    reason="; ".join(terminal["notes"]),
                    path=path,
                )
            )
            return None
        if depth >= max_depth:
            frontier.append(
                _expansion_frontier_term(
                    current,
                    current_orientation,
                    coefficient=path_coefficient,
                    move=move,
                    depth=depth,
                    reason="max_depth",
                    path=path,
                )
            )
            return None

        bad_visit = next(
            (
                visit
                for visit in terminal["first_visits"]
                if visit["strand"] == "under"
            ),
            None,
        )
        if bad_visit is None:
            frontier.append(
                _expansion_frontier_term(
                    current,
                    current_orientation,
                    coefficient=path_coefficient,
                    move=move,
                    depth=depth,
                    reason="no under-first crossing found",
                    path=path,
                )
            )
            return None

        crossing_index = int(bad_visit["crossing_index"])
        nodes[-1]["selected_crossing"] = crossing_index
        try:
            relation = homfly_skein_relation(
                current,
                crossing_index,
                orientation=current_orientation,
            )
        except ValueError as exc:
            frontier.append(
                _expansion_frontier_term(
                    current,
                    current_orientation,
                    coefficient=path_coefficient,
                    move=move,
                    depth=depth,
                    reason=str(exc),
                    path=path,
                )
            )
            return None

        sign = current.crossings[crossing_index].sign
        if sign > 0:
            switch_child = relation["negative"]
            switch_orientation = relation["negative_orientation"]
            switch_coefficient = MultivariateLaurentPolynomial.monomial(
                1,
                (-2, 0),
                variables=variables,
            )
            smooth_coefficient = MultivariateLaurentPolynomial.monomial(
                1,
                (-1, 1),
                variables=variables,
            )
        else:
            switch_child = relation["positive"]
            switch_orientation = relation["positive_orientation"]
            switch_coefficient = MultivariateLaurentPolynomial.monomial(
                1,
                (2, 0),
                variables=variables,
            )
            smooth_coefficient = MultivariateLaurentPolynomial.monomial(
                -1,
                (1, 1),
                variables=variables,
            )

        switch_polynomial = evaluate(
            switch_child,
            switch_orientation,
            depth + 1,
            "switch",
            path_coefficient * switch_coefficient,
            [*path, "switch"],
        )
        smooth_polynomial = evaluate(
            relation["smoothed"],
            relation["smoothed_orientation"],
            depth + 1,
            "smooth",
            path_coefficient * smooth_coefficient,
            [*path, "smooth"],
        )
        if switch_polynomial is None or smooth_polynomial is None:
            return None

        polynomial = (
            switch_coefficient * switch_polynomial
            + smooth_coefficient * smooth_polynomial
        )
        memo[key] = polynomial
        return polynomial

    polynomial = evaluate(
        diagram,
        root_orientation,
        0,
        "root",
        MultivariateLaurentPolynomial.constant(1, variables=variables),
        ["root"],
    )
    solved = polynomial is not None and not frontier and not truncated
    frontier_reasons = _homfly_frontier_reasons(frontier)
    frontier_witnesses = _homfly_frontier_witnesses_from_frontier(
        frontier,
        max_depth=max_depth,
        max_nodes=max_nodes,
        recursion_nodes=len(nodes),
    )
    frontier_witness_summary = _homfly_frontier_witness_summary_record(
        {
            "frontier_count": len(frontier),
            "frontier_witness_count": len(frontier_witnesses),
            "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
            "frontier_witnesses_truncated": len(frontier) > len(frontier_witnesses),
            "frontier_witnesses": frontier_witnesses,
            "first_frontier_witness": (
                frontier_witnesses[0] if frontier_witnesses else None
            ),
        }
    )
    return {
        "homfly_polynomial": polynomial.format() if solved else None,
        "method": "bounded_recursive_switching_to_descending",
        "normalization": "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1",
        "max_crossings": max_crossings,
        "max_depth": max_depth,
        "max_nodes": max_nodes,
        "recursion_nodes": len(nodes),
        "cache_hits": cache_hits,
        "terminal_reductions": terminal_reductions,
        "memoized_reductions": memoized_reductions,
        "frontier": frontier,
        "frontier_count": len(frontier),
        "frontier_reason_count": len(frontier_reasons),
        "frontier_reasons": frontier_reasons,
        "frontier_witness_count": len(frontier_witnesses),
        "frontier_witness_limit": _HOMFLY_FRONTIER_WITNESS_LIMIT,
        "frontier_witnesses_truncated": len(frontier) > len(frontier_witnesses),
        "frontier_witnesses": frontier_witnesses,
        "first_frontier_witness": (
            frontier_witnesses[0] if frontier_witnesses else None
        ),
        "frontier_witness_summary": frontier_witness_summary,
        "truncated": truncated,
        "skipped": not solved,
        "notes": [
            "bounded recursion switches the first deterministic under-first crossing and smooths it by the HOMFLY skein relation",
            "zero-crossing and deterministic descending diagrams are evaluated as unlink terminals",
            "complete HOMFLY-PT coverage still requires fixture-backed normalization and broader convention validation",
        ],
    }


def homfly_complete_evaluation_from_pd(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None = None,
) -> dict:
    """Evaluate HOMFLY-PT without depth, node, or crossing cut-offs.

    The evaluator is the standard descending-diagram skein algorithm.  Its
    work list is explicit (rather than Python-recursive), so mathematical
    termination is not coupled to the interpreter recursion limit.  Every
    switch child strictly decreases the number of under-first crossings at a
    fixed crossing count, and every smoothing child strictly decreases the
    crossing count.  The returned transition rows make that lexicographic
    termination argument and every exact Laurent recombination replayable.

    Runtime and memory remain exponential in the worst case.  "Complete"
    describes the absence of correctness cut-offs for finite, valid oriented
    signed-PD inputs; it is not a practical-size or complexity guarantee.
    """

    variables = ("a", "z")
    root_orientation = _homfly_orientation_or_inferred(diagram, orientation)
    if diagram.crossing_count and root_orientation is None:
        return _homfly_complete_invalid_result(
            diagram,
            [
                "complete HOMFLY evaluation requires explicit valid orientation "
                "metadata or an unambiguous signed-PD role orientation"
            ],
        )
    if root_orientation is not None:
        root_issues = root_orientation.validation_issues(diagram)
        if root_issues:
            return _homfly_complete_invalid_result(diagram, root_issues)

    one = MultivariateLaurentPolynomial.constant(1, variables=variables)
    memo: dict[tuple, MultivariateLaurentPolynomial] = {}
    analyses: dict[tuple, dict] = {}
    dependencies: dict[tuple, dict] = {}
    state_rows: dict[tuple, dict] = {}
    terminal_rows: list[dict] = []
    transition_rows: list[dict] = []
    stack: list[tuple[PlanarDiagram, PDOrientation | None, bool]] = [
        (diagram, root_orientation, False)
    ]

    while stack:
        current, current_orientation, expanded = stack.pop()
        key = _homfly_complete_state_key(current, current_orientation)
        if key in memo:
            continue

        analysis = analyses.get(key)
        if analysis is None:
            terminal = homfly_descending_terminal_from_pd(
                current,
                orientation=current_orientation,
            )
            if terminal.get("skipped"):
                return _homfly_complete_invalid_result(
                    diagram,
                    [str(note) for note in terminal.get("notes", [])],
                    state_count=len(analyses),
                )
            bad_visits = [
                visit
                for visit in terminal.get("first_visits", [])
                if visit.get("strand") == "under"
            ]
            analysis = {
                "terminal": bool(terminal.get("terminal")),
                "terminal_kind": terminal.get("terminal_kind"),
                "component_count": int(
                    terminal.get("component_count")
                    or current.component_count
                    or 1
                ),
                "bad_crossing_count": len(bad_visits),
                "first_bad_visit": bad_visits[0] if bad_visits else None,
            }
            analyses[key] = analysis
            state_rows[key] = {
                "state_id": len(state_rows),
                "crossing_count": current.crossing_count,
                "component_count": analysis["component_count"],
                "bad_crossing_count": analysis["bad_crossing_count"],
                "termination_measure": [
                    current.crossing_count,
                    analysis["bad_crossing_count"],
                ],
                "terminal": analysis["terminal"],
                "terminal_kind": analysis["terminal_kind"],
                "canonical_state_sha256": _homfly_complete_state_sha256(
                    current,
                    current_orientation,
                ),
            }

        if analysis["terminal"]:
            polynomial = _homfly_unlink_polynomial(analysis["component_count"])
            memo[key] = polynomial
            state_rows[key]["homfly_polynomial"] = polynomial.format()
            terminal_rows.append(
                {
                    "state_id": state_rows[key]["state_id"],
                    "terminal_kind": analysis["terminal_kind"],
                    "component_count": analysis["component_count"],
                    "normalization_polynomial": polynomial.format(),
                    "normalization_matched": True,
                }
            )
            continue

        dependency = dependencies.get(key)
        if dependency is None:
            first_bad_visit = analysis["first_bad_visit"]
            if first_bad_visit is None:
                return _homfly_complete_invalid_result(
                    diagram,
                    ["non-terminal state has no under-first crossing"],
                    state_count=len(analyses),
                )
            crossing_index = int(first_bad_visit["crossing_index"])
            try:
                relation = homfly_skein_relation(
                    current,
                    crossing_index,
                    orientation=current_orientation,
                )
            except ValueError as exc:
                return _homfly_complete_invalid_result(
                    diagram,
                    [str(exc)],
                    state_count=len(analyses),
                )

            sign = current.crossings[crossing_index].sign
            if sign > 0:
                switch_child = relation["negative"]
                switch_orientation = relation["negative_orientation"]
                switch_coefficient = MultivariateLaurentPolynomial.monomial(
                    1,
                    (-2, 0),
                    variables=variables,
                )
                smooth_coefficient = MultivariateLaurentPolynomial.monomial(
                    1,
                    (-1, 1),
                    variables=variables,
                )
            else:
                switch_child = relation["positive"]
                switch_orientation = relation["positive_orientation"]
                switch_coefficient = MultivariateLaurentPolynomial.monomial(
                    1,
                    (2, 0),
                    variables=variables,
                )
                smooth_coefficient = MultivariateLaurentPolynomial.monomial(
                    -1,
                    (1, 1),
                    variables=variables,
                )
            smooth_child = relation["smoothed"]
            smooth_orientation = relation["smoothed_orientation"]
            switch_key = _homfly_complete_state_key(
                switch_child,
                switch_orientation,
            )
            smooth_key = _homfly_complete_state_key(
                smooth_child,
                smooth_orientation,
            )
            dependency = {
                "crossing_index": crossing_index,
                "sign": sign,
                "switch_child": switch_child,
                "switch_orientation": switch_orientation,
                "switch_key": switch_key,
                "switch_coefficient": switch_coefficient,
                "smooth_child": smooth_child,
                "smooth_orientation": smooth_orientation,
                "smooth_key": smooth_key,
                "smooth_coefficient": smooth_coefficient,
            }
            dependencies[key] = dependency

        if not expanded:
            stack.append((current, current_orientation, True))
            if dependency["smooth_key"] not in memo:
                stack.append(
                    (
                        dependency["smooth_child"],
                        dependency["smooth_orientation"],
                        False,
                    )
                )
            if dependency["switch_key"] not in memo:
                stack.append(
                    (
                        dependency["switch_child"],
                        dependency["switch_orientation"],
                        False,
                    )
                )
            continue

        missing_children = []
        for prefix in ("switch", "smooth"):
            if dependency[f"{prefix}_key"] not in memo:
                missing_children.append(prefix)
        if missing_children:
            stack.append((current, current_orientation, True))
            for prefix in reversed(missing_children):
                stack.append(
                    (
                        dependency[f"{prefix}_child"],
                        dependency[f"{prefix}_orientation"],
                        False,
                    )
                )
            continue

        switch_polynomial = memo[dependency["switch_key"]]
        smooth_polynomial = memo[dependency["smooth_key"]]
        polynomial = (
            dependency["switch_coefficient"] * switch_polynomial
            + dependency["smooth_coefficient"] * smooth_polynomial
        )
        memo[key] = polynomial
        state_rows[key]["homfly_polynomial"] = polynomial.format()

        switch_analysis = analyses[dependency["switch_key"]]
        smooth_analysis = analyses[dependency["smooth_key"]]
        parent_measure = (
            current.crossing_count,
            analysis["bad_crossing_count"],
        )
        switch_measure = (
            dependency["switch_child"].crossing_count,
            switch_analysis["bad_crossing_count"],
        )
        smooth_measure = (
            dependency["smooth_child"].crossing_count,
            smooth_analysis["bad_crossing_count"],
        )
        switch_measure_decreased = switch_measure < parent_measure
        smooth_measure_decreased = smooth_measure < parent_measure
        replay = (
            dependency["switch_coefficient"] * switch_polynomial
            + dependency["smooth_coefficient"] * smooth_polynomial
        )
        transition_rows.append(
            {
                "state_id": state_rows[key]["state_id"],
                "crossing_index": dependency["crossing_index"],
                "parent_sign": dependency["sign"],
                "parent_measure": list(parent_measure),
                "switch_measure": list(switch_measure),
                "smooth_measure": list(smooth_measure),
                "switch_measure_decreased": switch_measure_decreased,
                "smooth_measure_decreased": smooth_measure_decreased,
                "switch_coefficient": dependency[
                    "switch_coefficient"
                ].format(),
                "smooth_coefficient": dependency[
                    "smooth_coefficient"
                ].format(),
                "switch_polynomial": switch_polynomial.format(),
                "smooth_polynomial": smooth_polynomial.format(),
                "recombined_polynomial": replay.format(),
                "parent_polynomial": polynomial.format(),
                "skein_replay_matched": replay == polynomial,
            }
        )

    root_key = _homfly_complete_state_key(diagram, root_orientation)
    polynomial = memo[root_key]
    transition_rows.sort(key=lambda row: int(row["state_id"]))
    terminal_rows.sort(key=lambda row: int(row["state_id"]))
    states = sorted(state_rows.values(), key=lambda row: int(row["state_id"]))
    termination_measure_certified = all(
        row["switch_measure_decreased"] and row["smooth_measure_decreased"]
        for row in transition_rows
    )
    skein_replay_certified = all(
        row["skein_replay_matched"] for row in transition_rows
    )
    terminal_normalization_certified = all(
        row["normalization_matched"] for row in terminal_rows
    )
    certified = (
        termination_measure_certified
        and skein_replay_certified
        and terminal_normalization_certified
        and root_key in memo
    )
    return {
        "homfly_polynomial": polynomial.format() if certified else None,
        "method": "complete_descending_diagram_skein_evaluation",
        "normalization": (
            "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1; "
            "P(unlink_c)=((a-a^-1)/z)^(c-1)"
        ),
        "algorithm_scope": "arbitrary_finite_valid_oriented_signed_pd",
        "resource_cutoffs_used": False,
        "worst_case_complexity": "exponential",
        "crossing_count": diagram.crossing_count,
        "state_count": len(states),
        "transition_count": len(transition_rows),
        "terminal_count": len(terminal_rows),
        "termination_order": "lexicographic(crossing_count,bad_crossing_count)",
        "termination_measure_certified": termination_measure_certified,
        "skein_replay_certified": skein_replay_certified,
        "terminal_normalization_certified": terminal_normalization_certified,
        "certified_for_input": certified,
        "frontier_count": 0,
        "truncated": False,
        "skipped": not certified,
        "states": states,
        "transitions": transition_rows,
        "terminals": terminal_rows,
        "notes": [
            "the explicit work list has no crossing, depth, or node limit",
            "switch branches strictly reduce under-first crossings at fixed crossing count",
            "smoothing branches strictly reduce crossing count",
            "free circle components are retained through diagram.component_count",
            "worst-case runtime and storage are exponential",
        ],
    }


def _homfly_complete_invalid_result(
    diagram: PlanarDiagram,
    notes: Iterable[str],
    *,
    state_count: int = 0,
) -> dict:
    return {
        "homfly_polynomial": None,
        "method": "complete_descending_diagram_skein_evaluation",
        "normalization": (
            "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1; "
            "P(unlink_c)=((a-a^-1)/z)^(c-1)"
        ),
        "algorithm_scope": "arbitrary_finite_valid_oriented_signed_pd",
        "resource_cutoffs_used": False,
        "worst_case_complexity": "exponential",
        "crossing_count": diagram.crossing_count,
        "state_count": state_count,
        "transition_count": 0,
        "terminal_count": 0,
        "termination_order": "lexicographic(crossing_count,bad_crossing_count)",
        "termination_measure_certified": False,
        "skein_replay_certified": False,
        "terminal_normalization_certified": False,
        "certified_for_input": False,
        "frontier_count": 1,
        "truncated": False,
        "skipped": True,
        "states": [],
        "transitions": [],
        "terminals": [],
        "notes": [str(note) for note in notes],
    }


def _homfly_complete_state_key(
    diagram: PlanarDiagram,
    orientation: PDOrientation | None,
) -> tuple:
    return (
        tuple((tuple(crossing.code), crossing.sign) for crossing in diagram.crossings),
        diagram.component_count,
        _orientation_key(orientation),
        tuple(orientation.edge_components) if orientation is not None else None,
    )


def _homfly_complete_state_sha256(
    diagram: PlanarDiagram,
    orientation: PDOrientation | None,
) -> str:
    from hashlib import sha256
    from json import dumps

    payload = {
        "diagram": diagram.to_dict(),
        "orientation": orientation.to_dict() if orientation is not None else None,
    }
    return sha256(
        dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def homfly_descending_terminal_from_pd(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None = None,
) -> dict:
    """Recognize deterministic descending diagrams as HOMFLY unlink terminals."""

    if diagram.crossing_count == 0:
        component_count = diagram.component_count or 1
        return {
            "terminal": True,
            "terminal_kind": "zero_crossing_unlink",
            "is_descending": True,
            "homfly_polynomial": homfly_unlink_polynomial(component_count),
            "component_count": component_count,
            "basepoint_edges": [],
            "first_visits": [],
            "skipped": False,
            "notes": ["zero-crossing diagrams are terminal unlink diagrams"],
        }

    resolved_orientation = _homfly_orientation_or_inferred(diagram, orientation)
    if resolved_orientation is None:
        return {
            "terminal": False,
            "terminal_kind": None,
            "is_descending": False,
            "homfly_polynomial": None,
            "component_count": diagram.component_count,
            "basepoint_edges": [],
            "first_visits": [],
            "skipped": True,
            "notes": [
                "descending terminal recognition requires valid PDOrientation metadata",
            ],
        }

    issues = resolved_orientation.validation_issues(diagram)
    if issues:
        return {
            "terminal": False,
            "terminal_kind": None,
            "is_descending": False,
            "homfly_polynomial": None,
            "component_count": diagram.component_count,
            "basepoint_edges": [],
            "first_visits": [],
            "skipped": True,
            "notes": issues,
        }

    incoming_roles: dict[int, tuple[int, str]] = {}
    for index, crossing in enumerate(resolved_orientation.crossings):
        incoming_roles[crossing.under_in] = (index, "under")
        incoming_roles[crossing.over_in] = (index, "over")

    traversals = resolved_orientation.oriented_component_traversals(diagram)
    basepoint_edges = [item["edges"][0] for item in traversals if item["edges"]]
    first_visits: list[dict] = []
    seen_crossings: set[int] = set()
    descending = True
    for traversal in traversals:
        component = int(traversal["component"])
        for position, edge in enumerate(traversal["edges"]):
            role = incoming_roles.get(edge)
            if role is None:
                return {
                    "terminal": False,
                    "terminal_kind": None,
                    "is_descending": False,
                    "homfly_polynomial": None,
                    "component_count": len(traversals) or diagram.component_count,
                    "basepoint_edges": basepoint_edges,
                    "first_visits": first_visits,
                    "skipped": True,
                    "notes": [f"edge {edge} has no incoming crossing role"],
                }
            crossing_index, strand = role
            if crossing_index in seen_crossings:
                continue
            seen_crossings.add(crossing_index)
            first_visits.append(
                {
                    "crossing_index": crossing_index,
                    "component": component,
                    "edge": edge,
                    "position": position,
                    "strand": strand,
                }
            )
            if strand != "over":
                descending = False

    if len(seen_crossings) != diagram.crossing_count:
        return {
            "terminal": False,
            "terminal_kind": None,
            "is_descending": False,
            "homfly_polynomial": None,
            "component_count": len(traversals) or diagram.component_count,
            "basepoint_edges": basepoint_edges,
            "first_visits": first_visits,
            "skipped": True,
            "notes": ["orientation traversal did not visit every crossing"],
        }

    # ``oriented_component_traversals`` contains only components that still
    # carry PD edges.  Oriented smoothing can also create free circles while
    # other crossings remain; those circles are retained in
    # ``diagram.component_count`` and contribute split-union factors.
    component_count = diagram.component_count or len(traversals) or 1
    if descending:
        return {
            "terminal": True,
            "terminal_kind": "descending_unlink",
            "is_descending": True,
            "homfly_polynomial": homfly_unlink_polynomial(component_count),
            "component_count": component_count,
            "basepoint_edges": basepoint_edges,
            "first_visits": first_visits,
            "skipped": False,
            "notes": [
                "every crossing is first encountered on the over strand under the deterministic component/basepoint order",
                "descending oriented diagrams are evaluated as unlink terminals",
            ],
        }
    return {
        "terminal": False,
        "terminal_kind": None,
        "is_descending": False,
        "homfly_polynomial": None,
        "component_count": component_count,
        "basepoint_edges": basepoint_edges,
        "first_visits": first_visits,
        "skipped": False,
        "notes": [
            "at least one crossing is first encountered on the under strand under the deterministic component/basepoint order",
        ],
    }


def homfly_skein_expansion_from_pd(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None = None,
    max_crossings: int = 8,
    max_depth: int = 2,
    max_nodes: int = 64,
    smoothing: str = "B",
) -> dict:
    """Expand a bounded HOMFLY skein frontier with Laurent coefficients."""

    variables = ("a", "z")
    if diagram.crossing_count > max_crossings:
        return {
            "homfly_polynomial": None,
            "method": "skipped",
            "frontier": [],
            "terminal_terms": [],
            "node_count": 0,
            "truncated": False,
            "skipped": True,
            "notes": ["crossing_count exceeds max_crossings"],
        }

    root_orientation = _homfly_orientation_or_inferred(diagram, orientation)
    queue: list[
        tuple[
            PlanarDiagram,
            PDOrientation | None,
            MultivariateLaurentPolynomial,
            int,
            str,
        ]
    ] = [
        (
            diagram,
            root_orientation,
            MultivariateLaurentPolynomial.constant(1, variables=variables),
            0,
            "root",
        )
    ]
    terminal_terms: list[dict] = []
    frontier: list[dict] = []
    total = MultivariateLaurentPolynomial.constant(0, variables=variables)
    node_count = 0
    truncated = False

    while queue:
        current, current_orientation, coefficient, depth, move = queue.pop(0)
        node_count += 1
        if node_count > max_nodes:
            truncated = True
            break

        terminal_status = _homfly_terminal_status(current, current_orientation)
        if terminal_status["terminal"]:
            component_count = int(terminal_status["component_count"] or 1)
            terminal_polynomial = coefficient * _homfly_unlink_polynomial(component_count)
            total = total + terminal_polynomial
            terminal_terms.append(
                {
                    "coefficient": coefficient.format(),
                    "component_count": component_count,
                    "polynomial": terminal_polynomial.format(),
                    "terminal_kind": terminal_status["terminal_kind"],
                    "move": move,
                    "depth": depth,
                }
            )
            continue

        if depth >= max_depth:
            frontier.append(
                _expansion_frontier_term(
                    current,
                    current_orientation,
                    coefficient=coefficient,
                    move=move,
                    depth=depth,
                    reason="max_depth",
                )
            )
            continue

        crossing_index = _first_expandable_crossing(current)
        if crossing_index is None:
            frontier.append(
                _expansion_frontier_term(
                    current,
                    current_orientation,
                    coefficient=coefficient,
                    move=move,
                    depth=depth,
                    reason="no_expandable_crossing",
                )
            )
            continue

        try:
            relation = homfly_skein_relation(
                current,
                crossing_index,
                smoothing=smoothing,
                orientation=current_orientation,
            )
        except ValueError as exc:
            frontier.append(
                _expansion_frontier_term(
                    current,
                    current_orientation,
                    coefficient=coefficient,
                    move=move,
                    depth=depth,
                    reason=str(exc),
                )
            )
            continue

        sign = current.crossings[crossing_index].sign
        if sign > 0:
            switch_coefficient = coefficient * MultivariateLaurentPolynomial.monomial(
                1,
                (-2, 0),
                variables=variables,
            )
            smooth_coefficient = coefficient * MultivariateLaurentPolynomial.monomial(
                1,
                (-1, 1),
                variables=variables,
            )
            switch_child = relation["negative"]
            switch_orientation = relation["negative_orientation"]
        else:
            switch_coefficient = coefficient * MultivariateLaurentPolynomial.monomial(
                1,
                (2, 0),
                variables=variables,
            )
            smooth_coefficient = coefficient * MultivariateLaurentPolynomial.monomial(
                -1,
                (1, 1),
                variables=variables,
            )
            switch_child = relation["positive"]
            switch_orientation = relation["positive_orientation"]

        queue.append(
            (
                switch_child,
                switch_orientation,
                switch_coefficient,
                depth + 1,
                "switch",
            )
        )
        queue.append(
            (
                relation["smoothed"],
                relation["smoothed_orientation"],
                smooth_coefficient,
                depth + 1,
                "smooth",
            )
        )

    solved = not frontier and not truncated
    return {
        "homfly_polynomial": total.format() if solved else None,
        "method": "bounded_skein_expansion",
        "normalization": "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1",
        "max_crossings": max_crossings,
        "max_depth": max_depth,
        "max_nodes": max_nodes,
        "node_count": node_count,
        "terminal_terms": terminal_terms,
        "frontier": frontier,
        "frontier_count": len(frontier),
        "truncated": truncated,
        "skipped": False,
        "notes": [
            "frontier coefficients are exact Laurent monomials/polynomials in a,z",
            "zero-crossing and deterministic descending diagrams are evaluated as unlink terminals",
            "remaining non-terminal frontier diagrams require more reductions before this is a full HOMFLY evaluator",
        ],
    }


def _homfly_unlink_polynomial(component_count: int) -> MultivariateLaurentPolynomial:
    if component_count < 1:
        raise ValueError("component_count must be positive")
    variables = ("a", "z")
    factor = MultivariateLaurentPolynomial.from_dict(
        {
            (1, -1): 1,
            (-1, -1): -1,
        },
        variables=variables,
    )
    polynomial = MultivariateLaurentPolynomial.constant(1, variables=variables)
    for _ in range(component_count - 1):
        polynomial = polynomial * factor
    return polynomial


def homfly_skein_trace_from_pd(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None = None,
    max_crossings: int = 8,
    max_depth: int = 2,
    max_nodes: int = 64,
    smoothing: str = "B",
) -> dict:
    """Build a bounded, memo-friendly HOMFLY skein expansion trace.

    This function records the finite expansion graph used by the future
    evaluator. It deliberately does not claim a polynomial for non-terminal
    diagrams because a complete evaluator also needs an oriented smoothing
    convention and descending-diagram terminal recognition.
    """

    if smoothing not in {"A", "B"}:
        raise ValueError("smoothing must be 'A' or 'B'")
    if diagram.crossing_count > max_crossings:
        return {
            "method": "bounded_skein_trace",
            "skipped": True,
            "nodes": [],
            "node_count": 0,
            "truncated": False,
            "notes": ["crossing_count exceeds max_crossings"],
        }

    notes = [
        "relation convention: a P(L+) - a^-1 P(L-) = z P(L0)",
        "trace records signed-PD switching and oriented smoothing when valid orientation metadata is available",
        "trace recognizes zero-crossing and deterministic descending terminals",
        "trace is not a complete HOMFLY evaluator until recursive switching-to-descending reduction and fixture-backed normalization are complete",
    ]
    nodes: list[dict] = []
    root_orientation = _homfly_orientation_or_inferred(diagram, orientation)
    queue: list[tuple[PlanarDiagram, PDOrientation | None, int, int | None, str]] = [
        (diagram, root_orientation, 0, None, "root")
    ]
    seen: dict[tuple, int] = {}
    truncated = False

    while queue:
        current, current_orientation, depth, parent, move = queue.pop(0)
        key = (current.canonical_key(), _orientation_key(current_orientation))
        if key in seen:
            continue
        node_id = len(nodes)
        seen[key] = node_id
        terminal = _homfly_terminal_status(current, current_orientation)
        nodes.append(
            _skein_node(
                current,
                node_id,
                orientation=current_orientation,
                depth=depth,
                parent=parent,
                move=move,
                terminal=terminal,
            )
        )
        if len(nodes) >= max_nodes:
            truncated = bool(queue)
            break
        if depth >= max_depth or terminal["terminal"]:
            continue

        crossing_index = _first_expandable_crossing(current)
        if crossing_index is None:
            continue
        try:
            relation = homfly_skein_relation(
                current,
                crossing_index,
                smoothing=smoothing,
                orientation=current_orientation,
            )
        except ValueError as exc:
            nodes[-1]["notes"].append(str(exc))
            continue

        for child_move, child, child_orientation in [
            (
                "switch",
                relation["negative"] if current.crossings[crossing_index].sign > 0 else relation["positive"],
                relation["negative_orientation"]
                if current.crossings[crossing_index].sign > 0
                else relation["positive_orientation"],
            ),
            ("smooth", relation["smoothed"], relation["smoothed_orientation"]),
        ]:
            if len(nodes) + len(queue) >= max_nodes:
                truncated = True
                break
            queue.append((child, child_orientation, depth + 1, node_id, child_move))

    return {
        "method": "bounded_skein_trace",
        "normalization": "a P(L+) - a^-1 P(L-) = z P(L0); P(unknot)=1",
        "smoothing": smoothing,
        "max_crossings": max_crossings,
        "max_depth": max_depth,
        "max_nodes": max_nodes,
        "root": 0 if nodes else None,
        "nodes": nodes,
        "node_count": len(nodes),
        "truncated": truncated,
        "skipped": False,
        "notes": notes,
    }


def homfly_skein_relation(
    diagram: PlanarDiagram,
    crossing_index: int,
    *,
    smoothing: str = "B",
    orientation: PDOrientation | None = None,
) -> dict:
    if crossing_index < 0 or crossing_index >= diagram.crossing_count:
        raise IndexError("crossing_index out of range")
    smoothed_orientation = None
    if orientation is not None:
        smoothed, smoothed_orientation = diagram.oriented_smooth_crossing_with_orientation(
            crossing_index,
            orientation=orientation,
        )
        positive, positive_orientation = _homfly_with_crossing_sign_and_orientation(
            diagram,
            orientation,
            crossing_index,
            sign=1,
        )
        negative, negative_orientation = _homfly_with_crossing_sign_and_orientation(
            diagram,
            orientation,
            crossing_index,
            sign=-1,
        )
    else:
        smoothed = diagram.smooth_crossing(crossing_index, smoothing=smoothing)
        positive = diagram.with_crossing_sign(crossing_index, 1)
        negative = diagram.with_crossing_sign(crossing_index, -1)
        positive_orientation = None
        negative_orientation = None
    return {
        "crossing_index": crossing_index,
        "positive": positive,
        "positive_orientation": positive_orientation,
        "negative": negative,
        "negative_orientation": negative_orientation,
        "smoothed": smoothed,
        "smoothed_orientation": smoothed_orientation,
        "smoothing_method": "oriented" if orientation is not None else smoothing,
        "relation": "a P(L+) - a^-1 P(L-) = z P(L0)",
    }


def _skipped(note: str) -> dict:
    return {
        "homfly_polynomial": None,
        "method": "skipped",
        "table_match": None,
        "skipped": True,
        "notes": [note],
    }


def _fixture_source_orientation_diagnostics(fixture) -> dict:
    if not getattr(fixture, "has_pd_code", False):
        return {
            "method": "fixture_source_orientation_diagnostics",
            "skipped": True,
            "has_pd_code": False,
            "has_gauss_code": False,
            "gauss_code_matched": False,
            "gauss_code_orientation_diagnostics": None,
            "notes": ["fixture does not have a PD source record"],
        }
    if fixture.gauss_code is None:
        return {
            "method": "fixture_source_orientation_diagnostics",
            "skipped": True,
            "has_pd_code": True,
            "has_gauss_code": False,
            "gauss_code_matched": False,
            "gauss_code_orientation_diagnostics": None,
            "notes": [
                "fixture has a PD source record but no source Gauss code to constrain orientation",
            ],
        }

    gauss = fixture.gauss_code_orientation_diagnostics(
        max_orientation_samples=64,
        max_matches=4,
    )
    return {
        "method": "fixture_source_orientation_diagnostics",
        "skipped": False,
        "has_pd_code": True,
        "has_gauss_code": True,
        "gauss_code_matched": bool(gauss["matched"]),
        "gauss_code_orientation_diagnostics": gauss,
        "notes": [
            "source Gauss-code orientation evidence is available",
            "crossing signs and expected HOMFLY value are still not registered",
        ]
        if gauss["matched"]
        else [
            "source Gauss code is registered but no sampled local role assignment matched it",
            "crossing signs and expected HOMFLY value are still not registered",
        ],
    }


def _first_expandable_crossing(diagram: PlanarDiagram) -> int | None:
    return 0 if diagram.crossing_count else None


def _homfly_with_crossing_sign_and_orientation(
    diagram: PlanarDiagram,
    orientation: PDOrientation,
    crossing_index: int,
    *,
    sign: int,
) -> tuple[PlanarDiagram, PDOrientation]:
    if sign not in {-1, 1}:
        raise ValueError("sign must be -1 or 1")
    if diagram.crossings[crossing_index].sign == sign:
        return diagram, orientation

    crossings = list(diagram.crossings)
    orientations = list(orientation.crossings)
    crossing_orientation = orientations[crossing_index]
    switched_orientation = type(crossing_orientation)(
        under_in=crossing_orientation.over_in,
        under_out=crossing_orientation.over_out,
        over_in=crossing_orientation.under_in,
        over_out=crossing_orientation.under_out,
    )
    crossings[crossing_index] = type(diagram.crossings[crossing_index])(
        (
            switched_orientation.under_in,
            switched_orientation.over_in,
            switched_orientation.under_out,
            switched_orientation.over_out,
        ),
        sign=sign,
    )
    orientations[crossing_index] = switched_orientation
    switched_diagram = PlanarDiagram(
        tuple(crossings),
        component_count=diagram.component_count,
        name=diagram.name,
        convention=diagram.convention,
    )
    switched_pd_orientation = PDOrientation(
        tuple(orientations),
        edge_components=orientation.edge_components,
        convention=orientation.convention,
    )
    issues = switched_pd_orientation.validation_issues(switched_diagram)
    if issues:
        raise ValueError("; ".join(issues))
    return switched_diagram, switched_pd_orientation


def _homfly_orientation_or_inferred(
    diagram: PlanarDiagram,
    orientation: PDOrientation | None,
) -> PDOrientation | None:
    if orientation is not None:
        return orientation
    if diagram.crossing_count == 0:
        return None
    try:
        inferred = PDOrientation.from_signed_pd_roles(diagram)
    except ValueError:
        return None
    if inferred.validation_issues(diagram):
        return None
    return inferred


def _homfly_terminal_status(
    diagram: PlanarDiagram,
    orientation: PDOrientation | None,
) -> dict:
    if diagram.crossing_count == 0:
        component_count = diagram.component_count or 1
        return {
            "terminal": True,
            "terminal_kind": "zero_crossing_unlink",
            "component_count": component_count,
            "is_descending": True,
        }
    result = homfly_descending_terminal_from_pd(diagram, orientation=orientation)
    return {
        "terminal": bool(result["terminal"]),
        "terminal_kind": result["terminal_kind"],
        "component_count": result["component_count"],
        "is_descending": bool(result["is_descending"]),
    }


def _skein_node(
    diagram: PlanarDiagram,
    node_id: int,
    *,
    orientation: PDOrientation | None,
    depth: int,
    parent: int | None,
    move: str,
    terminal: dict,
) -> dict:
    return {
        "id": node_id,
        "parent": parent,
        "move": move,
        "depth": depth,
        "crossing_count": diagram.crossing_count,
        "writhe": diagram.writhe,
        "component_count": diagram.component_count,
        "canonical_key": [
            [sign, list(code)]
            for sign, code in diagram.canonical_key()
        ],
        "orientation": orientation.to_dict() if orientation is not None else None,
        "has_orientation": orientation is not None,
        "terminal": bool(terminal["terminal"]),
        "terminal_kind": terminal["terminal_kind"],
        "descending": bool(terminal["is_descending"]),
        "notes": [],
    }


def _orientation_key(orientation: PDOrientation | None) -> tuple | None:
    if orientation is None:
        return None
    return (
        tuple(
            (
                crossing.under_in,
                crossing.under_out,
                crossing.over_in,
                crossing.over_out,
            )
            for crossing in orientation.crossings
        ),
        tuple(orientation.edge_components),
    )


def _expansion_frontier_term(
    diagram: PlanarDiagram,
    orientation: PDOrientation | None,
    *,
    coefficient: MultivariateLaurentPolynomial,
    move: str,
    depth: int,
    reason: str,
    path: Iterable[str] | None = None,
) -> dict:
    return {
        "coefficient": coefficient.format(),
        "move": move,
        "path": list(path) if path is not None else [move],
        "depth": depth,
        "reason": reason,
        "crossing_count": diagram.crossing_count,
        "writhe": diagram.writhe,
        "component_count": diagram.component_count,
        "canonical_key": [
            [sign, list(code)]
            for sign, code in diagram.canonical_key()
        ],
        "orientation": orientation.to_dict() if orientation is not None else None,
        "has_orientation": orientation is not None,
    }
