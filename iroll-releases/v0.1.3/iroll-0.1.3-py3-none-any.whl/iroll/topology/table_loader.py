"""Validation and loading helpers for optional knot/link tables."""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any, Iterable, Literal, Mapping
from urllib.parse import urlparse

TableKind = Literal["knot", "link"]


@dataclass(frozen=True)
class TableValidationIssue:
    path: str
    message: str

    def to_dict(self) -> dict[str, str]:
        return {
            "path": self.path,
            "message": self.message,
        }


class TableValidationError(ValueError):
    """Raised when an imported knot/link table fails schema validation."""

    def __init__(self, issues: Iterable[TableValidationIssue]) -> None:
        self.issues = tuple(issues)
        detail = "; ".join(f"{issue.path}: {issue.message}" for issue in self.issues)
        super().__init__(f"invalid topology table: {detail}")


def load_knot_table_json(
    path: str | Path,
    *,
    expected_convention: str | None = None,
) -> list[dict[str, Any]]:
    """Load and validate knot-table records from JSON."""

    records = _read_records(path, kind="knot")
    assert_valid_knot_table(records, expected_convention=expected_convention)
    return records


def load_link_table_json(
    path: str | Path,
    *,
    expected_convention: str | None = None,
) -> list[dict[str, Any]]:
    """Load and validate link-table records from JSON."""

    records = _read_records(path, kind="link")
    assert_valid_link_table(records, expected_convention=expected_convention)
    return records


def validate_knot_table(
    records: Iterable[Mapping[str, Any]],
    *,
    expected_convention: str | None = None,
) -> list[TableValidationIssue]:
    issues: list[TableValidationIssue] = []
    rows = list(records)
    _validate_records_container(rows, issues)
    _validate_unique_identifiers(rows, issues, primary_key="notation")

    for index, record in enumerate(rows):
        path = f"$[{index}]"
        _require_string(record, "notation", path, issues)
        _require_string(record, "knot_type", path, issues)
        _require_non_negative_int(record, "minimal_crossing_number", path, issues)
        _require_non_negative_int(record, "determinant", path, issues)
        _require_string(record, "alexander_polynomial", path, issues)
        _require_bool(record, "chiral", path, issues)
        _require_optional_string(record, "jones_polynomial", path, issues)
        _require_optional_string(record, "homfly_polynomial", path, issues)
        _validate_aliases(record, path, issues)
        _validate_source_fields(record, path, issues)
        _validate_known_limitations(record, path, issues)
        _validate_convention(
            record,
            path,
            issues,
            expected_convention=expected_convention,
        )
    return issues


def validate_link_table(
    records: Iterable[Mapping[str, Any]],
    *,
    expected_convention: str | None = None,
) -> list[TableValidationIssue]:
    issues: list[TableValidationIssue] = []
    rows = list(records)
    _validate_records_container(rows, issues)
    _validate_unique_identifiers(rows, issues, primary_key="notation")

    for index, record in enumerate(rows):
        path = f"$[{index}]"
        _require_string(record, "notation", path, issues)
        _require_string(record, "link_type", path, issues)
        _require_non_negative_int(record, "minimal_crossing_number", path, issues)
        _require_positive_int(record, "component_count", path, issues)
        _validate_pairwise_linking(record, path, issues)
        _require_optional_string(
            record,
            "multivariable_alexander_polynomial",
            path,
            issues,
        )
        _require_optional_string(record, "jones_polynomial", path, issues)
        _require_optional_string(record, "homfly_polynomial", path, issues)
        _validate_aliases(record, path, issues)
        _validate_source_fields(record, path, issues)
        _validate_known_limitations(record, path, issues)
        _validate_convention(
            record,
            path,
            issues,
            expected_convention=expected_convention,
        )
    return issues


def assert_valid_knot_table(
    records: Iterable[Mapping[str, Any]],
    *,
    expected_convention: str | None = None,
) -> None:
    issues = validate_knot_table(records, expected_convention=expected_convention)
    if issues:
        raise TableValidationError(issues)


def assert_valid_link_table(
    records: Iterable[Mapping[str, Any]],
    *,
    expected_convention: str | None = None,
) -> None:
    issues = validate_link_table(records, expected_convention=expected_convention)
    if issues:
        raise TableValidationError(issues)


def validate_table_file(
    path: str | Path,
    *,
    kind: TableKind,
    expected_convention: str | None = None,
) -> dict[str, Any]:
    records = _read_records(path, kind=kind)
    if kind == "knot":
        issues = validate_knot_table(records, expected_convention=expected_convention)
    elif kind == "link":
        issues = validate_link_table(records, expected_convention=expected_convention)
    else:
        raise ValueError("kind must be 'knot' or 'link'")
    return {
        "kind": kind,
        "path": str(path),
        "record_count": len(records),
        "valid": not issues,
        "issues": [issue.to_dict() for issue in issues],
        "source_metadata_summary": _source_metadata_summary(
            records,
            expected_convention=expected_convention,
        ),
    }


def _read_records(path: str | Path, *, kind: TableKind) -> list[dict[str, Any]]:
    table_path = Path(path)
    payload = json.loads(table_path.read_text(encoding="utf-8"))
    key = "knots" if kind == "knot" else "links"
    if isinstance(payload, list):
        raw_records = payload
    elif isinstance(payload, dict) and isinstance(payload.get(key), list):
        raw_records = payload[key]
    else:
        raise TableValidationError(
            [
                TableValidationIssue(
                    "$",
                    f"expected a list or an object with a '{key}' list",
                )
            ]
        )
    records: list[dict[str, Any]] = []
    for index, record in enumerate(raw_records):
        if not isinstance(record, dict):
            raise TableValidationError(
                [TableValidationIssue(f"$[{index}]", "expected object")]
            )
        records.append(dict(record))
    return records


def _validate_records_container(
    records: list[Mapping[str, Any]],
    issues: list[TableValidationIssue],
) -> None:
    for index, record in enumerate(records):
        if not isinstance(record, Mapping):
            issues.append(TableValidationIssue(f"$[{index}]", "expected object"))


def _validate_unique_identifiers(
    records: list[Mapping[str, Any]],
    issues: list[TableValidationIssue],
    *,
    primary_key: str,
) -> None:
    seen: dict[str, int] = {}
    notation_keys: dict[str, int] = {}
    aliases: dict[str, int] = {}
    for index, record in enumerate(records):
        value = record.get(primary_key)
        if isinstance(value, str):
            key = value.casefold()
            if key in seen:
                issues.append(
                    TableValidationIssue(
                        f"$[{index}].{primary_key}",
                        f"duplicates $[{seen[key]}].{primary_key}",
                    )
                )
            seen[key] = index
            notation_keys[key] = index

    for index, record in enumerate(records):
        raw_aliases = record.get("aliases", [])
        if isinstance(raw_aliases, list):
            for alias in raw_aliases:
                if not isinstance(alias, str):
                    continue
                key = alias.casefold()
                if key in notation_keys:
                    issues.append(
                        TableValidationIssue(
                            f"$[{index}].aliases",
                            "alias conflicts with an existing notation",
                        )
                    )
                if key in aliases:
                    issues.append(
                        TableValidationIssue(
                            f"$[{index}].aliases",
                            f"alias duplicates $[{aliases[key]}].aliases",
                        )
                    )
                aliases[key] = index


def _require_string(
    record: Mapping[str, Any],
    key: str,
    path: str,
    issues: list[TableValidationIssue],
) -> None:
    value = record.get(key)
    if not isinstance(value, str) or not value.strip():
        issues.append(TableValidationIssue(f"{path}.{key}", "expected non-empty string"))


def _require_optional_string(
    record: Mapping[str, Any],
    key: str,
    path: str,
    issues: list[TableValidationIssue],
) -> None:
    value = record.get(key)
    if value is not None and not isinstance(value, str):
        issues.append(TableValidationIssue(f"{path}.{key}", "expected string or null"))


def _require_bool(
    record: Mapping[str, Any],
    key: str,
    path: str,
    issues: list[TableValidationIssue],
) -> None:
    value = record.get(key)
    if not isinstance(value, bool):
        issues.append(TableValidationIssue(f"{path}.{key}", "expected bool"))


def _require_non_negative_int(
    record: Mapping[str, Any],
    key: str,
    path: str,
    issues: list[TableValidationIssue],
) -> None:
    value = record.get(key)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        issues.append(TableValidationIssue(f"{path}.{key}", "expected non-negative int"))


def _require_positive_int(
    record: Mapping[str, Any],
    key: str,
    path: str,
    issues: list[TableValidationIssue],
) -> None:
    value = record.get(key)
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        issues.append(TableValidationIssue(f"{path}.{key}", "expected positive int"))


def _validate_pairwise_linking(
    record: Mapping[str, Any],
    path: str,
    issues: list[TableValidationIssue],
) -> None:
    value = record.get("pairwise_linking")
    if not isinstance(value, list) or any(
        isinstance(item, bool) or not isinstance(item, int) for item in value
    ):
        issues.append(TableValidationIssue(f"{path}.pairwise_linking", "expected int list"))
        return

    component_count = record.get("component_count")
    if isinstance(component_count, int) and not isinstance(component_count, bool):
        expected = component_count * (component_count - 1) // 2
        if len(value) != expected:
            issues.append(
                TableValidationIssue(
                    f"{path}.pairwise_linking",
                    f"expected {expected} values for {component_count} components",
                )
            )


def _validate_aliases(
    record: Mapping[str, Any],
    path: str,
    issues: list[TableValidationIssue],
) -> None:
    aliases = record.get("aliases", [])
    if not isinstance(aliases, list):
        issues.append(TableValidationIssue(f"{path}.aliases", "expected list"))
        return
    for alias_index, alias in enumerate(aliases):
        if not isinstance(alias, str) or not alias.strip():
            issues.append(
                TableValidationIssue(
                    f"{path}.aliases[{alias_index}]",
                    "expected non-empty string",
                )
            )


def _validate_source_fields(
    record: Mapping[str, Any],
    path: str,
    issues: list[TableValidationIssue],
) -> None:
    _require_optional_string(record, "source", path, issues)
    _require_optional_string(record, "source_url", path, issues)


def _has_known_limitation_text(value: Any) -> bool:
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, list):
        return any(isinstance(item, str) and item.strip() for item in value)
    return False


def _validate_known_limitations(
    record: Mapping[str, Any],
    path: str,
    issues: list[TableValidationIssue],
) -> None:
    value = record.get("known_limitations")
    if value is None:
        return
    if isinstance(value, str):
        if not value.strip():
            issues.append(
                TableValidationIssue(
                    f"{path}.known_limitations",
                    "expected non-empty string or non-empty list of non-empty strings",
                )
            )
        return
    if not isinstance(value, list) or not value:
        issues.append(
            TableValidationIssue(
                f"{path}.known_limitations",
                "expected non-empty string or non-empty list of non-empty strings",
            )
        )
        return
    for item_index, item in enumerate(value):
        if not isinstance(item, str) or not item.strip():
            issues.append(
                TableValidationIssue(
                    f"{path}.known_limitations[{item_index}]",
                    "expected non-empty string",
                )
            )


def _source_metadata_summary(
    records: list[Mapping[str, Any]],
    *,
    expected_convention: str | None = None,
) -> dict[str, Any]:
    source_value_counts: dict[str, int] = {}
    source_value_rows: dict[str, list[str]] = {}
    source_url_scheme_counts: dict[str, int] = {}
    source_url_domain_counts: dict[str, int] = {}
    source_url_scheme_rows: dict[str, list[str]] = {}
    source_url_domain_rows: dict[str, list[str]] = {}
    source_url_issue_code_counts: dict[str, int] = {}
    source_url_issue_code_rows: dict[str, list[str]] = {}
    source_rows: list[str] = []
    source_url_rows: list[str] = []
    source_with_source_url_rows: list[str] = []
    valid_source_url_rows: list[str] = []
    source_url_missing_scheme_rows: list[str] = []
    source_url_missing_domain_rows: list[str] = []
    convention_rows: list[str] = []
    convention_metadata_rows: list[str] = []
    convention_metadata_name_rows: list[str] = []
    convention_mismatch_rows: list[dict[str, str]] = []
    missing_convention_rows: list[str] = []
    known_limitations_rows: list[str] = []
    missing_source_rows: list[str] = []
    missing_source_url_rows: list[str] = []
    source_url_without_source_rows: list[str] = []
    invalid_source_url_rows: list[dict[str, str]] = []
    source_completeness_rows: list[dict[str, Any]] = []
    source_count = 0
    source_url_count = 0
    convention_count = 0
    convention_metadata_count = 0
    convention_metadata_name_count = 0
    known_limitations_count = 0

    for index, record in enumerate(records):
        path = f"$[{index}]"
        source = record.get("source")
        source_url = record.get("source_url")
        has_source = isinstance(source, str) and source.strip()
        has_source_url = isinstance(source_url, str) and source_url.strip()
        source_url_missing_scheme = False
        source_url_missing_domain = False
        source_url_invalid = False
        if has_source:
            source_count += 1
            source_rows.append(path)
            source_value = source.strip()
            source_value_counts[source_value] = source_value_counts.get(
                source_value, 0
            ) + 1
            source_value_rows.setdefault(source_value, []).append(path)
            if not has_source_url:
                missing_source_url_rows.append(path)
            else:
                source_with_source_url_rows.append(path)
        else:
            missing_source_rows.append(path)
            if has_source_url:
                source_url_without_source_rows.append(path)

        if has_source_url:
            source_url_count += 1
            source_url_rows.append(path)
            parsed = urlparse(source_url.strip())
            scheme = parsed.scheme.casefold()
            domain = parsed.netloc.casefold()
            source_url_issue_codes = []
            if not scheme:
                source_url_missing_scheme = True
                source_url_missing_scheme_rows.append(path)
                source_url_issue_codes.append("missing_scheme")
            elif scheme not in {"http", "https"}:
                source_url_issue_codes.append("unsupported_scheme")
            if not domain:
                source_url_missing_domain = True
                source_url_missing_domain_rows.append(path)
                source_url_issue_codes.append("missing_domain")
            if scheme:
                source_url_scheme_counts[scheme] = (
                    source_url_scheme_counts.get(scheme, 0) + 1
                )
                source_url_scheme_rows.setdefault(scheme, []).append(path)
            if domain:
                source_url_domain_counts[domain] = (
                    source_url_domain_counts.get(domain, 0) + 1
                )
                source_url_domain_rows.setdefault(domain, []).append(path)
            for issue_code in source_url_issue_codes:
                source_url_issue_code_counts[issue_code] = (
                    source_url_issue_code_counts.get(issue_code, 0) + 1
                )
                source_url_issue_code_rows.setdefault(issue_code, []).append(path)
            source_url_invalid = scheme not in {"http", "https"} or not domain
            if source_url_invalid:
                invalid_source_url_rows.append(
                    {
                        "path": f"{path}.source_url",
                        "source_url": source_url,
                    }
                )
            else:
                valid_source_url_rows.append(path)
        source_completeness_rows.append(
            {
                "row": path,
                "has_source": bool(has_source),
                "has_source_url": bool(has_source_url),
                "source_record_has_source_url": (
                    bool(has_source_url) if has_source else True
                ),
                "source_url_has_source": (
                    bool(has_source) if has_source_url else True
                ),
                "source_with_source_url": bool(has_source and has_source_url),
                "source_url_http_or_https": not source_url_invalid,
                "source_url_missing_scheme": source_url_missing_scheme,
                "source_url_missing_domain": source_url_missing_domain,
                "source_url_invalid": source_url_invalid,
            }
        )

        convention = record.get("convention")
        has_convention = isinstance(convention, str) and convention.strip()
        observed_convention = None
        observed_convention_path = None
        if isinstance(convention, str) and convention.strip():
            convention_count += 1
            convention_rows.append(path)
            observed_convention = convention.strip()
            observed_convention_path = f"{path}.convention"
        metadata = record.get("convention_metadata")
        has_convention_metadata_name = False
        if isinstance(metadata, Mapping):
            convention_metadata_count += 1
            convention_metadata_rows.append(path)
            name = metadata.get("name")
            if isinstance(name, str) and name.strip():
                convention_metadata_name_count += 1
                convention_metadata_name_rows.append(path)
                has_convention_metadata_name = True
                if observed_convention is None:
                    observed_convention = name.strip()
                    observed_convention_path = f"{path}.convention_metadata.name"
        if not has_convention and not has_convention_metadata_name:
            missing_convention_rows.append(path)
        elif (
            expected_convention is not None
            and observed_convention is not None
            and observed_convention != expected_convention
        ):
            convention_mismatch_rows.append(
                {
                    "path": observed_convention_path or f"{path}.convention",
                    "row": path,
                    "expected_convention": expected_convention,
                    "observed_convention": observed_convention,
                }
            )
        if _has_known_limitation_text(record.get("known_limitations")):
            known_limitations_count += 1
            known_limitations_rows.append(path)

    record_count = len(records)
    record_count_matched = record_count == len(source_rows) + len(missing_source_rows)
    source_count_matched = source_count == len(source_rows)
    source_value_count_total_matched = sum(source_value_counts.values()) == source_count
    source_value_row_count_total_matched = (
        sum(len(rows) for rows in source_value_rows.values()) == source_count
    )
    source_url_count_matched = source_url_count == len(source_url_rows)
    source_with_source_url_count = len(source_with_source_url_rows)
    missing_source_count_matched = (
        len(missing_source_rows) == record_count - source_count
    )
    missing_source_url_count_matched = (
        len(missing_source_url_rows) == source_count - source_with_source_url_count
    )
    source_url_without_source_count_matched = len(
        source_url_without_source_rows
    ) == source_url_count - source_with_source_url_count
    source_url_without_source_rows_subset = set(
        source_url_without_source_rows
    ).issubset(set(missing_source_rows))
    valid_source_url_count = len(valid_source_url_rows)
    source_url_missing_scheme_count = len(source_url_missing_scheme_rows)
    source_url_missing_domain_count = len(source_url_missing_domain_rows)
    invalid_source_url_count_matched = (
        len(invalid_source_url_rows) == source_url_count - valid_source_url_count
    )
    source_url_scheme_count_total_matched = (
        sum(source_url_scheme_counts.values())
        == source_url_count - source_url_missing_scheme_count
    )
    source_url_scheme_row_count_total_matched = (
        sum(len(rows) for rows in source_url_scheme_rows.values())
        == source_url_count - source_url_missing_scheme_count
    )
    source_url_domain_count_total_matched = (
        sum(source_url_domain_counts.values())
        == source_url_count - source_url_missing_domain_count
    )
    source_url_domain_row_count_total_matched = (
        sum(len(rows) for rows in source_url_domain_rows.values())
        == source_url_count - source_url_missing_domain_count
    )
    source_url_issue_code_total = sum(source_url_issue_code_counts.values())
    source_url_issue_code_count_total_matched = (
        source_url_issue_code_total
        == sum(len(rows) for rows in source_url_issue_code_rows.values())
    )
    invalid_source_url_row_paths = {
        str(row["path"]).removesuffix(".source_url")
        for row in invalid_source_url_rows
    }
    source_url_issue_code_row_paths = {
        row for rows in source_url_issue_code_rows.values() for row in rows
    }
    source_url_issue_code_invalid_row_coverage_matched = (
        invalid_source_url_row_paths == source_url_issue_code_row_paths
    )
    convention_count_matched = convention_count == len(convention_rows)
    convention_metadata_count_matched = (
        convention_metadata_count == len(convention_metadata_rows)
    )
    convention_metadata_name_count_matched = (
        convention_metadata_name_count == len(convention_metadata_name_rows)
    )
    convention_metadata_without_name_count = (
        convention_metadata_count - convention_metadata_name_count
    )
    convention_metadata_name_row_set = set(convention_metadata_name_rows)
    convention_metadata_without_name_rows = [
        path
        for path in convention_metadata_rows
        if path not in convention_metadata_name_row_set
    ]
    convention_mismatch_count = len(convention_mismatch_rows)
    convention_mismatch_count_matched = convention_mismatch_count == len(
        convention_mismatch_rows
    )
    known_limitations_count_matched = known_limitations_count == len(
        known_limitations_rows
    )
    source_completeness_row_count_matched = (
        len(source_completeness_rows) == record_count
    )
    source_completeness_source_count_matched = (
        sum(1 for row in source_completeness_rows if row["has_source"])
        == source_count
    )
    source_completeness_source_url_count_matched = (
        sum(1 for row in source_completeness_rows if row["has_source_url"])
        == source_url_count
    )
    source_completeness_invalid_url_count_matched = (
        sum(1 for row in source_completeness_rows if row["source_url_invalid"])
        == len(invalid_source_url_rows)
    )
    summary_consistency = {
        "method": "source_metadata_summary_consistency",
        "claim_scope": "table_source_metadata_summary_self_consistency",
        "matched": (
            record_count_matched
            and source_count_matched
            and source_value_count_total_matched
            and source_value_row_count_total_matched
            and source_url_count_matched
            and missing_source_count_matched
            and missing_source_url_count_matched
            and source_url_without_source_count_matched
            and source_url_without_source_rows_subset
            and invalid_source_url_count_matched
            and source_url_scheme_count_total_matched
            and source_url_scheme_row_count_total_matched
            and source_url_domain_count_total_matched
            and source_url_domain_row_count_total_matched
            and source_url_issue_code_count_total_matched
            and source_url_issue_code_invalid_row_coverage_matched
            and convention_count_matched
            and convention_metadata_count_matched
            and convention_metadata_name_count_matched
            and convention_mismatch_count_matched
            and known_limitations_count_matched
            and source_completeness_row_count_matched
            and source_completeness_source_count_matched
            and source_completeness_source_url_count_matched
            and source_completeness_invalid_url_count_matched
        ),
        "record_count": record_count,
        "source_count": source_count,
        "source_url_count": source_url_count,
        "source_with_source_url_count": source_with_source_url_count,
        "valid_source_url_count": valid_source_url_count,
        "source_url_missing_scheme_count": source_url_missing_scheme_count,
        "source_url_missing_domain_count": source_url_missing_domain_count,
        "source_url_issue_code_total": source_url_issue_code_total,
        "convention_count": convention_count,
        "convention_metadata_count": convention_metadata_count,
        "convention_metadata_name_count": convention_metadata_name_count,
        "convention_metadata_without_name_count": (
            convention_metadata_without_name_count
        ),
        "convention_mismatch_count": convention_mismatch_count,
        "known_limitations_count": known_limitations_count,
        "source_completeness_row_count": len(source_completeness_rows),
        "record_count_matched": record_count_matched,
        "source_count_matched": source_count_matched,
        "source_value_count_total_matched": source_value_count_total_matched,
        "source_value_row_count_total_matched": source_value_row_count_total_matched,
        "source_url_count_matched": source_url_count_matched,
        "missing_source_count_matched": missing_source_count_matched,
        "missing_source_url_count_matched": missing_source_url_count_matched,
        "source_url_without_source_count_matched": (
            source_url_without_source_count_matched
        ),
        "source_url_without_source_rows_subset_of_missing_source_rows": (
            source_url_without_source_rows_subset
        ),
        "invalid_source_url_count_matched": invalid_source_url_count_matched,
        "source_url_scheme_count_total_matched": (
            source_url_scheme_count_total_matched
        ),
        "source_url_scheme_row_count_total_matched": (
            source_url_scheme_row_count_total_matched
        ),
        "source_url_domain_count_total_matched": (
            source_url_domain_count_total_matched
        ),
        "source_url_domain_row_count_total_matched": (
            source_url_domain_row_count_total_matched
        ),
        "source_url_issue_code_count_total_matched": (
            source_url_issue_code_count_total_matched
        ),
        "source_url_issue_code_invalid_row_coverage_matched": (
            source_url_issue_code_invalid_row_coverage_matched
        ),
        "convention_count_matched": convention_count_matched,
        "convention_metadata_count_matched": convention_metadata_count_matched,
        "convention_metadata_name_count_matched": (
            convention_metadata_name_count_matched
        ),
        "convention_mismatch_count_matched": convention_mismatch_count_matched,
        "known_limitations_count_matched": known_limitations_count_matched,
        "source_completeness_row_count_matched": (
            source_completeness_row_count_matched
        ),
        "source_completeness_source_count_matched": (
            source_completeness_source_count_matched
        ),
        "source_completeness_source_url_count_matched": (
            source_completeness_source_url_count_matched
        ),
        "source_completeness_invalid_url_count_matched": (
            source_completeness_invalid_url_count_matched
        ),
    }
    provenance_blocker_details: list[dict[str, Any]] = []

    def add_provenance_blocker_rows(
        code: str,
        rows: list[str],
        *,
        field: str,
        reason: str,
    ) -> None:
        for row in rows:
            provenance_blocker_details.append(
                {
                    "code": code,
                    "severity": "blocking",
                    "scope": "table_source_metadata_provenance",
                    "path": f"{row}.{field}",
                    "row": row,
                    "reason": reason,
                }
            )

    add_provenance_blocker_rows(
        "missing_source",
        missing_source_rows,
        field="source",
        reason="record has no source label",
    )
    add_provenance_blocker_rows(
        "missing_source_url",
        missing_source_url_rows,
        field="source_url",
        reason="source record has no source_url",
    )
    add_provenance_blocker_rows(
        "source_url_without_source",
        source_url_without_source_rows,
        field="source",
        reason="source_url is present without a source label",
    )
    for row in invalid_source_url_rows:
        source_url = row["source_url"]
        parsed = urlparse(source_url.strip())
        scheme = parsed.scheme.casefold()
        domain = parsed.netloc.casefold()
        source_url_issue_codes = []
        if not scheme:
            source_url_issue_codes.append("missing_scheme")
        elif scheme not in {"http", "https"}:
            source_url_issue_codes.append("unsupported_scheme")
        if not domain:
            source_url_issue_codes.append("missing_domain")
        provenance_blocker_details.append(
            {
                "code": "invalid_source_url",
                "severity": "blocking",
                "scope": "table_source_metadata_provenance",
                "path": row["path"],
                "row": str(row["path"]).removesuffix(".source_url"),
                "reason": "source_url is missing an http(s) scheme or domain",
                "source_url": source_url,
                "scheme": scheme,
                "domain": domain,
                "source_url_issue_codes": source_url_issue_codes,
            }
        )
    add_provenance_blocker_rows(
        "missing_convention",
        missing_convention_rows,
        field="convention",
        reason="record has no convention or convention_metadata.name",
    )
    for row in convention_mismatch_rows:
        provenance_blocker_details.append(
            {
                "code": "convention_mismatch",
                "severity": "blocking",
                "scope": "table_source_metadata_provenance",
                "path": row["path"],
                "row": row["row"],
                "reason": "record convention does not match expected convention",
                "expected_convention": row["expected_convention"],
                "observed_convention": row["observed_convention"],
            }
        )
    provenance_blocker_codes = list(
        dict.fromkeys(detail["code"] for detail in provenance_blocker_details)
    )
    provenance_blocker_count = len(provenance_blocker_details)
    provenance_review_ready = (
        summary_consistency["matched"] and provenance_blocker_count == 0
    )
    provenance_blocker_detail_count_matched = (
        provenance_blocker_count == len(provenance_blocker_details)
    )
    provenance_blocker_unique_code_count_matched = len(
        provenance_blocker_codes
    ) == len({detail["code"] for detail in provenance_blocker_details})
    provenance_review_ready_matched = provenance_review_ready == (
        summary_consistency["matched"] and provenance_blocker_count == 0
    )
    provenance_blocker_summary_consistency = {
        "method": "source_metadata_provenance_blocker_summary_consistency",
        "claim_scope": "table_source_metadata_provenance_blocker_self_consistency",
        "matched": (
            provenance_blocker_detail_count_matched
            and provenance_blocker_unique_code_count_matched
            and provenance_review_ready_matched
        ),
        "blocker_count": provenance_blocker_count,
        "detail_count": len(provenance_blocker_details),
        "code_count": len(provenance_blocker_codes),
        "detail_count_matched": provenance_blocker_detail_count_matched,
        "unique_code_count_matched": provenance_blocker_unique_code_count_matched,
        "review_ready_matched": provenance_review_ready_matched,
    }
    return {
        "claim_scope": "table_source_metadata_scan",
        "expected_convention": expected_convention,
        "record_count": record_count,
        "source_count": source_count,
        "source_rows": source_rows,
        "source_value_counts": source_value_counts,
        "source_value_rows": source_value_rows,
        "source_url_count": source_url_count,
        "source_url_rows": source_url_rows,
        "source_with_source_url_count": source_with_source_url_count,
        "source_with_source_url_rows": source_with_source_url_rows,
        "valid_source_url_count": valid_source_url_count,
        "valid_source_url_rows": valid_source_url_rows,
        "source_url_missing_scheme_count": source_url_missing_scheme_count,
        "source_url_missing_scheme_rows": source_url_missing_scheme_rows,
        "source_url_missing_domain_count": source_url_missing_domain_count,
        "source_url_missing_domain_rows": source_url_missing_domain_rows,
        "missing_source_count": len(missing_source_rows),
        "missing_source_rows": missing_source_rows,
        "missing_source_url_count": len(missing_source_url_rows),
        "missing_source_url_rows": missing_source_url_rows,
        "source_url_without_source_count": len(source_url_without_source_rows),
        "source_url_without_source_rows": source_url_without_source_rows,
        "invalid_source_url_count": len(invalid_source_url_rows),
        "invalid_source_url_rows": invalid_source_url_rows,
        "source_url_scheme_counts": source_url_scheme_counts,
        "source_url_scheme_rows": source_url_scheme_rows,
        "source_url_domain_counts": source_url_domain_counts,
        "source_url_domain_rows": source_url_domain_rows,
        "source_url_issue_code_counts": source_url_issue_code_counts,
        "source_url_issue_code_rows": source_url_issue_code_rows,
        "source_completeness_rows": source_completeness_rows,
        "convention_count": convention_count,
        "convention_rows": convention_rows,
        "convention_metadata_count": convention_metadata_count,
        "convention_metadata_rows": convention_metadata_rows,
        "convention_metadata_name_count": convention_metadata_name_count,
        "convention_metadata_name_rows": convention_metadata_name_rows,
        "convention_metadata_without_name_count": (
            convention_metadata_without_name_count
        ),
        "convention_metadata_without_name_rows": (
            convention_metadata_without_name_rows
        ),
        "convention_mismatch_count": convention_mismatch_count,
        "convention_mismatch_rows": convention_mismatch_rows,
        "known_limitations_count": known_limitations_count,
        "known_limitations_rows": known_limitations_rows,
        "provenance_review_ready": provenance_review_ready,
        "provenance_blocker_count": provenance_blocker_count,
        "provenance_blocker_codes": provenance_blocker_codes,
        "provenance_blocker_details": provenance_blocker_details,
        "provenance_blocker_summary_consistency": (
            provenance_blocker_summary_consistency
        ),
        "all_records_have_source": source_count == record_count,
        "all_source_records_have_source_url": len(missing_source_url_rows) == 0,
        "all_source_urls_have_source": len(source_url_without_source_rows) == 0,
        "all_source_urls_are_http_or_https": len(invalid_source_url_rows) == 0,
        "all_conventions_match_expected": convention_mismatch_count == 0,
        "table_correctness_certified": False,
        "external_source_verified": False,
        "summary_consistency": summary_consistency,
        "notes": [
            "source metadata scan only; does not verify external table correctness",
        ],
    }


def _validate_convention(
    record: Mapping[str, Any],
    path: str,
    issues: list[TableValidationIssue],
    *,
    expected_convention: str | None,
) -> None:
    metadata = record.get("convention_metadata")
    if metadata is not None and not isinstance(metadata, Mapping):
        issues.append(TableValidationIssue(f"{path}.convention_metadata", "expected object"))
        return

    convention = record.get("convention")
    if convention is not None:
        if not isinstance(convention, str):
            issues.append(TableValidationIssue(f"{path}.convention", "expected string"))
            return
        if not convention.strip():
            issues.append(
                TableValidationIssue(f"{path}.convention", "expected non-empty string")
            )
            return

    metadata_name = None
    if isinstance(metadata, Mapping) and "name" in metadata:
        raw_name = metadata.get("name")
        if not isinstance(raw_name, str) or not raw_name.strip():
            issues.append(
                TableValidationIssue(
                    f"{path}.convention_metadata.name",
                    "expected non-empty string",
                )
            )
            return
        metadata_name = raw_name

    observed = convention if convention is not None else metadata_name
    if observed is None:
        issues.append(
            TableValidationIssue(
                f"{path}.convention",
                "expected convention or convention_metadata.name",
            )
        )
        return
    if expected_convention is not None and observed != expected_convention:
        issues.append(
            TableValidationIssue(
                f"{path}.convention",
                f"expected convention '{expected_convention}', got '{observed}'",
            )
        )
