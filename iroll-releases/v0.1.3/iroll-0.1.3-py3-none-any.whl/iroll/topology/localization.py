"""Subchain scanning helpers for local knot analysis."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from numpy.typing import ArrayLike

from iroll.core.curve import Polyline3D
from iroll.topology.classify import classify_curve, classify_open_curve


@dataclass(frozen=True)
class SubchainResult:
    start: int
    end: int
    point_count: int
    classification: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "start": self.start,
            "end": self.end,
            "point_count": self.point_count,
            "classification": self.classification,
        }


def scan_subchains(
    curve: Polyline3D,
    *,
    window_points: int,
    step: int,
    closure: dict | str | None = None,
    direction: ArrayLike | None = None,
    max_windows: int | None = 200,
) -> list[SubchainResult]:
    if window_points < 2:
        raise ValueError("window_points must be at least 2")
    if step < 1:
        raise ValueError("step must be at least 1")
    if max_windows is not None and max_windows < 1:
        raise ValueError("max_windows must be at least 1")
    if window_points > curve.point_count:
        raise ValueError("window_points cannot exceed curve point_count")

    results: list[SubchainResult] = []
    for start in range(0, curve.point_count - window_points + 1, step):
        end = start + window_points
        subchain = Polyline3D(
            curve.points[start:end],
            closed=False,
            name=_subchain_name(curve, start, end),
            metadata={**curve.metadata, "subchain_start": start, "subchain_end": end},
        )
        classification = _classify_subchain(
            subchain,
            closure=closure,
            direction=direction,
        )
        results.append(
            SubchainResult(
                start=start,
                end=end,
                point_count=subchain.point_count,
                classification=classification,
            )
        )
        if max_windows is not None and len(results) >= max_windows:
            break
    return results


def summarize_subchains(
    results: list[SubchainResult],
    *,
    window_points: int,
    step: int,
    max_windows: int | None,
) -> dict[str, Any]:
    return {
        "window_points": window_points,
        "step": step,
        "max_windows": max_windows,
        "count": len(results),
        "results": [result.to_dict() for result in results],
    }


def _classify_subchain(
    subchain: Polyline3D,
    *,
    closure: dict | str | None,
    direction: ArrayLike | None,
) -> dict[str, Any]:
    if closure is None:
        return classify_curve(subchain, direction=direction).to_dict()
    closure_result = classify_open_curve(subchain, closure=closure, direction=direction)
    return {
        "knot_type": closure_result["dominant_knot_type"],
        "method": f"closure:{closure_result['method']}",
        "confidence": closure_result["confidence"],
        "closure": closure_result,
    }


def _subchain_name(curve: Polyline3D, start: int, end: int) -> str | None:
    if curve.name is None:
        return None
    return f"{curve.name}[{start}:{end}]"
