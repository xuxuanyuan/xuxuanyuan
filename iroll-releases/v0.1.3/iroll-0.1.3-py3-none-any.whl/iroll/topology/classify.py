"""Small first-pass knot classifier."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
from typing import Iterable

import numpy as np
from numpy.typing import ArrayLike

from iroll.core.curve import Polyline3D
from iroll.core.link import Link3D
from iroll.topology.closure import ClosureSpec, iter_closed_curves
from iroll.topology.crossings import Crossing, find_curve_crossings
from iroll.topology.diagram import (
    alexander_polynomial_from_diagram,
    build_knot_diagram,
    knot_determinant_from_diagram,
)
from iroll.topology.knot_table import lookup_knot
from iroll.topology.knot_table import jones_polynomial_for_entry
from iroll.topology.linking import linking_matrix
from iroll.topology.projection import DEFAULT_PROJECTION_DIRECTIONS


@dataclass(frozen=True)
class ClassificationResult:
    knot_type: str
    notation: str | None
    method: str
    confidence: str
    crossing_count: int
    arc_count: int = 0
    determinant: int | None = None
    alexander_polynomial: str | None = None
    table_match: dict | None = None
    chirality: str = "unknown"
    chirality_method: str | None = None
    jones_polynomial: str | None = None
    jones_method: str | None = None
    projection_direction: list[float] | None = None
    notes: list[str] | None = None

    def to_dict(self) -> dict:
        return {
            "knot_type": self.knot_type,
            "notation": self.notation,
            "method": self.method,
            "confidence": self.confidence,
            "crossing_count": self.crossing_count,
            "arc_count": self.arc_count,
            "determinant": self.determinant,
            "alexander_polynomial": self.alexander_polynomial,
            "table_match": self.table_match,
            "chirality": self.chirality,
            "chirality_method": self.chirality_method,
            "jones_polynomial": self.jones_polynomial,
            "jones_method": self.jones_method,
            "projection_direction": self.projection_direction,
            "notes": list(self.notes or []),
        }


@dataclass(frozen=True)
class MultiProjectionClassification:
    selected: ClassificationResult
    results: list[ClassificationResult]
    distribution: dict[str, float]
    stable: bool
    agreement: float

    def to_dict(self) -> dict:
        return {
            "selected": self.selected.to_dict(),
            "distribution": self.distribution,
            "stable": self.stable,
            "agreement": self.agreement,
            "results": [result.to_dict() for result in self.results],
        }


@dataclass(frozen=True)
class LinkClassificationResult:
    link_type: str
    notation: str | None
    method: str
    confidence: str
    component_count: int
    linking_matrix: list[list[float]] | None = None
    pairwise_linking: list[dict] | None = None
    component_reports: list[dict] | None = None
    split_evidence: dict | None = None
    table_match: dict | None = None
    table_candidates: list[dict] | None = None
    table_candidate_summary: dict | None = None
    invariants: dict | None = None
    notes: list[str] | None = None

    def to_dict(self) -> dict:
        table_match = self.table_match
        invariants = self.invariants
        if table_match is None or invariants is None:
            table_match, invariants = _link_table_payload(self.link_type)
        table_candidates = list(self.table_candidates or [])
        table_candidate_summary = (
            self.table_candidate_summary
            if self.table_candidate_summary is not None
            else _link_table_candidate_summary(table_candidates)
        )
        return {
            "link_type": self.link_type,
            "notation": self.notation,
            "method": self.method,
            "confidence": self.confidence,
            "component_count": self.component_count,
            "linking_matrix": self.linking_matrix,
            "pairwise_linking": list(self.pairwise_linking or []),
            "component_reports": list(self.component_reports or []),
            "split_evidence": self.split_evidence,
            "table_match": table_match,
            "table_candidates": table_candidates,
            "table_candidate_summary": table_candidate_summary,
            "invariants": invariants,
            "notes": list(self.notes or []),
        }


def classify_curve(
    curve: Polyline3D,
    *,
    direction: ArrayLike | None = None,
) -> ClassificationResult:
    if not curve.closed:
        return ClassificationResult(
            knot_type="unknown",
            notation=None,
            method="requires_closure",
            confidence="none",
            crossing_count=0,
            notes=["open curves require an explicit closure strategy"],
        )

    if direction is not None:
        return _classify_with_direction(curve, direction)

    return classify_curve_multi_projection(curve).selected


def classify_curve_multi_projection(
    curve: Polyline3D,
    *,
    directions: Iterable[ArrayLike] | None = None,
) -> MultiProjectionClassification:
    if not curve.closed:
        result = classify_curve(curve, direction=[0.3, 0.5, 1.0])
        return MultiProjectionClassification(
            selected=result,
            results=[result],
            distribution={result.knot_type: 1.0},
            stable=False,
            agreement=1.0,
        )

    candidates = list(directions or DEFAULT_PROJECTION_DIRECTIONS)
    results = [_classify_with_direction(curve, candidate) for candidate in candidates]
    counts = Counter(result.knot_type for result in results)
    total = len(results)
    distribution = {
        knot_type: count / total
        for knot_type, count in sorted(counts.items(), key=lambda item: item[0])
    }
    selected = _select_projection_vote(results)
    agreement = counts[selected.knot_type] / total
    stable = agreement >= 0.7 and selected.knot_type != "unknown"
    if stable and selected.confidence in {"low", "none"}:
        selected = _replace_confidence(selected, "medium")
    return MultiProjectionClassification(
        selected=selected,
        results=results,
        distribution=distribution,
        stable=stable,
        agreement=agreement,
    )


def _select_projection_vote(results: list[ClassificationResult]) -> ClassificationResult:
    counts = Counter(result.knot_type for result in results)
    return sorted(
        results,
        key=lambda result: (
            -counts[result.knot_type],
            result.knot_type == "unknown",
            result.knot_type == "unknot_or_determinant_one",
            result.crossing_count,
            result.determinant is None,
        ),
    )[0]


def _replace_confidence(result: ClassificationResult, confidence: str) -> ClassificationResult:
    return ClassificationResult(
        knot_type=result.knot_type,
        notation=result.notation,
        method=result.method,
        confidence=confidence,
        crossing_count=result.crossing_count,
        arc_count=result.arc_count,
        determinant=result.determinant,
        alexander_polynomial=result.alexander_polynomial,
        table_match=result.table_match,
        chirality=result.chirality,
        chirality_method=result.chirality_method,
        jones_polynomial=result.jones_polynomial,
        jones_method=result.jones_method,
        projection_direction=result.projection_direction,
        notes=result.notes,
    )


def classify_open_curve(
    curve: Polyline3D,
    *,
    closure: dict | str | None = None,
    direction: ArrayLike | None = None,
) -> dict:
    spec = ClosureSpec.from_value(closure)
    results = [
        classify_curve(closed_curve, direction=direction)
        for closed_curve in iter_closed_curves(
            curve,
            method=spec.method,
            samples=spec.samples,
            seed=spec.seed,
            scale=spec.scale,
        )
    ]
    counts = Counter(result.knot_type for result in results)
    total = len(results)
    distribution = {
        knot_type: count / total
        for knot_type, count in sorted(counts.items(), key=lambda item: item[0])
    }
    dominant, dominant_count = counts.most_common(1)[0]
    return {
        "method": spec.method,
        "samples": total,
        "seed": spec.seed,
        "scale": spec.scale,
        "distribution": distribution,
        "dominant_knot_type": dominant,
        "confidence": _distribution_confidence(dominant_count / total, total),
        "results": [result.to_dict() for result in results],
    }


def classify_link(
    link: Link3D,
    *,
    direction: ArrayLike | None = None,
    backend: str = "auto",
    linking_matrix_values: ArrayLike | None = None,
) -> LinkClassificationResult:
    component_reports = [
        classify_curve(component, direction=direction).to_dict()
        for component in link.components
    ]
    notes = [
        "link classification is an MVP based on pairwise linking numbers",
        "zero pairwise linking does not prove a general unlink",
    ]

    if not link.all_closed:
        return LinkClassificationResult(
            link_type="unknown_open_components",
            notation=None,
            method="requires_closed_components",
            confidence="none",
            component_count=link.component_count,
            component_reports=component_reports,
            notes=[*notes, "classical link type classification requires closed components"],
        )

    matrix = (
        np.asarray(linking_matrix_values, dtype=float)
        if linking_matrix_values is not None
        else linking_matrix(link, direction=direction, backend=backend)
    )
    pairwise = _pairwise_linking(matrix)
    split_evidence = _axis_aligned_split_evidence(link)
    components_are_unknotted = all(
        report.get("knot_type") == "unknot" for report in component_reports
    )

    if link.component_count == 1:
        component_type = component_reports[0].get("knot_type", "unknown")
        return LinkClassificationResult(
            link_type=str(component_type),
            notation=component_reports[0].get("notation"),
            method="single_component_classification",
            confidence=str(component_reports[0].get("confidence", "low")),
            component_count=link.component_count,
            linking_matrix=matrix.tolist(),
            pairwise_linking=pairwise,
            component_reports=component_reports,
            split_evidence=split_evidence,
            notes=[*notes, "single-component links are reported as knot classifications"],
        )

    if link.component_count == 2:
        value = float(matrix[0, 1])
        abs_value = abs(value)
        if np.isclose(abs_value, 1.0, atol=1e-9):
            confidence = "medium" if components_are_unknotted else "low"
            extra_notes = [] if components_are_unknotted else [
                "pairwise linking matches Hopf, but one or more components are not classified as unknot",
            ]
            return LinkClassificationResult(
                link_type="hopf_link",
                notation=None,
                method="pairwise_linking_number",
                confidence=confidence,
                component_count=link.component_count,
                linking_matrix=matrix.tolist(),
                pairwise_linking=pairwise,
                component_reports=component_reports,
                split_evidence=split_evidence,
                notes=[*notes, *extra_notes],
            )
        if np.isclose(abs_value, 0.0, atol=1e-9):
            if components_are_unknotted and split_evidence is not None:
                return LinkClassificationResult(
                    link_type="unlink",
                    notation=None,
                    method="pairwise_linking_number+axis_aligned_split",
                    confidence="medium",
                    component_count=link.component_count,
                    linking_matrix=matrix.tolist(),
                    pairwise_linking=pairwise,
                    component_reports=component_reports,
                    split_evidence=split_evidence,
                    notes=[
                        *notes,
                        "axis-aligned bounding boxes provide split-link evidence",
                    ],
                )
            table_candidates = _link_table_candidates_for_pairwise(
                link.component_count,
                pairwise,
            )
            nontrivial_candidates = [
                candidate
                for candidate in table_candidates
                if candidate.get("link_type") != "unlink"
            ]
            return LinkClassificationResult(
                link_type="pairwise_unlink_candidate",
                notation=None,
                method="pairwise_linking_number",
                confidence="low",
                component_count=link.component_count,
                linking_matrix=matrix.tolist(),
                pairwise_linking=pairwise,
                component_reports=component_reports,
                split_evidence=split_evidence,
                table_candidates=table_candidates,
                notes=[
                    *notes,
                    "no simple split-link evidence was found",
                    *(
                        [
                            "built-in link table contains nontrivial links with the same pairwise linking signature; stronger invariants are required",
                        ]
                        if nontrivial_candidates
                        else []
                    ),
                ],
            )

    if all(np.isclose(item["abs_linking_number"], 0.0, atol=1e-9) for item in pairwise):
        if components_are_unknotted and split_evidence is not None:
            return LinkClassificationResult(
                link_type="unlink",
                notation=None,
                method="pairwise_linking_number+axis_aligned_split",
                confidence="medium",
                component_count=link.component_count,
                linking_matrix=matrix.tolist(),
                pairwise_linking=pairwise,
                component_reports=component_reports,
                split_evidence=split_evidence,
                notes=[
                    *notes,
                    "axis-aligned bounding boxes provide split-link evidence",
                ],
            )
        table_candidates = _link_table_candidates_for_pairwise(
            link.component_count,
            pairwise,
        )
        nontrivial_candidates = [
            candidate
            for candidate in table_candidates
            if candidate.get("link_type") != "unlink"
        ]
        return LinkClassificationResult(
            link_type="pairwise_unlink_candidate",
            notation=None,
            method="pairwise_linking_number",
            confidence="low",
            component_count=link.component_count,
            linking_matrix=matrix.tolist(),
            pairwise_linking=pairwise,
            component_reports=component_reports,
            split_evidence=split_evidence,
            table_candidates=table_candidates,
            notes=[
                *notes,
                "no simple split-link evidence was found",
                *(
                    [
                        "built-in link table contains nontrivial links with the same pairwise linking signature; stronger invariants are required",
                    ]
                    if nontrivial_candidates
                    else []
                ),
            ],
        )

    return LinkClassificationResult(
        link_type="linked_pairwise_nonzero",
        notation=None,
        method="pairwise_linking_number",
        confidence="low",
        component_count=link.component_count,
        linking_matrix=matrix.tolist(),
        pairwise_linking=pairwise,
        component_reports=component_reports,
        split_evidence=split_evidence,
        notes=notes,
    )


def knot_determinant(crossings: Iterable[Crossing]) -> int:
    return knot_determinant_from_diagram(build_knot_diagram(crossings))


def _classify_with_direction(
    curve: Polyline3D,
    direction: ArrayLike,
) -> ClassificationResult:
    crossings = find_curve_crossings(curve, direction=direction)
    diagram = build_knot_diagram(crossings)
    determinant = knot_determinant_from_diagram(diagram)
    alexander_polynomial = alexander_polynomial_from_diagram(diagram)
    table_entry = lookup_knot(
        determinant=determinant,
        alexander_polynomial=alexander_polynomial,
        crossing_count=len(crossings),
    )
    knot_type, notation, confidence, notes = _label_from_table(
        table_entry,
        determinant=determinant,
        crossing_count=len(crossings),
    )
    chirality, chirality_method = _infer_chirality(
        crossings,
        knot_type=knot_type,
        table_chiral=table_entry.chiral if table_entry is not None else False,
    )
    jones_polynomial, jones_method = jones_polynomial_for_entry(
        table_entry,
        chirality=chirality,
    )
    if alexander_polynomial is None and len(crossings) > 8:
        notes = [*notes, "alexander polynomial skipped for crossing_count > 8"]
    if jones_method == "requires_stable_chirality":
        notes = [*notes, "Jones polynomial requires stable chirality for this chiral knot"]
    return ClassificationResult(
        knot_type=knot_type,
        notation=notation,
        method="knot_determinant",
        confidence=confidence,
        crossing_count=len(crossings),
        arc_count=diagram.arc_count,
        determinant=determinant,
        alexander_polynomial=alexander_polynomial,
        table_match=table_entry.to_dict() if table_entry is not None else None,
        chirality=chirality,
        chirality_method=chirality_method,
        jones_polynomial=jones_polynomial,
        jones_method=jones_method,
        projection_direction=np.asarray(direction, dtype=float).tolist(),
        notes=notes,
    )


def _label_from_table(
    table_entry,
    determinant: int,
    *,
    crossing_count: int,
) -> tuple[str, str | None, str, list[str]]:
    notes = [
        "determinant is |Alexander polynomial evaluated at t=-1|",
        "classification uses the built-in MVP knot table when possible",
    ]
    if table_entry is not None:
        confidence = "high" if table_entry.notation == "0_1" else "medium"
        return table_entry.knot_type, table_entry.notation, confidence, notes

    if crossing_count == 0:
        return "unknot", "0_1", "high", notes
    if determinant == 1:
        return "unknot_or_determinant_one", None, "low", notes
    return "unknown", None, "low", notes


def _infer_chirality(
    crossings: list[Crossing],
    *,
    knot_type: str,
    table_chiral: bool,
) -> tuple[str, str | None]:
    if knot_type == "unknot":
        return "achiral", "built_in_knot_table"
    if not table_chiral:
        return "achiral" if knot_type != "unknown" else "unknown", "built_in_knot_table"
    if not crossings:
        return "unknown", None

    sign_sum = sum(crossing.sign for crossing in crossings)
    if abs(sign_sum) == len(crossings):
        return ("positive" if sign_sum > 0 else "negative"), "crossing_sign_sum"
    return "mixed_or_projection_dependent", "crossing_sign_sum"


def _distribution_confidence(fraction: float, samples: int) -> str:
    if samples == 1:
        return "single_sample"
    if fraction >= 0.85:
        return "high"
    if fraction >= 0.6:
        return "medium"
    return "low"


def _pairwise_linking(matrix: np.ndarray) -> list[dict]:
    pairs = []
    for i in range(matrix.shape[0]):
        for j in range(i + 1, matrix.shape[1]):
            value = float(matrix[i, j])
            pairs.append(
                {
                    "components": [i, j],
                    "linking_number": value,
                    "abs_linking_number": abs(value),
                }
            )
    return pairs


def _link_table_payload(link_type: str) -> tuple[dict | None, dict]:
    from iroll.topology.homfly import homfly_polynomial_for_link
    from iroll.topology.knot_table import lookup_link
    from iroll.topology.multivariable_alexander import multivariable_alexander_for_link

    table_entry = lookup_link(link_type=link_type)
    homfly = homfly_polynomial_for_link(link_type)
    alexander = multivariable_alexander_for_link(link_type)
    signed_pd_homfly = _homfly_from_signed_pd_fixture(link_type)
    if homfly["skipped"] and signed_pd_homfly is not None:
        homfly = signed_pd_homfly
    signed_pd_alexander = _multivariable_alexander_from_signed_pd_fixture(link_type)
    if alexander["skipped"] and signed_pd_alexander is not None:
        alexander = signed_pd_alexander
    return (
        table_entry.to_dict() if table_entry is not None else None,
        {
            "homfly": homfly,
            "multivariable_alexander": alexander,
        },
    )


def _homfly_from_signed_pd_fixture(link_type: str) -> dict | None:
    fixture = _signed_pd_fixture_for_link_type(link_type)
    if fixture is None:
        return None
    from iroll.topology.homfly import homfly_fixture_comparison

    comparison = homfly_fixture_comparison(fixture.notation)
    observed = comparison.get("observed_homfly")
    if comparison["skipped"] or observed is None:
        return None
    return {
        "homfly_polynomial": observed,
        "method": "signed_pd_fixture_comparison",
        "table_match": None,
        "fixture": comparison["fixture"],
        "fixture_comparison": comparison,
        "skipped": False,
        "notes": [
            "computed from the registered signed-PD fixture instead of a link-table HOMFLY entry",
        ],
    }


def _multivariable_alexander_from_signed_pd_fixture(link_type: str) -> dict | None:
    fixture = _signed_pd_fixture_for_link_type(link_type)
    if fixture is None:
        return None
    from iroll.topology.multivariable_alexander import (
        multivariable_alexander_fixture_comparison,
    )

    comparison = multivariable_alexander_fixture_comparison(fixture.notation)
    observed = comparison.get("observed_multivariable_alexander")
    if comparison["skipped"] or observed is None or comparison["result"] is None:
        return None
    result = dict(comparison["result"])
    result["table_match"] = None
    result["fixture"] = comparison["fixture"]
    result["fixture_comparison"] = comparison
    result["notes"] = [
        "computed from the registered signed-PD fixture instead of a link-table Alexander entry",
        *result.get("notes", []),
    ]
    return result


def _signed_pd_fixture_for_link_type(link_type: str):
    notation = {
        "hopf_link": "L2a1",
    }.get(link_type)
    if notation is None:
        return None
    from iroll.topology.pd_fixtures import get_diagram_fixture

    fixture = get_diagram_fixture(notation)
    return fixture if fixture.has_signed_pd else None


def _link_table_candidates_for_pairwise(
    component_count: int,
    pairwise: list[dict],
) -> list[dict]:
    from iroll.topology.knot_table import builtin_link_table

    signature = tuple(
        int(round(float(item["abs_linking_number"])))
        for item in pairwise
    )
    candidates = []
    for entry in builtin_link_table():
        if entry["component_count"] != component_count:
            continue
        entry_signature = tuple(abs(value) for value in entry["pairwise_linking"])
        if entry_signature == signature:
            if entry.get("source_table_invariant_audit_available"):
                audit_summary = _source_table_audit_candidate_summary(
                    str(entry.get("notation"))
                )
                if audit_summary is not None:
                    entry = {
                        **entry,
                        "source_table_invariant_audit_summary": audit_summary,
                    }
            candidates.append(entry)
    return candidates


@lru_cache(maxsize=None)
def _source_table_audit_candidate_summary(notation: str) -> dict | None:
    if not notation:
        return None
    from iroll.topology.pd_fixtures import get_diagram_fixture

    fixture = get_diagram_fixture(notation)
    if (
        fixture.source_table_jones is None
        and fixture.source_table_homfly is None
        and fixture.source_table_multivariable_alexander is None
    ):
        return None

    audit = fixture.source_table_invariant_audit(compute_homfly=False)
    comparisons = audit.get("comparisons")
    comparison_statuses: dict[str, str] = {}
    if isinstance(comparisons, dict):
        comparison_statuses = {
            str(name): str(comparison.get("source_match_resolution_status", ""))
            for name, comparison in comparisons.items()
            if isinstance(comparison, dict)
            and comparison.get("source_match_resolution_status") is not None
        }
    homfly = comparisons.get("homfly") if isinstance(comparisons, dict) else None
    homfly_variant_status = (
        homfly.get("source_value_variant_resolution_status")
        if isinstance(homfly, dict)
        else None
    )
    skipped_attempt_summary = audit.get(
        "source_table_alexander_skipped_common_gcd_attempt_summary"
    )
    skipped_attempt_summary = (
        skipped_attempt_summary if isinstance(skipped_attempt_summary, dict) else {}
    )
    source_divisibility_summary = audit.get(
        "source_table_alexander_source_numerator_divisibility_summary"
    )
    source_divisibility_summary = (
        source_divisibility_summary
        if isinstance(source_divisibility_summary, dict)
        else {}
    )
    return {
        "method": "diagram_fixture_source_table_invariant_audit_summary",
        "notation": audit.get("notation"),
        "source_url": audit.get("source_url"),
        "registered_fixture_invariant_claim": bool(
            audit.get("registered_fixture_invariant_claim", False)
        ),
        "complete_candidate_set": bool(audit.get("complete_candidate_set", False)),
        "source_table_candidate_count": int(
            audit.get("source_table_candidate_count", 0) or 0
        ),
        "source_table_candidate_unique_sign_pattern_count": int(
            audit.get("source_table_candidate_unique_sign_pattern_count", 0) or 0
        ),
        "source_table_complete_source_compatible_candidate_count": int(
            audit.get("source_table_complete_source_compatible_candidate_count", 0)
            or 0
        ),
        "source_table_complete_source_compatible_unique_sign_pattern_count": int(
            audit.get(
                "source_table_complete_source_compatible_unique_sign_pattern_count",
                0,
            )
            or 0
        ),
        "source_table_top_candidate_count": int(
            audit.get("source_table_top_candidate_count", 0) or 0
        ),
        "source_table_top_candidate_unique_sign_pattern_count": int(
            audit.get("source_table_top_candidate_unique_sign_pattern_count", 0) or 0
        ),
        "source_table_max_matched_source_value_count": int(
            audit.get("source_table_max_matched_source_value_count", 0) or 0
        ),
        "source_table_max_matched_candidate_total_count": int(
            audit.get("source_table_max_matched_candidate_total_count", 0) or 0
        ),
        "matched_source_table_invariants": list(
            audit.get("matched_source_table_invariants") or []
        ),
        "matched_source_table_invariant_count": int(
            audit.get("matched_source_table_invariant_count", 0) or 0
        ),
        "uncomputed_source_table_invariants": list(
            audit.get("uncomputed_source_table_invariants") or []
        ),
        "uncomputed_source_table_invariant_count": int(
            audit.get("uncomputed_source_table_invariant_count", 0) or 0
        ),
        "mismatched_source_table_invariants": list(
            audit.get("mismatched_source_table_invariants") or []
        ),
        "mismatched_source_table_invariant_count": int(
            audit.get("mismatched_source_table_invariant_count", 0) or 0
        ),
        "unstable_source_table_invariants": list(
            audit.get("unstable_source_table_invariants") or []
        ),
        "unstable_source_table_invariant_count": int(
            audit.get("unstable_source_table_invariant_count", 0) or 0
        ),
        "source_match_resolution_statuses": comparison_statuses,
        "homfly_variant_resolution_status": homfly_variant_status,
        "source_table_registration_ready": bool(
            audit.get("source_table_registration_ready", False)
        ),
        "source_table_registration_blockers": list(
            audit.get("source_table_registration_blockers") or []
        ),
        "source_table_registration_blocker_count": int(
            audit.get("source_table_registration_blocker_count", 0) or 0
        ),
        "source_table_alexander_skipped_common_gcd_attempt_candidate_count": int(
            skipped_attempt_summary.get("candidate_with_attempt_evidence_count", 0)
            or 0
        ),
        "source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count": int(
            skipped_attempt_summary.get("not_certified_candidate_count", 0) or 0
        ),
        "source_table_alexander_skipped_common_gcd_attempt_statuses": list(
            skipped_attempt_summary.get("statuses") or []
        ),
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count": int(
            skipped_attempt_summary.get("direct_divisor_attempt_evidence_count", 0)
            or 0
        ),
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_min": int(
            skipped_attempt_summary.get("direct_divisor_candidate_count_min", 0) or 0
        ),
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_max": int(
            skipped_attempt_summary.get("direct_divisor_candidate_count_max", 0) or 0
        ),
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_min": int(
            skipped_attempt_summary.get("direct_divisor_failed_candidate_count_min", 0)
            or 0
        ),
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max": int(
            skipped_attempt_summary.get("direct_divisor_failed_candidate_count_max", 0)
            or 0
        ),
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed": bool(
            skipped_attempt_summary.get("direct_divisor_all_candidates_failed", False)
        ),
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count": int(
            skipped_attempt_summary.get("support_signature_evidence_count", 0) or 0
        ),
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count": int(
            skipped_attempt_summary.get("support_signature_variant_count", 0) or 0
        ),
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min": int(
            skipped_attempt_summary.get("support_signature_input_count_min", 0) or 0
        ),
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max": int(
            skipped_attempt_summary.get("support_signature_input_count_max", 0) or 0
        ),
        "source_table_alexander_source_divisibility_checked_candidate_count": int(
            source_divisibility_summary.get("checked_candidate_count", 0) or 0
        ),
        "source_table_alexander_source_divisibility_source_divides_all_candidate_count": int(
            source_divisibility_summary.get("source_divides_all_candidate_count", 0)
            or 0
        ),
        "source_table_alexander_source_divisibility_source_division_failed_candidate_count": int(
            source_divisibility_summary.get("source_division_failed_candidate_count", 0)
            or 0
        ),
        "source_table_alexander_source_divisibility_statuses": list(
            source_divisibility_summary.get("statuses") or []
        ),
        "notes": [
            "summary is derived from the lightweight source-table audit with HOMFLY computation disabled",
            "source-table matches remain convention evidence and do not register signed fixture values",
        ],
    }


def _link_table_candidate_summary(candidates: list[dict]) -> dict:
    nontrivial = [
        candidate
        for candidate in candidates
        if candidate.get("link_type") != "unlink"
    ]
    source_table_audit_candidates = [
        candidate
        for candidate in candidates
        if candidate.get("source_table_invariant_audit_available")
    ]
    nontrivial_source_table_audit_candidates = [
        candidate
        for candidate in source_table_audit_candidates
        if candidate.get("link_type") != "unlink"
    ]
    audit_summaries = [
        candidate.get("source_table_invariant_audit_summary")
        for candidate in source_table_audit_candidates
        if isinstance(candidate.get("source_table_invariant_audit_summary"), dict)
    ]
    homfly_variant_statuses = sorted(
        {
            str(summary.get("homfly_variant_resolution_status"))
            for summary in audit_summaries
            if summary.get("homfly_variant_resolution_status")
        }
    )
    registration_blocker_counts: Counter[str] = Counter()
    for summary in audit_summaries:
        blockers = summary.get("source_table_registration_blockers")
        if not isinstance(blockers, list):
            continue
        registration_blocker_counts.update(
            str(blocker) for blocker in blockers if str(blocker)
        )
    registration_blocker_code_counts = [
        {"code": code, "count": count}
        for code, count in sorted(registration_blocker_counts.items())
    ]
    registration_blocker_count_signature = ",".join(
        f"{row['code']}:{row['count']}" for row in registration_blocker_code_counts
    )
    source_match_statuses: list[str] = []
    for summary in audit_summaries:
        raw_statuses = summary.get("source_match_resolution_statuses")
        if not isinstance(raw_statuses, dict):
            continue
        notation = str(summary.get("notation") or "")
        prefix = f"{notation}:" if notation else ""
        for invariant_name, status in raw_statuses.items():
            if status:
                source_match_statuses.append(
                    f"{prefix}{invariant_name}:{status}"
                )
    source_match_statuses = sorted(set(source_match_statuses))
    return {
        "method": "link_table_candidate_summary",
        "candidate_count": len(candidates),
        "nontrivial_candidate_count": len(nontrivial),
        "nontrivial_link_types": [
            str(candidate.get("link_type"))
            for candidate in nontrivial
            if candidate.get("link_type") is not None
        ],
        "nontrivial_notations": [
            str(candidate.get("notation"))
            for candidate in nontrivial
            if candidate.get("notation") is not None
        ],
        "source_table_invariant_audit_available_count": len(
            source_table_audit_candidates
        ),
        "source_table_nontrivial_candidate_count": len(
            nontrivial_source_table_audit_candidates
        ),
        "source_table_nontrivial_candidate_notations": [
            str(candidate.get("notation"))
            for candidate in nontrivial_source_table_audit_candidates
            if candidate.get("notation") is not None
        ],
        "source_table_distinguishing_evidence_available": bool(
            nontrivial_source_table_audit_candidates
        ),
        "stronger_invariants_required": bool(nontrivial),
        "source_table_invariant_audit_summary_count": len(audit_summaries),
        "source_table_registration_ready_count": sum(
            1
            for summary in audit_summaries
            if summary.get("source_table_registration_ready") is True
        ),
        "source_table_registration_blocked_count": sum(
            1
            for summary in audit_summaries
            if summary.get("source_table_registration_ready") is not True
        ),
        "source_table_registration_blocker_count": sum(
            int(summary.get("source_table_registration_blocker_count", 0) or 0)
            for summary in audit_summaries
        ),
        "source_table_registration_blocker_codes": [
            row["code"] for row in registration_blocker_code_counts
        ],
        "source_table_registration_blocker_code_count": len(
            registration_blocker_code_counts
        ),
        "source_table_registration_blocker_code_counts": (
            registration_blocker_code_counts
        ),
        "source_table_registration_blocker_count_signature": (
            registration_blocker_count_signature
        ),
        "source_table_matched_invariant_count": sum(
            int(summary.get("matched_source_table_invariant_count", 0) or 0)
            for summary in audit_summaries
        ),
        "source_table_uncomputed_invariant_count": sum(
            int(summary.get("uncomputed_source_table_invariant_count", 0) or 0)
            for summary in audit_summaries
        ),
        "source_table_mismatched_invariant_count": sum(
            int(summary.get("mismatched_source_table_invariant_count", 0) or 0)
            for summary in audit_summaries
        ),
        "source_table_unstable_invariant_count": sum(
            int(summary.get("unstable_source_table_invariant_count", 0) or 0)
            for summary in audit_summaries
        ),
        "source_table_complete_source_compatible_unique_sign_pattern_count": sum(
            int(
                summary.get(
                    "source_table_complete_source_compatible_unique_sign_pattern_count",
                    0,
                )
                or 0
            )
            for summary in audit_summaries
        ),
        "source_table_top_candidate_count": sum(
            int(summary.get("source_table_top_candidate_count", 0) or 0)
            for summary in audit_summaries
        ),
        "source_table_max_matched_candidate_total_count": sum(
            int(summary.get("source_table_max_matched_candidate_total_count", 0) or 0)
            for summary in audit_summaries
        ),
        "source_table_source_match_resolution_statuses": source_match_statuses,
        "source_table_source_match_resolution_status_count": len(
            source_match_statuses
        ),
        "source_table_homfly_variant_resolution_statuses": homfly_variant_statuses,
        "source_table_alexander_skipped_common_gcd_attempt_candidate_count": sum(
            int(
                summary.get(
                    "source_table_alexander_skipped_common_gcd_attempt_candidate_count",
                    0,
                )
                or 0
            )
            for summary in audit_summaries
        ),
        "source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count": sum(
            int(
                summary.get(
                    "source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count",
                    0,
                )
                or 0
            )
            for summary in audit_summaries
        ),
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count": sum(
            int(
                summary.get(
                    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count",
                    0,
                )
                or 0
            )
            for summary in audit_summaries
        ),
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_min": sum(
            int(
                summary.get(
                    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_min",
                    0,
                )
                or 0
            )
            for summary in audit_summaries
        ),
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_max": sum(
            int(
                summary.get(
                    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_max",
                    0,
                )
                or 0
            )
            for summary in audit_summaries
        ),
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_min": sum(
            int(
                summary.get(
                    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_min",
                    0,
                )
                or 0
            )
            for summary in audit_summaries
        ),
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max": sum(
            int(
                summary.get(
                    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max",
                    0,
                )
                or 0
            )
            for summary in audit_summaries
        ),
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed_summary_count": sum(
            1
            for summary in audit_summaries
            if summary.get(
                "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed"
            )
            is True
        ),
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count": sum(
            int(
                summary.get(
                    "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count",
                    0,
                )
                or 0
            )
            for summary in audit_summaries
        ),
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count": sum(
            int(
                summary.get(
                    "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count",
                    0,
                )
                or 0
            )
            for summary in audit_summaries
        ),
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min": sum(
            int(
                summary.get(
                    "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min",
                    0,
                )
                or 0
            )
            for summary in audit_summaries
        ),
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max": sum(
            int(
                summary.get(
                    "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max",
                    0,
                )
                or 0
            )
            for summary in audit_summaries
        ),
        "source_table_alexander_source_divisibility_checked_candidate_count": sum(
            int(
                summary.get(
                    "source_table_alexander_source_divisibility_checked_candidate_count",
                    0,
                )
                or 0
            )
            for summary in audit_summaries
        ),
        "source_table_alexander_source_divisibility_source_divides_all_candidate_count": sum(
            int(
                summary.get(
                    "source_table_alexander_source_divisibility_source_divides_all_candidate_count",
                    0,
                )
                or 0
            )
            for summary in audit_summaries
        ),
        "source_table_alexander_source_divisibility_source_division_failed_candidate_count": sum(
            int(
                summary.get(
                    "source_table_alexander_source_divisibility_source_division_failed_candidate_count",
                    0,
                )
                or 0
            )
            for summary in audit_summaries
        ),
        "link_types": [
            str(candidate.get("link_type"))
            for candidate in candidates
            if candidate.get("link_type") is not None
        ],
        "notations": [
            str(candidate.get("notation"))
            for candidate in candidates
            if candidate.get("notation") is not None
        ],
        "source_table_audit_notations": [
            str(candidate.get("notation"))
            for candidate in source_table_audit_candidates
            if candidate.get("notation") is not None
        ],
        "ambiguous": len(candidates) > 1,
        "notes": [
            "candidate summary is derived from built-in table rows sharing the pairwise-linking signature",
            "source-table audit availability is evidence for follow-up convention checks, not an automatic classification",
        ],
    }


def _axis_aligned_split_evidence(link: Link3D, *, eps: float = 1e-12) -> dict | None:
    if link.component_count < 2:
        return None

    mins = np.vstack([np.min(component.points, axis=0) for component in link.components])
    maxs = np.vstack([np.max(component.points, axis=0) for component in link.components])
    axis_names = ["x", "y", "z"]

    for axis, axis_name in enumerate(axis_names):
        order = np.argsort(maxs[:, axis])
        left_max = -np.inf
        left_components: list[int] = []
        for split_index in range(link.component_count - 1):
            component_index = int(order[split_index])
            left_components.append(component_index)
            left_max = max(left_max, float(maxs[component_index, axis]))

            right_components = [int(index) for index in order[split_index + 1 :]]
            right_min = float(min(mins[index, axis] for index in right_components))
            if left_max + eps < right_min:
                return {
                    "kind": "axis_aligned_bounding_box_split",
                    "axis": axis_name,
                    "axis_index": axis,
                    "left_components": sorted(left_components),
                    "right_components": sorted(right_components),
                    "gap": right_min - left_max,
                    "split_coordinate": (left_max + right_min) / 2.0,
                }
    return None
