"""Small built-in knot table for MVP classification."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class KnotTableEntry:
    notation: str
    knot_type: str
    minimal_crossing_number: int
    determinant: int
    alexander_polynomial: str
    jones_polynomial: str | None
    chiral: bool
    homfly_polynomial: str | None = None
    aliases: tuple[str, ...] = ()
    source: str = "iroll built-in"
    source_url: str | None = None

    def to_dict(self) -> dict:
        return {
            "notation": self.notation,
            "knot_type": self.knot_type,
            "minimal_crossing_number": self.minimal_crossing_number,
            "determinant": self.determinant,
            "alexander_polynomial": self.alexander_polynomial,
            "jones_polynomial": self.jones_polynomial,
            "homfly_polynomial": self.homfly_polynomial,
            "chiral": self.chiral,
            "aliases": list(self.aliases),
            "source": self.source,
            "source_url": self.source_url,
        }


KNOT_ATLAS = "Knot Atlas"


BUILTIN_KNOT_TABLE = [
    KnotTableEntry(
        notation="0_1",
        knot_type="unknot",
        minimal_crossing_number=0,
        determinant=1,
        alexander_polynomial="1",
        jones_polynomial="1",
        chiral=False,
        aliases=("unknot",),
    ),
    KnotTableEntry(
        notation="3_1",
        knot_type="trefoil",
        minimal_crossing_number=3,
        determinant=3,
        alexander_polynomial="1 - t + t^2",
        jones_polynomial="t^-1 + t^-3 - t^-4",
        chiral=True,
        aliases=("trefoil knot",),
    ),
    KnotTableEntry(
        notation="4_1",
        knot_type="figure_eight",
        minimal_crossing_number=4,
        determinant=5,
        alexander_polynomial="1 - 3t + t^2",
        jones_polynomial="t^-2 - t^-1 + 1 - t + t^2",
        chiral=False,
        aliases=("figure-eight knot",),
    ),
    KnotTableEntry(
        notation="5_1",
        knot_type="cinquefoil",
        minimal_crossing_number=5,
        determinant=5,
        alexander_polynomial="1 - t + t^2 - t^3 + t^4",
        jones_polynomial="-q^-7 + q^-6 - q^-5 + q^-4 + q^-2",
        chiral=True,
        aliases=("torus knot T(5,2)",),
        source=KNOT_ATLAS,
        source_url="https://katlas.org/wiki/5_1",
    ),
    KnotTableEntry(
        notation="5_2",
        knot_type="five_two",
        minimal_crossing_number=5,
        determinant=7,
        alexander_polynomial="2 - 3t + 2t^2",
        jones_polynomial="-q^-6 + q^-5 - q^-4 + 2q^-3 - q^-2 + q^-1",
        homfly_polynomial="-a^6 + a^4z^2 + a^4 + a^2z^2 + a^2",
        chiral=True,
        source=KNOT_ATLAS,
        source_url="https://katlas.org/wiki/5_2",
    ),
    KnotTableEntry(
        notation="6_1",
        knot_type="stevedore",
        minimal_crossing_number=6,
        determinant=9,
        alexander_polynomial="-2 + 5t - 2t^2",
        jones_polynomial="q^2 - q + 2 - 2q^-1 + q^-2 - q^-3 + q^-4",
        homfly_polynomial="a^4 - z^2a^2 - a^2 - z^2 + a^-2",
        chiral=False,
        aliases=("stevedore knot",),
        source=KNOT_ATLAS,
        source_url="https://katlas.org/wiki/6_1",
    ),
    KnotTableEntry(
        notation="6_2",
        knot_type="six_two",
        minimal_crossing_number=6,
        determinant=11,
        alexander_polynomial="1 - 3t + 3t^2 - 3t^3 + t^4",
        jones_polynomial="q - 1 + 2q^-1 - 2q^-2 + 2q^-3 - 2q^-4 + q^-5",
        homfly_polynomial="z^2a^4 + a^4 - z^4a^2 - 3z^2a^2 - 2a^2 + z^2 + 2",
        chiral=True,
        source=KNOT_ATLAS,
        source_url="https://katlas.org/wiki/6_2",
    ),
    KnotTableEntry(
        notation="6_3",
        knot_type="six_three",
        minimal_crossing_number=6,
        determinant=13,
        alexander_polynomial="1 - 3t + 5t^2 - 3t^3 + t^4",
        jones_polynomial="-q^3 + 2q^2 - 2q + 3 - 2q^-1 + 2q^-2 - q^-3",
        chiral=False,
        source=KNOT_ATLAS,
        source_url="https://katlas.org/wiki/6_3",
    ),
]


@dataclass(frozen=True)
class LinkTableEntry:
    notation: str
    link_type: str
    component_count: int
    minimal_crossing_number: int
    pairwise_linking: tuple[int, ...]
    multivariable_alexander_polynomial: str | None = None
    jones_polynomial: str | None = None
    homfly_polynomial: str | None = None
    source_table_jones: str | None = None
    source_table_jones_iroll_normalized: str | None = None
    source_table_homfly: str | None = None
    source_table_homfly_iroll_normalized: str | None = None
    source_table_multivariable_alexander: str | None = None
    source_table_multivariable_alexander_numerator: str | None = None
    source_table_invariant_audit_available: bool = False
    source_table_notes: tuple[str, ...] = ()
    aliases: tuple[str, ...] = ()
    source: str = "iroll built-in"
    source_url: str | None = None

    def to_dict(self) -> dict:
        return {
            "notation": self.notation,
            "link_type": self.link_type,
            "component_count": self.component_count,
            "minimal_crossing_number": self.minimal_crossing_number,
            "pairwise_linking": list(self.pairwise_linking),
            "multivariable_alexander_polynomial": self.multivariable_alexander_polynomial,
            "jones_polynomial": self.jones_polynomial,
            "homfly_polynomial": self.homfly_polynomial,
            "source_table_jones": self.source_table_jones,
            "source_table_jones_iroll_normalized": (
                self.source_table_jones_iroll_normalized
            ),
            "source_table_homfly": self.source_table_homfly,
            "source_table_homfly_iroll_normalized": (
                self.source_table_homfly_iroll_normalized
            ),
            "source_table_multivariable_alexander": (
                self.source_table_multivariable_alexander
            ),
            "source_table_multivariable_alexander_numerator": (
                self.source_table_multivariable_alexander_numerator
            ),
            "source_table_invariant_audit_available": (
                self.source_table_invariant_audit_available
            ),
            "source_table_notes": list(self.source_table_notes),
            "aliases": list(self.aliases),
            "source": self.source,
            "source_url": self.source_url,
        }


BUILTIN_LINK_TABLE = [
    LinkTableEntry(
        notation="L0a1",
        link_type="unlink",
        component_count=2,
        minimal_crossing_number=0,
        pairwise_linking=(0,),
        multivariable_alexander_polynomial="0",
        jones_polynomial="-t^-1 - t",
        aliases=("two-component unlink",),
    ),
    LinkTableEntry(
        notation="L2a1",
        link_type="hopf_link",
        component_count=2,
        minimal_crossing_number=2,
        pairwise_linking=(1,),
        jones_polynomial="-t^-1 - t",
        aliases=("Hopf link",),
    ),
    LinkTableEntry(
        notation="L5a1",
        link_type="whitehead_link",
        component_count=2,
        minimal_crossing_number=5,
        pairwise_linking=(0,),
        source_table_jones=(
            "q^-7/2 - 2q^-5/2 + q^-3/2 - 2q^-1/2 + q^1/2 - q^3/2"
        ),
        source_table_jones_iroll_normalized=(
            "t^-2 - 2t^-1 + 1 - 2t + t^2 - t^3"
        ),
        source_table_homfly=(
            "-a^3*z + a*z^3 + 2a*z + a*z^-1 - a^-1*z - a^-1*z^-1"
        ),
        source_table_homfly_iroll_normalized=(
            "-a^3*z + a*z^3 + 2a*z + a*z^-1 - a^-1*z - a^-1*z^-1"
        ),
        source_table_multivariable_alexander=(
            "(u - 1)*(v - 1)/(sqrt(u)*sqrt(v))"
        ),
        source_table_multivariable_alexander_numerator=(
            "1 - t2 - t1 + t1*t2"
        ),
        source_table_invariant_audit_available=True,
        source_table_notes=(
            "source-table values are available for audit but are not registered as automatic link invariant outputs",
        ),
        aliases=("Whitehead link",),
        source=KNOT_ATLAS,
        source_url="https://katlas.org/wiki/L5a1",
    ),
    LinkTableEntry(
        notation="L6a4",
        link_type="borromean_rings",
        component_count=3,
        minimal_crossing_number=6,
        pairwise_linking=(0, 0, 0),
        source_table_jones=(
            "-q^3 - q^-3 + 3q^2 + 3q^-2 - 2q - 2q^-1 + 4"
        ),
        source_table_jones_iroll_normalized=(
            "-t^-3 + 3t^-2 - 2t^-1 + 4 - 2t + 3t^2 - t^3"
        ),
        source_table_homfly=(
            "-a^2*z^2 - a^-2*z^2 + a^2*z^-2 + a^-2*z^-2 + z^4 + 2z^2 - 2z^-2"
        ),
        source_table_homfly_iroll_normalized=(
            "-a^2*z^2 - a^-2*z^2 + a^2*z^-2 + a^-2*z^-2 + z^4 + 2z^2 - 2z^-2"
        ),
        source_table_multivariable_alexander=(
            "(u - 1)*(v - 1)*(w - 1)/(sqrt(u)*sqrt(v)*sqrt(w))"
        ),
        source_table_multivariable_alexander_numerator=(
            "1 - t3 - t2 + t2*t3 - t1 + t1*t3 + t1*t2 - t1*t2*t3"
        ),
        source_table_invariant_audit_available=True,
        source_table_notes=(
            "source-table values are available for audit but are not registered as automatic link invariant outputs",
        ),
        aliases=("Borromean rings",),
        source=KNOT_ATLAS,
        source_url="https://katlas.org/wiki/L6a4",
    ),
    LinkTableEntry(
        notation="L4a1",
        link_type="solomon_link",
        component_count=2,
        minimal_crossing_number=4,
        pairwise_linking=(2,),
        aliases=("Solomon link",),
        source=KNOT_ATLAS,
        source_url="https://katlas.org/wiki/L4a1",
    ),
]


def lookup_knot(
    *,
    determinant: int,
    alexander_polynomial: str | None = None,
    crossing_count: int | None = None,
) -> KnotTableEntry | None:
    if crossing_count == 0 and determinant == 1:
        return BUILTIN_KNOT_TABLE[0]

    if alexander_polynomial is not None:
        for entry in BUILTIN_KNOT_TABLE:
            if (
                entry.determinant == determinant
                and entry.alexander_polynomial == alexander_polynomial
            ):
                return entry

    determinant_matches = [
        entry
        for entry in BUILTIN_KNOT_TABLE
        if entry.determinant == determinant
        and entry.notation != "0_1"
        and (
            crossing_count is None
            or crossing_count >= entry.minimal_crossing_number
        )
    ]
    if len(determinant_matches) == 1:
        return determinant_matches[0]
    return None


def builtin_knot_table() -> list[dict]:
    return [entry.to_dict() for entry in BUILTIN_KNOT_TABLE]


def builtin_link_table() -> list[dict]:
    return [entry.to_dict() for entry in BUILTIN_LINK_TABLE]


def lookup_link(
    *,
    link_type: str | None = None,
    component_count: int | None = None,
    pairwise_linking: tuple[int, ...] | None = None,
) -> LinkTableEntry | None:
    for entry in BUILTIN_LINK_TABLE:
        if link_type is not None and entry.link_type != link_type:
            continue
        if component_count is not None and entry.component_count != component_count:
            continue
        if pairwise_linking is not None and entry.pairwise_linking != pairwise_linking:
            continue
        return entry
    return None


def jones_polynomial_for_entry(
    entry: KnotTableEntry | None,
    *,
    chirality: str,
) -> tuple[str | None, str | None]:
    if entry is None or entry.jones_polynomial is None:
        return None, None
    if "q" in entry.jones_polynomial:
        return entry.jones_polynomial, "built_in_knot_table_source_convention"
    if not entry.chiral:
        return entry.jones_polynomial, "built_in_knot_table"
    if chirality == "negative":
        return entry.jones_polynomial, "built_in_knot_table_chirality"
    if chirality == "positive":
        return mirror_laurent_polynomial(entry.jones_polynomial), "built_in_knot_table_chirality"
    return None, "requires_stable_chirality"


def mirror_laurent_polynomial(polynomial: str) -> str:
    terms = _parse_laurent(polynomial)
    mirrored = {-exponent: coefficient for exponent, coefficient in terms.items()}
    return _format_laurent(mirrored)


def _parse_laurent(polynomial: str) -> dict[int, int]:
    normalized = polynomial.replace(" - ", " + -")
    terms: dict[int, int] = {}
    for raw_part in normalized.split(" + "):
        part = raw_part.strip()
        if not part:
            continue
        coefficient, exponent = _parse_term(part)
        terms[exponent] = terms.get(exponent, 0) + coefficient
    return {exponent: coefficient for exponent, coefficient in terms.items() if coefficient}


def _parse_term(term: str) -> tuple[int, int]:
    if "t" not in term:
        return int(term), 0

    prefix, _, suffix = term.partition("t")
    if prefix in {"", "+"}:
        coefficient = 1
    elif prefix == "-":
        coefficient = -1
    else:
        coefficient = int(prefix)

    if suffix.startswith("^"):
        exponent = int(suffix[1:])
    else:
        exponent = 1
    return coefficient, exponent


def _format_laurent(terms: dict[int, int]) -> str:
    if not terms:
        return "0"
    parts = []
    for exponent in sorted(terms, reverse=True):
        coefficient = terms[exponent]
        sign = "-" if coefficient < 0 else "+"
        magnitude = abs(coefficient)
        if exponent == 0:
            body = str(magnitude)
        elif exponent == 1:
            body = "t" if magnitude == 1 else f"{magnitude}t"
        else:
            body = f"t^{exponent}" if magnitude == 1 else f"{magnitude}t^{exponent}"
        parts.append((sign, body))

    first_sign, first_body = parts[0]
    text = first_body if first_sign == "+" else f"-{first_body}"
    for sign, body in parts[1:]:
        text += f" {sign} {body}"
    return text
