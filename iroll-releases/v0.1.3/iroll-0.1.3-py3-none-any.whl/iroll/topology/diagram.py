"""Knot diagram representations derived from projected crossings."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np

from iroll.topology.crossings import Crossing


@dataclass(frozen=True)
class ArcRelation:
    crossing_index: int
    over_arc: int
    under_before_arc: int
    under_after_arc: int
    sign: int
    over_position: float
    under_position: float

    def to_dict(self) -> dict[str, int | float]:
        return {
            "crossing_index": self.crossing_index,
            "over_arc": self.over_arc,
            "under_before_arc": self.under_before_arc,
            "under_after_arc": self.under_after_arc,
            "sign": self.sign,
            "over_position": self.over_position,
            "under_position": self.under_position,
        }


@dataclass(frozen=True)
class KnotDiagram:
    crossings: list[Crossing]
    under_positions: list[float]
    arc_relations: list[ArcRelation]
    coloring_matrix: np.ndarray

    @property
    def crossing_count(self) -> int:
        return len(self.crossings)

    @property
    def arc_count(self) -> int:
        return len(self.under_positions)

    def gauss_code(self) -> list[dict[str, int | float | str]]:
        events = []
        for index, crossing in enumerate(self.crossings):
            events.append(
                {
                    "crossing_index": index,
                    "kind": "over",
                    "position": _over_position(crossing),
                    "sign": crossing.sign,
                }
            )
            events.append(
                {
                    "crossing_index": index,
                    "kind": "under",
                    "position": _under_position(crossing),
                    "sign": crossing.sign,
                }
            )
        return sorted(events, key=lambda event: float(event["position"]))

    def pd_code(self) -> list[dict[str, int | list[int]]]:
        """Return a compact PD-style code derived from arc relations.

        The tuple follows iroll's internal arc convention:
        [under_before, over, under_after, over].
        """

        return [
            {
                "crossing_index": relation.crossing_index,
                "code": [
                    relation.under_before_arc,
                    relation.over_arc,
                    relation.under_after_arc,
                    relation.over_arc,
                ],
                "sign": relation.sign,
            }
            for relation in self.arc_relations
        ]

    def to_dict(self, *, include_matrix: bool = False) -> dict:
        payload = {
            "crossing_count": self.crossing_count,
            "arc_count": self.arc_count,
            "under_positions": self.under_positions,
            "arc_relations": [relation.to_dict() for relation in self.arc_relations],
            "gauss_code": self.gauss_code(),
            "pd_code": self.pd_code(),
        }
        if include_matrix:
            payload["coloring_matrix"] = [
                [int(value) for value in row] for row in self.coloring_matrix.tolist()
            ]
        return payload


def build_knot_diagram(crossings: Iterable[Crossing]) -> KnotDiagram:
    crossings = list(crossings)
    under_positions = sorted(_under_position(crossing) for crossing in crossings)
    coloring_matrix = _coloring_matrix(crossings, under_positions)
    relations = _arc_relations(crossings, under_positions)
    return KnotDiagram(
        crossings=crossings,
        under_positions=under_positions,
        arc_relations=relations,
        coloring_matrix=coloring_matrix,
    )


def knot_determinant_from_diagram(diagram: KnotDiagram) -> int:
    if diagram.crossing_count == 0:
        return 1
    if diagram.coloring_matrix.shape[0] <= 1:
        return 0
    minor = diagram.coloring_matrix[:-1, :-1]
    return abs(bareiss_det(minor))


def alexander_polynomial_from_diagram(
    diagram: KnotDiagram,
    *,
    max_crossings: int = 8,
) -> str | None:
    """Return a small normalized Alexander polynomial string when feasible.

    The implementation uses the oriented arc relations already used by the
    determinant classifier. It intentionally caps crossing count because this
    pure Python polynomial determinant is meant as a correctness-oriented MVP.
    """

    if diagram.crossing_count == 0:
        return "1"
    if diagram.crossing_count > max_crossings or diagram.arc_count <= 1:
        return None
    matrix = _alexander_matrix(diagram)
    minor = [row[:-1] for row in matrix[:-1]]
    return _format_laurent(_normalize_laurent(_poly_det(minor)))


def bareiss_det(matrix: np.ndarray) -> int:
    size = matrix.shape[0]
    if size == 0:
        return 1

    work = [[int(matrix[row, col]) for col in range(size)] for row in range(size)]
    sign = 1
    previous = 1
    for k in range(size - 1):
        if work[k][k] == 0:
            swap = next((row for row in range(k + 1, size) if work[row][k] != 0), None)
            if swap is None:
                return 0
            work[k], work[swap] = work[swap], work[k]
            sign *= -1

        pivot = work[k][k]
        for i in range(k + 1, size):
            for j in range(k + 1, size):
                work[i][j] = (work[i][j] * pivot - work[i][k] * work[k][j]) // previous
        previous = pivot
        for i in range(k + 1, size):
            work[i][k] = 0
        for j in range(k + 1, size):
            work[k][j] = 0

    return sign * work[size - 1][size - 1]


def _alexander_matrix(diagram: KnotDiagram) -> list[list[dict[int, int]]]:
    size = diagram.arc_count
    matrix = [[{} for _ in range(size)] for _ in range(size)]
    one_minus_t = {0: 1, 1: -1}
    t = {1: 1}
    minus_one = {0: -1}

    for row, relation in enumerate(diagram.arc_relations):
        _poly_add_into(matrix[row][relation.over_arc], one_minus_t)
        if relation.sign >= 0:
            _poly_add_into(matrix[row][relation.under_before_arc], t)
            _poly_add_into(matrix[row][relation.under_after_arc], minus_one)
        else:
            _poly_add_into(matrix[row][relation.under_before_arc], minus_one)
            _poly_add_into(matrix[row][relation.under_after_arc], t)
    return matrix


def _poly_det(matrix: list[list[dict[int, int]]]) -> dict[int, int]:
    size = len(matrix)
    if size == 0:
        return {0: 1}
    if size == 1:
        return dict(matrix[0][0])

    total: dict[int, int] = {}
    for column in range(size):
        term = _poly_mul(
            matrix[0][column],
            _poly_det([row[:column] + row[column + 1 :] for row in matrix[1:]]),
        )
        if column % 2:
            term = _poly_scale(term, -1)
        total = _poly_add(total, term)
    return total


def _poly_add(left: dict[int, int], right: dict[int, int]) -> dict[int, int]:
    result = dict(left)
    _poly_add_into(result, right)
    return result


def _poly_add_into(left: dict[int, int], right: dict[int, int]) -> None:
    for exponent, coefficient in right.items():
        value = left.get(exponent, 0) + coefficient
        if value:
            left[exponent] = value
        elif exponent in left:
            del left[exponent]


def _poly_mul(left: dict[int, int], right: dict[int, int]) -> dict[int, int]:
    result: dict[int, int] = {}
    for left_exp, left_coeff in left.items():
        for right_exp, right_coeff in right.items():
            exponent = left_exp + right_exp
            result[exponent] = result.get(exponent, 0) + left_coeff * right_coeff
    return {exponent: coeff for exponent, coeff in result.items() if coeff}


def _poly_scale(poly: dict[int, int], factor: int) -> dict[int, int]:
    return {
        exponent: coefficient * factor
        for exponent, coefficient in poly.items()
        if coefficient * factor
    }


def _normalize_laurent(poly: dict[int, int]) -> dict[int, int]:
    if not poly:
        return {}
    min_exp = min(poly)
    shifted = {exponent - min_exp: coefficient for exponent, coefficient in poly.items()}
    max_exp = max(shifted)
    if shifted[max_exp] < 0:
        shifted = _poly_scale(shifted, -1)
    return shifted


def _format_laurent(poly: dict[int, int]) -> str:
    if not poly:
        return "0"
    parts = []
    for exponent in sorted(poly):
        coefficient = poly[exponent]
        sign = "-" if coefficient < 0 else "+"
        magnitude = abs(coefficient)
        if exponent == 0:
            term = str(magnitude)
        elif exponent == 1:
            term = "t" if magnitude == 1 else f"{magnitude}t"
        else:
            term = f"t^{exponent}" if magnitude == 1 else f"{magnitude}t^{exponent}"
        parts.append((sign, term))

    first_sign, first_term = parts[0]
    text = first_term if first_sign == "+" else f"-{first_term}"
    for sign, term in parts[1:]:
        text += f" {sign} {term}"
    return text


def _coloring_matrix(crossings: list[Crossing], under_positions: list[float]) -> np.ndarray:
    size = len(under_positions)
    matrix = np.zeros((size, size), dtype=object)

    for row, crossing in enumerate(crossings):
        under_position = _under_position(crossing)
        under_index = _find_position_index(under_positions, under_position)
        under_before = (under_index - 1) % size
        under_after = under_index
        over_arc = _arc_at_position(under_positions, _over_position(crossing))

        matrix[row, over_arc] += 2
        matrix[row, under_before] -= 1
        matrix[row, under_after] -= 1
    return matrix


def _arc_relations(
    crossings: list[Crossing],
    under_positions: list[float],
) -> list[ArcRelation]:
    relations = []
    for index, crossing in enumerate(crossings):
        under_position = _under_position(crossing)
        under_index = _find_position_index(under_positions, under_position)
        relations.append(
            ArcRelation(
                crossing_index=index,
                over_arc=_arc_at_position(under_positions, _over_position(crossing)),
                under_before_arc=(under_index - 1) % len(under_positions),
                under_after_arc=under_index,
                sign=crossing.sign,
                over_position=_over_position(crossing),
                under_position=under_position,
            )
        )
    return relations


def _under_position(crossing: Crossing) -> float:
    if _a_is_over(crossing):
        return crossing.segment_b + crossing.parameter_b
    return crossing.segment_a + crossing.parameter_a


def _over_position(crossing: Crossing) -> float:
    if _a_is_over(crossing):
        return crossing.segment_a + crossing.parameter_a
    return crossing.segment_b + crossing.parameter_b


def _a_is_over(crossing: Crossing) -> bool:
    return (
        crossing.over_component == crossing.component_a
        and crossing.over_segment == crossing.segment_a
    )


def _find_position_index(positions: list[float], target: float) -> int:
    distances = [abs(position - target) for position in positions]
    return int(np.argmin(distances))


def _arc_at_position(under_positions: list[float], position: float) -> int:
    index = int(np.searchsorted(under_positions, position, side="right")) - 1
    if index < 0:
        return len(under_positions) - 1
    return index
