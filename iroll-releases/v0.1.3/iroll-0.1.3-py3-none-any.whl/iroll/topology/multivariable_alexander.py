"""Multi-variable Alexander polynomial and Fox-calculus helpers."""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
from itertools import combinations
from math import comb, gcd
import re
from typing import Iterable, Mapping, Sequence

from iroll.topology.knot_table import lookup_link
from iroll.topology.pd import PDOrientation, PlanarDiagram
from iroll.topology.polynomial import (
    MultivariateLaurentPolynomial,
    parse_multivariate_laurent_polynomial,
)

FoxWord = Sequence[tuple[int, int]]

_BOUNDED_MULTIVARIATE_COMMON_GCD_MAX_TERMS = 14
_BOUNDED_MULTIVARIATE_ROOT_BINOMIAL_MAX_FACTORS = 4
_BOUNDED_MULTIVARIATE_ROOT_BINOMIAL_MAX_CANDIDATES = 512
_BOUNDED_MULTIVARIATE_SPARSE_FACTOR_MAX_FACTORS = 4
_BOUNDED_MULTIVARIATE_SPARSE_FACTOR_MAX_CANDIDATES = 2048
_BOUNDED_MULTIVARIATE_COFACTOR_MAX_DIVISOR_FACTORS = 2
_BOUNDED_MULTIVARIATE_COFACTOR_MAX_CANDIDATES = 512
_OPTIONAL_SYMBOLIC_MULTIVARIATE_GCD_MAX_VARIABLES = 4
_OPTIONAL_SYMBOLIC_MULTIVARIATE_GCD_MAX_POLYNOMIALS = 8
_OPTIONAL_SYMBOLIC_MULTIVARIATE_GCD_MAX_TOTAL_TERMS = 128
_ALEXANDER_AUDIT_WITNESS_LIMIT = 8
_ADMISSIBLE_MINOR_NORMALIZATION_MISMATCH_WITNESS_LIMIT = 8
_ALEXANDER_MATURITY_NOT_CERTIFIED = "not_certified"
_ALEXANDER_MATURITY_ZERO_CROSSING_UNLINK = "zero_crossing_unlink_terminal"
_ALEXANDER_MATURITY_EXACT_SCANNED_GCD = "exact_scanned_gcd"
_ALEXANDER_MATURITY_LAURENT_UNIT_CONSENSUS = (
    "laurent_unit_normalization_consensus"
)
_ALEXANDER_MATURITY_GENERAL_GCD_WITHOUT_UNIT_CONSENSUS = (
    "general_gcd_without_unit_normalization_consensus"
)
_ALEXANDER_MATURITY_SOURCE_TABLE_DIAGNOSTIC = "source_table_diagnostic_only"
_ALEXANDER_MATURITY_CERTIFIED_PATHS = {
    _ALEXANDER_MATURITY_ZERO_CROSSING_UNLINK,
    _ALEXANDER_MATURITY_EXACT_SCANNED_GCD,
    _ALEXANDER_MATURITY_LAURENT_UNIT_CONSENSUS,
    _ALEXANDER_MATURITY_GENERAL_GCD_WITHOUT_UNIT_CONSENSUS,
}

def _empty_fox_minor_validation_witness_fields() -> dict:
    witness_limit = _ALEXANDER_AUDIT_WITNESS_LIMIT
    reference_witnesses: list[dict] = []
    normalization_witnesses: list[dict] = []
    return {
        "invalid_minor_reference_witness_count": 0,
        "invalid_minor_reference_witness_limit": witness_limit,
        "invalid_minor_reference_witness_truncated": False,
        "invalid_minor_reference_witnesses": reference_witnesses,
        "invalid_minor_reference_witness_consistency": (
            _bounded_witness_consistency_summary(
                witness_kind="invalid_minor_reference",
                witness_count=0,
                witness_limit=witness_limit,
                witness_truncated=False,
                witnesses=reference_witnesses,
            )
        ),
        "invalid_normalization_witness_count": 0,
        "invalid_normalization_witness_limit": witness_limit,
        "invalid_normalization_witness_truncated": False,
        "invalid_normalization_witnesses": normalization_witnesses,
        "invalid_normalization_witness_consistency": (
            _bounded_witness_consistency_summary(
                witness_kind="invalid_minor_normalization",
                witness_count=0,
                witness_limit=witness_limit,
                witness_truncated=False,
                witnesses=normalization_witnesses,
            )
        ),
    }


def _minor_validation_witness(
    minor_index: int,
    minor: object,
    *,
    validation_kind: str,
    issues: Sequence[str],
) -> dict:
    issue_list = [str(issue) for issue in issues]
    if isinstance(minor, dict):
        rows = minor.get("rows", [])
        columns = minor.get("columns", [])
        return {
            "minor_index": int(minor_index),
            "validation_kind": str(validation_kind),
            "rows": list(rows) if isinstance(rows, list) else [],
            "columns": list(columns) if isinstance(columns, list) else [],
            "minor_polynomial": minor.get("polynomial"),
            "raw_polynomial": minor.get("raw_polynomial"),
            "issue_count": len(issue_list),
            "issues": issue_list,
        }
    return {
        "minor_index": int(minor_index),
        "validation_kind": str(validation_kind),
        "rows": [],
        "columns": [],
        "minor_polynomial": None,
        "raw_polynomial": None,
        "issue_count": len(issue_list),
        "issues": issue_list,
    }


def _fox_minor_validation_witness_fields(
    *,
    reference_witnesses: Sequence[dict],
    normalization_witnesses: Sequence[dict],
    limit: int = _ALEXANDER_AUDIT_WITNESS_LIMIT,
) -> dict:
    witness_limit = _witness_limit_int(
        limit,
        fallback=_ALEXANDER_AUDIT_WITNESS_LIMIT,
    )
    reference_witness_list = _dict_sequence(reference_witnesses)
    normalization_witness_list = _dict_sequence(normalization_witnesses)
    emitted_reference_witnesses = reference_witness_list[:witness_limit]
    emitted_normalization_witnesses = normalization_witness_list[:witness_limit]
    reference_witness_count = len(reference_witness_list)
    normalization_witness_count = len(normalization_witness_list)
    reference_truncated = reference_witness_count > len(emitted_reference_witnesses)
    normalization_truncated = (
        normalization_witness_count > len(emitted_normalization_witnesses)
    )
    return {
        "invalid_minor_reference_witness_count": reference_witness_count,
        "invalid_minor_reference_witness_limit": witness_limit,
        "invalid_minor_reference_witness_truncated": reference_truncated,
        "invalid_minor_reference_witnesses": emitted_reference_witnesses,
        "invalid_minor_reference_witness_consistency": (
            _bounded_witness_consistency_summary(
                witness_kind="invalid_minor_reference",
                witness_count=reference_witness_count,
                witness_limit=witness_limit,
                witness_truncated=reference_truncated,
                witnesses=emitted_reference_witnesses,
            )
        ),
        "invalid_normalization_witness_count": normalization_witness_count,
        "invalid_normalization_witness_limit": witness_limit,
        "invalid_normalization_witness_truncated": normalization_truncated,
        "invalid_normalization_witnesses": emitted_normalization_witnesses,
        "invalid_normalization_witness_consistency": (
            _bounded_witness_consistency_summary(
                witness_kind="invalid_minor_normalization",
                witness_count=normalization_witness_count,
                witness_limit=witness_limit,
                witness_truncated=normalization_truncated,
                witnesses=emitted_normalization_witnesses,
            )
        ),
    }


def _fox_square_minor_validation_witness_evidence_fields(
    audit: dict | None,
) -> dict:
    if not isinstance(audit, dict) or audit.get("skipped", False):
        source_fields = _empty_fox_minor_validation_witness_fields()
    else:
        source_fields = _fox_minor_validation_witness_fields(
            reference_witnesses=_dict_sequence(
                audit.get("invalid_minor_reference_witnesses", [])
            ),
            normalization_witnesses=_dict_sequence(
                audit.get("invalid_normalization_witnesses", [])
            ),
            limit=_witness_limit_int(
                audit.get(
                    "invalid_normalization_witness_limit",
                    audit.get(
                        "invalid_minor_reference_witness_limit",
                        _ALEXANDER_AUDIT_WITNESS_LIMIT,
                    ),
                ),
                fallback=_ALEXANDER_AUDIT_WITNESS_LIMIT,
            ),
        )
        source_fields["invalid_minor_reference_witness_count"] = _blocker_int(
            audit.get(
                "invalid_minor_reference_witness_count",
                audit.get("invalid_minor_reference_count", 0),
            ),
            fallback=source_fields["invalid_minor_reference_witness_count"],
        )
        source_fields["invalid_normalization_witness_count"] = _blocker_int(
            audit.get(
                "invalid_normalization_witness_count",
                audit.get("invalid_normalization_count", 0),
            ),
            fallback=source_fields["invalid_normalization_witness_count"],
        )
        source_fields["invalid_minor_reference_witness_truncated"] = bool(
            audit.get(
                "invalid_minor_reference_witness_truncated",
                source_fields["invalid_minor_reference_witness_truncated"],
            )
        )
        source_fields["invalid_normalization_witness_truncated"] = bool(
            audit.get(
                "invalid_normalization_witness_truncated",
                source_fields["invalid_normalization_witness_truncated"],
            )
        )
        source_fields["invalid_minor_reference_witness_consistency"] = (
            _bounded_witness_consistency_summary(
                witness_kind="invalid_minor_reference",
                witness_count=source_fields["invalid_minor_reference_witness_count"],
                witness_limit=source_fields["invalid_minor_reference_witness_limit"],
                witness_truncated=source_fields[
                    "invalid_minor_reference_witness_truncated"
                ],
                witnesses=source_fields["invalid_minor_reference_witnesses"],
            )
        )
        source_fields["invalid_normalization_witness_consistency"] = (
            _bounded_witness_consistency_summary(
                witness_kind="invalid_minor_normalization",
                witness_count=source_fields["invalid_normalization_witness_count"],
                witness_limit=source_fields["invalid_normalization_witness_limit"],
                witness_truncated=source_fields[
                    "invalid_normalization_witness_truncated"
                ],
                witnesses=source_fields["invalid_normalization_witnesses"],
            )
        )

    return {
        "fox_square_minor_invalid_reference_witness_count": source_fields[
            "invalid_minor_reference_witness_count"
        ],
        "fox_square_minor_invalid_reference_witness_limit": source_fields[
            "invalid_minor_reference_witness_limit"
        ],
        "fox_square_minor_invalid_reference_witness_truncated": source_fields[
            "invalid_minor_reference_witness_truncated"
        ],
        "fox_square_minor_invalid_reference_witnesses": source_fields[
            "invalid_minor_reference_witnesses"
        ],
        "fox_square_minor_invalid_reference_witness_consistency": source_fields[
            "invalid_minor_reference_witness_consistency"
        ],
        "fox_square_minor_invalid_normalization_witness_count": source_fields[
            "invalid_normalization_witness_count"
        ],
        "fox_square_minor_invalid_normalization_witness_limit": source_fields[
            "invalid_normalization_witness_limit"
        ],
        "fox_square_minor_invalid_normalization_witness_truncated": source_fields[
            "invalid_normalization_witness_truncated"
        ],
        "fox_square_minor_invalid_normalization_witnesses": source_fields[
            "invalid_normalization_witnesses"
        ],
        "fox_square_minor_invalid_normalization_witness_consistency": source_fields[
            "invalid_normalization_witness_consistency"
        ],
    }

def _empty_division_failure_witness_fields() -> dict:
    witness_count = 0
    witness_limit = _ALEXANDER_AUDIT_WITNESS_LIMIT
    witness_truncated = False
    witnesses: list[dict] = []
    return {
        "failed_division_witness_count": witness_count,
        "failed_division_witness_limit": witness_limit,
        "failed_division_witness_truncated": witness_truncated,
        "failed_division_witnesses": witnesses,
        "failed_division_witness_consistency": _bounded_witness_consistency_summary(
            witness_kind="failed_division",
            witness_count=witness_count,
            witness_limit=witness_limit,
            witness_truncated=witness_truncated,
            witnesses=witnesses,
        ),
    }


def _division_failure_witness_fields(
    division_records: Sequence[dict],
    *,
    limit: int = _ALEXANDER_AUDIT_WITNESS_LIMIT,
) -> dict:
    witness_limit = _witness_limit_int(
        limit,
        fallback=_ALEXANDER_AUDIT_WITNESS_LIMIT,
    )
    failed_records = [
        record for record in division_records if not bool(record.get("divisible"))
    ]
    witnesses = [
        {
            "minor_index": int(record.get("minor_index", index)),
            "rows": list(record.get("rows", [])),
            "columns": list(record.get("columns", [])),
            "minor_polynomial": record.get("minor_polynomial"),
            "divisible": False,
            "quotient_polynomial": record.get("quotient_polynomial"),
        }
        for index, record in enumerate(failed_records[:witness_limit])
    ]
    witness_count = len(failed_records)
    witness_truncated = witness_count > len(witnesses)
    return {
        "failed_division_witness_count": witness_count,
        "failed_division_witness_limit": witness_limit,
        "failed_division_witness_truncated": witness_truncated,
        "failed_division_witnesses": witnesses,
        "failed_division_witness_consistency": _bounded_witness_consistency_summary(
            witness_kind="failed_division",
            witness_count=witness_count,
            witness_limit=witness_limit,
            witness_truncated=witness_truncated,
            witnesses=witnesses,
        ),
    }


def _division_failure_witness_fields_from_minors(
    indexed_minors: Sequence[tuple[int, dict]],
    *,
    reason: str,
    limit: int = _ALEXANDER_AUDIT_WITNESS_LIMIT,
) -> dict:
    witness_limit = _witness_limit_int(
        limit,
        fallback=_ALEXANDER_AUDIT_WITNESS_LIMIT,
    )
    witnesses = [
        {
            "minor_index": int(index),
            "rows": list(minor.get("rows", [])),
            "columns": list(minor.get("columns", [])),
            "minor_polynomial": minor.get("polynomial"),
            "divisible": False,
            "quotient_polynomial": None,
            "reason": reason,
        }
        for index, minor in indexed_minors[:witness_limit]
    ]
    witness_count = len(indexed_minors)
    witness_truncated = witness_count > len(witnesses)
    return {
        "failed_division_witness_count": witness_count,
        "failed_division_witness_limit": witness_limit,
        "failed_division_witness_truncated": witness_truncated,
        "failed_division_witnesses": witnesses,
        "failed_division_witness_consistency": _bounded_witness_consistency_summary(
            witness_kind="failed_division",
            witness_count=witness_count,
            witness_limit=witness_limit,
            witness_truncated=witness_truncated,
            witnesses=witnesses,
        ),
    }


def _empty_failed_input_witness_fields() -> dict:
    witness_count = 0
    witness_limit = _ALEXANDER_AUDIT_WITNESS_LIMIT
    witness_truncated = False
    witnesses: list[dict] = []
    return {
        "failed_input_witness_count": witness_count,
        "failed_input_witness_limit": witness_limit,
        "failed_input_witness_truncated": witness_truncated,
        "failed_input_witnesses": witnesses,
        "first_failed_input_witness": None,
        "failed_input_witness_consistency": _bounded_witness_consistency_summary(
            witness_kind="source_divisibility_failed_input",
            witness_count=witness_count,
            witness_limit=witness_limit,
            witness_truncated=witness_truncated,
            witnesses=witnesses,
        ),
    }


def _failed_input_witness_fields_from_division_records(
    division_records: Sequence[dict],
    *,
    limit: int = _ALEXANDER_AUDIT_WITNESS_LIMIT,
) -> dict:
    witness_limit = _witness_limit_int(
        limit,
        fallback=_ALEXANDER_AUDIT_WITNESS_LIMIT,
    )
    failed_records = [
        record for record in division_records if not bool(record.get("divisible"))
    ]
    witnesses = []
    for index, record in enumerate(failed_records[:witness_limit]):
        witness = {
            "input_index": int(record.get("input_index", index)),
            "input_polynomial": record.get("input_polynomial"),
            "divisible": False,
            "invalid": bool(record.get("invalid", False)),
            "quotient_polynomial": record.get("quotient_polynomial"),
        }
        if record.get("parse_error") is not None:
            witness["parse_error"] = str(record.get("parse_error"))
        witnesses.append(witness)
    witness_count = len(failed_records)
    witness_truncated = witness_count > len(witnesses)
    return {
        "failed_input_witness_count": witness_count,
        "failed_input_witness_limit": witness_limit,
        "failed_input_witness_truncated": witness_truncated,
        "failed_input_witnesses": witnesses,
        "first_failed_input_witness": witnesses[0] if witnesses else None,
        "failed_input_witness_consistency": _bounded_witness_consistency_summary(
            witness_kind="source_divisibility_failed_input",
            witness_count=witness_count,
            witness_limit=witness_limit,
            witness_truncated=witness_truncated,
            witnesses=witnesses,
        ),
    }


def _quotient_polynomial_count_consistency(
    quotient_polynomials: Sequence[str],
) -> dict:
    quotient_list = [str(polynomial) for polynomial in quotient_polynomials]
    quotient_count = len(quotient_list)
    unique_count = len(set(quotient_list))
    return {
        "method": "quotient_polynomial_count_consistency",
        "claim_scope": "bounded_scanned_fox_minor_quotient_gcd_uncertainty",
        "quotient_polynomial_count": quotient_count,
        "quotient_polynomial_list_count": len(quotient_list),
        "unique_quotient_polynomial_count": unique_count,
        "unique_quotient_polynomial_list_count": unique_count,
        "quotient_polynomial_count_matches_list": True,
        "unique_quotient_polynomial_count_matches_list": True,
        "quotient_polynomial_count_covers_unique_count": quotient_count >= unique_count,
        "count_list_consistent": True,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
    }


def _quotient_polynomial_witness_fields(
    quotient_polynomials: Sequence[object],
    *,
    variables: Sequence[str],
    limit: int = _ALEXANDER_AUDIT_WITNESS_LIMIT,
) -> dict:
    witness_limit = _witness_limit_int(
        limit,
        fallback=_ALEXANDER_AUDIT_WITNESS_LIMIT,
    )
    variable_names = list(variables)
    witnesses = []
    for index, value in enumerate(quotient_polynomials[:witness_limit]):
        polynomial = None
        if isinstance(value, MultivariateLaurentPolynomial):
            polynomial = value.normalize_unit()
            polynomial_text = polynomial.format()
        else:
            polynomial_text = str(value)
            if variable_names:
                try:
                    polynomial = parse_multivariate_laurent_polynomial(
                        polynomial_text,
                        variables=tuple(variable_names),
                    ).normalize_unit()
                except ValueError:
                    polynomial = None
        witness = {
            "quotient_index": index,
            "quotient_polynomial": polynomial_text,
        }
        if polynomial is not None:
            support = _polynomial_variable_support(polynomial)
            witness["quotient_term_count"] = len(polynomial.terms)
            witness["variable_support"] = [
                variable_names[support_index]
                for support_index in sorted(support)
                if support_index < len(variable_names)
            ]
        witnesses.append(witness)
    witness_count = len(quotient_polynomials)
    witness_truncated = witness_count > len(witnesses)
    return {
        "quotient_polynomial_witness_count": witness_count,
        "quotient_polynomial_witness_limit": witness_limit,
        "quotient_polynomial_witness_truncated": witness_truncated,
        "quotient_polynomial_witnesses": witnesses,
        "first_quotient_polynomial_witness": witnesses[0] if witnesses else None,
        "quotient_polynomial_witness_consistency": (
            _bounded_witness_consistency_summary(
                witness_kind="quotient_polynomial",
                witness_count=witness_count,
                witness_limit=witness_limit,
                witness_truncated=witness_truncated,
                witnesses=witnesses,
            )
        ),
    }


def _empty_quotient_gcd_uncertainty_fields() -> dict:
    return {"quotient_gcd_uncertainty_evidence": None}


def _quotient_gcd_uncertainty_evidence(
    quotient_polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    variables: Sequence[str],
    complete_combination_scan: bool,
    truncated: bool,
) -> dict:
    normalized = [
        polynomial.normalize_unit()
        for polynomial in quotient_polynomials
    ]
    quotient_polynomial_list = [
        polynomial.format()
        for polynomial in normalized
    ]
    supports = [_polynomial_variable_support(polynomial) for polynomial in normalized]
    common_support = set.intersection(*supports) if supports else set()
    return {
        "method": "fox_square_minor_quotient_gcd_uncertainty_evidence",
        "claim_scope": "bounded_scanned_fox_minor_quotient_gcd_uncertainty",
        "variables": list(variables),
        "status": "not_certified",
        "certified": False,
        "quotient_polynomial_count": len(normalized),
        "unique_quotient_polynomial_count": len(
            set(quotient_polynomial_list)
        ),
        "quotient_polynomials": quotient_polynomial_list,
        "quotient_polynomial_count_consistency": (
            _quotient_polynomial_count_consistency(quotient_polynomial_list)
        ),
        **_quotient_polynomial_witness_fields(
            normalized,
            variables=variables,
        ),
        "common_variable_support": [
            variables[index]
            for index in sorted(common_support)
            if index < len(variables)
        ],
        "candidate_methods_attempted": [
            "quotient_unit_witness_gcd",
            "quotient_integer_content_gcd",
            "quotient_disjoint_support_unit_gcd",
            "quotient_conservative_common_laurent_gcd",
        ],
        "bounded_search_limits": _bounded_common_gcd_search_limits(),
        "attempt_diagnostics": _common_gcd_attempt_diagnostics(
            normalized,
            variables=variables,
        ),
        "complete_combination_scan": bool(complete_combination_scan),
        "truncated": bool(truncated),
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": [
            "all nonzero scanned minors divided by the candidate, but the quotient common factor was not certified",
            "this records uncertainty in the bounded quotient-gcd layer and does not promote the candidate to an exact scanned gcd",
        ],
    }


def _blocker_summary(
    prefix: str,
    blockers: Sequence[str],
    details: dict[str, object] | None = None,
) -> dict:
    blocker_list = list(blockers)
    return {
        f"{prefix}_blockers": blocker_list,
        f"{prefix}_blocker_count": len(blocker_list),
        f"{prefix}_blocker_details": dict(details or {}),
    }


def _blocker_int(value: object, fallback: int = 0) -> int:
    if isinstance(value, bool):
        return fallback
    try:
        return int(value)
    except (TypeError, ValueError):
        return fallback


def _dict_sequence(value: object) -> list[dict]:
    if not isinstance(value, Sequence) or isinstance(
        value,
        (str, bytes, bytearray),
    ):
        return []
    return [dict(item) for item in value if isinstance(item, dict)]


def _int_sequence(value: object) -> list[int]:
    if not isinstance(value, Sequence) or isinstance(
        value,
        (str, bytes, bytearray),
    ):
        return []
    indices: list[int] = []
    for item in value:
        if isinstance(item, bool):
            continue
        try:
            indices.append(int(item))
        except (TypeError, ValueError):
            continue
    return indices


def _witness_limit_int(value: object, *, fallback: int) -> int:
    if isinstance(value, bool):
        return fallback
    try:
        limit = int(value)
    except (TypeError, ValueError):
        return fallback
    return max(0, limit)


def _bounded_witness_consistency_summary(
    *,
    witness_kind: str,
    witness_count: object,
    witness_limit: object,
    witness_truncated: object,
    witnesses: object,
) -> dict:
    normalized_count = max(0, _blocker_int(witness_count, fallback=0))
    normalized_limit = _witness_limit_int(
        witness_limit,
        fallback=_ALEXANDER_AUDIT_WITNESS_LIMIT,
    )
    witness_list = _dict_sequence(witnesses)
    witness_list_count = len(witness_list)
    expected_witness_list_count = min(normalized_count, normalized_limit)
    truncated = bool(witness_truncated)
    list_within_limit = witness_list_count <= normalized_limit
    count_covers_list = normalized_count >= witness_list_count
    list_count_matches_expected = (
        witness_list_count == expected_witness_list_count
    )
    truncation_matches_count = truncated == (
        normalized_count > witness_list_count
    )
    return {
        "witness_kind": witness_kind,
        "witness_count": normalized_count,
        "witness_list_count": witness_list_count,
        "witness_limit": normalized_limit,
        "witness_truncated": truncated,
        "expected_witness_list_count": expected_witness_list_count,
        "witness_list_within_limit": list_within_limit,
        "witness_count_covers_list": count_covers_list,
        "witness_list_count_matches_expected": list_count_matches_expected,
        "witness_truncation_matches_count": truncation_matches_count,
        "count_list_limit_truncation_consistent": bool(
            list_within_limit
            and count_covers_list
            and list_count_matches_expected
            and truncation_matches_count
        ),
    }


def _division_failure_witness_fields_from_audit(audit: dict) -> dict:
    witnesses = _dict_sequence(audit.get("failed_division_witnesses", []))
    limit = _witness_limit_int(
        audit.get("failed_division_witness_limit", _ALEXANDER_AUDIT_WITNESS_LIMIT),
        fallback=_ALEXANDER_AUDIT_WITNESS_LIMIT,
    )
    failed_nonzero_minor_count = _blocker_int(
        audit.get("failed_nonzero_minor_count", len(witnesses)),
        fallback=len(witnesses),
    )
    reported_witness_count = _blocker_int(
        audit.get("failed_division_witness_count", failed_nonzero_minor_count),
        fallback=failed_nonzero_minor_count,
    )
    truncated = bool(audit.get("failed_division_witness_truncated", False))
    if truncated:
        witness_count = (
            failed_nonzero_minor_count
            if failed_nonzero_minor_count >= len(witnesses)
            else max(reported_witness_count, len(witnesses))
        )
    else:
        witness_count = len(witnesses)
    return {
        "failed_division_witness_count": witness_count,
        "failed_division_witness_limit": limit,
        "failed_division_witness_truncated": truncated,
        "failed_division_witnesses": witnesses,
        "failed_division_witness_consistency": _bounded_witness_consistency_summary(
            witness_kind="failed_division",
            witness_count=witness_count,
            witness_limit=limit,
            witness_truncated=truncated,
            witnesses=witnesses,
        ),
    }


def _quotient_gcd_uncertainty_evidence_from_audit(audit: dict) -> dict | None:
    evidence = audit.get("quotient_gcd_uncertainty_evidence")
    if not isinstance(evidence, dict):
        return None
    normalized = dict(evidence)
    variables_value = normalized.get("variables", audit.get("variables", []))
    variables = (
        [
            str(variable)
            for variable in variables_value
        ]
        if isinstance(variables_value, Sequence)
        and not isinstance(variables_value, (str, bytes, bytearray))
        else []
    )
    normalized["variables"] = variables
    quotient_polynomials = normalized.get("quotient_polynomials")
    if isinstance(quotient_polynomials, Sequence) and not isinstance(
        quotient_polynomials,
        (str, bytes, bytearray),
    ):
        quotient_polynomial_list = [
            str(polynomial)
            for polynomial in quotient_polynomials
        ]
        normalized["quotient_polynomials"] = quotient_polynomial_list
        normalized["quotient_polynomial_count"] = len(quotient_polynomial_list)
        normalized["unique_quotient_polynomial_count"] = len(
            set(quotient_polynomial_list)
        )
    else:
        quotient_polynomial_list = []
        normalized["quotient_polynomials"] = quotient_polynomial_list
        normalized["quotient_polynomial_count"] = 0
        normalized["unique_quotient_polynomial_count"] = 0
    normalized["quotient_polynomial_count_consistency"] = (
        _quotient_polynomial_count_consistency(quotient_polynomial_list)
    )
    normalized.update(
        _quotient_polynomial_witness_fields(
            quotient_polynomial_list,
            variables=variables,
        )
    )
    normalized["full_admissible_minor_normalization_certified"] = False
    normalized["full_invariant_certified"] = False
    return normalized


def _empty_source_table_source_divisibility_failed_candidate_witness_summary() -> dict:
    witness_count = 0
    witness_limit = _ALEXANDER_AUDIT_WITNESS_LIMIT
    witness_truncated = False
    witnesses: list[dict] = []
    return {
        "method": (
            "source_table_alexander_source_divisibility_failed_candidate_witness_summary"
        ),
        "claim_scope": "source_table_alexander_numerator_bounded_candidate_witnesses",
        "checked_candidate_count": 0,
        "failed_candidate_witness_count": witness_count,
        "failed_candidate_witness_limit": witness_limit,
        "failed_candidate_witness_truncated": witness_truncated,
        "failed_candidate_witnesses": witnesses,
        "first_failed_candidate_witness": None,
        "failed_candidate_witness_consistency": (
            _bounded_witness_consistency_summary(
                witness_kind=(
                    "source_table_alexander_source_divisibility_failed_candidate"
                ),
                witness_count=witness_count,
                witness_limit=witness_limit,
                witness_truncated=witness_truncated,
                witnesses=witnesses,
            )
        ),
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": [
            "no source-table Alexander numerator candidate divisibility witnesses were available",
        ],
    }


def _source_table_source_divisibility_failed_candidate_witness_summary(
    source_table_invariant_audit: dict | None,
    source_divisibility_summary: dict | None,
    *,
    limit: int = _ALEXANDER_AUDIT_WITNESS_LIMIT,
) -> dict:
    if not isinstance(source_table_invariant_audit, dict) or not isinstance(
        source_divisibility_summary,
        dict,
    ):
        return _empty_source_table_source_divisibility_failed_candidate_witness_summary()

    candidate_indices = _int_sequence(
        source_divisibility_summary.get("candidate_indices", [])
    )
    candidate_diagnostics = source_table_invariant_audit.get(
        "candidate_diagnostics",
        {},
    )
    candidates = (
        candidate_diagnostics.get("candidates", [])
        if isinstance(candidate_diagnostics, dict)
        else []
    )
    if not isinstance(candidates, Sequence) or isinstance(
        candidates,
        (str, bytes, bytearray),
    ):
        candidates = []

    failed_candidate_witnesses = []
    for candidate_index in candidate_indices:
        if candidate_index < 0 or candidate_index >= len(candidates):
            continue
        candidate = candidates[candidate_index]
        if not isinstance(candidate, dict):
            continue
        alexander = candidate.get("multivariable_alexander")
        if not isinstance(alexander, dict):
            continue
        source_audit = alexander.get("source_numerator_divisibility_audit")
        if not isinstance(source_audit, dict):
            continue
        if bool(source_audit.get("divides_all_inputs", False)):
            continue
        failed_input_fields = _failed_input_witness_fields_from_division_records(
            _dict_sequence(source_audit.get("division_records", []))
        )
        first_failed_input_witness = source_audit.get("first_failed_input_witness")
        if not isinstance(first_failed_input_witness, dict):
            first_failed_input_witness = failed_input_fields[
                "first_failed_input_witness"
            ]
        failed_candidate_witnesses.append(
            {
                "candidate_index": candidate_index,
                "status": source_audit.get("status"),
                "source_polynomial": source_audit.get("source_polynomial"),
                "normalized_source_polynomial": source_audit.get(
                    "normalized_source_polynomial"
                ),
                "failed_input_count": _blocker_int(
                    source_audit.get("failed_input_count", 0)
                ),
                "invalid_input_count": _blocker_int(
                    source_audit.get("invalid_input_count", 0)
                ),
                "unique_input_polynomial_count": _blocker_int(
                    source_audit.get("unique_input_polynomial_count", 0)
                ),
                "first_failed_input_witness": first_failed_input_witness,
            }
        )

    witness_limit = _witness_limit_int(
        limit,
        fallback=_ALEXANDER_AUDIT_WITNESS_LIMIT,
    )
    witnesses = failed_candidate_witnesses[:witness_limit]
    witness_count = len(failed_candidate_witnesses)
    witness_truncated = witness_count > len(witnesses)
    return {
        "method": (
            "source_table_alexander_source_divisibility_failed_candidate_witness_summary"
        ),
        "claim_scope": "source_table_alexander_numerator_bounded_candidate_witnesses",
        "checked_candidate_count": _blocker_int(
            source_divisibility_summary.get(
                "checked_candidate_count",
                len(candidate_indices),
            ),
            fallback=len(candidate_indices),
        ),
        "candidate_indices": candidate_indices,
        "failed_candidate_witness_count": witness_count,
        "failed_candidate_witness_limit": witness_limit,
        "failed_candidate_witness_truncated": witness_truncated,
        "failed_candidate_witnesses": witnesses,
        "first_failed_candidate_witness": witnesses[0] if witnesses else None,
        "failed_candidate_witness_consistency": (
            _bounded_witness_consistency_summary(
                witness_kind=(
                    "source_table_alexander_source_divisibility_failed_candidate"
                ),
                witness_count=witness_count,
                witness_limit=witness_limit,
                witness_truncated=witness_truncated,
                witnesses=witnesses,
            )
        ),
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": [
            "each witness records one bounded failed-input example for a skipped source-table Alexander candidate",
            "the witnesses do not certify a full multivariate gcd or admissible-minor normalization",
        ],
    }


def _normalization_mismatch_witness_fields_from_audit(audit: dict) -> dict:
    raw_witnesses = _dict_sequence(
        audit.get("normalization_mismatch_witnesses", [])
    )
    limit = _witness_limit_int(
        audit.get(
            "normalization_mismatch_witness_limit",
            _ADMISSIBLE_MINOR_NORMALIZATION_MISMATCH_WITNESS_LIMIT,
        ),
        fallback=_ADMISSIBLE_MINOR_NORMALIZATION_MISMATCH_WITNESS_LIMIT,
    )
    witnesses = raw_witnesses[:limit] if limit else []
    reported_witness_count = _blocker_int(
        audit.get("normalization_mismatch_witness_count", len(raw_witnesses)),
        fallback=len(raw_witnesses),
    )
    failed_nonzero_minor_count = _blocker_int(
        audit.get("failed_nonzero_minor_count", len(raw_witnesses)),
        fallback=len(raw_witnesses),
    )
    truncated = bool(audit.get("normalization_mismatch_witness_truncated", False))
    if truncated:
        witness_count = (
            failed_nonzero_minor_count
            if failed_nonzero_minor_count >= len(raw_witnesses)
            else max(reported_witness_count, len(raw_witnesses))
        )
    else:
        witness_count = len(raw_witnesses)
    witness_truncated = bool(truncated or len(raw_witnesses) > len(witnesses))
    if witness_truncated and witness_count < len(raw_witnesses):
        witness_count = len(raw_witnesses)
    return {
        "normalization_mismatch_witness_count": witness_count,
        "normalization_mismatch_witness_limit": limit,
        "normalization_mismatch_witness_truncated": witness_truncated,
        "normalization_mismatch_witnesses": witnesses,
        "normalization_mismatch_witness_consistency": (
            _bounded_witness_consistency_summary(
                witness_kind="normalization_mismatch",
                witness_count=witness_count,
                witness_limit=limit,
                witness_truncated=witness_truncated,
                witnesses=witnesses,
            )
        ),
    }


def _admissible_minor_normalization_blocker_details(
    details: object,
    *,
    normalization_audit: dict | None = None,
    normalization_mismatch_witness_fields: dict | None = None,
) -> dict[str, object]:
    if not isinstance(details, dict):
        return {}
    audit = normalization_audit if isinstance(normalization_audit, dict) else {}
    normalized_details: dict[str, object] = dict(details)
    failed_detail = normalized_details.get("failed_nonzero_minor_normalization")
    if isinstance(failed_detail, dict):
        normalized_failed_detail = dict(failed_detail)
        failed_indices = _int_sequence(
            normalized_failed_detail.get(
                "failed_minor_indices",
                audit.get("failed_minor_indices", []),
            )
        )
        if not failed_indices:
            failed_indices = _int_sequence(audit.get("failed_minor_indices", []))
        if failed_indices:
            failed_count = len(failed_indices)
        else:
            failed_count = _blocker_int(
                audit.get(
                    "failed_nonzero_minor_count",
                    normalized_failed_detail.get("failed_nonzero_minor_count", 0),
                )
            )
        normalized_failed_detail["failed_nonzero_minor_count"] = failed_count
        normalized_failed_detail["failed_minor_indices"] = failed_indices
        normalized_details["failed_nonzero_minor_normalization"] = (
            normalized_failed_detail
        )
    class_detail = normalized_details.get("normalization_class_not_unique")
    if isinstance(class_detail, dict):
        normalized_class_detail = dict(class_detail)
        witnesses = _dict_sequence(
            normalized_class_detail.get("normalization_class_witnesses", [])
        )
        if not witnesses:
            witnesses = _dict_sequence(audit.get("normalization_class_counts", []))
        for key in (
            "normalization_class_count",
            "largest_normalization_class_minor_count",
            "representative_normalization_class_minor_count",
            "nonrepresentative_normalization_class_count",
        ):
            if key in audit:
                normalized_class_detail[key] = _blocker_int(
                    audit.get(key),
                    fallback=_blocker_int(normalized_class_detail.get(key, 0)),
                )
        normalized_class_detail["normalization_class_witness_count"] = len(witnesses)
        normalized_class_detail["normalization_class_witnesses"] = witnesses
        normalized_details["normalization_class_not_unique"] = (
            normalized_class_detail
        )
    mismatch_fields = (
        normalization_mismatch_witness_fields
        if isinstance(normalization_mismatch_witness_fields, dict)
        else None
    )
    mismatch_detail = normalized_details.get(
        "normalization_mismatch_witnesses_present"
    )
    if isinstance(mismatch_detail, dict) and mismatch_fields is not None:
        normalized_mismatch_detail = dict(mismatch_detail)
        normalized_mismatch_detail["normalization_mismatch_witness_count"] = (
            _blocker_int(
                mismatch_fields.get("normalization_mismatch_witness_count", 0)
            )
        )
        normalized_mismatch_detail["normalization_mismatch_witness_limit"] = (
            _blocker_int(
                mismatch_fields.get(
                    "normalization_mismatch_witness_limit",
                    _ADMISSIBLE_MINOR_NORMALIZATION_MISMATCH_WITNESS_LIMIT,
                ),
                fallback=_ADMISSIBLE_MINOR_NORMALIZATION_MISMATCH_WITNESS_LIMIT,
            )
        )
        normalized_mismatch_detail["normalization_mismatch_witness_truncated"] = (
            bool(
                mismatch_fields.get(
                    "normalization_mismatch_witness_truncated",
                    False,
                )
            )
        )
        normalized_details["normalization_mismatch_witnesses_present"] = (
            normalized_mismatch_detail
        )
    elif mismatch_fields is not None and _blocker_int(
        mismatch_fields.get("normalization_mismatch_witness_count", 0)
    ):
        normalized_details["normalization_mismatch_witnesses_present"] = {
            "normalization_mismatch_witness_count": _blocker_int(
                mismatch_fields.get("normalization_mismatch_witness_count", 0)
            ),
            "normalization_mismatch_witness_limit": _blocker_int(
                mismatch_fields.get(
                    "normalization_mismatch_witness_limit",
                    _ADMISSIBLE_MINOR_NORMALIZATION_MISMATCH_WITNESS_LIMIT,
                ),
                fallback=_ADMISSIBLE_MINOR_NORMALIZATION_MISMATCH_WITNESS_LIMIT,
            ),
            "normalization_mismatch_witness_truncated": bool(
                mismatch_fields.get(
                    "normalization_mismatch_witness_truncated",
                    False,
                )
            ),
        }
    return normalized_details


def _admissible_minor_blocker_reason(code: str) -> str:
    reason_by_code = {
        "square_minor_scan_missing": "scan_missing",
        "square_minor_scan_skipped": "scan_skipped",
        "scanned_gcd_audit_missing": "scan_missing",
        "scanned_gcd_audit_skipped": "scan_skipped",
        "variable_names_missing": "input_metadata_incomplete",
        "nonzero_admissible_minor_missing": "nonzero_minor_missing",
        "complete_combination_scan_incomplete": "scan_incomplete",
        "square_minor_scan_truncated": "scan_incomplete",
        "nonzero_minor_coverage_incomplete": "row_column_coverage_incomplete",
        "failed_nonzero_minor_normalization": "nonunique_class",
        "normalization_class_not_unique": "nonunique_class",
        "normalization_mismatch_witnesses_present": "nonunique_class",
        "candidate_not_exact_scanned_gcd": "scanned_gcd_not_exact",
        "failed_nonzero_minor_division": "minor_division_failure",
        "quotient_gcd_uncertified": "quotient_uncertainty",
    }
    return reason_by_code.get(code, "bounded_evidence_incomplete")


def _ordered_unique_strings(values: Iterable[object]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        text = str(value)
        if text in seen:
            continue
        seen.add(text)
        ordered.append(text)
    return ordered


def _ordered_string_counts(values: Iterable[object]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for value in values:
        text = str(value)
        counts[text] = counts.get(text, 0) + 1
    return counts


def _bounded_admissible_minor_normalization_gate_row(
    gate: str,
    passed: bool,
    *,
    blockers: Sequence[str] = (),
    source_fields: Sequence[str] = (),
    evidence: dict | None = None,
    required: bool = True,
) -> dict:
    blocker_list = [] if passed else [str(blocker) for blocker in blockers]
    return {
        "gate": gate,
        "passed": bool(passed),
        "required": bool(required),
        "blockers": blocker_list,
        "blocker_count": len(blocker_list),
        "reason_codes": _ordered_unique_strings(
            _admissible_minor_blocker_reason(blocker)
            for blocker in blocker_list
        ),
        "source_fields": [str(field) for field in source_fields],
        "evidence": dict(evidence or {}),
    }


def _bounded_admissible_minor_normalization_failed_gate_blocker_attributions(
    gate_rows: Sequence[dict],
) -> list[dict]:
    attributions: list[dict] = []
    for row in _dict_sequence(gate_rows):
        if bool(row.get("passed")):
            continue
        gate_name = str(row.get("gate"))
        for blocker in row.get("blockers", []):
            blocker_text = str(blocker)
            attributions.append(
                {
                    "gate": gate_name,
                    "blocker": blocker_text,
                    "reason_code": _admissible_minor_blocker_reason(
                        blocker_text
                    ),
                }
            )
    return attributions


def _bounded_admissible_minor_normalization_failed_gate_blocker_provenance_consistency(
    *,
    claim_scope: str,
    gate_rows: Sequence[dict],
    failed_gate_blockers: Sequence[str],
    blocker_witness_summary: dict | None,
) -> dict:
    gate_list = _dict_sequence(gate_rows)
    failed_gate_names = [
        str(row.get("gate"))
        for row in gate_list
        if not bool(row.get("passed"))
    ]
    failed_gate_blocker_list = [
        str(blocker) for blocker in failed_gate_blockers
    ]
    failed_gate_blocker_reason_counts = _ordered_string_counts(
        _admissible_minor_blocker_reason(blocker)
        for blocker in failed_gate_blocker_list
    )
    failed_gate_blocker_reason_count = len(failed_gate_blocker_reason_counts)
    failed_gate_blocker_reason_counts_total = sum(
        failed_gate_blocker_reason_counts.values()
    )
    failed_gate_blocker_attributions = (
        _bounded_admissible_minor_normalization_failed_gate_blocker_attributions(
            gate_list
        )
    )
    attributed_gate_names = _ordered_unique_strings(
        attribution["gate"]
        for attribution in failed_gate_blocker_attributions
    )
    attribution_count = len(failed_gate_blocker_attributions)
    attribution_counts_by_gate = _ordered_string_counts(
        attribution["gate"] for attribution in failed_gate_blocker_attributions
    )
    attribution_counts_by_blocker = _ordered_string_counts(
        attribution["blocker"] for attribution in failed_gate_blocker_attributions
    )
    attribution_counts_by_reason = _ordered_string_counts(
        attribution["reason_code"]
        for attribution in failed_gate_blocker_attributions
    )
    blocker_witness_summary_available = isinstance(blocker_witness_summary, dict)
    blocker_witness_summary_blockers = (
        [str(blocker) for blocker in blocker_witness_summary.get("blockers", [])]
        if blocker_witness_summary_available
        else []
    )
    blocker_witness_summary_blocker_count = (
        _blocker_int(blocker_witness_summary.get("blocker_count", 0))
        if blocker_witness_summary_available
        else 0
    )
    blocker_witness_summary_reason_counts = (
        _ordered_string_counts(
            _admissible_minor_blocker_reason(blocker)
            for blocker in blocker_witness_summary_blockers
        )
        if blocker_witness_summary_available
        else {}
    )
    blocker_witness_source_rows = (
        _dict_sequence(blocker_witness_summary.get("blocker_witness_sources", []))
        if blocker_witness_summary_available
        else []
    )
    blocker_witness_source_row_count = len(blocker_witness_source_rows)
    blocker_witness_source_row_blockers = [
        str(row.get("blocker")) for row in blocker_witness_source_rows
    ]
    blocker_witness_source_row_reason_counts = _ordered_string_counts(
        row.get("reason_code") for row in blocker_witness_source_rows
    )
    blocker_witness_source_row_available_count = sum(
        1 for row in blocker_witness_source_rows if bool(row.get("available"))
    )
    blocker_witness_source_row_missing_count = (
        blocker_witness_source_row_count
        - blocker_witness_source_row_available_count
    )
    blocker_witness_source_row_available_counts_by_reason = _ordered_string_counts(
        row.get("reason_code")
        for row in blocker_witness_source_rows
        if bool(row.get("available"))
    )
    blocker_witness_source_row_missing_counts_by_reason = _ordered_string_counts(
        row.get("reason_code")
        for row in blocker_witness_source_rows
        if not bool(row.get("available"))
    )
    blocker_witness_sources_by_blocker = {
        str(row.get("blocker")): row for row in blocker_witness_source_rows
    }
    provenance_rows: list[dict] = []
    missing_source_blockers: list[str] = []
    inconsistent_source_blockers: list[str] = []
    for blocker in failed_gate_blocker_list:
        reason_code = _admissible_minor_blocker_reason(blocker)
        gates = [
            attribution["gate"]
            for attribution in failed_gate_blocker_attributions
            if attribution["blocker"] == blocker
        ]
        source = blocker_witness_sources_by_blocker.get(blocker)
        source_row_available = source is not None
        if source is None:
            missing_source_blockers.append(blocker)
            row = {
                "blocker": blocker,
                "reason_code": reason_code,
                "gates": gates,
                "gate_count": len(gates),
                "source_row_available": False,
                "source_available": False,
                "source_blocker": None,
                "source_reason_code": None,
                "source_field": None,
                "source_detail_field": None,
                "witness_kind": None,
                "missing_reason": "blocker_witness_source_missing",
                "source_row_matches_blocker": False,
                "source_row_reason_matches_blocker_reason": False,
                "source_provenance_consistent": False,
            }
        else:
            source_reason_code = source.get("reason_code")
            source_row_matches_blocker = str(source.get("blocker")) == blocker
            source_row_reason_matches_blocker_reason = (
                str(source_reason_code) == reason_code
            )
            source_provenance_consistent = bool(
                source_row_available
                and source_row_matches_blocker
                and source_row_reason_matches_blocker_reason
                and source.get("source_provenance_consistent")
            )
            if not source_provenance_consistent:
                inconsistent_source_blockers.append(blocker)
            row = {
                "blocker": blocker,
                "reason_code": reason_code,
                "gates": gates,
                "gate_count": len(gates),
                "source_row_available": source_row_available,
                "source_available": bool(source.get("available")),
                "source_blocker": source.get("source_blocker"),
                "source_reason_code": source.get("source_reason_code"),
                "source_field": source.get("source_field"),
                "source_detail_field": source.get("source_detail_field"),
                "witness_kind": source.get("witness_kind"),
                "missing_reason": source.get("missing_reason"),
                "source_row_matches_blocker": source_row_matches_blocker,
                "source_row_reason_matches_blocker_reason": (
                    source_row_reason_matches_blocker_reason
                ),
                "source_provenance_consistent": source_provenance_consistent,
            }
        provenance_rows.append(row)

    provenance_row_reason_counts = _ordered_string_counts(
        row["reason_code"] for row in provenance_rows
    )
    provenance_row_gate_count_total = sum(
        _blocker_int(row.get("gate_count", 0)) for row in provenance_rows
    )
    raw_provenance_row_failed_gate_names = _ordered_unique_strings(
        gate
        for row in provenance_rows
        for gate in row.get("gates", [])
    )
    raw_provenance_row_failed_gate_name_set = set(
        raw_provenance_row_failed_gate_names
    )
    failed_gate_name_set = set(failed_gate_names)
    provenance_row_failed_gate_names = [
        gate
        for gate in failed_gate_names
        if gate in raw_provenance_row_failed_gate_name_set
    ]
    provenance_row_failed_gate_names.extend(
        gate
        for gate in raw_provenance_row_failed_gate_names
        if gate not in failed_gate_name_set
    )
    provenance_source_available_count = sum(
        1 for row in provenance_rows if bool(row.get("source_available"))
    )
    provenance_source_missing_count = (
        len(provenance_rows) - provenance_source_available_count
    )
    provenance_source_available_counts_by_reason = _ordered_string_counts(
        row["reason_code"]
        for row in provenance_rows
        if bool(row.get("source_available"))
    )
    provenance_source_missing_counts_by_reason = _ordered_string_counts(
        row["reason_code"]
        for row in provenance_rows
        if not bool(row.get("source_available"))
    )
    provenance_source_available_counts_total = sum(
        provenance_source_available_counts_by_reason.values()
    )
    provenance_source_missing_counts_total = sum(
        provenance_source_missing_counts_by_reason.values()
    )
    blocker_witness_source_row_provenance_keys = [
        {
            "blocker": str(row.get("blocker")),
            "reason_code": str(row.get("reason_code")),
            "available": bool(row.get("available")),
            "source_blocker": row.get("source_blocker"),
            "source_reason_code": row.get("source_reason_code"),
            "source_field": row.get("source_field"),
            "source_detail_field": row.get("source_detail_field"),
            "witness_kind": row.get("witness_kind"),
            "missing_reason": row.get("missing_reason"),
            "source_provenance_consistent": bool(
                row.get("source_provenance_consistent")
            ),
        }
        for row in blocker_witness_source_rows
    ]
    provenance_row_source_keys = [
        {
            "blocker": row["blocker"],
            "reason_code": row["reason_code"],
            "available": bool(row.get("source_available")),
            "source_blocker": row.get("source_blocker"),
            "source_reason_code": row.get("source_reason_code"),
            "source_field": row.get("source_field"),
            "source_detail_field": row.get("source_detail_field"),
            "witness_kind": row.get("witness_kind"),
            "missing_reason": row.get("missing_reason"),
            "source_provenance_consistent": bool(
                row.get("source_provenance_consistent")
            ),
        }
        for row in provenance_rows
    ]
    blocker_witness_summary_blockers_match_failed_gate_blockers = (
        blocker_witness_summary_blockers == failed_gate_blocker_list
        if blocker_witness_summary_available
        else False
    )
    blocker_witness_summary_blocker_count_matches_failed_gate_blocker_count = (
        blocker_witness_summary_blocker_count == len(failed_gate_blocker_list)
        if blocker_witness_summary_available
        else False
    )
    blocker_witness_summary_reason_counts_match_failed_gate_reason_counts = (
        blocker_witness_summary_reason_counts == failed_gate_blocker_reason_counts
        if blocker_witness_summary_available
        else False
    )
    failed_gate_blocker_count_matches_list = (
        len(failed_gate_blocker_list) == len(failed_gate_blockers)
    )
    failed_gate_blocker_reason_counts_total_matches_blocker_count = (
        failed_gate_blocker_reason_counts_total == len(failed_gate_blocker_list)
    )
    failed_gate_blocker_reason_count_matches_counts_key_count = (
        failed_gate_blocker_reason_count == len(failed_gate_blocker_reason_counts)
    )
    attribution_counts_by_reason_total_matches_attribution_count = (
        sum(attribution_counts_by_reason.values()) == attribution_count
    )
    attribution_blocker_set_matches_failed_gate_blocker_set = (
        set(attribution_counts_by_blocker) == set(failed_gate_blocker_list)
    )
    attribution_gate_set_matches_failed_gate_names = (
        set(attribution_counts_by_gate) == set(failed_gate_names)
    )
    blocker_witness_source_row_count_matches_failed_gate_blocker_count = (
        blocker_witness_source_row_count == len(failed_gate_blocker_list)
        if blocker_witness_summary_available
        else False
    )
    blocker_witness_source_row_blockers_match_failed_gate_blockers = (
        blocker_witness_source_row_blockers == failed_gate_blocker_list
        if blocker_witness_summary_available
        else False
    )
    blocker_witness_source_row_reason_counts_match_failed_gate_reason_counts = (
        blocker_witness_source_row_reason_counts == failed_gate_blocker_reason_counts
        if blocker_witness_summary_available
        else False
    )
    blocker_witness_source_row_availability_counts_sum_to_row_count = (
        blocker_witness_source_row_available_count
        + blocker_witness_source_row_missing_count
        == blocker_witness_source_row_count
    )
    blocker_witness_source_rows_match_provenance_rows = (
        blocker_witness_source_row_provenance_keys == provenance_row_source_keys
        if blocker_witness_summary_available
        else False
    )
    provenance_row_count_matches_failed_gate_blocker_count = (
        len(provenance_rows) == len(failed_gate_blocker_list)
    )
    provenance_row_reason_counts_match_failed_gate_reason_counts = (
        provenance_row_reason_counts == failed_gate_blocker_reason_counts
    )
    provenance_row_gate_count_total_matches_attribution_count = (
        provenance_row_gate_count_total == attribution_count
    )
    provenance_row_failed_gate_names_match_failed_gate_names = (
        provenance_row_failed_gate_names == failed_gate_names
    )
    provenance_rows_have_witness_sources = not missing_source_blockers
    provenance_source_provenance_consistent = not inconsistent_source_blockers
    provenance_source_availability_counts_sum_to_row_count = (
        provenance_source_available_count + provenance_source_missing_count
        == len(provenance_rows)
    )
    provenance_source_available_counts_total_matches_available_count = (
        provenance_source_available_counts_total == provenance_source_available_count
    )
    provenance_source_missing_counts_total_matches_missing_count = (
        provenance_source_missing_counts_total == provenance_source_missing_count
    )
    return {
        "method": (
            "bounded_admissible_minor_normalization_failed_gate_blocker_provenance_consistency"
        ),
        "claim_scope": claim_scope,
        "failed_gate_names": failed_gate_names,
        "failed_gate_count": len(failed_gate_names),
        "failed_gate_blockers": failed_gate_blocker_list,
        "failed_gate_blocker_count": len(failed_gate_blocker_list),
        "failed_gate_blocker_list_count": len(failed_gate_blocker_list),
        "failed_gate_blocker_count_matches_list": (
            failed_gate_blocker_count_matches_list
        ),
        "failed_gate_blocker_reason_counts": failed_gate_blocker_reason_counts,
        "failed_gate_blocker_reason_count": failed_gate_blocker_reason_count,
        "failed_gate_blocker_reason_counts_total": (
            failed_gate_blocker_reason_counts_total
        ),
        "failed_gate_blocker_reason_counts_total_matches_blocker_count": (
            failed_gate_blocker_reason_counts_total_matches_blocker_count
        ),
        "failed_gate_blocker_reason_count_matches_counts_key_count": (
            failed_gate_blocker_reason_count_matches_counts_key_count
        ),
        "failed_gate_blocker_attribution_count": attribution_count,
        "failed_gate_blocker_attributed_gate_names": attributed_gate_names,
        "failed_gate_blocker_attribution_counts_by_gate": (
            attribution_counts_by_gate
        ),
        "failed_gate_blocker_attribution_counts_by_blocker": (
            attribution_counts_by_blocker
        ),
        "failed_gate_blocker_attribution_counts_by_reason": (
            attribution_counts_by_reason
        ),
        "failed_gate_blocker_attribution_counts_by_reason_total_matches_attribution_count": (
            attribution_counts_by_reason_total_matches_attribution_count
        ),
        "failed_gate_blocker_attribution_blocker_set_matches_failed_gate_blocker_set": (
            attribution_blocker_set_matches_failed_gate_blocker_set
        ),
        "failed_gate_blocker_attribution_gate_set_matches_failed_gate_names": (
            attribution_gate_set_matches_failed_gate_names
        ),
        "blocker_witness_summary_available": blocker_witness_summary_available,
        "blocker_witness_summary_blockers": blocker_witness_summary_blockers,
        "blocker_witness_summary_blocker_count": (
            blocker_witness_summary_blocker_count
        ),
        "blocker_witness_summary_reason_counts": (
            blocker_witness_summary_reason_counts
        ),
        "blocker_witness_summary_first_witness_available": (
            bool(blocker_witness_summary.get("first_witness_available"))
            if blocker_witness_summary_available
            else False
        ),
        "blocker_witness_summary_first_witness_kind": (
            blocker_witness_summary.get("first_witness_kind")
            if blocker_witness_summary_available
            else None
        ),
        "blocker_witness_summary_first_witness_source": (
            dict(blocker_witness_summary.get("first_witness_source", {}))
            if blocker_witness_summary_available
            and isinstance(blocker_witness_summary.get("first_witness_source"), dict)
            else None
        ),
        "blocker_witness_source_row_count": blocker_witness_source_row_count,
        "blocker_witness_source_row_blockers": (
            blocker_witness_source_row_blockers
        ),
        "blocker_witness_source_row_reason_counts": (
            blocker_witness_source_row_reason_counts
        ),
        "blocker_witness_source_row_available_count": (
            blocker_witness_source_row_available_count
        ),
        "blocker_witness_source_row_missing_count": (
            blocker_witness_source_row_missing_count
        ),
        "blocker_witness_source_row_available_counts_by_reason": (
            blocker_witness_source_row_available_counts_by_reason
        ),
        "blocker_witness_source_row_missing_counts_by_reason": (
            blocker_witness_source_row_missing_counts_by_reason
        ),
        "blocker_witness_source_row_provenance_keys": (
            blocker_witness_source_row_provenance_keys
        ),
        "failed_gate_blocker_provenance_rows": provenance_rows,
        "failed_gate_blocker_provenance_row_count": len(provenance_rows),
        "failed_gate_blocker_provenance_row_reason_counts": (
            provenance_row_reason_counts
        ),
        "failed_gate_blocker_provenance_row_gate_count_total": (
            provenance_row_gate_count_total
        ),
        "failed_gate_blocker_provenance_row_failed_gate_names": (
            provenance_row_failed_gate_names
        ),
        "failed_gate_blocker_provenance_source_available_count": (
            provenance_source_available_count
        ),
        "failed_gate_blocker_provenance_source_missing_count": (
            provenance_source_missing_count
        ),
        "failed_gate_blocker_provenance_source_available_counts_by_reason": (
            provenance_source_available_counts_by_reason
        ),
        "failed_gate_blocker_provenance_source_available_counts_total": (
            provenance_source_available_counts_total
        ),
        "failed_gate_blocker_provenance_source_missing_counts_by_reason": (
            provenance_source_missing_counts_by_reason
        ),
        "failed_gate_blocker_provenance_source_missing_counts_total": (
            provenance_source_missing_counts_total
        ),
        "failed_gate_blocker_provenance_row_source_keys": (
            provenance_row_source_keys
        ),
        "failed_gate_blocker_provenance_missing_source_blockers": (
            missing_source_blockers
        ),
        "failed_gate_blocker_provenance_inconsistent_source_blockers": (
            inconsistent_source_blockers
        ),
        "blocker_witness_summary_blockers_match_failed_gate_blockers": (
            blocker_witness_summary_blockers_match_failed_gate_blockers
        ),
        "blocker_witness_summary_blocker_count_matches_failed_gate_blocker_count": (
            blocker_witness_summary_blocker_count_matches_failed_gate_blocker_count
        ),
        "blocker_witness_summary_reason_counts_match_failed_gate_reason_counts": (
            blocker_witness_summary_reason_counts_match_failed_gate_reason_counts
        ),
        "blocker_witness_source_row_count_matches_failed_gate_blocker_count": (
            blocker_witness_source_row_count_matches_failed_gate_blocker_count
        ),
        "blocker_witness_source_row_blockers_match_failed_gate_blockers": (
            blocker_witness_source_row_blockers_match_failed_gate_blockers
        ),
        "blocker_witness_source_row_reason_counts_match_failed_gate_reason_counts": (
            blocker_witness_source_row_reason_counts_match_failed_gate_reason_counts
        ),
        "blocker_witness_source_row_availability_counts_sum_to_row_count": (
            blocker_witness_source_row_availability_counts_sum_to_row_count
        ),
        "blocker_witness_source_rows_match_provenance_rows": (
            blocker_witness_source_rows_match_provenance_rows
        ),
        "provenance_row_count_matches_failed_gate_blocker_count": (
            provenance_row_count_matches_failed_gate_blocker_count
        ),
        "provenance_row_reason_counts_match_failed_gate_reason_counts": (
            provenance_row_reason_counts_match_failed_gate_reason_counts
        ),
        "provenance_row_gate_count_total_matches_attribution_count": (
            provenance_row_gate_count_total_matches_attribution_count
        ),
        "provenance_row_failed_gate_names_match_failed_gate_names": (
            provenance_row_failed_gate_names_match_failed_gate_names
        ),
        "provenance_rows_have_witness_sources": (
            provenance_rows_have_witness_sources
        ),
        "provenance_source_provenance_consistent": (
            provenance_source_provenance_consistent
        ),
        "provenance_source_availability_counts_sum_to_row_count": (
            provenance_source_availability_counts_sum_to_row_count
        ),
        "provenance_source_available_counts_total_matches_available_count": (
            provenance_source_available_counts_total_matches_available_count
        ),
        "provenance_source_missing_counts_total_matches_missing_count": (
            provenance_source_missing_counts_total_matches_missing_count
        ),
        "normalization_gate_provenance_consistent": bool(
            blocker_witness_summary_available
            and failed_gate_blocker_count_matches_list
            and failed_gate_blocker_reason_counts_total_matches_blocker_count
            and failed_gate_blocker_reason_count_matches_counts_key_count
            and attribution_counts_by_reason_total_matches_attribution_count
            and attribution_blocker_set_matches_failed_gate_blocker_set
            and attribution_gate_set_matches_failed_gate_names
            and blocker_witness_summary_blockers_match_failed_gate_blockers
            and blocker_witness_summary_blocker_count_matches_failed_gate_blocker_count
            and blocker_witness_summary_reason_counts_match_failed_gate_reason_counts
            and blocker_witness_source_row_count_matches_failed_gate_blocker_count
            and blocker_witness_source_row_blockers_match_failed_gate_blockers
            and blocker_witness_source_row_reason_counts_match_failed_gate_reason_counts
            and blocker_witness_source_row_availability_counts_sum_to_row_count
            and blocker_witness_source_rows_match_provenance_rows
            and provenance_row_count_matches_failed_gate_blocker_count
            and provenance_row_reason_counts_match_failed_gate_reason_counts
            and provenance_row_gate_count_total_matches_attribution_count
            and provenance_row_failed_gate_names_match_failed_gate_names
            and provenance_rows_have_witness_sources
            and provenance_source_provenance_consistent
            and provenance_source_availability_counts_sum_to_row_count
            and provenance_source_available_counts_total_matches_available_count
            and provenance_source_missing_counts_total_matches_missing_count
        ),
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
    }


def _bounded_admissible_minor_normalization_gate_pressure_summary(
    *,
    claim_scope: str,
    gate_rows: Sequence[dict],
    failed_gate_blockers: Sequence[str],
    blocker_witness_summary: dict | None,
) -> dict:
    gate_list = _dict_sequence(gate_rows)
    gate_names = [str(row.get("gate")) for row in gate_list]
    passed_gate_names = [
        str(row.get("gate"))
        for row in gate_list
        if bool(row.get("passed"))
    ]
    failed_gate_names = [
        str(row.get("gate"))
        for row in gate_list
        if not bool(row.get("passed"))
    ]
    failed_gate_blocker_list = [
        str(blocker) for blocker in failed_gate_blockers
    ]
    failed_gate_blocker_attributions = (
        _bounded_admissible_minor_normalization_failed_gate_blocker_attributions(
            gate_list
        )
    )
    attributed_gates = _ordered_unique_strings(
        row["gate"] for row in failed_gate_blocker_attributions
    )
    attributed_blockers = _ordered_unique_strings(
        row["blocker"] for row in failed_gate_blocker_attributions
    )
    failed_gate_blocker_reason_codes = _ordered_unique_strings(
        _admissible_minor_blocker_reason(blocker)
        for blocker in failed_gate_blocker_list
    )
    failed_gate_blocker_reason_counts = _ordered_string_counts(
        _admissible_minor_blocker_reason(blocker)
        for blocker in failed_gate_blocker_list
    )
    attribution_reason_counts = _ordered_string_counts(
        row["reason_code"] for row in failed_gate_blocker_attributions
    )
    blocker_witness_summary_available = isinstance(blocker_witness_summary, dict)
    blocker_witness_summary_blockers = (
        [str(blocker) for blocker in blocker_witness_summary.get("blockers", [])]
        if blocker_witness_summary_available
        else []
    )
    blocker_witness_summary_blocker_count = (
        _blocker_int(blocker_witness_summary.get("blocker_count", 0))
        if blocker_witness_summary_available
        else 0
    )
    provenance_consistency = (
        _bounded_admissible_minor_normalization_failed_gate_blocker_provenance_consistency(
            claim_scope=claim_scope,
            gate_rows=gate_list,
            failed_gate_blockers=failed_gate_blocker_list,
            blocker_witness_summary=blocker_witness_summary,
        )
    )
    return {
        "method": "bounded_admissible_minor_normalization_gate_pressure_summary",
        "claim_scope": claim_scope,
        "gate_count": len(gate_list),
        "gate_name_count": len(gate_names),
        "passed_gate_count": len(passed_gate_names),
        "failed_gate_count": len(failed_gate_names),
        "passed_failed_gate_counts_sum_to_gate_count": (
            len(passed_gate_names) + len(failed_gate_names) == len(gate_list)
        ),
        "failed_gate_names": failed_gate_names,
        "failed_gate_name_count": len(failed_gate_names),
        "failed_gate_blockers": failed_gate_blocker_list,
        "failed_gate_blocker_count": len(failed_gate_blocker_list),
        "failed_gate_blocker_reason_codes": failed_gate_blocker_reason_codes,
        "failed_gate_blocker_reason_count": len(
            failed_gate_blocker_reason_codes
        ),
        "failed_gate_blocker_reason_counts": failed_gate_blocker_reason_counts,
        "failed_gate_blocker_attributions": failed_gate_blocker_attributions,
        "failed_gate_blocker_attribution_count": len(
            failed_gate_blocker_attributions
        ),
        "failed_gate_blocker_attribution_counts_by_gate": (
            _ordered_string_counts(
                row["gate"] for row in failed_gate_blocker_attributions
            )
        ),
        "failed_gate_blocker_attribution_counts_by_blocker": (
            _ordered_string_counts(
                row["blocker"] for row in failed_gate_blocker_attributions
            )
        ),
        "failed_gate_blocker_attribution_counts_by_reason": (
            attribution_reason_counts
        ),
        "failed_gate_blocker_attributed_gates": attributed_gates,
        "failed_gate_blocker_attributed_gate_count": len(attributed_gates),
        "failed_gate_blocker_attributed_blockers": attributed_blockers,
        "failed_gate_blocker_attributed_blocker_count": len(attributed_blockers),
        "failed_gate_blocker_set_matches_attribution_set": (
            set(failed_gate_blocker_list) == set(attributed_blockers)
        ),
        "failed_gate_blocker_attribution_gate_set_matches_failed_gate_names": (
            set(attributed_gates) == set(failed_gate_names)
        ),
        "failed_gate_blocker_attribution_count_covers_failed_gate_blocker_count": (
            len(failed_gate_blocker_attributions) >= len(failed_gate_blocker_list)
        ),
        "blocker_witness_summary_available": blocker_witness_summary_available,
        "blocker_witness_summary_blockers": blocker_witness_summary_blockers,
        "blocker_witness_summary_blocker_count": (
            blocker_witness_summary_blocker_count
        ),
        "blocker_witness_summary_blocker_count_matches_failed_gate_blocker_count": (
            blocker_witness_summary_blocker_count == len(failed_gate_blocker_list)
            if blocker_witness_summary_available
            else False
        ),
        "blocker_witness_summary_blocker_set_matches_failed_gate_blocker_set": (
            set(blocker_witness_summary_blockers)
            == set(failed_gate_blocker_list)
            if blocker_witness_summary_available
            else False
        ),
        "failed_gate_blocker_provenance_consistency": (
            provenance_consistency
        ),
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
    }


def _bounded_admissible_minor_normalization_gate_summary_consistency(
    *,
    claim_scope: str,
    gate_rows: Sequence[dict],
    blockers: Sequence[str],
    failed_gate_blockers: Sequence[str],
    blocker_witness_summary: dict | None,
) -> dict:
    gate_list = _dict_sequence(gate_rows)
    blocker_list = [str(blocker) for blocker in blockers]
    failed_gate_blocker_list = [str(blocker) for blocker in failed_gate_blockers]
    gate_names = [str(row.get("gate")) for row in gate_list]
    failed_gate_names = [
        str(row.get("gate"))
        for row in gate_list
        if not bool(row.get("passed"))
    ]
    gate_blockers = {
        str(row.get("gate")): [str(blocker) for blocker in row.get("blockers", [])]
        for row in gate_list
    }
    failed_gate_blocker_attributions = (
        _bounded_admissible_minor_normalization_failed_gate_blocker_attributions(
            gate_list
        )
    )
    attributed_gates = _ordered_unique_strings(
        row["gate"] for row in failed_gate_blocker_attributions
    )
    attributed_blockers = _ordered_unique_strings(
        row["blocker"] for row in failed_gate_blocker_attributions
    )
    failed_gate_blocker_reason_counts = _ordered_string_counts(
        _admissible_minor_blocker_reason(blocker)
        for blocker in failed_gate_blocker_list
    )
    failed_gate_blocker_attribution_reason_counts = _ordered_string_counts(
        row["reason_code"] for row in failed_gate_blocker_attributions
    )
    gate_count = len(gate_list)
    passed_gate_count = sum(1 for row in gate_list if bool(row.get("passed")))
    failed_gate_count = gate_count - passed_gate_count
    required_gate_count = sum(1 for row in gate_list if bool(row.get("required")))
    failed_required_gate_count = sum(
        1
        for row in gate_list
        if bool(row.get("required")) and not bool(row.get("passed"))
    )
    blocker_count = len(blocker_list)
    failed_gate_blocker_count = len(failed_gate_blocker_list)
    blocker_witness_summary_available = isinstance(blocker_witness_summary, dict)
    blocker_witness_summary_blockers = (
        [str(blocker) for blocker in blocker_witness_summary.get("blockers", [])]
        if blocker_witness_summary_available
        else []
    )
    blocker_witness_summary_blocker_count = (
        _blocker_int(blocker_witness_summary.get("blocker_count", 0))
        if blocker_witness_summary_available
        else 0
    )
    blocker_count_matches_list = blocker_count == len(blocker_list)
    failed_gate_blocker_count_matches_list = (
        failed_gate_blocker_count == len(failed_gate_blocker_list)
    )
    failed_gate_blockers_match_blockers = failed_gate_blocker_list == blocker_list
    failed_gate_blocker_set_matches_blocker_set = (
        set(failed_gate_blocker_list) == set(blocker_list)
    )
    blocker_witness_summary_blockers_match = (
        blocker_witness_summary_blockers == blocker_list
        if blocker_witness_summary_available
        else False
    )
    blocker_witness_summary_blocker_count_matches = (
        blocker_witness_summary_blocker_count == blocker_count
        if blocker_witness_summary_available
        else False
    )
    all_failed_gates_have_blockers = all(
        bool(row.get("passed")) or bool(row.get("blockers"))
        for row in gate_list
    )
    passed_gates_have_no_blockers = all(
        (not bool(row.get("passed"))) or not bool(row.get("blockers"))
        for row in gate_list
    )
    gate_blocker_keys_match_gate_names = list(gate_blockers) == gate_names
    failed_gate_name_count_matches_failed_gate_count = (
        len(failed_gate_names) == failed_gate_count
    )
    failed_gate_blocker_reason_counts_total = sum(
        failed_gate_blocker_reason_counts.values()
    )
    failed_gate_blocker_reason_counts_total_matches_blocker_count = (
        failed_gate_blocker_reason_counts_total == failed_gate_blocker_count
    )
    failed_gate_blocker_attribution_count = len(failed_gate_blocker_attributions)
    failed_gate_blocker_attribution_reason_counts_total = sum(
        failed_gate_blocker_attribution_reason_counts.values()
    )
    failed_gate_blocker_attribution_reason_counts_total_matches_attribution_count = (
        failed_gate_blocker_attribution_reason_counts_total
        == failed_gate_blocker_attribution_count
    )
    failed_gate_blocker_attribution_set_matches_failed_gate_blocker_set = (
        set(attributed_blockers) == set(failed_gate_blocker_list)
    )
    failed_gate_blocker_attribution_gate_set_matches_failed_gate_names = (
        set(attributed_gates) == set(failed_gate_names)
    )
    failed_gate_blocker_attribution_count_covers_failed_gate_blocker_count = (
        failed_gate_blocker_attribution_count >= failed_gate_blocker_count
    )
    blocker_witness_summary_blocker_set_matches_failed_gate_blocker_set = (
        set(blocker_witness_summary_blockers) == set(failed_gate_blocker_list)
        if blocker_witness_summary_available
        else False
    )
    provenance_consistency = (
        _bounded_admissible_minor_normalization_failed_gate_blocker_provenance_consistency(
            claim_scope=claim_scope,
            gate_rows=gate_list,
            failed_gate_blockers=failed_gate_blocker_list,
            blocker_witness_summary=blocker_witness_summary,
        )
    )
    return {
        "method": (
            "bounded_admissible_minor_normalization_gate_summary_consistency"
        ),
        "claim_scope": claim_scope,
        "gate_count": gate_count,
        "gate_list_count": len(gate_list),
        "gate_count_matches_list": True,
        "gate_names": gate_names,
        "gate_name_count": len(gate_names),
        "gate_name_count_matches_gate_count": len(gate_names) == gate_count,
        "gate_blocker_map_count": len(gate_blockers),
        "gate_blocker_map_keys": list(gate_blockers),
        "gate_blocker_keys_match_gate_names": gate_blocker_keys_match_gate_names,
        "passed_gate_count": passed_gate_count,
        "failed_gate_count": failed_gate_count,
        "passed_failed_gate_counts_sum_to_gate_count": (
            passed_gate_count + failed_gate_count == gate_count
        ),
        "failed_gate_names": failed_gate_names,
        "failed_gate_name_count": len(failed_gate_names),
        "failed_gate_name_count_matches_failed_gate_count": (
            failed_gate_name_count_matches_failed_gate_count
        ),
        "required_gate_count": required_gate_count,
        "failed_required_gate_count": failed_required_gate_count,
        "blocker_count": blocker_count,
        "blocker_list_count": len(blocker_list),
        "blocker_count_matches_list": blocker_count_matches_list,
        "failed_gate_blocker_count": failed_gate_blocker_count,
        "failed_gate_blocker_list_count": len(failed_gate_blocker_list),
        "failed_gate_blocker_count_matches_list": (
            failed_gate_blocker_count_matches_list
        ),
        "failed_gate_blockers_match_blockers": failed_gate_blockers_match_blockers,
        "failed_gate_blocker_set_matches_blocker_set": (
            failed_gate_blocker_set_matches_blocker_set
        ),
        "failed_gate_blocker_reason_counts": failed_gate_blocker_reason_counts,
        "failed_gate_blocker_reason_counts_total": (
            failed_gate_blocker_reason_counts_total
        ),
        "failed_gate_blocker_reason_counts_total_matches_blocker_count": (
            failed_gate_blocker_reason_counts_total_matches_blocker_count
        ),
        "failed_gate_blocker_attributions": failed_gate_blocker_attributions,
        "failed_gate_blocker_attribution_count": (
            failed_gate_blocker_attribution_count
        ),
        "failed_gate_blocker_attribution_reason_counts": (
            failed_gate_blocker_attribution_reason_counts
        ),
        "failed_gate_blocker_attribution_reason_counts_total": (
            failed_gate_blocker_attribution_reason_counts_total
        ),
        "failed_gate_blocker_attribution_reason_counts_total_matches_attribution_count": (
            failed_gate_blocker_attribution_reason_counts_total_matches_attribution_count
        ),
        "failed_gate_blocker_attributed_gates": attributed_gates,
        "failed_gate_blocker_attributed_blockers": attributed_blockers,
        "failed_gate_blocker_attribution_set_matches_failed_gate_blocker_set": (
            failed_gate_blocker_attribution_set_matches_failed_gate_blocker_set
        ),
        "failed_gate_blocker_attribution_gate_set_matches_failed_gate_names": (
            failed_gate_blocker_attribution_gate_set_matches_failed_gate_names
        ),
        "failed_gate_blocker_attribution_count_covers_failed_gate_blocker_count": (
            failed_gate_blocker_attribution_count_covers_failed_gate_blocker_count
        ),
        "all_failed_gates_have_blockers": all_failed_gates_have_blockers,
        "passed_gates_have_no_blockers": passed_gates_have_no_blockers,
        "blocker_witness_summary_available": blocker_witness_summary_available,
        "blocker_witness_summary_blockers": blocker_witness_summary_blockers,
        "blocker_witness_summary_blockers_match": (
            blocker_witness_summary_blockers_match
        ),
        "blocker_witness_summary_blocker_count": (
            blocker_witness_summary_blocker_count
        ),
        "blocker_witness_summary_blocker_count_matches": (
            blocker_witness_summary_blocker_count_matches
        ),
        "blocker_witness_summary_blocker_set_matches_failed_gate_blocker_set": (
            blocker_witness_summary_blocker_set_matches_failed_gate_blocker_set
        ),
        "failed_gate_blocker_provenance_consistency": (
            provenance_consistency
        ),
        "gate_blocker_summary_consistent": bool(
            blocker_count_matches_list
            and failed_gate_blocker_count_matches_list
            and failed_gate_blocker_set_matches_blocker_set
            and failed_gate_blocker_reason_counts_total_matches_blocker_count
            and failed_gate_blocker_attribution_reason_counts_total_matches_attribution_count
            and failed_gate_blocker_attribution_set_matches_failed_gate_blocker_set
            and failed_gate_blocker_attribution_gate_set_matches_failed_gate_names
            and failed_gate_blocker_attribution_count_covers_failed_gate_blocker_count
            and gate_blocker_keys_match_gate_names
            and failed_gate_name_count_matches_failed_gate_count
            and all_failed_gates_have_blockers
            and passed_gates_have_no_blockers
            and blocker_witness_summary_available
            and blocker_witness_summary_blockers_match
            and blocker_witness_summary_blocker_count_matches
            and blocker_witness_summary_blocker_set_matches_failed_gate_blocker_set
            and provenance_consistency[
                "normalization_gate_provenance_consistent"
            ]
        ),
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
    }


def _bounded_admissible_minor_normalization_gate_summary(
    *,
    claim_scope: str,
    blockers: Sequence[object],
    blocker_witness_summary: dict | None,
    include_scanned_gcd_gates: bool = False,
    scanned_gcd_audit_missing: bool = False,
    scanned_gcd_audit_skipped: bool = False,
    candidate_is_exact_scanned_gcd: bool | None = None,
    quotient_gcd_certified: bool | None = None,
    include_normalization_gates: bool = True,
    scan_missing: bool = False,
    scan_skipped: bool = False,
    variables_missing: bool = False,
    checked_nonzero_minor_count: int = 0,
    failed_minor_indices: Sequence[int] = (),
    normalization_class_count: int = 0,
    normalization_mismatch_witness_count: int = 0,
    all_nonzero_minors_laurent_unit_equivalent: bool = False,
    complete_combination_scan: bool = False,
    truncated: bool = False,
    all_rows_have_nonzero_minor: bool = False,
    all_columns_have_nonzero_minor: bool = False,
    bounded_admissible_minor_normalization_certified: bool = False,
) -> dict:
    blocker_list = [str(blocker) for blocker in blockers]
    failed_indices = [int(index) for index in failed_minor_indices]
    gate_rows: list[dict] = []

    if include_scanned_gcd_gates:
        if scanned_gcd_audit_missing:
            gate_rows.append(
                _bounded_admissible_minor_normalization_gate_row(
                    "scanned_gcd_audit_present",
                    False,
                    blockers=["scanned_gcd_audit_missing"],
                    source_fields=["scanned_gcd_audit"],
                    evidence={"scanned_gcd_audit_present": False},
                )
            )
        if scanned_gcd_audit_skipped:
            gate_rows.append(
                _bounded_admissible_minor_normalization_gate_row(
                    "scanned_gcd_audit_not_skipped",
                    False,
                    blockers=["scanned_gcd_audit_skipped"],
                    source_fields=["skipped"],
                    evidence={"skipped": True},
                )
            )
        if candidate_is_exact_scanned_gcd is not None:
            exact_scanned_gcd = bool(candidate_is_exact_scanned_gcd)
            gate_rows.append(
                _bounded_admissible_minor_normalization_gate_row(
                    "exact_scanned_gcd",
                    exact_scanned_gcd,
                    blockers=["candidate_not_exact_scanned_gcd"],
                    source_fields=["candidate_is_exact_scanned_gcd"],
                    evidence={
                        "candidate_is_exact_scanned_gcd": exact_scanned_gcd,
                    },
                )
            )
        if quotient_gcd_certified is not None:
            quotient_certified = bool(quotient_gcd_certified)
            gate_rows.append(
                _bounded_admissible_minor_normalization_gate_row(
                    "quotient_gcd",
                    quotient_certified,
                    blockers=["quotient_gcd_uncertified"],
                    source_fields=["quotient_gcd_certified"],
                    evidence={
                        "quotient_gcd_certified": quotient_certified,
                    },
                )
            )

    if scan_missing:
        gate_rows.append(
            _bounded_admissible_minor_normalization_gate_row(
                "square_minor_scan_available",
                False,
                blockers=["square_minor_scan_missing"],
                source_fields=["square_minors"],
                evidence={"square_minor_scan_available": False},
            )
        )
    elif include_normalization_gates:
        if scan_skipped:
            gate_rows.append(
                _bounded_admissible_minor_normalization_gate_row(
                    "square_minor_scan_not_skipped",
                    False,
                    blockers=["square_minor_scan_skipped"],
                    source_fields=["skipped"],
                    evidence={"skipped": True},
                )
            )
        if variables_missing:
            gate_rows.append(
                _bounded_admissible_minor_normalization_gate_row(
                    "variable_names_available",
                    False,
                    blockers=["variable_names_missing"],
                    source_fields=["variables"],
                    evidence={"variables_available": False},
                )
            )

    if not scan_missing or include_scanned_gcd_gates:
        complete_scan_passed = bool(complete_combination_scan) and not bool(truncated)
        complete_scan_blockers = []
        if not bool(complete_combination_scan):
            complete_scan_blockers.append("complete_combination_scan_incomplete")
        if bool(truncated):
            complete_scan_blockers.append("square_minor_scan_truncated")
        gate_rows.append(
            _bounded_admissible_minor_normalization_gate_row(
                "complete_scan",
                complete_scan_passed,
                blockers=complete_scan_blockers,
                source_fields=["complete_combination_scan", "truncated"],
                evidence={
                    "complete_combination_scan": bool(complete_combination_scan),
                    "truncated": bool(truncated),
                },
            )
        )
        gate_rows.append(
            _bounded_admissible_minor_normalization_gate_row(
                "row_coverage",
                bool(all_rows_have_nonzero_minor),
                blockers=["nonzero_minor_coverage_incomplete"],
                source_fields=["all_rows_have_nonzero_minor"],
                evidence={
                    "all_rows_have_nonzero_minor": bool(
                        all_rows_have_nonzero_minor
                    ),
                },
            )
        )
        gate_rows.append(
            _bounded_admissible_minor_normalization_gate_row(
                "column_coverage",
                bool(all_columns_have_nonzero_minor),
                blockers=["nonzero_minor_coverage_incomplete"],
                source_fields=["all_columns_have_nonzero_minor"],
                evidence={
                    "all_columns_have_nonzero_minor": bool(
                        all_columns_have_nonzero_minor
                    ),
                },
            )
        )

    if include_normalization_gates and not (
        scan_missing or scan_skipped or variables_missing
    ):
        has_nonzero_minor = checked_nonzero_minor_count > 0
        gate_rows.append(
            _bounded_admissible_minor_normalization_gate_row(
                "nonzero_minor_present",
                has_nonzero_minor,
                blockers=["nonzero_admissible_minor_missing"],
                source_fields=["checked_nonzero_minor_count"],
                evidence={
                    "checked_nonzero_minor_count": checked_nonzero_minor_count,
                },
            )
        )
        unique_normalized_class = has_nonzero_minor and normalization_class_count == 1
        gate_rows.append(
            _bounded_admissible_minor_normalization_gate_row(
                "unique_normalized_class",
                unique_normalized_class,
                blockers=(
                    ["normalization_class_not_unique"]
                    if has_nonzero_minor
                    else ["nonzero_admissible_minor_missing"]
                ),
                source_fields=["normalization_class_count"],
                evidence={
                    "normalization_class_count": normalization_class_count,
                },
            )
        )
        if has_nonzero_minor:
            mismatch_absent = bool(all_nonzero_minors_laurent_unit_equivalent) and (
                not failed_indices
            ) and normalization_mismatch_witness_count == 0
            mismatch_blockers: list[str] = []
            if failed_indices or not bool(all_nonzero_minors_laurent_unit_equivalent):
                mismatch_blockers.append("failed_nonzero_minor_normalization")
            if normalization_mismatch_witness_count:
                mismatch_blockers.append("normalization_mismatch_witnesses_present")
            gate_rows.append(
                _bounded_admissible_minor_normalization_gate_row(
                    "normalization_mismatch_absent",
                    mismatch_absent,
                    blockers=mismatch_blockers,
                    source_fields=[
                        "all_nonzero_minors_laurent_unit_equivalent",
                        "failed_minor_indices",
                        "normalization_mismatch_witness_count",
                    ],
                    evidence={
                        "all_nonzero_minors_laurent_unit_equivalent": bool(
                            all_nonzero_minors_laurent_unit_equivalent
                        ),
                        "failed_minor_indices": failed_indices,
                        "normalization_mismatch_witness_count": (
                            normalization_mismatch_witness_count
                        ),
                    },
                )
            )

    derived_blockers = _ordered_unique_strings(
        blocker
        for row in gate_rows
        if not bool(row.get("passed"))
        for blocker in row.get("blockers", [])
    )
    derived_blocker_set = set(derived_blockers)
    failed_gate_blockers = [
        blocker for blocker in blocker_list if blocker in derived_blocker_set
    ]
    failed_gate_blockers.extend(
        blocker
        for blocker in derived_blockers
        if blocker not in set(failed_gate_blockers)
    )
    passed_gate_names = [
        str(row["gate"])
        for row in gate_rows
        if bool(row.get("passed"))
    ]
    failed_gate_names = [
        str(row["gate"])
        for row in gate_rows
        if not bool(row.get("passed"))
    ]
    required_gate_rows = [
        row for row in gate_rows if bool(row.get("required"))
    ]
    failed_required_gate_names = [
        str(row["gate"])
        for row in required_gate_rows
        if not bool(row.get("passed"))
    ]
    summary_consistency = (
        _bounded_admissible_minor_normalization_gate_summary_consistency(
            claim_scope=claim_scope,
            gate_rows=gate_rows,
            blockers=blocker_list,
            failed_gate_blockers=failed_gate_blockers,
            blocker_witness_summary=blocker_witness_summary,
        )
    )
    gate_pressure_summary = (
        _bounded_admissible_minor_normalization_gate_pressure_summary(
            claim_scope=claim_scope,
            gate_rows=gate_rows,
            failed_gate_blockers=failed_gate_blockers,
            blocker_witness_summary=blocker_witness_summary,
        )
    )
    failed_gate_blocker_provenance_consistency = gate_pressure_summary[
        "failed_gate_blocker_provenance_consistency"
    ]
    return {
        "method": "bounded_admissible_minor_normalization_gate_summary",
        "claim_scope": claim_scope,
        "gate_checks": gate_rows,
        "gate_count": len(gate_rows),
        "gate_statuses": {
            str(row["gate"]): bool(row.get("passed"))
            for row in gate_rows
        },
        "gate_blockers": {
            str(row["gate"]): list(row.get("blockers", []))
            for row in gate_rows
        },
        "passed_gate_names": passed_gate_names,
        "passed_gate_count": len(passed_gate_names),
        "failed_gate_names": failed_gate_names,
        "failed_gate_count": len(failed_gate_names),
        "required_gate_count": len(required_gate_rows),
        "failed_required_gate_names": failed_required_gate_names,
        "failed_required_gate_count": len(failed_required_gate_names),
        "all_required_gates_passed": bool(required_gate_rows)
        and not failed_required_gate_names,
        "failed_gate_blockers": failed_gate_blockers,
        "failed_gate_blocker_count": len(failed_gate_blockers),
        "failed_gate_blocker_reason_codes": gate_pressure_summary[
            "failed_gate_blocker_reason_codes"
        ],
        "failed_gate_blocker_reason_count": gate_pressure_summary[
            "failed_gate_blocker_reason_count"
        ],
        "failed_gate_blocker_reason_counts": gate_pressure_summary[
            "failed_gate_blocker_reason_counts"
        ],
        "failed_gate_blocker_attributions": gate_pressure_summary[
            "failed_gate_blocker_attributions"
        ],
        "failed_gate_blocker_attribution_count": gate_pressure_summary[
            "failed_gate_blocker_attribution_count"
        ],
        "failed_gate_blocker_attribution_counts_by_gate": gate_pressure_summary[
            "failed_gate_blocker_attribution_counts_by_gate"
        ],
        "failed_gate_blocker_attribution_counts_by_blocker": gate_pressure_summary[
            "failed_gate_blocker_attribution_counts_by_blocker"
        ],
        "failed_gate_blocker_attribution_counts_by_reason": gate_pressure_summary[
            "failed_gate_blocker_attribution_counts_by_reason"
        ],
        "failed_gate_blocker_provenance_consistency": (
            failed_gate_blocker_provenance_consistency
        ),
        "gate_pressure_summary": gate_pressure_summary,
        "blockers": blocker_list,
        "blocker_count": len(blocker_list),
        "blocker_reason_codes": _ordered_unique_strings(
            _admissible_minor_blocker_reason(blocker)
            for blocker in blocker_list
        ),
        "blocker_reason_counts": _ordered_string_counts(
            _admissible_minor_blocker_reason(blocker)
            for blocker in blocker_list
        ),
        "bounded_admissible_minor_normalization_certified": bool(
            bounded_admissible_minor_normalization_certified
        ),
        "summary_consistency": summary_consistency,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": [
            "gate statuses are derived from bounded scanned evidence and existing blocker fields",
            "passing all listed gates is not a full admissible-minor normalization certificate",
        ],
    }


def _minor_location_witness_from_record(
    record: dict,
    *,
    witness_kind: str,
) -> dict | None:
    minor_index_value = record.get("minor_index", record.get("first_minor_index"))
    if minor_index_value is None:
        return None
    try:
        minor_index = int(minor_index_value)
    except (TypeError, ValueError):
        return None
    witness = {
        "witness_kind": witness_kind,
        "minor_index": minor_index,
        "rows": list(record.get("rows", record.get("first_rows", []))),
        "columns": list(record.get("columns", record.get("first_columns", []))),
    }
    if record.get("normalized_polynomial") is not None:
        witness["normalized_polynomial"] = record.get("normalized_polynomial")
    if record.get("minor_polynomial") is not None:
        witness["minor_polynomial"] = record.get("minor_polynomial")
    if record.get("raw_polynomial") is not None:
        witness["raw_polynomial"] = record.get("raw_polynomial")
    return witness


def _first_normalization_record_witness(
    audit: dict,
    *,
    failed_indices: Sequence[int] = (),
) -> dict | None:
    records = _dict_sequence(audit.get("normalization_records", []))
    if not records:
        return None
    failed_index_set = {int(index) for index in failed_indices}
    if failed_index_set:
        for record in records:
            try:
                record_index = int(record.get("minor_index"))
            except (TypeError, ValueError):
                continue
            if record_index in failed_index_set:
                return _minor_location_witness_from_record(
                    record,
                    witness_kind="normalization_record",
                )
    return _minor_location_witness_from_record(
        records[0],
        witness_kind="normalization_record",
    )


def _first_normalization_class_witness(
    details: dict,
    audit: dict,
) -> dict | None:
    class_detail = details.get("normalization_class_not_unique")
    witnesses = (
        _dict_sequence(class_detail.get("normalization_class_witnesses", []))
        if isinstance(class_detail, dict)
        else []
    )
    if not witnesses:
        witnesses = _dict_sequence(audit.get("normalization_class_counts", []))
    if not witnesses:
        return None
    return _minor_location_witness_from_record(
        witnesses[0],
        witness_kind="normalization_class",
    )


def _first_normalization_mismatch_witness(audit: dict) -> dict | None:
    witnesses = _dict_sequence(audit.get("normalization_mismatch_witnesses", []))
    if not witnesses:
        return None
    witness = witnesses[0]
    try:
        minor_index = int(witness.get("mismatched_minor_index"))
    except (TypeError, ValueError):
        return None
    return {
        "witness_kind": "normalization_mismatch",
        "minor_index": minor_index,
        "rows": list(witness.get("mismatched_rows", [])),
        "columns": list(witness.get("mismatched_columns", [])),
        "normalized_polynomial": witness.get("mismatched_normalized_polynomial"),
        "minor_polynomial": witness.get("mismatched_minor_polynomial"),
        "raw_polynomial": witness.get("mismatched_raw_polynomial"),
        "representative_minor_index": witness.get("representative_minor_index"),
        "representative_rows": list(witness.get("representative_rows", [])),
        "representative_columns": list(witness.get("representative_columns", [])),
        "representative_normalized_polynomial": witness.get(
            "representative_normalized_polynomial"
        ),
    }


def _first_representative_normalization_witness(audit: dict) -> dict | None:
    representative = audit.get("normalization_representative_witness")
    if not isinstance(representative, dict):
        return None
    return _minor_location_witness_from_record(
        representative,
        witness_kind="normalization_representative",
    )


def _first_failed_division_witness(details: dict, audit: dict) -> dict | None:
    failed_detail = details.get("failed_nonzero_minor_division")
    witnesses = (
        _dict_sequence(failed_detail.get("failed_division_witnesses", []))
        if isinstance(failed_detail, dict)
        else []
    )
    if not witnesses:
        witnesses = _dict_sequence(audit.get("failed_division_witnesses", []))
    if not witnesses:
        return None
    witness = dict(witnesses[0])
    witness["witness_kind"] = "failed_division"
    return witness


def _first_quotient_uncertainty_witness(
    details: dict,
    quotient_gcd_uncertainty: dict | None,
) -> dict | None:
    uncertainty = quotient_gcd_uncertainty
    if uncertainty is None:
        quotient_detail = details.get("quotient_gcd_uncertified")
        if isinstance(quotient_detail, dict) and isinstance(
            quotient_detail.get("quotient_gcd_uncertainty_evidence"),
            dict,
        ):
            uncertainty = quotient_detail["quotient_gcd_uncertainty_evidence"]
    if not isinstance(uncertainty, dict):
        return None
    witness = uncertainty.get("first_quotient_polynomial_witness")
    if not isinstance(witness, dict):
        witnesses = _dict_sequence(uncertainty.get("quotient_polynomial_witnesses", []))
        witness = witnesses[0] if witnesses else None
    if not isinstance(witness, dict):
        return None
    normalized = dict(witness)
    normalized["witness_kind"] = "quotient_polynomial"
    return normalized


def _first_bounded_admissible_blocker_witness(
    blockers: Sequence[str],
    details: dict,
    *,
    normalization_audit: dict | None,
    scanned_gcd_audit: dict | None,
    quotient_gcd_uncertainty: dict | None,
) -> dict | None:
    witness_payload = _first_bounded_admissible_blocker_witness_payload(
        blockers,
        details,
        normalization_audit=normalization_audit,
        scanned_gcd_audit=scanned_gcd_audit,
        quotient_gcd_uncertainty=quotient_gcd_uncertainty,
    )
    return (
        witness_payload.get("witness")
        if isinstance(witness_payload, dict)
        else None
    )


def _bounded_blocker_witness_payload(
    witness: dict | None,
    *,
    source_blocker: str,
    source_field: str,
    source_detail_field: str | None = None,
) -> dict | None:
    if witness is None:
        return None
    return {
        "witness": witness,
        "source": {
            "available": True,
            "source_blocker": source_blocker,
            "source_reason_code": _admissible_minor_blocker_reason(
                source_blocker
            ),
            "source_field": source_field,
            "source_detail_field": source_detail_field,
            "witness_kind": witness.get("witness_kind"),
            "missing_reason": None,
        },
    }


def _first_quotient_uncertainty_witness_payload(
    details: dict,
    quotient_gcd_uncertainty: dict | None,
    *,
    source_blocker: str,
) -> dict | None:
    uncertainty = quotient_gcd_uncertainty
    source_prefix = "quotient_gcd_uncertainty_evidence"
    if uncertainty is None:
        quotient_detail = details.get("quotient_gcd_uncertified")
        if isinstance(quotient_detail, dict) and isinstance(
            quotient_detail.get("quotient_gcd_uncertainty_evidence"),
            dict,
        ):
            uncertainty = quotient_detail["quotient_gcd_uncertainty_evidence"]
            source_prefix = (
                "blocker_details.quotient_gcd_uncertified."
                "quotient_gcd_uncertainty_evidence"
            )
    if not isinstance(uncertainty, dict):
        return None
    witness = uncertainty.get("first_quotient_polynomial_witness")
    source_field = f"{source_prefix}.first_quotient_polynomial_witness"
    if not isinstance(witness, dict):
        witnesses = _dict_sequence(uncertainty.get("quotient_polynomial_witnesses", []))
        witness = witnesses[0] if witnesses else None
        source_field = f"{source_prefix}.quotient_polynomial_witnesses[0]"
    if not isinstance(witness, dict):
        return None
    normalized = dict(witness)
    normalized["witness_kind"] = "quotient_polynomial"
    return _bounded_blocker_witness_payload(
        normalized,
        source_blocker=source_blocker,
        source_field=source_field,
    )


def _first_failed_division_witness_payload(
    details: dict,
    audit: dict,
    *,
    source_blocker: str,
) -> dict | None:
    failed_detail = details.get("failed_nonzero_minor_division")
    witnesses = (
        _dict_sequence(failed_detail.get("failed_division_witnesses", []))
        if isinstance(failed_detail, dict)
        else []
    )
    source_field = (
        "blocker_details.failed_nonzero_minor_division."
        "failed_division_witnesses[0]"
    )
    if not witnesses:
        witnesses = _dict_sequence(audit.get("failed_division_witnesses", []))
        source_field = "scanned_gcd_audit.failed_division_witnesses[0]"
    if not witnesses:
        return None
    witness = dict(witnesses[0])
    witness["witness_kind"] = "failed_division"
    return _bounded_blocker_witness_payload(
        witness,
        source_blocker=source_blocker,
        source_field=source_field,
    )


def _first_normalization_record_witness_payload(
    audit: dict,
    *,
    source_blocker: str,
    failed_indices: Sequence[int] = (),
    source_detail_field: str | None = None,
) -> dict | None:
    witness = _first_normalization_record_witness(
        audit,
        failed_indices=failed_indices,
    )
    return _bounded_blocker_witness_payload(
        witness,
        source_blocker=source_blocker,
        source_field="normalization_audit.normalization_records",
        source_detail_field=source_detail_field,
    )


def _first_normalization_class_witness_payload(
    details: dict,
    audit: dict,
    *,
    source_blocker: str,
) -> dict | None:
    class_detail = details.get("normalization_class_not_unique")
    witnesses = (
        _dict_sequence(class_detail.get("normalization_class_witnesses", []))
        if isinstance(class_detail, dict)
        else []
    )
    source_field = (
        "blocker_details.normalization_class_not_unique."
        "normalization_class_witnesses[0]"
    )
    if not witnesses:
        witnesses = _dict_sequence(audit.get("normalization_class_counts", []))
        source_field = "normalization_audit.normalization_class_counts[0]"
    if not witnesses:
        return None
    witness = _minor_location_witness_from_record(
        witnesses[0],
        witness_kind="normalization_class",
    )
    return _bounded_blocker_witness_payload(
        witness,
        source_blocker=source_blocker,
        source_field=source_field,
    )


def _first_normalization_mismatch_witness_payload(
    audit: dict,
    *,
    source_blocker: str,
) -> dict | None:
    witness = _first_normalization_mismatch_witness(audit)
    return _bounded_blocker_witness_payload(
        witness,
        source_blocker=source_blocker,
        source_field="normalization_audit.normalization_mismatch_witnesses[0]",
    )


def _first_representative_normalization_witness_payload(
    audit: dict,
    *,
    source_blocker: str,
) -> dict | None:
    witness = _first_representative_normalization_witness(audit)
    return _bounded_blocker_witness_payload(
        witness,
        source_blocker=source_blocker,
        source_field="normalization_audit.normalization_representative_witness",
    )


def _first_bounded_admissible_blocker_witness_payload(
    blockers: Sequence[str],
    details: dict,
    *,
    normalization_audit: dict | None,
    scanned_gcd_audit: dict | None,
    quotient_gcd_uncertainty: dict | None,
) -> dict | None:
    normalization = normalization_audit if isinstance(normalization_audit, dict) else {}
    scanned = scanned_gcd_audit if isinstance(scanned_gcd_audit, dict) else {}
    failed_normalization_detail = details.get("failed_nonzero_minor_normalization")
    failed_indices = (
        _int_sequence(failed_normalization_detail.get("failed_minor_indices", []))
        if isinstance(failed_normalization_detail, dict)
        else _int_sequence(normalization.get("failed_minor_indices", []))
    )

    for blocker in blockers:
        witness_payload = _bounded_admissible_blocker_specific_witness_payload(
            blocker,
            details,
            normalization_audit=normalization,
            scanned_gcd_audit=scanned,
            quotient_gcd_uncertainty=quotient_gcd_uncertainty,
            failed_indices=failed_indices,
        )
        if witness_payload is not None:
            return witness_payload

    for witness_payload in (
        _first_quotient_uncertainty_witness_payload(
            details,
            quotient_gcd_uncertainty,
            source_blocker="quotient_gcd_uncertified",
        ),
        _first_failed_division_witness_payload(
            details,
            scanned,
            source_blocker="failed_nonzero_minor_division",
        ),
        _first_normalization_mismatch_witness_payload(
            normalization,
            source_blocker="normalization_mismatch_witnesses_present",
        ),
        _first_normalization_class_witness_payload(
            details,
            normalization,
            source_blocker="normalization_class_not_unique",
        ),
        _first_representative_normalization_witness_payload(
            normalization,
            source_blocker="nonzero_minor_coverage_incomplete",
        ),
        _first_normalization_record_witness_payload(
            normalization,
            source_blocker="failed_nonzero_minor_normalization",
        ),
    ):
        if witness_payload is not None:
            return witness_payload
    return None


def _bounded_admissible_blocker_specific_witness_payload(
    blocker: str,
    details: dict,
    *,
    normalization_audit: dict | None,
    scanned_gcd_audit: dict | None,
    quotient_gcd_uncertainty: dict | None,
    failed_indices: Sequence[int] = (),
) -> dict | None:
    normalization = (
        normalization_audit if isinstance(normalization_audit, dict) else {}
    )
    scanned = scanned_gcd_audit if isinstance(scanned_gcd_audit, dict) else {}
    if blocker == "quotient_gcd_uncertified":
        return _first_quotient_uncertainty_witness_payload(
            details,
            quotient_gcd_uncertainty,
            source_blocker=blocker,
        )
    if blocker == "failed_nonzero_minor_division":
        return _first_failed_division_witness_payload(
            details,
            scanned,
            source_blocker=blocker,
        )
    if blocker == "failed_nonzero_minor_normalization":
        witness_payload = _first_normalization_record_witness_payload(
            normalization,
            source_blocker=blocker,
            failed_indices=failed_indices,
            source_detail_field=(
                "blocker_details.failed_nonzero_minor_normalization."
                "failed_minor_indices"
            ),
        )
        if witness_payload is not None:
            return witness_payload
        return _first_normalization_mismatch_witness_payload(
            normalization,
            source_blocker=blocker,
        )
    if blocker == "normalization_class_not_unique":
        return _first_normalization_class_witness_payload(
            details,
            normalization,
            source_blocker=blocker,
        )
    if blocker == "normalization_mismatch_witnesses_present":
        return _first_normalization_mismatch_witness_payload(
            normalization,
            source_blocker=blocker,
        )
    if blocker in {
        "complete_combination_scan_incomplete",
        "square_minor_scan_truncated",
        "nonzero_minor_coverage_incomplete",
    }:
        witness_payload = _first_representative_normalization_witness_payload(
            normalization,
            source_blocker=blocker,
        )
        if witness_payload is not None:
            return witness_payload
        return _first_normalization_record_witness_payload(
            normalization,
            source_blocker=blocker,
        )
    return None


def _missing_bounded_blocker_witness_source(
    blockers: Sequence[str],
    reason_codes: Sequence[str],
) -> dict:
    return {
        "available": False,
        "source_blocker": None,
        "source_reason_code": None,
        "source_field": None,
        "source_detail_field": None,
        "witness_kind": None,
        "missing_reason": (
            "no_reusable_locator_witness"
            if blockers
            else "no_blockers_supplied"
        ),
    }


def _bounded_blocker_witness_source_rows(
    blockers: Sequence[str],
    details: dict,
    *,
    normalization_audit: dict | None,
    scanned_gcd_audit: dict | None,
    quotient_gcd_uncertainty: dict | None,
) -> list[dict]:
    normalization = (
        normalization_audit if isinstance(normalization_audit, dict) else {}
    )
    failed_normalization_detail = details.get("failed_nonzero_minor_normalization")
    failed_indices = (
        _int_sequence(failed_normalization_detail.get("failed_minor_indices", []))
        if isinstance(failed_normalization_detail, dict)
        else _int_sequence(normalization.get("failed_minor_indices", []))
    )
    rows: list[dict] = []
    for blocker in blockers:
        reason_code = _admissible_minor_blocker_reason(blocker)
        witness_payload = _bounded_admissible_blocker_specific_witness_payload(
            blocker,
            details,
            normalization_audit=normalization_audit,
            scanned_gcd_audit=scanned_gcd_audit,
            quotient_gcd_uncertainty=quotient_gcd_uncertainty,
            failed_indices=failed_indices,
        )
        if (
            isinstance(witness_payload, dict)
            and isinstance(witness_payload.get("source"), dict)
        ):
            source = dict(witness_payload["source"])
        else:
            source = _missing_bounded_blocker_witness_source(
                [blocker],
                [reason_code],
            )
        available = bool(source.get("available"))
        source_blocker = source.get("source_blocker")
        source_reason_code = source.get("source_reason_code")
        source_matches_blocker = bool(available and source_blocker == blocker)
        source_reason_matches_blocker_reason = bool(
            available and source_reason_code == reason_code
        )
        missing_reason = source.get("missing_reason")
        source_provenance_consistent = (
            source_matches_blocker
            and source_reason_matches_blocker_reason
            if available
            else missing_reason is not None
        )
        rows.append(
            {
                "blocker": blocker,
                "reason_code": reason_code,
                "available": available,
                "source_blocker": source_blocker,
                "source_reason_code": source_reason_code,
                "source_field": source.get("source_field"),
                "source_detail_field": source.get("source_detail_field"),
                "witness_kind": source.get("witness_kind"),
                "missing_reason": missing_reason,
                "source_matches_blocker": source_matches_blocker,
                "source_reason_matches_blocker_reason": (
                    source_reason_matches_blocker_reason
                ),
                "source_provenance_consistent": source_provenance_consistent,
            }
        )
    return rows


def _bounded_blocker_summary_consistency(
    *,
    blockers: Sequence[str],
    blocker_count: int,
    reason_codes: Sequence[str],
    blocker_reason_count: int,
    blocker_reason_counts: dict[str, int],
    reason_count: int,
    first_witness: dict | None,
    first_witness_source: dict,
    witness_available_count: int,
    missing_witness_reasons: Sequence[str],
    missing_witness_reason_count: int,
    missing_witness_reason_counts: dict[str, int],
    blocker_witness_sources: Sequence[dict],
) -> dict:
    blocker_list_count = len(blockers)
    reason_list_count = len(reason_codes)
    reason_codes_unique = len(set(reason_codes)) == reason_list_count
    blocker_reason_counts_total = sum(blocker_reason_counts.values())
    blocker_reason_counts_key_count = len(blocker_reason_counts)
    expected_blocker_reason_counts_total = (
        blocker_list_count if blocker_list_count else reason_list_count
    )
    blocker_reason_counts_total_matches_expected = (
        blocker_reason_counts_total == expected_blocker_reason_counts_total
    )
    blocker_reason_counts_keys_match_reason_codes = (
        set(blocker_reason_counts) == set(reason_codes)
    )
    blocker_reason_count_matches_counts_key_count = (
        blocker_reason_count == blocker_reason_counts_key_count
    )
    first_witness_available = first_witness is not None
    source_available = bool(first_witness_source.get("available"))
    first_witness_kind = (
        first_witness.get("witness_kind")
        if isinstance(first_witness, dict)
        else None
    )
    source_witness_kind = first_witness_source.get("witness_kind")
    missing_witness_reason_list_count = len(missing_witness_reasons)
    missing_witness_reason_counts_total = sum(
        missing_witness_reason_counts.values()
    )
    missing_witness_reason_counts_key_count = len(missing_witness_reason_counts)
    blocker_count_matches_list = blocker_count == blocker_list_count
    reason_count_matches_list = reason_count == reason_list_count
    blocker_reason_count_matches_reason_count = blocker_reason_count == reason_count
    witness_available_count_matches_first_witness = (
        witness_available_count == int(first_witness_available)
    )
    first_witness_source_matches_witness = (
        source_available == first_witness_available
    )
    first_witness_kind_matches_source = first_witness_kind == source_witness_kind
    missing_witness_reason_count_matches_list = (
        missing_witness_reason_count == missing_witness_reason_list_count
    )
    missing_witness_reason_counts_total_matches_list = (
        missing_witness_reason_counts_total == missing_witness_reason_list_count
    )
    missing_witness_reason_counts_keys_match_reasons = (
        set(missing_witness_reason_counts) == set(missing_witness_reasons)
    )
    missing_witness_reason_count_matches_counts_total = (
        missing_witness_reason_count == missing_witness_reason_counts_total
    )
    missing_witness_reasons_match_availability = (
        missing_witness_reason_count == 0
        if first_witness_available
        else missing_witness_reason_count > 0
    )
    blocker_witness_source_rows = _dict_sequence(blocker_witness_sources)
    blocker_witness_source_count = len(blocker_witness_source_rows)
    blocker_witness_source_blockers = [
        str(row.get("blocker"))
        for row in blocker_witness_source_rows
    ]
    blocker_witness_source_reason_codes = [
        str(row.get("reason_code"))
        for row in blocker_witness_source_rows
    ]
    expected_blocker_source_reason_codes = [
        _admissible_minor_blocker_reason(blocker)
        for blocker in blockers
    ]
    expected_source_reason_counts = _ordered_string_counts(
        _admissible_minor_blocker_reason(blocker)
        for blocker in blockers
    )
    blocker_witness_source_counts_by_reason = _ordered_string_counts(
        blocker_witness_source_reason_codes
    )
    blocker_witness_source_available_count = sum(
        1
        for row in blocker_witness_source_rows
        if bool(row.get("available"))
    )
    blocker_witness_source_missing_count = (
        blocker_witness_source_count - blocker_witness_source_available_count
    )
    blocker_witness_source_available_counts_by_reason = _ordered_string_counts(
        row.get("reason_code")
        for row in blocker_witness_source_rows
        if bool(row.get("available"))
    )
    blocker_witness_source_missing_counts_by_reason = _ordered_string_counts(
        row.get("reason_code")
        for row in blocker_witness_source_rows
        if not bool(row.get("available"))
    )
    blocker_witness_source_available_blockers = [
        str(row.get("blocker"))
        for row in blocker_witness_source_rows
        if bool(row.get("available"))
    ]
    blocker_witness_source_missing_blockers = [
        str(row.get("blocker"))
        for row in blocker_witness_source_rows
        if not bool(row.get("available"))
    ]
    blocker_witness_source_missing_reasons = [
        str(row.get("missing_reason"))
        for row in blocker_witness_source_rows
        if not bool(row.get("available"))
        and row.get("missing_reason") is not None
    ]
    blocker_witness_source_missing_reason_counts = _ordered_string_counts(
        blocker_witness_source_missing_reasons
    )
    blocker_witness_source_available_counts_total = sum(
        blocker_witness_source_available_counts_by_reason.values()
    )
    blocker_witness_source_missing_counts_total = sum(
        blocker_witness_source_missing_counts_by_reason.values()
    )
    blocker_witness_source_count_matches_blocker_count = (
        blocker_witness_source_count == blocker_list_count
    )
    blocker_witness_source_blockers_match_blockers = (
        blocker_witness_source_blockers == list(blockers)
    )
    blocker_witness_source_reason_code_count_matches_source_count = (
        len(blocker_witness_source_reason_codes) == blocker_witness_source_count
    )
    blocker_witness_source_reason_codes_match_blocker_reasons = (
        blocker_witness_source_reason_codes == expected_blocker_source_reason_codes
    )
    blocker_witness_source_reason_counts_match_expected = (
        blocker_witness_source_counts_by_reason == expected_source_reason_counts
    )
    blocker_witness_source_availability_counts_sum_to_source_count = (
        blocker_witness_source_available_count
        + blocker_witness_source_missing_count
        == blocker_witness_source_count
    )
    blocker_witness_source_available_counts_total_matches_available_count = (
        blocker_witness_source_available_counts_total
        == blocker_witness_source_available_count
    )
    blocker_witness_source_missing_counts_total_matches_missing_count = (
        blocker_witness_source_missing_counts_total
        == blocker_witness_source_missing_count
    )
    blocker_witness_source_available_blocker_count_matches_available_count = (
        len(blocker_witness_source_available_blockers)
        == blocker_witness_source_available_count
    )
    blocker_witness_source_missing_blocker_count_matches_missing_count = (
        len(blocker_witness_source_missing_blockers)
        == blocker_witness_source_missing_count
    )
    blocker_witness_source_missing_reason_count_matches_missing_count = (
        len(blocker_witness_source_missing_reasons)
        == blocker_witness_source_missing_count
    )
    blocker_witness_source_missing_reason_counts_total_matches_missing_count = (
        sum(blocker_witness_source_missing_reason_counts.values())
        == blocker_witness_source_missing_count
    )
    blocker_witness_source_available_rows_have_no_missing_reason = all(
        row.get("missing_reason") is None
        for row in blocker_witness_source_rows
        if bool(row.get("available"))
    )
    blocker_witness_source_provenance_consistent = all(
        bool(row.get("source_provenance_consistent"))
        for row in blocker_witness_source_rows
    )
    source_witness_rows_consistent = bool(
        blocker_witness_source_count_matches_blocker_count
        and blocker_witness_source_blockers_match_blockers
        and blocker_witness_source_reason_code_count_matches_source_count
        and blocker_witness_source_reason_codes_match_blocker_reasons
        and blocker_witness_source_reason_counts_match_expected
        and blocker_witness_source_availability_counts_sum_to_source_count
        and blocker_witness_source_available_counts_total_matches_available_count
        and blocker_witness_source_missing_counts_total_matches_missing_count
        and blocker_witness_source_available_blocker_count_matches_available_count
        and blocker_witness_source_missing_blocker_count_matches_missing_count
        and blocker_witness_source_missing_reason_count_matches_missing_count
        and blocker_witness_source_missing_reason_counts_total_matches_missing_count
        and blocker_witness_source_available_rows_have_no_missing_reason
        and blocker_witness_source_provenance_consistent
    )
    return {
        "method": (
            "bounded_admissible_minor_normalization_blocker_summary_consistency"
        ),
        "blocker_count": blocker_count,
        "blocker_list_count": blocker_list_count,
        "blocker_count_matches_list": blocker_count_matches_list,
        "reason_count": reason_count,
        "reason_list_count": reason_list_count,
        "blocker_reason_count": blocker_reason_count,
        "reason_count_matches_list": reason_count_matches_list,
        "blocker_reason_count_matches_reason_count": (
            blocker_reason_count_matches_reason_count
        ),
        "reason_codes_unique": reason_codes_unique,
        "blocker_reason_counts_total": blocker_reason_counts_total,
        "expected_blocker_reason_counts_total": (
            expected_blocker_reason_counts_total
        ),
        "blocker_reason_counts_total_matches_expected": (
            blocker_reason_counts_total_matches_expected
        ),
        "blocker_reason_counts_key_count": blocker_reason_counts_key_count,
        "blocker_reason_counts_keys_match_reason_codes": (
            blocker_reason_counts_keys_match_reason_codes
        ),
        "blocker_reason_count_matches_counts_key_count": (
            blocker_reason_count_matches_counts_key_count
        ),
        "first_witness_available": first_witness_available,
        "witness_available_count": witness_available_count,
        "witness_available_count_matches_first_witness": (
            witness_available_count_matches_first_witness
        ),
        "first_witness_source_available": source_available,
        "first_witness_source_matches_witness": (
            first_witness_source_matches_witness
        ),
        "first_witness_kind_matches_source": first_witness_kind_matches_source,
        "missing_witness_reason_count": missing_witness_reason_count,
        "missing_witness_reason_list_count": missing_witness_reason_list_count,
        "missing_witness_reason_count_matches_list": (
            missing_witness_reason_count_matches_list
        ),
        "missing_witness_reason_counts_total": (
            missing_witness_reason_counts_total
        ),
        "missing_witness_reason_counts_key_count": (
            missing_witness_reason_counts_key_count
        ),
        "missing_witness_reason_counts_total_matches_list": (
            missing_witness_reason_counts_total_matches_list
        ),
        "missing_witness_reason_counts_keys_match_reasons": (
            missing_witness_reason_counts_keys_match_reasons
        ),
        "missing_witness_reason_count_matches_counts_total": (
            missing_witness_reason_count_matches_counts_total
        ),
        "missing_witness_reasons_match_availability": (
            missing_witness_reasons_match_availability
        ),
        "blocker_witness_source_count": blocker_witness_source_count,
        "blocker_witness_source_count_matches_blocker_count": (
            blocker_witness_source_count_matches_blocker_count
        ),
        "blocker_witness_source_blockers": blocker_witness_source_blockers,
        "blocker_witness_source_blockers_match_blockers": (
            blocker_witness_source_blockers_match_blockers
        ),
        "blocker_witness_source_reason_codes": (
            blocker_witness_source_reason_codes
        ),
        "expected_blocker_witness_source_reason_codes": (
            expected_blocker_source_reason_codes
        ),
        "blocker_witness_source_reason_code_count": (
            len(blocker_witness_source_reason_codes)
        ),
        "blocker_witness_source_reason_code_count_matches_source_count": (
            blocker_witness_source_reason_code_count_matches_source_count
        ),
        "blocker_witness_source_reason_codes_match_blocker_reasons": (
            blocker_witness_source_reason_codes_match_blocker_reasons
        ),
        "blocker_witness_source_counts_by_reason": (
            blocker_witness_source_counts_by_reason
        ),
        "expected_blocker_witness_source_counts_by_reason": (
            expected_source_reason_counts
        ),
        "blocker_witness_source_reason_counts_match_expected": (
            blocker_witness_source_reason_counts_match_expected
        ),
        "blocker_witness_source_available_count": (
            blocker_witness_source_available_count
        ),
        "blocker_witness_source_available_blockers": (
            blocker_witness_source_available_blockers
        ),
        "blocker_witness_source_available_blocker_count_matches_available_count": (
            blocker_witness_source_available_blocker_count_matches_available_count
        ),
        "blocker_witness_source_available_counts_by_reason": (
            blocker_witness_source_available_counts_by_reason
        ),
        "blocker_witness_source_available_counts_total": (
            blocker_witness_source_available_counts_total
        ),
        "blocker_witness_source_available_counts_total_matches_available_count": (
            blocker_witness_source_available_counts_total_matches_available_count
        ),
        "blocker_witness_source_missing_count": (
            blocker_witness_source_missing_count
        ),
        "blocker_witness_source_missing_blockers": (
            blocker_witness_source_missing_blockers
        ),
        "blocker_witness_source_missing_blocker_count_matches_missing_count": (
            blocker_witness_source_missing_blocker_count_matches_missing_count
        ),
        "blocker_witness_source_missing_reasons": (
            blocker_witness_source_missing_reasons
        ),
        "blocker_witness_source_missing_reason_counts": (
            blocker_witness_source_missing_reason_counts
        ),
        "blocker_witness_source_missing_reason_count": (
            len(blocker_witness_source_missing_reasons)
        ),
        "blocker_witness_source_missing_reason_count_matches_missing_count": (
            blocker_witness_source_missing_reason_count_matches_missing_count
        ),
        "blocker_witness_source_missing_reason_counts_total_matches_missing_count": (
            blocker_witness_source_missing_reason_counts_total_matches_missing_count
        ),
        "blocker_witness_source_missing_counts_by_reason": (
            blocker_witness_source_missing_counts_by_reason
        ),
        "blocker_witness_source_missing_counts_total": (
            blocker_witness_source_missing_counts_total
        ),
        "blocker_witness_source_missing_counts_total_matches_missing_count": (
            blocker_witness_source_missing_counts_total_matches_missing_count
        ),
        "blocker_witness_source_availability_counts_sum_to_source_count": (
            blocker_witness_source_availability_counts_sum_to_source_count
        ),
        "blocker_witness_source_available_rows_have_no_missing_reason": (
            blocker_witness_source_available_rows_have_no_missing_reason
        ),
        "blocker_witness_source_provenance_consistent": (
            blocker_witness_source_provenance_consistent
        ),
        "source_witness_rows_consistent": source_witness_rows_consistent,
        "count_list_source_provenance_consistent": bool(
            blocker_count_matches_list
            and reason_count_matches_list
            and blocker_reason_count_matches_reason_count
            and reason_codes_unique
            and blocker_reason_counts_total_matches_expected
            and blocker_reason_counts_keys_match_reason_codes
            and blocker_reason_count_matches_counts_key_count
            and witness_available_count_matches_first_witness
            and first_witness_source_matches_witness
            and first_witness_kind_matches_source
            and missing_witness_reason_count_matches_list
            and missing_witness_reason_counts_total_matches_list
            and missing_witness_reason_counts_keys_match_reasons
            and missing_witness_reason_count_matches_counts_total
            and missing_witness_reasons_match_availability
            and blocker_witness_source_count_matches_blocker_count
            and blocker_witness_source_blockers_match_blockers
            and blocker_witness_source_reason_code_count_matches_source_count
            and blocker_witness_source_reason_codes_match_blocker_reasons
            and blocker_witness_source_reason_counts_match_expected
            and blocker_witness_source_availability_counts_sum_to_source_count
            and blocker_witness_source_available_counts_total_matches_available_count
            and blocker_witness_source_missing_counts_total_matches_missing_count
            and source_witness_rows_consistent
        ),
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
    }


def _bounded_admissible_minor_normalization_blocker_witness_summary(
    blockers: Sequence[object],
    details: object | None = None,
    *,
    normalization_audit: dict | None = None,
    scanned_gcd_audit: dict | None = None,
    quotient_gcd_uncertainty: dict | None = None,
    claim_scope: str,
) -> dict:
    blocker_list = [str(blocker) for blocker in blockers]
    normalized_details = dict(details) if isinstance(details, dict) else {}
    blocker_reason_list = [
        _admissible_minor_blocker_reason(blocker)
        for blocker in blocker_list
    ]
    if not blocker_reason_list:
        blocker_reason_list = [
            "bounded_scan_only_not_full_admissible_minor_normalization"
        ]
    reason_codes = _ordered_unique_strings(blocker_reason_list)
    blocker_reason_counts = _ordered_string_counts(blocker_reason_list)
    first_witness_payload = _first_bounded_admissible_blocker_witness_payload(
        blocker_list,
        normalized_details,
        normalization_audit=normalization_audit,
        scanned_gcd_audit=scanned_gcd_audit,
        quotient_gcd_uncertainty=quotient_gcd_uncertainty,
    )
    first_witness = (
        first_witness_payload.get("witness")
        if isinstance(first_witness_payload, dict)
        else None
    )
    first_witness_source = (
        first_witness_payload.get("source")
        if isinstance(first_witness_payload, dict)
        and isinstance(first_witness_payload.get("source"), dict)
        else _missing_bounded_blocker_witness_source(blocker_list, reason_codes)
    )
    blocker_witness_sources = _bounded_blocker_witness_source_rows(
        blocker_list,
        normalized_details,
        normalization_audit=normalization_audit,
        scanned_gcd_audit=scanned_gcd_audit,
        quotient_gcd_uncertainty=quotient_gcd_uncertainty,
    )
    blocker_witness_source_count = len(blocker_witness_sources)
    blocker_witness_source_reason_codes = [
        str(row.get("reason_code")) for row in blocker_witness_sources
    ]
    blocker_witness_source_counts_by_reason = _ordered_string_counts(
        row.get("reason_code") for row in blocker_witness_sources
    )
    blocker_witness_source_available_count = sum(
        1 for row in blocker_witness_sources if bool(row.get("available"))
    )
    blocker_witness_source_available_blockers = [
        str(row.get("blocker"))
        for row in blocker_witness_sources
        if bool(row.get("available"))
    ]
    blocker_witness_source_available_counts_by_reason = _ordered_string_counts(
        row.get("reason_code")
        for row in blocker_witness_sources
        if bool(row.get("available"))
    )
    blocker_witness_source_missing_count = (
        blocker_witness_source_count - blocker_witness_source_available_count
    )
    blocker_witness_source_missing_blockers = [
        str(row.get("blocker"))
        for row in blocker_witness_sources
        if not bool(row.get("available"))
    ]
    blocker_witness_source_missing_reasons = [
        str(row.get("missing_reason"))
        for row in blocker_witness_sources
        if not bool(row.get("available"))
        and row.get("missing_reason") is not None
    ]
    blocker_witness_source_missing_reason_counts = _ordered_string_counts(
        blocker_witness_source_missing_reasons
    )
    blocker_witness_source_missing_counts_by_reason = _ordered_string_counts(
        row.get("reason_code")
        for row in blocker_witness_sources
        if not bool(row.get("available"))
    )
    reason_count = len(reason_codes)
    witness_available_count = int(first_witness is not None)
    missing_witness_reasons = (
        []
        if first_witness is not None
        else [str(first_witness_source.get("missing_reason"))]
    )
    missing_witness_reason_counts = _ordered_string_counts(
        missing_witness_reasons
    )
    missing_witness_reason_count = len(missing_witness_reasons)
    blocker_count = len(blocker_list)
    blocker_reason_count = len(reason_codes)
    summary_consistency = _bounded_blocker_summary_consistency(
        blockers=blocker_list,
        blocker_count=blocker_count,
        reason_codes=reason_codes,
        blocker_reason_count=blocker_reason_count,
        blocker_reason_counts=blocker_reason_counts,
        reason_count=reason_count,
        first_witness=first_witness,
        first_witness_source=first_witness_source,
        witness_available_count=witness_available_count,
        missing_witness_reasons=missing_witness_reasons,
        missing_witness_reason_count=missing_witness_reason_count,
        missing_witness_reason_counts=missing_witness_reason_counts,
        blocker_witness_sources=blocker_witness_sources,
    )
    return {
        "method": "bounded_admissible_minor_normalization_blocker_witness_summary",
        "claim_scope": claim_scope,
        "blockers": blocker_list,
        "blocker_count": blocker_count,
        "blocker_reason_codes": reason_codes,
        "blocker_reason_counts": blocker_reason_counts,
        "blocker_reason_count": blocker_reason_count,
        "reason_count": reason_count,
        "first_witness_available": first_witness is not None,
        "witness_available_count": witness_available_count,
        "first_witness_kind": (
            first_witness.get("witness_kind")
            if isinstance(first_witness, dict)
            else None
        ),
        "first_witness_source": first_witness_source,
        "first_witness": first_witness,
        "missing_witness_reasons": missing_witness_reasons,
        "missing_witness_reason_counts": missing_witness_reason_counts,
        "missing_witness_reason_count": missing_witness_reason_count,
        "blocker_witness_sources": blocker_witness_sources,
        "blocker_witness_source_count": blocker_witness_source_count,
        "blocker_witness_source_reason_codes": (
            blocker_witness_source_reason_codes
        ),
        "blocker_witness_source_counts_by_reason": (
            blocker_witness_source_counts_by_reason
        ),
        "blocker_witness_source_available_count": (
            blocker_witness_source_available_count
        ),
        "blocker_witness_source_available_blockers": (
            blocker_witness_source_available_blockers
        ),
        "blocker_witness_source_available_counts_by_reason": (
            blocker_witness_source_available_counts_by_reason
        ),
        "blocker_witness_source_missing_count": (
            blocker_witness_source_missing_count
        ),
        "blocker_witness_source_missing_blockers": (
            blocker_witness_source_missing_blockers
        ),
        "blocker_witness_source_missing_reasons": (
            blocker_witness_source_missing_reasons
        ),
        "blocker_witness_source_missing_reason_counts": (
            blocker_witness_source_missing_reason_counts
        ),
        "blocker_witness_source_missing_reason_count": (
            len(blocker_witness_source_missing_reasons)
        ),
        "blocker_witness_source_missing_counts_by_reason": (
            blocker_witness_source_missing_counts_by_reason
        ),
        "summary_consistency": summary_consistency,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": [
            "bounded witnesses explain why the current payload does not certify full admissible-minor normalization",
            "missing first_witness means the payload had counts or blockers but no reusable locator witness",
        ],
    }


def _with_bounded_admissible_minor_normalization_blocker_witness_summary(
    blocker_summary: dict,
    *,
    prefix: str,
    normalization_audit: dict | None = None,
    scanned_gcd_audit: dict | None = None,
    quotient_gcd_uncertainty: dict | None = None,
    claim_scope: str,
) -> dict:
    normalized = dict(blocker_summary)
    blockers_key = f"{prefix}_blockers"
    details_key = f"{prefix}_blocker_details"
    blockers = [str(blocker) for blocker in normalized.get(blockers_key, [])]
    details = (
        dict(normalized.get(details_key, {}))
        if isinstance(normalized.get(details_key, {}), dict)
        else {}
    )
    summary = _bounded_admissible_minor_normalization_blocker_witness_summary(
        blockers,
        details,
        normalization_audit=normalization_audit,
        scanned_gcd_audit=scanned_gcd_audit,
        quotient_gcd_uncertainty=quotient_gcd_uncertainty,
        claim_scope=claim_scope,
    )
    normalized["bounded_admissible_minor_normalization_blocker_witness_summary"] = (
        summary
    )
    if blockers:
        details[
            "bounded_admissible_minor_normalization_blocker_witness_summary"
        ] = summary
        normalized[details_key] = details
    return normalized


def _full_alexander_completion_blocker_summary(
    *,
    full_admissible_minor_normalization_certified: bool,
    full_invariant_certified: bool,
    claim_scope: str,
    bounded_admissible_minor_normalization_blocker_witness_summary: (
        dict | None
    ) = None,
) -> dict:
    blockers: list[str] = []
    details: dict[str, object] = {}

    def add_blocker(code: str, detail: object | None = None) -> None:
        blockers.append(code)
        if detail is not None:
            details[code] = detail

    if not full_admissible_minor_normalization_certified:
        admissible_detail = {
            "full_admissible_minor_normalization_certified": False,
            "claim_scope": claim_scope,
        }
        if isinstance(
            bounded_admissible_minor_normalization_blocker_witness_summary,
            dict,
        ):
            admissible_detail[
                "bounded_admissible_minor_normalization_blocker_witness_summary"
            ] = bounded_admissible_minor_normalization_blocker_witness_summary
        add_blocker(
            "full_admissible_minor_normalization_not_certified",
            admissible_detail,
        )
    if not full_invariant_certified:
        add_blocker(
            "full_varied_polynomial_gcd_not_certified",
            {"claim_scope": claim_scope},
        )
        add_blocker(
            "full_invariant_not_certified",
            {
                "full_invariant_certified": False,
                "claim_scope": claim_scope,
            },
        )

    return _blocker_summary("full_alexander_completion", blockers, details)


def _input_certification_blocker_summary(
    scanned_gcd_audit: dict | None,
    summary: dict,
) -> dict:
    blockers: list[str] = []
    details: dict[str, object] = {}
    claim_scope = "exact_scanned_fox_minor_gcd_for_one_signed_pd_input"
    quotient_uncertainty: dict | None = None

    def add_blocker(code: str, detail: object | None = None) -> None:
        blockers.append(code)
        if detail is not None:
            details[code] = detail

    if not isinstance(scanned_gcd_audit, dict):
        add_blocker("scanned_gcd_audit_missing")
        return _with_bounded_admissible_minor_normalization_blocker_witness_summary(
            _blocker_summary("certification", blockers, details),
            prefix="certification",
            scanned_gcd_audit=scanned_gcd_audit,
            claim_scope=claim_scope,
        )

    skipped = bool(scanned_gcd_audit.get("skipped", False))
    if skipped:
        add_blocker(
            "scanned_gcd_audit_skipped",
            {"source_method": scanned_gcd_audit.get("source_method")},
        )
    if not bool(scanned_gcd_audit.get("candidate_is_exact_scanned_gcd", False)):
        add_blocker("candidate_not_exact_scanned_gcd")

    failed_nonzero_minor_count = _blocker_int(
        scanned_gcd_audit.get("failed_nonzero_minor_count", 0)
    )
    if failed_nonzero_minor_count:
        failed_witness_fields = _division_failure_witness_fields_from_audit(
            scanned_gcd_audit
        )
        add_blocker(
            "failed_nonzero_minor_division",
            {
                "failed_nonzero_minor_count": failed_nonzero_minor_count,
                "failed_minor_indices": list(
                    scanned_gcd_audit.get("failed_minor_indices", [])
                ),
                **failed_witness_fields,
            },
        )

    if not bool(scanned_gcd_audit.get("quotient_gcd_certified", False)):
        quotient_uncertainty = _quotient_gcd_uncertainty_evidence_from_audit(
            scanned_gcd_audit
        )
        add_blocker(
            "quotient_gcd_uncertified",
            {
                "quotient_gcd_polynomial": scanned_gcd_audit.get(
                    "quotient_gcd_polynomial"
                ),
                "quotient_gcd_method": scanned_gcd_audit.get(
                    "quotient_gcd_method"
                ),
                "quotient_gcd_uncertainty_present": (
                    quotient_uncertainty is not None
                ),
                "quotient_gcd_uncertainty_evidence": quotient_uncertainty,
            },
        )

    if not bool(scanned_gcd_audit.get("complete_combination_scan", False)):
        add_blocker(
            "complete_combination_scan_incomplete",
            {
                "expected_combination_count": _blocker_int(
                    summary.get("expected_combination_count", 0)
                ),
                "scanned_minor_count": _blocker_int(
                    summary.get("scanned_minor_count", 0)
                ),
            },
        )

    if bool(scanned_gcd_audit.get("truncated", False)):
        add_blocker(
            "square_minor_scan_truncated",
            {
                "expected_combination_count": _blocker_int(
                    summary.get("expected_combination_count", 0)
                ),
                "scanned_minor_count": _blocker_int(
                    summary.get("scanned_minor_count", 0)
                ),
            },
        )

    if not bool(summary.get("nonzero_minor_coverage_complete", False)):
        add_blocker(
            "nonzero_minor_coverage_incomplete",
            {
                "all_rows_have_nonzero_minor": bool(
                    summary.get("all_rows_have_nonzero_minor", False)
                ),
                "all_columns_have_nonzero_minor": bool(
                    summary.get("all_columns_have_nonzero_minor", False)
                ),
            },
        )

    return _with_bounded_admissible_minor_normalization_blocker_witness_summary(
        _blocker_summary("certification", blockers, details),
        prefix="certification",
        scanned_gcd_audit=scanned_gcd_audit,
        quotient_gcd_uncertainty=quotient_uncertainty,
        claim_scope=claim_scope,
    )


def _admissible_minor_normalization_blocker_summary(
    *,
    scan_missing: bool = False,
    scan_skipped: bool = False,
    variables_missing: bool = False,
    checked_nonzero_minor_count: int = 0,
    failed_minor_indices: Sequence[int] = (),
    normalization_class_count: int = 0,
    largest_normalization_class_minor_count: int = 0,
    representative_normalization_class_minor_count: int = 0,
    nonrepresentative_normalization_class_count: int = 0,
    normalization_class_witnesses: Sequence[dict] = (),
    normalization_mismatch_witness_count: int = 0,
    normalization_mismatch_witness_limit: int = (
        _ADMISSIBLE_MINOR_NORMALIZATION_MISMATCH_WITNESS_LIMIT
    ),
    normalization_mismatch_witness_truncated: bool = False,
    complete_combination_scan: bool = False,
    truncated: bool = False,
    nonzero_minor_coverage_complete: bool = False,
    expected_combination_count: int = 0,
    scanned_minor_count: int = 0,
    all_rows_have_nonzero_minor: bool = False,
    all_columns_have_nonzero_minor: bool = False,
    normalization_audit: dict | None = None,
    claim_scope: str = (
        "bounded_scanned_fox_admissible_minor_laurent_unit_normalization"
    ),
) -> dict:
    blockers: list[str] = []
    details: dict[str, object] = {}

    def add_blocker(code: str, detail: object | None = None) -> None:
        blockers.append(code)
        if detail is not None:
            details[code] = detail

    if scan_missing:
        add_blocker("square_minor_scan_missing")
        return _with_bounded_admissible_minor_normalization_blocker_witness_summary(
            _blocker_summary(
                "admissible_minor_normalization",
                blockers,
                details,
            ),
            prefix="admissible_minor_normalization",
            normalization_audit=normalization_audit,
            claim_scope=claim_scope,
        )
    if scan_skipped:
        add_blocker("square_minor_scan_skipped")
    if variables_missing:
        add_blocker("variable_names_missing")

    if checked_nonzero_minor_count <= 0 and not (scan_skipped or variables_missing):
        add_blocker("nonzero_admissible_minor_missing")

    failed_indices = [int(index) for index in failed_minor_indices]
    if failed_indices:
        add_blocker(
            "failed_nonzero_minor_normalization",
            {
                "failed_nonzero_minor_count": len(failed_indices),
                "failed_minor_indices": failed_indices,
            },
        )

    if checked_nonzero_minor_count > 0 and normalization_class_count != 1:
        normalization_class_witness_list = _dict_sequence(
            normalization_class_witnesses
        )
        add_blocker(
            "normalization_class_not_unique",
            {
                "normalization_class_count": normalization_class_count,
                "largest_normalization_class_minor_count": (
                    largest_normalization_class_minor_count
                ),
                "representative_normalization_class_minor_count": (
                    representative_normalization_class_minor_count
                ),
                "nonrepresentative_normalization_class_count": (
                    nonrepresentative_normalization_class_count
                ),
                "normalization_class_witness_count": len(
                    normalization_class_witness_list
                ),
                "normalization_class_witnesses": normalization_class_witness_list,
            },
        )

    if normalization_mismatch_witness_count:
        add_blocker(
            "normalization_mismatch_witnesses_present",
            {
                "normalization_mismatch_witness_count": (
                    normalization_mismatch_witness_count
                ),
                "normalization_mismatch_witness_limit": (
                    normalization_mismatch_witness_limit
                ),
                "normalization_mismatch_witness_truncated": (
                    normalization_mismatch_witness_truncated
                ),
            },
        )

    if not complete_combination_scan:
        add_blocker(
            "complete_combination_scan_incomplete",
            {
                "expected_combination_count": expected_combination_count,
                "scanned_minor_count": scanned_minor_count,
            },
        )
    if truncated:
        add_blocker(
            "square_minor_scan_truncated",
            {
                "expected_combination_count": expected_combination_count,
                "scanned_minor_count": scanned_minor_count,
            },
        )
    if not nonzero_minor_coverage_complete:
        add_blocker(
            "nonzero_minor_coverage_incomplete",
            {
                "all_rows_have_nonzero_minor": all_rows_have_nonzero_minor,
                "all_columns_have_nonzero_minor": all_columns_have_nonzero_minor,
            },
        )

    return _with_bounded_admissible_minor_normalization_blocker_witness_summary(
        _blocker_summary(
            "admissible_minor_normalization",
            blockers,
            details,
        ),
        prefix="admissible_minor_normalization",
        normalization_audit=normalization_audit,
        claim_scope=claim_scope,
    )


@dataclass(frozen=True)
class WirtingerPresentation:
    relations: tuple[tuple[tuple[int, int], ...], ...]
    generator_components: tuple[int, ...]
    variables: tuple[str, ...]
    source: str = "explicit_oriented_crossing_records"
    convention: str = "over^sign under_in over^-sign under_out^-1 = 1"

    def to_dict(self) -> dict:
        return {
            "relations": [
                [[generator, exponent] for generator, exponent in relation]
                for relation in self.relations
            ],
            "generator_components": list(self.generator_components),
            "variables": list(self.variables),
            "source": self.source,
            "convention": self.convention,
        }


def multivariable_alexander_for_link(link_type: str) -> dict:
    entry = lookup_link(link_type=link_type)
    if entry is not None and entry.multivariable_alexander_polynomial is not None:
        return {
            "multivariable_alexander_polynomial": (
                entry.multivariable_alexander_polynomial
            ),
            "method": "built_in_link_table",
            "table_match": entry.to_dict(),
            "skipped": False,
            "notes": [],
        }
    return {
        "multivariable_alexander_polynomial": None,
        "method": "skipped",
        "table_match": entry.to_dict() if entry is not None else None,
        "skipped": True,
        "notes": [
            "multi-variable Alexander polynomial requires a table entry or future Fox-calculus implementation",
        ],
    }


def multivariable_alexander_fixture_comparison(
    notation: str,
    *,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    """Compare signed-PD Alexander output against a standard fixture value."""

    from iroll.topology.pd_fixtures import get_diagram_fixture

    fixture = get_diagram_fixture(notation)
    fixture_payload = fixture.to_dict()
    expected = fixture.expected_multivariable_alexander
    variables = _fixture_alexander_variables(fixture)
    base_payload = {
        "method": "multivariable_alexander_fixture_comparison",
        "notation": fixture.notation,
        "fixture": fixture_payload,
        "expected_multivariable_alexander": expected,
        "expected_variables": list(variables),
    }
    if not fixture.has_signed_pd:
        source_orientation_diagnostics = _fixture_source_orientation_diagnostics(
            fixture,
        )
        source_pairwise_candidate_diagnostics = (
            fixture.source_pairwise_candidate_diagnostics(
                max_orientation_samples=64,
                max_candidates=8,
            )
        )
        return {
            **base_payload,
            "observed_multivariable_alexander": None,
            "matched": False,
            "skipped": True,
            "result": None,
            "source_orientation_diagnostics": source_orientation_diagnostics,
            "source_pairwise_candidate_diagnostics": (
                source_pairwise_candidate_diagnostics
            ),
            "notes": [
                "fixture does not have a signed-PD diagram",
                *source_orientation_diagnostics["notes"],
                *source_pairwise_candidate_diagnostics["notes"],
            ],
        }

    result = multivariable_alexander_from_pd(
        fixture.diagram(),
        orientation=fixture.orientation(),
        variables=variables,
        max_matrix_size=max_matrix_size,
        max_minors=max_minors,
    )
    observed = result["multivariable_alexander_polynomial"]
    if expected is None:
        return {
            **base_payload,
            "observed_multivariable_alexander": observed,
            "matched": False,
            "skipped": True,
            "result": result,
            "notes": [
                "fixture does not yet register an expected multi-variable Alexander polynomial",
                "algorithmic result is reported only as convention diagnostic metadata",
            ],
        }

    matched = not result["skipped"] and observed == expected
    return {
        **base_payload,
        "observed_multivariable_alexander": observed,
        "matched": matched,
        "skipped": result["skipped"],
        "result": result,
        "notes": []
        if matched
        else [
            "algorithmic multi-variable Alexander result does not match the registered fixture value",
        ],
    }


def _bounded_alexander_maturity_path(
    *,
    source_table_diagnostic_only: bool = False,
    zero_crossing_unlink_certified: bool = False,
    bounded_admissible_minor_normalization_certified: bool = False,
    all_nonzero_minors_laurent_unit_equivalent: bool = False,
    complete_scanned_gcd_certified: bool = False,
    bounded_scanned_gcd_certified: bool = False,
    candidate_is_exact_scanned_gcd: bool = False,
    quotient_gcd_certified: bool = False,
) -> str:
    if source_table_diagnostic_only:
        return _ALEXANDER_MATURITY_SOURCE_TABLE_DIAGNOSTIC
    if zero_crossing_unlink_certified:
        return _ALEXANDER_MATURITY_ZERO_CROSSING_UNLINK
    if (
        bounded_admissible_minor_normalization_certified
        and all_nonzero_minors_laurent_unit_equivalent
    ):
        return _ALEXANDER_MATURITY_LAURENT_UNIT_CONSENSUS
    if (
        complete_scanned_gcd_certified
        or bounded_scanned_gcd_certified
        or candidate_is_exact_scanned_gcd
    ):
        return _ALEXANDER_MATURITY_EXACT_SCANNED_GCD
    if quotient_gcd_certified:
        return _ALEXANDER_MATURITY_GENERAL_GCD_WITHOUT_UNIT_CONSENSUS
    return _ALEXANDER_MATURITY_NOT_CERTIFIED


def _bounded_alexander_maturity_path_certified(path: str) -> bool:
    return path in _ALEXANDER_MATURITY_CERTIFIED_PATHS

def multivariable_alexander_input_certification_evidence(
    scanned_gcd_audit: dict | None,
    wirtinger_fox_audit: dict | None = None,
    admissible_minor_normalization_audit: dict | None = None,
) -> dict:
    """Summarize bounded scanned-gcd evidence from an existing audit payload.

    This helper does not run Fox calculus. It gives report/UI consumers a stable
    shape for the current input-level evidence while keeping the boundary clear:
    scanned-minor gcd certification is not full admissible-minor normalization
    and not a complete multi-variable Alexander invariant certificate.
    """

    if scanned_gcd_audit is None:
        certification_blockers = _input_certification_blocker_summary(None, {})
        admissible_normalization_blockers = _with_bounded_admissible_minor_normalization_blocker_witness_summary(
            _blocker_summary("admissible_minor_normalization", []),
            prefix="admissible_minor_normalization",
            claim_scope="exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        )
        bounded_blocker_witness_summary = (
            certification_blockers[
                "bounded_admissible_minor_normalization_blocker_witness_summary"
            ]
        )
        gate_summary = _bounded_admissible_minor_normalization_gate_summary(
            claim_scope="exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
            blockers=certification_blockers.get("certification_blockers", []),
            blocker_witness_summary=bounded_blocker_witness_summary,
            include_scanned_gcd_gates=True,
            scanned_gcd_audit_missing=True,
            include_normalization_gates=False,
            complete_combination_scan=False,
            truncated=False,
            all_rows_have_nonzero_minor=False,
            all_columns_have_nonzero_minor=False,
            bounded_admissible_minor_normalization_certified=False,
        )
        return {
            "method": "multivariable_alexander_input_certification_evidence",
            "claim_scope": "exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
            "source_method": None,
            "multivariable_alexander_polynomial": None,
            "variables": [],
            "candidate_polynomials": [],
            "bounded_alexander_maturity_path": _ALEXANDER_MATURITY_NOT_CERTIFIED,
            "bounded_alexander_maturity_path_certified": False,
            "bounded_scanned_gcd_certified": False,
            "candidate_is_exact_scanned_gcd": False,
            "complete_scanned_gcd_certified": False,
            "quotient_gcd_certified": False,
            "quotient_gcd_polynomial": None,
            "quotient_gcd_method": None,
            "quotient_gcd_uncertainty_present": False,
            "quotient_gcd_uncertainty_evidence": None,
            "improved_candidate_polynomial": None,
            "source_common_gcd_evidence": None,
            "scanned_gcd_improvement_evidence": None,
            "scanned_gcd_promoted_candidate": False,
            "scanned_gcd_promoted_candidate_count": 0,
            "common_gcd_attempt_evidence": None,
            "admissible_minor_normalization_evidence": None,
            "bounded_admissible_minor_normalization_certified": False,
            "all_nonzero_minors_laurent_unit_equivalent": False,
            "admissible_minor_normalized_representative_polynomial": None,
            "admissible_minor_normalization_checked_nonzero_minor_count": 0,
            "admissible_minor_normalization_failed_nonzero_minor_count": 0,
            "admissible_minor_normalization_class_count": 0,
            "admissible_minor_normalization_largest_class_minor_count": 0,
            "admissible_minor_normalization_representative_class_minor_count": 0,
            "admissible_minor_normalization_nonrepresentative_class_count": 0,
            "admissible_minor_normalization_representative_witness": None,
            "admissible_minor_normalization_mismatch_witness_count": 0,
            "admissible_minor_normalization_mismatch_witness_limit": (
                _ADMISSIBLE_MINOR_NORMALIZATION_MISMATCH_WITNESS_LIMIT
            ),
            "admissible_minor_normalization_mismatch_witness_truncated": False,
            "admissible_minor_normalization_mismatch_witnesses": [],
            "admissible_minor_normalization_mismatch_witness_consistency": (
                _bounded_witness_consistency_summary(
                    witness_kind="normalization_mismatch",
                    witness_count=0,
                    witness_limit=(
                        _ADMISSIBLE_MINOR_NORMALIZATION_MISMATCH_WITNESS_LIMIT
                    ),
                    witness_truncated=False,
                    witnesses=[],
                )
            ),
            "checked_nonzero_minor_count": 0,
            "failed_nonzero_minor_count": 0,
            **_empty_division_failure_witness_fields(),
            "failed_minor_count": 0,
            "division_record_count": 0,
            "expected_combination_count": 0,
            "scanned_minor_count": 0,
            "nonzero_minor_count": 0,
            "zero_minor_count": 0,
            "unit_minor_count": 0,
            "unique_nonzero_polynomial_count": 0,
            "all_rows_have_nonzero_minor": False,
            "all_columns_have_nonzero_minor": False,
            "nonzero_minor_coverage_complete": False,
            "wirtinger_fox_input_chain_consistent": False,
            "wirtinger_presentation_valid": False,
            "fox_jacobian_valid": False,
            "fox_square_minor_scan_valid": False,
            "wirtinger_relation_count": 0,
            "wirtinger_generator_count": 0,
            "fox_jacobian_row_count": 0,
            "fox_jacobian_column_count": 0,
            "fox_square_minor_invalid_reference_count": 0,
            "fox_square_minor_invalid_normalization_count": 0,
            **_fox_square_minor_validation_witness_evidence_fields(None),
            "complete_combination_scan": False,
            "truncated": False,
            "full_admissible_minor_normalization_certified": False,
            "full_invariant_certified": False,
            **certification_blockers,
            **admissible_normalization_blockers,
            "bounded_admissible_minor_normalization_blocker_witness_summary": (
                bounded_blocker_witness_summary
            ),
            "bounded_admissible_minor_normalization_gate_summary": gate_summary,
            **_full_alexander_completion_blocker_summary(
                full_admissible_minor_normalization_certified=False,
                full_invariant_certified=False,
                claim_scope="exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
                bounded_admissible_minor_normalization_blocker_witness_summary=(
                    bounded_blocker_witness_summary
                ),
            ),
            "skipped": True,
            "notes": ["no scanned-gcd audit supplied"],
        }

    summary = scanned_gcd_audit.get("admissible_minor_summary")
    if not isinstance(summary, dict):
        summary = {}
    division_records = list(scanned_gcd_audit.get("division_records", []))
    failed_minor_indices = list(scanned_gcd_audit.get("failed_minor_indices", []))
    failed_division_witness_fields = _division_failure_witness_fields_from_audit(
        scanned_gcd_audit
    )
    quotient_gcd_uncertainty = _quotient_gcd_uncertainty_evidence_from_audit(
        scanned_gcd_audit
    )
    candidate_is_exact_scanned_gcd = bool(
        scanned_gcd_audit.get("candidate_is_exact_scanned_gcd", False)
    )
    skipped = bool(scanned_gcd_audit.get("skipped", False))
    complete_scanned_gcd_certified = bool(
        scanned_gcd_audit.get("complete_scanned_gcd_certified", False)
    )
    scanned_gcd_improvement_evidence = (
        scanned_gcd_audit.get("scanned_gcd_improvement_evidence")
        if isinstance(scanned_gcd_audit.get("scanned_gcd_improvement_evidence"), dict)
        else None
    )
    scanned_gcd_promoted_candidate = scanned_gcd_improvement_evidence is not None
    notes = [str(note) for note in scanned_gcd_audit.get("notes", [])]
    if scanned_gcd_promoted_candidate:
        notes.append(
            "scanned-gcd promotion evidence was preserved from the bounded gcd main path"
        )
    notes.append(
        "input evidence is limited to the scanned Fox-minor set and does not certify full admissible-minor normalization"
    )
    wirtinger_fox = _wirtinger_fox_evidence_fields(wirtinger_fox_audit)
    normalization = (
        admissible_minor_normalization_audit
        if isinstance(admissible_minor_normalization_audit, dict)
        else None
    )
    bounded_normalization_certified = bool(
        normalization
        and normalization.get(
            "bounded_admissible_minor_normalization_certified",
            False,
        )
    )
    all_minors_laurent_unit_equivalent = bool(
        normalization
        and normalization.get(
            "all_nonzero_minors_laurent_unit_equivalent",
            False,
        )
    )
    normalized_representative = (
        normalization.get("normalized_representative_polynomial")
        if normalization is not None
        else None
    )
    normalization_checked = int(
        normalization.get("checked_nonzero_minor_count", 0) or 0
    ) if normalization is not None else 0
    normalization_failed_indices = (
        _int_sequence(normalization.get("failed_minor_indices", []))
        if normalization is not None
        else []
    )
    normalization_failed = (
        len(normalization_failed_indices)
        if normalization_failed_indices
        else _blocker_int(normalization.get("failed_nonzero_minor_count", 0))
    ) if normalization is not None else 0
    normalization_class_count = int(
        normalization.get("normalization_class_count", 0) or 0
    ) if normalization is not None else 0
    normalization_largest_class = int(
        normalization.get("largest_normalization_class_minor_count", 0) or 0
    ) if normalization is not None else 0
    normalization_representative_class = int(
        normalization.get("representative_normalization_class_minor_count", 0) or 0
    ) if normalization is not None else 0
    normalization_nonrepresentative_class = int(
        normalization.get("nonrepresentative_normalization_class_count", 0) or 0
    ) if normalization is not None else 0
    normalization_representative_witness = (
        normalization.get("normalization_representative_witness")
        if normalization is not None
        else None
    )
    normalization_mismatch_witness_fields = (
        _normalization_mismatch_witness_fields_from_audit(normalization)
        if normalization is not None
        else {
            "normalization_mismatch_witness_count": 0,
            "normalization_mismatch_witness_limit": (
                _ADMISSIBLE_MINOR_NORMALIZATION_MISMATCH_WITNESS_LIMIT
            ),
            "normalization_mismatch_witness_truncated": False,
            "normalization_mismatch_witnesses": [],
            "normalization_mismatch_witness_consistency": (
                _bounded_witness_consistency_summary(
                    witness_kind="normalization_mismatch",
                    witness_count=0,
                    witness_limit=(
                        _ADMISSIBLE_MINOR_NORMALIZATION_MISMATCH_WITNESS_LIMIT
                    ),
                    witness_truncated=False,
                    witnesses=[],
                )
            ),
        }
    )
    normalization_mismatch_witness_count = _blocker_int(
        normalization_mismatch_witness_fields.get(
            "normalization_mismatch_witness_count",
            0,
        )
    )
    normalization_mismatch_witness_limit = _blocker_int(
        normalization_mismatch_witness_fields.get(
            "normalization_mismatch_witness_limit",
            _ADMISSIBLE_MINOR_NORMALIZATION_MISMATCH_WITNESS_LIMIT,
        ),
        fallback=_ADMISSIBLE_MINOR_NORMALIZATION_MISMATCH_WITNESS_LIMIT,
    )
    normalization_mismatch_witness_truncated = bool(
        normalization_mismatch_witness_fields.get(
            "normalization_mismatch_witness_truncated",
            False,
        )
    )
    normalization_mismatch_witnesses = _dict_sequence(
        normalization_mismatch_witness_fields.get(
            "normalization_mismatch_witnesses",
            [],
        )
    )
    normalization_mismatch_witness_consistency = (
        normalization_mismatch_witness_fields.get(
            "normalization_mismatch_witness_consistency"
        )
    )
    if not isinstance(normalization_mismatch_witness_consistency, dict):
        normalization_mismatch_witness_consistency = (
            _bounded_witness_consistency_summary(
                witness_kind="normalization_mismatch",
                witness_count=normalization_mismatch_witness_count,
                witness_limit=normalization_mismatch_witness_limit,
                witness_truncated=normalization_mismatch_witness_truncated,
                witnesses=normalization_mismatch_witnesses,
            )
        )
    if normalization is not None:
        notes.append(
            "bounded admissible-minor normalization audit is attached as scanned-minor evidence only"
        )
    if normalization is None:
        normalization_blockers = _with_bounded_admissible_minor_normalization_blocker_witness_summary(
            _blocker_summary(
                "admissible_minor_normalization",
                [],
            ),
            prefix="admissible_minor_normalization",
            claim_scope="exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        )
    elif isinstance(
        normalization.get("admissible_minor_normalization_blockers"),
        list,
    ):
        normalization_blockers = (
            _with_bounded_admissible_minor_normalization_blocker_witness_summary(
                _blocker_summary(
                    "admissible_minor_normalization",
                    [
                        str(blocker)
                        for blocker in normalization.get(
                            "admissible_minor_normalization_blockers",
                            [],
                        )
                    ],
                    _admissible_minor_normalization_blocker_details(
                        normalization.get(
                            "admissible_minor_normalization_blocker_details"
                        ),
                        normalization_audit=normalization,
                        normalization_mismatch_witness_fields=(
                            normalization_mismatch_witness_fields
                        ),
                    ),
                ),
                prefix="admissible_minor_normalization",
                normalization_audit=normalization,
                claim_scope="exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
            )
        )
    else:
        normalization_blockers = _admissible_minor_normalization_blocker_summary(
            scan_missing=False,
            scan_skipped=bool(normalization.get("skipped", False)),
            variables_missing=not bool(normalization.get("variables", [])),
            checked_nonzero_minor_count=normalization_checked,
            failed_minor_indices=normalization_failed_indices,
            normalization_class_count=normalization_class_count,
            largest_normalization_class_minor_count=normalization_largest_class,
            representative_normalization_class_minor_count=(
                normalization_representative_class
            ),
            nonrepresentative_normalization_class_count=(
                normalization_nonrepresentative_class
            ),
            normalization_class_witnesses=_dict_sequence(
                normalization.get("normalization_class_counts", [])
            ),
            normalization_mismatch_witness_count=(
                normalization_mismatch_witness_count
            ),
            normalization_mismatch_witness_limit=(
                normalization_mismatch_witness_limit
            ),
            normalization_mismatch_witness_truncated=(
                normalization_mismatch_witness_truncated
            ),
            complete_combination_scan=bool(
                normalization.get("complete_combination_scan", False)
            ),
            truncated=bool(normalization.get("truncated", False)),
            nonzero_minor_coverage_complete=bool(
                normalization.get("nonzero_minor_coverage_complete", False)
            ),
            expected_combination_count=_blocker_int(
                normalization.get("expected_combination_count", 0)
            ),
            scanned_minor_count=_blocker_int(
                normalization.get("scanned_minor_count", 0)
            ),
            all_rows_have_nonzero_minor=bool(
                normalization.get("all_rows_have_nonzero_minor", False)
            ),
            all_columns_have_nonzero_minor=bool(
                normalization.get("all_columns_have_nonzero_minor", False)
            ),
            normalization_audit=normalization,
            claim_scope="exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        )
    full_admissible_minor_normalization_certified = False
    full_invariant_certified = False
    certification_blockers = _input_certification_blocker_summary(
        scanned_gcd_audit,
        summary,
    )
    combined_blockers = [
        *certification_blockers.get("certification_blockers", []),
        *normalization_blockers.get(
            "admissible_minor_normalization_blockers",
            [],
        ),
    ]
    normalization_blocker_codes = [
        str(blocker)
        for blocker in normalization_blockers.get(
            "admissible_minor_normalization_blockers",
            [],
        )
    ]
    combined_details = {
        **(
            certification_blockers.get("certification_blocker_details", {})
            if isinstance(
                certification_blockers.get("certification_blocker_details", {}),
                dict,
            )
            else {}
        ),
        **(
            normalization_blockers.get(
                "admissible_minor_normalization_blocker_details",
                {},
            )
            if isinstance(
                normalization_blockers.get(
                    "admissible_minor_normalization_blocker_details",
                    {},
                ),
                dict,
            )
            else {}
        ),
    }
    bounded_blocker_witness_summary = (
        _bounded_admissible_minor_normalization_blocker_witness_summary(
            combined_blockers,
            combined_details,
            normalization_audit=normalization,
            scanned_gcd_audit=scanned_gcd_audit,
            quotient_gcd_uncertainty=quotient_gcd_uncertainty,
            claim_scope="exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        )
    )
    gate_summary = _bounded_admissible_minor_normalization_gate_summary(
        claim_scope="exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        blockers=combined_blockers,
        blocker_witness_summary=bounded_blocker_witness_summary,
        include_scanned_gcd_gates=True,
        scanned_gcd_audit_skipped=skipped,
        candidate_is_exact_scanned_gcd=candidate_is_exact_scanned_gcd,
        quotient_gcd_certified=bool(
            scanned_gcd_audit.get("quotient_gcd_certified", False)
        ),
        include_normalization_gates=normalization is not None,
        scan_missing="square_minor_scan_missing" in normalization_blocker_codes,
        scan_skipped="square_minor_scan_skipped" in normalization_blocker_codes
        if normalization is not None
        else False,
        variables_missing=not bool(normalization.get("variables", []))
        if normalization is not None
        else False,
        checked_nonzero_minor_count=normalization_checked,
        failed_minor_indices=normalization_failed_indices,
        normalization_class_count=normalization_class_count,
        normalization_mismatch_witness_count=normalization_mismatch_witness_count,
        all_nonzero_minors_laurent_unit_equivalent=(
            all_minors_laurent_unit_equivalent
        ),
        complete_combination_scan=bool(
            scanned_gcd_audit.get("complete_combination_scan", False)
        ),
        truncated=bool(scanned_gcd_audit.get("truncated", False)),
        all_rows_have_nonzero_minor=bool(
            summary.get("all_rows_have_nonzero_minor", False)
        ),
        all_columns_have_nonzero_minor=bool(
            summary.get("all_columns_have_nonzero_minor", False)
        ),
        bounded_admissible_minor_normalization_certified=(
            bounded_normalization_certified
        ),
    )
    bounded_scanned_gcd_certified = bool(
        not skipped and candidate_is_exact_scanned_gcd
    )
    bounded_alexander_maturity_path = _bounded_alexander_maturity_path(
        bounded_admissible_minor_normalization_certified=(
            bounded_normalization_certified
        ),
        all_nonzero_minors_laurent_unit_equivalent=(
            all_minors_laurent_unit_equivalent
        ),
        complete_scanned_gcd_certified=complete_scanned_gcd_certified,
        bounded_scanned_gcd_certified=bounded_scanned_gcd_certified,
        candidate_is_exact_scanned_gcd=candidate_is_exact_scanned_gcd,
        quotient_gcd_certified=bool(
            scanned_gcd_audit.get("quotient_gcd_certified", False)
        ),
    )

    return {
        "method": "multivariable_alexander_input_certification_evidence",
        "claim_scope": "exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        "source_method": scanned_gcd_audit.get("source_method"),
        "multivariable_alexander_polynomial": scanned_gcd_audit.get(
            "multivariable_alexander_polynomial"
        ),
        "variables": list(scanned_gcd_audit.get("variables", [])),
        "candidate_polynomials": list(
            scanned_gcd_audit.get("candidate_polynomials", [])
        ),
        "bounded_alexander_maturity_path": bounded_alexander_maturity_path,
        "bounded_alexander_maturity_path_certified": (
            _bounded_alexander_maturity_path_certified(
                bounded_alexander_maturity_path
            )
        ),
        "bounded_scanned_gcd_certified": bounded_scanned_gcd_certified,
        "candidate_is_exact_scanned_gcd": candidate_is_exact_scanned_gcd,
        "complete_scanned_gcd_certified": complete_scanned_gcd_certified,
        "quotient_gcd_certified": bool(
            scanned_gcd_audit.get("quotient_gcd_certified", False)
        ),
        "quotient_gcd_polynomial": scanned_gcd_audit.get(
            "quotient_gcd_polynomial"
        ),
        "quotient_gcd_method": scanned_gcd_audit.get("quotient_gcd_method"),
        "quotient_gcd_uncertainty_present": quotient_gcd_uncertainty is not None,
        "quotient_gcd_uncertainty_evidence": quotient_gcd_uncertainty,
        "improved_candidate_polynomial": scanned_gcd_audit.get(
            "improved_candidate_polynomial"
        ),
        "source_common_gcd_evidence": (
            scanned_gcd_audit.get("source_common_gcd_evidence")
            if isinstance(scanned_gcd_audit.get("source_common_gcd_evidence"), dict)
            else None
        ),
        "scanned_gcd_improvement_evidence": scanned_gcd_improvement_evidence,
        "scanned_gcd_promoted_candidate": scanned_gcd_promoted_candidate,
        "scanned_gcd_promoted_candidate_count": (
            1 if scanned_gcd_promoted_candidate else 0
        ),
        "common_gcd_attempt_evidence": (
            scanned_gcd_audit.get("common_gcd_attempt_evidence")
            if isinstance(scanned_gcd_audit.get("common_gcd_attempt_evidence"), dict)
            else None
        ),
        "admissible_minor_normalization_evidence": normalization,
        "bounded_admissible_minor_normalization_certified": (
            bounded_normalization_certified
        ),
        "all_nonzero_minors_laurent_unit_equivalent": (
            all_minors_laurent_unit_equivalent
        ),
        "admissible_minor_normalized_representative_polynomial": (
            normalized_representative
        ),
        "admissible_minor_normalization_checked_nonzero_minor_count": (
            normalization_checked
        ),
        "admissible_minor_normalization_failed_nonzero_minor_count": (
            normalization_failed
        ),
        "admissible_minor_normalization_class_count": (
            normalization_class_count
        ),
        "admissible_minor_normalization_largest_class_minor_count": (
            normalization_largest_class
        ),
        "admissible_minor_normalization_representative_class_minor_count": (
            normalization_representative_class
        ),
        "admissible_minor_normalization_nonrepresentative_class_count": (
            normalization_nonrepresentative_class
        ),
        "admissible_minor_normalization_representative_witness": (
            normalization_representative_witness
        ),
        "admissible_minor_normalization_mismatch_witness_count": (
            normalization_mismatch_witness_count
        ),
        "admissible_minor_normalization_mismatch_witness_limit": (
            normalization_mismatch_witness_limit
        ),
        "admissible_minor_normalization_mismatch_witness_truncated": (
            normalization_mismatch_witness_truncated
        ),
        "admissible_minor_normalization_mismatch_witnesses": (
            normalization_mismatch_witnesses
        ),
        "admissible_minor_normalization_mismatch_witness_consistency": (
            normalization_mismatch_witness_consistency
        ),
        "checked_nonzero_minor_count": int(
            scanned_gcd_audit.get("checked_nonzero_minor_count", 0) or 0
        ),
        "failed_nonzero_minor_count": int(
            scanned_gcd_audit.get("failed_nonzero_minor_count", 0) or 0
        ),
        **failed_division_witness_fields,
        "failed_minor_count": len(failed_minor_indices),
        "division_record_count": len(division_records),
        "expected_combination_count": int(
            summary.get("expected_combination_count", 0) or 0
        ),
        "scanned_minor_count": int(summary.get("scanned_minor_count", 0) or 0),
        "nonzero_minor_count": int(summary.get("nonzero_minor_count", 0) or 0),
        "zero_minor_count": int(summary.get("zero_minor_count", 0) or 0),
        "unit_minor_count": int(summary.get("unit_minor_count", 0) or 0),
        "unique_nonzero_polynomial_count": int(
            summary.get("unique_nonzero_polynomial_count", 0) or 0
        ),
        "all_rows_have_nonzero_minor": bool(
            summary.get("all_rows_have_nonzero_minor", False)
        ),
        "all_columns_have_nonzero_minor": bool(
            summary.get("all_columns_have_nonzero_minor", False)
        ),
        "nonzero_minor_coverage_complete": bool(
            summary.get("nonzero_minor_coverage_complete", False)
        ),
        **wirtinger_fox,
        "complete_combination_scan": bool(
            scanned_gcd_audit.get("complete_combination_scan", False)
        ),
        "truncated": bool(scanned_gcd_audit.get("truncated", False)),
        "full_admissible_minor_normalization_certified": (
            full_admissible_minor_normalization_certified
        ),
        "full_invariant_certified": full_invariant_certified,
        **certification_blockers,
        **normalization_blockers,
        "bounded_admissible_minor_normalization_blocker_witness_summary": (
            bounded_blocker_witness_summary
        ),
        "bounded_admissible_minor_normalization_gate_summary": gate_summary,
        **_full_alexander_completion_blocker_summary(
            full_admissible_minor_normalization_certified=(
                full_admissible_minor_normalization_certified
            ),
            full_invariant_certified=full_invariant_certified,
            claim_scope="exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
            bounded_admissible_minor_normalization_blocker_witness_summary=(
                bounded_blocker_witness_summary
            ),
        ),
        "skipped": skipped,
        "notes": notes,
    }



def multivariable_alexander_wirtinger_fox_audit(result: dict | None) -> dict:
    """Validate the generated Wirtinger presentation and Fox-matrix bridge.

    The audit is intentionally input-scoped: it proves that one result payload's
    presentation, Fox Jacobian dimensions, and scanned minor references are
    internally consistent. It does not prove full admissible-minor normalization
    or a complete multi-variable Alexander invariant.
    """

    base_payload = {
        "method": "multivariable_alexander_wirtinger_fox_audit",
        "claim_scope": "input_wirtinger_presentation_and_fox_matrix_consistency",
        "source_method": result.get("method") if isinstance(result, dict) else None,
        "presentation_valid": False,
        "presentation_source": None,
        "presentation_convention": (
            "Wirtinger relation over^sign under_in over^-sign under_out^-1"
        ),
        "wirtinger_relation_shape_valid": False,
        "wirtinger_relation_shape_invalid_count": 0,
        "wirtinger_relation_shape_witnesses": [],
        "wirtinger_generator_component_coverage_complete": False,
        "wirtinger_generator_component_counts": [],
        "fox_jacobian_valid": False,
        "fox_square_minor_scan_valid": False,
        "input_chain_consistent": False,
        "relation_count": 0,
        "generator_count": 0,
        "variable_count": 0,
        "component_count": 0,
        "jacobian_matrix_size": [0, 0],
        "square_minor_matrix_size": [0, 0],
        "scanned_minor_count": 0,
        "invalid_minor_reference_count": 0,
        "invalid_normalization_count": 0,
        **_empty_fox_minor_validation_witness_fields(),
        "complete_combination_scan": False,
        "truncated": False,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
    }
    if not isinstance(result, dict):
        return {
            **base_payload,
            "skipped": True,
            "notes": ["no Alexander result payload supplied"],
        }

    presentation = result.get("presentation")
    if not isinstance(presentation, dict):
        return {
            **base_payload,
            "skipped": True,
            "notes": ["source Alexander result does not include a Wirtinger presentation"],
        }

    relations, generator_components, variables, presentation_issues = (
        _parse_presentation_payload(presentation)
    )
    relation_count = len(relations)
    generator_count = len(generator_components)
    variable_count = len(variables)
    component_count = max(generator_components) + 1 if generator_components else 0
    presentation_valid = not presentation_issues
    relation_shape = _wirtinger_relation_shape_audit(
        relations,
        generator_components=generator_components,
    )

    jacobian_matrix_size = [0, 0]
    fox_jacobian_valid = False
    jacobian_issues: list[str] = []
    if presentation_valid:
        try:
            matrix = fox_jacobian(
                relations,
                generator_components=generator_components,
                variables=variables,
            )
        except ValueError as exc:
            matrix = []
            jacobian_issues.append(str(exc))
        else:
            row_count = len(matrix)
            column_counts = {len(row) for row in matrix}
            column_count = len(matrix[0]) if matrix else 0
            jacobian_matrix_size = [row_count, column_count]
            if row_count != relation_count:
                jacobian_issues.append("Fox Jacobian row count does not match relation count")
            if column_counts != {generator_count}:
                jacobian_issues.append("Fox Jacobian column count does not match generator count")
            if any(
                entry.variables != variables
                for row in matrix
                for entry in row
            ):
                jacobian_issues.append("Fox Jacobian entry variables do not match presentation variables")
        fox_jacobian_valid = not jacobian_issues

    scan = result.get("square_minors")
    (
        fox_square_minor_scan_valid,
        square_minor_matrix_size,
        scanned_minor_count,
        invalid_minor_reference_count,
        invalid_normalization_count,
        complete_combination_scan,
        truncated,
        scan_issues,
        minor_validation_witness_fields,
    ) = _validate_square_minor_scan_payload(
        scan,
        expected_matrix_size=jacobian_matrix_size,
        variables=variables,
    )

    input_chain_consistent = (
        presentation_valid
        and relation_shape["wirtinger_relation_shape_valid"]
        and relation_shape["wirtinger_generator_component_coverage_complete"]
        and fox_jacobian_valid
        and fox_square_minor_scan_valid
    )
    issues = (
        presentation_issues
        + list(relation_shape["wirtinger_relation_shape_issues"])
        + jacobian_issues
        + scan_issues
    )
    notes = (
        [
            "Wirtinger presentation, Fox Jacobian dimensions, and scanned minor references are internally consistent for this input",
            "this audit does not certify full admissible-minor normalization or complete multi-variable Alexander invariance",
        ]
        if input_chain_consistent
        else [
            *issues,
            "input-level Wirtinger/Fox consistency failed or was incomplete",
            "full admissible-minor normalization and complete invariant certification remain false",
        ]
    )
    return {
        **base_payload,
        "presentation_valid": presentation_valid,
        "presentation_source": str(
            result.get("presentation_source") or "stored_wirtinger_presentation"
        ),
        "presentation_convention": (
            "Wirtinger relation over^sign under_in over^-sign under_out^-1"
        ),
        "wirtinger_relation_shape_valid": relation_shape[
            "wirtinger_relation_shape_valid"
        ],
        "wirtinger_relation_shape_invalid_count": relation_shape[
            "wirtinger_relation_shape_invalid_count"
        ],
        "wirtinger_relation_shape_witnesses": relation_shape[
            "wirtinger_relation_shape_witnesses"
        ],
        "wirtinger_generator_component_coverage_complete": relation_shape[
            "wirtinger_generator_component_coverage_complete"
        ],
        "wirtinger_generator_component_counts": relation_shape[
            "wirtinger_generator_component_counts"
        ],
        "fox_jacobian_valid": fox_jacobian_valid,
        "fox_square_minor_scan_valid": fox_square_minor_scan_valid,
        "input_chain_consistent": input_chain_consistent,
        "relation_count": relation_count,
        "generator_count": generator_count,
        "variable_count": variable_count,
        "component_count": component_count,
        "jacobian_matrix_size": jacobian_matrix_size,
        "square_minor_matrix_size": square_minor_matrix_size,
        "scanned_minor_count": scanned_minor_count,
        "invalid_minor_reference_count": invalid_minor_reference_count,
        "invalid_normalization_count": invalid_normalization_count,
        **minor_validation_witness_fields,
        "complete_combination_scan": complete_combination_scan,
        "truncated": truncated,
        "skipped": False,
        "notes": notes,
    }

def _registered_knot_admissible_normalization_evidence(
    fixture,
    comparison: dict,
    scanned_gcd_audit: dict | None,
    wirtinger_fox_audit: dict | None,
) -> dict:
    """Return scoped admissible-normalization evidence for registered knots.

    This narrows one part of the remaining Alexander work without claiming the
    full link invariant: for one-component registered signed-PD fixtures, a
    complete nonzero-minor scan, exact scanned gcd, Wirtinger/Fox consistency,
    and expected-value match give a fixture-scoped normalization certificate.
    """

    expected = fixture.expected_multivariable_alexander
    variables = _fixture_alexander_variables(fixture)
    observed = comparison.get("observed_multivariable_alexander")
    summary = {}
    if isinstance(scanned_gcd_audit, dict):
        maybe_summary = scanned_gcd_audit.get("admissible_minor_summary")
        if isinstance(maybe_summary, dict):
            summary = maybe_summary

    crossing_count = len(fixture.pd_code or ()) if fixture.pd_code is not None else 0
    applicable = bool(
        fixture.has_signed_pd
        and expected is not None
        and fixture.component_count == 1
        and len(variables) == 1
        and crossing_count > 0
    )
    comparison_matched = bool(
        not comparison.get("skipped", False) and comparison.get("matched", False)
    )
    scanned_gcd_certified = bool(
        isinstance(scanned_gcd_audit, dict)
        and not scanned_gcd_audit.get("skipped", False)
        and scanned_gcd_audit.get("candidate_is_exact_scanned_gcd", False)
    )
    wirtinger_fox_consistent = bool(
        isinstance(wirtinger_fox_audit, dict)
        and not wirtinger_fox_audit.get("skipped", False)
        and wirtinger_fox_audit.get("input_chain_consistent", False)
    )
    complete_combination_scan = bool(
        isinstance(scanned_gcd_audit, dict)
        and scanned_gcd_audit.get("complete_combination_scan", False)
    )
    truncated = bool(
        isinstance(scanned_gcd_audit, dict)
        and scanned_gcd_audit.get("truncated", False)
    )
    nonzero_minor_coverage_complete = bool(
        summary.get("nonzero_minor_coverage_complete", False)
    )
    certified = bool(
        applicable
        and comparison_matched
        and observed == expected
        and scanned_gcd_certified
        and wirtinger_fox_consistent
        and complete_combination_scan
        and not truncated
        and nonzero_minor_coverage_complete
    )

    failed_reasons = []
    if not applicable:
        failed_reasons.append(
            "scope applies only to registered one-component nonzero-crossing signed-PD knot fixtures"
        )
    if applicable and not comparison_matched:
        failed_reasons.append("registered expected value did not match generated output")
    if applicable and not scanned_gcd_certified:
        failed_reasons.append("scanned Fox-minor gcd was not certified")
    if applicable and not wirtinger_fox_consistent:
        failed_reasons.append("Wirtinger/Fox input chain was not certified")
    if applicable and not complete_combination_scan:
        failed_reasons.append("Fox square-minor scan was incomplete")
    if applicable and truncated:
        failed_reasons.append("Fox square-minor scan was truncated")
    if applicable and not nonzero_minor_coverage_complete:
        failed_reasons.append("nonzero scanned minors do not cover every Fox row and column")

    notes = (
        [
            "registered one-component signed-PD knot passed expected-value, complete scanned-gcd, nonzero-minor coverage, and Wirtinger/Fox consistency checks",
            "this is fixture-scoped knot normalization evidence, not full multi-component link admissible-minor normalization",
        ]
        if certified
        else [
            *failed_reasons,
            "full multi-variable Alexander invariant certification remains false",
        ]
    )
    return {
        "method": "registered_knot_admissible_normalization_evidence",
        "claim_scope": "registered_one_component_signed_pd_complete_minor_scan_with_expected_value_match",
        "applicable": applicable,
        "certified": certified,
        "component_count": fixture.component_count,
        "variable_count": len(variables),
        "expected_multivariable_alexander": expected,
        "observed_multivariable_alexander": observed,
        "comparison_matched": comparison_matched,
        "scanned_gcd_certified": scanned_gcd_certified,
        "wirtinger_fox_input_chain_consistent": wirtinger_fox_consistent,
        "complete_combination_scan": complete_combination_scan,
        "nonzero_minor_coverage_complete": nonzero_minor_coverage_complete,
        "truncated": truncated,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "skipped": not applicable,
        "notes": notes,
    }
def _zero_crossing_unlink_normalization_evidence(
    fixture,
    comparison: dict,
) -> dict:
    """Return fixture-scoped evidence for zero-crossing unlink terminals."""

    expected = fixture.expected_multivariable_alexander
    variables = _fixture_alexander_variables(fixture)
    observed = comparison.get("observed_multivariable_alexander")
    result = comparison.get("result")
    result_method = result.get("method") if isinstance(result, dict) else None
    component_count = int(getattr(fixture, "component_count", 0) or 0)
    crossing_count = len(fixture.pd_code or ()) if fixture.pd_code is not None else None
    applicable = bool(
        fixture.has_signed_pd
        and expected is not None
        and crossing_count == 0
        and isinstance(result, dict)
        and result_method == "zero_crossing_unlink_normalization"
    )
    comparison_matched = bool(
        not comparison.get("skipped", False) and comparison.get("matched", False)
    )
    result_certified = bool(
        isinstance(result, dict)
        and not result.get("skipped", False)
        and result.get("zero_crossing_unlink_certified", False)
    )
    certified = bool(
        applicable
        and comparison_matched
        and result_certified
        and observed == expected
    )
    failed_reasons = []
    if not applicable:
        failed_reasons.append(
            "scope applies only to registered signed-PD zero-crossing unlink fixtures"
        )
    if applicable and not comparison_matched:
        failed_reasons.append("registered expected value did not match generated output")
    if applicable and not result_certified:
        failed_reasons.append("zero-crossing unlink result was not certified")

    notes = (
        [
            "registered zero-crossing unlink fixture passed terminal normalization evidence",
            "this bypasses Wirtinger/Fox because zero-crossing diagrams have no arc generators",
            "full admissible-minor normalization and complete invariant certification remain false",
        ]
        if certified
        else [
            *failed_reasons,
            "full multi-variable Alexander invariant certification remains false",
        ]
    )
    bounded_alexander_maturity_path = _bounded_alexander_maturity_path(
        zero_crossing_unlink_certified=certified,
    )
    return {
        "method": "zero_crossing_unlink_normalization_evidence",
        "claim_scope": "registered_zero_crossing_unlink_terminal_normalization",
        "applicable": applicable,
        "certified": certified,
        "component_count": component_count,
        "crossing_count": crossing_count,
        "variable_count": len(variables),
        "variables": list(variables),
        "bounded_alexander_maturity_path": bounded_alexander_maturity_path,
        "bounded_alexander_maturity_path_certified": (
            _bounded_alexander_maturity_path_certified(
                bounded_alexander_maturity_path
            )
        ),
        "expected_multivariable_alexander": expected,
        "observed_multivariable_alexander": observed,
        "comparison_matched": comparison_matched,
        "result_method": result_method,
        "result_certified": result_certified,
        "wirtinger_fox_applicable": False,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "skipped": not applicable,
        "notes": notes,
    }


@lru_cache(maxsize=32)
def _cached_fixture_source_table_invariant_audit_for_acceptance(
    notation: str,
) -> dict | None:
    from iroll.topology.pd_fixtures import get_diagram_fixture

    fixture = get_diagram_fixture(notation)
    if (
        fixture.pd_code is None
        or fixture.gauss_code is None
        or fixture.source_table_multivariable_alexander_numerator is None
    ):
        return None
    return fixture.source_table_invariant_audit(
        compute_homfly=False,
        compute_alexander=True,
        max_candidates=64,
    )


def _fixture_source_table_invariant_audit_for_acceptance(fixture) -> dict | None:
    audit = _cached_fixture_source_table_invariant_audit_for_acceptance(
        fixture.notation,
    )
    return deepcopy(audit) if isinstance(audit, dict) else None


def _source_table_registration_fields_from_audit(audit: dict | None) -> dict:
    if not isinstance(audit, dict):
        return {
            "source_table_registration_ready": None,
            "source_table_registration_blockers": [],
            "source_table_registration_blocker_count": 0,
            "source_table_registration_blocker_details": {},
        }

    raw_blockers = audit.get("source_table_registration_blockers", [])
    blockers = [
        str(blocker)
        for blocker in raw_blockers
        if blocker not in (None, "")
    ] if isinstance(raw_blockers, Sequence) and not isinstance(
        raw_blockers,
        (str, bytes, bytearray),
    ) else []
    raw_count = audit.get("source_table_registration_blocker_count")
    blocker_count = _blocker_int(raw_count, fallback=len(blockers))
    ready_value = audit.get("source_table_registration_ready")
    ready = ready_value if isinstance(ready_value, bool) else len(blockers) == 0
    details = audit.get("source_table_registration_blocker_details")
    return {
        "source_table_registration_ready": ready,
        "source_table_registration_blockers": blockers,
        "source_table_registration_blocker_count": blocker_count,
        "source_table_registration_blocker_details": (
            dict(details) if isinstance(details, dict) else {}
        ),
    }


def _source_table_alexander_numerator_link_normalization_evidence(
    *,
    notation: str,
    checked: bool,
    source_seen: bool,
    complete_match: bool,
    returned_match: bool,
    resolution_status: str | None,
    candidate_unique_value_count: int,
    computed_candidate_count: int,
    skipped_candidate_count: int,
    missing_candidate_count: int,
    source_divisibility_checked_candidate_count: int,
    source_divisibility_failed_candidate_count: int,
    source_divisibility_statuses: Sequence[str],
    registration_ready: bool | None,
    registration_blockers: Sequence[str],
) -> dict:
    readiness_blockers = []
    if not checked:
        readiness_blockers.append(
            "source_table_alexander_numerator_not_checked"
        )
    elif not source_seen:
        readiness_blockers.append(
            "source_table_alexander_numerator_source_not_seen"
        )
    elif (
        not complete_match
        or resolution_status != "complete_source_match"
    ):
        readiness_blockers.append(
            "source_table_alexander_numerator_not_complete_source_match"
        )
    if source_divisibility_failed_candidate_count > 0:
        readiness_blockers.append(
            "source_table_alexander_source_divisibility_failed"
        )

    ready = checked and not readiness_blockers
    blockers = [
        str(blocker)
        for blocker in registration_blockers
        if blocker not in (None, "")
    ]
    notes = [
        "readiness is scoped to source-table Alexander numerator link-normalization convention work",
        "this is not fixture registration or full admissible-minor normalization certification",
    ]
    if ready:
        notes.append(
            "source-table numerator candidates give a complete source match"
        )
    else:
        notes.append(
            "source-table numerator candidates remain blocked for link normalization"
        )
    return {
        "method": (
            "source_table_alexander_numerator_link_normalization_evidence"
        ),
        "claim_scope": (
            "source_table_alexander_numerator_link_normalization_readiness"
        ),
        "notation": notation,
        "checked": checked,
        "ready": ready,
        "source_seen": source_seen,
        "complete_match": complete_match,
        "returned_match": returned_match,
        "resolution_status": resolution_status,
        "candidate_unique_value_count": candidate_unique_value_count,
        "computed_candidate_count": computed_candidate_count,
        "skipped_candidate_count": skipped_candidate_count,
        "missing_candidate_count": missing_candidate_count,
        "source_divisibility_checked_candidate_count": (
            source_divisibility_checked_candidate_count
        ),
        "source_divisibility_failed_candidate_count": (
            source_divisibility_failed_candidate_count
        ),
        "source_divisibility_statuses": [
            str(status) for status in source_divisibility_statuses
        ],
        "registration_ready": registration_ready,
        "registration_blockers": blockers,
        "registration_blocker_count": len(blockers),
        "readiness_blockers": readiness_blockers,
        "readiness_blocker_count": len(readiness_blockers),
        "registered_fixture_claim": False,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": notes,
    }

def _source_table_registration_summary_consistency(
    *,
    checked_count: int,
    ready_count: int,
    blocked_count: int,
    blocker_count: int,
    blocker_counts: Sequence[dict],
    blocked_notations: Sequence[str],
    ready_notations: Sequence[str],
    rows: Sequence[dict],
) -> dict:
    registration_rows = [
        row
        for row in rows
        if isinstance(row.get("source_table_registration_ready"), bool)
    ]
    row_ready_rows = [
        row
        for row in registration_rows
        if row["source_table_registration_ready"]
    ]
    row_blocked_rows = [
        row
        for row in registration_rows
        if not row["source_table_registration_ready"]
    ]
    row_ready_notations = [
        str(row.get("notation", ""))
        for row in row_ready_rows
    ]
    row_blocked_notations = [
        str(row.get("notation", ""))
        for row in row_blocked_rows
    ]

    row_blocker_count = 0
    row_blocker_count_map: dict[str, int] = {}
    row_count_mismatches = []
    row_detail_mismatches = []
    for row in registration_rows:
        notation = str(row.get("notation", ""))
        raw_blockers = row.get("source_table_registration_blockers", [])
        row_blockers = [
            str(blocker)
            for blocker in raw_blockers
            if blocker not in (None, "")
        ] if isinstance(raw_blockers, Sequence) and not isinstance(
            raw_blockers,
            (str, bytes, bytearray),
        ) else []
        reported_row_blocker_count = _blocker_int(
            row.get("source_table_registration_blocker_count"),
            fallback=len(row_blockers),
        )
        row_blocker_count += reported_row_blocker_count
        if reported_row_blocker_count != len(row_blockers):
            row_count_mismatches.append(
                {
                    "notation": notation,
                    "reported_blocker_count": reported_row_blocker_count,
                    "row_blocker_list_count": len(row_blockers),
                }
            )
        for blocker in row_blockers:
            row_blocker_count_map[blocker] = (
                row_blocker_count_map.get(blocker, 0) + 1
            )
        details = row.get("source_table_registration_blocker_details")
        if isinstance(details, dict):
            unexpected_detail_blockers = [
                str(blocker)
                for blocker in details
                if str(blocker) and str(blocker) not in row_blockers
            ]
            if unexpected_detail_blockers:
                row_detail_mismatches.append(
                    {
                        "notation": notation,
                        "unexpected_detail_blockers": unexpected_detail_blockers,
                    }
                )

    row_blocker_counts = [
        {
            "blocker": blocker,
            "fixture_count": row_blocker_count_map[blocker],
        }
        for blocker in sorted(row_blocker_count_map)
    ]
    reported_blocker_counts = [
        {
            "blocker": str(row.get("blocker", "")),
            "fixture_count": _blocker_int(row.get("fixture_count")),
        }
        for row in blocker_counts
        if isinstance(row, dict)
    ]
    reported_blocked_notations = [str(notation) for notation in blocked_notations]
    reported_ready_notations = [str(notation) for notation in ready_notations]

    checks = {
        "checked_count_matches_rows": checked_count == len(registration_rows),
        "ready_count_matches_rows": ready_count == len(row_ready_rows),
        "blocked_count_matches_rows": blocked_count == len(row_blocked_rows),
        "blocker_count_matches_rows": blocker_count == row_blocker_count,
        "blocker_counts_match_rows": reported_blocker_counts == row_blocker_counts,
        "blocked_notations_match_rows": (
            reported_blocked_notations == row_blocked_notations
        ),
        "ready_notations_match_rows": (
            reported_ready_notations == row_ready_notations
        ),
        "row_blocker_count_matches_list": not row_count_mismatches,
        "row_blocker_details_cover_blockers": not row_detail_mismatches,
    }
    mismatch_witnesses = []
    for field, matched in checks.items():
        if matched:
            continue
        witness = {"kind": field.removesuffix("_matches_rows"), "field": field}
        if field == "checked_count_matches_rows":
            witness.update(
                {
                    "reported": checked_count,
                    "row_derived": len(registration_rows),
                    "report_value": checked_count,
                    "source_value": len(registration_rows),
                }
            )
        elif field == "ready_count_matches_rows":
            witness.update(
                {
                    "reported": ready_count,
                    "row_derived": len(row_ready_rows),
                    "report_value": ready_count,
                    "source_value": len(row_ready_rows),
                }
            )
        elif field == "blocked_count_matches_rows":
            witness.update(
                {
                    "reported": blocked_count,
                    "row_derived": len(row_blocked_rows),
                    "report_value": blocked_count,
                    "source_value": len(row_blocked_rows),
                }
            )
        elif field == "blocker_count_matches_rows":
            witness.update(
                {
                    "reported": blocker_count,
                    "row_derived": row_blocker_count,
                    "report_value": blocker_count,
                    "source_value": row_blocker_count,
                }
            )
        elif field == "blocker_counts_match_rows":
            witness.update(
                {
                    "reported": reported_blocker_counts,
                    "row_derived": row_blocker_counts,
                    "report_value": reported_blocker_counts,
                    "source_value": row_blocker_counts,
                }
            )
        elif field == "blocked_notations_match_rows":
            witness.update(
                {
                    "reported": reported_blocked_notations,
                    "row_derived": row_blocked_notations,
                    "report_value": reported_blocked_notations,
                    "source_value": row_blocked_notations,
                }
            )
        elif field == "ready_notations_match_rows":
            witness.update(
                {
                    "reported": reported_ready_notations,
                    "row_derived": row_ready_notations,
                    "report_value": reported_ready_notations,
                    "source_value": row_ready_notations,
                }
            )
        elif field == "row_blocker_count_matches_list":
            witness["rows"] = row_count_mismatches
            witness["report_value"] = row_count_mismatches
            witness["source_value"] = []
        elif field == "row_blocker_details_cover_blockers":
            witness["rows"] = row_detail_mismatches
            witness["report_value"] = row_detail_mismatches
            witness["source_value"] = []
        mismatch_witnesses.append(witness)

    return {
        "method": "source_table_registration_summary_consistency",
        "claim_scope": "bounded_source_table_registration_summary_consistency",
        "matched": all(checks.values()),
        "mismatch_count": len(mismatch_witnesses),
        "first_mismatch": mismatch_witnesses[0] if mismatch_witnesses else None,
        "mismatch_witnesses": mismatch_witnesses,
        "report_checked_count": checked_count,
        "reported_checked_count": checked_count,
        "row_checked_count": len(registration_rows),
        "report_ready_count": ready_count,
        "reported_ready_count": ready_count,
        "row_ready_count": len(row_ready_rows),
        "report_blocked_count": blocked_count,
        "reported_blocked_count": blocked_count,
        "row_blocked_count": len(row_blocked_rows),
        "report_blocker_count": blocker_count,
        "reported_blocker_count": blocker_count,
        "row_blocker_count": row_blocker_count,
        "report_blocker_counts": reported_blocker_counts,
        "reported_blocker_counts": reported_blocker_counts,
        "row_blocker_counts": row_blocker_counts,
        "report_blocked_notations": reported_blocked_notations,
        "reported_blocked_notations": reported_blocked_notations,
        "row_blocked_notations": row_blocked_notations,
        "report_ready_notations": reported_ready_notations,
        "reported_ready_notations": reported_ready_notations,
        "row_ready_notations": row_ready_notations,
        "row_blocker_count_mismatches": row_count_mismatches[:8],
        "row_blocker_detail_mismatches": row_detail_mismatches[:8],
        **checks,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": [
            "checks Alexander source-table registration root aggregate fields against row-level registration diagnostics",
            "this is bounded source-table audit provenance and does not claim full admissible-minor normalization",
        ],
    }


def multivariable_alexander_fixture_acceptance_report(
    notations: Iterable[str] | None = None,
    *,
    include_unregistered: bool = False,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    """Aggregate fixture comparison and scanned-minor audit evidence."""

    from iroll.topology.pd_fixtures import (
        get_diagram_fixture,
        standard_diagram_fixtures,
    )

    fixtures = (
        [get_diagram_fixture(notation) for notation in notations]
        if notations is not None
        else standard_diagram_fixtures()
    )
    if not include_unregistered:
        fixtures = [
            fixture
            for fixture in fixtures
            if fixture.expected_multivariable_alexander is not None
        ]

    rows = []
    for fixture in fixtures:
        comparison = multivariable_alexander_fixture_comparison(
            fixture.notation,
            max_matrix_size=max_matrix_size,
            max_minors=max_minors,
        )
        comparison_passed = (
            not comparison["skipped"] and comparison["matched"]
        )
        zero_crossing_unlink_normalization_evidence = (
            _zero_crossing_unlink_normalization_evidence(
                fixture,
                comparison,
            )
        )
        zero_crossing_unlink_normalization_applicable = bool(
            zero_crossing_unlink_normalization_evidence["applicable"]
        )
        zero_crossing_unlink_normalization_certified = bool(
            zero_crossing_unlink_normalization_evidence["certified"]
        )
        audit = None
        audit_applicable = (
            comparison.get("result") is not None
            and not zero_crossing_unlink_normalization_applicable
        )
        if audit_applicable:
            audit = multivariable_alexander_minor_divisibility_audit(
                comparison["result"]
            )
        audit_passed = (
            audit is not None
            and not audit["skipped"]
            and audit["all_nonzero_minors_divisible"]
        )
        scanned_gcd_audit = None
        if audit_applicable:
            scanned_gcd_audit = multivariable_alexander_scanned_gcd_audit(
                comparison["result"]
            )
        admissible_minor_normalization_audit = None
        if audit_applicable:
            admissible_minor_normalization_audit = (
                multivariable_alexander_admissible_minor_normalization_audit(
                    comparison["result"]
                )
            )
        scanned_gcd_passed = (
            scanned_gcd_audit is not None
            and not scanned_gcd_audit["skipped"]
            and scanned_gcd_audit["candidate_is_exact_scanned_gcd"]
        )
        wirtinger_fox_audit = None
        if audit_applicable:
            wirtinger_fox_audit = multivariable_alexander_wirtinger_fox_audit(
                comparison["result"]
            )
        wirtinger_fox_passed = (
            wirtinger_fox_audit is not None
            and not wirtinger_fox_audit["skipped"]
            and wirtinger_fox_audit["input_chain_consistent"]
        )
        bounded_scanned_gcd_evidence = (
            multivariable_alexander_input_certification_evidence(
                scanned_gcd_audit,
                wirtinger_fox_audit,
                admissible_minor_normalization_audit,
            )
        )
        bounded_scanned_gcd_certification_applicable = (
            fixture.expected_multivariable_alexander is not None
            and audit_applicable
        )
        bounded_scanned_gcd_certified = (
            bounded_scanned_gcd_certification_applicable
            and scanned_gcd_passed
        )
        registered_knot_admissible_normalization_evidence = (
            _registered_knot_admissible_normalization_evidence(
                fixture,
                comparison,
                scanned_gcd_audit,
                wirtinger_fox_audit,
            )
        )
        registered_knot_admissible_normalization_applicable = bool(
            registered_knot_admissible_normalization_evidence["applicable"]
        )
        registered_knot_admissible_normalization_certified = bool(
            registered_knot_admissible_normalization_evidence["certified"]
        )
        source_table_invariant_audit = None
        if not fixture.has_signed_pd:
            source_table_invariant_audit = (
                _fixture_source_table_invariant_audit_for_acceptance(fixture)
            )
        source_table_alexander_comparison = None
        if isinstance(source_table_invariant_audit, dict):
            source_table_alexander_comparison = source_table_invariant_audit.get(
                "comparisons",
                {},
            ).get("multivariable_alexander_numerator")
        source_table_registration_fields = (
            _source_table_registration_fields_from_audit(
                source_table_invariant_audit,
            )
        )
        source_table_alexander_checked = isinstance(
            source_table_alexander_comparison,
            dict,
        ) and bool(source_table_alexander_comparison.get("source_value_present"))
        source_table_alexander_source_seen = bool(
            isinstance(source_table_alexander_comparison, dict)
            and source_table_alexander_comparison.get("source_value_seen", False)
        )
        source_table_alexander_complete_match = bool(
            isinstance(source_table_alexander_comparison, dict)
            and source_table_alexander_comparison.get(
                "complete_candidate_source_match",
                False,
            )
        )
        source_table_alexander_returned_match = bool(
            isinstance(source_table_alexander_comparison, dict)
            and source_table_alexander_comparison.get(
                "returned_candidate_source_match",
                False,
            )
        )
        source_table_alexander_resolution_status = (
            str(
                source_table_alexander_comparison.get(
                    "source_match_resolution_status",
                )
            )
            if isinstance(source_table_alexander_comparison, dict)
            and source_table_alexander_comparison.get(
                "source_match_resolution_status",
            )
            is not None
            else None
        )
        source_table_alexander_candidate_unique_value_count = (
            int(
                source_table_alexander_comparison.get(
                    "candidate_unique_value_count",
                    0,
                )
                or 0
            )
            if isinstance(source_table_alexander_comparison, dict)
            else 0
        )
        source_table_alexander_computed_candidate_count = (
            int(
                source_table_alexander_comparison.get(
                    "computed_candidate_count",
                    0,
                )
                or 0
            )
            if isinstance(source_table_alexander_comparison, dict)
            else 0
        )
        source_table_alexander_skipped_candidate_count = (
            int(
                source_table_alexander_comparison.get(
                    "skipped_candidate_count",
                    0,
                )
                or 0
            )
            if isinstance(source_table_alexander_comparison, dict)
            else 0
        )
        source_table_alexander_missing_candidate_count = (
            int(
                source_table_alexander_comparison.get(
                    "missing_candidate_count",
                    0,
                )
                or 0
            )
            if isinstance(source_table_alexander_comparison, dict)
            else 0
        )
        source_table_alexander_source_divisibility_summary = (
            source_table_alexander_comparison.get(
                "source_numerator_divisibility_summary",
            )
            if isinstance(source_table_alexander_comparison, dict)
            else None
        )

        def _source_table_alexander_source_divisibility_int(name: str) -> int:
            if not isinstance(source_table_alexander_source_divisibility_summary, dict):
                return 0
            return int(
                source_table_alexander_source_divisibility_summary.get(name, 0)
                or 0
            )

        def _source_table_alexander_source_divisibility_optional_int(
            name: str,
        ) -> int | None:
            if not isinstance(source_table_alexander_source_divisibility_summary, dict):
                return None
            value = source_table_alexander_source_divisibility_summary.get(name)
            if value is None or isinstance(value, bool):
                return None
            try:
                return int(value)
            except (TypeError, ValueError):
                return None

        def _source_table_alexander_source_divisibility_int_list(
            name: str,
        ) -> list[int]:
            if not isinstance(source_table_alexander_source_divisibility_summary, dict):
                return []
            values = source_table_alexander_source_divisibility_summary.get(name, [])
            if not isinstance(values, list):
                return []
            output = []
            for value in values:
                if isinstance(value, bool):
                    continue
                try:
                    output.append(int(value))
                except (TypeError, ValueError):
                    continue
            return output

        def _source_table_alexander_source_divisibility_status_counts() -> list[dict]:
            if not isinstance(source_table_alexander_source_divisibility_summary, dict):
                return []
            rows = []
            raw_rows = source_table_alexander_source_divisibility_summary.get(
                "status_counts",
                [],
            )
            if not isinstance(raw_rows, list):
                return rows
            for raw_row in raw_rows:
                if not isinstance(raw_row, dict):
                    continue
                status = str(raw_row.get("status") or "")
                if not status:
                    continue
                rows.append(
                    {
                        "status": status,
                        "candidate_count": int(
                            raw_row.get("candidate_count", 0) or 0
                        ),
                    }
                )
            return rows

        source_table_alexander_source_divisibility_statuses = (
            [
                str(status)
                for status in source_table_alexander_source_divisibility_summary.get(
                    "statuses",
                    [],
                )
            ]
            if isinstance(source_table_alexander_source_divisibility_summary, dict)
            else []
        )
        source_table_alexander_source_divisibility_all_checked_candidates_divisible = (
            bool(
                source_table_alexander_source_divisibility_summary.get(
                    "all_checked_candidates_divisible",
                    False,
                )
            )
            if isinstance(source_table_alexander_source_divisibility_summary, dict)
            else False
        )
        source_table_alexander_source_divisibility_first_failed_input = (
            source_table_alexander_source_divisibility_summary.get(
                "first_failed_input_polynomial",
            )
            if isinstance(source_table_alexander_source_divisibility_summary, dict)
            else None
        )
        source_table_alexander_source_divisibility_status_counts = (
            _source_table_alexander_source_divisibility_status_counts()
        )
        source_table_alexander_source_divisibility_failure_status_counts = [
            row
            for row in source_table_alexander_source_divisibility_status_counts
            if row["status"] != "all_inputs_divisible"
        ]
        source_table_alexander_source_divisibility_candidate_indices = (
            _source_table_alexander_source_divisibility_int_list(
                "candidate_indices",
            )
        )
        source_table_alexander_source_divisibility_first_failed_candidate_index = (
            _source_table_alexander_source_divisibility_optional_int(
                "first_failed_candidate_index",
            )
        )
        source_table_alexander_source_divisibility_checked_candidate_count = (
            _source_table_alexander_source_divisibility_int(
                "checked_candidate_count"
            )
        )
        source_table_alexander_source_divisibility_source_divides_all_candidate_count = (
            _source_table_alexander_source_divisibility_int(
                "source_divides_all_candidate_count"
            )
        )
        source_table_alexander_source_divisibility_source_division_failed_candidate_count = (
            _source_table_alexander_source_divisibility_int(
                "source_division_failed_candidate_count"
            )
        )
        source_table_alexander_source_divisibility_failed_candidate_witness_summary = (
            _source_table_source_divisibility_failed_candidate_witness_summary(
                source_table_invariant_audit,
                source_table_alexander_source_divisibility_summary,
            )
        )
        source_table_alexander_numerator_link_normalization_evidence = (
            _source_table_alexander_numerator_link_normalization_evidence(
                notation=fixture.notation,
                checked=source_table_alexander_checked,
                source_seen=source_table_alexander_source_seen,
                complete_match=source_table_alexander_complete_match,
                returned_match=source_table_alexander_returned_match,
                resolution_status=source_table_alexander_resolution_status,
                candidate_unique_value_count=(
                    source_table_alexander_candidate_unique_value_count
                ),
                computed_candidate_count=source_table_alexander_computed_candidate_count,
                skipped_candidate_count=source_table_alexander_skipped_candidate_count,
                missing_candidate_count=source_table_alexander_missing_candidate_count,
                source_divisibility_checked_candidate_count=(
                    source_table_alexander_source_divisibility_checked_candidate_count
                ),
                source_divisibility_failed_candidate_count=(
                    source_table_alexander_source_divisibility_source_division_failed_candidate_count
                ),
                source_divisibility_statuses=(
                    source_table_alexander_source_divisibility_statuses
                ),
                registration_ready=source_table_registration_fields[
                    "source_table_registration_ready"
                ],
                registration_blockers=source_table_registration_fields[
                    "source_table_registration_blockers"
                ],
            )
        )
        fox_minor_path_accepted = (
            audit_passed
            and scanned_gcd_passed
            and wirtinger_fox_passed
            and (
                not registered_knot_admissible_normalization_applicable
                or registered_knot_admissible_normalization_certified
            )
        )
        zero_crossing_path_accepted = (
            zero_crossing_unlink_normalization_applicable
            and zero_crossing_unlink_normalization_certified
        )
        accepted = comparison_passed and (
            fox_minor_path_accepted or zero_crossing_path_accepted
        )
        row_required = (
            1
            + (1 if zero_crossing_unlink_normalization_applicable else 0)
            + (1 if audit_applicable else 0) * 3
            + (1 if registered_knot_admissible_normalization_applicable else 0)
        )
        row_passed = (
            (1 if comparison_passed else 0)
            + (
                1
                if zero_crossing_unlink_normalization_applicable
                and zero_crossing_unlink_normalization_certified
                else 0
            )
            + (1 if audit_applicable and audit_passed else 0)
            + (1 if audit_applicable and scanned_gcd_passed else 0)
            + (1 if audit_applicable and wirtinger_fox_passed else 0)
            + (
                1
                if registered_knot_admissible_normalization_applicable
                and registered_knot_admissible_normalization_certified
                else 0
            )
        )
        row_failed = max(0, row_required - row_passed)
        source_table_diagnostic_only = bool(
            isinstance(source_table_invariant_audit, dict)
            and not fixture.has_signed_pd
        )
        row_bounded_alexander_maturity_path = _bounded_alexander_maturity_path(
            source_table_diagnostic_only=source_table_diagnostic_only,
            zero_crossing_unlink_certified=zero_crossing_path_accepted,
            bounded_admissible_minor_normalization_certified=bool(
                bounded_scanned_gcd_evidence.get(
                    "bounded_admissible_minor_normalization_certified",
                    False,
                )
            ),
            all_nonzero_minors_laurent_unit_equivalent=bool(
                bounded_scanned_gcd_evidence.get(
                    "all_nonzero_minors_laurent_unit_equivalent",
                    False,
                )
            ),
            complete_scanned_gcd_certified=bool(
                bounded_scanned_gcd_evidence.get(
                    "complete_scanned_gcd_certified",
                    False,
                )
            ),
            bounded_scanned_gcd_certified=bounded_scanned_gcd_certified,
            candidate_is_exact_scanned_gcd=bool(
                bounded_scanned_gcd_evidence.get(
                    "candidate_is_exact_scanned_gcd",
                    False,
                )
            ),
            quotient_gcd_certified=bool(
                bounded_scanned_gcd_evidence.get("quotient_gcd_certified", False)
            ),
        )
        row_bounded_alexander_maturity_path_certified = (
            _bounded_alexander_maturity_path_certified(
                row_bounded_alexander_maturity_path
            )
        )
        rows.append(
            {
                "notation": fixture.notation,
                "name": fixture.name,
                "kind": fixture.kind,
                "component_count": fixture.component_count,
                "source": fixture.source,
                "source_url": fixture.source_url,
                "expected_multivariable_alexander": (
                    fixture.expected_multivariable_alexander
                ),
                "expected_variables": list(_fixture_alexander_variables(fixture)),
                "expected_multivariable_alexander_source": (
                    fixture.expected_multivariable_alexander_source
                ),
                "comparison_matched": comparison_passed,
                "minor_divisibility_audit_applicable": audit_applicable,
                "minor_divisibility_audit_matched": audit_passed
                if audit_applicable
                else None,
                "scanned_gcd_audit_applicable": audit_applicable,
                "scanned_gcd_audit_matched": scanned_gcd_passed
                if audit_applicable
                else None,
                "wirtinger_fox_audit_applicable": audit_applicable,
                "wirtinger_fox_audit_matched": wirtinger_fox_passed
                if audit_applicable
                else None,
                "bounded_scanned_gcd_certification_applicable": (
                    bounded_scanned_gcd_certification_applicable
                ),
                "bounded_scanned_gcd_certified": (
                    bounded_scanned_gcd_certified
                ),
                "bounded_alexander_maturity_path": (
                    row_bounded_alexander_maturity_path
                ),
                "bounded_alexander_maturity_path_certified": (
                    row_bounded_alexander_maturity_path_certified
                ),
                "bounded_scanned_gcd_evidence": bounded_scanned_gcd_evidence,
                "admissible_minor_normalization_audit": (
                    admissible_minor_normalization_audit
                ),
                "zero_crossing_unlink_normalization_applicable": (
                    zero_crossing_unlink_normalization_applicable
                ),
                "zero_crossing_unlink_normalization_certified": (
                    zero_crossing_unlink_normalization_certified
                ),
                "zero_crossing_unlink_normalization_evidence": (
                    zero_crossing_unlink_normalization_evidence
                ),
                "registered_knot_admissible_normalization_applicable": (
                    registered_knot_admissible_normalization_applicable
                ),
                "registered_knot_admissible_normalization_certified": (
                    registered_knot_admissible_normalization_certified
                ),
                "registered_knot_admissible_normalization_evidence": (
                    registered_knot_admissible_normalization_evidence
                ),
                "source_table_invariant_audit_applicable": isinstance(
                    source_table_invariant_audit,
                    dict,
                ),
                "source_table_invariant_audit": source_table_invariant_audit,
                **source_table_registration_fields,
                "source_table_multivariable_alexander_numerator_checked": (
                    source_table_alexander_checked
                ),
                "source_table_multivariable_alexander_numerator_source_seen": (
                    source_table_alexander_source_seen
                ),
                "source_table_multivariable_alexander_numerator_complete_match": (
                    source_table_alexander_complete_match
                ),
                "source_table_multivariable_alexander_numerator_returned_match": (
                    source_table_alexander_returned_match
                ),
                "source_table_multivariable_alexander_numerator_resolution_status": (
                    source_table_alexander_resolution_status
                ),
                "source_table_multivariable_alexander_numerator_candidate_unique_value_count": (
                    source_table_alexander_candidate_unique_value_count
                ),
                "source_table_multivariable_alexander_numerator_computed_candidate_count": (
                    source_table_alexander_computed_candidate_count
                ),
                "source_table_multivariable_alexander_numerator_skipped_candidate_count": (
                    source_table_alexander_skipped_candidate_count
                ),
                "source_table_multivariable_alexander_numerator_missing_candidate_count": (
                    source_table_alexander_missing_candidate_count
                ),
                "source_table_alexander_numerator_link_normalization_evidence": (
                    source_table_alexander_numerator_link_normalization_evidence
                ),
                "source_table_alexander_numerator_link_normalization_checked": (
                    source_table_alexander_numerator_link_normalization_evidence[
                        "checked"
                    ]
                ),
                "source_table_alexander_numerator_link_normalization_ready": (
                    source_table_alexander_numerator_link_normalization_evidence[
                        "ready"
                    ]
                ),
                "source_table_alexander_numerator_link_normalization_blockers": (
                    source_table_alexander_numerator_link_normalization_evidence[
                        "readiness_blockers"
                    ]
                ),
                "source_table_alexander_numerator_link_normalization_blocker_count": (
                    source_table_alexander_numerator_link_normalization_evidence[
                        "readiness_blocker_count"
                    ]
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_checked_candidate_count": (
                    source_table_alexander_source_divisibility_checked_candidate_count
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_source_divides_all_candidate_count": (
                    source_table_alexander_source_divisibility_source_divides_all_candidate_count
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_source_division_failed_candidate_count": (
                    source_table_alexander_source_divisibility_source_division_failed_candidate_count
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_all_checked_candidates_divisible": (
                    source_table_alexander_source_divisibility_all_checked_candidates_divisible
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_statuses": (
                    source_table_alexander_source_divisibility_statuses
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_status_counts": (
                    source_table_alexander_source_divisibility_status_counts
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_failure_status_counts": (
                    source_table_alexander_source_divisibility_failure_status_counts
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_candidate_indices": (
                    source_table_alexander_source_divisibility_candidate_indices
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_failed_input_count_min": (
                    _source_table_alexander_source_divisibility_int(
                        "failed_input_count_min"
                    )
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_failed_input_count_max": (
                    _source_table_alexander_source_divisibility_int(
                        "failed_input_count_max"
                    )
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_unique_input_polynomial_count_min": (
                    _source_table_alexander_source_divisibility_int(
                        "unique_input_polynomial_count_min"
                    )
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_unique_input_polynomial_count_max": (
                    _source_table_alexander_source_divisibility_int(
                        "unique_input_polynomial_count_max"
                    )
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_candidate_index": (
                    source_table_alexander_source_divisibility_first_failed_candidate_index
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_input_polynomial": (
                    source_table_alexander_source_divisibility_first_failed_input
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_failed_candidate_witness_summary": (
                    source_table_alexander_source_divisibility_failed_candidate_witness_summary
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_failed_candidate_witness_count": (
                    source_table_alexander_source_divisibility_failed_candidate_witness_summary[
                        "failed_candidate_witness_count"
                    ]
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_failed_candidate_witness_limit": (
                    source_table_alexander_source_divisibility_failed_candidate_witness_summary[
                        "failed_candidate_witness_limit"
                    ]
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_failed_candidate_witness_truncated": (
                    source_table_alexander_source_divisibility_failed_candidate_witness_summary[
                        "failed_candidate_witness_truncated"
                    ]
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_failed_candidate_witnesses": (
                    source_table_alexander_source_divisibility_failed_candidate_witness_summary[
                        "failed_candidate_witnesses"
                    ]
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_candidate_witness": (
                    source_table_alexander_source_divisibility_failed_candidate_witness_summary[
                        "first_failed_candidate_witness"
                    ]
                ),
                "source_table_multivariable_alexander_numerator_source_divisibility_failed_candidate_witness_consistency": (
                    source_table_alexander_source_divisibility_failed_candidate_witness_summary[
                        "failed_candidate_witness_consistency"
                    ]
                ),
                "full_invariant_certified": False,
                "accepted": accepted,
                "comparison": comparison,
                "minor_divisibility_audit": audit,
                "scanned_gcd_audit": scanned_gcd_audit,
                "wirtinger_fox_audit": wirtinger_fox_audit,
                "required_check_count": row_required,
                "passed_check_count": row_passed,
                "failed_check_count": row_failed,
                "notes": []
                if accepted
                else [
                    "fixture does not yet satisfy every multi-variable Alexander acceptance-report check",
                ],
            }
        )

    comparison_checked = sum(
        1
        for row in rows
        if row["expected_multivariable_alexander"] is not None
    )
    comparison_matched = sum(1 for row in rows if row["comparison_matched"])
    audit_checked = sum(1 for row in rows if row["minor_divisibility_audit_applicable"])
    audit_matched = sum(
        1
        for row in rows
        if row["minor_divisibility_audit_matched"] is True
    )
    scanned_gcd_checked = sum(
        1 for row in rows if row["scanned_gcd_audit_applicable"]
    )
    scanned_gcd_matched = sum(
        1 for row in rows if row["scanned_gcd_audit_matched"] is True
    )
    wirtinger_fox_checked = sum(
        1 for row in rows if row["wirtinger_fox_audit_applicable"]
    )
    wirtinger_fox_matched = sum(
        1 for row in rows if row["wirtinger_fox_audit_matched"] is True
    )
    wirtinger_fox_rows = [
        row
        for row in rows
        if isinstance(row["wirtinger_fox_audit"], dict)
        and not row["wirtinger_fox_audit"].get("skipped", False)
    ]
    wirtinger_fox_relation_count = sum(
        int(row["wirtinger_fox_audit"].get("relation_count", 0) or 0)
        for row in wirtinger_fox_rows
    )
    wirtinger_fox_generator_count = sum(
        int(row["wirtinger_fox_audit"].get("generator_count", 0) or 0)
        for row in wirtinger_fox_rows
    )
    wirtinger_fox_scanned_minor_count = sum(
        int(row["wirtinger_fox_audit"].get("scanned_minor_count", 0) or 0)
        for row in wirtinger_fox_rows
    )
    wirtinger_fox_invalid_minor_reference_count = sum(
        int(row["wirtinger_fox_audit"].get("invalid_minor_reference_count", 0) or 0)
        for row in wirtinger_fox_rows
    )
    wirtinger_fox_invalid_normalization_count = sum(
        int(row["wirtinger_fox_audit"].get("invalid_normalization_count", 0) or 0)
        for row in wirtinger_fox_rows
    )
    wirtinger_fox_complete_scan_count = sum(
        1
        for row in wirtinger_fox_rows
        if row["wirtinger_fox_audit"].get("complete_combination_scan", False)
    )
    wirtinger_fox_truncated_count = sum(
        1
        for row in wirtinger_fox_rows
        if row["wirtinger_fox_audit"].get("truncated", False)
    )
    bounded_scanned_gcd_certification_applicable_count = sum(
        1
        for row in rows
        if row["bounded_scanned_gcd_certification_applicable"]
    )
    bounded_scanned_gcd_certified_count = sum(
        1 for row in rows if row["bounded_scanned_gcd_certified"]
    )
    bounded_scanned_gcd_uncertified_count = (
        bounded_scanned_gcd_certification_applicable_count
        - bounded_scanned_gcd_certified_count
    )
    bounded_scanned_gcd_rows = [
        row
        for row in rows
        if row["bounded_scanned_gcd_certification_applicable"]
    ]
    bounded_scanned_gcd_checked_nonzero_minor_count = sum(
        int(row["bounded_scanned_gcd_evidence"]["checked_nonzero_minor_count"])
        for row in bounded_scanned_gcd_rows
    )
    bounded_scanned_gcd_failed_nonzero_minor_count = sum(
        int(row["bounded_scanned_gcd_evidence"]["failed_nonzero_minor_count"])
        for row in bounded_scanned_gcd_rows
    )
    bounded_scanned_gcd_scanned_minor_count = sum(
        int(row["bounded_scanned_gcd_evidence"]["scanned_minor_count"])
        for row in bounded_scanned_gcd_rows
    )
    bounded_scanned_gcd_division_record_count = sum(
        int(row["bounded_scanned_gcd_evidence"]["division_record_count"])
        for row in bounded_scanned_gcd_rows
    )
    bounded_scanned_gcd_expected_combination_count = sum(
        int(row["bounded_scanned_gcd_evidence"].get("expected_combination_count", 0) or 0)
        for row in bounded_scanned_gcd_rows
    )
    bounded_scanned_gcd_nonzero_minor_count = sum(
        int(row["bounded_scanned_gcd_evidence"].get("nonzero_minor_count", 0) or 0)
        for row in bounded_scanned_gcd_rows
    )
    bounded_scanned_gcd_zero_minor_count = sum(
        int(row["bounded_scanned_gcd_evidence"].get("zero_minor_count", 0) or 0)
        for row in bounded_scanned_gcd_rows
    )
    bounded_scanned_gcd_unit_minor_count = sum(
        int(row["bounded_scanned_gcd_evidence"].get("unit_minor_count", 0) or 0)
        for row in bounded_scanned_gcd_rows
    )
    bounded_scanned_gcd_unique_nonzero_polynomial_count = sum(
        int(
            row["bounded_scanned_gcd_evidence"].get(
                "unique_nonzero_polynomial_count",
                0,
            )
            or 0
        )
        for row in bounded_scanned_gcd_rows
    )
    bounded_scanned_gcd_all_rows_have_nonzero_minor_count = sum(
        1
        for row in bounded_scanned_gcd_rows
        if row["bounded_scanned_gcd_evidence"].get(
            "all_rows_have_nonzero_minor",
            False,
        )
    )
    bounded_scanned_gcd_all_columns_have_nonzero_minor_count = sum(
        1
        for row in bounded_scanned_gcd_rows
        if row["bounded_scanned_gcd_evidence"].get(
            "all_columns_have_nonzero_minor",
            False,
        )
    )
    bounded_scanned_gcd_complete_scan_count = sum(
        1
        for row in bounded_scanned_gcd_rows
        if row["bounded_scanned_gcd_evidence"]["complete_combination_scan"]
    )
    bounded_scanned_gcd_nonzero_minor_coverage_complete_count = sum(
        1
        for row in bounded_scanned_gcd_rows
        if row["bounded_scanned_gcd_evidence"].get(
            "nonzero_minor_coverage_complete", False
        )
    )
    bounded_scanned_gcd_truncated_count = sum(
        1
        for row in bounded_scanned_gcd_rows
        if row["bounded_scanned_gcd_evidence"]["truncated"]
    )
    bounded_scanned_gcd_quotient_gcd_certified_count = sum(
        1
        for row in bounded_scanned_gcd_rows
        if row["bounded_scanned_gcd_evidence"].get("quotient_gcd_certified", False)
    )
    bounded_scanned_gcd_complete_certified_count = sum(
        1
        for row in bounded_scanned_gcd_rows
        if row["bounded_scanned_gcd_evidence"].get(
            "complete_scanned_gcd_certified", False
        )
    )
    bounded_scanned_gcd_improved_candidate_count = sum(
        1
        for row in bounded_scanned_gcd_rows
        if row["bounded_scanned_gcd_evidence"].get("improved_candidate_polynomial")
        or row["bounded_scanned_gcd_evidence"].get(
            "scanned_gcd_promoted_candidate", False
        )
        or row["bounded_scanned_gcd_evidence"].get(
            "scanned_gcd_improvement_evidence"
        )
    )
    bounded_alexander_maturity_path_counts = [
        {
            "bounded_alexander_maturity_path": path,
            "fixture_count": sum(
                1
                for row in rows
                if str(
                    row.get(
                        "bounded_alexander_maturity_path",
                        _ALEXANDER_MATURITY_NOT_CERTIFIED,
                    )
                    or _ALEXANDER_MATURITY_NOT_CERTIFIED
                )
                == path
            ),
        }
        for path in sorted(
            {
                str(
                    row.get(
                        "bounded_alexander_maturity_path",
                        _ALEXANDER_MATURITY_NOT_CERTIFIED,
                    )
                    or _ALEXANDER_MATURITY_NOT_CERTIFIED
                )
                for row in rows
            }
        )
    ]
    bounded_alexander_maturity_path_certified_count = sum(
        1
        for row in rows
        if row.get("bounded_alexander_maturity_path_certified", False)
    )
    bounded_alexander_maturity_path_summary_consistency = (
        _bounded_alexander_maturity_path_summary_consistency(
            rows,
            reported_path_counts=bounded_alexander_maturity_path_counts,
            reported_distinct_count=len(bounded_alexander_maturity_path_counts),
            reported_certified_count=bounded_alexander_maturity_path_certified_count,
            count_key="fixture_count",
        )
    )
    zero_crossing_unlink_normalization_applicable_count = sum(
        1
        for row in rows
        if row["zero_crossing_unlink_normalization_applicable"]
    )
    zero_crossing_unlink_normalization_certified_count = sum(
        1
        for row in rows
        if row["zero_crossing_unlink_normalization_certified"]
    )
    zero_crossing_unlink_normalization_uncertified_count = (
        zero_crossing_unlink_normalization_applicable_count
        - zero_crossing_unlink_normalization_certified_count
    )
    registered_knot_admissible_normalization_applicable_count = sum(
        1
        for row in rows
        if row["registered_knot_admissible_normalization_applicable"]
    )
    registered_knot_admissible_normalization_certified_count = sum(
        1
        for row in rows
        if row["registered_knot_admissible_normalization_certified"]
    )
    registered_knot_admissible_normalization_uncertified_count = (
        registered_knot_admissible_normalization_applicable_count
        - registered_knot_admissible_normalization_certified_count
    )
    source_table_invariant_audit_applicable_count = sum(
        1 for row in rows if row["source_table_invariant_audit_applicable"]
    )
    source_table_registration_rows = [
        row
        for row in rows
        if isinstance(row.get("source_table_registration_ready"), bool)
    ]
    source_table_registration_ready_count = sum(
        1
        for row in source_table_registration_rows
        if row["source_table_registration_ready"]
    )
    source_table_registration_blocked_rows = [
        row
        for row in source_table_registration_rows
        if not row["source_table_registration_ready"]
    ]
    source_table_registration_blocked_count = len(
        source_table_registration_blocked_rows
    )
    source_table_registration_blocker_count = sum(
        int(row.get("source_table_registration_blocker_count", 0) or 0)
        for row in source_table_registration_rows
    )
    source_table_registration_blocker_count_map: dict[str, int] = {}
    for row in source_table_registration_rows:
        for blocker in row.get("source_table_registration_blockers", []):
            blocker_key = str(blocker)
            if not blocker_key:
                continue
            source_table_registration_blocker_count_map[blocker_key] = (
                source_table_registration_blocker_count_map.get(blocker_key, 0)
                + 1
            )
    source_table_registration_blocker_counts = [
        {
            "blocker": blocker,
            "fixture_count": source_table_registration_blocker_count_map[blocker],
        }
        for blocker in sorted(source_table_registration_blocker_count_map)
    ]
    source_table_registration_blockers = [
        row["blocker"] for row in source_table_registration_blocker_counts
    ]
    source_table_registration_checked_count = len(source_table_registration_rows)
    source_table_registration_blocked_notations = [
        row["notation"] for row in source_table_registration_blocked_rows
    ]
    source_table_registration_ready_notations = [
        row["notation"]
        for row in source_table_registration_rows
        if row["source_table_registration_ready"]
    ]
    source_table_registration_summary_consistency = (
        _source_table_registration_summary_consistency(
            checked_count=source_table_registration_checked_count,
            ready_count=source_table_registration_ready_count,
            blocked_count=source_table_registration_blocked_count,
            blocker_count=source_table_registration_blocker_count,
            blocker_counts=source_table_registration_blocker_counts,
            blocked_notations=source_table_registration_blocked_notations,
            ready_notations=source_table_registration_ready_notations,
            rows=rows,
        )
    )
    source_table_alexander_rows = [
        row
        for row in rows
        if row["source_table_multivariable_alexander_numerator_checked"]
    ]
    source_table_alexander_numerator_checked_count = len(source_table_alexander_rows)
    source_table_alexander_numerator_source_seen_count = sum(
        1
        for row in source_table_alexander_rows
        if row["source_table_multivariable_alexander_numerator_source_seen"]
    )
    source_table_alexander_numerator_complete_match_count = sum(
        1
        for row in source_table_alexander_rows
        if row["source_table_multivariable_alexander_numerator_complete_match"]
    )
    source_table_alexander_numerator_returned_match_count = sum(
        1
        for row in source_table_alexander_rows
        if row["source_table_multivariable_alexander_numerator_returned_match"]
    )
    source_table_alexander_numerator_incomplete_or_unstable_count = sum(
        1
        for row in source_table_alexander_rows
        if row["source_table_multivariable_alexander_numerator_source_seen"]
        and not row["source_table_multivariable_alexander_numerator_complete_match"]
    )
    source_table_alexander_numerator_candidate_unique_value_count = sum(
        int(
            row[
                "source_table_multivariable_alexander_numerator_candidate_unique_value_count"
            ]
        )
        for row in source_table_alexander_rows
    )
    source_table_alexander_numerator_computed_candidate_count = sum(
        int(
            row[
                "source_table_multivariable_alexander_numerator_computed_candidate_count"
            ]
        )
        for row in source_table_alexander_rows
    )
    source_table_alexander_numerator_skipped_candidate_count = sum(
        int(
            row[
                "source_table_multivariable_alexander_numerator_skipped_candidate_count"
            ]
        )
        for row in source_table_alexander_rows
    )
    source_table_alexander_numerator_missing_candidate_count = sum(
        int(
            row[
                "source_table_multivariable_alexander_numerator_missing_candidate_count"
            ]
        )
        for row in source_table_alexander_rows
    )
    source_table_alexander_numerator_source_divisibility_checked_candidate_count = sum(
        int(
            row[
                "source_table_multivariable_alexander_numerator_source_divisibility_checked_candidate_count"
            ]
        )
        for row in source_table_alexander_rows
    )
    source_table_alexander_numerator_source_divisibility_source_divides_all_candidate_count = sum(
        int(
            row[
                "source_table_multivariable_alexander_numerator_source_divisibility_source_divides_all_candidate_count"
            ]
        )
        for row in source_table_alexander_rows
    )
    source_table_alexander_numerator_source_divisibility_source_division_failed_candidate_count = sum(
        int(
            row[
                "source_table_multivariable_alexander_numerator_source_divisibility_source_division_failed_candidate_count"
            ]
        )
        for row in source_table_alexander_rows
    )
    source_table_alexander_numerator_source_divisibility_all_checked_candidates_divisible_count = sum(
        1
        for row in source_table_alexander_rows
        if row[
            "source_table_multivariable_alexander_numerator_source_divisibility_all_checked_candidates_divisible"
        ]
    )
    source_table_alexander_numerator_source_divisibility_statuses = sorted(
        {
            str(status)
            for row in source_table_alexander_rows
            for status in row[
                "source_table_multivariable_alexander_numerator_source_divisibility_statuses"
            ]
        }
    )
    source_table_alexander_numerator_source_divisibility_status_count_map: dict[
        str,
        int,
    ] = {}
    for row in source_table_alexander_rows:
        for status_count in row[
            "source_table_multivariable_alexander_numerator_source_divisibility_status_counts"
        ]:
            status = str(status_count.get("status") or "")
            if not status:
                continue
            source_table_alexander_numerator_source_divisibility_status_count_map[
                status
            ] = (
                source_table_alexander_numerator_source_divisibility_status_count_map.get(
                    status,
                    0,
                )
                + int(status_count.get("candidate_count", 0) or 0)
            )
    source_table_alexander_numerator_source_divisibility_status_counts = [
        {
            "status": status,
            "candidate_count": (
                source_table_alexander_numerator_source_divisibility_status_count_map[
                    status
                ]
            ),
        }
        for status in sorted(
            source_table_alexander_numerator_source_divisibility_status_count_map
        )
    ]
    source_table_alexander_numerator_source_divisibility_failure_status_counts = [
        status_count
        for status_count in source_table_alexander_numerator_source_divisibility_status_counts
        if status_count["status"] != "all_inputs_divisible"
    ]
    source_table_alexander_numerator_source_divisibility_checked_rows = [
        row
        for row in source_table_alexander_rows
        if int(
            row[
                "source_table_multivariable_alexander_numerator_source_divisibility_checked_candidate_count"
            ]
        )
        > 0
    ]
    source_table_alexander_numerator_source_divisibility_failed_input_count_min = (
        min(
            int(
                row[
                    "source_table_multivariable_alexander_numerator_source_divisibility_failed_input_count_min"
                ]
            )
            for row in source_table_alexander_numerator_source_divisibility_checked_rows
        )
        if source_table_alexander_numerator_source_divisibility_checked_rows
        else 0
    )
    source_table_alexander_numerator_source_divisibility_failed_input_count_max = (
        max(
            int(
                row[
                    "source_table_multivariable_alexander_numerator_source_divisibility_failed_input_count_max"
                ]
            )
            for row in source_table_alexander_numerator_source_divisibility_checked_rows
        )
        if source_table_alexander_numerator_source_divisibility_checked_rows
        else 0
    )
    source_table_alexander_numerator_source_divisibility_unique_input_polynomial_count_min = (
        min(
            int(
                row[
                    "source_table_multivariable_alexander_numerator_source_divisibility_unique_input_polynomial_count_min"
                ]
            )
            for row in source_table_alexander_numerator_source_divisibility_checked_rows
        )
        if source_table_alexander_numerator_source_divisibility_checked_rows
        else 0
    )
    source_table_alexander_numerator_source_divisibility_unique_input_polynomial_count_max = (
        max(
            int(
                row[
                    "source_table_multivariable_alexander_numerator_source_divisibility_unique_input_polynomial_count_max"
                ]
            )
            for row in source_table_alexander_numerator_source_divisibility_checked_rows
        )
        if source_table_alexander_numerator_source_divisibility_checked_rows
        else 0
    )
    source_table_alexander_numerator_source_divisibility_first_failed_row = next(
        (
            row
            for row in source_table_alexander_rows
            if row[
                "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_input_polynomial"
            ]
            is not None
        ),
        None,
    )
    source_table_alexander_numerator_source_divisibility_failed_candidate_witness_limit = (
        _ALEXANDER_AUDIT_WITNESS_LIMIT
    )
    source_table_alexander_numerator_source_divisibility_failed_candidate_witnesses = []
    source_table_alexander_numerator_source_divisibility_failed_candidate_witness_count = (
        0
    )
    for row in source_table_alexander_rows:
        summary = row[
            "source_table_multivariable_alexander_numerator_source_divisibility_failed_candidate_witness_summary"
        ]
        if not isinstance(summary, dict):
            continue
        source_table_alexander_numerator_source_divisibility_failed_candidate_witness_count += _blocker_int(
            summary.get("failed_candidate_witness_count", 0)
        )
        for witness in _dict_sequence(summary.get("failed_candidate_witnesses", [])):
            if (
                len(
                    source_table_alexander_numerator_source_divisibility_failed_candidate_witnesses
                )
                >= source_table_alexander_numerator_source_divisibility_failed_candidate_witness_limit
            ):
                break
            source_table_alexander_numerator_source_divisibility_failed_candidate_witnesses.append(
                {
                    "notation": row["notation"],
                    **witness,
                }
            )
    source_table_alexander_numerator_source_divisibility_failed_candidate_witness_truncated = (
        source_table_alexander_numerator_source_divisibility_failed_candidate_witness_count
        > len(
            source_table_alexander_numerator_source_divisibility_failed_candidate_witnesses
        )
    )
    source_table_alexander_numerator_source_divisibility_failed_candidate_witness_consistency = (
        _bounded_witness_consistency_summary(
            witness_kind=(
                "source_table_alexander_source_divisibility_failed_candidate"
            ),
            witness_count=(
                source_table_alexander_numerator_source_divisibility_failed_candidate_witness_count
            ),
            witness_limit=(
                source_table_alexander_numerator_source_divisibility_failed_candidate_witness_limit
            ),
            witness_truncated=(
                source_table_alexander_numerator_source_divisibility_failed_candidate_witness_truncated
            ),
            witnesses=(
                source_table_alexander_numerator_source_divisibility_failed_candidate_witnesses
            ),
        )
    )
    source_table_alexander_numerator_source_divisibility_first_failed_candidate_witness = (
        source_table_alexander_numerator_source_divisibility_failed_candidate_witnesses[0]
        if source_table_alexander_numerator_source_divisibility_failed_candidate_witnesses
        else None
    )
    source_table_alexander_numerator_link_normalization_rows = [
        row
        for row in source_table_alexander_rows
        if row.get(
            "source_table_alexander_numerator_link_normalization_checked"
        )
    ]
    source_table_alexander_numerator_link_normalization_checked_count = len(
        source_table_alexander_numerator_link_normalization_rows
    )
    source_table_alexander_numerator_link_normalization_ready_rows = [
        row
        for row in source_table_alexander_numerator_link_normalization_rows
        if row.get("source_table_alexander_numerator_link_normalization_ready")
    ]
    source_table_alexander_numerator_link_normalization_ready_count = len(
        source_table_alexander_numerator_link_normalization_ready_rows
    )
    source_table_alexander_numerator_link_normalization_blocked_rows = [
        row
        for row in source_table_alexander_numerator_link_normalization_rows
        if not row.get("source_table_alexander_numerator_link_normalization_ready")
    ]
    source_table_alexander_numerator_link_normalization_blocked_count = len(
        source_table_alexander_numerator_link_normalization_blocked_rows
    )
    source_table_alexander_numerator_link_normalization_ready_notations = [
        row["notation"]
        for row in source_table_alexander_numerator_link_normalization_ready_rows
    ]
    source_table_alexander_numerator_link_normalization_blocked_notations = [
        row["notation"]
        for row in source_table_alexander_numerator_link_normalization_blocked_rows
    ]
    source_table_alexander_numerator_link_normalization_blocker_count = sum(
        _blocker_int(
            row.get(
                "source_table_alexander_numerator_link_normalization_blocker_count",
                0,
            )
        )
        for row in source_table_alexander_numerator_link_normalization_rows
    )
    source_table_alexander_numerator_link_normalization_blocker_count_map: dict[
        str,
        int,
    ] = {}
    for row in source_table_alexander_numerator_link_normalization_rows:
        blockers = row.get(
            "source_table_alexander_numerator_link_normalization_blockers",
            [],
        )
        if not isinstance(blockers, list):
            continue
        for blocker in blockers:
            blocker_key = str(blocker)
            if not blocker_key:
                continue
            source_table_alexander_numerator_link_normalization_blocker_count_map[
                blocker_key
            ] = (
                source_table_alexander_numerator_link_normalization_blocker_count_map.get(
                    blocker_key,
                    0,
                )
                + 1
            )
    source_table_alexander_numerator_link_normalization_blocker_counts = [
        {
            "blocker": blocker,
            "fixture_count": source_table_alexander_numerator_link_normalization_blocker_count_map[
                blocker
            ],
        }
        for blocker in sorted(
            source_table_alexander_numerator_link_normalization_blocker_count_map
        )
    ]
    source_table_alexander_numerator_link_normalization_blockers = [
        row["blocker"]
        for row in source_table_alexander_numerator_link_normalization_blocker_counts
    ]
    accepted_count = sum(1 for row in rows if row["accepted"])
    incomplete = [row["notation"] for row in rows if not row["accepted"]]
    required_check_count = sum(row["required_check_count"] for row in rows)
    passed_check_count = sum(row["passed_check_count"] for row in rows)
    failed_check_count = max(0, required_check_count - passed_check_count)

    return {
        "method": "multivariable_alexander_fixture_acceptance_report",
        "claim_scope": "registered_fixture_acceptance_under_iroll_convention",
        "bounded_certification_scope": (
            "exact_scanned_fox_minor_gcd_for_registered_signed_pd_inputs"
        ),
        "registered_knot_admissible_normalization_scope": (
            "registered_one_component_signed_pd_complete_minor_scan_with_expected_value_match"
        ),
        "zero_crossing_unlink_normalization_scope": (
            "registered_zero_crossing_unlink_terminal_normalization"
        ),
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "include_unregistered": include_unregistered,
        "fixture_count": len(rows),
        "accepted": accepted_count == len(rows),
        "accepted_count": accepted_count,
        "incomplete_notations": incomplete,
        "comparison_checked_count": comparison_checked,
        "comparison_matched_count": comparison_matched,
        "minor_divisibility_audit_checked_count": audit_checked,
        "minor_divisibility_audit_matched_count": audit_matched,
        "scanned_gcd_audit_checked_count": scanned_gcd_checked,
        "scanned_gcd_audit_matched_count": scanned_gcd_matched,
        "wirtinger_fox_audit_checked_count": wirtinger_fox_checked,
        "wirtinger_fox_audit_matched_count": wirtinger_fox_matched,
        "wirtinger_fox_relation_count": wirtinger_fox_relation_count,
        "wirtinger_fox_generator_count": wirtinger_fox_generator_count,
        "wirtinger_fox_scanned_minor_count": wirtinger_fox_scanned_minor_count,
        "wirtinger_fox_invalid_minor_reference_count": (
            wirtinger_fox_invalid_minor_reference_count
        ),
        "wirtinger_fox_invalid_normalization_count": (
            wirtinger_fox_invalid_normalization_count
        ),
        "wirtinger_fox_complete_scan_count": wirtinger_fox_complete_scan_count,
        "wirtinger_fox_truncated_count": wirtinger_fox_truncated_count,
        "bounded_scanned_gcd_certification_applicable_count": (
            bounded_scanned_gcd_certification_applicable_count
        ),
        "bounded_scanned_gcd_certified_count": (
            bounded_scanned_gcd_certified_count
        ),
        "bounded_scanned_gcd_uncertified_count": (
            bounded_scanned_gcd_uncertified_count
        ),
        "bounded_scanned_gcd_checked_nonzero_minor_count": (
            bounded_scanned_gcd_checked_nonzero_minor_count
        ),
        "bounded_scanned_gcd_failed_nonzero_minor_count": (
            bounded_scanned_gcd_failed_nonzero_minor_count
        ),
        "bounded_scanned_gcd_scanned_minor_count": (
            bounded_scanned_gcd_scanned_minor_count
        ),
        "bounded_scanned_gcd_division_record_count": (
            bounded_scanned_gcd_division_record_count
        ),
        "bounded_scanned_gcd_expected_minor_combination_count": (
            bounded_scanned_gcd_expected_combination_count
        ),
        "bounded_scanned_gcd_nonzero_minor_count": (
            bounded_scanned_gcd_nonzero_minor_count
        ),
        "bounded_scanned_gcd_zero_minor_count": (
            bounded_scanned_gcd_zero_minor_count
        ),
        "bounded_scanned_gcd_unit_minor_count": (
            bounded_scanned_gcd_unit_minor_count
        ),
        "bounded_scanned_gcd_unique_nonzero_polynomial_count": (
            bounded_scanned_gcd_unique_nonzero_polynomial_count
        ),
        "bounded_scanned_gcd_all_rows_have_nonzero_minor_count": (
            bounded_scanned_gcd_all_rows_have_nonzero_minor_count
        ),
        "bounded_scanned_gcd_all_columns_have_nonzero_minor_count": (
            bounded_scanned_gcd_all_columns_have_nonzero_minor_count
        ),
        "bounded_scanned_gcd_complete_scan_count": (
            bounded_scanned_gcd_complete_scan_count
        ),
        "bounded_scanned_gcd_nonzero_minor_coverage_complete_count": (
            bounded_scanned_gcd_nonzero_minor_coverage_complete_count
        ),
        "bounded_scanned_gcd_truncated_count": (
            bounded_scanned_gcd_truncated_count
        ),
        "bounded_scanned_gcd_quotient_gcd_certified_count": (
            bounded_scanned_gcd_quotient_gcd_certified_count
        ),
        "bounded_scanned_gcd_complete_certified_count": (
            bounded_scanned_gcd_complete_certified_count
        ),
        "bounded_scanned_gcd_improved_candidate_count": (
            bounded_scanned_gcd_improved_candidate_count
        ),
        "bounded_alexander_maturity_path_counts": (
            bounded_alexander_maturity_path_counts
        ),
        "bounded_alexander_maturity_path_distinct_count": len(
            bounded_alexander_maturity_path_counts
        ),
        "bounded_alexander_maturity_path_certified_count": (
            bounded_alexander_maturity_path_certified_count
        ),
        "bounded_alexander_maturity_path_summary_consistency": (
            bounded_alexander_maturity_path_summary_consistency
        ),
        "zero_crossing_unlink_normalization_applicable_count": (
            zero_crossing_unlink_normalization_applicable_count
        ),
        "zero_crossing_unlink_normalization_certified_count": (
            zero_crossing_unlink_normalization_certified_count
        ),
        "zero_crossing_unlink_normalization_uncertified_count": (
            zero_crossing_unlink_normalization_uncertified_count
        ),
        "input_certification_zero_crossing_count": (
            zero_crossing_unlink_normalization_certified_count
        ),
        "registered_knot_admissible_normalization_applicable_count": (
            registered_knot_admissible_normalization_applicable_count
        ),
        "registered_knot_admissible_normalization_certified_count": (
            registered_knot_admissible_normalization_certified_count
        ),
        "registered_knot_admissible_normalization_uncertified_count": (
            registered_knot_admissible_normalization_uncertified_count
        ),
        "source_table_invariant_audit_applicable_count": (
            source_table_invariant_audit_applicable_count
        ),
        "source_table_registration_checked_count": (
            source_table_registration_checked_count
        ),
        "source_table_registration_ready_count": (
            source_table_registration_ready_count
        ),
        "source_table_registration_blocked_count": (
            source_table_registration_blocked_count
        ),
        "source_table_registration_blocker_count": (
            source_table_registration_blocker_count
        ),
        "source_table_registration_blockers": source_table_registration_blockers,
        "source_table_registration_blocker_counts": (
            source_table_registration_blocker_counts
        ),
        "source_table_registration_blocked_notations": (
            source_table_registration_blocked_notations
        ),
        "source_table_registration_ready_notations": (
            source_table_registration_ready_notations
        ),
        "source_table_registration_summary_consistency": (
            source_table_registration_summary_consistency
        ),
        "source_table_multivariable_alexander_numerator_checked_count": (
            source_table_alexander_numerator_checked_count
        ),
        "source_table_multivariable_alexander_numerator_source_seen_count": (
            source_table_alexander_numerator_source_seen_count
        ),
        "source_table_multivariable_alexander_numerator_complete_match_count": (
            source_table_alexander_numerator_complete_match_count
        ),
        "source_table_multivariable_alexander_numerator_returned_match_count": (
            source_table_alexander_numerator_returned_match_count
        ),
        "source_table_multivariable_alexander_numerator_incomplete_or_unstable_count": (
            source_table_alexander_numerator_incomplete_or_unstable_count
        ),
        "source_table_multivariable_alexander_numerator_candidate_unique_value_count": (
            source_table_alexander_numerator_candidate_unique_value_count
        ),
        "source_table_multivariable_alexander_numerator_computed_candidate_count": (
            source_table_alexander_numerator_computed_candidate_count
        ),
        "source_table_multivariable_alexander_numerator_skipped_candidate_count": (
            source_table_alexander_numerator_skipped_candidate_count
        ),
        "source_table_multivariable_alexander_numerator_missing_candidate_count": (
            source_table_alexander_numerator_missing_candidate_count
        ),
        "source_table_alexander_numerator_link_normalization_checked_count": (
            source_table_alexander_numerator_link_normalization_checked_count
        ),
        "source_table_alexander_numerator_link_normalization_ready_count": (
            source_table_alexander_numerator_link_normalization_ready_count
        ),
        "source_table_alexander_numerator_link_normalization_blocked_count": (
            source_table_alexander_numerator_link_normalization_blocked_count
        ),
        "source_table_alexander_numerator_link_normalization_blocker_count": (
            source_table_alexander_numerator_link_normalization_blocker_count
        ),
        "source_table_alexander_numerator_link_normalization_blockers": (
            source_table_alexander_numerator_link_normalization_blockers
        ),
        "source_table_alexander_numerator_link_normalization_blocker_counts": (
            source_table_alexander_numerator_link_normalization_blocker_counts
        ),
        "source_table_alexander_numerator_link_normalization_ready_notations": (
            source_table_alexander_numerator_link_normalization_ready_notations
        ),
        "source_table_alexander_numerator_link_normalization_blocked_notations": (
            source_table_alexander_numerator_link_normalization_blocked_notations
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_checked_candidate_count": (
            source_table_alexander_numerator_source_divisibility_checked_candidate_count
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_source_divides_all_candidate_count": (
            source_table_alexander_numerator_source_divisibility_source_divides_all_candidate_count
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_source_division_failed_candidate_count": (
            source_table_alexander_numerator_source_divisibility_source_division_failed_candidate_count
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_all_checked_candidates_divisible_count": (
            source_table_alexander_numerator_source_divisibility_all_checked_candidates_divisible_count
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_statuses": (
            source_table_alexander_numerator_source_divisibility_statuses
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_status_counts": (
            source_table_alexander_numerator_source_divisibility_status_counts
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_failure_status_counts": (
            source_table_alexander_numerator_source_divisibility_failure_status_counts
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_failed_input_count_min": (
            source_table_alexander_numerator_source_divisibility_failed_input_count_min
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_failed_input_count_max": (
            source_table_alexander_numerator_source_divisibility_failed_input_count_max
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_unique_input_polynomial_count_min": (
            source_table_alexander_numerator_source_divisibility_unique_input_polynomial_count_min
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_unique_input_polynomial_count_max": (
            source_table_alexander_numerator_source_divisibility_unique_input_polynomial_count_max
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_notation": (
            source_table_alexander_numerator_source_divisibility_first_failed_row[
                "notation"
            ]
            if source_table_alexander_numerator_source_divisibility_first_failed_row
            is not None
            else None
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_candidate_index": (
            source_table_alexander_numerator_source_divisibility_first_failed_row[
                "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_candidate_index"
            ]
            if source_table_alexander_numerator_source_divisibility_first_failed_row
            is not None
            else None
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_input_polynomial": (
            source_table_alexander_numerator_source_divisibility_first_failed_row[
                "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_input_polynomial"
            ]
            if source_table_alexander_numerator_source_divisibility_first_failed_row
            is not None
            else None
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_failed_candidate_witness_count": (
            source_table_alexander_numerator_source_divisibility_failed_candidate_witness_count
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_failed_candidate_witness_limit": (
            source_table_alexander_numerator_source_divisibility_failed_candidate_witness_limit
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_failed_candidate_witness_truncated": (
            source_table_alexander_numerator_source_divisibility_failed_candidate_witness_truncated
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_failed_candidate_witnesses": (
            source_table_alexander_numerator_source_divisibility_failed_candidate_witnesses
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_candidate_witness": (
            source_table_alexander_numerator_source_divisibility_first_failed_candidate_witness
        ),
        "source_table_multivariable_alexander_numerator_source_divisibility_failed_candidate_witness_consistency": (
            source_table_alexander_numerator_source_divisibility_failed_candidate_witness_consistency
        ),
        "required_check_count": required_check_count,
        "passed_check_count": passed_check_count,
        "failed_check_count": failed_check_count,
        "fixtures": rows,
        "notes": [
            "this report aggregates signed-PD fixture comparison, Wirtinger/Fox input-chain consistency, bounded Fox-minor divisibility evidence, and exact scanned-gcd evidence",
            "bounded scanned-gcd certification is limited to the scanned Fox-minor set for each registered signed-PD fixture",
            "zero-crossing unlink fixtures are certified only through terminal normalization because no Wirtinger/Fox presentation exists",
            "registered one-component knot normalization evidence is scoped to fixtures with complete nonzero-minor coverage and expected-value matches",
            "unregistered source-table fixtures may carry source-Gauss-matched Alexander numerator candidate audits as convention evidence only",
            "source-table Alexander numerator link-normalization readiness does not register fixture signs or certify full admissible-minor normalization",
            "it is not a full multivariate Laurent gcd or fixture-certified multi-component admissible-minor normalization claim",
        ],
    }


def multivariable_alexander_signed_pd_coverage_report(
    notations: Iterable[str] | None = None,
    *,
    max_matrix_size: int = 4,
    max_minors: int = 64,
    branch_depth: int = 1,
) -> dict:
    """Audit Alexander Wirtinger/Fox coverage on generated signed-PD inputs.

    The report uses the same fixture roots and bounded signed-PD branch
    generation as the HOMFLY small-diagram coverage audit, then verifies the
    Alexander input chain through Wirtinger/Fox consistency and exact scanned
    Fox-minor gcd evidence. It deliberately does not claim full admissible-minor
    normalization or arbitrary signed-diagram coverage.
    """

    from iroll.topology.homfly import _generated_skein_branch_inputs
    from iroll.topology.pd_fixtures import get_diagram_fixture

    selected_notations = tuple(notations) if notations is not None else (
        "L2a1",
        "3_1",
        "4_1",
    )
    cases: list[dict] = []
    relation_error_count = 0
    nonzero_evaluation_cache: dict[tuple[str, str, int, int], dict] = {}
    nonzero_reused_evaluation_count = 0
    nonzero_evaluation_stats_by_source: dict[str, dict[str, int]] = {}

    for notation in selected_notations:
        fixture = get_diagram_fixture(notation)
        source_evaluation_stats = nonzero_evaluation_stats_by_source.setdefault(
            fixture.notation,
            {
                "nonzero_evaluated_case_count": 0,
                "nonzero_cache_miss_evaluation_count": 0,
                "nonzero_cache_hit_evaluation_count": 0,
            },
        )
        if not fixture.has_signed_pd:
            cases.append(
                _multivariable_alexander_signed_pd_coverage_skipped_case(
                    source_notation=fixture.notation,
                    source_kind="fixture_without_signed_pd",
                    crossing_index=None,
                    branch=None,
                    crossing_count=int(len(fixture.pd_code or ())),
                    component_count=fixture.component_count,
                    diagram_key=None,
                    notes=["fixture does not have a signed-PD diagram"],
                )
            )
            continue

        diagram = fixture.diagram()
        orientation = fixture.orientation()
        branch_inputs, relation_errors = _generated_skein_branch_inputs(
            source_notation=fixture.notation,
            diagram=diagram,
            orientation=orientation,
            branch_depth=branch_depth,
        )
        relation_error_count += len(relation_errors)
        for branch_input in branch_inputs:
            evaluation = None
            if not (
                branch_input["diagram"].crossing_count == 0
                and not branch_input["diagram"].edge_labels
            ):
                evaluation_key = _multivariable_alexander_signed_pd_coverage_evaluation_key(
                    branch_input["diagram"],
                    branch_input["orientation"],
                    max_matrix_size=max_matrix_size,
                    max_minors=max_minors,
                )
                source_evaluation_stats["nonzero_evaluated_case_count"] += 1
                evaluation = nonzero_evaluation_cache.get(evaluation_key)
                if evaluation is None:
                    evaluation = (
                        _multivariable_alexander_signed_pd_coverage_evaluation_fields(
                            branch_input["diagram"],
                            branch_input["orientation"],
                            max_matrix_size=max_matrix_size,
                            max_minors=max_minors,
                        )
                    )
                    nonzero_evaluation_cache[evaluation_key] = evaluation
                    source_evaluation_stats[
                        "nonzero_cache_miss_evaluation_count"
                    ] += 1
                else:
                    nonzero_reused_evaluation_count += 1
                    source_evaluation_stats[
                        "nonzero_cache_hit_evaluation_count"
                    ] += 1
            cases.append(
                _multivariable_alexander_signed_pd_coverage_case(
                    source_notation=fixture.notation,
                    source_kind=branch_input["source_kind"],
                    crossing_index=branch_input["crossing_index"],
                    branch=branch_input["branch"],
                    branch_depth=branch_input["branch_depth"],
                    branch_path=branch_input["branch_path"],
                    parent_case_id=branch_input["parent_case_id"],
                    case_id=branch_input["case_id"],
                    diagram=branch_input["diagram"],
                    orientation=branch_input["orientation"],
                    max_matrix_size=max_matrix_size,
                    max_minors=max_minors,
                    evaluation=evaluation,
                )
            )
        for error in relation_errors:
            cases.append(
                _multivariable_alexander_signed_pd_coverage_skipped_case(
                    source_notation=fixture.notation,
                    source_kind=error["source_kind"],
                    crossing_index=error["crossing_index"],
                    branch=None,
                    branch_depth=error["branch_depth"],
                    branch_path=error["branch_path"],
                    parent_case_id=error["parent_case_id"],
                    case_id=error["case_id"],
                    crossing_count=error["diagram"].crossing_count,
                    component_count=error["diagram"].component_count,
                    diagram_key=repr(error["diagram"].canonical_key()),
                    notes=[error["error"]],
                )
            )
    case_count = len(cases)
    accepted_case_count = sum(1 for case in cases if case["accepted"])
    skipped_case_count = sum(1 for case in cases if case["result_skipped"])
    nonzero_evaluated_result_skipped_case_count = sum(
        1
        for case in cases
        if case["result_skipped"]
        and case.get("orientation_key") is not None
        and not case.get("zero_crossing_unlink_certified", False)
    )
    unevaluated_skipped_case_count = (
        skipped_case_count - nonzero_evaluated_result_skipped_case_count
    )
    truncated_case_count = sum(1 for case in cases if case["truncated"])
    non_fixture_case_count = sum(
        1 for case in cases if case["source_kind"] != "fixture_root"
    )
    unique_diagram_keys = {
        case["diagram_key"]
        for case in cases
        if case["diagram_key"] is not None
    }
    unique_oriented_diagram_keys = {
        (case["diagram_key"], case["orientation_key"])
        for case in cases
        if case["diagram_key"] is not None and case.get("orientation_key") is not None
    }
    source_notation_summary = _multivariable_alexander_source_notation_coverage_summary(
        cases,
        selected_notations,
        nonzero_evaluation_stats_by_source,
    )
    accepted = (
        case_count > 0
        and accepted_case_count == case_count
        and skipped_case_count == 0
        and truncated_case_count == 0
        and relation_error_count == 0
    )
    bounded_alexander_maturity_path_counts = (
        _alexander_coverage_count_records_by_string_field(
            cases,
            "bounded_alexander_maturity_path",
            "bounded_alexander_maturity_path",
        )
    )
    bounded_alexander_maturity_path_certified_count = sum(
        1
        for case in cases
        if case.get("bounded_alexander_maturity_path_certified", False)
    )
    bounded_alexander_maturity_path_summary_consistency = (
        _bounded_alexander_maturity_path_summary_consistency(
            cases,
            reported_path_counts=bounded_alexander_maturity_path_counts,
            reported_distinct_count=len(bounded_alexander_maturity_path_counts),
            reported_certified_count=bounded_alexander_maturity_path_certified_count,
            count_key="case_count",
        )
    )
    zero_crossing_unlink_case_count = sum(
        1 for case in cases if case.get("zero_crossing_unlink_certified", False)
    )
    uncertified_case_count = case_count - accepted_case_count
    scanned_minor_count = sum(int(case["scanned_minor_count"]) for case in cases)
    expected_minor_combination_count = sum(
        int(case.get("expected_combination_count", 0) or 0) for case in cases
    )
    nonzero_minor_count = sum(
        int(case.get("nonzero_minor_count", 0) or 0) for case in cases
    )
    zero_minor_count = sum(
        int(case.get("zero_minor_count", 0) or 0) for case in cases
    )
    unit_minor_count = sum(
        int(case.get("unit_minor_count", 0) or 0) for case in cases
    )
    nonzero_unique_evaluation_count = len(nonzero_evaluation_cache)
    nonzero_evaluated_case_count = (
        nonzero_unique_evaluation_count + nonzero_reused_evaluation_count
    )
    nonzero_evaluation_accounted_case_count = (
        nonzero_evaluated_case_count
        + zero_crossing_unlink_case_count
        + unevaluated_skipped_case_count
    )
    source_notation_cache_counts = []
    for row in source_notation_summary:
        source_case_count = int(row["case_count"])
        source_nonzero_evaluated_case_count = int(
            row["nonzero_evaluated_case_count"]
        )
        source_nonzero_cache_miss_evaluation_count = int(
            row["nonzero_cache_miss_evaluation_count"]
        )
        source_nonzero_cache_hit_evaluation_count = int(
            row["nonzero_cache_hit_evaluation_count"]
        )
        source_zero_crossing_unlink_case_count = int(
            row["zero_crossing_unlink_certified_case_count"]
        )
        source_result_skipped_case_count = int(row["result_skipped_case_count"])
        source_nonzero_evaluated_result_skipped_case_count = int(
            row["nonzero_evaluated_result_skipped_case_count"]
        )
        source_unevaluated_skipped_case_count = int(
            row["unevaluated_skipped_case_count"]
        )
        source_accounted_case_count = (
            source_nonzero_evaluated_case_count
            + source_zero_crossing_unlink_case_count
            + source_unevaluated_skipped_case_count
        )
        source_notation_cache_counts.append(
            {
                "source_notation": row["source_notation"],
                "case_count": source_case_count,
                "nonzero_evaluated_case_count": source_nonzero_evaluated_case_count,
                "nonzero_cache_miss_evaluation_count": (
                    source_nonzero_cache_miss_evaluation_count
                ),
                "nonzero_cache_hit_evaluation_count": (
                    source_nonzero_cache_hit_evaluation_count
                ),
                "zero_crossing_unlink_case_count": (
                    source_zero_crossing_unlink_case_count
                ),
                "result_skipped_case_count": source_result_skipped_case_count,
                "nonzero_evaluated_result_skipped_case_count": (
                    source_nonzero_evaluated_result_skipped_case_count
                ),
                "unevaluated_skipped_case_count": (
                    source_unevaluated_skipped_case_count
                ),
                "accounted_case_count": source_accounted_case_count,
                "nonzero_evaluation_cache_accounted": row[
                    "nonzero_evaluation_cache_accounted"
                ],
                "case_accounting_complete": (
                    source_accounted_case_count == source_case_count
                ),
                "nonzero_evaluation_cache_reuse_observed": row[
                    "nonzero_evaluation_cache_reuse_observed"
                ],
            }
        )
    source_total_case_count = sum(
        row["case_count"] for row in source_notation_cache_counts
    )
    source_total_nonzero_evaluated_case_count = sum(
        row["nonzero_evaluated_case_count"]
        for row in source_notation_cache_counts
    )
    source_total_nonzero_cache_miss_evaluation_count = sum(
        row["nonzero_cache_miss_evaluation_count"]
        for row in source_notation_cache_counts
    )
    source_total_nonzero_cache_hit_evaluation_count = sum(
        row["nonzero_cache_hit_evaluation_count"]
        for row in source_notation_cache_counts
    )
    source_total_zero_crossing_unlink_case_count = sum(
        row["zero_crossing_unlink_case_count"]
        for row in source_notation_cache_counts
    )
    source_total_result_skipped_case_count = sum(
        row["result_skipped_case_count"] for row in source_notation_cache_counts
    )
    source_total_nonzero_evaluated_result_skipped_case_count = sum(
        row["nonzero_evaluated_result_skipped_case_count"]
        for row in source_notation_cache_counts
    )
    source_total_unevaluated_skipped_case_count = sum(
        row["unevaluated_skipped_case_count"]
        for row in source_notation_cache_counts
    )
    source_total_accounted_case_count = sum(
        row["accounted_case_count"] for row in source_notation_cache_counts
    )
    source_cache_totals_match_report = (
        source_total_case_count == case_count
        and source_total_nonzero_evaluated_case_count == nonzero_evaluated_case_count
        and source_total_nonzero_cache_miss_evaluation_count
        == nonzero_unique_evaluation_count
        and source_total_nonzero_cache_hit_evaluation_count
        == nonzero_reused_evaluation_count
        and source_total_zero_crossing_unlink_case_count
        == zero_crossing_unlink_case_count
        and source_total_result_skipped_case_count == skipped_case_count
        and source_total_nonzero_evaluated_result_skipped_case_count
        == nonzero_evaluated_result_skipped_case_count
        and source_total_unevaluated_skipped_case_count
        == unevaluated_skipped_case_count
        and source_total_accounted_case_count
        == nonzero_evaluation_accounted_case_count
    )
    source_case_accounting_complete = source_cache_totals_match_report and all(
        row["nonzero_evaluation_cache_accounted"]
        and row["case_accounting_complete"]
        for row in source_notation_cache_counts
    )
    nonzero_evaluation_cache_evidence = {
        "method": (
            "multivariable_alexander_signed_pd_coverage_nonzero_evaluation_cache_evidence"
        ),
        "claim_scope": "generated_signed_pd_nonzero_input_evaluation_reuse_accounting",
        "nonzero_evaluated_case_count": nonzero_evaluated_case_count,
        "nonzero_unique_evaluation_count": nonzero_unique_evaluation_count,
        "nonzero_reused_evaluation_count": nonzero_reused_evaluation_count,
        "nonzero_cache_reuse_observed": nonzero_reused_evaluation_count > 0,
        "zero_crossing_unlink_case_count": zero_crossing_unlink_case_count,
        "result_skipped_case_count": skipped_case_count,
        "nonzero_evaluated_result_skipped_case_count": (
            nonzero_evaluated_result_skipped_case_count
        ),
        "unevaluated_skipped_case_count": unevaluated_skipped_case_count,
        "accounted_case_count": nonzero_evaluation_accounted_case_count,
        "case_count": case_count,
        "nonzero_evaluation_accounting_complete": (
            nonzero_evaluation_accounted_case_count == case_count
        ),
        "source_notation_count": len(source_notation_cache_counts),
        "source_case_count": source_total_case_count,
        "source_nonzero_evaluated_case_count": (
            source_total_nonzero_evaluated_case_count
        ),
        "source_nonzero_cache_miss_evaluation_count": (
            source_total_nonzero_cache_miss_evaluation_count
        ),
        "source_nonzero_cache_hit_evaluation_count": (
            source_total_nonzero_cache_hit_evaluation_count
        ),
        "source_zero_crossing_unlink_case_count": (
            source_total_zero_crossing_unlink_case_count
        ),
        "source_result_skipped_case_count": source_total_result_skipped_case_count,
        "source_nonzero_evaluated_result_skipped_case_count": (
            source_total_nonzero_evaluated_result_skipped_case_count
        ),
        "source_unevaluated_skipped_case_count": (
            source_total_unevaluated_skipped_case_count
        ),
        "source_accounted_case_count": source_total_accounted_case_count,
        "source_cache_totals_match_report": source_cache_totals_match_report,
        "source_case_accounting_complete": source_case_accounting_complete,
        "source_notation_counts": source_notation_cache_counts,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": [
            "cache evidence records generated nonzero signed-PD evaluation reuse only",
            "zero-crossing unlink terminal cases are accounted separately because they bypass Wirtinger/Fox evaluation",
            "source totals are aggregated from source_notation_counts and compared with report-level counts",
            "this is runtime evidence for bounded generated coverage, not a stronger Alexander invariant claim",
        ],
    }
    report_count_totals = {
        "case_count": case_count,
        "accepted_case_count": accepted_case_count,
        "uncertified_case_count": uncertified_case_count,
        "result_skipped_case_count": skipped_case_count,
        "nonzero_evaluated_result_skipped_case_count": (
            nonzero_evaluated_result_skipped_case_count
        ),
        "unevaluated_skipped_case_count": unevaluated_skipped_case_count,
        "truncated_case_count": truncated_case_count,
        "zero_crossing_unlink_certified_case_count": zero_crossing_unlink_case_count,
        "scanned_minor_count": scanned_minor_count,
        "expected_minor_combination_count": expected_minor_combination_count,
        "nonzero_minor_count": nonzero_minor_count,
        "zero_minor_count": zero_minor_count,
        "unit_minor_count": unit_minor_count,
        "nonzero_evaluated_case_count": nonzero_evaluated_case_count,
        "nonzero_unique_evaluation_count": nonzero_unique_evaluation_count,
        "nonzero_reused_evaluation_count": nonzero_reused_evaluation_count,
    }
    source_notation_summary_consistency = (
        _multivariable_alexander_source_notation_summary_consistency(
            report_count_totals,
            source_notation_summary,
            fixture_count=len(selected_notations),
        )
    )

    return {
        "method": "multivariable_alexander_signed_pd_coverage_report",
        "claim_scope": "generated_small_signed_pd_wirtinger_fox_scanned_gcd_coverage",
        "source_notations": list(selected_notations),
        "fixture_count": len(selected_notations),
        "case_count": case_count,
        "non_fixture_case_count": non_fixture_case_count,
        "unique_diagram_count": len(unique_diagram_keys),
        "unique_oriented_diagram_count": len(unique_oriented_diagram_keys),
        "accepted_case_count": accepted_case_count,
        "uncertified_case_count": uncertified_case_count,
        "bounded_alexander_maturity_path_counts": (
            bounded_alexander_maturity_path_counts
        ),
        "bounded_alexander_maturity_path_distinct_count": len(
            bounded_alexander_maturity_path_counts
        ),
        "bounded_alexander_maturity_path_certified_count": (
            bounded_alexander_maturity_path_certified_count
        ),
        "bounded_alexander_maturity_path_summary_consistency": (
            bounded_alexander_maturity_path_summary_consistency
        ),
        "result_skipped_case_count": skipped_case_count,
        "nonzero_evaluated_result_skipped_case_count": (
            nonzero_evaluated_result_skipped_case_count
        ),
        "unevaluated_skipped_case_count": unevaluated_skipped_case_count,
        "truncated_case_count": truncated_case_count,
        "relation_error_count": relation_error_count,
        "minor_divisibility_matched_case_count": sum(
            1 for case in cases if case["minor_divisibility_matched"]
        ),
        "bounded_scanned_gcd_certified_case_count": sum(
            1 for case in cases if case["bounded_scanned_gcd_certified"]
        ),
        "complete_scanned_gcd_certified_case_count": sum(
            1 for case in cases if case.get("complete_scanned_gcd_certified", False)
        ),
        "wirtinger_fox_matched_case_count": sum(
            1 for case in cases if case["wirtinger_fox_matched"]
        ),
        "zero_crossing_unlink_certified_case_count": zero_crossing_unlink_case_count,
        "complete_scan_case_count": sum(
            1 for case in cases if case["complete_combination_scan"]
        ),
        "nonzero_minor_coverage_complete_case_count": sum(
            1 for case in cases if case["nonzero_minor_coverage_complete"]
        ),
        "scanned_minor_count": scanned_minor_count,
        "expected_combination_count": expected_minor_combination_count,
        "expected_minor_combination_count": expected_minor_combination_count,
        "nonzero_minor_count": nonzero_minor_count,
        "zero_minor_count": zero_minor_count,
        "unit_minor_count": unit_minor_count,
        "unique_nonzero_polynomial_count": sum(
            int(case.get("unique_nonzero_polynomial_count", 0) or 0)
            for case in cases
        ),
        "admissible_minor_normalization_mismatch_witness_count": sum(
            int(
                case.get(
                    "admissible_minor_normalization_mismatch_witness_count",
                    0,
                )
                or 0
            )
            for case in cases
        ),
        "admissible_minor_normalization_mismatch_witness_truncated_case_count": sum(
            1
            for case in cases
            if case.get(
                "admissible_minor_normalization_mismatch_witness_truncated"
            )
        ),
        "all_rows_have_nonzero_minor_case_count": sum(
            1 for case in cases if case.get("all_rows_have_nonzero_minor")
        ),
        "all_columns_have_nonzero_minor_case_count": sum(
            1 for case in cases if case.get("all_columns_have_nonzero_minor")
        ),
        "checked_nonzero_minor_count": sum(
            int(case["checked_nonzero_minor_count"]) for case in cases
        ),
        "failed_nonzero_minor_count": sum(
            int(case["failed_nonzero_minor_count"]) for case in cases
        ),
        "invalid_minor_reference_count": sum(
            int(case.get("invalid_minor_reference_count", 0) or 0) for case in cases
        ),
        "invalid_normalization_count": sum(
            int(case.get("invalid_normalization_count", 0) or 0) for case in cases
        ),
        "max_crossing_count": max(
            (int(case["crossing_count"]) for case in cases),
            default=0,
        ),
        "max_matrix_size": max_matrix_size,
        "max_minors": max_minors,
        "branch_depth": branch_depth,
        "nonzero_evaluated_case_count": nonzero_evaluated_case_count,
        "nonzero_unique_evaluation_count": nonzero_unique_evaluation_count,
        "nonzero_reused_evaluation_count": nonzero_reused_evaluation_count,
        "nonzero_evaluation_cache_evidence": nonzero_evaluation_cache_evidence,
        "max_generated_branch_depth": max(
            (int(case.get("branch_depth", 0) or 0) for case in cases),
            default=0,
        ),
        "accepted": accepted,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "arbitrary_diagram_coverage_certified": False,
        "source_notation_summary": source_notation_summary,
        "source_notation_summary_consistency": source_notation_summary_consistency,
        "cases": cases,
        "notes": [
            "generated cases include fixture roots and bounded positive/negative/smoothed signed-PD branch paths",
            "each nonzero-crossing case is accepted only when Wirtinger/Fox input-chain consistency and exact scanned Fox-minor gcd evidence both pass without truncation",
            "zero-crossing unlink terminal cases are accepted only through the explicit zero_crossing_unlink_normalization path",
            "this is generated small signed-PD input-chain coverage, not full admissible-minor normalization or arbitrary signed-diagram coverage",
        ],
    }


def _alexander_coverage_count_records_by_int_field(
    cases: Iterable[dict],
    field: str,
    output_key: str,
) -> list[dict]:
    counts: dict[int, int] = {}
    for case in cases:
        value = int(case.get(field, 0) or 0)
        counts[value] = counts.get(value, 0) + 1
    return [
        {output_key: value, "case_count": counts[value]}
        for value in sorted(counts)
    ]


def _alexander_coverage_count_records_by_string_field(
    cases: Iterable[dict],
    field: str,
    output_key: str,
) -> list[dict]:
    counts: dict[str, int] = {}
    for case in cases:
        raw_value = case.get(field)
        value = str(raw_value) if raw_value is not None else "none"
        counts[value] = counts.get(value, 0) + 1
    return [
        {output_key: value, "case_count": counts[value]}
        for value in sorted(counts)
    ]


def _bounded_alexander_maturity_path_summary_consistency(
    records: Iterable[dict],
    *,
    reported_path_counts: Sequence[dict],
    reported_distinct_count: int,
    reported_certified_count: int,
    count_key: str,
) -> dict:
    record_list = list(records)
    actual_path_counts = [
        {
            "bounded_alexander_maturity_path": path,
            count_key: sum(
                1
                for record in record_list
                if str(
                    record.get(
                        "bounded_alexander_maturity_path",
                        _ALEXANDER_MATURITY_NOT_CERTIFIED,
                    )
                    or _ALEXANDER_MATURITY_NOT_CERTIFIED
                )
                == path
            ),
        }
        for path in sorted(
            {
                str(
                    record.get(
                        "bounded_alexander_maturity_path",
                        _ALEXANDER_MATURITY_NOT_CERTIFIED,
                    )
                    or _ALEXANDER_MATURITY_NOT_CERTIFIED
                )
                for record in record_list
            }
        )
    ]
    actual_distinct_count = len(actual_path_counts)
    actual_certified_count = sum(
        1
        for record in record_list
        if record.get("bounded_alexander_maturity_path_certified", False)
    )
    path_count_total = sum(int(row.get(count_key, 0) or 0) for row in actual_path_counts)
    reported_path_count_total = sum(
        int(row.get(count_key, 0) or 0) for row in reported_path_counts
    )
    path_counts_match_report = list(reported_path_counts) == actual_path_counts
    distinct_count_matches_path_rows = reported_distinct_count == actual_distinct_count
    certified_count_matches_certified_paths = (
        reported_certified_count == actual_certified_count
    )
    path_count_total_matches_record_count = path_count_total == len(record_list)
    reported_path_count_total_matches_record_count = (
        reported_path_count_total == len(record_list)
    )
    matched = (
        path_counts_match_report
        and distinct_count_matches_path_rows
        and certified_count_matches_certified_paths
        and path_count_total_matches_record_count
        and reported_path_count_total_matches_record_count
    )
    return {
        "method": "bounded_alexander_maturity_path_summary_consistency",
        "claim_scope": "bounded_alexander_maturity_path_report_count_consistency",
        "matched": matched,
        "record_count": len(record_list),
        "count_key": count_key,
        "record_count_field": count_key,
        "reported_path_counts": list(reported_path_counts),
        "actual_path_counts": actual_path_counts,
        "path_counts_by_path": actual_path_counts,
        "path_counts_match_report": path_counts_match_report,
        "reported_path_count_total": reported_path_count_total,
        "path_count_total": path_count_total,
        "path_count_total_matches_record_count": path_count_total_matches_record_count,
        "reported_path_count_total_matches_record_count": (
            reported_path_count_total_matches_record_count
        ),
        "reported_distinct_count": reported_distinct_count,
        "actual_distinct_count": actual_distinct_count,
        "path_count_row_count": actual_distinct_count,
        "bounded_alexander_maturity_path_distinct_count": reported_distinct_count,
        "distinct_count_matches_path_rows": distinct_count_matches_path_rows,
        "distinct_count_matches_path_count_rows": distinct_count_matches_path_rows,
        "certified_count": reported_certified_count,
        "bounded_alexander_maturity_path_certified_count": reported_certified_count,
        "certified_path_count": actual_certified_count,
        "expected_bounded_alexander_maturity_path_certified_count": (
            actual_certified_count
        ),
        "certified_count_matches_certified_paths": (
            certified_count_matches_certified_paths
        ),
        "certified_count_matches_paths": certified_count_matches_certified_paths,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": [
            "checks bounded Alexander maturity-path root aggregates against emitted rows",
            "consistency evidence is not a full admissible-minor normalization certificate",
        ],
    }

def _multivariable_alexander_source_summary_mismatch_tags(field: str) -> list[str]:
    tags: list[str] = []
    if "source" in field:
        tags.append("source")
    if "case" in field:
        tags.append("case")
    if "minor" in field:
        tags.append("minor")
    if "skipped" in field:
        tags.append("skipped")
    if "zero_crossing" in field:
        tags.append("zero_crossing")
    if "nonzero" in field:
        tags.append("nonzero")
    if "count" in field:
        tags.append("count")
    return tags


def _multivariable_alexander_source_summary_mismatch_witness(
    *,
    kind: str,
    field: str,
    report_value,
    source_value,
) -> dict:
    return {
        "kind": kind,
        "field": field,
        "tags": _multivariable_alexander_source_summary_mismatch_tags(field),
        "report_value": report_value,
        "source_value": source_value,
    }


def _multivariable_alexander_source_notation_summary_consistency(
    report_count_totals: dict[str, int],
    source_notation_summary: Sequence[dict],
    *,
    fixture_count: int,
) -> dict:
    count_field_specs = [
        ("case_count", "case_count"),
        ("accepted_case_count", "accepted_case_count"),
        ("uncertified_case_count", "uncertified_case_count"),
        ("result_skipped_case_count", "result_skipped_case_count"),
        (
            "nonzero_evaluated_result_skipped_case_count",
            "nonzero_evaluated_result_skipped_case_count",
        ),
        ("unevaluated_skipped_case_count", "unevaluated_skipped_case_count"),
        ("truncated_case_count", "truncated_case_count"),
        (
            "zero_crossing_unlink_certified_case_count",
            "zero_crossing_unlink_certified_case_count",
        ),
        ("scanned_minor_count", "scanned_minor_count"),
        ("expected_minor_combination_count", "expected_combination_count"),
        ("nonzero_minor_count", "nonzero_minor_count"),
        ("zero_minor_count", "zero_minor_count"),
        ("unit_minor_count", "unit_minor_count"),
        ("nonzero_evaluated_case_count", "nonzero_evaluated_case_count"),
        ("nonzero_unique_evaluation_count", "nonzero_cache_miss_evaluation_count"),
        ("nonzero_reused_evaluation_count", "nonzero_cache_hit_evaluation_count"),
    ]

    def _count_int(value: object) -> int:
        if value is None or isinstance(value, bool):
            return 0
        return int(value)

    source_count_totals = {}
    count_matches = {}
    for report_field, source_field in count_field_specs:
        source_total = sum(
            _count_int(row.get(source_field, row.get(report_field, 0)))
            for row in source_notation_summary
        )
        report_total = _count_int(report_count_totals.get(report_field, 0))
        source_count_totals[report_field] = source_total
        count_matches[report_field] = {
            "report_total": report_total,
            "source_total": source_total,
            "matched": report_total == source_total,
        }

    count_totals_matched = all(
        match["matched"] for match in count_matches.values()
    )
    source_notation_count_matches_fixture_count = (
        len(source_notation_summary) == int(fixture_count)
    )
    matched = count_totals_matched and source_notation_count_matches_fixture_count
    mismatch_witnesses: list[dict] = []
    if not source_notation_count_matches_fixture_count:
        mismatch_witnesses.append(
            _multivariable_alexander_source_summary_mismatch_witness(
                kind="source_notation_count",
                field="source_notation_count",
                report_value=int(fixture_count),
                source_value=len(source_notation_summary),
            )
        )
    for field, match in count_matches.items():
        if not match["matched"]:
            mismatch_witnesses.append(
                _multivariable_alexander_source_summary_mismatch_witness(
                    kind="count_total",
                    field=field,
                    report_value=match["report_total"],
                    source_value=match["source_total"],
                )
            )

    return {
        "method": (
            "multivariable_alexander_source_notation_summary_consistency"
        ),
        "claim_scope": "generated_signed_pd_report_source_summary_count_consistency",
        "matched": matched,
        "mismatch_count": len(mismatch_witnesses),
        "first_mismatch": mismatch_witnesses[0] if mismatch_witnesses else None,
        "mismatch_witnesses": mismatch_witnesses[:8],
        "count_totals_matched": count_totals_matched,
        "source_notation_count_matches_fixture_count": (
            source_notation_count_matches_fixture_count
        ),
        "fixture_count": int(fixture_count),
        "source_notation_count": len(source_notation_summary),
        "compared_count_fields": [
            report_field for report_field, _source_field in count_field_specs
        ],
        "report_count_totals": {
            report_field: _count_int(report_count_totals.get(report_field, 0))
            for report_field, _source_field in count_field_specs
        },
        "source_count_totals": source_count_totals,
        "count_matches": count_matches,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": [
            "source_notation_summary totals are aggregated and compared with report-level generated coverage totals",
            "nonzero_unique_evaluation_count is aggregated from per-source cache miss counts",
            "nonzero_reused_evaluation_count is aggregated from per-source cache hit counts",
            "this is a report accounting consistency check, not a stronger Alexander invariant claim",
        ],
    }


def _multivariable_alexander_source_notation_coverage_summary(
    cases: Iterable[dict],
    source_notations: Iterable[str],
    nonzero_evaluation_stats_by_source: dict[str, dict[str, int]] | None = None,
) -> list[dict]:
    case_list = list(cases)
    evaluation_stats_by_source = nonzero_evaluation_stats_by_source or {}
    rows: list[dict] = []
    for notation in source_notations:
        notation_cases = [
            case for case in case_list if case.get("source_notation") == notation
        ]
        source_key = str(notation)
        if source_key not in evaluation_stats_by_source and notation_cases:
            source_key = str(notation_cases[0].get("source_notation"))
        evaluation_stats = evaluation_stats_by_source.get(source_key, {})
        nonzero_evaluated_case_count = int(
            evaluation_stats.get("nonzero_evaluated_case_count", 0) or 0
        )
        nonzero_cache_miss_evaluation_count = int(
            evaluation_stats.get("nonzero_cache_miss_evaluation_count", 0) or 0
        )
        nonzero_cache_hit_evaluation_count = int(
            evaluation_stats.get("nonzero_cache_hit_evaluation_count", 0) or 0
        )
        case_count = len(notation_cases)
        accepted_count = sum(1 for case in notation_cases if case.get("accepted"))
        skipped_count = sum(1 for case in notation_cases if case.get("result_skipped"))
        nonzero_evaluated_result_skipped_count = sum(
            1
            for case in notation_cases
            if case.get("result_skipped")
            and case.get("orientation_key") is not None
            and not case.get("zero_crossing_unlink_certified", False)
        )
        unevaluated_skipped_count = (
            skipped_count - nonzero_evaluated_result_skipped_count
        )
        truncated_count = sum(1 for case in notation_cases if case.get("truncated"))
        unique_diagram_keys = {
            case.get("diagram_key")
            for case in notation_cases
            if case.get("diagram_key") is not None
        }
        unique_oriented_diagram_keys = {
            (case.get("diagram_key"), case.get("orientation_key"))
            for case in notation_cases
            if case.get("diagram_key") is not None
            and case.get("orientation_key") is not None
        }
        rows.append(
            {
                "source_notation": str(notation),
                "case_count": case_count,
                "non_fixture_case_count": sum(
                    1
                    for case in notation_cases
                    if case.get("source_kind") != "fixture_root"
                ),
                "accepted_case_count": accepted_count,
                "uncertified_case_count": case_count - accepted_count,
                "result_skipped_case_count": skipped_count,
                "nonzero_evaluated_result_skipped_case_count": (
                    nonzero_evaluated_result_skipped_count
                ),
                "unevaluated_skipped_case_count": unevaluated_skipped_count,
                "truncated_case_count": truncated_count,
                "minor_divisibility_matched_case_count": sum(
                    1
                    for case in notation_cases
                    if case.get("minor_divisibility_matched")
                ),
                "bounded_scanned_gcd_certified_case_count": sum(
                    1
                    for case in notation_cases
                    if case.get("bounded_scanned_gcd_certified")
                ),
                "complete_scanned_gcd_certified_case_count": sum(
                    1
                    for case in notation_cases
                    if case.get("complete_scanned_gcd_certified")
                ),
                "wirtinger_fox_matched_case_count": sum(
                    1 for case in notation_cases if case.get("wirtinger_fox_matched")
                ),
                "zero_crossing_unlink_certified_case_count": sum(
                    1
                    for case in notation_cases
                    if case.get("zero_crossing_unlink_certified")
                ),
                "complete_scan_case_count": sum(
                    1
                    for case in notation_cases
                    if case.get("complete_combination_scan")
                ),
                "nonzero_minor_coverage_complete_case_count": sum(
                    1
                    for case in notation_cases
                    if case.get("nonzero_minor_coverage_complete")
                ),
                "scanned_minor_count": sum(
                    int(case.get("scanned_minor_count", 0) or 0)
                    for case in notation_cases
                ),
                "expected_combination_count": sum(
                    int(case.get("expected_combination_count", 0) or 0)
                    for case in notation_cases
                ),
                "nonzero_minor_count": sum(
                    int(case.get("nonzero_minor_count", 0) or 0)
                    for case in notation_cases
                ),
                "zero_minor_count": sum(
                    int(case.get("zero_minor_count", 0) or 0)
                    for case in notation_cases
                ),
                "unit_minor_count": sum(
                    int(case.get("unit_minor_count", 0) or 0)
                    for case in notation_cases
                ),
                "unique_nonzero_polynomial_count": sum(
                    int(case.get("unique_nonzero_polynomial_count", 0) or 0)
                    for case in notation_cases
                ),
                "admissible_minor_normalization_mismatch_witness_count": sum(
                    int(
                        case.get(
                            "admissible_minor_normalization_mismatch_witness_count",
                            0,
                        )
                        or 0
                    )
                    for case in notation_cases
                ),
                "admissible_minor_normalization_mismatch_witness_truncated_case_count": sum(
                    1
                    for case in notation_cases
                    if case.get(
                        "admissible_minor_normalization_mismatch_witness_truncated"
                    )
                ),
                "all_rows_have_nonzero_minor_case_count": sum(
                    1
                    for case in notation_cases
                    if case.get("all_rows_have_nonzero_minor")
                ),
                "all_columns_have_nonzero_minor_case_count": sum(
                    1
                    for case in notation_cases
                    if case.get("all_columns_have_nonzero_minor")
                ),
                "checked_nonzero_minor_count": sum(
                    int(case.get("checked_nonzero_minor_count", 0) or 0)
                    for case in notation_cases
                ),
                "failed_nonzero_minor_count": sum(
                    int(case.get("failed_nonzero_minor_count", 0) or 0)
                    for case in notation_cases
                ),
                "invalid_minor_reference_count": sum(
                    int(case.get("invalid_minor_reference_count", 0) or 0)
                    for case in notation_cases
                ),
                "invalid_normalization_count": sum(
                    int(case.get("invalid_normalization_count", 0) or 0)
                    for case in notation_cases
                ),
                "unique_diagram_count": len(unique_diagram_keys),
                "unique_oriented_diagram_count": len(unique_oriented_diagram_keys),
                "nonzero_evaluated_case_count": nonzero_evaluated_case_count,
                "nonzero_cache_miss_evaluation_count": (
                    nonzero_cache_miss_evaluation_count
                ),
                "nonzero_cache_hit_evaluation_count": (
                    nonzero_cache_hit_evaluation_count
                ),
                "nonzero_evaluation_cache_accounted": (
                    nonzero_cache_miss_evaluation_count
                    + nonzero_cache_hit_evaluation_count
                    == nonzero_evaluated_case_count
                ),
                "nonzero_evaluation_cache_reuse_observed": (
                    nonzero_cache_hit_evaluation_count > 0
                ),
                "max_crossing_count": max(
                    (
                        int(case.get("crossing_count", 0) or 0)
                        for case in notation_cases
                    ),
                    default=0,
                ),
                "max_generated_branch_depth": max(
                    (
                        int(case.get("branch_depth", 0) or 0)
                        for case in notation_cases
                    ),
                    default=0,
                ),
                "branch_depth_counts": _alexander_coverage_count_records_by_int_field(
                    notation_cases,
                    "branch_depth",
                    "branch_depth",
                ),
                "source_kind_counts": _alexander_coverage_count_records_by_string_field(
                    notation_cases,
                    "source_kind",
                    "source_kind",
                ),
                "branch_counts": _alexander_coverage_count_records_by_string_field(
                    notation_cases,
                    "branch",
                    "branch",
                ),
                "accepted": bool(notation_cases)
                and accepted_count == case_count
                and skipped_count == 0
                and truncated_count == 0,
            }
        )
    return rows


def _multivariable_alexander_signed_pd_coverage_case(
    *,
    source_notation: str,
    source_kind: str,
    crossing_index: int | None,
    branch: str | None,
    branch_depth: int,
    branch_path: list[str],
    parent_case_id: str | None,
    case_id: str,
    diagram: PlanarDiagram,
    orientation: PDOrientation,
    max_matrix_size: int,
    max_minors: int,
    evaluation: dict | None = None,
) -> dict:
    if diagram.crossing_count == 0 and not diagram.edge_labels:
        return _multivariable_alexander_zero_crossing_unlink_coverage_case(
            source_notation=source_notation,
            source_kind=source_kind,
            crossing_index=crossing_index,
            branch=branch,
            branch_depth=branch_depth,
            branch_path=branch_path,
            parent_case_id=parent_case_id,
            case_id=case_id,
            diagram=diagram,
            orientation=orientation,
        )

    if evaluation is None:
        evaluation = _multivariable_alexander_signed_pd_coverage_evaluation_fields(
            diagram,
            orientation,
            max_matrix_size=max_matrix_size,
            max_minors=max_minors,
        )
    return {
        "source_notation": source_notation,
        "source_kind": source_kind,
        "crossing_index": crossing_index,
        "branch": branch,
        "branch_depth": branch_depth,
        "branch_path": list(branch_path),
        "parent_case_id": parent_case_id,
        "case_id": case_id,
        **evaluation,
    }


def _multivariable_alexander_signed_pd_coverage_evaluation_key(
    diagram: PlanarDiagram,
    orientation: PDOrientation,
    *,
    max_matrix_size: int,
    max_minors: int,
) -> tuple[str, str, int, int]:
    return (
        repr(diagram.canonical_key()),
        repr(orientation.to_dict()),
        int(max_matrix_size),
        int(max_minors),
    )


def _multivariable_alexander_signed_pd_coverage_evaluation_fields(
    diagram: PlanarDiagram,
    orientation: PDOrientation,
    *,
    max_matrix_size: int,
    max_minors: int,
) -> dict:
    result = multivariable_alexander_from_pd(
        diagram,
        orientation=orientation,
        max_matrix_size=max_matrix_size,
        max_minors=max_minors,
    )
    minor_audit = multivariable_alexander_minor_divisibility_audit(result)
    scanned_gcd_audit = multivariable_alexander_scanned_gcd_audit(result)
    wirtinger_fox_audit = multivariable_alexander_wirtinger_fox_audit(result)
    admissible_minor_normalization_audit = (
        multivariable_alexander_admissible_minor_normalization_audit(result)
    )
    evidence = multivariable_alexander_input_certification_evidence(
        scanned_gcd_audit,
        wirtinger_fox_audit,
        admissible_minor_normalization_audit,
    )
    result_skipped = bool(result.get("skipped", False))
    minor_divisibility_matched = (
        not minor_audit.get("skipped", False)
        and bool(minor_audit.get("all_nonzero_minors_divisible", False))
    )
    bounded_scanned_gcd_certified = (
        not scanned_gcd_audit.get("skipped", False)
        and bool(scanned_gcd_audit.get("candidate_is_exact_scanned_gcd", False))
    )
    complete_scanned_gcd_certified = bool(
        evidence.get("complete_scanned_gcd_certified", False)
    )
    wirtinger_fox_matched = (
        not wirtinger_fox_audit.get("skipped", False)
        and bool(wirtinger_fox_audit.get("input_chain_consistent", False))
    )
    truncated = bool(evidence.get("truncated", False))
    accepted = (
        not result_skipped
        and minor_divisibility_matched
        and bounded_scanned_gcd_certified
        and wirtinger_fox_matched
        and not truncated
    )
    summary = result.get("admissible_minor_summary") or {}
    return {
        "crossing_count": diagram.crossing_count,
        "component_count": diagram.component_count,
        "diagram_key": repr(diagram.canonical_key()),
        "orientation_key": repr(orientation.to_dict()),
        "multivariable_alexander_polynomial": result.get(
            "multivariable_alexander_polynomial"
        ),
        "result_method": result.get("method"),
        "result_skipped": result_skipped,
        "minor_divisibility_matched": minor_divisibility_matched,
        "bounded_scanned_gcd_certified": bounded_scanned_gcd_certified,
        "complete_scanned_gcd_certified": complete_scanned_gcd_certified,
        "bounded_alexander_maturity_path": str(
            evidence.get(
                "bounded_alexander_maturity_path",
                _ALEXANDER_MATURITY_NOT_CERTIFIED,
            )
            or _ALEXANDER_MATURITY_NOT_CERTIFIED
        ),
        "bounded_alexander_maturity_path_certified": bool(
            evidence.get("bounded_alexander_maturity_path_certified", False)
        ),
        "bounded_admissible_minor_normalization_certified": bool(
            evidence.get(
                "bounded_admissible_minor_normalization_certified",
                False,
            )
        ),
        "all_nonzero_minors_laurent_unit_equivalent": bool(
            evidence.get(
                "all_nonzero_minors_laurent_unit_equivalent",
                False,
            )
        ),
        "admissible_minor_normalized_representative_polynomial": (
            evidence.get("admissible_minor_normalized_representative_polynomial")
        ),
        "admissible_minor_normalization_class_count": int(
            evidence.get("admissible_minor_normalization_class_count", 0) or 0
        ),
        "admissible_minor_normalization_nonrepresentative_class_count": int(
            evidence.get(
                "admissible_minor_normalization_nonrepresentative_class_count",
                0,
            )
            or 0
        ),
        "admissible_minor_normalization_mismatch_witness_count": int(
            evidence.get(
                "admissible_minor_normalization_mismatch_witness_count",
                0,
            )
            or 0
        ),
        "admissible_minor_normalization_mismatch_witness_truncated": bool(
            evidence.get(
                "admissible_minor_normalization_mismatch_witness_truncated",
                False,
            )
        ),
        "wirtinger_fox_matched": wirtinger_fox_matched,
        "zero_crossing_unlink_certified": False,
        "truncated": truncated,
        "expected_combination_count": int(
            summary.get("expected_combination_count", 0) or 0
        ),
        "scanned_minor_count": int(evidence.get("scanned_minor_count", 0) or 0),
        "nonzero_minor_count": int(summary.get("nonzero_minor_count", 0) or 0),
        "zero_minor_count": int(summary.get("zero_minor_count", 0) or 0),
        "unit_minor_count": int(summary.get("unit_minor_count", 0) or 0),
        "unique_nonzero_polynomial_count": int(
            summary.get("unique_nonzero_polynomial_count", 0) or 0
        ),
        "all_rows_have_nonzero_minor": bool(
            evidence.get("all_rows_have_nonzero_minor", False)
        ),
        "all_columns_have_nonzero_minor": bool(
            evidence.get("all_columns_have_nonzero_minor", False)
        ),
        "checked_nonzero_minor_count": int(
            evidence.get("checked_nonzero_minor_count", 0) or 0
        ),
        "failed_nonzero_minor_count": int(
            evidence.get("failed_nonzero_minor_count", 0) or 0
        ),
        "invalid_minor_reference_count": int(
            evidence.get("fox_square_minor_invalid_reference_count", 0) or 0
        ),
        "invalid_normalization_count": int(
            evidence.get("fox_square_minor_invalid_normalization_count", 0) or 0
        ),
        "complete_combination_scan": bool(
            evidence.get("complete_combination_scan", False)
        ),
        "nonzero_minor_coverage_complete": bool(
            evidence.get("nonzero_minor_coverage_complete", False)
        ),
        "admissible_minor_summary": summary,
        "input_certification_evidence": evidence,
        "result": result,
        "minor_divisibility_audit": minor_audit,
        "scanned_gcd_audit": scanned_gcd_audit,
        "wirtinger_fox_audit": wirtinger_fox_audit,
        "admissible_minor_normalization_audit": admissible_minor_normalization_audit,
        "accepted": accepted,
        "notes": []
        if accepted
        else [
            "generated signed-PD input did not satisfy every bounded Alexander coverage check",
        ],
    }

def _multivariable_alexander_zero_crossing_unlink_coverage_case(
    *,
    source_notation: str,
    source_kind: str,
    crossing_index: int | None,
    branch: str | None,
    branch_depth: int,
    branch_path: list[str],
    parent_case_id: str | None,
    case_id: str,
    diagram: PlanarDiagram,
    orientation: PDOrientation,
) -> dict:
    component_count = diagram.component_count or 1
    variables = [f"t{index + 1}" for index in range(component_count)]
    polynomial = "1" if component_count == 1 else "0"
    summary = _zero_crossing_unlink_admissible_minor_summary(variables)
    evidence = multivariable_alexander_input_certification_evidence(None, None)
    evidence.update(
        {
            "claim_scope": "zero_crossing_unlink_terminal_normalization",
            "source_method": "zero_crossing_unlink_normalization",
            "multivariable_alexander_polynomial": polynomial,
            "variables": variables,
            "bounded_alexander_maturity_path": (
                _ALEXANDER_MATURITY_ZERO_CROSSING_UNLINK
            ),
            "bounded_alexander_maturity_path_certified": True,
            "zero_crossing_unlink_certified": True,
            "component_count": component_count,
            "skipped": False,
            "notes": [
                "zero-crossing signed-PD coverage case is certified as an unlink terminal",
                "this path bypasses Wirtinger/Fox because zero-crossing diagrams have no arc generators",
                "full admissible-minor normalization and complete invariant certification remain false",
            ],
        }
    )
    result = _multivariable_alexander_zero_crossing_unlink_result(
        diagram,
        variables=variables,
    )
    zero_audit = {
        "method": "zero_crossing_unlink_terminal_audit",
        "source_method": "zero_crossing_unlink_normalization",
        "claim_scope": "zero_crossing_unlink_terminal_normalization",
        "multivariable_alexander_polynomial": polynomial,
        "variables": variables,
        "component_count": component_count,
        "zero_crossing_unlink_certified": True,
        "skipped": False,
        "complete_combination_scan": False,
        "truncated": False,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": [
            "coverage-only terminal audit; no Fox minor scan exists for a zero-crossing unlink diagram",
        ],
    }
    wirtinger_fox_audit = {
        "method": "multivariable_alexander_wirtinger_fox_audit",
        "claim_scope": "zero_crossing_unlink_terminal_normalization",
        "source_method": "zero_crossing_unlink_normalization",
        "presentation_valid": False,
        "fox_jacobian_valid": False,
        "fox_square_minor_scan_valid": False,
        "input_chain_consistent": False,
        "relation_count": 0,
        "generator_count": 0,
        "variable_count": len(variables),
        "component_count": component_count,
        "jacobian_matrix_size": [0, 0],
        "square_minor_matrix_size": [0, 0],
        "scanned_minor_count": 0,
        "invalid_minor_reference_count": 0,
        "invalid_normalization_count": 0,
        **_empty_fox_minor_validation_witness_fields(),
        "complete_combination_scan": False,
        "truncated": False,
        "skipped": True,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": [
            "Wirtinger/Fox input-chain audit is not applicable to zero-crossing unlink terminals",
        ],
    }
    return {
        "source_notation": source_notation,
        "source_kind": source_kind,
        "crossing_index": crossing_index,
        "branch": branch,
        "branch_depth": branch_depth,
        "branch_path": list(branch_path),
        "parent_case_id": parent_case_id,
        "case_id": case_id,
        "crossing_count": diagram.crossing_count,
        "component_count": component_count,
        "diagram_key": repr(diagram.canonical_key()),
        "orientation_key": repr(orientation.to_dict()),
        "multivariable_alexander_polynomial": polynomial,
        "result_method": "zero_crossing_unlink_normalization",
        "result_skipped": False,
        "minor_divisibility_matched": False,
        "bounded_scanned_gcd_certified": False,
        "complete_scanned_gcd_certified": False,
        "bounded_alexander_maturity_path": (
            _ALEXANDER_MATURITY_ZERO_CROSSING_UNLINK
        ),
        "bounded_alexander_maturity_path_certified": True,
        "wirtinger_fox_matched": False,
        "zero_crossing_unlink_certified": True,
        "truncated": False,
        "expected_combination_count": 0,
        "scanned_minor_count": 0,
        "nonzero_minor_count": 0,
        "zero_minor_count": 0,
        "unit_minor_count": 0,
        "unique_nonzero_polynomial_count": 0,
        "all_rows_have_nonzero_minor": False,
        "all_columns_have_nonzero_minor": False,
        "checked_nonzero_minor_count": 0,
        "failed_nonzero_minor_count": 0,
        "invalid_minor_reference_count": 0,
        "invalid_normalization_count": 0,
        **_empty_fox_minor_validation_witness_fields(),
        "complete_combination_scan": False,
        "nonzero_minor_coverage_complete": False,
        "admissible_minor_summary": summary,
        "input_certification_evidence": evidence,
        "result": result,
        "minor_divisibility_audit": zero_audit,
        "scanned_gcd_audit": zero_audit,
        "wirtinger_fox_audit": wirtinger_fox_audit,
        "accepted": True,
        "notes": [
            "accepted through zero-crossing unlink terminal normalization, not through a Wirtinger/Fox minor scan",
        ],
    }

def _multivariable_alexander_zero_crossing_unlink_result(
    diagram: PlanarDiagram,
    *,
    variables: Iterable[str] | None = None,
) -> dict:
    component_count = diagram.component_count or 1
    variables_tuple = _zero_crossing_unlink_variables(component_count, variables)
    polynomial = "1" if component_count == 1 else "0"
    return {
        "multivariable_alexander_polynomial": polynomial,
        "candidate_polynomials": [],
        "bounded_alexander_maturity_path": (
            _ALEXANDER_MATURITY_ZERO_CROSSING_UNLINK
        ),
        "bounded_alexander_maturity_path_certified": True,
        "method": "zero_crossing_unlink_normalization",
        "diagram": diagram.to_dict(),
        "presentation": None,
        "square_minors": None,
        "admissible_minor_summary": _zero_crossing_unlink_admissible_minor_summary(
            variables_tuple,
        ),
        "variables": list(variables_tuple),
        "component_count": component_count,
        "requires_normalization": False,
        "skipped": False,
        "zero_crossing_unlink_certified": True,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": [
            "zero-crossing unlink terminal normalization uses 1 for the unknot and 0 for multi-component unlinks under the current iroll Alexander convention",
            "ordinary signed-PD Wirtinger/Fox generation is not applicable because there are no arc generators",
        ],
    }


def _zero_crossing_unlink_variables(
    component_count: int,
    variables: Iterable[str] | None,
) -> tuple[str, ...]:
    if component_count < 1:
        raise ValueError("zero-crossing unlink component count must be positive")
    if variables is None:
        return tuple(f"t{index + 1}" for index in range(component_count))
    variables_tuple = tuple(str(variable) for variable in variables)
    if len(variables_tuple) != component_count:
        raise ValueError("variables length must match component count")
    return variables_tuple

def _zero_crossing_unlink_admissible_minor_summary(variables: Sequence[str]) -> dict:
    return {
        "method": "zero_crossing_unlink_admissible_minor_summary",
        "variables": list(variables),
        "matrix_size": [0, 0],
        "target_size": 0,
        "expected_combination_count": 0,
        "scanned_minor_count": 0,
        "complete_combination_scan": False,
        "truncated": False,
        "skipped": True,
        "nonzero_minor_count": 0,
        "zero_minor_count": 0,
        "unit_minor_count": 0,
        "unique_nonzero_polynomials": [],
        "unique_nonzero_polynomial_count": 0,
        "admissible_minor_indices": [],
        "row_subset_count": 0,
        "column_subset_count": 0,
        "row_subsets": [],
        "column_subsets": [],
        "covered_rows": [],
        "covered_columns": [],
        "all_rows_covered": False,
        "all_columns_covered": False,
        "nonzero_row_subset_count": 0,
        "nonzero_column_subset_count": 0,
        "nonzero_row_subsets": [],
        "nonzero_column_subsets": [],
        "nonzero_covered_rows": [],
        "nonzero_covered_columns": [],
        "all_rows_have_nonzero_minor": False,
        "all_columns_have_nonzero_minor": False,
        "nonzero_minor_coverage_complete": False,
        "notes": [
            "zero-crossing unlink terminal has no Wirtinger/Fox matrix or admissible minor scan",
        ],
    }
def _multivariable_alexander_signed_pd_coverage_skipped_case(
    *,
    source_notation: str,
    source_kind: str,
    crossing_index: int | None,
    branch: str | None,
    crossing_count: int,
    component_count: int,
    diagram_key: str | None,
    notes: list[str],
    branch_depth: int = 0,
    branch_path: list[str] | None = None,
    parent_case_id: str | None = None,
    case_id: str | None = None,
) -> dict:
    evidence = multivariable_alexander_input_certification_evidence(None, None)
    return {
        "source_notation": source_notation,
        "source_kind": source_kind,
        "crossing_index": crossing_index,
        "branch": branch,
        "branch_depth": branch_depth,
        "branch_path": list(branch_path or []),
        "parent_case_id": parent_case_id,
        "case_id": case_id or f"{source_notation}:{crossing_index}:{branch}:skipped",
        "crossing_count": crossing_count,
        "component_count": component_count,
        "diagram_key": diagram_key,
        "orientation_key": None,
        "multivariable_alexander_polynomial": None,
        "result_method": "skipped",
        "result_skipped": True,
        "minor_divisibility_matched": False,
        "bounded_scanned_gcd_certified": False,
        "complete_scanned_gcd_certified": False,
        "bounded_alexander_maturity_path": _ALEXANDER_MATURITY_NOT_CERTIFIED,
        "bounded_alexander_maturity_path_certified": False,
        "wirtinger_fox_matched": False,
        "zero_crossing_unlink_certified": False,
        "truncated": False,
        "scanned_minor_count": 0,
        "checked_nonzero_minor_count": 0,
        "failed_nonzero_minor_count": 0,
        "invalid_minor_reference_count": 0,
        "invalid_normalization_count": 0,
        **_empty_fox_minor_validation_witness_fields(),
        "complete_combination_scan": False,
        "nonzero_minor_coverage_complete": False,
        "admissible_minor_summary": None,
        "input_certification_evidence": evidence,
        "result": None,
        "minor_divisibility_audit": None,
        "scanned_gcd_audit": None,
        "wirtinger_fox_audit": None,
        "accepted": False,
        "notes": notes,
    }

def multivariable_alexander_from_presentation(
    presentation: WirtingerPresentation,
    *,
    remove_row: int | None = None,
    remove_column: int = 0,
    normalize: bool = True,
    max_matrix_size: int = 6,
) -> dict:
    result = fox_minor_from_presentation(
        presentation.relations,
        generator_components=presentation.generator_components,
        variables=presentation.variables,
        remove_row=remove_row,
        remove_column=remove_column,
        normalize=normalize,
        max_matrix_size=max_matrix_size,
    )
    result["presentation"] = presentation.to_dict()
    return result


def exact_multivariate_laurent_gcd(
    polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    variables: Sequence[str],
) -> tuple[MultivariateLaurentPolynomial, dict]:
    """Compute the exact gcd in ``ZZ[t_1^±1,...,t_m^±1]``.

    Each input is shifted by an independently invertible Laurent monomial,
    then SymPy computes the gcd over ``ZZ``.  Integer content is deliberately
    retained (only Laurent monomials and sign are units).  Exact quotients are
    recomputed and their gcd is required to be one, which is the maximality
    witness for the returned common divisor.
    """

    if any(tuple(polynomial.variables) != tuple(variables) for polynomial in polynomials):
        raise ValueError("exact Laurent gcd variables must match every input")
    try:
        import sympy as sympy  # type: ignore[import-not-found]
    except Exception as exc:  # pragma: no cover - required dependency failure
        raise RuntimeError("SymPy >= 1.14 is required for exact Laurent gcd") from exc

    version_parts = tuple(
        int(part)
        for part in re.findall(r"\d+", str(sympy.__version__))[:2]
    )
    if version_parts < (1, 14):  # pragma: no cover - packaging contract guard
        raise RuntimeError("SymPy >= 1.14 is required for exact Laurent gcd")

    if not polynomials:
        zero = MultivariateLaurentPolynomial.constant(0, variables=variables)
        return zero, {
            "method": "sympy_zz_exact_multivariate_laurent_gcd_v1",
            "sympy_version": str(sympy.__version__),
            "coefficient_domain": "ZZ",
            "input_count": 0,
            "nonzero_input_count": 0,
            "all_inputs_zero": True,
            "empty_input_family": True,
            "laurent_monomial_units_cleared": True,
            "integer_content_preserved": True,
            "candidate_polynomial": "0",
            "candidate_is_zero": True,
            "candidate_divides_all_nonzero_inputs": True,
            "quotient_gcd_certified": False,
            "quotient_gcd_polynomial": None,
            "zero_ideal_certified": True,
            "exact_gcd_certification_basis": "no_admissible_maximal_minors",
            "candidate_is_exact_gcd": True,
            "division_records": [],
        }

    symbols = sympy.symbols(" ".join(variables))
    if not isinstance(symbols, tuple):
        symbols = (symbols,)

    normalized_inputs = [polynomial.normalize_unit() for polynomial in polynomials]
    nonzero_inputs = [polynomial for polynomial in normalized_inputs if not polynomial.is_zero]
    if not nonzero_inputs:
        zero = MultivariateLaurentPolynomial.constant(0, variables=variables)
        return zero, {
            "method": "sympy_zz_exact_multivariate_laurent_gcd_v1",
            "sympy_version": str(sympy.__version__),
            "coefficient_domain": "ZZ",
            "input_count": len(polynomials),
            "nonzero_input_count": 0,
            "all_inputs_zero": True,
            "empty_input_family": False,
            "laurent_monomial_units_cleared": True,
            "integer_content_preserved": True,
            "candidate_polynomial": "0",
            "candidate_is_zero": True,
            "candidate_divides_all_nonzero_inputs": True,
            "quotient_gcd_certified": False,
            "quotient_gcd_polynomial": None,
            "zero_ideal_certified": True,
            "exact_gcd_certification_basis": (
                "all_enumerated_ideal_generators_zero"
            ),
            "candidate_is_exact_gcd": True,
            "division_records": [],
        }

    def to_sympy(polynomial: MultivariateLaurentPolynomial):
        return sympy.Poly.from_dict(
            {
                exponents: sympy.Integer(coefficient)
                for exponents, coefficient in polynomial.terms
            },
            *symbols,
            domain=sympy.ZZ,
        )

    sympy_inputs = [to_sympy(polynomial) for polynomial in nonzero_inputs]
    gcd_poly = sympy_inputs[0]
    for polynomial in sympy_inputs[1:]:
        gcd_poly = gcd_poly.gcd(polynomial)
    candidate = MultivariateLaurentPolynomial.from_dict(
        {
            tuple(int(exponent) for exponent in monomial): int(coefficient)
            for monomial, coefficient in gcd_poly.terms()
        },
        variables=tuple(variables),
    ).normalize_unit()
    candidate_poly = to_sympy(candidate)

    quotient_polys = []
    division_records = []
    for input_index, (source, polynomial) in enumerate(zip(nonzero_inputs, sympy_inputs)):
        quotient = polynomial.exquo(candidate_poly)
        quotient_polys.append(quotient)
        quotient_value = MultivariateLaurentPolynomial.from_dict(
            {
                tuple(int(exponent) for exponent in monomial): int(coefficient)
                for monomial, coefficient in quotient.terms()
            },
            variables=tuple(variables),
        ).normalize_unit()
        division_records.append(
            {
                "nonzero_input_index": input_index,
                "input_polynomial": source.format(),
                "quotient_polynomial": quotient_value.format(),
                "exact_division": True,
            }
        )

    quotient_gcd = quotient_polys[0]
    for quotient in quotient_polys[1:]:
        quotient_gcd = quotient_gcd.gcd(quotient)
    quotient_gcd_value = MultivariateLaurentPolynomial.from_dict(
        {
            tuple(int(exponent) for exponent in monomial): int(coefficient)
            for monomial, coefficient in quotient_gcd.terms()
        },
        variables=tuple(variables),
    ).normalize_unit()
    quotient_gcd_is_unit = _is_unit_polynomial(quotient_gcd_value)
    if not quotient_gcd_is_unit:
        raise ArithmeticError("exact gcd quotient family unexpectedly has non-unit gcd")

    return candidate, {
        "method": "sympy_zz_exact_multivariate_laurent_gcd_v1",
        "sympy_version": str(sympy.__version__),
        "coefficient_domain": "ZZ",
        "input_count": len(polynomials),
        "nonzero_input_count": len(nonzero_inputs),
        "all_inputs_zero": False,
        "empty_input_family": False,
        "laurent_monomial_units_cleared": True,
        "integer_content_preserved": True,
        "candidate_polynomial": candidate.format(),
        "candidate_is_zero": False,
        "candidate_divides_all_nonzero_inputs": True,
        "quotient_gcd_certified": True,
        "quotient_gcd_polynomial": quotient_gcd_value.format(),
        "zero_ideal_certified": False,
        "exact_gcd_certification_basis": (
            "exact_division_and_quotient_gcd_one"
        ),
        "candidate_is_exact_gcd": True,
        "division_records": division_records,
    }


def _fox_fundamental_identity_certificate(
    presentation: WirtingerPresentation,
    matrix: Sequence[Sequence[MultivariateLaurentPolynomial]],
) -> dict:
    variables = tuple(presentation.variables)
    one = MultivariateLaurentPolynomial.constant(1, variables=variables)
    zero = MultivariateLaurentPolynomial.constant(0, variables=variables)
    failures = []
    relator_failures = []
    for relation_index, (relation, row) in enumerate(
        zip(presentation.relations, matrix)
    ):
        fox_sum = zero
        for generator, derivative in enumerate(row):
            generator_value = _generator_monomial(
                generator,
                1,
                generator_components=presentation.generator_components,
                variables=variables,
            )
            fox_sum = fox_sum + derivative * (generator_value - one)
        abelianized_relator = one
        for generator, exponent in relation:
            abelianized_relator = abelianized_relator * _generator_monomial(
                generator,
                exponent,
                generator_components=presentation.generator_components,
                variables=variables,
            )
        relator_minus_one = abelianized_relator - one
        if fox_sum != relator_minus_one:
            failures.append(
                {
                    "relation_index": relation_index,
                    "fox_sum": fox_sum.format(),
                    "abelianized_relator_minus_one": relator_minus_one.format(),
                }
            )
        if not relator_minus_one.is_zero:
            relator_failures.append(
                {
                    "relation_index": relation_index,
                    "abelianized_relator": abelianized_relator.format(),
                }
            )
    all_identities_hold = not failures and len(matrix) == len(
        presentation.relations
    )
    all_relators_valid = not relator_failures
    return {
        "method": "abelianized_fox_fundamental_identity_v1",
        "relation_count": len(presentation.relations),
        "checked_relation_count": min(len(presentation.relations), len(matrix)),
        "all_fox_fundamental_identities_hold": all_identities_hold,
        "all_relators_abelianize_to_identity": all_relators_valid,
        "fox_identity_failure_count": len(failures),
        "fox_identity_failure_witnesses": failures[:8],
        "relator_abelianization_failure_count": len(relator_failures),
        "relator_abelianization_failure_witnesses": relator_failures[:8],
        "certified": all_identities_hold and all_relators_valid,
    }


def multivariable_alexander_exact_from_presentation(
    presentation: WirtingerPresentation,
) -> dict:
    """Compute the exact maximal-minor Alexander gcd without scan caps.

    For an ``m x n`` Wirtinger Fox matrix, every ``(n-1) x (n-1)`` minor is
    enumerated.  When ``m < n-1`` there are no such minors, so the generated
    ideal is exactly the zero ideal.  The exact Laurent gcd is computed over
    ``ZZ``. A nonzero ideal uses an exact-division and quotient-gcd-one
    certificate; an all-zero or empty minor family certifies the zero ideal
    directly. Any input, dependency, enumeration, determinant, or gcd failure
    returns a skipped result and never promotes a partial computation.
    """

    variables = tuple(presentation.variables)
    base = {
        "presentation": presentation.to_dict(),
        "variables": list(variables),
        "exact_algorithm": "all_maximal_fox_minors_sympy_zz_gcd_v1",
        "resource_caps": None,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
    }
    try:
        matrix = fox_jacobian(
            presentation.relations,
            generator_components=presentation.generator_components,
            variables=variables,
        )
    except Exception as exc:
        return {
            **base,
            "multivariable_alexander_polynomial": None,
            "candidate_polynomials": [],
            "method": "skipped",
            "square_minors": None,
            "admissible_minor_summary": None,
            "exact_gcd_certificate": None,
            "requires_normalization": True,
            "skipped": True,
            "failure_reason": f"{type(exc).__name__}: {exc}",
            "notes": ["exact Alexander Fox-Jacobian construction failed closed"],
        }

    row_count = len(matrix)
    generator_count = len(presentation.generator_components)
    column_count = len(matrix[0]) if matrix else generator_count
    target_size = column_count - 1
    if (
        column_count == 0
        or column_count != generator_count
        or target_size < 0
    ):
        return {
            **base,
            "multivariable_alexander_polynomial": None,
            "candidate_polynomials": [],
            "method": "skipped",
            "square_minors": None,
            "admissible_minor_summary": None,
            "exact_gcd_certificate": None,
            "requires_normalization": True,
            "skipped": True,
            "failure_reason": "fox_jacobian_has_invalid_generator_dimension",
            "notes": [
                "exact Alexander normalization requires an m x n Fox matrix "
                "with positive n equal to the generator count"
            ],
        }

    fox_identity_certificate = _fox_fundamental_identity_certificate(
        presentation,
        matrix,
    )
    if fox_identity_certificate.get("certified") is not True:
        return {
            **base,
            "multivariable_alexander_polynomial": None,
            "candidate_polynomials": [],
            "method": "skipped",
            "square_minors": None,
            "admissible_minor_summary": None,
            "exact_gcd_certificate": None,
            "fox_fundamental_identity_certificate": fox_identity_certificate,
            "requires_normalization": True,
            "skipped": True,
            "failure_reason": "fox_abelianization_or_fundamental_identity_failed",
            "notes": [
                "the supplied presentation does not define the declared "
                "component abelianization or failed the Fox fundamental identity"
            ],
        }

    expected_minor_count = comb(row_count, target_size) * comb(
        column_count, target_size
    )
    try:
        scan = fox_square_minors_from_presentation(
            presentation.relations,
            generator_components=presentation.generator_components,
            variables=variables,
            target_size=target_size,
            max_matrix_size=target_size,
            max_minors=expected_minor_count,
        )
        summary = scan["admissible_minor_summary"]
        complete = bool(
            scan.get("skipped") is False
            and scan.get("truncated") is False
            and summary.get("complete_combination_scan") is True
            and int(summary.get("scanned_minor_count", 0)) == expected_minor_count
        )
        if not complete:
            raise ArithmeticError("maximal Fox minor enumeration was incomplete")
        minor_polynomials = [
            _polynomial_from_serialized_terms(
                minor.get("raw_terms", []),
                variables=variables,
            )
            for minor in scan["minors"]
        ]
        polynomial, gcd_certificate = exact_multivariate_laurent_gcd(
            minor_polynomials,
            variables=variables,
        )
    except Exception as exc:
        return {
            **base,
            "multivariable_alexander_polynomial": None,
            "candidate_polynomials": [],
            "method": "skipped",
            "square_minors": None,
            "admissible_minor_summary": None,
            "exact_gcd_certificate": None,
            "requires_normalization": True,
            "skipped": True,
            "failure_reason": f"{type(exc).__name__}: {exc}",
            "notes": ["exact all-maximal-minor Alexander computation failed closed"],
        }

    return {
        **base,
        "multivariable_alexander_polynomial": polynomial.format(),
        "candidate_polynomials": _unique_nonzero_minor_polynomials(scan["minors"]),
        "method": "fox_all_maximal_minors_exact_sympy_zz_gcd",
        "square_minors": scan,
        "admissible_minor_summary": summary,
        "exact_gcd_certificate": gcd_certificate,
        "fox_fundamental_identity_certificate": fox_identity_certificate,
        "expected_maximal_minor_count": expected_minor_count,
        "enumerated_maximal_minor_count": len(scan["minors"]),
        "all_maximal_minors_enumerated": True,
        "all_maximal_minors_zero": bool(
            gcd_certificate.get("all_inputs_zero") is True
        ),
        "zero_ideal_certified": bool(
            gcd_certificate.get("zero_ideal_certified") is True
        ),
        "requires_normalization": False,
        "skipped": False,
        "full_admissible_minor_normalization_certified": True,
        "full_invariant_certified": True,
        "notes": (
            [
                "the admissible maximal-minor index family is empty because "
                "the Fox presentation has fewer than n-1 relations",
                "the ideal generated by an empty minor family is the zero ideal",
            ]
            if expected_minor_count == 0
            else
            [
                "every maximal (n-1)x(n-1) Fox minor was enumerated without a matrix or minor cap",
                "every enumerated maximal minor is zero, so the generated "
                "Alexander ideal is the zero ideal",
            ]
            if gcd_certificate.get("all_inputs_zero") is True
            else [
                "every maximal (n-1)x(n-1) Fox minor was enumerated without a matrix or minor cap",
                "the Laurent gcd was computed exactly over ZZ and its quotient family has gcd one",
            ]
        ),
    }


def multivariable_alexander_exact_from_oriented_pd(
    diagram: PlanarDiagram,
    orientation: PDOrientation,
    *,
    variables: Iterable[str] | None = None,
) -> dict:
    """Run the uncapped exact path from an explicitly oriented signed PD."""

    if diagram.crossing_count == 0:
        try:
            issues = orientation.validation_issues(diagram)
        except Exception as exc:
            return {
                "multivariable_alexander_polynomial": None,
                "method": "skipped",
                "diagram": diagram.to_dict(),
                "orientation": orientation.to_dict(),
                "requires_normalization": True,
                "skipped": True,
                "full_admissible_minor_normalization_certified": False,
                "full_invariant_certified": False,
                "failure_reason": f"{type(exc).__name__}: {exc}",
                "notes": ["zero-crossing signed-PD validation failed closed"],
            }
        if issues:
            return {
                "multivariable_alexander_polynomial": None,
                "method": "skipped",
                "diagram": diagram.to_dict(),
                "orientation": orientation.to_dict(),
                "requires_normalization": True,
                "skipped": True,
                "full_admissible_minor_normalization_certified": False,
                "full_invariant_certified": False,
                "failure_reason": "ValueError: " + "; ".join(issues),
                "notes": ["zero-crossing signed-PD validation failed closed"],
            }
        component_count = diagram.component_count
        if component_count is None or component_count < 1:
            return {
                "multivariable_alexander_polynomial": None,
                "method": "skipped",
                "diagram": diagram.to_dict(),
                "orientation": orientation.to_dict(),
                "requires_normalization": True,
                "skipped": True,
                "full_admissible_minor_normalization_certified": False,
                "full_invariant_certified": False,
                "failure_reason": (
                    "ValueError: zero-crossing exact Alexander input requires "
                    "a positive explicit component_count"
                ),
                "notes": ["zero-crossing component count was not certifiable"],
            }
        try:
            variables_tuple = _zero_crossing_unlink_variables(
                component_count,
                variables,
            )
        except Exception as exc:
            return {
                "multivariable_alexander_polynomial": None,
                "method": "skipped",
                "diagram": diagram.to_dict(),
                "orientation": orientation.to_dict(),
                "requires_normalization": True,
                "skipped": True,
                "full_admissible_minor_normalization_certified": False,
                "full_invariant_certified": False,
                "failure_reason": f"{type(exc).__name__}: {exc}",
                "notes": ["zero-crossing Alexander normalization failed closed"],
            }
        polynomial = "1" if component_count == 1 else "0"
        summary = _zero_crossing_unlink_admissible_minor_summary(variables_tuple)
        summary.update(
            {
                "complete_combination_scan": True,
                "skipped": False,
                "zero_crossing_terminal": True,
                "notes": [
                    "zero-crossing unlink has no Fox matrix; its empty "
                    "admissible-minor boundary is terminally normalized"
                ],
            }
        )
        zero_ideal = component_count > 1
        return {
            "multivariable_alexander_polynomial": polynomial,
            "candidate_polynomials": [],
            "method": "zero_crossing_unlink_exact_normalization",
            "diagram": diagram.to_dict(),
            "orientation": orientation.to_dict(),
            "presentation": None,
            "square_minors": None,
            "admissible_minor_summary": summary,
            "exact_gcd_certificate": None,
            "exact_terminal_certificate": {
                "method": "zero_crossing_unlink_exact_normalization_v1",
                "component_count": component_count,
                "normalization_axiom": (
                    "unknot_equals_one"
                    if component_count == 1
                    else "split_multicomponent_unlink_equals_zero"
                ),
                "polynomial": polynomial,
                "zero_ideal_certified": zero_ideal,
                "certified": True,
            },
            "variables": list(variables_tuple),
            "component_count": component_count,
            "exact_algorithm": "zero_crossing_unlink_exact_normalization_v1",
            "resource_caps": None,
            "expected_maximal_minor_count": 0,
            "enumerated_maximal_minor_count": 0,
            "all_maximal_minors_enumerated": True,
            "all_maximal_minors_zero": zero_ideal,
            "zero_ideal_certified": zero_ideal,
            "zero_crossing_unlink_certified": True,
            "requires_normalization": False,
            "skipped": False,
            "full_admissible_minor_normalization_certified": True,
            "full_invariant_certified": True,
            "notes": [
                "the crossingless unknot is normalized to 1"
                if component_count == 1
                else (
                    "a crossingless multi-component unlink is normalized to "
                    "the zero Alexander ideal"
                )
            ],
        }

    try:
        issues = orientation.validation_issues(diagram)
        implicit_component_map = not orientation.edge_components
        only_missing_component_map_issue = bool(
            issues
            and all(
                issue.startswith(
                    "edge_components must include every edge label for "
                    "multi-component diagrams"
                )
                for issue in issues
            )
        )
        if issues and not (
            implicit_component_map and only_missing_component_map_issue
        ):
            raise ValueError("; ".join(issues))
        traversal_diagram = diagram
        if implicit_component_map and only_missing_component_map_issue:
            traversal_diagram = PlanarDiagram(
                diagram.crossings,
                component_count=None,
                name=diagram.name,
                convention=diagram.convention,
            )
        traversals = orientation.oriented_component_traversals(
            traversal_diagram
        )
        component_count = diagram.component_count
        if component_count is not None and component_count > len(traversals):
            represented_component_ids = (
                _oriented_pd_represented_component_ids(
                    diagram,
                    orientation,
                    traversals=traversals,
                )
            )
            variables_tuple = _zero_crossing_unlink_variables(
                component_count,
                variables,
            )
            free_component_ids = tuple(
                sorted(set(range(component_count)) - set(represented_component_ids))
            )
            if not free_component_ids:
                raise ValueError(
                    "component_count exceeds represented cycles but no free "
                    "component id was available"
                )
            summary = _zero_crossing_unlink_admissible_minor_summary(
                variables_tuple
            )
            summary.update(
                {
                    "method": "split_free_component_admissible_minor_summary",
                    "complete_combination_scan": True,
                    "skipped": False,
                    "split_free_component_terminal": True,
                    "notes": [
                        "the signed PD records every crossing-bearing component "
                        "and explicit component_count records at least one "
                        "additional free circle",
                        "the split-free-circle theorem terminally normalizes the "
                        "multivariable Alexander ideal to zero",
                    ],
                }
            )
            terminal_certificate = {
                "method": "split_free_component_exact_normalization_v1",
                "component_count": component_count,
                "represented_component_cycle_count": len(traversals),
                "represented_component_ids": list(represented_component_ids),
                "free_component_ids": list(free_component_ids),
                "split_free_component_count": len(free_component_ids),
                "normalization_theorem": (
                    "split_link_with_free_circle_has_zero_multivariable_"
                    "alexander_polynomial"
                ),
                "polynomial": "0",
                "zero_ideal_certified": True,
                "certified": True,
            }
            return {
                "multivariable_alexander_polynomial": "0",
                "candidate_polynomials": [],
                "method": "split_free_component_exact_normalization",
                "diagram": diagram.to_dict(),
                "orientation": orientation.to_dict(),
                "presentation": None,
                "square_minors": None,
                "admissible_minor_summary": summary,
                "exact_gcd_certificate": None,
                "exact_terminal_certificate": terminal_certificate,
                "variables": list(variables_tuple),
                "component_count": component_count,
                "represented_component_cycle_count": len(traversals),
                "represented_component_ids": list(represented_component_ids),
                "free_component_ids": list(free_component_ids),
                "split_free_component_count": len(free_component_ids),
                "exact_algorithm": (
                    "split_free_component_exact_normalization_v1"
                ),
                "resource_caps": None,
                "expected_maximal_minor_count": 0,
                "enumerated_maximal_minor_count": 0,
                "all_maximal_minors_enumerated": True,
                "all_maximal_minors_zero": True,
                "zero_ideal_certified": True,
                "split_free_component_certified": True,
                "requires_normalization": False,
                "skipped": False,
                "full_admissible_minor_normalization_certified": True,
                "full_invariant_certified": True,
                "notes": [
                    "an explicitly counted free circle is a split component, "
                    "so the multivariable Alexander polynomial is exactly zero"
                ],
            }
    except Exception as exc:
        return {
            "multivariable_alexander_polynomial": None,
            "method": "skipped",
            "diagram": diagram.to_dict(),
            "orientation": orientation.to_dict(),
            "requires_normalization": True,
            "skipped": True,
            "full_admissible_minor_normalization_certified": False,
            "full_invariant_certified": False,
            "failure_reason": f"{type(exc).__name__}: {exc}",
            "notes": ["signed-PD component validation failed closed"],
        }

    try:
        presentation = wirtinger_presentation_from_oriented_pd(
            diagram,
            orientation,
            variables=variables,
        )
    except Exception as exc:
        return {
            "multivariable_alexander_polynomial": None,
            "method": "skipped",
            "diagram": diagram.to_dict(),
            "orientation": orientation.to_dict(),
            "requires_normalization": True,
            "skipped": True,
            "full_admissible_minor_normalization_certified": False,
            "full_invariant_certified": False,
            "failure_reason": f"{type(exc).__name__}: {exc}",
            "notes": ["signed-PD to Wirtinger conversion failed closed"],
        }
    result = multivariable_alexander_exact_from_presentation(presentation)
    result["diagram"] = diagram.to_dict()
    result["orientation"] = orientation.to_dict()
    return result


def multivariable_alexander_exact_result_audit(result: Mapping[str, object]) -> dict:
    """Replay an exact result and its signed-PD bridge when available."""

    terminal_method = result.get("method")
    if terminal_method in {
        "zero_crossing_unlink_exact_normalization",
        "split_free_component_exact_normalization",
    }:
        zero_crossing_terminal = (
            terminal_method == "zero_crossing_unlink_exact_normalization"
        )
        expected_algorithm = (
            "zero_crossing_unlink_exact_normalization_v1"
            if zero_crossing_terminal
            else "split_free_component_exact_normalization_v1"
        )
        diagram_payload = result.get("diagram")
        orientation_payload = result.get("orientation")
        terminal_certificate = result.get("exact_terminal_certificate")
        component_count = result.get("component_count")
        checks = {
            "result_not_skipped": result.get("skipped") is False,
            "exact_method": result.get("exact_algorithm") == expected_algorithm,
            "resource_caps_absent": result.get("resource_caps") is None,
            "diagram_available": isinstance(diagram_payload, dict),
            "orientation_available": isinstance(orientation_payload, dict),
            "presentation_absent": result.get("presentation") is None,
        }
        common_terminal_semantics = bool(
            isinstance(terminal_certificate, Mapping)
            and terminal_certificate.get("method") == expected_algorithm
            and terminal_certificate.get("certified") is True
            and terminal_certificate.get("polynomial")
            == result.get("multivariable_alexander_polynomial")
            and terminal_certificate.get("zero_ideal_certified")
            is result.get("zero_ideal_certified")
            and result.get("full_admissible_minor_normalization_certified")
            is True
            and result.get("full_invariant_certified") is True
        )
        if zero_crossing_terminal:
            positive_component_count = bool(
                isinstance(component_count, int)
                and not isinstance(component_count, bool)
                and component_count > 0
            )
            expected_polynomial = (
                "1" if component_count == 1 else "0"
            )
            expected_zero_ideal = bool(
                positive_component_count and component_count > 1
            )
            checks["terminal_certificate_semantics"] = bool(
                common_terminal_semantics
                and positive_component_count
                and isinstance(terminal_certificate, Mapping)
                and terminal_certificate.get("component_count")
                == component_count
                and terminal_certificate.get("normalization_axiom")
                == (
                    "unknot_equals_one"
                    if component_count == 1
                    else "split_multicomponent_unlink_equals_zero"
                )
                and result.get("multivariable_alexander_polynomial")
                == expected_polynomial
                and result.get("zero_ideal_certified")
                is expected_zero_ideal
                and result.get("zero_crossing_unlink_certified") is True
            )
        else:
            represented_ids = result.get("represented_component_ids")
            free_ids = result.get("free_component_ids")
            ids_partition_valid = bool(
                isinstance(component_count, int)
                and not isinstance(component_count, bool)
                and component_count > 1
                and isinstance(represented_ids, list)
                and isinstance(free_ids, list)
                and free_ids
                and all(
                    isinstance(value, int) and not isinstance(value, bool)
                    for value in represented_ids + free_ids
                )
                and len(set(represented_ids)) == len(represented_ids)
                and len(set(free_ids)) == len(free_ids)
                and not (set(represented_ids) & set(free_ids))
                and set(represented_ids) | set(free_ids)
                == set(range(component_count))
            )
            checks["terminal_certificate_semantics"] = bool(
                common_terminal_semantics
                and ids_partition_valid
                and isinstance(terminal_certificate, Mapping)
                and terminal_certificate.get("component_count")
                == component_count
                and terminal_certificate.get("represented_component_ids")
                == represented_ids
                and terminal_certificate.get("free_component_ids") == free_ids
                and terminal_certificate.get("represented_component_cycle_count")
                == result.get("represented_component_cycle_count")
                == len(represented_ids)
                and terminal_certificate.get("split_free_component_count")
                == result.get("split_free_component_count")
                == len(free_ids)
                and terminal_certificate.get("normalization_theorem")
                == (
                    "split_link_with_free_circle_has_zero_multivariable_"
                    "alexander_polynomial"
                )
                and result.get("multivariable_alexander_polynomial") == "0"
                and result.get("zero_ideal_certified") is True
                and result.get("split_free_component_certified") is True
            )
        recomputed: dict | None = None
        recompute_error: str | None = None
        if isinstance(diagram_payload, dict) and isinstance(
            orientation_payload,
            dict,
        ):
            try:
                diagram = PlanarDiagram.from_dict(diagram_payload)
                orientation = PDOrientation.from_dict(orientation_payload)
                recomputed = multivariable_alexander_exact_from_oriented_pd(
                    diagram,
                    orientation,
                    variables=tuple(str(value) for value in result.get("variables", [])),
                )
            except Exception as exc:
                recompute_error = f"{type(exc).__name__}: {exc}"
        checks["recompute_succeeded"] = bool(
            isinstance(recomputed, dict) and recomputed.get("skipped") is False
        )
        comparable_fields = (
            "multivariable_alexander_polynomial",
            "candidate_polynomials",
            "method",
            "presentation",
            "square_minors",
            "admissible_minor_summary",
            "exact_gcd_certificate",
            "exact_terminal_certificate",
            "variables",
            "component_count",
            "exact_algorithm",
            "resource_caps",
            "expected_maximal_minor_count",
            "enumerated_maximal_minor_count",
            "all_maximal_minors_enumerated",
            "all_maximal_minors_zero",
            "zero_ideal_certified",
            "requires_normalization",
            "skipped",
            "full_admissible_minor_normalization_certified",
            "full_invariant_certified",
        )
        comparable_fields += (
            ("zero_crossing_unlink_certified",)
            if zero_crossing_terminal
            else (
                "represented_component_cycle_count",
                "represented_component_ids",
                "free_component_ids",
                "split_free_component_count",
                "split_free_component_certified",
            )
        )
        checks["recomputed_fields_match"] = bool(
            recomputed is not None
            and all(
                result.get(field) == recomputed.get(field)
                for field in comparable_fields
            )
        )
        failed_checks = [name for name, passed in checks.items() if not passed]
        return {
            "method": "multivariable_alexander_exact_result_audit",
            "claim_scope": (
                "exact_zero_crossing_unlink_normalization_replay"
                if zero_crossing_terminal
                else "exact_split_free_component_normalization_replay"
            ),
            "certified": not failed_checks,
            "checks": checks,
            "failed_check_count": len(failed_checks),
            "failed_checks": failed_checks,
            "recompute_error": recompute_error,
        }

    presentation_payload = result.get("presentation")
    fox_identity_certificate = result.get(
        "fox_fundamental_identity_certificate"
    )
    checks = {
        "result_not_skipped": result.get("skipped") is False,
        "exact_method": result.get("method")
        == "fox_all_maximal_minors_exact_sympy_zz_gcd",
        "exact_algorithm_label": result.get("exact_algorithm")
        == "all_maximal_fox_minors_sympy_zz_gcd_v1",
        "resource_caps_absent": result.get("resource_caps") is None,
        "presentation_available": isinstance(presentation_payload, dict),
        "fox_fundamental_identity_certified": bool(
            isinstance(fox_identity_certificate, Mapping)
            and fox_identity_certificate.get("certified") is True
            and fox_identity_certificate.get(
                "all_fox_fundamental_identities_hold"
            )
            is True
            and fox_identity_certificate.get(
                "all_relators_abelianize_to_identity"
            )
            is True
        ),
    }
    certificate = result.get("exact_gcd_certificate")
    if isinstance(certificate, Mapping):
        if certificate.get("all_inputs_zero") is True:
            empty_input_family = certificate.get("empty_input_family") is True
            expected_zero_basis = (
                "no_admissible_maximal_minors"
                if empty_input_family
                else "all_enumerated_ideal_generators_zero"
            )
            checks["exact_gcd_certificate_semantics"] = bool(
                certificate.get("candidate_polynomial") == "0"
                and certificate.get("candidate_is_zero") is True
                and certificate.get("zero_ideal_certified") is True
                and certificate.get("exact_gcd_certification_basis")
                == expected_zero_basis
                and certificate.get("input_count")
                == result.get("enumerated_maximal_minor_count")
                and (
                    not empty_input_family
                    or (
                        result.get("expected_maximal_minor_count") == 0
                        and result.get("enumerated_maximal_minor_count") == 0
                    )
                )
                and certificate.get("quotient_gcd_certified") is False
                and certificate.get("quotient_gcd_polynomial") is None
                and result.get("all_maximal_minors_zero") is True
                and result.get("zero_ideal_certified") is True
            )
        else:
            checks["exact_gcd_certificate_semantics"] = bool(
                certificate.get("candidate_is_zero") is False
                and certificate.get("empty_input_family") is False
                and certificate.get("zero_ideal_certified") is False
                and certificate.get("exact_gcd_certification_basis")
                == "exact_division_and_quotient_gcd_one"
                and certificate.get("quotient_gcd_certified") is True
                and certificate.get("quotient_gcd_polynomial") == "1"
                and result.get("all_maximal_minors_zero") is False
                and result.get("zero_ideal_certified") is False
            )
    else:
        checks["exact_gcd_certificate_semantics"] = False
    recomputed: dict | None = None
    recompute_error: str | None = None
    oriented_pd_bridge_error: str | None = None
    diagram_payload = result.get("diagram")
    orientation_payload = result.get("orientation")
    if diagram_payload is not None or orientation_payload is not None:
        checks["oriented_pd_payload_complete"] = bool(
            isinstance(diagram_payload, dict)
            and isinstance(orientation_payload, dict)
        )
        reconstructed_presentation: WirtingerPresentation | None = None
        if isinstance(diagram_payload, dict) and isinstance(
            orientation_payload,
            dict,
        ):
            try:
                reconstructed_presentation = (
                    wirtinger_presentation_from_oriented_pd(
                        PlanarDiagram.from_dict(diagram_payload),
                        PDOrientation.from_dict(orientation_payload),
                        variables=tuple(
                            str(value)
                            for value in result.get("variables", [])
                        ),
                    )
                )
            except Exception as exc:
                oriented_pd_bridge_error = f"{type(exc).__name__}: {exc}"
        checks["oriented_pd_presentation_matches"] = bool(
            reconstructed_presentation is not None
            and isinstance(presentation_payload, dict)
            and reconstructed_presentation.to_dict() == presentation_payload
        )
    if isinstance(presentation_payload, dict):
        try:
            presentation = WirtingerPresentation(
                relations=tuple(
                    tuple((int(term[0]), int(term[1])) for term in relation)
                    for relation in presentation_payload["relations"]
                ),
                generator_components=tuple(
                    int(value) for value in presentation_payload["generator_components"]
                ),
                variables=tuple(str(value) for value in presentation_payload["variables"]),
                source=str(presentation_payload.get("source", "explicit")),
                convention=str(presentation_payload.get("convention", "")),
            )
            recomputed = multivariable_alexander_exact_from_presentation(presentation)
        except Exception as exc:
            recompute_error = f"{type(exc).__name__}: {exc}"
    checks["recompute_succeeded"] = (
        isinstance(recomputed, dict) and recomputed.get("skipped") is False
    )
    comparable_fields = (
        "multivariable_alexander_polynomial",
        "candidate_polynomials",
        "method",
        "presentation",
        "square_minors",
        "admissible_minor_summary",
        "exact_gcd_certificate",
        "fox_fundamental_identity_certificate",
        "variables",
        "exact_algorithm",
        "resource_caps",
        "expected_maximal_minor_count",
        "enumerated_maximal_minor_count",
        "all_maximal_minors_enumerated",
        "all_maximal_minors_zero",
        "zero_ideal_certified",
        "requires_normalization",
        "skipped",
        "full_admissible_minor_normalization_certified",
        "full_invariant_certified",
    )
    checks["recomputed_fields_match"] = bool(
        recomputed is not None
        and all(result.get(field) == recomputed.get(field) for field in comparable_fields)
    )
    failed_checks = [name for name, passed in checks.items() if not passed]
    return {
        "method": "multivariable_alexander_exact_result_audit",
        "claim_scope": "uncapped_exact_all_maximal_fox_minor_gcd_replay",
        "certified": not failed_checks,
        "checks": checks,
        "failed_check_count": len(failed_checks),
        "failed_checks": failed_checks,
        "recompute_error": recompute_error,
        "oriented_pd_bridge_error": oriented_pd_bridge_error,
    }


def multivariable_alexander_candidates_from_presentation(
    presentation: WirtingerPresentation,
    *,
    target_size: int | None = None,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    """Return bounded Fox-minor candidates without claiming final normalization."""

    effective_target_size = (
        target_size
        if target_size is not None
        else _default_alexander_minor_size(presentation)
    )
    scan = fox_square_minors_from_presentation(
        presentation.relations,
        generator_components=presentation.generator_components,
        variables=presentation.variables,
        target_size=effective_target_size,
        max_matrix_size=max_matrix_size,
        max_minors=max_minors,
    )
    if scan["skipped"]:
        return {
            "multivariable_alexander_polynomial": None,
            "candidate_polynomials": [],
            "method": "skipped",
            "presentation": presentation.to_dict(),
            "square_minors": scan,
            "admissible_minor_summary": scan["admissible_minor_summary"],
            "requires_normalization": True,
            "skipped": True,
            "notes": [
                "multi-variable Alexander candidate scan skipped",
                *scan["notes"],
            ],
        }

    candidates = _unique_nonzero_minor_polynomials(scan["minors"])
    return {
        "multivariable_alexander_polynomial": None,
        "candidate_polynomials": candidates,
        "method": "fox_square_minor_candidate_scan",
        "presentation": presentation.to_dict(),
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": True,
        "skipped": False,
        "notes": [
            "candidate_polynomials are normalized square Fox minors, not a final multi-variable Alexander invariant",
            "final invariant still requires admissible-minor selection or gcd normalization",
        ],
    }


def multivariable_alexander_gcd_from_presentation(
    presentation: WirtingerPresentation,
    *,
    target_size: int | None = None,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    """Conservatively summarize bounded Fox minors by a common divisor.

    This is intentionally stricter than a full multivariate polynomial gcd.
    It returns a polynomial only when the scanned minors make the conclusion
    immediate: all minors are zero, at least one scanned minor is a unit,
    every nonzero normalized minor agrees exactly, or a bounded exact divisor
    check proves a common factor.
    """

    effective_target_size = (
        target_size
        if target_size is not None
        else _default_alexander_minor_size(presentation)
    )
    scan = fox_square_minors_from_presentation(
        presentation.relations,
        generator_components=presentation.generator_components,
        variables=presentation.variables,
        target_size=effective_target_size,
        max_matrix_size=max_matrix_size,
        max_minors=max_minors,
    )
    if scan["skipped"]:
        return _gcd_skipped(
            presentation,
            scan,
            notes=[
                "multi-variable Alexander gcd summary skipped",
                *scan["notes"],
            ],
        )
    if scan["truncated"]:
        return _gcd_skipped(
            presentation,
            scan,
            notes=[
                "multi-variable Alexander gcd summary skipped because minor scan was truncated",
            ],
        )

    nonzero_minors = [minor for minor in scan["minors"] if not minor["is_zero"]]
    if not nonzero_minors:
        return {
            "multivariable_alexander_polynomial": "0",
            "candidate_polynomials": [],
            "method": "fox_square_minor_zero_gcd",
            "presentation": presentation.to_dict(),
            "square_minors": scan,
            "admissible_minor_summary": scan["admissible_minor_summary"],
            "requires_normalization": False,
            "skipped": False,
            "notes": [
                "all scanned square Fox minors are zero",
                "result is still tied to the documented presentation convention",
            ],
        }

    candidates = _unique_nonzero_minor_polynomials(nonzero_minors)
    if any(minor["is_unit"] for minor in nonzero_minors):
        return {
            "multivariable_alexander_polynomial": "1",
            "candidate_polynomials": candidates,
            "method": "fox_square_minor_unit_gcd",
            "presentation": presentation.to_dict(),
            "square_minors": scan,
            "admissible_minor_summary": scan["admissible_minor_summary"],
            "requires_normalization": False,
            "skipped": False,
            "notes": [
                "a scanned square Fox minor is a unit, so the common divisor over the scanned set is 1",
                "full invariant completion still requires fixture-backed admissible-minor convention checks",
            ],
        }
    if len(candidates) == 1:
        return {
            "multivariable_alexander_polynomial": candidates[0],
            "candidate_polynomials": candidates,
            "method": "fox_square_minor_consensus_gcd",
            "presentation": presentation.to_dict(),
            "square_minors": scan,
            "admissible_minor_summary": scan["admissible_minor_summary"],
            "requires_normalization": False,
            "skipped": False,
            "notes": [
                "all nonzero normalized square Fox minors agree on one polynomial",
                "full invariant completion still requires fixture-backed admissible-minor convention checks",
            ],
        }
    common_gcd = _conservative_common_gcd_with_evidence_from_minors(
        nonzero_minors,
        variables=presentation.variables,
    )
    if common_gcd is not None:
        polynomial, method, note, evidence = common_gcd
        result = {
            "multivariable_alexander_polynomial": polynomial.format(),
            "candidate_polynomials": candidates,
            "method": method,
            "presentation": presentation.to_dict(),
            "square_minors": scan,
            "admissible_minor_summary": scan["admissible_minor_summary"],
            "common_gcd_evidence": evidence,
            "requires_normalization": False,
            "skipped": False,
            "notes": [
                note,
                "result is a conservative common divisor of the bounded scanned minors",
                "full fixture-backed admissible-minor convention checks are still required before claiming complete link coverage",
            ],
        }
        return _promote_scanned_gcd_result_if_certified(result)
    return _gcd_skipped(
        presentation,
        scan,
        notes=[
            "scanned square Fox minors do not have an immediate unit or consensus gcd",
            "a full multivariate Laurent gcd/admissible-minor implementation is still required",
        ],
        candidate_polynomials=candidates,
        extra_fields={
            "common_gcd_attempt_evidence": (
                _common_gcd_attempt_evidence_from_minors(
                    nonzero_minors,
                    variables=presentation.variables,
                    status="not_certified",
                    notes=[
                        "conservative bounded common-gcd search did not certify a common non-unit factor",
                        "result remains skipped rather than claiming a completed multi-variable Alexander invariant",
                    ],
                )
            ),
        },
    )


def multivariable_alexander_minor_divisibility_audit(result: dict) -> dict:
    """Audit whether the reported Alexander result divides scanned Fox minors.

    The audit intentionally proves only a bounded scanned-minor claim. It does
    not certify the full multi-variable Alexander normalization convention.
    """

    scan = result.get("square_minors")
    summary = result.get("admissible_minor_summary")
    polynomial_text = result.get("multivariable_alexander_polynomial")
    variables = _audit_variables(result)
    base_payload = {
        "method": "multivariable_alexander_minor_divisibility_audit",
        "source_method": result.get("method"),
        "multivariable_alexander_polynomial": polynomial_text,
        "variables": list(variables),
        "candidate_polynomials": list(result.get("candidate_polynomials", [])),
        "claim_scope": "bounded_scanned_fox_minor_divisibility",
        "full_invariant_certified": False,
        **_empty_division_failure_witness_fields(),
    }
    if result.get("skipped", False) or polynomial_text is None:
        return {
            **base_payload,
            "skipped": True,
            "all_nonzero_minors_divisible": False,
            "checked_nonzero_minor_count": 0,
            "failed_nonzero_minor_count": 0,
            "division_records": [],
            "failed_minor_indices": [],
            "complete_combination_scan": False,
            "truncated": bool(scan.get("truncated")) if isinstance(scan, dict) else False,
            "admissible_minor_summary": summary,
            "notes": [
                "source Alexander result did not return a polynomial",
                *list(result.get("notes", [])),
            ],
        }
    if not isinstance(scan, dict):
        return {
            **base_payload,
            "skipped": True,
            "all_nonzero_minors_divisible": False,
            "checked_nonzero_minor_count": 0,
            "failed_nonzero_minor_count": 0,
            "division_records": [],
            "failed_minor_indices": [],
            "complete_combination_scan": False,
            "truncated": False,
            "admissible_minor_summary": summary,
            "notes": ["source Alexander result does not include square-minor scan data"],
        }
    if scan.get("skipped", False):
        return {
            **base_payload,
            "skipped": True,
            "all_nonzero_minors_divisible": False,
            "checked_nonzero_minor_count": 0,
            "failed_nonzero_minor_count": 0,
            "division_records": [],
            "failed_minor_indices": [],
            "complete_combination_scan": False,
            "truncated": bool(scan.get("truncated", False)),
            "admissible_minor_summary": summary or scan.get("admissible_minor_summary"),
            "notes": [
                "source square-minor scan was skipped",
                *list(scan.get("notes", [])),
            ],
        }
    if not variables:
        return {
            **base_payload,
            "skipped": True,
            "all_nonzero_minors_divisible": False,
            "checked_nonzero_minor_count": 0,
            "failed_nonzero_minor_count": 0,
            "division_records": [],
            "failed_minor_indices": [],
            "complete_combination_scan": False,
            "truncated": bool(scan.get("truncated", False)),
            "admissible_minor_summary": summary or scan.get("admissible_minor_summary"),
            "notes": ["source square-minor scan does not expose variable names"],
        }

    divisor = parse_multivariate_laurent_polynomial(
        str(polynomial_text),
        variables=variables,
    ).normalize_unit()
    minors = list(scan.get("minors", []))
    nonzero_minors = [
        (index, minor)
        for index, minor in enumerate(minors)
        if not minor.get("is_zero", False)
    ]
    if divisor.is_zero:
        all_divisible = not nonzero_minors
        return {
            **base_payload,
            "divisor_terms": _serialized_terms(divisor),
            "skipped": False,
            "all_nonzero_minors_divisible": all_divisible,
            "checked_nonzero_minor_count": len(nonzero_minors),
            "failed_nonzero_minor_count": len(nonzero_minors),
            "division_records": [],
            "failed_minor_indices": [index for index, _ in nonzero_minors],
            **_division_failure_witness_fields_from_minors(
                nonzero_minors,
                reason="zero_divisor_nonzero_minor",
            ),
            "complete_combination_scan": bool(
                (summary or scan.get("admissible_minor_summary") or {}).get(
                    "complete_combination_scan",
                    False,
                )
            ),
            "truncated": bool(scan.get("truncated", False)),
            "admissible_minor_summary": summary or scan.get("admissible_minor_summary"),
            "notes": [
                "reported zero polynomial is accepted only when every scanned Fox minor is zero",
                "this is bounded scan evidence, not full multi-variable Alexander certification",
            ],
        }

    division_records = []
    failed_indices = []
    for index, minor in nonzero_minors:
        minor_polynomial = _polynomial_from_serialized_terms(
            minor.get("terms", []),
            variables=variables,
        )
        quotient = _exact_multivariate_division(minor_polynomial, divisor)
        divisible = quotient is not None
        if not divisible:
            failed_indices.append(index)
        division_records.append(
            {
                "minor_index": index,
                "rows": list(minor.get("rows", [])),
                "columns": list(minor.get("columns", [])),
                "minor_polynomial": minor.get("polynomial"),
                "divisible": divisible,
                "quotient_polynomial": (
                    quotient.normalize_unit().format()
                    if quotient is not None
                    else None
                ),
            }
        )

    effective_summary = summary or scan.get("admissible_minor_summary") or {}
    all_divisible = not failed_indices
    notes = [
        "reported polynomial divides every nonzero scanned Fox minor by exact multivariate division"
        if all_divisible
        else "reported polynomial failed exact division against at least one scanned Fox minor",
        "this audit proves bounded scanned-minor divisibility only; full admissible-minor normalization is still a separate requirement",
    ]
    if scan.get("truncated", False) or not effective_summary.get(
        "complete_combination_scan",
        False,
    ):
        notes.append(
            "the square-minor scan is incomplete or truncated, so the audit cannot support a complete invariant claim",
        )

    return {
        **base_payload,
        "divisor_terms": _serialized_terms(divisor),
        "skipped": False,
        "all_nonzero_minors_divisible": all_divisible,
        "checked_nonzero_minor_count": len(nonzero_minors),
        "failed_nonzero_minor_count": len(failed_indices),
        "division_records": division_records,
        "failed_minor_indices": failed_indices,
        **_division_failure_witness_fields(division_records),
        "complete_combination_scan": bool(
            effective_summary.get("complete_combination_scan", False)
        ),
        "truncated": bool(scan.get("truncated", False)),
        "admissible_minor_summary": effective_summary,
        "notes": notes,
    }


def _empty_admissible_minor_normalization_witness_fields() -> dict:
    witness_count = 0
    witness_limit = _ADMISSIBLE_MINOR_NORMALIZATION_MISMATCH_WITNESS_LIMIT
    witness_truncated = False
    witnesses: list[dict] = []
    return {
        "normalization_representative_witness": None,
        "normalization_mismatch_witness_count": witness_count,
        "normalization_mismatch_witness_limit": witness_limit,
        "normalization_mismatch_witness_truncated": witness_truncated,
        "normalization_mismatch_witnesses": witnesses,
        "normalization_mismatch_witness_consistency": (
            _bounded_witness_consistency_summary(
                witness_kind="normalization_mismatch",
                witness_count=witness_count,
                witness_limit=witness_limit,
                witness_truncated=witness_truncated,
                witnesses=witnesses,
            )
        ),
    }


def _admissible_minor_normalization_record_witness(record: dict) -> dict:
    return {
        "minor_index": int(record["minor_index"]),
        "rows": list(record.get("rows", [])),
        "columns": list(record.get("columns", [])),
        "raw_polynomial": record.get("raw_polynomial"),
        "minor_polynomial": record.get("minor_polynomial"),
        "normalized_polynomial": record.get("normalized_polynomial"),
    }


def _admissible_minor_normalization_mismatch_witness(
    representative_record: dict,
    mismatch_record: dict,
) -> dict:
    return {
        "representative_minor_index": int(representative_record["minor_index"]),
        "representative_rows": list(representative_record.get("rows", [])),
        "representative_columns": list(representative_record.get("columns", [])),
        "representative_normalized_polynomial": representative_record.get(
            "normalized_polynomial"
        ),
        "mismatched_minor_index": int(mismatch_record["minor_index"]),
        "mismatched_rows": list(mismatch_record.get("rows", [])),
        "mismatched_columns": list(mismatch_record.get("columns", [])),
        "mismatched_normalized_polynomial": mismatch_record.get(
            "normalized_polynomial"
        ),
        "mismatched_raw_polynomial": mismatch_record.get("raw_polynomial"),
        "mismatched_minor_polynomial": mismatch_record.get("minor_polynomial"),
    }


def multivariable_alexander_admissible_minor_normalization_audit(
    result: dict,
) -> dict:
    """Audit Laurent-unit normalization agreement across scanned nonzero minors.

    The audit is deliberately bounded: it checks only the square Fox minors
    already present in ``result["square_minors"]``. A positive bounded
    certificate says those scanned nonzero minors normalize to one representative
    under the deterministic Laurent-unit convention and that the scan was
    complete with nonzero row/column coverage. It is not a full table or
    arbitrary admissible-minor normalization claim.
    """

    scan = result.get("square_minors")
    summary = result.get("admissible_minor_summary")
    variables = _audit_variables(result)
    base_payload = {
        "method": "multivariable_alexander_admissible_minor_normalization_audit",
        "source_method": result.get("method"),
        "multivariable_alexander_polynomial": result.get(
            "multivariable_alexander_polynomial"
        ),
        "variables": list(variables),
        "candidate_polynomials": list(result.get("candidate_polynomials", [])),
        "claim_scope": (
            "bounded_scanned_fox_admissible_minor_laurent_unit_normalization"
        ),
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        **_full_alexander_completion_blocker_summary(
            full_admissible_minor_normalization_certified=False,
            full_invariant_certified=False,
            claim_scope=(
                "bounded_scanned_fox_admissible_minor_laurent_unit_normalization"
            ),
        ),
    }
    if not isinstance(scan, dict):
        normalization_blockers = _admissible_minor_normalization_blocker_summary(
            scan_missing=True,
        )
        bounded_blocker_witness_summary = normalization_blockers[
            "bounded_admissible_minor_normalization_blocker_witness_summary"
        ]
        gate_summary = _bounded_admissible_minor_normalization_gate_summary(
            claim_scope=(
                "bounded_scanned_fox_admissible_minor_laurent_unit_normalization"
            ),
            blockers=normalization_blockers[
                "admissible_minor_normalization_blockers"
            ],
            blocker_witness_summary=bounded_blocker_witness_summary,
            scan_missing=True,
            checked_nonzero_minor_count=0,
            complete_combination_scan=False,
            truncated=False,
            all_rows_have_nonzero_minor=False,
            all_columns_have_nonzero_minor=False,
            bounded_admissible_minor_normalization_certified=False,
        )
        return {
            **base_payload,
            "skipped": True,
            "normalized_representative_polynomial": None,
            "all_nonzero_minors_laurent_unit_equivalent": False,
            "bounded_admissible_minor_normalization_certified": False,
            "checked_nonzero_minor_count": 0,
            "failed_nonzero_minor_count": 0,
            "failed_minor_indices": [],
            "normalization_records": [],
            "normalization_class_counts": [],
            "normalization_class_count": 0,
            "largest_normalization_class_minor_count": 0,
            "representative_normalization_class_minor_count": 0,
            "nonrepresentative_normalization_class_count": 0,
            **_empty_admissible_minor_normalization_witness_fields(),
            "expected_combination_count": 0,
            "scanned_minor_count": 0,
            "nonzero_minor_count": 0,
            "zero_minor_count": 0,
            "unit_minor_count": 0,
            "unique_nonzero_polynomial_count": 0,
            "all_rows_have_nonzero_minor": False,
            "all_columns_have_nonzero_minor": False,
            "complete_combination_scan": False,
            "nonzero_minor_coverage_complete": False,
            "truncated": False,
            "admissible_minor_summary": summary,
            "bounded_admissible_minor_normalization_gate_summary": gate_summary,
            **normalization_blockers,
            "notes": [
                "source Alexander result does not include square-minor scan data",
            ],
        }
    if scan.get("skipped", False):
        normalization_blockers = _admissible_minor_normalization_blocker_summary(
            scan_skipped=True,
            truncated=bool(scan.get("truncated", False)),
        )
        bounded_blocker_witness_summary = normalization_blockers[
            "bounded_admissible_minor_normalization_blocker_witness_summary"
        ]
        gate_summary = _bounded_admissible_minor_normalization_gate_summary(
            claim_scope=(
                "bounded_scanned_fox_admissible_minor_laurent_unit_normalization"
            ),
            blockers=normalization_blockers[
                "admissible_minor_normalization_blockers"
            ],
            blocker_witness_summary=bounded_blocker_witness_summary,
            scan_skipped=True,
            checked_nonzero_minor_count=0,
            complete_combination_scan=False,
            truncated=bool(scan.get("truncated", False)),
            all_rows_have_nonzero_minor=False,
            all_columns_have_nonzero_minor=False,
            bounded_admissible_minor_normalization_certified=False,
        )
        return {
            **base_payload,
            "skipped": True,
            "normalized_representative_polynomial": None,
            "all_nonzero_minors_laurent_unit_equivalent": False,
            "bounded_admissible_minor_normalization_certified": False,
            "checked_nonzero_minor_count": 0,
            "failed_nonzero_minor_count": 0,
            "failed_minor_indices": [],
            "normalization_records": [],
            "normalization_class_counts": [],
            "normalization_class_count": 0,
            "largest_normalization_class_minor_count": 0,
            "representative_normalization_class_minor_count": 0,
            "nonrepresentative_normalization_class_count": 0,
            **_empty_admissible_minor_normalization_witness_fields(),
            "expected_combination_count": 0,
            "scanned_minor_count": 0,
            "nonzero_minor_count": 0,
            "zero_minor_count": 0,
            "unit_minor_count": 0,
            "unique_nonzero_polynomial_count": 0,
            "all_rows_have_nonzero_minor": False,
            "all_columns_have_nonzero_minor": False,
            "complete_combination_scan": False,
            "nonzero_minor_coverage_complete": False,
            "truncated": bool(scan.get("truncated", False)),
            "admissible_minor_summary": summary or scan.get("admissible_minor_summary"),
            "bounded_admissible_minor_normalization_gate_summary": gate_summary,
            **normalization_blockers,
            "notes": [
                "source square-minor scan was skipped",
                *list(scan.get("notes", [])),
            ],
        }
    if not variables:
        scanned_minor_count = _blocker_int(
            len(scan.get("minors", []))
            if isinstance(scan.get("minors", []), list)
            else 0
        )
        normalization_blockers = _admissible_minor_normalization_blocker_summary(
            variables_missing=True,
            truncated=bool(scan.get("truncated", False)),
            scanned_minor_count=scanned_minor_count,
        )
        bounded_blocker_witness_summary = normalization_blockers[
            "bounded_admissible_minor_normalization_blocker_witness_summary"
        ]
        gate_summary = _bounded_admissible_minor_normalization_gate_summary(
            claim_scope=(
                "bounded_scanned_fox_admissible_minor_laurent_unit_normalization"
            ),
            blockers=normalization_blockers[
                "admissible_minor_normalization_blockers"
            ],
            blocker_witness_summary=bounded_blocker_witness_summary,
            variables_missing=True,
            checked_nonzero_minor_count=0,
            scanned_gcd_audit_skipped=False,
            complete_combination_scan=False,
            truncated=bool(scan.get("truncated", False)),
            all_rows_have_nonzero_minor=False,
            all_columns_have_nonzero_minor=False,
            bounded_admissible_minor_normalization_certified=False,
        )
        return {
            **base_payload,
            "skipped": True,
            "normalized_representative_polynomial": None,
            "all_nonzero_minors_laurent_unit_equivalent": False,
            "bounded_admissible_minor_normalization_certified": False,
            "checked_nonzero_minor_count": 0,
            "failed_nonzero_minor_count": 0,
            "failed_minor_indices": [],
            "normalization_records": [],
            "normalization_class_counts": [],
            "normalization_class_count": 0,
            "largest_normalization_class_minor_count": 0,
            "representative_normalization_class_minor_count": 0,
            "nonrepresentative_normalization_class_count": 0,
            **_empty_admissible_minor_normalization_witness_fields(),
            "expected_combination_count": 0,
            "scanned_minor_count": 0,
            "nonzero_minor_count": 0,
            "zero_minor_count": 0,
            "unit_minor_count": 0,
            "unique_nonzero_polynomial_count": 0,
            "all_rows_have_nonzero_minor": False,
            "all_columns_have_nonzero_minor": False,
            "complete_combination_scan": False,
            "nonzero_minor_coverage_complete": False,
            "truncated": bool(scan.get("truncated", False)),
            "admissible_minor_summary": summary or scan.get("admissible_minor_summary"),
            "bounded_admissible_minor_normalization_gate_summary": gate_summary,
            **normalization_blockers,
            "notes": ["source square-minor scan does not expose variable names"],
        }

    effective_summary = summary or scan.get("admissible_minor_summary") or {}
    minors = list(scan.get("minors", []))

    def _summary_int(name: str, fallback: int = 0) -> int:
        value = effective_summary.get(name, fallback)
        if isinstance(value, bool):
            return int(value)
        try:
            return int(value)
        except (TypeError, ValueError):
            return fallback

    records: list[dict] = []
    normalized_class_counts: dict[str, int] = {}
    normalized_class_first_records: dict[str, dict] = {}
    nonzero_records: list[dict] = []
    for index, minor in enumerate(minors):
        if minor.get("is_zero", False):
            continue
        try:
            raw_polynomial = _polynomial_from_serialized_terms(
                minor.get("raw_terms", minor.get("terms", [])),
                variables=variables,
            )
            normalized = raw_polynomial.normalize_unit()
        except (KeyError, TypeError, ValueError):
            normalized = _polynomial_from_serialized_terms(
                minor.get("terms", []),
                variables=variables,
            ).normalize_unit()
        normalized_text = normalized.format()
        record = {
            "minor_index": index,
            "rows": list(minor.get("rows", [])),
            "columns": list(minor.get("columns", [])),
            "raw_polynomial": minor.get("raw_polynomial"),
            "minor_polynomial": minor.get("polynomial"),
            "normalized_polynomial": normalized_text,
            "normalized_terms": _serialized_terms(normalized),
        }
        records.append(record)
        nonzero_records.append(record)
        normalized_class_counts[normalized_text] = (
            normalized_class_counts.get(normalized_text, 0) + 1
        )
        normalized_class_first_records.setdefault(normalized_text, record)

    representative = (
        nonzero_records[0]["normalized_polynomial"] if nonzero_records else None
    )
    failed_indices = [
        int(record["minor_index"])
        for record in nonzero_records
        if record["normalized_polynomial"] != representative
    ]
    for record in nonzero_records:
        record["matches_representative"] = (
            record["normalized_polynomial"] == representative
        )
    representative_record = nonzero_records[0] if nonzero_records else None
    representative_witness = (
        _admissible_minor_normalization_record_witness(representative_record)
        if representative_record is not None
        else None
    )
    mismatch_records = [
        record
        for record in nonzero_records
        if record["normalized_polynomial"] != representative
    ]
    witness_limit = _ADMISSIBLE_MINOR_NORMALIZATION_MISMATCH_WITNESS_LIMIT
    mismatch_witnesses = (
        [
            _admissible_minor_normalization_mismatch_witness(
                representative_record,
                record,
            )
            for record in mismatch_records[:witness_limit]
        ]
        if representative_record is not None
        else []
    )
    mismatch_witness_truncated = len(mismatch_records) > len(mismatch_witnesses)
    mismatch_witness_consistency = _bounded_witness_consistency_summary(
        witness_kind="normalization_mismatch",
        witness_count=len(mismatch_records),
        witness_limit=witness_limit,
        witness_truncated=mismatch_witness_truncated,
        witnesses=mismatch_witnesses,
    )
    all_equivalent = bool(nonzero_records) and not failed_indices
    complete = bool(effective_summary.get("complete_combination_scan", False))
    nonzero_coverage_complete = bool(
        effective_summary.get("nonzero_minor_coverage_complete", False)
    )
    truncated = bool(scan.get("truncated", False))
    bounded_certified = bool(
        all_equivalent
        and complete
        and nonzero_coverage_complete
        and not truncated
    )
    notes = [
        (
            "all scanned nonzero Fox minors normalize to one Laurent-unit representative"
            if all_equivalent
            else "scanned nonzero Fox minors normalize to more than one representative"
        ),
        "this audit is bounded to the scanned Fox-minor set and does not certify full admissible-minor normalization",
    ]
    if not nonzero_records:
        notes.insert(0, "the square-minor scan contains no nonzero admissible-minor candidates")
    if truncated or not complete:
        notes.append(
            "the square-minor scan is incomplete or truncated, so the audit cannot support a complete scanned-normalization certificate",
        )
    if not nonzero_coverage_complete:
        notes.append(
            "nonzero scanned minors do not cover every row and column, so complete scanned-normalization coverage is not certified",
        )
    normalization_class_rows = [
        {
            "normalized_polynomial": polynomial,
            "minor_count": count,
            "first_minor_index": int(
                normalized_class_first_records[polynomial]["minor_index"]
            ),
            "first_rows": list(normalized_class_first_records[polynomial]["rows"]),
            "first_columns": list(
                normalized_class_first_records[polynomial]["columns"]
            ),
        }
        for polynomial, count in sorted(normalized_class_counts.items())
    ]
    normalization_class_count = len(normalization_class_rows)
    largest_normalization_class_minor_count = max(
        normalized_class_counts.values(),
        default=0,
    )
    representative_normalization_class_minor_count = (
        normalized_class_counts.get(representative, 0)
        if representative is not None
        else 0
    )
    nonrepresentative_normalization_class_count = sum(
        1
        for polynomial in normalized_class_counts
        if polynomial != representative
    )
    expected_combination_count = _summary_int(
        "expected_combination_count",
        len(minors),
    )
    nonzero_minor_count = _summary_int(
        "nonzero_minor_count",
        len(nonzero_records),
    )
    zero_minor_count = _summary_int(
        "zero_minor_count",
        max(0, len(minors) - len(nonzero_records)),
    )
    unit_minor_count = _summary_int("unit_minor_count", 0)
    unique_nonzero_polynomial_count = _summary_int(
        "unique_nonzero_polynomial_count",
        len(normalized_class_counts),
    )
    all_rows_have_nonzero_minor = bool(
        effective_summary.get("all_rows_have_nonzero_minor", False)
    )
    all_columns_have_nonzero_minor = bool(
        effective_summary.get("all_columns_have_nonzero_minor", False)
    )
    normalization_context = {
        "normalization_representative_witness": representative_witness,
        "normalization_mismatch_witnesses": mismatch_witnesses,
        "normalization_records": records,
        "normalization_class_counts": normalization_class_rows,
        "failed_minor_indices": failed_indices,
    }
    normalization_blockers = _admissible_minor_normalization_blocker_summary(
        checked_nonzero_minor_count=len(nonzero_records),
        failed_minor_indices=failed_indices,
        normalization_class_count=normalization_class_count,
        largest_normalization_class_minor_count=(
            largest_normalization_class_minor_count
        ),
        representative_normalization_class_minor_count=(
            representative_normalization_class_minor_count
        ),
        nonrepresentative_normalization_class_count=(
            nonrepresentative_normalization_class_count
        ),
        normalization_class_witnesses=normalization_class_rows,
        normalization_mismatch_witness_count=len(mismatch_records),
        normalization_mismatch_witness_limit=witness_limit,
        normalization_mismatch_witness_truncated=mismatch_witness_truncated,
        complete_combination_scan=complete,
        truncated=truncated,
        nonzero_minor_coverage_complete=nonzero_coverage_complete,
        expected_combination_count=expected_combination_count,
        scanned_minor_count=len(minors),
        all_rows_have_nonzero_minor=all_rows_have_nonzero_minor,
        all_columns_have_nonzero_minor=all_columns_have_nonzero_minor,
        normalization_audit=normalization_context,
    )
    bounded_blocker_witness_summary = normalization_blockers[
        "bounded_admissible_minor_normalization_blocker_witness_summary"
    ]
    gate_summary = _bounded_admissible_minor_normalization_gate_summary(
        claim_scope=(
            "bounded_scanned_fox_admissible_minor_laurent_unit_normalization"
        ),
        blockers=normalization_blockers[
            "admissible_minor_normalization_blockers"
        ],
        blocker_witness_summary=bounded_blocker_witness_summary,
        checked_nonzero_minor_count=len(nonzero_records),
        failed_minor_indices=failed_indices,
        normalization_class_count=normalization_class_count,
        normalization_mismatch_witness_count=len(mismatch_records),
        all_nonzero_minors_laurent_unit_equivalent=all_equivalent,
        complete_combination_scan=complete,
        truncated=truncated,
        all_rows_have_nonzero_minor=all_rows_have_nonzero_minor,
        all_columns_have_nonzero_minor=all_columns_have_nonzero_minor,
        bounded_admissible_minor_normalization_certified=bounded_certified,
    )
    completion_blockers = _full_alexander_completion_blocker_summary(
        full_admissible_minor_normalization_certified=False,
        full_invariant_certified=False,
        claim_scope=(
            "bounded_scanned_fox_admissible_minor_laurent_unit_normalization"
        ),
        bounded_admissible_minor_normalization_blocker_witness_summary=(
            bounded_blocker_witness_summary
        ),
    )

    return {
        **base_payload,
        "skipped": False,
        "normalized_representative_polynomial": representative,
        "all_nonzero_minors_laurent_unit_equivalent": all_equivalent,
        "bounded_admissible_minor_normalization_certified": bounded_certified,
        "checked_nonzero_minor_count": len(nonzero_records),
        "failed_nonzero_minor_count": len(failed_indices),
        "failed_minor_indices": failed_indices,
        "normalization_records": records,
        "normalization_class_counts": normalization_class_rows,
        "normalization_class_count": normalization_class_count,
        "largest_normalization_class_minor_count": (
            largest_normalization_class_minor_count
        ),
        "representative_normalization_class_minor_count": (
            representative_normalization_class_minor_count
        ),
        "nonrepresentative_normalization_class_count": (
            nonrepresentative_normalization_class_count
        ),
        "normalization_representative_witness": representative_witness,
        "normalization_mismatch_witness_count": len(mismatch_records),
        "normalization_mismatch_witness_limit": witness_limit,
        "normalization_mismatch_witness_truncated": mismatch_witness_truncated,
        "normalization_mismatch_witnesses": mismatch_witnesses,
        "normalization_mismatch_witness_consistency": (
            mismatch_witness_consistency
        ),
        "expected_combination_count": expected_combination_count,
        "scanned_minor_count": len(minors),
        "nonzero_minor_count": nonzero_minor_count,
        "zero_minor_count": zero_minor_count,
        "unit_minor_count": unit_minor_count,
        "unique_nonzero_polynomial_count": unique_nonzero_polynomial_count,
        "all_rows_have_nonzero_minor": all_rows_have_nonzero_minor,
        "all_columns_have_nonzero_minor": all_columns_have_nonzero_minor,
        "complete_combination_scan": complete,
        "nonzero_minor_coverage_complete": nonzero_coverage_complete,
        "truncated": truncated,
        "admissible_minor_summary": effective_summary,
        "bounded_admissible_minor_normalization_gate_summary": gate_summary,
        **normalization_blockers,
        **completion_blockers,
        "notes": notes,
    }


def multivariable_alexander_minor_divisibility_audit_from_presentation(
    presentation: WirtingerPresentation,
    *,
    target_size: int | None = None,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    result = multivariable_alexander_gcd_from_presentation(
        presentation,
        target_size=target_size,
        max_matrix_size=max_matrix_size,
        max_minors=max_minors,
    )
    audit = multivariable_alexander_minor_divisibility_audit(result)
    audit["result"] = result
    return audit


def multivariable_alexander_minor_divisibility_audit_from_oriented_pd(
    diagram: PlanarDiagram,
    orientation: PDOrientation,
    *,
    variables: Iterable[str] | None = None,
    target_size: int | None = None,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    result = multivariable_alexander_from_oriented_pd(
        diagram,
        orientation,
        variables=variables,
        target_size=target_size,
        max_matrix_size=max_matrix_size,
        max_minors=max_minors,
    )
    audit = multivariable_alexander_minor_divisibility_audit(result)
    audit["diagram"] = diagram.to_dict()
    audit["result"] = result
    return audit


def multivariable_alexander_minor_divisibility_audit_from_pd(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None = None,
    variables: Iterable[str] | None = None,
    target_size: int | None = None,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    result = multivariable_alexander_from_pd(
        diagram,
        orientation=orientation,
        variables=variables,
        target_size=target_size,
        max_matrix_size=max_matrix_size,
        max_minors=max_minors,
    )
    audit = multivariable_alexander_minor_divisibility_audit(result)
    audit["diagram"] = diagram.to_dict()
    audit["result"] = result
    return audit


def multivariable_alexander_source_polynomial_divisibility_audit(
    *,
    source_polynomial: str | None,
    input_polynomials: Sequence[str],
    variables: Sequence[str],
) -> dict:
    """Check a source-table Alexander numerator against bounded scanned minors."""

    variables_tuple = tuple(variables)
    if not source_polynomial:
        return {
            "method": "multivariable_alexander_source_polynomial_divisibility_audit",
            "claim_scope": "source_polynomial_against_bounded_scanned_fox_minors",
            "skipped": True,
            "status": "skipped_no_source_polynomial",
            "source_polynomial": source_polynomial,
            "variables": list(variables_tuple),
            "input_polynomial_count": len(input_polynomials),
            "unique_input_polynomial_count": len(set(input_polynomials)),
            **_empty_failed_input_witness_fields(),
            "full_invariant_certified": False,
            "notes": ["no source-table Alexander numerator was available to audit"],
        }
    unique_inputs = sorted(set(str(value) for value in input_polynomials))
    if not unique_inputs:
        return {
            "method": "multivariable_alexander_source_polynomial_divisibility_audit",
            "claim_scope": "source_polynomial_against_bounded_scanned_fox_minors",
            "skipped": True,
            "status": "skipped_no_input_polynomials",
            "source_polynomial": source_polynomial,
            "variables": list(variables_tuple),
            "input_polynomial_count": len(input_polynomials),
            "unique_input_polynomial_count": 0,
            **_empty_failed_input_witness_fields(),
            "full_invariant_certified": False,
            "notes": ["no bounded scanned Fox-minor input polynomials were available"],
        }

    try:
        source = parse_multivariate_laurent_polynomial(
            source_polynomial,
            variables=variables_tuple,
        ).normalize_unit()
    except ValueError as error:
        return {
            "method": "multivariable_alexander_source_polynomial_divisibility_audit",
            "claim_scope": "source_polynomial_against_bounded_scanned_fox_minors",
            "skipped": True,
            "status": "invalid_source_polynomial",
            "source_polynomial": source_polynomial,
            "variables": list(variables_tuple),
            "input_polynomial_count": len(input_polynomials),
            "unique_input_polynomial_count": len(unique_inputs),
            "parse_error": str(error),
            **_empty_failed_input_witness_fields(),
            "full_invariant_certified": False,
            "notes": ["source-table Alexander numerator could not be parsed"],
        }

    division_records = []
    failed_indices = []
    invalid_indices = []
    quotient_polynomials = []
    for index, polynomial_text in enumerate(unique_inputs):
        try:
            polynomial = parse_multivariate_laurent_polynomial(
                polynomial_text,
                variables=variables_tuple,
            )
        except ValueError as error:
            invalid_indices.append(index)
            division_records.append(
                {
                    "input_index": index,
                    "input_polynomial": polynomial_text,
                    "divisible": False,
                    "invalid": True,
                    "parse_error": str(error),
                    "quotient_polynomial": None,
                }
            )
            continue
        quotient = _exact_multivariate_division(polynomial, source)
        divisible = quotient is not None
        if not divisible:
            failed_indices.append(index)
        normalized_quotient = quotient.normalize_unit() if quotient is not None else None
        if normalized_quotient is not None:
            quotient_polynomials.append(normalized_quotient.format())
        division_records.append(
            {
                "input_index": index,
                "input_polynomial": polynomial.normalize_unit().format(),
                "divisible": divisible,
                "invalid": False,
                "quotient_polynomial": (
                    normalized_quotient.format()
                    if normalized_quotient is not None
                    else None
                ),
                "quotient_terms": (
                    _serialized_terms(normalized_quotient)
                    if normalized_quotient is not None
                    else []
                ),
            }
        )

    all_divisible = not failed_indices and not invalid_indices
    status = (
        "all_inputs_divisible"
        if all_divisible
        else (
            "invalid_input_polynomial"
            if invalid_indices
            else "source_does_not_divide_all_inputs"
        )
    )
    return {
        "method": "multivariable_alexander_source_polynomial_divisibility_audit",
        "claim_scope": "source_polynomial_against_bounded_scanned_fox_minors",
        "skipped": False,
        "status": status,
        "variables": list(variables_tuple),
        "source_polynomial": source_polynomial,
        "normalized_source_polynomial": source.format(),
        "source_terms": _serialized_terms(source),
        "input_polynomial_count": len(input_polynomials),
        "unique_input_polynomial_count": len(unique_inputs),
        "checked_unique_input_polynomial_count": len(unique_inputs),
        "divisible_input_count": len(unique_inputs)
        - len(failed_indices)
        - len(invalid_indices),
        "failed_input_count": len(failed_indices),
        "invalid_input_count": len(invalid_indices),
        "failed_input_indices": failed_indices,
        "invalid_input_indices": invalid_indices,
        "divides_all_inputs": all_divisible,
        "division_records": division_records,
        **_failed_input_witness_fields_from_division_records(division_records),
        "quotient_polynomial_count": len(quotient_polynomials),
        "unique_quotient_polynomial_count": len(set(quotient_polynomials)),
        "unique_quotient_polynomials": sorted(set(quotient_polynomials)),
        "full_invariant_certified": False,
        "notes": [
            "source-table numerator is checked only against the bounded scanned Fox-minor input set",
            "a failed divisibility audit is negative evidence for promoting the source numerator under the current scanned-minor convention",
            "full admissible-minor normalization and external table normalization remain separate claims",
        ],
    }


def multivariable_alexander_admissible_minor_normalization_audit_from_presentation(
    presentation: WirtingerPresentation,
    *,
    target_size: int | None = None,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    result = multivariable_alexander_gcd_from_presentation(
        presentation,
        target_size=target_size,
        max_matrix_size=max_matrix_size,
        max_minors=max_minors,
    )
    audit = multivariable_alexander_admissible_minor_normalization_audit(result)
    audit["result"] = result
    return audit


def multivariable_alexander_admissible_minor_normalization_audit_from_oriented_pd(
    diagram: PlanarDiagram,
    orientation: PDOrientation,
    *,
    variables: Iterable[str] | None = None,
    target_size: int | None = None,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    result = multivariable_alexander_from_oriented_pd(
        diagram,
        orientation,
        variables=variables,
        target_size=target_size,
        max_matrix_size=max_matrix_size,
        max_minors=max_minors,
    )
    audit = multivariable_alexander_admissible_minor_normalization_audit(result)
    audit["diagram"] = diagram.to_dict()
    audit["result"] = result
    return audit


def multivariable_alexander_admissible_minor_normalization_audit_from_pd(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None = None,
    variables: Iterable[str] | None = None,
    target_size: int | None = None,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    result = multivariable_alexander_from_pd(
        diagram,
        orientation=orientation,
        variables=variables,
        target_size=target_size,
        max_matrix_size=max_matrix_size,
        max_minors=max_minors,
    )
    audit = multivariable_alexander_admissible_minor_normalization_audit(result)
    audit["diagram"] = diagram.to_dict()
    audit["result"] = result
    return audit


def _complete_scanned_gcd_certified(
    *,
    candidate_is_exact_scanned_gcd: bool,
    summary: dict,
    truncated: bool,
) -> bool:
    return bool(
        candidate_is_exact_scanned_gcd
        and not truncated
        and summary.get("complete_combination_scan", False)
        and summary.get("nonzero_minor_coverage_complete", False)
    )


def multivariable_alexander_scanned_gcd_audit(result: dict) -> dict:
    """Audit whether the returned candidate is an exact gcd of scanned minors.

    This is stronger than the divisibility audit but still deliberately scoped:
    it certifies only the scanned Fox-minor set. It does not claim a full
    admissible-minor convention or external table-normalized invariant.
    """

    scan = result.get("square_minors")
    summary = result.get("admissible_minor_summary")
    polynomial_text = result.get("multivariable_alexander_polynomial")
    variables = _audit_variables(result)
    scanned_gcd_improvement_evidence = (
        result.get("scanned_gcd_improvement_evidence")
        if isinstance(result.get("scanned_gcd_improvement_evidence"), dict)
        else None
    )
    source_common_gcd_evidence = (
        result.get("source_common_gcd_evidence")
        if isinstance(result.get("source_common_gcd_evidence"), dict)
        else None
    )
    base_payload = {
        "method": "multivariable_alexander_scanned_gcd_audit",
        "source_method": result.get("method"),
        "multivariable_alexander_polynomial": polynomial_text,
        "variables": list(variables),
        "candidate_polynomials": list(result.get("candidate_polynomials", [])),
        "claim_scope": "bounded_scanned_fox_minor_exact_gcd",
        "quotient_gcd_evidence": None,
        **_empty_quotient_gcd_uncertainty_fields(),
        "common_gcd_attempt_evidence": (
            result.get("common_gcd_attempt_evidence")
            if isinstance(result.get("common_gcd_attempt_evidence"), dict)
            else None
        ),
        "source_common_gcd_evidence": source_common_gcd_evidence,
        "scanned_gcd_improvement_evidence": scanned_gcd_improvement_evidence,
        "scanned_gcd_promoted_candidate": (
            scanned_gcd_improvement_evidence is not None
        ),
        "scanned_gcd_promoted_candidate_count": (
            1 if scanned_gcd_improvement_evidence is not None else 0
        ),
        "full_invariant_certified": False,
        **_empty_division_failure_witness_fields(),
    }
    if result.get("skipped", False) or polynomial_text is None:
        return _scanned_gcd_audit_skipped(
            base_payload,
            scan=scan,
            summary=summary,
            notes=[
                "source Alexander result did not return a polynomial",
                *list(result.get("notes", [])),
            ],
        )
    if not isinstance(scan, dict):
        return _scanned_gcd_audit_skipped(
            base_payload,
            scan=scan,
            summary=summary,
            notes=["source Alexander result does not include square-minor scan data"],
        )
    if scan.get("skipped", False):
        return _scanned_gcd_audit_skipped(
            base_payload,
            scan=scan,
            summary=summary,
            notes=[
                "source square-minor scan was skipped",
                *list(scan.get("notes", [])),
            ],
        )
    if not variables:
        return _scanned_gcd_audit_skipped(
            base_payload,
            scan=scan,
            summary=summary,
            notes=["source square-minor scan does not expose variable names"],
        )

    effective_summary = summary or scan.get("admissible_minor_summary") or {}
    divisor = parse_multivariate_laurent_polynomial(
        str(polynomial_text),
        variables=variables,
    ).normalize_unit()
    minors = list(scan.get("minors", []))
    nonzero_minors = [
        (index, minor)
        for index, minor in enumerate(minors)
        if not minor.get("is_zero", False)
    ]
    if divisor.is_zero:
        exact_zero = len(nonzero_minors) == 0
        complete_scanned_gcd_certified = _complete_scanned_gcd_certified(
            candidate_is_exact_scanned_gcd=exact_zero,
            summary=effective_summary,
            truncated=bool(scan.get("truncated", False)),
        )
        return {
            **base_payload,
            "divisor_terms": _serialized_terms(divisor),
            "skipped": False,
            "candidate_is_exact_scanned_gcd": exact_zero,
            "complete_scanned_gcd_certified": complete_scanned_gcd_certified,
            "quotient_gcd_certified": exact_zero,
            "quotient_gcd_polynomial": "1" if exact_zero else None,
            "quotient_gcd_method": "all_scanned_minors_zero" if exact_zero else None,
            "improved_candidate_polynomial": None,
            "checked_nonzero_minor_count": len(nonzero_minors),
            "failed_nonzero_minor_count": len(nonzero_minors),
            "division_records": [],
            "failed_minor_indices": [index for index, _ in nonzero_minors],
            **_division_failure_witness_fields_from_minors(
                nonzero_minors,
                reason="zero_divisor_nonzero_minor",
            ),
            "complete_combination_scan": bool(
                effective_summary.get("complete_combination_scan", False)
            ),
            "truncated": bool(scan.get("truncated", False)),
            "admissible_minor_summary": effective_summary,
            "notes": [
                "reported zero polynomial is an exact scanned gcd only when every scanned Fox minor is zero",
                "this audit certifies only the bounded scanned-minor set; full admissible-minor normalization remains separate",
            ],
        }

    division_records = []
    failed_indices = []
    quotient_polynomials: list[MultivariateLaurentPolynomial] = []
    for index, minor in nonzero_minors:
        minor_polynomial = _polynomial_from_serialized_terms(
            minor.get("terms", []),
            variables=variables,
        )
        quotient = _exact_multivariate_division(minor_polynomial, divisor)
        divisible = quotient is not None
        if not divisible:
            failed_indices.append(index)
        normalized_quotient = quotient.normalize_unit() if quotient is not None else None
        if normalized_quotient is not None:
            quotient_polynomials.append(normalized_quotient)
        division_records.append(
            {
                "minor_index": index,
                "rows": list(minor.get("rows", [])),
                "columns": list(minor.get("columns", [])),
                "minor_polynomial": minor.get("polynomial"),
                "divisible": divisible,
                "quotient_polynomial": (
                    normalized_quotient.format()
                    if normalized_quotient is not None
                    else None
                ),
                "quotient_terms": (
                    _serialized_terms(normalized_quotient)
                    if normalized_quotient is not None
                    else []
                ),
                "quotient_is_unit": (
                    _is_unit_polynomial(normalized_quotient)
                    if normalized_quotient is not None
                    else False
                ),
            }
        )

    if failed_indices:
        return {
            **base_payload,
            "divisor_terms": _serialized_terms(divisor),
            "skipped": False,
            "candidate_is_exact_scanned_gcd": False,
            "complete_scanned_gcd_certified": False,
            "quotient_gcd_certified": False,
            "quotient_gcd_polynomial": None,
            "quotient_gcd_method": None,
            "improved_candidate_polynomial": None,
            "checked_nonzero_minor_count": len(nonzero_minors),
            "failed_nonzero_minor_count": len(failed_indices),
            "division_records": division_records,
            "failed_minor_indices": failed_indices,
            **_division_failure_witness_fields(division_records),
            "complete_combination_scan": bool(
                effective_summary.get("complete_combination_scan", False)
            ),
            "truncated": bool(scan.get("truncated", False)),
            "admissible_minor_summary": effective_summary,
            "notes": [
                "reported polynomial failed exact division against at least one scanned Fox minor",
                "therefore it cannot be the exact gcd of the scanned Fox-minor set",
            ],
        }

    if not quotient_polynomials:
        return {
            **base_payload,
            "divisor_terms": _serialized_terms(divisor),
            "skipped": False,
            "candidate_is_exact_scanned_gcd": False,
            "complete_scanned_gcd_certified": False,
            "quotient_gcd_certified": False,
            "quotient_gcd_polynomial": None,
            "quotient_gcd_method": None,
            "improved_candidate_polynomial": None,
            "checked_nonzero_minor_count": 0,
            "failed_nonzero_minor_count": 0,
            "division_records": [],
            "failed_minor_indices": [],
            "complete_combination_scan": bool(
                effective_summary.get("complete_combination_scan", False)
            ),
            "truncated": bool(scan.get("truncated", False)),
            "admissible_minor_summary": effective_summary,
            "notes": [
                "all scanned minors are zero but the reported polynomial is nonzero",
                "a nonzero candidate is not an exact gcd of the scanned zero ideal",
            ],
        }

    quotient_gcd_polynomial = None
    quotient_gcd_method = None
    quotient_gcd_evidence = None
    quotient_gcd_uncertainty = None
    improved_candidate = None
    exact_scanned_gcd = False
    quotient_gcd_certified = False
    if any(_is_unit_polynomial(quotient) for quotient in quotient_polynomials):
        quotient_gcd_polynomial = "1"
        quotient_gcd_method = "fox_square_minor_quotient_unit_gcd"
        quotient_gcd_evidence = _common_gcd_evidence(
            quotient_polynomials,
            MultivariateLaurentPolynomial.constant(1, variables=variables),
            variables=variables,
            common_integer_content=1,
            method=quotient_gcd_method,
            note=(
                "at least one quotient polynomial is a unit, so the quotient "
                "common factor is certified as 1"
            ),
        )
        exact_scanned_gcd = True
        quotient_gcd_certified = True
    else:
        quotient_gcd = _conservative_common_gcd_with_evidence_from_minors(
            [
                {
                    "is_zero": quotient.is_zero,
                    "terms": _serialized_terms(quotient),
                }
                for quotient in quotient_polynomials
            ],
            variables=variables,
        )
        if quotient_gcd is None:
            common_quotient = None
            quotient_gcd_evidence = None
            quotient_gcd_uncertainty = _quotient_gcd_uncertainty_evidence(
                quotient_polynomials,
                variables=variables,
                complete_combination_scan=bool(
                    effective_summary.get("complete_combination_scan", False)
                ),
                truncated=bool(scan.get("truncated", False)),
            )
        else:
            common_quotient, quotient_gcd_method, _, quotient_gcd_evidence = quotient_gcd
    if quotient_gcd_method is not None and quotient_gcd_polynomial is None:
        assert common_quotient is not None
        quotient_gcd_polynomial = common_quotient.normalize_unit().format()
        quotient_gcd_certified = True
        if _is_unit_polynomial(common_quotient):
            exact_scanned_gcd = True
        else:
            improved_candidate = (divisor * common_quotient).normalize_unit().format()

    notes = [
        "reported polynomial divides every nonzero scanned Fox minor by exact multivariate division",
    ]
    if exact_scanned_gcd:
        notes.append(
            "the quotient polynomials have certified unit common factor, so the reported polynomial is an exact gcd of the scanned set",
        )
    elif quotient_gcd_certified:
        notes.append(
            "the quotient polynomials still have a certified non-unit common factor, so the reported polynomial is not maximal for the scanned set",
        )
    else:
        notes.append(
            "the quotient common factor was not certified by the conservative gcd layer, so exact scanned-gcd status remains unknown",
        )
    notes.append(
        "this audit certifies only the bounded scanned-minor set; full admissible-minor normalization remains separate",
    )
    if scan.get("truncated", False) or not effective_summary.get(
        "complete_combination_scan",
        False,
    ):
        notes.append(
            "the square-minor scan is incomplete or truncated, so even a scanned-gcd certificate is not a complete admissible-minor claim",
        )

    complete_scanned_gcd_certified = _complete_scanned_gcd_certified(
        candidate_is_exact_scanned_gcd=exact_scanned_gcd,
        summary=effective_summary,
        truncated=bool(scan.get("truncated", False)),
    )

    return {
        **base_payload,
        "divisor_terms": _serialized_terms(divisor),
        "skipped": False,
        "candidate_is_exact_scanned_gcd": exact_scanned_gcd,
        "complete_scanned_gcd_certified": complete_scanned_gcd_certified,
        "quotient_gcd_certified": quotient_gcd_certified,
        "quotient_gcd_polynomial": quotient_gcd_polynomial,
        "quotient_gcd_method": quotient_gcd_method,
        "quotient_gcd_evidence": quotient_gcd_evidence
        if quotient_gcd_certified
        else None,
        "quotient_gcd_uncertainty_evidence": (
            quotient_gcd_uncertainty
            if not quotient_gcd_certified
            else None
        ),
        "improved_candidate_polynomial": improved_candidate,
        "checked_nonzero_minor_count": len(nonzero_minors),
        "failed_nonzero_minor_count": 0,
        "division_records": division_records,
        "failed_minor_indices": [],
        **_division_failure_witness_fields(division_records),
        "complete_combination_scan": bool(
            effective_summary.get("complete_combination_scan", False)
        ),
        "truncated": bool(scan.get("truncated", False)),
        "admissible_minor_summary": effective_summary,
        "notes": notes,
    }


def multivariable_alexander_improve_scanned_gcd_result(result: dict) -> dict:
    """Return an improved bounded scanned-gcd result when the audit proves one.

    This is intentionally an explicit post-processing step. It does not make a
    full admissible-minor claim; it only promotes an existing candidate when the
    scanned-gcd audit has already certified a non-unit common quotient factor.
    """

    source_audit = multivariable_alexander_scanned_gcd_audit(result)
    improved_polynomial = source_audit.get("improved_candidate_polynomial")
    base_payload = {
        "method": "multivariable_alexander_improve_scanned_gcd_result",
        "source_method": result.get("method"),
        "source_polynomial": result.get("multivariable_alexander_polynomial"),
        "source_audit": source_audit,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
    }
    if not improved_polynomial:
        return {
            **base_payload,
            "skipped": True,
            "improved": False,
            "improved_candidate_polynomial": None,
            "result": None,
            "improved_audit": None,
            "notes": [
                "source scanned-gcd audit did not expose a certified improved candidate",
            ],
        }

    improved_result = deepcopy(result)
    source_method = str(result.get("method", "unknown"))
    improved_result["source_method"] = result.get("method")
    improved_result["source_multivariable_alexander_polynomial"] = result.get(
        "multivariable_alexander_polynomial"
    )
    improved_result["multivariable_alexander_polynomial"] = improved_polynomial
    improved_result["method"] = (
        f"{source_method}_improved_by_scanned_quotient_gcd"
    )
    if "common_gcd_evidence" in improved_result:
        improved_result["source_common_gcd_evidence"] = improved_result.pop(
            "common_gcd_evidence"
        )
    improved_result["scanned_gcd_improvement_evidence"] = {
        "method": "bounded_scanned_gcd_candidate_promotion",
        "source_method": result.get("method"),
        "source_polynomial": result.get("multivariable_alexander_polynomial"),
        "improved_candidate_polynomial": improved_polynomial,
        "quotient_gcd_certified": bool(
            source_audit.get("quotient_gcd_certified", False)
        ),
        "quotient_gcd_polynomial": source_audit.get("quotient_gcd_polynomial"),
        "quotient_gcd_method": source_audit.get("quotient_gcd_method"),
        "candidate_is_exact_scanned_gcd_before_promotion": bool(
            source_audit.get("candidate_is_exact_scanned_gcd", False)
        ),
        "claim_scope": "bounded_scanned_fox_minor_exact_gcd_promotion",
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
    }
    improved_result["requires_normalization"] = False
    improved_result["skipped"] = False
    improved_result["notes"] = [
        *list(result.get("notes", [])),
        (
            "scanned-gcd audit found a certified non-unit common quotient "
            "factor and promoted the bounded candidate"
        ),
        "full admissible-minor normalization remains separate",
    ]

    improved_audit = multivariable_alexander_scanned_gcd_audit(improved_result)
    accepted = (
        not improved_audit.get("skipped", False)
        and improved_audit.get("candidate_is_exact_scanned_gcd") is True
    )
    return {
        **base_payload,
        "skipped": False,
        "improved": True,
        "accepted": accepted,
        "improved_candidate_polynomial": improved_polynomial,
        "result": improved_result,
        "improved_audit": improved_audit,
        "notes": [
            "improved result is certified only against the bounded scanned Fox-minor set",
            "full admissible-minor normalization remains separate",
        ],
    }


def _promote_scanned_gcd_result_if_certified(result: dict) -> dict:
    improvement = multivariable_alexander_improve_scanned_gcd_result(result)
    if not improvement.get("improved") or not improvement.get("accepted"):
        return result
    improved_result = improvement.get("result")
    if not isinstance(improved_result, dict):
        return result
    evidence = improved_result.get("scanned_gcd_improvement_evidence")
    if isinstance(evidence, dict):
        evidence["accepted"] = True
        evidence["candidate_is_exact_scanned_gcd_after_promotion"] = True
    return improved_result


def multivariable_alexander_scanned_gcd_audit_from_presentation(
    presentation: WirtingerPresentation,
    *,
    target_size: int | None = None,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    result = multivariable_alexander_gcd_from_presentation(
        presentation,
        target_size=target_size,
        max_matrix_size=max_matrix_size,
        max_minors=max_minors,
    )
    audit = multivariable_alexander_scanned_gcd_audit(result)
    audit["result"] = result
    return audit


def multivariable_alexander_scanned_gcd_audit_from_oriented_pd(
    diagram: PlanarDiagram,
    orientation: PDOrientation,
    *,
    variables: Iterable[str] | None = None,
    target_size: int | None = None,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    result = multivariable_alexander_from_oriented_pd(
        diagram,
        orientation,
        variables=variables,
        target_size=target_size,
        max_matrix_size=max_matrix_size,
        max_minors=max_minors,
    )
    audit = multivariable_alexander_scanned_gcd_audit(result)
    audit["diagram"] = diagram.to_dict()
    audit["result"] = result
    return audit


def multivariable_alexander_scanned_gcd_audit_from_pd(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None = None,
    variables: Iterable[str] | None = None,
    target_size: int | None = None,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    result = multivariable_alexander_from_pd(
        diagram,
        orientation=orientation,
        variables=variables,
        target_size=target_size,
        max_matrix_size=max_matrix_size,
        max_minors=max_minors,
    )
    audit = multivariable_alexander_scanned_gcd_audit(result)
    audit["diagram"] = diagram.to_dict()
    audit["result"] = result
    return audit


def multivariable_alexander_from_oriented_pd(
    diagram: PlanarDiagram,
    orientation: PDOrientation,
    *,
    variables: Iterable[str] | None = None,
    target_size: int | None = None,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    presentation = wirtinger_presentation_from_oriented_pd(
        diagram,
        orientation,
        variables=variables,
    )
    result = multivariable_alexander_gcd_from_presentation(
        presentation,
        target_size=target_size,
        max_matrix_size=max_matrix_size,
        max_minors=max_minors,
    )
    result["diagram"] = diagram.to_dict()
    return result


def multivariable_alexander_from_pd(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None = None,
    role_order: Iterable[int] | None = None,
    variables: Iterable[str] | None = None,
    target_size: int | None = None,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    if not diagram.edge_labels:
        try:
            return _multivariable_alexander_zero_crossing_unlink_result(
                diagram,
                variables=variables,
            )
        except ValueError as exc:
            return {
                "multivariable_alexander_polynomial": None,
                "candidate_polynomials": [],
                "method": "skipped",
                "diagram": diagram.to_dict(),
                "requires_normalization": True,
                "skipped": True,
                "notes": [
                    "zero-crossing unlink normalization failed",
                    str(exc),
                ],
            }
    try:
        effective_orientation = _effective_pd_orientation(
            diagram,
            orientation=orientation,
            role_order=role_order,
        )
    except ValueError as exc:
        return {
            "multivariable_alexander_polynomial": None,
            "candidate_polynomials": [],
            "method": "skipped",
            "diagram": diagram.to_dict(),
            "requires_normalization": True,
            "skipped": True,
            "notes": [
                "signed-PD to Wirtinger orientation inference failed",
                str(exc),
            ],
        }
    try:
        result = multivariable_alexander_from_oriented_pd(
            diagram,
            effective_orientation,
            variables=variables,
            target_size=target_size,
            max_matrix_size=max_matrix_size,
            max_minors=max_minors,
        )
        result["orientation_inference"] = _pd_orientation_inference_payload(
            effective_orientation,
            explicit=orientation is not None,
            role_order=role_order,
        )
        return result
    except ValueError as exc:
        return {
            "multivariable_alexander_polynomial": None,
            "candidate_polynomials": [],
            "method": "skipped",
            "diagram": diagram.to_dict(),
            "requires_normalization": True,
            "skipped": True,
            "notes": [
                "signed-PD to Wirtinger orientation validation failed",
                str(exc),
            ],
        }


def _effective_pd_orientation(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None,
    role_order: Iterable[int] | None,
) -> PDOrientation:
    if orientation is not None:
        if role_order is not None:
            raise ValueError("role_order cannot be supplied with explicit PDOrientation metadata")
        return orientation
    normalized_role_order = _normalized_pd_role_order(role_order)
    if normalized_role_order is None:
        return PDOrientation.from_signed_pd_roles(diagram)
    return PDOrientation.from_signed_pd_roles(
        diagram,
        role_order=normalized_role_order,
    )


def _normalized_pd_role_order(
    role_order: Iterable[int] | None,
) -> tuple[int, int, int, int] | None:
    if role_order is None:
        return None
    order = tuple(int(position) for position in role_order)
    if len(order) != 4 or set(order) != {0, 1, 2, 3}:
        raise ValueError("signed-PD role_order must be a permutation of (0, 1, 2, 3)")
    return order  # type: ignore[return-value]


def _pd_orientation_inference_method(
    orientation: PDOrientation,
    *,
    explicit: bool,
    role_order: Iterable[int] | None,
) -> str:
    if explicit:
        return "explicit_oriented_signed_pd"
    normalized_role_order = _normalized_pd_role_order(role_order)
    if normalized_role_order is None or normalized_role_order == (0, 1, 2, 3):
        return "inferred_signed_pd_position_roles"
    return "inferred_signed_pd_global_role_order"


def _pd_orientation_inference_payload(
    orientation: PDOrientation,
    *,
    explicit: bool,
    role_order: Iterable[int] | None,
) -> dict:
    normalized_role_order = _normalized_pd_role_order(role_order)
    return {
        "method": _pd_orientation_inference_method(
            orientation,
            explicit=explicit,
            role_order=normalized_role_order,
        ),
        "explicit_orientation": explicit,
        "role_order": (
            list(normalized_role_order)
            if normalized_role_order is not None
            else ([0, 1, 2, 3] if not explicit else None)
        ),
        "orientation_convention": orientation.convention,
        "crossing_count": len(orientation.crossings),
        "edge_component_count": len(orientation.edge_components),
    }


def _pd_orientation_inference_notes(
    orientation: PDOrientation,
    *,
    explicit: bool,
    role_order: Iterable[int] | None,
) -> list[str]:
    normalized_role_order = _normalized_pd_role_order(role_order)
    if explicit:
        return ["presentation built from explicit PDOrientation metadata"]
    if normalized_role_order is None or normalized_role_order == (0, 1, 2, 3):
        return ["presentation inferred from signed-PD position roles"]
    return [
        "presentation inferred from caller-supplied signed-PD global role_order",
        "role_order maps canonical roles (under_in, over_in, under_out, over_out) to crossing-code positions",
    ]


def multivariable_alexander_candidates_from_oriented_pd(
    diagram: PlanarDiagram,
    orientation: PDOrientation,
    *,
    variables: Iterable[str] | None = None,
    target_size: int | None = None,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    presentation = wirtinger_presentation_from_oriented_pd(
        diagram,
        orientation,
        variables=variables,
    )
    result = multivariable_alexander_candidates_from_presentation(
        presentation,
        target_size=target_size,
        max_matrix_size=max_matrix_size,
        max_minors=max_minors,
    )
    result["diagram"] = diagram.to_dict()
    return result


def wirtinger_presentation_from_oriented_crossings(
    *,
    generator_components: Sequence[int],
    crossings: Sequence[dict],
    variables: Iterable[str] | None = None,
) -> WirtingerPresentation:
    """Build a presentation from explicit oriented crossing records.

    Each crossing record must contain zero-based `under_in`, `under_out`,
    `over`, and `sign` fields. This is the safe intermediate contract before
    full signed-PD traversal is available.
    """

    variables_tuple = _variables_for_components(generator_components, variables)
    relations = []
    for index, crossing in enumerate(crossings):
        try:
            under_in = int(crossing["under_in"])
            under_out = int(crossing["under_out"])
            over = int(crossing["over"])
            sign = int(crossing["sign"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"invalid oriented crossing record at index {index}") from exc
        if sign not in {-1, 1}:
            raise ValueError("oriented crossing sign must be +1 or -1")
        for generator in [under_in, under_out, over]:
            if generator < 0 or generator >= len(generator_components):
                raise ValueError("crossing generator index out of range")
        relations.append(
            (
                (over, sign),
                (under_in, 1),
                (over, -sign),
                (under_out, -1),
            )
        )
    return WirtingerPresentation(
        relations=tuple(relations),
        generator_components=tuple(generator_components),
        variables=variables_tuple,
    )


def wirtinger_presentation_from_oriented_pd(
    diagram: PlanarDiagram,
    orientation: PDOrientation,
    *,
    variables: Iterable[str] | None = None,
) -> WirtingerPresentation:
    """Build a Wirtinger presentation from signed PD plus explicit orientation.

    The orientation object binds `under_in`, `under_out`, `over_in`, and
    `over_out` roles to each PD crossing's edge labels. This is the
    diagram-level bridge before fully automatic orientation traversal exists.
    """

    issues = orientation.validation_issues(diagram)
    if issues:
        raise ValueError("; ".join(issues))

    edge_to_generator, generator_components = _wirtinger_generators_from_orientation(
        diagram,
        orientation,
    )
    crossings = [
        {
            "under_in": edge_to_generator[crossing_orientation.under_in],
            "under_out": edge_to_generator[crossing_orientation.under_out],
            "over": edge_to_generator[crossing_orientation.over_in],
            "sign": crossing.sign,
        }
        for crossing, crossing_orientation in zip(diagram.crossings, orientation.crossings)
    ]
    presentation = wirtinger_presentation_from_oriented_crossings(
        generator_components=generator_components,
        crossings=crossings,
        variables=variables,
    )
    return WirtingerPresentation(
        relations=presentation.relations,
        generator_components=presentation.generator_components,
        variables=presentation.variables,
        source="explicit_oriented_signed_pd",
        convention=(
            "PDOrientation over_in/over_out pairs are collapsed into Wirtinger generators; "
            "relation over^sign under_in over^-sign under_out^-1 = 1"
        ),
    )


def wirtinger_presentation_from_pd(
    diagram: PlanarDiagram,
    *,
    orientation: PDOrientation | None = None,
    role_order: Iterable[int] | None = None,
    variables: Iterable[str] | None = None,
) -> dict:
    if not diagram.edge_labels:
        return {
            "presentation": None,
            "method": "skipped",
            "skipped": True,
            "diagram": diagram.to_dict(),
            "notes": [
                "zero-crossing signed-PD diagrams do not contain Wirtinger arc generators",
                "use table or unlink normalization paths for zero-crossing unlink cases",
            ],
        }
    try:
        effective_orientation = _effective_pd_orientation(
            diagram,
            orientation=orientation,
            role_order=role_order,
        )
    except ValueError as exc:
        return {
            "presentation": None,
            "method": "skipped",
            "skipped": True,
            "diagram": diagram.to_dict(),
            "notes": [
                "signed-PD to Wirtinger orientation inference failed",
                str(exc),
            ],
        }
    if effective_orientation is not None:
        try:
            presentation = wirtinger_presentation_from_oriented_pd(
                diagram,
                effective_orientation,
                variables=variables,
            )
        except ValueError as exc:
            return {
                "presentation": None,
                "method": "skipped",
                "skipped": True,
                "diagram": diagram.to_dict(),
                "notes": [
                    "signed-PD to Wirtinger orientation validation failed",
                    str(exc),
                ],
            }
        return {
            "presentation": presentation.to_dict(),
            "method": _pd_orientation_inference_method(
                effective_orientation,
                explicit=orientation is not None,
                role_order=role_order,
            ),
            "orientation_inference": _pd_orientation_inference_payload(
                effective_orientation,
                explicit=orientation is not None,
                role_order=role_order,
            ),
            "skipped": False,
            "diagram": diagram.to_dict(),
            "notes": _pd_orientation_inference_notes(
                effective_orientation,
                explicit=orientation is not None,
                role_order=role_order,
            ),
        }
    raise AssertionError("effective_orientation is unexpectedly None")


def fox_derivative_word(
    word: FoxWord,
    *,
    target_generator: int,
    generator_components: Sequence[int],
    variables: Iterable[str] | None = None,
) -> MultivariateLaurentPolynomial:
    """Return the abelianized Fox derivative of a word.

    Generators are zero-based. Word terms are `(generator, exponent)` pairs
    with exponent `+1` or `-1`. `generator_components` maps each generator to
    the component variable used after abelianization.
    """

    variables_tuple = _variables_for_components(generator_components, variables)
    prefix = MultivariateLaurentPolynomial.constant(1, variables=variables_tuple)
    total = MultivariateLaurentPolynomial.constant(0, variables=variables_tuple)

    for generator, exponent in word:
        _validate_word_term(generator, exponent, generator_components)
        if generator == target_generator:
            if exponent == 1:
                local = MultivariateLaurentPolynomial.constant(1, variables=variables_tuple)
            else:
                local = _generator_monomial(
                    generator,
                    -1,
                    generator_components=generator_components,
                    variables=variables_tuple,
                ).scale(-1)
            total = total + (prefix * local)
        prefix = prefix * _generator_monomial(
            generator,
            exponent,
            generator_components=generator_components,
            variables=variables_tuple,
        )
    return total


def fox_jacobian(
    relations: Sequence[FoxWord],
    *,
    generator_components: Sequence[int],
    variables: Iterable[str] | None = None,
) -> list[list[MultivariateLaurentPolynomial]]:
    variables_tuple = _variables_for_components(generator_components, variables)
    return [
        [
            fox_derivative_word(
                relation,
                target_generator=generator,
                generator_components=generator_components,
                variables=variables_tuple,
            )
            for generator in range(len(generator_components))
        ]
        for relation in relations
    ]


def fox_minor_from_presentation(
    relations: Sequence[FoxWord],
    *,
    generator_components: Sequence[int],
    variables: Iterable[str] | None = None,
    remove_row: int | None = None,
    remove_column: int = 0,
    normalize: bool = True,
    max_matrix_size: int = 6,
) -> dict:
    """Compute one Fox minor from a deficiency-one style presentation.

    This is the executable algebraic core needed by a future full
    multi-variable Alexander implementation. It does not yet build the
    Wirtinger presentation from signed PD diagrams or compute a gcd over all
    admissible minors.
    """

    variables_tuple = _variables_for_components(generator_components, variables)
    matrix = fox_jacobian(
        relations,
        generator_components=generator_components,
        variables=variables_tuple,
    )
    minor = _remove_row_column(matrix, remove_row=remove_row, remove_column=remove_column)
    if any(len(row) != len(minor) for row in minor):
        return {
            "polynomial": None,
            "method": "skipped",
            "variables": list(variables_tuple),
            "removed_row": remove_row,
            "removed_column": remove_column,
            "matrix_size": [len(minor), len(minor[0]) if minor else 0],
            "skipped": True,
            "notes": [
                "Fox minor determinant skipped because the selected minor is not square",
                "full link Alexander normalization may require admissible minor selection or gcd over minors",
            ],
        }
    if len(minor) > max_matrix_size:
        return {
            "polynomial": None,
            "method": "skipped",
            "variables": list(variables_tuple),
            "removed_row": remove_row,
            "removed_column": remove_column,
            "skipped": True,
            "notes": ["Fox minor determinant skipped for matrix larger than max_matrix_size"],
        }
    determinant = multivariate_laurent_determinant(minor, variables=variables_tuple)
    normalized, normalization = _normalize_alexander_polynomial(
        determinant,
        normalize=normalize,
    )
    return {
        "polynomial": normalized.format(),
        "raw_polynomial": determinant.format(),
        "normalization": normalization,
        "method": "fox_calculus_presentation_minor",
        "variables": list(variables_tuple),
        "removed_row": remove_row,
        "removed_column": remove_column,
        "matrix_size": len(minor),
        "skipped": False,
        "notes": [
            "presentation-level Fox minor; signed-PD to Wirtinger conversion is a separate step",
            "full link Alexander normalization may require gcd over admissible minors",
        ],
    }


def fox_square_minors_from_presentation(
    relations: Sequence[FoxWord],
    *,
    generator_components: Sequence[int],
    variables: Iterable[str] | None = None,
    target_size: int | None = None,
    normalize: bool = True,
    max_matrix_size: int = 4,
    max_minors: int = 64,
) -> dict:
    """Enumerate bounded square Fox minors for later Alexander normalization."""

    variables_tuple = _variables_for_components(generator_components, variables)
    matrix = fox_jacobian(
        relations,
        generator_components=generator_components,
        variables=variables_tuple,
    )
    row_count = len(matrix)
    # An empty relation family still has a known Fox-matrix column count.  It
    # matters at the exact boundary: a one-generator presentation has the
    # unique 0x0 minor 1, while n > 1 has no (n-1)x(n-1) row subsets.
    column_count = len(matrix[0]) if matrix else len(generator_components)
    size = target_size if target_size is not None else min(row_count, column_count)
    if size < 0:
        raise ValueError("target_size must be non-negative")
    if size > max_matrix_size:
        result = {
            "method": "skipped",
            "variables": list(variables_tuple),
            "matrix_size": [row_count, column_count],
            "target_size": size,
            "minors": [],
            "truncated": False,
            "skipped": True,
            "notes": ["Fox square minor scan skipped because target_size exceeds max_matrix_size"],
        }
        result["admissible_minor_summary"] = fox_admissible_minor_summary(result)
        return result

    minors = []
    truncated = False
    for row_indices in combinations(range(row_count), size):
        for column_indices in combinations(range(column_count), size):
            if len(minors) >= max_minors:
                truncated = True
                break
            submatrix = [
                [matrix[row][column] for column in column_indices]
                for row in row_indices
            ]
            determinant = multivariate_laurent_determinant(
                submatrix,
                variables=variables_tuple,
            )
            normalized, normalization = _normalize_alexander_polynomial(
                determinant,
                normalize=normalize,
            )
            minors.append(
                {
                    "rows": list(row_indices),
                    "columns": list(column_indices),
                    "polynomial": normalized.format(),
                    "raw_polynomial": determinant.format(),
                    "normalization": normalization,
                    "terms": _serialized_terms(normalized),
                    "raw_terms": _serialized_terms(determinant),
                    "is_zero": determinant.is_zero,
                    "is_unit": _is_unit_polynomial(normalized),
                    "term_count": len(normalized.terms),
                }
            )
        if truncated:
            break

    result = {
        "method": "fox_square_minor_scan",
        "variables": list(variables_tuple),
        "matrix_size": [row_count, column_count],
        "target_size": size,
        "minors": minors,
        "truncated": truncated,
        "skipped": False,
        "notes": [
            "square minor scan is an input to future admissible-minor/gcd normalization",
        ],
    }
    result["admissible_minor_summary"] = fox_admissible_minor_summary(result)
    return result


def fox_admissible_minor_summary(square_minor_scan: dict) -> dict:
    """Summarize bounded Fox square minors for later admissible-minor selection."""

    matrix_size = square_minor_scan.get("matrix_size", [0, 0])
    row_count = int(matrix_size[0]) if len(matrix_size) >= 1 else 0
    column_count = int(matrix_size[1]) if len(matrix_size) >= 2 else 0
    target_size = int(square_minor_scan.get("target_size", 0))
    minors = list(square_minor_scan.get("minors", []))
    expected_combination_count = (
        comb(row_count, target_size) * comb(column_count, target_size)
        if 0 <= target_size <= row_count and 0 <= target_size <= column_count
        else 0
    )
    row_subsets = sorted({tuple(minor["rows"]) for minor in minors})
    column_subsets = sorted({tuple(minor["columns"]) for minor in minors})
    covered_rows = sorted({row for subset in row_subsets for row in subset})
    covered_columns = sorted({column for subset in column_subsets for column in subset})
    nonzero_indices = [
        index
        for index, minor in enumerate(minors)
        if not minor.get("is_zero", False)
    ]
    nonzero_minors = [minors[index] for index in nonzero_indices]
    nonzero_row_subsets = sorted({tuple(minor["rows"]) for minor in nonzero_minors})
    nonzero_column_subsets = sorted(
        {tuple(minor["columns"]) for minor in nonzero_minors}
    )
    nonzero_covered_rows = sorted(
        {row for subset in nonzero_row_subsets for row in subset}
    )
    nonzero_covered_columns = sorted(
        {column for subset in nonzero_column_subsets for column in subset}
    )
    all_rows_have_nonzero_minor = bool(nonzero_indices) and nonzero_covered_rows == list(
        range(row_count)
    )
    all_columns_have_nonzero_minor = bool(
        nonzero_indices
    ) and nonzero_covered_columns == list(range(column_count))
    truncated = bool(square_minor_scan.get("truncated", False))
    skipped = bool(square_minor_scan.get("skipped", False))
    complete_combination_scan = (
        not skipped
        and not truncated
        and len(minors) == expected_combination_count
    )
    unique_polynomials = _unique_nonzero_minor_polynomials(minors)
    return {
        "method": "fox_admissible_minor_summary",
        "variables": list(square_minor_scan.get("variables", [])),
        "matrix_size": [row_count, column_count],
        "target_size": target_size,
        "expected_combination_count": expected_combination_count,
        "scanned_minor_count": len(minors),
        "complete_combination_scan": complete_combination_scan,
        "truncated": truncated,
        "skipped": skipped,
        "nonzero_minor_count": len(nonzero_indices),
        "zero_minor_count": len(minors) - len(nonzero_indices),
        "unit_minor_count": sum(1 for minor in minors if minor.get("is_unit", False)),
        "unique_nonzero_polynomials": unique_polynomials,
        "unique_nonzero_polynomial_count": len(unique_polynomials),
        "admissible_minor_indices": nonzero_indices,
        "row_subset_count": len(row_subsets),
        "column_subset_count": len(column_subsets),
        "row_subsets": [list(subset) for subset in row_subsets],
        "column_subsets": [list(subset) for subset in column_subsets],
        "covered_rows": covered_rows,
        "covered_columns": covered_columns,
        "all_rows_covered": covered_rows == list(range(row_count)),
        "all_columns_covered": covered_columns == list(range(column_count)),
        "nonzero_row_subset_count": len(nonzero_row_subsets),
        "nonzero_column_subset_count": len(nonzero_column_subsets),
        "nonzero_row_subsets": [list(subset) for subset in nonzero_row_subsets],
        "nonzero_column_subsets": [
            list(subset) for subset in nonzero_column_subsets
        ],
        "nonzero_covered_rows": nonzero_covered_rows,
        "nonzero_covered_columns": nonzero_covered_columns,
        "all_rows_have_nonzero_minor": all_rows_have_nonzero_minor,
        "all_columns_have_nonzero_minor": all_columns_have_nonzero_minor,
        "nonzero_minor_coverage_complete": (
            complete_combination_scan
            and all_rows_have_nonzero_minor
            and all_columns_have_nonzero_minor
        ),
        "notes": [
            "nonzero square minors are candidate admissible minors for later normalization",
            "this summary is scan evidence and does not by itself prove the final multi-variable Alexander invariant",
        ],
    }


def _unique_nonzero_minor_polynomials(minors: Sequence[dict]) -> list[str]:
    seen: set[str] = set()
    candidates: list[str] = []
    for minor in minors:
        if minor.get("is_zero"):
            continue
        polynomial = str(minor["polynomial"])
        if polynomial not in seen:
            candidates.append(polynomial)
            seen.add(polynomial)
    return candidates


def _gcd_skipped(
    presentation: WirtingerPresentation,
    scan: dict,
    *,
    notes: list[str],
    candidate_polynomials: list[str] | None = None,
    extra_fields: dict | None = None,
) -> dict:
    return {
        "multivariable_alexander_polynomial": None,
        "candidate_polynomials": candidate_polynomials or [],
        "method": "skipped",
        "presentation": presentation.to_dict(),
        "square_minors": scan,
        "admissible_minor_summary": scan["admissible_minor_summary"],
        "requires_normalization": True,
        "skipped": True,
        "notes": notes,
        **(extra_fields or {}),
    }


def _scanned_gcd_audit_skipped(
    base_payload: dict,
    *,
    scan: object,
    summary: object,
    notes: list[str],
) -> dict:
    return {
        **base_payload,
        "skipped": True,
        "candidate_is_exact_scanned_gcd": False,
        "complete_scanned_gcd_certified": False,
        "quotient_gcd_certified": False,
        "quotient_gcd_polynomial": None,
        "quotient_gcd_method": None,
        "improved_candidate_polynomial": None,
        "checked_nonzero_minor_count": 0,
        "failed_nonzero_minor_count": 0,
        "division_records": [],
        "failed_minor_indices": [],
        "complete_combination_scan": False,
        "truncated": bool(scan.get("truncated")) if isinstance(scan, dict) else False,
        "admissible_minor_summary": summary
        or (scan.get("admissible_minor_summary") if isinstance(scan, dict) else None),
        "notes": notes,
    }


def _audit_variables(result: dict) -> tuple[str, ...]:
    scan = result.get("square_minors")
    if isinstance(scan, dict) and scan.get("variables"):
        return tuple(str(variable) for variable in scan["variables"])
    presentation = result.get("presentation")
    if isinstance(presentation, dict) and presentation.get("variables"):
        return tuple(str(variable) for variable in presentation["variables"])
    summary = result.get("admissible_minor_summary")
    if isinstance(summary, dict) and summary.get("variables"):
        return tuple(str(variable) for variable in summary["variables"])
    return ()



def _wirtinger_fox_evidence_fields(audit: dict | None) -> dict:
    if not isinstance(audit, dict) or audit.get("skipped", False):
        return {
            "wirtinger_fox_input_chain_consistent": False,
            "wirtinger_presentation_valid": False,
            "wirtinger_relation_shape_valid": False,
            "wirtinger_relation_shape_invalid_count": 0,
            "wirtinger_relation_shape_witness_count": 0,
            "wirtinger_relation_shape_count_consistent": True,
            "wirtinger_generator_component_coverage_complete": False,
            "wirtinger_generator_component_count_row_count": 0,
            "wirtinger_generator_component_count_total": 0,
            "wirtinger_generator_component_count_consistent": True,
            "fox_jacobian_valid": False,
            "fox_square_minor_scan_valid": False,
            "wirtinger_relation_count": 0,
            "wirtinger_generator_count": 0,
            "fox_jacobian_row_count": 0,
            "fox_jacobian_column_count": 0,
            "fox_square_minor_invalid_reference_count": 0,
            "fox_square_minor_invalid_normalization_count": 0,
            **_fox_square_minor_validation_witness_evidence_fields(None),
        }

    matrix_size = audit.get("jacobian_matrix_size", [0, 0])
    if not isinstance(matrix_size, list) or len(matrix_size) < 2:
        matrix_size = [0, 0]
    relation_shape_invalid_count = int(
        audit.get("wirtinger_relation_shape_invalid_count", 0) or 0
    )
    relation_shape_witnesses = audit.get("wirtinger_relation_shape_witnesses")
    relation_shape_witness_count = (
        len(relation_shape_witnesses)
        if isinstance(relation_shape_witnesses, list)
        else 0
    )
    component_count_rows = audit.get("wirtinger_generator_component_counts")
    component_count_row_count = (
        len(component_count_rows) if isinstance(component_count_rows, list) else 0
    )
    component_count_total = (
        sum(
            int(row.get("generator_count", 0) or 0)
            for row in component_count_rows
            if isinstance(row, dict)
        )
        if isinstance(component_count_rows, list)
        else 0
    )
    generator_count = int(audit.get("generator_count", 0) or 0)
    return {
        "wirtinger_fox_input_chain_consistent": bool(
            audit.get("input_chain_consistent", False)
        ),
        "wirtinger_presentation_valid": bool(audit.get("presentation_valid", False)),
        "wirtinger_relation_shape_valid": bool(
            audit.get("wirtinger_relation_shape_valid", False)
        ),
        "wirtinger_relation_shape_invalid_count": relation_shape_invalid_count,
        "wirtinger_relation_shape_witness_count": relation_shape_witness_count,
        "wirtinger_relation_shape_count_consistent": (
            relation_shape_invalid_count == relation_shape_witness_count
        ),
        "wirtinger_generator_component_coverage_complete": bool(
            audit.get("wirtinger_generator_component_coverage_complete", False)
        ),
        "wirtinger_generator_component_count_row_count": component_count_row_count,
        "wirtinger_generator_component_count_total": component_count_total,
        "wirtinger_generator_component_count_consistent": (
            component_count_total == generator_count
        ),
        "fox_jacobian_valid": bool(audit.get("fox_jacobian_valid", False)),
        "fox_square_minor_scan_valid": bool(
            audit.get("fox_square_minor_scan_valid", False)
        ),
        "wirtinger_relation_count": int(audit.get("relation_count", 0) or 0),
        "wirtinger_generator_count": generator_count,
        "fox_jacobian_row_count": int(matrix_size[0] or 0),
        "fox_jacobian_column_count": int(matrix_size[1] or 0),
        "fox_square_minor_invalid_reference_count": int(
            audit.get("invalid_minor_reference_count", 0) or 0
        ),
        "fox_square_minor_invalid_normalization_count": int(
            audit.get("invalid_normalization_count", 0) or 0
        ),
        **_fox_square_minor_validation_witness_evidence_fields(audit),
    }


def _parse_presentation_payload(
    presentation: dict,
) -> tuple[
    tuple[tuple[tuple[int, int], ...], ...],
    tuple[int, ...],
    tuple[str, ...],
    list[str],
]:
    issues: list[str] = []

    raw_components = presentation.get("generator_components")
    generator_components: list[int] = []
    if not isinstance(raw_components, (list, tuple)):
        issues.append("presentation generator_components must be a list")
    else:
        for index, value in enumerate(raw_components):
            try:
                component = int(value)
            except (TypeError, ValueError):
                issues.append(f"generator component at index {index} is not an integer")
                continue
            if component < 0:
                issues.append(f"generator component at index {index} is negative")
            generator_components.append(component)
    if not generator_components:
        issues.append("presentation must contain at least one Wirtinger generator")

    raw_variables = presentation.get("variables")
    variables: tuple[str, ...] = ()
    if not isinstance(raw_variables, (list, tuple)):
        issues.append("presentation variables must be a list")
    else:
        variables = tuple(str(variable) for variable in raw_variables)
    if not variables:
        issues.append("presentation must expose at least one variable")
    if generator_components and variables:
        component_count = max(generator_components) + 1
        if component_count != len(variables):
            issues.append("presentation variable count does not match generator component count")

    raw_relations = presentation.get("relations")
    relations: list[tuple[tuple[int, int], ...]] = []
    if not isinstance(raw_relations, (list, tuple)):
        issues.append("presentation relations must be a list")
    else:
        for relation_index, raw_relation in enumerate(raw_relations):
            if not isinstance(raw_relation, (list, tuple)):
                issues.append(f"relation {relation_index} is not a list")
                continue
            relation: list[tuple[int, int]] = []
            for term_index, raw_term in enumerate(raw_relation):
                if not isinstance(raw_term, (list, tuple)) or len(raw_term) != 2:
                    issues.append(
                        f"relation {relation_index} term {term_index} must contain generator and exponent"
                    )
                    continue
                try:
                    generator = int(raw_term[0])
                    exponent = int(raw_term[1])
                except (TypeError, ValueError):
                    issues.append(
                        f"relation {relation_index} term {term_index} is not integral"
                    )
                    continue
                if generator < 0 or generator >= len(generator_components):
                    issues.append(
                        f"relation {relation_index} term {term_index} generator index out of range"
                    )
                if exponent not in {-1, 1}:
                    issues.append(
                        f"relation {relation_index} term {term_index} exponent is not +1 or -1"
                    )
                relation.append((generator, exponent))
            relations.append(tuple(relation))
    if not relations:
        issues.append("presentation must contain at least one relation")

    return tuple(relations), tuple(generator_components), variables, issues


def _wirtinger_relation_shape_audit(
    relations: Sequence[Sequence[tuple[int, int]]],
    *,
    generator_components: Sequence[int],
) -> dict:
    witnesses: list[dict] = []
    issues: list[str] = []
    component_counts = [
        {
            "component": component,
            "generator_count": sum(
                1 for value in generator_components if value == component
            ),
        }
        for component in range(max(generator_components) + 1)
    ] if generator_components else []
    component_coverage_complete = bool(component_counts) and all(
        row["generator_count"] > 0 for row in component_counts
    )
    if not component_coverage_complete:
        issues.append("Wirtinger generators do not cover every component")

    for relation_index, relation in enumerate(relations):
        relation_list = list(relation)
        reason = ""
        if len(relation_list) != 4:
            reason = "relation does not contain four Wirtinger terms"
        else:
            over_in = relation_list[0]
            under_in = relation_list[1]
            over_out = relation_list[2]
            under_out = relation_list[3]
            sign = over_in[1]
            if sign not in {-1, 1}:
                reason = "first over-strand exponent is not +1 or -1"
            elif over_out[0] != over_in[0]:
                reason = "first and third Wirtinger terms do not share the over generator"
            elif under_in[1] != 1:
                reason = "second under-in exponent is not +1"
            elif over_out[1] != -sign:
                reason = "third over-strand exponent is not the inverse of the first"
            elif under_out[1] != -1:
                reason = "fourth under-out exponent is not -1"
        if reason:
            witnesses.append(
                {
                    "relation_index": relation_index,
                    "reason": reason,
                    "relation": [
                        [int(generator), int(exponent)]
                        for generator, exponent in relation_list
                    ],
                }
            )

    if witnesses:
        issues.append("one or more Wirtinger relations do not match the expected shape")

    return {
        "wirtinger_relation_shape_valid": not witnesses,
        "wirtinger_relation_shape_invalid_count": len(witnesses),
        "wirtinger_relation_shape_witnesses": witnesses,
        "wirtinger_relation_shape_issues": issues,
        "wirtinger_generator_component_coverage_complete": (
            component_coverage_complete
        ),
        "wirtinger_generator_component_counts": component_counts,
    }


def _validate_square_minor_scan_payload(
    scan: object,
    *,
    expected_matrix_size: Sequence[int],
    variables: Sequence[str],
) -> tuple[bool, list[int], int, int, int, bool, bool, list[str], dict]:
    if not isinstance(scan, dict):
        return False, [0, 0], 0, 0, 0, False, False, [
            "source Alexander result does not include square-minor scan data",
        ], _empty_fox_minor_validation_witness_fields()

    raw_matrix_size = scan.get("matrix_size", [0, 0])
    matrix_size = _two_ints(raw_matrix_size)
    variable_count = len(tuple(variables))
    issues: list[str] = []
    if scan.get("skipped", False):
        issues.append("source square-minor scan was skipped")
    if list(expected_matrix_size) != [0, 0] and matrix_size != list(expected_matrix_size):
        issues.append("square-minor matrix size does not match Fox Jacobian size")

    raw_minors = scan.get("minors", [])
    if not isinstance(raw_minors, list):
        return False, matrix_size, 0, 0, 0, False, bool(scan.get("truncated", False)), [
            *issues,
            "square-minor scan minors must be a list",
        ], _empty_fox_minor_validation_witness_fields()

    invalid_reference_count = 0
    invalid_normalization_count = 0
    invalid_reference_witnesses: list[dict] = []
    invalid_normalization_witnesses: list[dict] = []
    for minor_index, minor in enumerate(raw_minors):
        if not isinstance(minor, dict):
            invalid_reference_count += 1
            invalid_normalization_count += 1
            minor_issues = ["minor is not a dictionary"]
            invalid_reference_witnesses.append(
                _minor_validation_witness(
                    minor_index,
                    minor,
                    validation_kind="reference",
                    issues=minor_issues,
                )
            )
            invalid_normalization_witnesses.append(
                _minor_validation_witness(
                    minor_index,
                    minor,
                    validation_kind="normalization",
                    issues=minor_issues,
                )
            )
            issues.append(f"minor {minor_index} is not a dictionary")
            continue
        rows_valid = _validate_minor_indices(
            minor.get("rows"),
            upper_bound=matrix_size[0],
        )
        columns_valid = _validate_minor_indices(
            minor.get("columns"),
            upper_bound=matrix_size[1],
        )
        terms_valid = _validate_minor_terms(
            minor.get("terms", []),
            variable_count=variable_count,
        )
        raw_terms_valid = _validate_minor_terms(
            minor.get("raw_terms", []),
            variable_count=variable_count,
        )
        if not (rows_valid and columns_valid and terms_valid and raw_terms_valid):
            invalid_reference_count += 1
            reference_issues = []
            if not rows_valid:
                reference_issues.append("rows are invalid for the Fox matrix")
            if not columns_valid:
                reference_issues.append("columns are invalid for the Fox matrix")
            if not terms_valid:
                reference_issues.append("terms are invalid Laurent terms")
            if not raw_terms_valid:
                reference_issues.append("raw_terms are invalid Laurent terms")
            invalid_reference_witnesses.append(
                _minor_validation_witness(
                    minor_index,
                    minor,
                    validation_kind="reference",
                    issues=reference_issues,
                )
            )
            issues.append(f"minor {minor_index} has invalid row, column, or term metadata")
        normalization_issues = _validate_minor_normalization_record(
            minor,
            variables=tuple(variables),
        )
        if normalization_issues:
            invalid_normalization_count += 1
            invalid_normalization_witnesses.append(
                _minor_validation_witness(
                    minor_index,
                    minor,
                    validation_kind="normalization",
                    issues=normalization_issues,
                )
            )
            issues.extend(
                f"minor {minor_index} normalization metadata invalid: {issue}"
                for issue in normalization_issues
            )

    summary = scan.get("admissible_minor_summary")
    complete_combination_scan = bool(
        summary.get("complete_combination_scan", False)
        if isinstance(summary, dict)
        else False
    )
    truncated = bool(scan.get("truncated", False))
    if invalid_reference_count:
        issues.append("one or more scanned Fox minors reference invalid rows, columns, or terms")
    if invalid_normalization_count:
        issues.append("one or more scanned Fox minors have invalid normalization metadata")

    return (
        len(issues) == 0,
        matrix_size,
        len(raw_minors),
        invalid_reference_count,
        invalid_normalization_count,
        complete_combination_scan,
        truncated,
        issues,
        _fox_minor_validation_witness_fields(
            reference_witnesses=invalid_reference_witnesses,
            normalization_witnesses=invalid_normalization_witnesses,
        ),
    )


def _two_ints(value: object) -> list[int]:
    if not isinstance(value, (list, tuple)) or len(value) < 2:
        return [0, 0]
    try:
        return [int(value[0]), int(value[1])]
    except (TypeError, ValueError):
        return [0, 0]


def _validate_minor_indices(value: object, *, upper_bound: int) -> bool:
    if not isinstance(value, list):
        return False
    seen: set[int] = set()
    for item in value:
        try:
            index = int(item)
        except (TypeError, ValueError):
            return False
        if index < 0 or index >= upper_bound or index in seen:
            return False
        seen.add(index)
    return True


def _validate_minor_terms(value: object, *, variable_count: int) -> bool:
    if not isinstance(value, list):
        return False
    for term in value:
        if not isinstance(term, dict):
            return False
        exponents = term.get("exponents")
        if not isinstance(exponents, list) or len(exponents) != variable_count:
            return False
        try:
            [int(exponent) for exponent in exponents]
            int(term.get("coefficient"))
        except (TypeError, ValueError):
            return False
    return True

def _validate_minor_normalization_record(
    minor: dict,
    *,
    variables: Sequence[str],
) -> list[str]:
    normalization = minor.get("normalization")
    if not isinstance(normalization, dict):
        return ["missing normalization record"]
    variable_count = len(tuple(variables))
    issues: list[str] = []
    raw_terms = minor.get("raw_terms", [])
    output_terms = minor.get("terms", [])
    if not _validate_minor_terms(raw_terms, variable_count=variable_count):
        return ["raw_terms are not valid Laurent terms"]
    if not _validate_minor_terms(output_terms, variable_count=variable_count):
        return ["terms are not valid Laurent terms"]

    try:
        raw_polynomial = _polynomial_from_serialized_terms(
            raw_terms,
            variables=variables,
        )
        output_polynomial = _polynomial_from_serialized_terms(
            output_terms,
            variables=variables,
        )
    except (KeyError, TypeError, ValueError) as exc:
        return [f"term parsing failed: {exc}"]

    canonical, expected_record = raw_polynomial.normalize_unit_with_record()
    applied_value = normalization.get("applied")
    if not isinstance(applied_value, bool):
        issues.append("applied must be a boolean")
        applied = True
    else:
        applied = applied_value
    expected_output = canonical if applied else raw_polynomial

    expected_fields = {
        "method": expected_record["method"],
        "variables": list(variables),
        "is_zero": expected_record["is_zero"],
        "unit_sign": expected_record["unit_sign"],
        "unit_exponents": expected_record["unit_exponents"],
        "minimum_exponents": expected_record["minimum_exponents"],
        "leading_coefficient_before_sign": expected_record[
            "leading_coefficient_before_sign"
        ],
        "raw_polynomial": raw_polynomial.format(),
        "normalized_polynomial": canonical.format(),
        "output_polynomial": expected_output.format(),
    }
    for field, expected in expected_fields.items():
        if normalization.get(field) != expected:
            issues.append(f"{field} does not match deterministic normalization")

    if str(minor.get("raw_polynomial")) != raw_polynomial.format():
        issues.append("minor raw_polynomial does not match raw_terms")
    if str(minor.get("polynomial")) != output_polynomial.format():
        issues.append("minor polynomial does not match terms")
    if output_polynomial.to_dict() != expected_output.to_dict():
        issues.append("minor output terms do not match the normalization applied flag")

    normalization_raw_terms = normalization.get("raw_terms", [])
    normalization_normalized_terms = normalization.get("normalized_terms", [])
    if not _validate_minor_terms(normalization_raw_terms, variable_count=variable_count):
        issues.append("normalization raw_terms are invalid")
    else:
        normalization_raw = _polynomial_from_serialized_terms(
            normalization_raw_terms,
            variables=variables,
        )
        if normalization_raw.to_dict() != raw_polynomial.to_dict():
            issues.append("normalization raw_terms do not match raw_polynomial")
    if not _validate_minor_terms(
        normalization_normalized_terms,
        variable_count=variable_count,
    ):
        issues.append("normalization normalized_terms are invalid")
    else:
        normalization_normalized = _polynomial_from_serialized_terms(
            normalization_normalized_terms,
            variables=variables,
        )
        if normalization_normalized.to_dict() != canonical.to_dict():
            issues.append("normalization normalized_terms do not match normalized_polynomial")

    return issues

def _is_unit_polynomial(polynomial: MultivariateLaurentPolynomial) -> bool:
    return len(polynomial.terms) == 1 and abs(polynomial.terms[0][1]) == 1


def _term_count_distribution(
    term_counts: Sequence[int],
    *,
    count_field: str,
) -> list[dict]:
    counts: dict[int, int] = {}
    for term_count in term_counts:
        normalized_count = int(term_count)
        counts[normalized_count] = counts.get(normalized_count, 0) + 1
    return [
        {
            "term_count": term_count,
            count_field: counts[term_count],
        }
        for term_count in sorted(counts)
    ]


def _conservative_common_gcd_from_minors(
    minors: Sequence[dict],
    *,
    variables: Sequence[str],
) -> tuple[MultivariateLaurentPolynomial, str, str] | None:
    result = _conservative_common_gcd_with_evidence_from_minors(
        minors,
        variables=variables,
    )
    if result is None:
        return None
    polynomial, method, note, _ = result
    return polynomial, method, note


def _conservative_common_gcd_with_evidence_from_minors(
    minors: Sequence[dict],
    *,
    variables: Sequence[str],
) -> tuple[MultivariateLaurentPolynomial, str, str, dict] | None:
    polynomials = [
        _polynomial_from_serialized_terms(minor["terms"], variables=variables)
        for minor in minors
        if not minor.get("is_zero")
    ]
    if not polynomials:
        return None

    common_content = _common_integer_content(polynomials)
    reduced_polynomials = polynomials
    if common_content > 1:
        reduced_polynomials = [
            _divide_polynomial_by_integer(polynomial, common_content)
            for polynomial in polynomials
        ]

    reduced_result = _conservative_common_laurent_gcd_from_polynomials(
        reduced_polynomials,
        variables=variables,
    )
    if reduced_result is not None:
        polynomial, method, note = reduced_result
        if common_content > 1:
            restored = _restore_integer_content_gcd(
                polynomials,
                polynomial,
                method=method,
                note=note,
                common_content=common_content,
                variables=variables,
            )
            polynomial, method, note = restored
        evidence = _common_gcd_evidence(
            polynomials,
            polynomial,
            variables=variables,
            common_integer_content=common_content,
            method=method,
            note=note,
        )
        return polynomial, method, note, evidence

    if common_content > 1:
        polynomial = MultivariateLaurentPolynomial.constant(
            common_content,
            variables=variables,
        )
        method = "fox_square_minor_integer_content_gcd"
        note = "all nonzero scanned Fox minors share a non-unit integer coefficient content"
        evidence = _common_gcd_evidence(
            polynomials,
            polynomial,
            variables=variables,
            common_integer_content=common_content,
            method=method,
            note=note,
        )
        return (
            polynomial,
            method,
            note,
            evidence,
        )

    return None


def _common_gcd_evidence(
    polynomials: Sequence[MultivariateLaurentPolynomial],
    candidate: MultivariateLaurentPolynomial,
    *,
    variables: Sequence[str],
    common_integer_content: int,
    method: str,
    note: str,
) -> dict:
    normalized_candidate = candidate.normalize_unit()
    normalized_inputs = [polynomial.normalize_unit() for polynomial in polynomials]
    input_term_counts = [len(polynomial.terms) for polynomial in normalized_inputs]
    division_records = []
    failed_indices = []
    quotient_polynomials: list[MultivariateLaurentPolynomial] = []
    for index, polynomial in enumerate(polynomials):
        quotient = _exact_multivariate_division(polynomial, normalized_candidate)
        divisible = quotient is not None
        if not divisible:
            failed_indices.append(index)
        normalized_quotient = quotient.normalize_unit() if quotient is not None else None
        if normalized_quotient is not None:
            quotient_polynomials.append(normalized_quotient)
        division_records.append(
            {
                "input_index": index,
                "input_polynomial": normalized_inputs[index].format(),
                "divisible": divisible,
                "quotient_polynomial": (
                    normalized_quotient.format()
                    if normalized_quotient is not None
                    else None
                ),
                "quotient_terms": (
                    _serialized_terms(normalized_quotient)
                    if normalized_quotient is not None
                    else []
                ),
                "quotient_is_unit": (
                    _is_unit_polynomial(normalized_quotient)
                    if normalized_quotient is not None
                    else False
                ),
            }
        )
    quotient_term_counts = [
        len(polynomial.terms)
        for polynomial in quotient_polynomials
    ]
    quotient_unit_indices = [
        int(record["input_index"])
        for record in division_records
        if record["quotient_is_unit"]
    ]
    quotient_status = _quotient_common_factor_status(
        quotient_polynomials if not failed_indices else (),
        variables=variables,
        skipped=bool(failed_indices),
    )

    return {
        "method": "fox_square_minor_common_gcd_evidence",
        "claim_scope": "bounded_scanned_fox_minor_common_divisor",
        "variables": list(variables),
        "input_polynomial_count": len(polynomials),
        "unique_input_polynomial_count": len(
            {polynomial.format() for polynomial in normalized_inputs}
        ),
        "input_polynomials": [
            polynomial.format()
            for polynomial in normalized_inputs
        ],
        "input_term_count_min": min(input_term_counts) if input_term_counts else 0,
        "input_term_count_max": max(input_term_counts) if input_term_counts else 0,
        "input_term_count_signature": _term_count_distribution(
            input_term_counts,
            count_field="input_count",
        ),
        "candidate_method": method,
        "candidate_note": note,
        "candidate_polynomial": normalized_candidate.format(),
        "candidate_term_count": len(normalized_candidate.terms),
        "candidate_terms": _serialized_terms(normalized_candidate),
        "bounded_search_limits": _bounded_common_gcd_search_limits(),
        "common_integer_content": common_integer_content,
        "integer_content_removed": common_integer_content > 1,
        "divides_all_inputs": not failed_indices,
        "divisible_input_count": len(polynomials) - len(failed_indices),
        "failed_input_count": len(failed_indices),
        "failed_input_indices": failed_indices,
        "division_records": division_records,
        "quotient_count": len(quotient_polynomials),
        "unique_quotient_polynomial_count": len(
            {polynomial.format() for polynomial in quotient_polynomials}
        ),
        "quotient_term_count_min": (
            min(quotient_term_counts) if quotient_term_counts else 0
        ),
        "quotient_term_count_max": (
            max(quotient_term_counts) if quotient_term_counts else 0
        ),
        "quotient_term_count_signature": _term_count_distribution(
            quotient_term_counts,
            count_field="quotient_count",
        ),
        "quotient_unit_count": len(quotient_unit_indices),
        "quotient_unit_indices": quotient_unit_indices,
        "quotient_common_factor_status": quotient_status,
        "quotient_common_factor_certified": quotient_status[
            "quotient_common_factor_certified"
        ],
        "quotient_common_factor_polynomial": quotient_status[
            "quotient_common_factor_polynomial"
        ],
        "quotient_common_factor_method": quotient_status[
            "quotient_common_factor_method"
        ],
        "quotient_common_factor_is_unit": quotient_status[
            "quotient_common_factor_is_unit"
        ],
        "candidate_is_exact_gcd_for_inputs": quotient_status[
            "candidate_is_exact_gcd_for_inputs"
        ],
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": [
            "candidate common divisor is verified only against the bounded scanned Fox-minor set",
            "full admissible-minor normalization and external table normalization remain separate claims",
        ],
    }


def _common_gcd_attempt_evidence_from_minors(
    minors: Sequence[dict],
    *,
    variables: Sequence[str],
    status: str,
    notes: Sequence[str],
) -> dict:
    polynomials = [
        _polynomial_from_serialized_terms(minor["terms"], variables=variables)
        for minor in minors
        if not minor.get("is_zero")
    ]
    normalized_polynomials = [
        polynomial.normalize_unit()
        for polynomial in polynomials
    ]
    input_term_counts = [len(polynomial.terms) for polynomial in normalized_polynomials]
    unique_polynomials = sorted(
        {polynomial.format() for polynomial in normalized_polynomials}
    )
    return {
        "method": "fox_square_minor_common_gcd_attempt_evidence",
        "claim_scope": "bounded_scanned_fox_minor_common_gcd_attempt",
        "status": status,
        "certified": False,
        "variables": list(variables),
        "input_polynomial_count": len(normalized_polynomials),
        "unique_input_polynomial_count": len(unique_polynomials),
        "input_polynomials": [
            polynomial.format()
            for polynomial in normalized_polynomials
        ],
        "input_term_count_min": min(input_term_counts) if input_term_counts else 0,
        "input_term_count_max": max(input_term_counts) if input_term_counts else 0,
        "input_term_count_signature": _term_count_distribution(
            input_term_counts,
            count_field="input_count",
        ),
        "unique_input_polynomials": unique_polynomials,
        "common_integer_content": _common_integer_content(normalized_polynomials),
        "candidate_polynomial": None,
        "candidate_method": None,
        "candidate_methods_attempted": [
            "integer_content",
            "univariate_gcd",
            "rank_one_monomial_gcd",
            "direct_scanned_minor_divisor",
            "bounded_multivariate_binomial_factor",
            "bounded_multivariate_root_binomial_factor",
            "bounded_multivariate_sparse_factor",
            "bounded_multivariate_cofactor_factor",
        ],
        "bounded_search_limits": _bounded_common_gcd_search_limits(),
        "attempt_diagnostics": _common_gcd_attempt_diagnostics(
            normalized_polynomials,
            variables=variables,
        ),
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": list(notes),
    }


def _common_gcd_attempt_diagnostics(
    polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    variables: Sequence[str],
) -> dict:
    normalized_polynomials = [polynomial.normalize_unit() for polynomial in polynomials]
    input_term_counts = [len(polynomial.terms) for polynomial in normalized_polynomials]
    supports = [
        _polynomial_variable_support(polynomial)
        for polynomial in normalized_polynomials
    ]
    common_support = set.intersection(*supports) if supports else set()
    union_support = set.union(*supports) if supports else set()
    support_signature_counts: dict[tuple[str, ...], int] = {}
    for support in supports:
        signature = tuple(
            variables[index]
            for index in sorted(support)
            if index < len(variables)
        )
        support_signature_counts[signature] = (
            support_signature_counts.get(signature, 0) + 1
        )

    return {
        "method": "bounded_common_gcd_attempt_diagnostics",
        "claim_scope": "bounded_scanned_fox_minor_common_gcd_attempt",
        "input_polynomial_count": len(normalized_polynomials),
        "unique_input_polynomial_count": len(
            {polynomial.format() for polynomial in normalized_polynomials}
        ),
        "input_term_count_min": min(input_term_counts) if input_term_counts else 0,
        "input_term_count_max": max(input_term_counts) if input_term_counts else 0,
        "input_term_count_signature": _term_count_distribution(
            input_term_counts,
            count_field="input_count",
        ),
        "common_variable_support": [
            variables[index]
            for index in sorted(common_support)
            if index < len(variables)
        ],
        "union_variable_support": [
            variables[index]
            for index in sorted(union_support)
            if index < len(variables)
        ],
        "support_signature_counts": [
            {"variables": list(signature), "input_count": count}
            for signature, count in sorted(
                support_signature_counts.items(),
                key=lambda item: (item[0], item[1]),
            )
        ],
        "support_signature_variant_count": len(support_signature_counts),
        "direct_scanned_minor_divisor_summary": (
            _direct_scanned_minor_divisor_attempt_summary(
                normalized_polynomials,
                variables=variables,
            )
        ),
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": [
            "diagnostics describe why bounded common-gcd search stayed uncertified",
            "they do not claim full multivariate Laurent gcd coverage",
        ],
    }


def _direct_scanned_minor_divisor_attempt_summary(
    polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    variables: Sequence[str],
    max_terms: int = _BOUNDED_MULTIVARIATE_COMMON_GCD_MAX_TERMS,
) -> dict:
    candidates: dict[str, MultivariateLaurentPolynomial] = {}
    for polynomial in polynomials:
        candidate = _primitive_multivariate_polynomial(polynomial).normalize_unit()
        if _is_unit_polynomial(candidate) or len(candidate.terms) > max_terms:
            continue
        candidates[candidate.format()] = candidate

    ordered_candidates = sorted(
        candidates.values(),
        key=lambda item: (len(item.terms), item.format()),
    )
    divides_all_candidate_count = 0
    failed_candidate_count = 0
    first_failure: dict | None = None
    term_counts = [len(candidate.terms) for candidate in ordered_candidates]
    failed_input_counts: list[int] = []
    for candidate_index, candidate in enumerate(ordered_candidates):
        failed_input_indices: list[int] = []
        for input_index, polynomial in enumerate(polynomials):
            if _exact_multivariate_division(polynomial, candidate) is None:
                failed_input_indices.append(input_index)
                if first_failure is None:
                    first_failure = {
                        "candidate_index": candidate_index,
                        "candidate_polynomial": candidate.format(),
                        "candidate_term_count": len(candidate.terms),
                        "failed_input_index": input_index,
                        "failed_input_polynomial": polynomial.normalize_unit().format(),
                        "failed_input_term_count": len(polynomial.terms),
                    }
        if failed_input_indices:
            failed_candidate_count += 1
            failed_input_counts.append(len(failed_input_indices))
        else:
            divides_all_candidate_count += 1

    return {
        "method": "direct_scanned_minor_divisor_attempt_summary",
        "variables": list(variables),
        "max_candidate_terms": max_terms,
        "candidate_count": len(ordered_candidates),
        "checked_candidate_count": len(ordered_candidates),
        "divides_all_candidate_count": divides_all_candidate_count,
        "failed_candidate_count": failed_candidate_count,
        "candidate_term_count_min": min(term_counts) if term_counts else 0,
        "candidate_term_count_max": max(term_counts) if term_counts else 0,
        "failed_input_count_min": (
            min(failed_input_counts) if failed_input_counts else 0
        ),
        "failed_input_count_max": (
            max(failed_input_counts) if failed_input_counts else 0
        ),
        "all_candidates_failed": bool(ordered_candidates)
        and failed_candidate_count == len(ordered_candidates),
        "first_failure": first_failure,
        "full_admissible_minor_normalization_certified": False,
        "full_invariant_certified": False,
        "notes": [
            "candidate divisors are primitive normalized non-unit scanned minor polynomials within the bounded term limit",
        ],
    }


def _bounded_common_gcd_search_limits() -> dict:
    return {
        "max_candidate_terms": _BOUNDED_MULTIVARIATE_COMMON_GCD_MAX_TERMS,
        "direct_scanned_minor_divisor_max_terms": (
            _BOUNDED_MULTIVARIATE_COMMON_GCD_MAX_TERMS
        ),
        "sparse_factor_max_terms": _BOUNDED_MULTIVARIATE_COMMON_GCD_MAX_TERMS,
        "sparse_factor_max_factors": _BOUNDED_MULTIVARIATE_SPARSE_FACTOR_MAX_FACTORS,
        "sparse_factor_max_candidates": (
            _BOUNDED_MULTIVARIATE_SPARSE_FACTOR_MAX_CANDIDATES
        ),
        "root_binomial_max_candidates": (
            _BOUNDED_MULTIVARIATE_ROOT_BINOMIAL_MAX_CANDIDATES
        ),
        "cofactor_max_terms": _BOUNDED_MULTIVARIATE_COMMON_GCD_MAX_TERMS,
        "cofactor_max_divisor_factors": (
            _BOUNDED_MULTIVARIATE_COFACTOR_MAX_DIVISOR_FACTORS
        ),
        "cofactor_max_candidates": _BOUNDED_MULTIVARIATE_COFACTOR_MAX_CANDIDATES,
        "cofactor_small_divisor_sparse_factor_max_terms": (
            _BOUNDED_MULTIVARIATE_COMMON_GCD_MAX_TERMS
        ),
        "optional_symbolic_gcd_max_variables": (
            _OPTIONAL_SYMBOLIC_MULTIVARIATE_GCD_MAX_VARIABLES
        ),
        "optional_symbolic_gcd_max_polynomials": (
            _OPTIONAL_SYMBOLIC_MULTIVARIATE_GCD_MAX_POLYNOMIALS
        ),
        "optional_symbolic_gcd_max_total_terms": (
            _OPTIONAL_SYMBOLIC_MULTIVARIATE_GCD_MAX_TOTAL_TERMS
        ),
        "full_invariant_certified": False,
    }

def _quotient_common_factor_status(
    quotient_polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    variables: Sequence[str],
    skipped: bool = False,
) -> dict:
    quotients = [polynomial.normalize_unit() for polynomial in quotient_polynomials]
    unit_indices = [
        index for index, polynomial in enumerate(quotients) if _is_unit_polynomial(polynomial)
    ]
    supports = [_polynomial_variable_support(polynomial) for polynomial in quotients]
    common_support = set.intersection(*supports) if supports else set()
    support_names = [
        variables[index]
        for index in sorted(common_support)
        if index < len(variables)
    ]
    base = {
        "method": "bounded_quotient_common_factor_status",
        "quotient_count": len(quotients),
        "quotient_polynomials": [polynomial.format() for polynomial in quotients],
        "quotient_unit_witness_count": len(unit_indices),
        "quotient_unit_witness_indices": unit_indices,
        "common_variable_support": support_names,
        "quotient_common_factor_certified": False,
        "quotient_common_factor_polynomial": None,
        "quotient_common_factor_method": None,
        "quotient_common_factor_is_unit": False,
        "candidate_is_exact_gcd_for_inputs": False,
    }
    if skipped:
        return {
            **base,
            "skipped": True,
            "notes": [
                "candidate did not divide every input, so quotient common-factor status was not evaluated",
            ],
        }
    if not quotients:
        return {
            **base,
            "skipped": True,
            "notes": ["no quotient polynomials were available to audit"],
        }
    if unit_indices:
        return {
            **base,
            "skipped": False,
            "quotient_common_factor_certified": True,
            "quotient_common_factor_polynomial": "1",
            "quotient_common_factor_method": "quotient_unit_witness_gcd",
            "quotient_common_factor_is_unit": True,
            "candidate_is_exact_gcd_for_inputs": True,
            "notes": [
                "at least one quotient is a unit, so the quotient set has unit common factor",
            ],
        }

    common_content = _common_integer_content(quotients)
    if common_content > 1:
        return {
            **base,
            "skipped": False,
            "quotient_common_factor_certified": True,
            "quotient_common_factor_polynomial": str(common_content),
            "quotient_common_factor_method": "quotient_integer_content_gcd",
            "quotient_common_factor_is_unit": False,
            "candidate_is_exact_gcd_for_inputs": False,
            "notes": [
                "quotients share a non-unit integer coefficient content",
            ],
        }
    if all(not support for support in supports):
        return {
            **base,
            "skipped": False,
            "quotient_common_factor_certified": True,
            "quotient_common_factor_polynomial": "1",
            "quotient_common_factor_method": "quotient_integer_content_unit_gcd",
            "quotient_common_factor_is_unit": True,
            "candidate_is_exact_gcd_for_inputs": True,
            "notes": [
                "constant quotients have no non-unit integer common content",
            ],
        }
    if not common_support:
        return {
            **base,
            "skipped": False,
            "quotient_common_factor_certified": True,
            "quotient_common_factor_polynomial": "1",
            "quotient_common_factor_method": "quotient_disjoint_support_unit_gcd",
            "quotient_common_factor_is_unit": True,
            "candidate_is_exact_gcd_for_inputs": True,
            "notes": [
                "quotients have no common variable support, so their common Laurent factor is a unit",
            ],
        }

    quotient_gcd = _conservative_common_laurent_gcd_from_polynomials(
        quotients,
        variables=variables,
    )
    if quotient_gcd is None:
        return {
            **base,
            "skipped": False,
            "notes": [
                "quotient common factor was not certified by the conservative bounded layer",
            ],
        }

    quotient_common, quotient_method, quotient_note = quotient_gcd
    normalized_common = quotient_common.normalize_unit()
    common_is_unit = _is_unit_polynomial(normalized_common)
    return {
        **base,
        "skipped": False,
        "quotient_common_factor_certified": True,
        "quotient_common_factor_polynomial": normalized_common.format(),
        "quotient_common_factor_method": f"quotient_{quotient_method}",
        "quotient_common_factor_is_unit": common_is_unit,
        "candidate_is_exact_gcd_for_inputs": common_is_unit,
        "notes": [quotient_note],
    }


def _conservative_common_laurent_gcd_from_polynomials(
    polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    variables: Sequence[str],
) -> tuple[MultivariateLaurentPolynomial, str, str] | None:
    supports = [_polynomial_variable_support(polynomial) for polynomial in polynomials]
    common_support = set.intersection(*supports) if supports else set()
    if not common_support and any(supports):
        return (
            MultivariateLaurentPolynomial.constant(1, variables=variables),
            "fox_square_minor_disjoint_support_gcd",
            "nonzero scanned Fox minors have no common variable support, so their common Laurent factor is 1",
        )

    union_support = set.union(*supports) if supports else set()
    if len(union_support) == 1:
        variable_index = next(iter(union_support))
        gcd_terms = _univariate_integer_gcd(
            [
                _as_univariate_terms(polynomial, variable_index=variable_index)
                for polynomial in polynomials
            ]
        )
        gcd_polynomial = _univariate_terms_to_multivariate(
            gcd_terms,
            variable_index=variable_index,
            variables=variables,
        ).normalize_unit()
        if not _is_unit_polynomial(gcd_polynomial):
            return (
                gcd_polynomial,
                "fox_square_minor_univariate_gcd",
                "all nonzero scanned Fox minors are one-variable Laurent polynomials, so an exact univariate gcd was computed",
            )
        return (
            MultivariateLaurentPolynomial.constant(1, variables=variables),
            "fox_square_minor_univariate_unit_gcd",
            "all nonzero scanned Fox minors are one-variable Laurent polynomials with unit gcd",
        )

    rank_one_gcd = _rank_one_monomial_laurent_gcd(
        polynomials,
        variables=variables,
    )
    if rank_one_gcd is not None:
        gcd_polynomial, axis = rank_one_gcd
        axis_note = ",".join(str(value) for value in axis)
        if not _is_unit_polynomial(gcd_polynomial):
            return (
                gcd_polynomial,
                "fox_square_minor_rank_one_monomial_gcd",
                (
                    "all nonzero scanned Fox minors lie on one monomial exponent "
                    f"axis [{axis_note}], so an exact univariate gcd in that "
                    "monomial was computed"
                ),
            )
        return (
            MultivariateLaurentPolynomial.constant(1, variables=variables),
            "fox_square_minor_rank_one_monomial_unit_gcd",
            (
                "all nonzero scanned Fox minors lie on one monomial exponent "
                f"axis [{axis_note}] with unit gcd"
            ),
        )

    divisor_gcd = _common_scanned_polynomial_divisor(
        polynomials,
        variables=variables,
    )
    if divisor_gcd is not None:
        return (
            divisor_gcd,
            "fox_square_minor_multivariate_divisor_gcd",
            "a non-unit scanned Fox minor divides every nonzero scanned minor by exact multivariate division",
        )

    bounded_factor_gcd = _bounded_multivariate_common_binomial_factor(
        polynomials,
        variables=variables,
    )
    if bounded_factor_gcd is not None:
        return (
            bounded_factor_gcd,
            "fox_square_minor_multivariate_factor_gcd",
            "a bounded exact scan found a common multivariate binomial Laurent factor of all nonzero scanned Fox minors",
        )

    root_binomial_gcd = _bounded_multivariate_common_root_binomial_factor(
        polynomials,
        variables=variables,
    )
    if root_binomial_gcd is not None:
        return (
            root_binomial_gcd,
            "fox_square_minor_multivariate_root_binomial_factor_gcd",
            "a bounded exact root-binomial scan found a hidden common Laurent binomial factor of all nonzero scanned Fox minors",
        )

    sparse_factor_gcd = _bounded_multivariate_common_sparse_factor(
        polynomials,
        variables=variables,
    )
    if sparse_factor_gcd is not None:
        return (
            sparse_factor_gcd,
            "fox_square_minor_multivariate_sparse_factor_gcd",
            "a bounded exact sparse-factor scan found a common multivariate Laurent factor or factor product of all nonzero scanned Fox minors",
        )

    cofactor_gcd = _bounded_multivariate_common_cofactor_factor(
        polynomials,
        variables=variables,
    )
    if cofactor_gcd is not None:
        return (
            cofactor_gcd,
            "fox_square_minor_multivariate_cofactor_factor_gcd",
            "a bounded exact cofactor scan found a common multivariate Laurent factor hidden behind cancelling small factors",
        )

    symbolic_gcd = _optional_symbolic_common_laurent_gcd(
        polynomials,
        variables=variables,
    )
    if symbolic_gcd is not None:
        return (
            symbolic_gcd,
            "fox_square_minor_optional_symbolic_multivariate_gcd",
            "an optional exact symbolic gcd found a common multivariate Laurent factor of the bounded scanned Fox minors",
        )

    return None


def _common_integer_content(
    polynomials: Sequence[MultivariateLaurentPolynomial],
) -> int:
    common_content = 0
    for polynomial in polynomials:
        polynomial_content = 0
        for _, coefficient in polynomial.terms:
            polynomial_content = gcd(polynomial_content, abs(coefficient))
        common_content = (
            polynomial_content
            if common_content == 0
            else gcd(common_content, polynomial_content)
        )
    return common_content


def _divide_polynomial_by_integer(
    polynomial: MultivariateLaurentPolynomial,
    divisor: int,
) -> MultivariateLaurentPolynomial:
    if divisor == 0:
        raise ZeroDivisionError("integer polynomial divisor must be nonzero")
    return MultivariateLaurentPolynomial(
        tuple(
            (exponents, coefficient // divisor)
            for exponents, coefficient in polynomial.terms
        ),
        variables=polynomial.variables,
    )


def _restore_integer_content_gcd(
    original_polynomials: Sequence[MultivariateLaurentPolynomial],
    reduced_gcd: MultivariateLaurentPolynomial,
    *,
    method: str,
    note: str,
    common_content: int,
    variables: Sequence[str],
) -> tuple[MultivariateLaurentPolynomial, str, str]:
    content_polynomial = MultivariateLaurentPolynomial.constant(
        common_content,
        variables=variables,
    )
    candidate = (
        content_polynomial
        if _is_unit_polynomial(reduced_gcd)
        else (content_polynomial * reduced_gcd).normalize_unit()
    )
    if not all(
        _exact_multivariate_division(polynomial, candidate) is not None
        for polynomial in original_polynomials
    ):
        return (
            content_polynomial,
            "fox_square_minor_integer_content_gcd",
            "all nonzero scanned Fox minors share a non-unit integer coefficient content",
        )
    if _is_unit_polynomial(reduced_gcd):
        return (
            candidate,
            "fox_square_minor_integer_content_gcd",
            "all nonzero scanned Fox minors share a non-unit integer coefficient content; after removing it, the remaining certified Laurent gcd is a unit",
        )
    return (
        candidate,
        "fox_square_minor_integer_content_product_gcd",
        (
            "all nonzero scanned Fox minors share a non-unit integer coefficient "
            f"content and, after removing it, also share this certified Laurent factor: {note}"
        ),
    )


def _common_scanned_polynomial_divisor(
    polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    variables: Sequence[str],
    max_terms: int = _BOUNDED_MULTIVARIATE_COMMON_GCD_MAX_TERMS,
) -> MultivariateLaurentPolynomial | None:
    candidates: dict[str, MultivariateLaurentPolynomial] = {}
    for polynomial in polynomials:
        candidate = _primitive_multivariate_polynomial(polynomial).normalize_unit()
        if _is_unit_polynomial(candidate) or len(candidate.terms) > max_terms:
            continue
        candidates[candidate.format()] = candidate

    for candidate in sorted(
        candidates.values(),
        key=lambda item: (len(item.terms), item.format()),
    ):
        quotients = [
            _exact_multivariate_division(polynomial, candidate)
            for polynomial in polynomials
        ]
        if all(quotient is not None for quotient in quotients):
            return candidate.normalize_unit()
    return None


def _normalize_alexander_polynomial(
    polynomial: MultivariateLaurentPolynomial,
    *,
    normalize: bool,
) -> tuple[MultivariateLaurentPolynomial, dict]:
    canonical, record = polynomial.normalize_unit_with_record()
    output = canonical if normalize else polynomial
    normalization = {
        **record,
        "applied": bool(normalize),
        "raw_polynomial": polynomial.format(),
        "normalized_polynomial": canonical.format(),
        "output_polynomial": output.format(),
        "raw_terms": _serialized_terms(polynomial),
        "normalized_terms": _serialized_terms(canonical),
        "notes": [
            "deterministic Laurent-unit normalization shifts minimum exponents to zero and makes the first lexicographic coefficient positive",
        ],
    }
    if not normalize:
        normalization["notes"].append(
            "normalization was disabled for this output; normalized_polynomial records the canonical value that would be emitted when enabled",
        )
    return output, normalization

def _serialized_terms(polynomial: MultivariateLaurentPolynomial) -> list[dict]:
    return [
        {
            "exponents": list(exponents),
            "coefficient": coefficient,
        }
        for exponents, coefficient in polynomial.terms
    ]


def _polynomial_from_serialized_terms(
    terms: Sequence[dict],
    *,
    variables: Sequence[str],
) -> MultivariateLaurentPolynomial:
    return MultivariateLaurentPolynomial(
        tuple(
            (
                tuple(int(exponent) for exponent in item["exponents"]),
                int(item["coefficient"]),
            )
            for item in terms
        ),
        variables=tuple(variables),
    )


def _polynomial_variable_support(polynomial: MultivariateLaurentPolynomial) -> set[int]:
    support: set[int] = set()
    for exponents, _ in polynomial.terms:
        support.update(index for index, exponent in enumerate(exponents) if exponent != 0)
    return support


def _rank_one_monomial_laurent_gcd(
    polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    variables: Sequence[str],
) -> tuple[MultivariateLaurentPolynomial, tuple[int, ...]] | None:
    axis = _shared_rank_one_exponent_axis(polynomials)
    if axis is None:
        return None
    gcd_terms = _univariate_integer_gcd(
        [
            _as_rank_one_univariate_terms(polynomial, axis=axis)
            for polynomial in polynomials
        ]
    )
    gcd_polynomial = _rank_one_terms_to_multivariate(
        gcd_terms,
        axis=axis,
        variables=variables,
    ).normalize_unit()
    if _is_unit_polynomial(gcd_polynomial):
        return gcd_polynomial, axis
    if all(
        _exact_multivariate_division(polynomial, gcd_polynomial) is not None
        for polynomial in polynomials
    ):
        return gcd_polynomial, axis
    return None


def _shared_rank_one_exponent_axis(
    polynomials: Sequence[MultivariateLaurentPolynomial],
) -> tuple[int, ...] | None:
    axis: tuple[int, ...] | None = None
    for polynomial in polynomials:
        if polynomial.is_zero or len(polynomial.terms) < 2:
            continue
        anchor = polynomial.terms[0][0]
        for exponents, _coefficient in polynomial.terms[1:]:
            delta = tuple(
                exponent - anchor_exponent
                for exponent, anchor_exponent in zip(exponents, anchor)
            )
            primitive = _primitive_integer_vector(delta)
            if primitive is None:
                continue
            if axis is None:
                axis = primitive
            elif primitive != axis:
                return None
            if _integer_vector_multiple(delta, axis) is None:
                return None
    if axis is None:
        return None
    for polynomial in polynomials:
        if polynomial.is_zero or len(polynomial.terms) < 2:
            continue
        anchor = polynomial.terms[0][0]
        for exponents, _coefficient in polynomial.terms:
            delta = tuple(
                exponent - anchor_exponent
                for exponent, anchor_exponent in zip(exponents, anchor)
            )
            if _integer_vector_multiple(delta, axis) is None:
                return None
    return axis


def _primitive_integer_vector(vector: Sequence[int]) -> tuple[int, ...] | None:
    content = 0
    for value in vector:
        content = gcd(content, abs(value))
    if content == 0:
        return None
    primitive = tuple(int(value // content) for value in vector)
    for value in primitive:
        if value == 0:
            continue
        if value < 0:
            primitive = tuple(-item for item in primitive)
        break
    return primitive


def _integer_vector_multiple(
    vector: Sequence[int],
    axis: Sequence[int],
) -> int | None:
    scale: int | None = None
    for value, axis_value in zip(vector, axis):
        if axis_value == 0:
            if value != 0:
                return None
            continue
        if value % axis_value != 0:
            return None
        candidate_scale = value // axis_value
        if scale is None:
            scale = candidate_scale
        elif scale != candidate_scale:
            return None
    return 0 if scale is None else scale


def _as_rank_one_univariate_terms(
    polynomial: MultivariateLaurentPolynomial,
    *,
    axis: Sequence[int],
) -> dict[int, int]:
    if polynomial.is_zero:
        return {}
    anchor = polynomial.terms[0][0]
    terms: dict[int, int] = {}
    for exponents, coefficient in polynomial.terms:
        delta = tuple(
            exponent - anchor_exponent
            for exponent, anchor_exponent in zip(exponents, anchor)
        )
        exponent = _integer_vector_multiple(delta, axis)
        if exponent is None:
            raise ValueError("polynomial terms do not lie on the rank-one axis")
        terms[exponent] = terms.get(exponent, 0) + coefficient
    return {exponent: coefficient for exponent, coefficient in terms.items() if coefficient}


def _rank_one_terms_to_multivariate(
    terms: dict[int, int],
    *,
    axis: Sequence[int],
    variables: Sequence[str],
) -> MultivariateLaurentPolynomial:
    multivariate_terms = {
        tuple(int(exponent * axis_value) for axis_value in axis): coefficient
        for exponent, coefficient in terms.items()
        if coefficient
    }
    return MultivariateLaurentPolynomial.from_dict(
        multivariate_terms,
        variables=tuple(variables),
    )


def _bounded_multivariate_common_binomial_factor(
    polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    variables: Sequence[str],
    max_factors: int = 8,
) -> MultivariateLaurentPolynomial | None:
    current = [polynomial.normalize_unit() for polynomial in polynomials]
    common = MultivariateLaurentPolynomial.constant(1, variables=variables)
    found_factor = False

    for _ in range(max_factors):
        candidates = _candidate_binomial_factors(current)
        factor = None
        quotients = None
        for candidate in candidates:
            divided = [_exact_multivariate_division(polynomial, candidate) for polynomial in current]
            if all(quotient is not None for quotient in divided):
                factor = candidate
                quotients = [
                    quotient.normalize_unit()
                    for quotient in divided
                    if quotient is not None
                ]
                break
        if factor is None or quotients is None:
            break
        common = (common * factor).normalize_unit()
        current = quotients
        found_factor = True
        if any(_is_unit_polynomial(polynomial) for polynomial in current):
            break

    if not found_factor or _is_unit_polynomial(common):
        return None
    return common.normalize_unit()


def _bounded_multivariate_common_root_binomial_factor(
    polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    variables: Sequence[str],
    max_factors: int = _BOUNDED_MULTIVARIATE_ROOT_BINOMIAL_MAX_FACTORS,
    max_candidates: int = _BOUNDED_MULTIVARIATE_ROOT_BINOMIAL_MAX_CANDIDATES,
) -> MultivariateLaurentPolynomial | None:
    current = [polynomial.normalize_unit() for polynomial in polynomials]
    common = MultivariateLaurentPolynomial.constant(1, variables=variables)
    found_factor = False

    for _ in range(max_factors):
        candidates = _candidate_root_binomial_factors(
            current,
            max_candidates=max_candidates,
        )
        factor = None
        quotients = None
        for candidate in candidates:
            divided = [
                _exact_multivariate_division(polynomial, candidate)
                for polynomial in current
            ]
            if all(quotient is not None for quotient in divided):
                factor = candidate
                quotients = [
                    quotient.normalize_unit()
                    for quotient in divided
                    if quotient is not None
                ]
                break
        if factor is None or quotients is None:
            break
        common = (common * factor).normalize_unit()
        current = quotients
        found_factor = True
        if any(_is_unit_polynomial(polynomial) for polynomial in current):
            break

    if not found_factor or _is_unit_polynomial(common):
        return None
    final_quotients = [
        _exact_multivariate_division(polynomial, common)
        for polynomial in polynomials
    ]
    if not all(quotient is not None for quotient in final_quotients):
        return None
    return common.normalize_unit()


def _bounded_multivariate_common_sparse_factor(
    polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    variables: Sequence[str],
    max_factor_terms: int = _BOUNDED_MULTIVARIATE_COMMON_GCD_MAX_TERMS,
    max_factors: int = _BOUNDED_MULTIVARIATE_SPARSE_FACTOR_MAX_FACTORS,
    max_candidates: int = _BOUNDED_MULTIVARIATE_SPARSE_FACTOR_MAX_CANDIDATES,
) -> MultivariateLaurentPolynomial | None:
    current = [polynomial.normalize_unit() for polynomial in polynomials]
    common = MultivariateLaurentPolynomial.constant(1, variables=variables)
    found_factor = False

    for _ in range(max_factors):
        candidates = _candidate_sparse_factors(
            current,
            max_factor_terms=max_factor_terms,
            max_candidates=max_candidates,
        )
        factor = None
        quotients = None
        for candidate in candidates:
            divided = [
                _exact_multivariate_division(polynomial, candidate)
                for polynomial in current
            ]
            if all(quotient is not None for quotient in divided):
                factor = candidate
                quotients = [
                    quotient.normalize_unit()
                    for quotient in divided
                    if quotient is not None
                ]
                break
        if factor is None or quotients is None:
            break
        common = (common * factor).normalize_unit()
        current = quotients
        found_factor = True
        if any(_is_unit_polynomial(polynomial) for polynomial in current):
            break

    if not found_factor or _is_unit_polynomial(common):
        return None
    final_quotients = [
        _exact_multivariate_division(polynomial, common)
        for polynomial in polynomials
    ]
    if not all(quotient is not None for quotient in final_quotients):
        return None
    return common.normalize_unit()


def _bounded_multivariate_common_cofactor_factor(
    polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    variables: Sequence[str],
    max_cofactor_terms: int = _BOUNDED_MULTIVARIATE_COMMON_GCD_MAX_TERMS,
    max_divisor_factors: int = _BOUNDED_MULTIVARIATE_COFACTOR_MAX_DIVISOR_FACTORS,
    max_candidates: int = _BOUNDED_MULTIVARIATE_COFACTOR_MAX_CANDIDATES,
) -> MultivariateLaurentPolynomial | None:
    candidates = _candidate_cofactor_factors(
        polynomials,
        max_cofactor_terms=max_cofactor_terms,
        max_divisor_factors=max_divisor_factors,
        max_candidates=max_candidates,
    )
    for candidate in candidates:
        divided = [
            _exact_multivariate_division(polynomial, candidate)
            for polynomial in polynomials
        ]
        if all(quotient is not None for quotient in divided):
            return candidate.normalize_unit()
    return None


def _optional_symbolic_common_laurent_gcd(
    polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    variables: Sequence[str],
) -> MultivariateLaurentPolynomial | None:
    if (
        len(variables) > _OPTIONAL_SYMBOLIC_MULTIVARIATE_GCD_MAX_VARIABLES
        or len(polynomials) > _OPTIONAL_SYMBOLIC_MULTIVARIATE_GCD_MAX_POLYNOMIALS
        or sum(len(polynomial.terms) for polynomial in polynomials)
        > _OPTIONAL_SYMBOLIC_MULTIVARIATE_GCD_MAX_TOTAL_TERMS
    ):
        return None
    try:
        import sympy as sympy  # type: ignore[import-not-found]
    except Exception:  # pragma: no cover - optional dependency boundary
        return None

    try:
        symbols = sympy.symbols(" ".join(variables))
        if not isinstance(symbols, tuple):
            symbols = (symbols,)
        sympy_polynomials = [
            _sympy_poly_from_laurent_polynomial(
                polynomial,
                symbols=symbols,
                sympy=sympy,
            )
            for polynomial in polynomials
        ]
        symbolic_gcd = sympy_polynomials[0]
        for polynomial in sympy_polynomials[1:]:
            symbolic_gcd = symbolic_gcd.gcd(polynomial)
        candidate = _multivariate_laurent_polynomial_from_sympy_poly(
            symbolic_gcd,
            variables=variables,
        ).normalize_unit()
    except Exception:  # pragma: no cover - optional symbolic backend guard
        return None

    if _is_unit_polynomial(candidate):
        return None
    if all(
        _exact_multivariate_division(polynomial, candidate) is not None
        for polynomial in polynomials
    ):
        return candidate
    return None


def _sympy_poly_from_laurent_polynomial(
    polynomial: MultivariateLaurentPolynomial,
    *,
    symbols: tuple[object, ...],
    sympy: object,
) -> object:
    normalized = polynomial.normalize_unit()
    terms = {
        exponents: sympy.Integer(coefficient)
        for exponents, coefficient in normalized.terms
    }
    return sympy.Poly.from_dict(terms, *symbols, domain=sympy.QQ)


def _multivariate_laurent_polynomial_from_sympy_poly(
    polynomial: object,
    *,
    variables: Sequence[str],
) -> MultivariateLaurentPolynomial:
    rational_terms: list[tuple[tuple[int, ...], int, int]] = []
    lcm_denominator = 1
    for monomial, coefficient in polynomial.terms():
        numerator, denominator = coefficient.as_numer_denom()
        denominator_int = abs(int(denominator))
        rational_terms.append(
            (
                tuple(int(exponent) for exponent in monomial),
                int(numerator),
                denominator_int,
            )
        )
        lcm_denominator = _lcm(lcm_denominator, denominator_int)

    integer_terms: dict[tuple[int, ...], int] = {}
    for exponents, numerator, denominator in rational_terms:
        integer_terms[exponents] = numerator * (lcm_denominator // denominator)

    content = 0
    for coefficient in integer_terms.values():
        content = gcd(content, abs(coefficient))
    if content > 1:
        integer_terms = {
            exponents: coefficient // content
            for exponents, coefficient in integer_terms.items()
        }
    return MultivariateLaurentPolynomial.from_dict(
        integer_terms,
        variables=tuple(variables),
    )


def _candidate_root_binomial_factors(
    polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    max_candidates: int,
) -> list[MultivariateLaurentPolynomial]:
    candidates: dict[str, MultivariateLaurentPolynomial] = {}
    for polynomial in sorted(
        (item for item in polynomials if not item.is_zero and len(item.terms) >= 2),
        key=lambda item: (len(item.terms), item.format()),
    ):
        for first_index, (first_exp, first_coeff) in enumerate(polynomial.terms):
            for second_exp, second_coeff in polynomial.terms[first_index + 1:]:
                delta = tuple(
                    first_value - second_value
                    for first_value, second_value in zip(first_exp, second_exp)
                )
                if all(value == 0 for value in delta):
                    continue
                root_content = 0
                for value in delta:
                    root_content = gcd(root_content, abs(value))
                if root_content <= 1:
                    continue
                for root_degree in _integer_divisors_greater_than_one(root_content):
                    first_root = _integer_nth_root(abs(first_coeff), root_degree)
                    second_root = _integer_nth_root(abs(second_coeff), root_degree)
                    if first_root is None or second_root is None:
                        continue
                    root_delta = tuple(value // root_degree for value in delta)
                    if all(value == 0 for value in root_delta):
                        continue
                    zero_exp = tuple(0 for _ in root_delta)
                    for first_root_coeff in _signed_integer_roots(first_root):
                        for second_root_coeff in _signed_integer_roots(second_root):
                            candidate = MultivariateLaurentPolynomial.from_dict(
                                {
                                    root_delta: first_root_coeff,
                                    zero_exp: second_root_coeff,
                                },
                                variables=polynomial.variables,
                            ).normalize_unit()
                            if len(candidate.terms) != 2 or _is_unit_polynomial(candidate):
                                continue
                            candidates[candidate.format()] = candidate
                            if len(candidates) >= max_candidates:
                                return [
                                    candidates[key]
                                    for key in sorted(candidates)
                                ]
    return [
        candidates[key]
        for key in sorted(candidates)
    ]


def _integer_divisors_greater_than_one(value: int) -> list[int]:
    return [divisor for divisor in range(2, value + 1) if value % divisor == 0]


def _integer_nth_root(value: int, degree: int) -> int | None:
    if value < 0 or degree <= 0:
        return None
    if value in (0, 1):
        return value
    low = 1
    high = value
    while low <= high:
        middle = (low + high) // 2
        powered = middle**degree
        if powered == value:
            return middle
        if powered < value:
            low = middle + 1
        else:
            high = middle - 1
    return None


def _signed_integer_roots(root: int) -> tuple[int, ...]:
    if root == 0:
        return (0,)
    return (-root, root)


def _candidate_sparse_factors(
    polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    max_factor_terms: int,
    max_candidates: int,
) -> list[MultivariateLaurentPolynomial]:
    candidates: dict[str, MultivariateLaurentPolynomial] = {}
    candidate_order: list[str] = []

    def record_candidate(
        term_subset: Sequence[tuple[tuple[int, ...], int]],
        *,
        variables: Sequence[str],
    ) -> bool:
        candidate = MultivariateLaurentPolynomial(
            tuple(term_subset),
            variables=variables,
        )
        candidate = _primitive_multivariate_polynomial(candidate).normalize_unit()
        if _is_unit_polynomial(candidate) or len(candidate.terms) < 3:
            return False
        key = candidate.format()
        if key not in candidates:
            candidates[key] = candidate
            candidate_order.append(key)
        return len(candidates) >= max_candidates

    for polynomial in sorted(
        (item for item in polynomials if not item.is_zero and len(item.terms) >= 3),
        key=lambda item: (len(item.terms), item.format()),
    ):
        max_size = min(max_factor_terms, len(polynomial.terms) - 1)
        for factor_size in range(max_size, 2, -1):
            priority_subsets = [
                polynomial.terms[:factor_size],
                polynomial.terms[-factor_size:],
            ]
            for term_subset in priority_subsets:
                if record_candidate(term_subset, variables=polynomial.variables):
                    return [candidates[key] for key in candidate_order]
        for factor_size in range(3, max_size + 1):
            for term_subset in combinations(polynomial.terms, factor_size):
                if record_candidate(term_subset, variables=polynomial.variables):
                    return [candidates[key] for key in candidate_order]
    return [candidates[key] for key in candidate_order]

def _candidate_cofactor_factors(
    polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    max_cofactor_terms: int,
    max_divisor_factors: int = _BOUNDED_MULTIVARIATE_COFACTOR_MAX_DIVISOR_FACTORS,
    max_candidates: int,
) -> list[MultivariateLaurentPolynomial]:
    candidates: dict[str, MultivariateLaurentPolynomial] = {}
    max_depth = max(1, max_divisor_factors)
    for polynomial in sorted(
        (item for item in polynomials if not item.is_zero and len(item.terms) >= 3),
        key=lambda item: (len(item.terms), item.format()),
    ):
        frontier = [polynomial.normalize_unit()]
        seen_remainders = {frontier[0].format()}
        for depth in range(max_depth):
            next_frontier: list[MultivariateLaurentPolynomial] = []
            for remainder in frontier:
                for divisor in _cofactor_small_divisor_candidates(
                    remainder,
                    max_candidates=max_candidates,
                ):
                    quotient = _exact_multivariate_division(remainder, divisor)
                    if quotient is None:
                        continue
                    quotient = quotient.normalize_unit()
                    candidate = _primitive_multivariate_polynomial(
                        quotient,
                    ).normalize_unit()
                    if (
                        not _is_unit_polynomial(candidate)
                        and 2 <= len(candidate.terms) <= max_cofactor_terms
                    ):
                        candidate_key = candidate.format()
                        if candidate_key not in candidates:
                            exact_candidate = _exact_common_cofactor_candidate(
                                candidate,
                                polynomials,
                                variables=polynomial.variables,
                            )
                            if exact_candidate is not None:
                                return [exact_candidate]
                            candidates[candidate_key] = candidate
                        if len(candidates) >= max_candidates:
                            return [
                                candidates[key]
                                for key in sorted(candidates)
                            ]
                    if depth + 1 >= max_depth:
                        continue
                    if _is_unit_polynomial(quotient) or len(quotient.terms) < 3:
                        continue
                    quotient_key = quotient.format()
                    if quotient_key in seen_remainders:
                        continue
                    seen_remainders.add(quotient_key)
                    next_frontier.append(quotient)
            frontier = sorted(
                next_frontier,
                key=lambda item: (len(item.terms), item.format()),
            )
            if not frontier:
                break
    return [
        candidates[key]
        for key in sorted(candidates)
    ]


def _exact_common_cofactor_candidate(
    candidate: MultivariateLaurentPolynomial,
    polynomials: Sequence[MultivariateLaurentPolynomial],
    *,
    variables: Sequence[str],
) -> MultivariateLaurentPolynomial | None:
    divided = [
        _exact_multivariate_division(polynomial, candidate)
        for polynomial in polynomials
    ]
    if not all(quotient is not None for quotient in divided):
        return None
    quotients = [
        quotient.normalize_unit()
        for quotient in divided
        if quotient is not None
    ]
    quotient_status = _quotient_common_factor_status(
        quotients,
        variables=variables,
    )
    if quotient_status.get("candidate_is_exact_gcd_for_inputs"):
        return candidate.normalize_unit()
    return None
def _cofactor_small_divisor_candidates(
    polynomial: MultivariateLaurentPolynomial,
    *,
    max_candidates: int,
) -> list[MultivariateLaurentPolynomial]:
    divisor_candidates: dict[str, MultivariateLaurentPolynomial] = {}
    candidate_order: list[str] = []

    def record(divisor: MultivariateLaurentPolynomial) -> None:
        key = divisor.format()
        if key not in divisor_candidates:
            divisor_candidates[key] = divisor
            candidate_order.append(key)

    for divisor in _candidate_sparse_factors(
        [polynomial],
        max_factor_terms=min(_BOUNDED_MULTIVARIATE_COMMON_GCD_MAX_TERMS, max(3, len(polynomial.terms) - 1)),
        max_candidates=max_candidates,
    ):
        record(divisor)
    for divisor in _candidate_binomial_factors([polynomial]):
        record(divisor)
    for divisor in _candidate_root_binomial_factors(
        [polynomial],
        max_candidates=max_candidates,
    ):
        record(divisor)
    return [
        divisor_candidates[key]
        for key in candidate_order
    ]
def _candidate_binomial_factors(
    polynomials: Sequence[MultivariateLaurentPolynomial],
) -> list[MultivariateLaurentPolynomial]:
    candidates: dict[str, MultivariateLaurentPolynomial] = {}
    for polynomial in sorted(
        (item for item in polynomials if not item.is_zero and len(item.terms) >= 2),
        key=lambda item: (len(item.terms), item.format()),
    ):
        for first_index, (first_exp, first_coeff) in enumerate(polynomial.terms):
            for second_exp, second_coeff in polynomial.terms[first_index + 1:]:
                candidate = MultivariateLaurentPolynomial(
                    (
                        (first_exp, first_coeff),
                        (second_exp, second_coeff),
                    ),
                    variables=polynomial.variables,
                )
                candidate = _primitive_multivariate_polynomial(candidate).normalize_unit()
                if len(candidate.terms) != 2 or _is_unit_polynomial(candidate):
                    continue
                candidates[candidate.format()] = candidate
    return [
        candidates[key]
        for key in sorted(candidates)
    ]


def _primitive_multivariate_polynomial(
    polynomial: MultivariateLaurentPolynomial,
) -> MultivariateLaurentPolynomial:
    if polynomial.is_zero:
        return polynomial
    content = 0
    for _, coefficient in polynomial.terms:
        content = gcd(content, abs(coefficient))
    if content <= 1:
        return polynomial
    return MultivariateLaurentPolynomial(
        tuple(
            (exponents, coefficient // content)
            for exponents, coefficient in polynomial.terms
        ),
        variables=polynomial.variables,
    )


def _exact_multivariate_division(
    dividend: MultivariateLaurentPolynomial,
    divisor: MultivariateLaurentPolynomial,
) -> MultivariateLaurentPolynomial | None:
    dividend._check_variables(divisor)
    dividend = dividend.normalize_unit()
    divisor = divisor.normalize_unit()
    if divisor.is_zero:
        raise ZeroDivisionError("polynomial division by zero")
    if dividend.is_zero:
        return MultivariateLaurentPolynomial.constant(0, variables=dividend.variables)
    if _is_unit_polynomial(divisor):
        return dividend

    remainder = {
        exponents: Fraction(coefficient)
        for exponents, coefficient in dividend.terms
    }
    divisor_terms = {
        exponents: Fraction(coefficient)
        for exponents, coefficient in divisor.terms
    }
    quotient: dict[tuple[int, ...], Fraction] = {}
    divisor_lead_exp, divisor_lead_coeff = _leading_fraction_term(divisor_terms)

    while remainder:
        remainder_lead_exp, remainder_lead_coeff = _leading_fraction_term(remainder)
        exponent_delta = tuple(
            remainder_exp - divisor_exp
            for remainder_exp, divisor_exp in zip(remainder_lead_exp, divisor_lead_exp)
        )
        if any(exponent < 0 for exponent in exponent_delta):
            return None
        coefficient_delta = remainder_lead_coeff / divisor_lead_coeff
        quotient[exponent_delta] = quotient.get(exponent_delta, Fraction(0)) + coefficient_delta
        for divisor_exp, divisor_coeff in divisor_terms.items():
            shifted_exp = tuple(
                exponent + shift
                for exponent, shift in zip(divisor_exp, exponent_delta)
            )
            remainder[shifted_exp] = remainder.get(shifted_exp, Fraction(0)) - (
                coefficient_delta * divisor_coeff
            )
            if remainder[shifted_exp] == 0:
                del remainder[shifted_exp]

    integer_terms: dict[tuple[int, ...], int] = {}
    for exponents, coefficient in quotient.items():
        if coefficient.denominator != 1:
            return None
        integer_terms[exponents] = int(coefficient)
    return MultivariateLaurentPolynomial.from_dict(
        integer_terms,
        variables=dividend.variables,
    )


def _leading_fraction_term(
    terms: dict[tuple[int, ...], Fraction],
) -> tuple[tuple[int, ...], Fraction]:
    exponent = max(terms)
    return exponent, terms[exponent]


def _as_univariate_terms(
    polynomial: MultivariateLaurentPolynomial,
    *,
    variable_index: int,
) -> dict[int, int]:
    terms: dict[int, int] = {}
    for exponents, coefficient in polynomial.terms:
        if any(
            exponent != 0
            for index, exponent in enumerate(exponents)
            if index != variable_index
        ):
            raise ValueError("polynomial contains more than one variable")
        terms[exponents[variable_index]] = terms.get(exponents[variable_index], 0) + coefficient
    return {exponent: coefficient for exponent, coefficient in terms.items() if coefficient}


def _univariate_terms_to_multivariate(
    terms: dict[int, int],
    *,
    variable_index: int,
    variables: Sequence[str],
) -> MultivariateLaurentPolynomial:
    variable_count = len(variables)
    multivariate_terms: dict[tuple[int, ...], int] = {}
    for exponent, coefficient in terms.items():
        exponents = [0] * variable_count
        exponents[variable_index] = exponent
        multivariate_terms[tuple(exponents)] = coefficient
    return MultivariateLaurentPolynomial.from_dict(
        multivariate_terms,
        variables=tuple(variables),
    )


def _univariate_integer_gcd(polynomials: Sequence[dict[int, int]]) -> dict[int, int]:
    if not polynomials:
        return {0: 1}
    gcd_coefficients = _fraction_polynomial_from_terms(polynomials[0])
    for polynomial in polynomials[1:]:
        gcd_coefficients = _fraction_polynomial_gcd(
            gcd_coefficients,
            _fraction_polynomial_from_terms(polynomial),
        )
    return _integer_terms_from_fraction_polynomial(gcd_coefficients)


def _fraction_polynomial_from_terms(terms: dict[int, int]) -> list[Fraction]:
    if not terms:
        return []
    min_exponent = min(terms)
    if min_exponent < 0:
        terms = {exponent - min_exponent: coefficient for exponent, coefficient in terms.items()}
    degree = max(terms)
    coefficients = [Fraction(0) for _ in range(degree + 1)]
    for exponent, coefficient in terms.items():
        coefficients[exponent] = Fraction(coefficient)
    return _trim_fraction_polynomial(coefficients)


def _fraction_polynomial_gcd(
    left: list[Fraction],
    right: list[Fraction],
) -> list[Fraction]:
    left = _monic_fraction_polynomial(left)
    right = _monic_fraction_polynomial(right)
    while right:
        _, remainder = _fraction_polynomial_divmod(left, right)
        left, right = right, _monic_fraction_polynomial(remainder)
    return _monic_fraction_polynomial(left)


def _fraction_polynomial_divmod(
    numerator: list[Fraction],
    denominator: list[Fraction],
) -> tuple[list[Fraction], list[Fraction]]:
    numerator = _trim_fraction_polynomial(numerator)
    denominator = _trim_fraction_polynomial(denominator)
    if not denominator:
        raise ZeroDivisionError("polynomial division by zero")
    if len(numerator) < len(denominator):
        return [], numerator

    quotient = [Fraction(0) for _ in range(len(numerator) - len(denominator) + 1)]
    remainder = numerator[:]
    denominator_degree = len(denominator) - 1
    denominator_lead = denominator[-1]
    while remainder and len(remainder) >= len(denominator):
        degree_shift = len(remainder) - len(denominator)
        factor = remainder[-1] / denominator_lead
        quotient[degree_shift] = factor
        for index in range(denominator_degree + 1):
            remainder[degree_shift + index] -= factor * denominator[index]
        remainder = _trim_fraction_polynomial(remainder)
    return _trim_fraction_polynomial(quotient), remainder


def _monic_fraction_polynomial(coefficients: list[Fraction]) -> list[Fraction]:
    coefficients = _trim_fraction_polynomial(coefficients)
    if not coefficients:
        return []
    leading = coefficients[-1]
    return _trim_fraction_polynomial([coefficient / leading for coefficient in coefficients])


def _trim_fraction_polynomial(coefficients: list[Fraction]) -> list[Fraction]:
    trimmed = coefficients[:]
    while trimmed and trimmed[-1] == 0:
        trimmed.pop()
    return trimmed


def _integer_terms_from_fraction_polynomial(coefficients: list[Fraction]) -> dict[int, int]:
    coefficients = _trim_fraction_polynomial(coefficients)
    if not coefficients:
        return {}
    lcm_denominator = 1
    for coefficient in coefficients:
        lcm_denominator = _lcm(lcm_denominator, coefficient.denominator)
    integer_coefficients = [
        int(coefficient * lcm_denominator)
        for coefficient in coefficients
    ]
    content = 0
    for coefficient in integer_coefficients:
        content = gcd(content, abs(coefficient))
    if content:
        integer_coefficients = [coefficient // content for coefficient in integer_coefficients]
    if integer_coefficients and integer_coefficients[-1] < 0:
        integer_coefficients = [-coefficient for coefficient in integer_coefficients]
    return {
        exponent: coefficient
        for exponent, coefficient in enumerate(integer_coefficients)
        if coefficient
    }


def _lcm(left: int, right: int) -> int:
    if left == 0 or right == 0:
        return 0
    return abs(left * right) // gcd(left, right)


def _fixture_alexander_variables(fixture) -> tuple[str, ...]:
    explicit = fixture.expected_multivariable_alexander_variables
    if explicit is not None:
        return tuple(explicit)
    if fixture.component_count <= 1:
        return ("t",)
    return tuple(f"t{index + 1}" for index in range(fixture.component_count))


def _fixture_source_orientation_diagnostics(fixture) -> dict:
    if not getattr(fixture, "has_pd_code", False):
        return {
            "method": "fixture_source_orientation_diagnostics",
            "skipped": True,
            "has_pd_code": False,
            "has_gauss_code": False,
            "gauss_code_matched": False,
            "gauss_code_orientation_diagnostics": None,
            "notes": ["fixture does not have a PD source record"],
        }
    if fixture.gauss_code is None:
        return {
            "method": "fixture_source_orientation_diagnostics",
            "skipped": True,
            "has_pd_code": True,
            "has_gauss_code": False,
            "gauss_code_matched": False,
            "gauss_code_orientation_diagnostics": None,
            "notes": [
                "fixture has a PD source record but no source Gauss code to constrain orientation",
            ],
        }

    gauss = fixture.gauss_code_orientation_diagnostics(
        max_orientation_samples=64,
        max_matches=4,
    )
    return {
        "method": "fixture_source_orientation_diagnostics",
        "skipped": False,
        "has_pd_code": True,
        "has_gauss_code": True,
        "gauss_code_matched": bool(gauss["matched"]),
        "gauss_code_orientation_diagnostics": gauss,
        "notes": [
            "source Gauss-code orientation evidence is available",
            "crossing signs and expected multi-variable Alexander value are still not registered",
        ]
        if gauss["matched"]
        else [
            "source Gauss code is registered but no sampled local role assignment matched it",
            "crossing signs and expected multi-variable Alexander value are still not registered",
        ],
    }


def _default_alexander_minor_size(presentation: WirtingerPresentation) -> int:
    return max(0, min(len(presentation.relations), len(presentation.generator_components)) - 1)


def _wirtinger_generators_from_orientation(
    diagram: PlanarDiagram,
    orientation: PDOrientation,
) -> tuple[dict[int, int], tuple[int, ...]]:
    edge_labels = diagram.edge_labels
    traversals = orientation.oriented_component_traversals(diagram)
    cycle_count = len(traversals)
    if (
        diagram.component_count is not None
        and cycle_count != diagram.component_count
    ):
        raise ValueError(
            "orientation component cycle count must match diagram.component_count; "
            f"inferred {cycle_count}, expected {diagram.component_count}"
        )

    declared_components = dict(orientation.edge_components)
    edge_components: dict[int, int] = {}
    if cycle_count == 1:
        declared_values = {
            declared_components[label]
            for label in traversals[0]["edges"]
            if label in declared_components
        }
        if declared_values and declared_values != {0}:
            raise ValueError(
                "single orientation component cycle must use component id 0"
            )
        edge_components.update(
            (int(label), 0) for label in traversals[0]["edges"]
        )
    elif cycle_count > 1 and not declared_components:
        for component, traversal in enumerate(traversals):
            edge_components.update(
                (int(label), component) for label in traversal["edges"]
            )
    elif cycle_count > 1:
        missing_labels = sorted(set(edge_labels) - set(declared_components))
        if missing_labels:
            raise ValueError(
                "multi-component Wirtinger conversion requires a complete "
                f"edge-component map; missing {missing_labels}"
            )
        cycle_components = []
        for traversal in traversals:
            values = {
                declared_components[int(label)]
                for label in traversal["edges"]
            }
            if len(values) != 1:
                raise ValueError(
                    "each orientation component cycle must have exactly one "
                    "component id"
                )
            cycle_components.append(next(iter(values)))
        expected_components = list(range(cycle_count))
        if sorted(cycle_components) != expected_components:
            raise ValueError(
                "orientation component cycles must use unique contiguous "
                f"component ids {expected_components}; observed "
                f"{sorted(cycle_components)}"
            )
        for traversal, component in zip(traversals, cycle_components):
            edge_components.update(
                (int(label), component) for label in traversal["edges"]
            )

    parents = {label: label for label in edge_labels}

    def find(label: int) -> int:
        if parents[label] != label:
            parents[label] = find(parents[label])
        return parents[label]

    def union(first: int, second: int) -> None:
        first_root = find(first)
        second_root = find(second)
        if first_root != second_root:
            parents[second_root] = first_root

    for crossing_orientation in orientation.crossings:
        union(crossing_orientation.over_in, crossing_orientation.over_out)

    roots = sorted({find(label) for label in edge_labels})
    root_to_generator = {root: index for index, root in enumerate(roots)}
    edge_to_generator = {
        label: root_to_generator[find(label)]
        for label in edge_labels
    }

    generator_component_map: dict[int, int] = {}
    for label, generator in edge_to_generator.items():
        component = edge_components[label]
        existing = generator_component_map.get(generator)
        if existing is not None and existing != component:
            raise ValueError(
                "over-strand Wirtinger generator contains edges from different components"
            )
        generator_component_map[generator] = component
    return (
        edge_to_generator,
        tuple(generator_component_map[index] for index in range(len(roots))),
    )


def _oriented_pd_represented_component_ids(
    diagram: PlanarDiagram,
    orientation: PDOrientation,
    *,
    traversals: Sequence[Mapping[str, object]] | None = None,
) -> tuple[int, ...]:
    """Validate component ids on crossing-bearing oriented PD cycles.

    Free circles have no PD edge labels.  Therefore the represented cycle ids
    need only be a unique subset of ``range(component_count)``; they need not
    start at zero or be consecutive.  This deliberately differs from the
    ordinary all-components-represented Wirtinger bridge.
    """

    issues = orientation.validation_issues(diagram)
    declared_components = dict(orientation.edge_components)
    only_missing_component_map_issue = bool(
        issues
        and all(
            issue.startswith(
                "edge_components must include every edge label for "
                "multi-component diagrams"
            )
            for issue in issues
        )
    )
    if issues and not (not declared_components and only_missing_component_map_issue):
        raise ValueError("; ".join(issues))
    effective_traversals = tuple(
        traversals
        if traversals is not None
        else orientation.oriented_component_traversals(diagram)
    )
    if diagram.crossing_count > 0 and not effective_traversals:
        raise ValueError("nonzero signed PD must represent at least one component cycle")

    represented = []
    for traversal_index, traversal in enumerate(effective_traversals):
        edges = tuple(int(label) for label in traversal.get("edges", []))
        if not declared_components:
            represented.append(traversal_index)
            continue
        missing = sorted(set(edges) - set(declared_components))
        if missing:
            raise ValueError(
                "free-component exact normalization requires a complete "
                f"edge-component map; missing {missing}"
            )
        component_values = {declared_components[label] for label in edges}
        if len(component_values) != 1:
            raise ValueError(
                "each represented orientation component cycle must have "
                "exactly one explicit component id"
            )
        represented.append(next(iter(component_values)))

    component_count = diagram.component_count
    if component_count is None or component_count < 1:
        raise ValueError(
            "free-component exact normalization requires a positive explicit "
            "component_count"
        )
    out_of_range = sorted(
        component
        for component in represented
        if component < 0 or component >= component_count
    )
    if out_of_range:
        raise ValueError(
            "represented component ids must be in component_count range; "
            f"observed {out_of_range}"
        )
    if len(set(represented)) != len(represented):
        raise ValueError(
            "represented orientation component cycles must use unique explicit "
            f"component ids; observed {sorted(represented)}"
        )
    return tuple(sorted(represented))


def multivariate_laurent_determinant(
    matrix: Sequence[Sequence[MultivariateLaurentPolynomial]],
    *,
    variables: Iterable[str],
) -> MultivariateLaurentPolynomial:
    variables_tuple = tuple(variables)
    size = len(matrix)
    if size == 0:
        return MultivariateLaurentPolynomial.constant(1, variables=variables_tuple)
    if any(len(row) != size for row in matrix):
        raise ValueError("determinant requires a square matrix")
    if size == 1:
        return matrix[0][0]

    total = MultivariateLaurentPolynomial.constant(0, variables=variables_tuple)
    for column, entry in enumerate(matrix[0]):
        cofactor = multivariate_laurent_determinant(
            [
                [value for value_index, value in enumerate(row) if value_index != column]
                for row in matrix[1:]
            ],
            variables=variables_tuple,
        )
        term = entry * cofactor
        total = total + (term.scale(-1) if column % 2 else term)
    return total


def _remove_row_column(
    matrix: Sequence[Sequence[MultivariateLaurentPolynomial]],
    *,
    remove_row: int | None,
    remove_column: int,
) -> list[list[MultivariateLaurentPolynomial]]:
    if matrix and (remove_column < 0 or remove_column >= len(matrix[0])):
        raise IndexError("remove_column out of range")
    if remove_row is not None and (remove_row < 0 or remove_row >= len(matrix)):
        raise IndexError("remove_row out of range")

    rows = [
        row
        for row_index, row in enumerate(matrix)
        if remove_row is None or row_index != remove_row
    ]
    return [
        [entry for column_index, entry in enumerate(row) if column_index != remove_column]
        for row in rows
    ]


def _variables_for_components(
    generator_components: Sequence[int],
    variables: Iterable[str] | None,
) -> tuple[str, ...]:
    if not generator_components:
        raise ValueError("generator_components must not be empty")
    if any(component < 0 for component in generator_components):
        raise ValueError("component indices must be non-negative")
    component_count = max(generator_components) + 1
    if variables is None:
        return tuple(f"t{index + 1}" for index in range(component_count))
    variables_tuple = tuple(variables)
    if len(variables_tuple) != component_count:
        raise ValueError("variables length must match component count")
    return variables_tuple


def _validate_word_term(
    generator: int,
    exponent: int,
    generator_components: Sequence[int],
) -> None:
    if generator < 0 or generator >= len(generator_components):
        raise ValueError("word generator index out of range")
    if exponent not in {-1, 1}:
        raise ValueError("Fox word exponents must be +1 or -1")


def _generator_monomial(
    generator: int,
    exponent: int,
    *,
    generator_components: Sequence[int],
    variables: tuple[str, ...],
) -> MultivariateLaurentPolynomial:
    component = generator_components[generator]
    exponents = [0] * len(variables)
    exponents[component] = exponent
    return MultivariateLaurentPolynomial.monomial(1, exponents, variables=variables)
