"""Linking number utilities."""

from __future__ import annotations

from collections import Counter

import numpy as np
from numpy.typing import ArrayLike

from iroll.core.curve import Polyline3D
from iroll.core.link import Link3D
from iroll.kernels import compute_gaussian_linking_number
from iroll.topology.crossings import find_link_crossings


def linking_number(
    component_a: Polyline3D,
    component_b: Polyline3D,
    *,
    direction: ArrayLike | None = None,
    method: str = "crossing",
    backend: str = "auto",
) -> float:
    if method == "gaussian":
        return compute_gaussian_linking_number(
            component_a.points,
            component_b.points,
            closed_a=component_a.closed,
            closed_b=component_b.closed,
            backend=backend,
        )
    if method != "crossing":
        raise ValueError("method must be 'crossing' or 'gaussian'")
    if not (component_a.closed and component_b.closed):
        raise ValueError("crossing linking number requires closed components")

    if direction is None:
        return _auto_crossing_linking_number(component_a, component_b)
    return _crossing_linking_number(component_a, component_b, direction=direction)


def _crossing_linking_number(
    component_a: Polyline3D,
    component_b: Polyline3D,
    *,
    direction: ArrayLike,
) -> float:
    link = Link3D([component_a, component_b])
    crossings = find_link_crossings(link, direction=direction)
    inter_component_signs = [
        crossing.sign
        for crossing in crossings
        if crossing.component_a != crossing.component_b
    ]
    return float(sum(inter_component_signs) / 2.0)


def _auto_crossing_linking_number(component_a: Polyline3D, component_b: Polyline3D) -> float:
    candidates = [
        [0.3, 0.5, 1.0],
        [1.0, 0.0, 1.0],
        [1.0, -0.25, 0.75],
        [-0.5, 1.0, 0.75],
        [0.75, 1.0, -0.5],
        [1.0, 1.0, 1.0],
        [0.0, 0.0, 1.0],
        [0.0, 1.0, 0.0],
        [1.0, 0.0, 0.0],
    ]
    integer_values: list[int] = []
    fallback_values: list[float] = []
    for candidate in candidates:
        value = _crossing_linking_number(component_a, component_b, direction=candidate)
        fallback_values.append(value)
        rounded = round(value)
        if abs(value - rounded) < 1e-9:
            integer_values.append(int(rounded))

    nonzero = [value for value in integer_values if value != 0]
    if nonzero:
        return float(Counter(nonzero).most_common(1)[0][0])
    if integer_values:
        return float(Counter(integer_values).most_common(1)[0][0])
    return float(fallback_values[0] if fallback_values else 0.0)


def linking_matrix(
    link: Link3D,
    *,
    direction: ArrayLike | None = None,
    method: str = "crossing",
    backend: str = "auto",
) -> np.ndarray:
    matrix = np.zeros((link.component_count, link.component_count), dtype=np.float64)
    for i in range(link.component_count):
        for j in range(i + 1, link.component_count):
            value = linking_number(
                link.components[i],
                link.components[j],
                direction=direction,
                method=method,
                backend=backend,
            )
            matrix[i, j] = value
            matrix[j, i] = value
    return matrix
