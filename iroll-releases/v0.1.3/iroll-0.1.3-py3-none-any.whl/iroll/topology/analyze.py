"""High-level analysis helpers."""

from __future__ import annotations

from numpy.typing import ArrayLike

from iroll.adapters import AdapterUnavailableError, classify_with_adapter
from iroll.core.curve import Polyline3D
from iroll.core.link import Link3D
from iroll.core.ribbon import Ribbon3D
from iroll.kernels import compute_writhe
from iroll.topology.classify import (
    classify_curve,
    classify_link,
    classify_curve_multi_projection,
    classify_open_curve,
)
from iroll.topology.contacts import (
    find_curve_contacts,
    find_link_contacts,
    summarize_contacts,
)
from iroll.topology.crossings import find_curve_crossings, find_link_crossings
from iroll.topology.diagram import build_knot_diagram
from iroll.topology.localization import scan_subchains, summarize_subchains
from iroll.topology.linking import linking_matrix


def analyze_curve(
    curve: Polyline3D,
    *,
    closure: dict | str | None = None,
    direction: ArrayLike | None = None,
    backend: str = "auto",
    contact_threshold: float | None = None,
    max_contacts: int = 100,
    include_diagram_matrix: bool = False,
    subchain_window_points: int | None = None,
    subchain_step: int = 1,
    subchain_max_windows: int | None = 200,
    adapter: str | None = None,
) -> dict:
    projection_vote = None
    if curve.closed and direction is None:
        vote = classify_curve_multi_projection(curve)
        classification_result = vote.selected
        projection_vote = vote.to_dict()
    else:
        classification_result = classify_curve(curve, direction=direction)
    effective_direction = direction
    if (
        curve.closed
        and effective_direction is None
        and classification_result.projection_direction is not None
    ):
        effective_direction = classification_result.projection_direction
    crossings = find_curve_crossings(curve, direction=effective_direction)
    classification = classification_result.to_dict()
    diagram = (
        build_knot_diagram(crossings).to_dict(include_matrix=include_diagram_matrix)
        if curve.closed
        else None
    )
    closure_report = None
    if not curve.closed and closure is not None:
        closure_report = classify_open_curve(curve, closure=closure, direction=direction)
        classification = {
            "knot_type": closure_report["dominant_knot_type"],
            "notation": None,
            "method": f"closure:{closure_report['method']}",
            "confidence": closure_report["confidence"],
            "crossing_count": None,
            "determinant": None,
            "projection_direction": None,
            "notes": [
                "open curves do not have a single absolute classical knot type",
                "classification summarizes closed samples from the selected closure method",
            ],
        }
    contacts = None
    if contact_threshold is not None:
        contacts = summarize_contacts(
            find_curve_contacts(
                curve,
                threshold=contact_threshold,
                max_contacts=max_contacts,
                backend=backend,
            ),
            threshold=contact_threshold,
        )
    subchains = None
    if subchain_window_points is not None:
        subchain_results = scan_subchains(
            curve,
            window_points=subchain_window_points,
            step=subchain_step,
            closure=closure,
            direction=direction,
            max_windows=subchain_max_windows,
        )
        subchains = summarize_subchains(
            subchain_results,
            window_points=subchain_window_points,
            step=subchain_step,
            max_windows=subchain_max_windows,
        )
    adapter_report = None
    if adapter is not None:
        try:
            adapter_report = classify_with_adapter(curve, adapter=adapter)
        except AdapterUnavailableError as exc:
            adapter_report = {
                "adapter": adapter,
                "available": False,
                "error": str(exc),
            }
    geometry = _geometry_summary_with_points(curve)
    geometry["components"] = [_component_geometry(curve)]
    return {
        "input": {
            "name": curve.name,
            "closed": curve.closed,
            "point_count": curve.point_count,
        },
        "geometry": geometry,
        "topology": {
            "writhe": compute_writhe(curve.points, closed=curve.closed, backend=backend),
            "crossing_count": len(crossings),
            "crossings": [crossing.to_dict() for crossing in crossings],
            "diagram": diagram,
            "classification": classification,
            "projection_vote": projection_vote,
            "closure": closure_report,
            "contacts": contacts,
            "subchains": subchains,
            "external_adapter": adapter_report,
        },
        "warnings": [],
        "runtime": {
            "requested_backend": backend,
        },
        "version": "0.1.0",
    }


def analyze_link(
    link: Link3D,
    *,
    direction: ArrayLike | None = None,
    backend: str = "auto",
    contact_threshold: float | None = None,
    max_contacts: int = 100,
) -> dict:
    crossings = find_link_crossings(link, direction=direction)
    matrix_array = None
    matrix = None
    warnings: list[str] = []
    if link.all_closed:
        matrix_array = linking_matrix(link, direction=direction, backend=backend)
        matrix = matrix_array.tolist()
    else:
        warnings.append("linking_matrix is only computed by default for closed components")
    classification = classify_link(
        link,
        direction=direction,
        backend=backend,
        linking_matrix_values=matrix_array,
    )
    contacts = None
    if contact_threshold is not None:
        contacts = summarize_contacts(
            find_link_contacts(
                link,
                threshold=contact_threshold,
                max_contacts=max_contacts,
                backend=backend,
            ),
            threshold=contact_threshold,
        )

    components = [_component_geometry(component) for component in link.components]
    return {
        "input": {
            "name": link.name,
            "component_count": link.component_count,
            "component_names": link.component_names(),
        },
        "components": components,
        "geometry": {
            "name": link.name,
            "component_count": link.component_count,
            "components": components,
        },
        "topology": {
            "crossing_count": len(crossings),
            "crossings": [crossing.to_dict() for crossing in crossings],
            "linking_matrix": matrix,
            "classification": classification.to_dict(),
            "component_reports": classification.component_reports or [],
            "link_type": classification.link_type,
            "contacts": contacts,
        },
        "warnings": warnings,
        "runtime": {
            "requested_backend": backend,
        },
        "version": "0.1.0",
    }


def analyze_ribbon(
    ribbon: Ribbon3D,
    *,
    backend: str = "auto",
    contact_threshold: float | None = None,
    max_contacts: int = 100,
) -> dict:
    writhe = compute_writhe(
        ribbon.centerline.points,
        closed=ribbon.closed,
        backend=backend,
    )
    twist = ribbon.twist()
    contacts = None
    if contact_threshold is not None:
        contacts = summarize_contacts(
            find_curve_contacts(
                ribbon.centerline,
                threshold=contact_threshold,
                max_contacts=max_contacts,
                backend=backend,
            ),
            threshold=contact_threshold,
        )
    centerline = _component_geometry(ribbon.centerline, name=ribbon.name)
    return {
        "input": {
            "name": ribbon.name,
            "closed": ribbon.closed,
            "point_count": ribbon.point_count,
        },
        "centerline": centerline,
        "geometry": {
            "name": ribbon.name,
            "component_count": 1,
            "components": [centerline],
            "directors": ribbon.directors.tolist(),
        },
        "topology": {
            "writhe": writhe,
            "twist": twist,
            "linking_estimate": writhe + twist,
            "twist_method": "discrete_director_rotation",
            "contacts": contacts,
        },
        "warnings": [
            "twist is a discrete director-rotation approximation",
            "linking_estimate is Tw + Wr and is not rounded to an integer",
        ],
        "runtime": {
            "requested_backend": backend,
        },
        "version": "0.1.0",
    }


def _geometry_summary_with_points(curve: Polyline3D) -> dict:
    summary = curve.geometry_summary()
    summary["points"] = curve.points.tolist()
    return summary


def _component_geometry(curve: Polyline3D, *, name: str | None = None) -> dict:
    summary = _geometry_summary_with_points(curve)
    if name is not None:
        summary["name"] = name
    return summary
