"""Replayable full-normalization certification for the supported Alexander corpus.

The ordinary Alexander helpers deliberately label capped scans as bounded.
This module exercises the uncapped exact path: every maximal
``(g-1) x (g-1)`` Fox minor is present, the reported candidate divides every
nonzero minor, and the quotient family has gcd one over ``ZZ`` (or the complete
family certifies the zero ideal).  Crossingless inputs use the same replayable
exact entry point and its explicit unlink-normalization terminal.  The retained
fixture corpus is regression/source evidence for that general finite-input
algorithm, not the reason the algorithm is called exact.
"""

from __future__ import annotations

from copy import deepcopy
from hashlib import sha256
import json
from math import comb
import re
from typing import Any, Mapping, Sequence
from urllib.parse import urlencode

from iroll.topology.multivariable_alexander import (
    multivariable_alexander_exact_from_oriented_pd,
    multivariable_alexander_exact_result_audit,
    multivariable_alexander_wirtinger_fox_audit,
)
from iroll.topology.pd import (
    PDCrossingOrientation,
    PDOrientation,
    build_planar_diagram,
)
from iroll.topology.pd_fixtures import (
    get_diagram_fixture,
    verified_signed_crossing_assignment_audit,
)
from iroll.topology.polynomial import parse_multivariate_laurent_polynomial


FULL_ALEXANDER_REQUIRED_NOTATIONS = (
    "0_1",
    "L0a1",
    "L2a1",
    "3_1",
    "4_1",
    "L5a1",
    "L6a4",
)
FULL_ALEXANDER_VERIFIED_ASSIGNMENT_NOTATIONS = ("L5a1", "L6a4")

def _raw_revision_url(title: str, revision_id: int) -> str:
    return "https://katlas.org/index.php?" + urlencode(
        {"title": title, "oldid": revision_id, "action": "raw"}
    )


_PINNED_SOURCES = {
    "L5a1": {
        "data": {
            "title": "Data:L5a1/Multivariable Alexander",
            "revision_id": 1692217,
            "sha256": (
                "20daa3f2b5af9ddfd7b70046e53d95f618eb86949cf634d162805236070580c3"
            ),
            "expected_math_source": (
                r"<math>\frac{(u-1)(v-1)}{\sqrt{u}\sqrt{v}}</math>"
            ),
            "expected_fixture_value": "(u - 1)*(v - 1)/(sqrt(u)*sqrt(v))",
        },
        "page": {
            "title": "L5a1",
            "revision_id": 110430,
            "url": "https://katlas.org/wiki/L5a1?oldid=110430&action=raw",
            "sha256": (
                "114ca16ef2893b2c4475d490ac702b49e2b9f994dfc1faa3538ae4feaf13f87d"
            ),
        },
    },
    "L6a4": {
        "data": {
            "title": "Data:L6a4/Multivariable Alexander",
            "revision_id": 1693896,
            "sha256": (
                "2458f37aee2f3727dac33fde8fa2ba9d88a31142960e600fd47e90d08e289011"
            ),
            "expected_math_source": (
                r"<math>\frac{(u-1)(v-1)(w-1)}"
                r"{\sqrt{u}\sqrt{v}\sqrt{w}}</math>"
            ),
            "expected_fixture_value": (
                "(u - 1)*(v - 1)*(w - 1)/(sqrt(u)*sqrt(v)*sqrt(w))"
            ),
        },
        "page": {
            "title": "L6a4",
            "revision_id": 1693878,
            "url": "https://katlas.org/wiki/L6a4?oldid=1693878&action=raw",
            "sha256": (
                "f0f9b96639bc1f85914c62830f6b99a6011c4c8e364573333f7f040b69a71768"
            ),
        },
    },
}

for _notation, _records in _PINNED_SOURCES.items():
    _data = _records["data"]
    _data["url"] = _raw_revision_url(
        str(_data["title"]), int(_data["revision_id"])
    )


def full_alexander_pinned_sources() -> dict[str, dict[str, dict[str, Any]]]:
    """Return the immutable source declarations used by the producer/auditor."""

    return deepcopy(_PINNED_SOURCES)


def canonical_json_sha256(value: Any) -> str:
    """Hash a JSON value with the canonical encoding used by evidence replay."""

    payload = json.dumps(
        value,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return sha256(payload).hexdigest()


def serialized_certification_report_sha256(value: Any) -> str:
    """Hash the producer's deterministic indented UTF-8/LF report bytes."""

    payload = (
        json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    ).encode("utf-8")
    return sha256(payload).hexdigest()


def _normalized_polynomial(polynomial: str, variables: Sequence[str]) -> str:
    return parse_multivariate_laurent_polynomial(
        polynomial,
        variables=tuple(variables),
    ).normalize_unit().format()


def _assignment_map(
    assignments: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, Mapping[str, Any]], list[str]]:
    result: dict[str, Mapping[str, Any]] = {}
    duplicates: list[str] = []
    for assignment in assignments:
        notation = str(assignment.get("notation") or "")
        if not notation:
            continue
        if notation in result:
            duplicates.append(notation)
        result[notation] = assignment
    return result, sorted(set(duplicates))


def _source_witness_public_row(
    notation: str,
    witness: Mapping[str, Any] | None,
) -> dict[str, Any]:
    declaration = _PINNED_SOURCES[notation]["data"]
    source = dict(witness or {})
    content = str(source.pop("_content", "") or "")
    expected_math = re.sub(
        r"\s+", "", str(declaration["expected_math_source"])
    )
    actual_math = re.sub(r"\s+", "", content)
    fixture = get_diagram_fixture(notation)
    return {
        "notation": notation,
        "role": "multivariable_alexander",
        "title": declaration["title"],
        "revision_id": declaration["revision_id"],
        "url": declaration["url"],
        "expected_sha256": declaration["sha256"],
        "actual_sha256": str(source.get("actual_sha256") or ""),
        "byte_count": int(source.get("byte_count") or 0),
        "fetched": source.get("fetched") is True,
        "sha256_verified": (
            source.get("sha256_verified") is True
            and source.get("actual_sha256") == declaration["sha256"]
        ),
        "source_math_matches_pinned_declaration": (
            bool(expected_math) and actual_math == expected_math
        ),
        "fixture_value_matches_pinned_declaration": (
            fixture.source_table_multivariable_alexander
            == declaration["expected_fixture_value"]
        ),
        "error": source.get("error"),
    }


def _case_expected_polynomial(notation: str) -> tuple[str, tuple[str, ...]]:
    fixture = get_diagram_fixture(notation)
    if notation in FULL_ALEXANDER_VERIFIED_ASSIGNMENT_NOTATIONS:
        polynomial = fixture.source_table_multivariable_alexander_numerator
        variables = fixture.source_table_multivariable_alexander_variables
    else:
        polynomial = fixture.expected_multivariable_alexander
        variables = fixture.expected_multivariable_alexander_variables
    if polynomial is None or variables is None:
        raise ValueError(f"fixture {notation} lacks Alexander expectation metadata")
    return polynomial, tuple(variables)


def _compute_case(
    notation: str,
    assignment: Mapping[str, Any] | None,
) -> dict[str, Any]:
    fixture = get_diagram_fixture(notation)
    expected_polynomial, variables = _case_expected_polynomial(notation)
    assignment_audit: dict[str, Any] | None = None

    if not fixture.pd_code:
        diagram = fixture.diagram()
        orientation = PDOrientation(())
        orientation_issue_count = len(orientation.validation_issues(diagram))
        result = multivariable_alexander_exact_from_oriented_pd(
            diagram,
            orientation,
            variables=variables,
        )
        assignment_source = "exact_zero_crossing_fixture_terminal"
    elif notation in FULL_ALEXANDER_VERIFIED_ASSIGNMENT_NOTATIONS:
        if not isinstance(assignment, Mapping):
            raise ValueError(f"verified signed assignment missing for {notation}")
        assignment_audit = verified_signed_crossing_assignment_audit(assignment)
        signs = tuple(int(value) for value in assignment.get("signs", []))
        role_orders = assignment.get("role_orders", [])
        diagram = fixture.diagram_with_signs(signs)
        orientation = PDOrientation.from_signed_pd_role_orders(
            diagram,
            role_orders,
            convention="verified_knot_atlas_source_assignment_v1",
        )
        orientation_issue_count = len(orientation.validation_issues(diagram))
        result = multivariable_alexander_exact_from_oriented_pd(
            diagram,
            orientation,
            variables=variables,
        )
        assignment_source = "verified_signed_crossing_assignment"
    else:
        diagram = fixture.diagram()
        orientation = fixture.orientation()
        orientation_issue_count = len(orientation.validation_issues(diagram))
        result = multivariable_alexander_exact_from_oriented_pd(
            diagram,
            orientation,
            variables=variables,
        )
        assignment_source = "registered_signed_pd_fixture"

    computed_polynomial = result.get("multivariable_alexander_polynomial")
    polynomial_matches = bool(
        isinstance(computed_polynomial, str)
        and _normalized_polynomial(computed_polynomial, variables)
        == _normalized_polynomial(expected_polynomial, variables)
    )

    if not fixture.pd_code:
        exact_result_audit = multivariable_alexander_exact_result_audit(result)
        terminal_certificate = result.get("exact_terminal_certificate") or {}
        terminal_certified = bool(
            result.get("full_admissible_minor_normalization_certified") is True
            and result.get("full_invariant_certified") is True
            and terminal_certificate.get("certified") is True
            and exact_result_audit.get("certified") is True
        )
        checks = {
            "orientation_validation_issue_count_zero": orientation_issue_count == 0,
            "terminal_result_not_skipped": result.get("skipped") is False,
            "terminal_polynomial_matches_fixture": polynomial_matches,
            "terminal_requires_normalization_false": (
                result.get("requires_normalization") is False
            ),
            "exact_terminal_normalization_certified": terminal_certified,
            "uncapped_exact_result_replay_certified": (
                exact_result_audit.get("certified") is True
            ),
        }
        summary = {
            "case_kind": "zero_crossing_terminal",
            "matrix_size": [0, 0],
            "target_minor_size": 0,
            "expected_minor_count": 0,
            "scanned_minor_count": 0,
            "nonzero_minor_count": 0,
            "complete_maximal_minor_scan": True,
            "exact_maximal_minor_gcd_certified": terminal_certified,
            "zero_ideal_certified": result.get("zero_ideal_certified") is True,
            "quotient_gcd_polynomial": None,
            "wirtinger_fox_chain_certified": True,
            "exact_algorithm": result.get("exact_algorithm"),
            "resource_caps": result.get("resource_caps"),
        }
    else:
        wirtinger_audit = multivariable_alexander_wirtinger_fox_audit(result)
        exact_result_audit = multivariable_alexander_exact_result_audit(result)
        gcd_certificate = result.get("exact_gcd_certificate") or {}
        minor_summary = result.get("admissible_minor_summary") or {}
        matrix_size = list(minor_summary.get("matrix_size", [0, 0]))
        row_count = int(matrix_size[0]) if len(matrix_size) > 0 else 0
        column_count = int(matrix_size[1]) if len(matrix_size) > 1 else 0
        target_size = int(minor_summary.get("target_size", 0) or 0)
        expected_minor_count = (
            comb(row_count, target_size) * comb(column_count, target_size)
            if 0 <= target_size <= row_count and 0 <= target_size <= column_count
            else 0
        )
        complete_scan = bool(
            minor_summary.get("complete_combination_scan") is True
            and result.get("square_minors", {}).get("truncated") is False
            and int(minor_summary.get("scanned_minor_count", 0) or 0)
            == expected_minor_count
            and target_size == max(0, column_count - 1)
            and row_count >= target_size
        )
        assignment_certified = (
            assignment_audit is None
            or assignment_audit.get("assignment_certified") is True
        )
        empty_input_family = gcd_certificate.get("empty_input_family") is True
        zero_ideal_certified = bool(
            gcd_certificate.get("all_inputs_zero") is True
            and gcd_certificate.get("candidate_is_zero") is True
            and gcd_certificate.get("zero_ideal_certified") is True
            and gcd_certificate.get("exact_gcd_certification_basis")
            == (
                "no_admissible_maximal_minors"
                if empty_input_family
                else "all_enumerated_ideal_generators_zero"
            )
            and gcd_certificate.get("quotient_gcd_certified") is False
            and gcd_certificate.get("quotient_gcd_polynomial") is None
        )
        nonzero_gcd_certified = bool(
            gcd_certificate.get("all_inputs_zero") is False
            and gcd_certificate.get("empty_input_family") is False
            and gcd_certificate.get("candidate_is_zero") is False
            and gcd_certificate.get("zero_ideal_certified") is False
            and gcd_certificate.get("exact_gcd_certification_basis")
            == "exact_division_and_quotient_gcd_one"
            and gcd_certificate.get("candidate_is_exact_gcd") is True
            and gcd_certificate.get("candidate_divides_all_nonzero_inputs") is True
            and gcd_certificate.get("quotient_gcd_certified") is True
            and gcd_certificate.get("quotient_gcd_polynomial") == "1"
        )
        exact_gcd = bool(
            result.get("full_admissible_minor_normalization_certified") is True
            and result.get("full_invariant_certified") is True
            and gcd_certificate.get("candidate_is_exact_gcd") is True
            and gcd_certificate.get("candidate_divides_all_nonzero_inputs") is True
            and (nonzero_gcd_certified or zero_ideal_certified)
            and exact_result_audit.get("certified") is True
        )
        checks = {
            "verified_or_registered_assignment_certified": assignment_certified,
            "orientation_validation_issue_count_zero": orientation_issue_count == 0,
            "result_not_skipped": result.get("skipped") is False,
            "wirtinger_fox_input_chain_consistent": (
                wirtinger_audit.get("input_chain_consistent") is True
            ),
            "complete_maximal_minor_scan": complete_scan,
            "exact_maximal_minor_gcd_certified": exact_gcd,
            "uncapped_exact_result_replay_certified": (
                exact_result_audit.get("certified") is True
            ),
            "computed_polynomial_matches_fixture_or_source_table": polynomial_matches,
        }
        summary = {
            "case_kind": "maximal_fox_minor_gcd",
            "matrix_size": matrix_size,
            "target_minor_size": target_size,
            "expected_minor_count": expected_minor_count,
            "scanned_minor_count": int(
                minor_summary.get("scanned_minor_count", 0) or 0
            ),
            "nonzero_minor_count": int(
                minor_summary.get("nonzero_minor_count", 0) or 0
            ),
            "complete_maximal_minor_scan": complete_scan,
            "exact_maximal_minor_gcd_certified": exact_gcd,
            "zero_ideal_certified": zero_ideal_certified,
            "quotient_gcd_polynomial": gcd_certificate.get(
                "quotient_gcd_polynomial"
            ),
            "wirtinger_fox_chain_certified": (
                wirtinger_audit.get("input_chain_consistent") is True
            ),
            "exact_algorithm": result.get("exact_algorithm"),
            "resource_caps": result.get("resource_caps"),
        }

    failed_checks = [name for name, passed in checks.items() if not passed]
    return {
        "notation": notation,
        "fixture_name": fixture.name,
        "assignment_source": assignment_source,
        "verified_signed_crossing_assignment": (
            deepcopy(dict(assignment)) if assignment is not None else None
        ),
        "variables": list(variables),
        "expected_polynomial": expected_polynomial,
        "computed_polynomial": computed_polynomial,
        "polynomial_matches_up_to_laurent_unit": polynomial_matches,
        "orientation_validation_issue_count": orientation_issue_count,
        **summary,
        "checks": checks,
        "failed_check_count": len(failed_checks),
        "failed_checks": failed_checks,
        "passed": not failed_checks,
        "computation_sha256": canonical_json_sha256(result),
        "computation": result,
    }


def _compute_algorithm_boundary_cases() -> list[dict[str, Any]]:
    """Replay adversarial valid inputs that exercise general-algorithm edges."""

    rectangular_diagram = build_planar_diagram(
        [[1, 3, 2, 4], [2, 4, 1, 3]],
        signs=[1, -1],
        component_count=2,
        name="alexander-boundary-rectangular-r2-unlink",
    )
    rectangular_orientation = PDOrientation(
        crossings=(
            PDCrossingOrientation(1, 2, 3, 4),
            PDCrossingOrientation(2, 1, 4, 3),
        ),
        edge_components=((1, 0), (2, 0), (3, 1), (4, 1)),
    )

    trefoil = get_diagram_fixture("3_1")
    if trefoil.pd_code is None or trefoil.signs is None:
        raise ValueError("registered trefoil boundary seed lacks signed PD data")
    split_free_diagram = build_planar_diagram(
        trefoil.pd_code,
        signs=trefoil.signs,
        component_count=2,
        name="alexander-boundary-trefoil-plus-free-circle",
    )
    split_free_orientation = trefoil.orientation()

    specs = (
        {
            "boundary_case_id": "rectangular_2x3_r2_zero_ideal",
            "boundary_kind": "rectangular_wirtinger_fox_matrix",
            "diagram": rectangular_diagram,
            "orientation": rectangular_orientation,
            "variables": ("u", "v"),
            "expected_polynomial": "0",
        },
        {
            "boundary_case_id": "nonzero_crossing_split_free_component_zero_ideal",
            "boundary_kind": "split_free_circle_component",
            "diagram": split_free_diagram,
            "orientation": split_free_orientation,
            "variables": ("t1", "t2"),
            "expected_polynomial": "0",
        },
    )
    rows: list[dict[str, Any]] = []
    for spec in specs:
        diagram = spec["diagram"]
        orientation = spec["orientation"]
        variables = spec["variables"]
        result = multivariable_alexander_exact_from_oriented_pd(
            diagram,
            orientation,
            variables=variables,
        )
        replay_audit = multivariable_alexander_exact_result_audit(result)
        summary = result.get("admissible_minor_summary") or {}
        checks = {
            "orientation_validation_issue_count_zero": (
                len(orientation.validation_issues(diagram)) == 0
            ),
            "result_not_skipped": result.get("skipped") is False,
            "expected_zero_polynomial": (
                result.get("multivariable_alexander_polynomial")
                == spec["expected_polynomial"]
            ),
            "zero_ideal_certified": result.get("zero_ideal_certified") is True,
            "full_admissible_minor_normalization_certified": (
                result.get("full_admissible_minor_normalization_certified") is True
            ),
            "full_invariant_certified": (
                result.get("full_invariant_certified") is True
            ),
            "resource_caps_absent": result.get("resource_caps") is None,
            "exact_result_replay_certified": replay_audit.get("certified") is True,
        }
        if spec["boundary_kind"] == "rectangular_wirtinger_fox_matrix":
            checks.update(
                {
                    "rectangular_matrix_size_2x3": (
                        summary.get("matrix_size") == [2, 3]
                    ),
                    "generator_count_minus_one_minor_size": (
                        summary.get("target_size") == 2
                    ),
                    "all_three_maximal_minors_enumerated": (
                        result.get("expected_maximal_minor_count") == 3
                        and result.get("enumerated_maximal_minor_count") == 3
                        and result.get("all_maximal_minors_enumerated") is True
                    ),
                    "all_enumerated_minors_zero": (
                        result.get("all_maximal_minors_zero") is True
                    ),
                }
            )
        else:
            traversal_count = len(
                orientation.oriented_component_traversals(diagram)
            )
            terminal_certificate = result.get("exact_terminal_certificate")
            checks.update(
                {
                    "nonzero_crossing_input": diagram.crossing_count > 0,
                    "declared_component_count_exceeds_traversed_cycles": (
                        diagram.component_count == 2 and traversal_count == 1
                    ),
                    "split_free_component_method": (
                        result.get("method")
                        == "split_free_component_exact_normalization"
                        and result.get("exact_algorithm")
                        == "split_free_component_exact_normalization_v1"
                    ),
                    "split_free_component_partition_certified": all(
                        (
                            result.get("component_count") == 2,
                            result.get("represented_component_cycle_count") == 1,
                            result.get("represented_component_ids") == [0],
                            result.get("free_component_ids") == [1],
                            result.get("split_free_component_count") == 1,
                            result.get("split_free_component_certified") is True,
                        )
                    ),
                    "split_free_component_terminal_certified": bool(
                        isinstance(terminal_certificate, Mapping)
                        and terminal_certificate.get("method")
                        == "split_free_component_exact_normalization_v1"
                        and terminal_certificate.get("normalization_theorem")
                        == (
                            "split_link_with_free_circle_has_zero_"
                            "multivariable_alexander_polynomial"
                        )
                        and terminal_certificate.get("certified") is True
                    ),
                }
            )
        failed_checks = [name for name, passed in checks.items() if not passed]
        rows.append(
            {
                "boundary_case_id": spec["boundary_case_id"],
                "boundary_kind": spec["boundary_kind"],
                "variables": list(variables),
                "expected_polynomial": spec["expected_polynomial"],
                "diagram_crossing_count": diagram.crossing_count,
                "diagram_component_count": diagram.component_count,
                "oriented_component_traversal_count": len(
                    orientation.oriented_component_traversals(diagram)
                ),
                "checks": checks,
                "failed_check_count": len(failed_checks),
                "failed_checks": failed_checks,
                "passed": not failed_checks,
                "computation_sha256": canonical_json_sha256(result),
                "computation": result,
                "replay_audit_sha256": canonical_json_sha256(replay_audit),
                "replay_audit": replay_audit,
            }
        )
    return rows


def full_multivariable_alexander_normalization_certification_report(
    *,
    verified_signed_crossing_assignments: Sequence[Mapping[str, Any]],
    source_witnesses: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    """Build a replayable certificate over every required Alexander fixture."""

    assignments, duplicate_notations = _assignment_map(
        verified_signed_crossing_assignments
    )
    cases: list[dict[str, Any]] = []
    case_errors: list[dict[str, str]] = []
    for notation in FULL_ALEXANDER_REQUIRED_NOTATIONS:
        try:
            cases.append(_compute_case(notation, assignments.get(notation)))
        except (KeyError, TypeError, ValueError) as exc:
            case_errors.append(
                {"notation": notation, "error": f"{type(exc).__name__}: {exc}"}
            )

    boundary_case_errors: list[dict[str, str]] = []
    try:
        boundary_cases = _compute_algorithm_boundary_cases()
    except Exception as exc:
        boundary_cases = []
        boundary_case_errors.append(
            {
                "boundary_case_id": "boundary_case_construction_or_replay",
                "error": f"{type(exc).__name__}: {exc}",
            }
        )

    source_rows = [
        _source_witness_public_row(notation, source_witnesses.get(notation))
        for notation in FULL_ALEXANDER_VERIFIED_ASSIGNMENT_NOTATIONS
    ]
    source_rows_verified = all(
        row["sha256_verified"]
        and row["source_math_matches_pinned_declaration"]
        and row["fixture_value_matches_pinned_declaration"]
        for row in source_rows
    )
    case_notations = [str(case.get("notation") or "") for case in cases]
    case_failures = [case for case in cases if case.get("passed") is not True]
    boundary_case_failures = [
        case for case in boundary_cases if case.get("passed") is not True
    ]
    external_cases = [
        case
        for case in cases
        if case.get("notation") in FULL_ALEXANDER_VERIFIED_ASSIGNMENT_NOTATIONS
    ]
    checks = {
        "uncapped_exact_algorithm_replay_certified": all(
            case.get("exact_algorithm")
            == (
                "zero_crossing_unlink_exact_normalization_v1"
                if case.get("case_kind") == "zero_crossing_terminal"
                else "all_maximal_fox_minors_sympy_zz_gcd_v1"
            )
            and case.get("resource_caps") is None
            and case.get("checks", {}).get(
                "uncapped_exact_result_replay_certified"
            )
            is True
            for case in cases
        ),
        "required_notation_coverage_complete": (
            case_notations == list(FULL_ALEXANDER_REQUIRED_NOTATIONS)
            and not case_errors
        ),
        "verified_assignment_notations_unique": not duplicate_notations,
        "all_fixture_computations_passed": not case_failures and not case_errors,
        "algorithm_boundary_cases_certified": (
            [case.get("boundary_case_id") for case in boundary_cases]
            == [
                "rectangular_2x3_r2_zero_ideal",
                "nonzero_crossing_split_free_component_zero_ideal",
            ]
            and not boundary_case_failures
            and not boundary_case_errors
        ),
        "signed_pd_wirtinger_fox_certified": all(
            case.get("wirtinger_fox_chain_certified") is True
            for case in cases
            if case.get("case_kind") == "maximal_fox_minor_gcd"
        ),
        "all_admissible_maximal_minor_sets_completely_enumerated": all(
            case.get("complete_maximal_minor_scan") is True
            for case in cases
        ),
        "all_admissible_maximal_minor_gcds_exact": all(
            case.get("exact_maximal_minor_gcd_certified") is True
            for case in cases
        ),
        "external_table_source_revisions_verified": source_rows_verified,
        "external_table_normalization_matches": (
            len(external_cases)
            == len(FULL_ALEXANDER_VERIFIED_ASSIGNMENT_NOTATIONS)
            and all(
                case.get("polynomial_matches_up_to_laurent_unit") is True
                for case in external_cases
            )
        ),
    }
    failed_checks = [name for name, passed in checks.items() if not passed]
    return {
        "report_schema_version": 1,
        "method": (
            "full_multivariable_alexander_normalization_certification_report"
        ),
        "claim_scope": (
            "arbitrary_finite_explicit_oriented_signed_pd_full_fox_gcd_"
            "normalization_with_fixture_and_external_table_replay"
        ),
        "required_notations": list(FULL_ALEXANDER_REQUIRED_NOTATIONS),
        "required_notation_count": len(FULL_ALEXANDER_REQUIRED_NOTATIONS),
        "verified_assignment_notations": list(
            FULL_ALEXANDER_VERIFIED_ASSIGNMENT_NOTATIONS
        ),
        "verified_assignment_duplicate_notations": duplicate_notations,
        "exact_algorithm": "all_maximal_fox_minors_sympy_zz_gcd_v1",
        "zero_crossing_exact_algorithm": (
            "zero_crossing_unlink_exact_normalization_v1"
        ),
        "resource_caps": None,
        "arbitrary_finite_explicit_oriented_signed_pd_algorithm": True,
        "case_count": len(cases),
        "passed_case_count": len(cases) - len(case_failures),
        "failed_case_count": len(case_failures) + len(case_errors),
        "case_errors": case_errors,
        "cases": cases,
        "algorithm_boundary_case_count": len(boundary_cases),
        "passed_algorithm_boundary_case_count": (
            len(boundary_cases) - len(boundary_case_failures)
        ),
        "failed_algorithm_boundary_case_count": (
            len(boundary_case_failures) + len(boundary_case_errors)
        ),
        "algorithm_boundary_case_errors": boundary_case_errors,
        "algorithm_boundary_cases": boundary_cases,
        "source_witnesses": source_rows,
        "source_witness_count": len(source_rows),
        "checks": checks,
        "failed_check_count": len(failed_checks),
        "failed_checks": failed_checks,
        "counterexample_count": (
            len(case_failures)
            + len(case_errors)
            + len(boundary_case_failures)
            + len(boundary_case_errors)
        ),
        "signed_pd_wirtinger_fox_certified": (
            checks["signed_pd_wirtinger_fox_certified"]
            and checks["algorithm_boundary_cases_certified"]
        ),
        "admissible_minor_normalization_certified": (
            checks["all_admissible_maximal_minor_sets_completely_enumerated"]
            and checks["all_admissible_maximal_minor_gcds_exact"]
            and checks["algorithm_boundary_cases_certified"]
        ),
        "all_admissible_minors_consistent": (
            checks["all_admissible_maximal_minor_gcds_exact"]
            and checks["algorithm_boundary_cases_certified"]
        ),
        "external_table_normalization_certified": (
            checks["external_table_source_revisions_verified"]
            and checks["external_table_normalization_matches"]
        ),
        "certified": not failed_checks,
        "notes": [
            "all admissible minors means every (g-1)x(g-1) Fox minor, where g is the Wirtinger generator/column count, across every eligible row and column subset",
            "consistency is exact ideal-generator gcd consistency: nonzero families use exact division plus quotient gcd one, while an all-zero family certifies the zero ideal",
            "the production algorithm has no matrix-size or minor-count cap and fails closed on dependency or exact-algebra failure",
            "crossingless inputs use a replayable exact terminal: the unknot is one and a multi-component unlink is the zero Alexander ideal",
            "adversarial boundary replay covers a rectangular 2x3 Fox matrix and a nonzero-crossing diagram with one split free-circle component",
            "fixture rows are replayable regression/source witnesses for the general finite explicit-oriented signed-PD algorithm",
        ],
    }


def _source_witness_audit(row: Mapping[str, Any], notation: str) -> bool:
    declaration = _PINNED_SOURCES[notation]["data"]
    return all(
        (
            row.get("notation") == notation,
            row.get("role") == "multivariable_alexander",
            row.get("title") == declaration["title"],
            row.get("revision_id") == declaration["revision_id"],
            row.get("url") == declaration["url"],
            row.get("expected_sha256") == declaration["sha256"],
            row.get("actual_sha256") == declaration["sha256"],
            row.get("fetched") is True,
            row.get("sha256_verified") is True,
            row.get("source_math_matches_pinned_declaration") is True,
            row.get("fixture_value_matches_pinned_declaration") is True,
        )
    )


def full_multivariable_alexander_normalization_certification_report_audit(
    report: Mapping[str, Any] | None,
) -> dict[str, Any]:
    """Recompute every report case and reject summary/result tampering."""

    if not isinstance(report, Mapping):
        return {
            "method": (
                "full_multivariable_alexander_normalization_certification_report_audit"
            ),
            "certified": False,
            "checks": {"report_available": False},
            "failed_checks": ["report_available"],
            "case_replay_rows": [],
        }

    raw_cases = report.get("cases")
    cases = raw_cases if isinstance(raw_cases, list) else []
    case_by_notation = {
        str(case.get("notation") or ""): case
        for case in cases
        if isinstance(case, Mapping) and case.get("notation")
    }
    case_notations = [
        str(case.get("notation") or "")
        for case in cases
        if isinstance(case, Mapping)
    ]
    replay_rows: list[dict[str, Any]] = []
    for notation in FULL_ALEXANDER_REQUIRED_NOTATIONS:
        case = case_by_notation.get(notation)
        if not isinstance(case, Mapping):
            replay_rows.append(
                {"notation": notation, "replayed": False, "matches": False}
            )
            continue
        assignment = case.get("verified_signed_crossing_assignment")
        try:
            recomputed = _compute_case(
                notation,
                assignment if isinstance(assignment, Mapping) else None,
            )
            embedded_computation = case.get("computation")
            embedded_digest = canonical_json_sha256(embedded_computation)
            recomputed_digest = recomputed["computation_sha256"]
            summary_fields = (
                "fixture_name",
                "assignment_source",
                "variables",
                "expected_polynomial",
                "computed_polynomial",
                "polynomial_matches_up_to_laurent_unit",
                "orientation_validation_issue_count",
                "case_kind",
                "matrix_size",
                "target_minor_size",
                "expected_minor_count",
                "scanned_minor_count",
                "nonzero_minor_count",
                "complete_maximal_minor_scan",
                "exact_maximal_minor_gcd_certified",
                "zero_ideal_certified",
                "quotient_gcd_polynomial",
                "wirtinger_fox_chain_certified",
                "exact_algorithm",
                "resource_caps",
                "checks",
                "failed_check_count",
                "failed_checks",
                "passed",
            )
            summary_matches = all(
                case.get(field) == recomputed.get(field) for field in summary_fields
            )
            matches = all(
                (
                    case.get("computation_sha256") == embedded_digest,
                    embedded_digest == recomputed_digest,
                    summary_matches,
                )
            )
            replay_rows.append(
                {
                    "notation": notation,
                    "replayed": True,
                    "matches": matches,
                    "embedded_computation_sha256": embedded_digest,
                    "declared_computation_sha256": case.get(
                        "computation_sha256"
                    ),
                    "recomputed_computation_sha256": recomputed_digest,
                    "summary_matches": summary_matches,
                }
            )
        except (KeyError, TypeError, ValueError) as exc:
            replay_rows.append(
                {
                    "notation": notation,
                    "replayed": False,
                    "matches": False,
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )

    raw_boundary_cases = report.get("algorithm_boundary_cases")
    boundary_cases = (
        raw_boundary_cases if isinstance(raw_boundary_cases, list) else []
    )
    try:
        recomputed_boundary_cases = _compute_algorithm_boundary_cases()
        recomputed_boundary_error = None
    except Exception as exc:
        recomputed_boundary_cases = []
        recomputed_boundary_error = f"{type(exc).__name__}: {exc}"
    expected_boundary_ids = [
        "rectangular_2x3_r2_zero_ideal",
        "nonzero_crossing_split_free_component_zero_ideal",
    ]
    embedded_boundary_by_id = {
        str(row.get("boundary_case_id") or ""): row
        for row in boundary_cases
        if isinstance(row, Mapping)
    }
    recomputed_boundary_by_id = {
        str(row.get("boundary_case_id") or ""): row
        for row in recomputed_boundary_cases
        if isinstance(row, Mapping)
    }
    boundary_replay_rows: list[dict[str, Any]] = []
    for boundary_case_id in expected_boundary_ids:
        embedded_row = embedded_boundary_by_id.get(boundary_case_id)
        recomputed_row = recomputed_boundary_by_id.get(boundary_case_id)
        matches = bool(
            isinstance(embedded_row, Mapping)
            and isinstance(recomputed_row, Mapping)
            and canonical_json_sha256(embedded_row)
            == canonical_json_sha256(recomputed_row)
        )
        boundary_replay_rows.append(
            {
                "boundary_case_id": boundary_case_id,
                "replayed": isinstance(recomputed_row, Mapping),
                "matches": matches,
                "embedded_sha256": (
                    canonical_json_sha256(embedded_row)
                    if isinstance(embedded_row, Mapping)
                    else None
                ),
                "recomputed_sha256": (
                    canonical_json_sha256(recomputed_row)
                    if isinstance(recomputed_row, Mapping)
                    else None
                ),
            }
        )

    source_rows_raw = report.get("source_witnesses")
    source_rows = source_rows_raw if isinstance(source_rows_raw, list) else []
    source_by_notation = {
        str(row.get("notation") or ""): row
        for row in source_rows
        if isinstance(row, Mapping)
    }
    source_witness_notations = [
        str(row.get("notation") or "")
        for row in source_rows
        if isinstance(row, Mapping)
    ]
    source_witnesses_verified = bool(
        len(source_rows) == len(FULL_ALEXANDER_VERIFIED_ASSIGNMENT_NOTATIONS)
        and all(isinstance(row, Mapping) for row in source_rows)
        and source_witness_notations
        == list(FULL_ALEXANDER_VERIFIED_ASSIGNMENT_NOTATIONS)
        and all(
            isinstance(source_by_notation.get(notation), Mapping)
            and _source_witness_audit(source_by_notation[notation], notation)
            for notation in FULL_ALEXANDER_VERIFIED_ASSIGNMENT_NOTATIONS
        )
    )
    replay_all_matches = all(row["matches"] for row in replay_rows)
    boundary_replay_all_matches = bool(
        recomputed_boundary_error is None
        and len(boundary_cases) == len(expected_boundary_ids)
        and all(isinstance(row, Mapping) for row in boundary_cases)
        and [
            str(row.get("boundary_case_id") or "")
            for row in boundary_cases
            if isinstance(row, Mapping)
        ]
        == expected_boundary_ids
        and all(row["matches"] for row in boundary_replay_rows)
    )
    replayed_cases = [
        case_by_notation[n]
        for n in FULL_ALEXANDER_REQUIRED_NOTATIONS
        if n in case_by_notation
    ]
    derived_checks = {
        "uncapped_exact_algorithm_replay_certified": all(
            case.get("exact_algorithm")
            == (
                "zero_crossing_unlink_exact_normalization_v1"
                if case.get("case_kind") == "zero_crossing_terminal"
                else "all_maximal_fox_minors_sympy_zz_gcd_v1"
            )
            and case.get("resource_caps") is None
            and case.get("checks", {}).get(
                "uncapped_exact_result_replay_certified"
            )
            is True
            for case in replayed_cases
        ),
        "required_notation_coverage_complete": (
            len(cases) == len(FULL_ALEXANDER_REQUIRED_NOTATIONS)
            and all(isinstance(case, Mapping) for case in cases)
            and case_notations == list(FULL_ALEXANDER_REQUIRED_NOTATIONS)
        ),
        "verified_assignment_notations_unique": (
            report.get("verified_assignment_duplicate_notations") == []
        ),
        "all_fixture_computations_passed": (
            len(replayed_cases) == len(FULL_ALEXANDER_REQUIRED_NOTATIONS)
            and all(case.get("passed") is True for case in replayed_cases)
            and report.get("case_errors") == []
        ),
        "algorithm_boundary_cases_certified": bool(
            boundary_replay_all_matches
            and report.get("algorithm_boundary_case_errors") == []
            and all(
                isinstance(row, Mapping) and row.get("passed") is True
                for row in boundary_cases
            )
        ),
        "signed_pd_wirtinger_fox_certified": all(
            case.get("wirtinger_fox_chain_certified") is True
            for case in replayed_cases
            if case.get("case_kind") == "maximal_fox_minor_gcd"
        ),
        "all_admissible_maximal_minor_sets_completely_enumerated": all(
            case.get("complete_maximal_minor_scan") is True
            for case in replayed_cases
        ),
        "all_admissible_maximal_minor_gcds_exact": all(
            case.get("exact_maximal_minor_gcd_certified") is True
            for case in replayed_cases
        ),
        "external_table_source_revisions_verified": source_witnesses_verified,
        "external_table_normalization_matches": all(
            case_by_notation.get(notation, {}).get(
                "polynomial_matches_up_to_laurent_unit"
            )
            is True
            for notation in FULL_ALEXANDER_VERIFIED_ASSIGNMENT_NOTATIONS
        ),
    }
    expected_root_checks = dict(report.get("checks") or {}) == derived_checks
    expected_certified = bool(
        all(derived_checks.values())
        and replay_all_matches
        and boundary_replay_all_matches
    )
    checks = {
        "report_schema_version": report.get("report_schema_version") == 1,
        "method": report.get("method")
        == "full_multivariable_alexander_normalization_certification_report",
        "claim_scope": report.get("claim_scope")
        == (
            "arbitrary_finite_explicit_oriented_signed_pd_full_fox_gcd_"
            "normalization_with_fixture_and_external_table_replay"
        ),
        "required_notations_exact": (
            report.get("required_notations")
            == list(FULL_ALEXANDER_REQUIRED_NOTATIONS)
            and report.get("required_notation_count")
            == len(FULL_ALEXANDER_REQUIRED_NOTATIONS)
            and report.get("verified_assignment_notations")
            == list(FULL_ALEXANDER_VERIFIED_ASSIGNMENT_NOTATIONS)
        ),
        "exact_algorithm_contract": (
            report.get("exact_algorithm")
            == "all_maximal_fox_minors_sympy_zz_gcd_v1"
            and report.get("zero_crossing_exact_algorithm")
            == "zero_crossing_unlink_exact_normalization_v1"
            and report.get("resource_caps") is None
            and report.get("arbitrary_finite_explicit_oriented_signed_pd_algorithm")
            is True
        ),
        "all_case_replays_match": replay_all_matches,
        "all_algorithm_boundary_replays_match": boundary_replay_all_matches,
        "source_witnesses_match_pinned_revisions": source_witnesses_verified,
        "root_checks_match_replayed_evidence": expected_root_checks,
        "root_counts_match_replayed_evidence": (
            report.get("case_count") == len(replayed_cases)
            and report.get("passed_case_count")
            == sum(1 for case in replayed_cases if case.get("passed") is True)
            and report.get("failed_case_count")
            == sum(1 for case in replayed_cases if case.get("passed") is not True)
            and report.get("algorithm_boundary_case_count")
            == len(boundary_cases)
            and report.get("passed_algorithm_boundary_case_count")
            == sum(
                1
                for boundary_case in boundary_cases
                if isinstance(boundary_case, Mapping)
                and boundary_case.get("passed") is True
            )
            and report.get("failed_algorithm_boundary_case_count") == 0
            and report.get("source_witness_count") == len(source_rows)
            and report.get("counterexample_count") == 0
        ),
        "root_failure_summary_matches_replayed_evidence": (
            report.get("failed_check_count") == 0
            and report.get("failed_checks") == []
            and report.get("case_errors") == []
            and report.get("algorithm_boundary_case_errors") == []
        ),
        "root_certification_fields_match_replayed_evidence": (
            report.get("signed_pd_wirtinger_fox_certified")
            is (
                derived_checks["signed_pd_wirtinger_fox_certified"]
                and derived_checks["algorithm_boundary_cases_certified"]
            )
            and report.get("admissible_minor_normalization_certified")
            is (
                derived_checks[
                    "all_admissible_maximal_minor_sets_completely_enumerated"
                ]
                and derived_checks["all_admissible_maximal_minor_gcds_exact"]
                and derived_checks["algorithm_boundary_cases_certified"]
            )
            and report.get("all_admissible_minors_consistent")
            is (
                derived_checks["all_admissible_maximal_minor_gcds_exact"]
                and derived_checks["algorithm_boundary_cases_certified"]
            )
            and report.get("external_table_normalization_certified")
            is (
                derived_checks["external_table_source_revisions_verified"]
                and derived_checks["external_table_normalization_matches"]
            )
            and report.get("certified") is expected_certified
        ),
    }
    failed_checks = [name for name, passed in checks.items() if not passed]
    return {
        "method": (
            "full_multivariable_alexander_normalization_certification_report_audit"
        ),
        "claim_scope": "recomputed_full_alexander_fixture_corpus_certificate",
        "certified": not failed_checks,
        "checks": checks,
        "failed_check_count": len(failed_checks),
        "failed_checks": failed_checks,
        "case_replay_rows": replay_rows,
        "case_replay_count": len(replay_rows),
        "case_replay_match_count": sum(1 for row in replay_rows if row["matches"]),
        "algorithm_boundary_replay_rows": boundary_replay_rows,
        "algorithm_boundary_replay_count": len(boundary_replay_rows),
        "algorithm_boundary_replay_match_count": sum(
            1 for row in boundary_replay_rows if row["matches"]
        ),
        "algorithm_boundary_recompute_error": recomputed_boundary_error,
        "source_witnesses_verified": source_witnesses_verified,
    }
