"""Standard signed-PD fixture conventions."""

from __future__ import annotations

import base64
import binascii
from hashlib import sha256
import ipaddress
import json
import math
from dataclasses import dataclass
from functools import lru_cache
from itertools import product
from pathlib import PurePosixPath
from statistics import median
from typing import Any, Mapping, Sequence
from urllib.parse import urlparse

from iroll.topology.pd import (
    PDOrientation,
    PDCrossingOrientation,
    PlanarDiagram,
    build_planar_diagram,
)


_SOURCE_TABLE_HOMFLY_VARIANT_MISS_WITNESS_LIMIT = 8

_CROSS_WORKSTREAM_REQUIRED_DIAGRAM_FIXTURES = (
    "0_1",
    "3_1",
    "4_1",
    "L0a1",
    "L2a1",
    "L5a1",
    "L6a4",
)

_RELEASE_GRADE_HIGH_POINT_PERFORMANCE_FILENAMES = {
    "raw": "release-grade-high-point-performance.json",
    "analysis": "release-grade-high-point-performance-imgui-analysis.json",
    "host": "release-grade-high-point-performance-imgui-host.json",
}

_BROAD_NOISY_CURVE_ROBUSTNESS_FILENAMES = {
    "raw": "broad-noisy-curve-robustness.json",
    "analysis": "broad-noisy-curve-robustness-imgui-analysis.json",
    "host": "broad-noisy-curve-robustness-imgui-host.json",
}

_SIGNED_RELEASE_SOURCE_PATH = "src/iroll/topology/pd_fixtures.py"
_SIGNED_RELEASE_WHEEL_MEMBER_PATH = "iroll/topology/pd_fixtures.py"
_SIGNED_RELEASE_SDIST_MEMBER_SUFFIX = "src/iroll/topology/pd_fixtures.py"
_SIGNED_RELEASE_REQUIRED_SOURCE_SYMBOLS = frozenset(
    {
        "broad_noisy_curve_robustness_certification_payloads",
        "_release_grade_high_point_timing_recomputation",
        "rust_module_binary_provenance",
    }
)

_BROAD_NOISY_CURVE_FAMILY_SPECS = (
    ("radial_circle_low", 192, 96, 1.0, 1.0, 1.0, 0.01, 0.004, (5.0, 11.0, 3.0)),
    ("radial_circle_high", 256, 128, 1.0, 1.0, 1.0, 0.035, 0.018, (7.0, 17.0, 9.0)),
    ("wide_oval_medium", 288, 144, 1.1, 1.55, 0.68, 0.024, 0.012, (9.0, 23.0, 13.0)),
    ("tall_oval_medium", 288, 144, 1.1, 0.72, 1.48, 0.022, 0.014, (8.0, 19.0, 15.0)),
    ("near_circle_dense", 384, 192, 0.85, 1.0, 1.0, 0.018, 0.010, (13.0, 29.0, 21.0)),
    ("large_radius_sparse", 160, 80, 1.8, 1.0, 1.0, 0.03, 0.015, (6.0, 14.0, 5.0)),
)


@dataclass(frozen=True)
class DiagramFixture:
    notation: str
    name: str
    kind: str
    component_count: int
    pd_code: tuple[tuple[int, int, int, int], ...] | None
    signs: tuple[int, ...] | None
    expected_jones: str | None = None
    expected_homfly: str | None = None
    expected_homfly_source: str | None = None
    expected_homfly_notes: tuple[str, ...] = ()
    expected_multivariable_alexander: str | None = None
    expected_multivariable_alexander_variables: tuple[str, ...] | None = None
    expected_multivariable_alexander_source: str | None = None
    expected_multivariable_alexander_notes: tuple[str, ...] = ()
    source_table_jones: str | None = None
    source_table_jones_iroll_normalized: str | None = None
    source_table_homfly: str | None = None
    source_table_homfly_iroll_normalized: str | None = None
    source_table_multivariable_alexander: str | None = None
    source_table_multivariable_alexander_numerator: str | None = None
    source_table_multivariable_alexander_variables: tuple[str, ...] | None = None
    source_table_notes: tuple[str, ...] = ()
    orientation_role_orders: tuple[tuple[int, int, int, int], ...] | None = None
    gauss_code: tuple[tuple[int, ...], ...] | None = None
    source: str = "iroll"
    source_url: str | None = None
    convention_notes: tuple[str, ...] = ()

    @property
    def has_signed_pd(self) -> bool:
        return self.pd_code is not None and self.signs is not None

    @property
    def has_pd_code(self) -> bool:
        return self.pd_code is not None

    def diagram(self) -> PlanarDiagram:
        if self.pd_code is None or self.signs is None:
            raise ValueError(f"fixture {self.notation} does not have a signed PD diagram")
        return build_planar_diagram(
            self.pd_code,
            signs=self.signs,
            component_count=self.component_count,
            name=self.name,
        )

    def diagram_with_signs(
        self,
        signs: tuple[int, ...] | None = None,
        *,
        default_sign: int = 1,
    ) -> PlanarDiagram:
        """Build a diagnostic diagram even when fixture signs are not registered."""

        if self.pd_code is None:
            raise ValueError(f"fixture {self.notation} does not have a PD diagram")
        resolved_signs = (
            tuple(int(sign) for sign in signs)
            if signs is not None
            else (
                self.signs
                if self.signs is not None
                else tuple(default_sign for _ in self.pd_code)
            )
        )
        return build_planar_diagram(
            self.pd_code,
            signs=resolved_signs,
            component_count=self.component_count,
            name=self.name,
        )

    def orientation_diagnostics(
        self,
        *,
        default_sign: int = 1,
        max_samples: int = 8,
        max_assignments: int = 500_000,
    ) -> dict:
        """Return orientation convention diagnostics for signed or unsigned PD fixtures."""

        diagram = self.diagram_with_signs(default_sign=default_sign)
        strict_candidates = PDOrientation.role_permutation_candidates(diagram)
        flow_candidates = PDOrientation.role_permutation_candidates(
            diagram,
            include_component_mismatches=True,
        )
        local_summary = PDOrientation.local_role_assignment_summary(
            diagram,
            max_samples=max_samples,
            max_assignments=max_assignments,
        )
        return {
            "method": "diagram_fixture_orientation_diagnostics",
            "notation": self.notation,
            "has_signed_pd": self.has_signed_pd,
            "diagnostic_signs": [crossing.sign for crossing in diagram.crossings],
            "diagram": diagram.to_dict(),
            "strict_candidate_count": len(strict_candidates),
            "strict_candidates": [
                _orientation_candidate_summary(candidate)
                for candidate in strict_candidates
            ],
            "flow_candidate_count": len(flow_candidates),
            "flow_candidates": [
                _orientation_candidate_summary(candidate)
                for candidate in flow_candidates
            ],
            "local_orientation_assignment_summary": local_summary,
            "notes": [
                "orientation diagnostics do not register fixture signs or expected invariants",
                "unsigned fixtures use diagnostic signs only because orientation flow is sign-independent",
            ],
        }

    def gauss_code_orientation_diagnostics(
        self,
        *,
        default_sign: int = 1,
        max_orientation_samples: int = 256,
        max_assignments: int = 500_000,
        max_matches: int = 8,
        allow_reversal: bool = False,
    ) -> dict:
        """Match local signed-PD role assignments against a source Gauss code."""

        if self.gauss_code is None:
            return {
                "method": "diagram_fixture_gauss_code_orientation_diagnostics",
                "notation": self.notation,
                "matched": False,
                "skipped": True,
                "target_gauss_code": None,
                "checked_sample_count": 0,
                "matching_sample_count": 0,
                "matches": [],
                "local_orientation_assignment_summary": None,
                "notes": ["fixture does not register a source Gauss code"],
            }

        diagram = self.diagram_with_signs(default_sign=default_sign)
        local_summary = PDOrientation.local_role_assignment_summary(
            diagram,
            max_samples=max_orientation_samples,
            max_assignments=max_assignments,
        )
        diagnostics = _gauss_code_orientation_diagnostics_from_samples(
            diagram,
            self.gauss_code,
            local_summary.get("samples", []),
            max_matches=max_matches,
            allow_reversal=allow_reversal,
        )
        return {
            "method": "diagram_fixture_gauss_code_orientation_diagnostics",
            "notation": self.notation,
            "matched": diagnostics["matched"],
            "skipped": False,
            "target_gauss_code": [list(component) for component in self.gauss_code],
            "checked_sample_count": diagnostics["checked_sample_count"],
            "matching_sample_count": diagnostics["matching_sample_count"],
            "matches": diagnostics["matches"],
            "local_orientation_assignment_summary": local_summary,
            "truncated": bool(local_summary.get("truncated", False)),
            "allow_reversal": allow_reversal,
            "notes": [
                "Gauss-code matching constrains source orientation metadata but does not choose crossing signs",
                "positive_entries_mark_over_strand is the current matched source convention when a match is present",
            ],
        }

    def source_pd_convention_assignment_audit(self) -> dict:
        """Derive one signed assignment from the documented Knot Atlas PD rules.

        Knot Atlas numbers edges increasingly around each oriented component and
        writes ``X[i,j,k,l]`` counterclockwise from the incoming lower edge.
        Therefore ``i -> k`` is the under-strand direction, while ``j -> l`` is
        a negative crossing and ``l -> j`` is a positive crossing. The source
        Gauss-code component lengths determine the consecutive edge ranges.

        This is a local, deterministic convention audit. A final evidence
        producer must still pin and hash the external source revisions before
        promoting the result to a verified assignment artifact.
        """

        if self.pd_code is None or self.gauss_code is None:
            return {
                "method": "diagram_fixture_source_pd_convention_assignment_audit",
                "claim_scope": "source_pd_convention_assignment_derivation",
                "notation": self.notation,
                "skipped": True,
                "assignment_unique_under_source_convention": False,
                "checks": {},
                "failed_checks": ["source_pd_and_gauss_code_available"],
                "notes": [
                    "fixture requires both a source PD presentation and source Gauss code",
                ],
            }

        component_edge_ranges: list[list[int]] = []
        successor: dict[int, int] = {}
        first_edge = 1
        for component in self.gauss_code:
            if not component:
                component_edge_ranges.append([])
                continue
            last_edge = first_edge + len(component) - 1
            edges = list(range(first_edge, last_edge + 1))
            component_edge_ranges.append(edges)
            for index, edge in enumerate(edges):
                successor[edge] = edges[(index + 1) % len(edges)]
            first_edge = last_edge + 1

        diagram_edges = sorted(
            {int(edge) for crossing in self.pd_code for edge in crossing}
        )
        expected_edges = list(range(1, 2 * len(self.pd_code) + 1))
        component_edges = sorted(successor)
        component_ranges_cover_diagram = (
            diagram_edges == expected_edges == component_edges
        )

        signs: list[int] = []
        role_orders: list[list[int]] = []
        crossing_rows: list[dict] = []
        ambiguous_crossing_indices: list[int] = []
        under_direction_mismatch_indices: list[int] = []
        for crossing_index, code in enumerate(self.pd_code):
            lower_in, upper_first, lower_out, upper_second = code
            under_direction_matches = successor.get(lower_in) == lower_out
            upper_first_to_second = successor.get(upper_first) == upper_second
            upper_second_to_first = successor.get(upper_second) == upper_first
            if not under_direction_matches:
                under_direction_mismatch_indices.append(crossing_index)
            if upper_first_to_second == upper_second_to_first:
                ambiguous_crossing_indices.append(crossing_index)
                crossing_rows.append(
                    {
                        "crossing_index": crossing_index,
                        "code": list(code),
                        "under_direction_matches": under_direction_matches,
                        "upper_direction_unique": False,
                        "sign": None,
                        "role_order": None,
                    }
                )
                continue

            if upper_first_to_second:
                sign = -1
                role_order = [0, 1, 2, 3]
                upper_direction = [upper_first, upper_second]
            else:
                sign = 1
                role_order = [0, 3, 2, 1]
                upper_direction = [upper_second, upper_first]
            signs.append(sign)
            role_orders.append(role_order)
            crossing_rows.append(
                {
                    "crossing_index": crossing_index,
                    "code": list(code),
                    "under_direction": [lower_in, lower_out],
                    "under_direction_matches": under_direction_matches,
                    "upper_direction": upper_direction,
                    "upper_direction_unique": True,
                    "sign": sign,
                    "role_order": role_order,
                }
            )

        complete_assignment = (
            component_ranges_cover_diagram
            and not ambiguous_crossing_indices
            and not under_direction_mismatch_indices
            and len(signs) == len(self.pd_code)
            and len(role_orders) == len(self.pd_code)
        )
        orientation_issues: list[str] = []
        encoded_gauss_code: tuple[tuple[int, ...], ...] = ()
        gauss_code_match = False
        exact_gauss_code_match = False
        pairwise_linking: list[float] = []
        replay = None
        if complete_assignment:
            diagram = self.diagram_with_signs(signs=tuple(signs))
            orientation = PDOrientation.from_signed_pd_role_orders(
                diagram,
                role_orders,
                convention="knot_atlas_pd_source_convention_v1",
            )
            orientation_issues = orientation.validation_issues(diagram)
            encoded_gauss_code = _gauss_code_from_orientation(
                diagram,
                orientation,
                positive_strand="over",
            )
            gauss_match = _match_gauss_code_components(
                self.gauss_code,
                encoded_gauss_code,
                allow_reversal=False,
            )
            gauss_code_match = bool(gauss_match["matched"])
            exact_gauss_code_match = encoded_gauss_code == self.gauss_code
            pairwise_linking = _pd_pairwise_linking_numbers(diagram, orientation)
            replay = {
                "claim_scope": "source_pd_convention_signed_assignment_replay",
                "source_notation": self.notation,
                "source_name": self.name,
                "source": self.source,
                "source_url": self.source_url,
                "diagram": diagram.to_dict(),
                "orientation": orientation.to_dict(),
                "role_orders": role_orders,
                "signs": signs,
                "pairwise_linking": pairwise_linking,
                "orientation_validation_issues": orientation_issues,
            }

        checks = {
            "source_is_knot_atlas": self.source == "Knot Atlas",
            "source_pd_and_gauss_code_available": True,
            "component_count_matches_gauss_code": (
                self.component_count == len(self.gauss_code)
            ),
            "component_edge_ranges_cover_diagram_edges": (
                component_ranges_cover_diagram
            ),
            "all_crossings_start_with_incoming_lower_edge": (
                not under_direction_mismatch_indices
            ),
            "all_upper_strand_directions_unique": not ambiguous_crossing_indices,
            "assignment_covers_every_crossing": complete_assignment,
            "orientation_validation_issue_count_zero": not orientation_issues,
            "source_gauss_code_match": gauss_code_match,
            "source_gauss_code_exact_match": exact_gauss_code_match,
        }
        failed_checks = [name for name, passed in checks.items() if not passed]
        assignment_unique = not failed_checks
        return {
            "method": "diagram_fixture_source_pd_convention_assignment_audit",
            "claim_scope": "source_pd_convention_assignment_derivation",
            "notation": self.notation,
            "source": self.source,
            "source_url": self.source_url,
            "skipped": False,
            "source_convention": "knot_atlas_pd_incoming_lower_counterclockwise_v1",
            "component_edge_ranges": component_edge_ranges,
            "crossing_count": len(self.pd_code),
            "signs": signs,
            "role_orders": role_orders,
            "crossing_rows": crossing_rows,
            "ambiguous_crossing_indices": ambiguous_crossing_indices,
            "under_direction_mismatch_indices": under_direction_mismatch_indices,
            "encoded_gauss_code": [list(component) for component in encoded_gauss_code],
            "target_gauss_code": [list(component) for component in self.gauss_code],
            "source_gauss_code_match": gauss_code_match,
            "source_gauss_code_exact_match": exact_gauss_code_match,
            "pairwise_linking": pairwise_linking,
            "orientation_validation_issues": orientation_issues,
            "orientation_validation_issue_count": len(orientation_issues),
            "source_candidate_replay_valid": (
                replay is not None and not orientation_issues and exact_gauss_code_match
            ),
            "candidate_replay": replay,
            "checks": checks,
            "check_count": len(checks),
            "passed_check_count": sum(1 for passed in checks.values() if passed),
            "failed_check_count": len(failed_checks),
            "failed_checks": failed_checks,
            "assignment_unique_under_source_convention": assignment_unique,
            "completion_claimed": False,
            "notes": [
                "Knot Atlas documents increasing edge labels around oriented components",
                "X[i,j,k,l] starts at the incoming lower edge and proceeds counterclockwise",
                "the documented Xp/Xm upper-strand directions determine crossing sign",
                "external pinned-revision hashes remain required for final evidence",
            ],
        }

    def signed_candidate_diagnostics(
        self,
        *,
        max_orientation_samples: int = 2,
        max_sign_patterns: int = 64,
        target_pairwise_linking: tuple[int | float, ...] | None = None,
        max_candidates: int = 8,
        compute_homfly: bool = True,
        compute_alexander: bool = True,
        homfly_max_depth: int = 12,
        homfly_max_nodes: int = 2048,
        alexander_max_matrix_size: int = 5,
        alexander_max_minors: int = 128,
        require_gauss_code_match: bool = False,
    ) -> dict:
        """Bounded signed-candidate scan for unsigned or convention-ambiguous fixtures."""

        from iroll.topology.homfly import (
            homfly_mirror_polynomial,
            homfly_polynomial_from_pd,
        )
        from iroll.topology.multivariable_alexander import multivariable_alexander_from_pd
        from iroll.topology.pd import jones_polynomial_from_pd, mirror_signed_pd

        if self.pd_code is None:
            raise ValueError(f"fixture {self.notation} does not have a PD diagram")
        if max_orientation_samples < 0:
            raise ValueError("max_orientation_samples must be non-negative")
        if max_sign_patterns < 0:
            raise ValueError("max_sign_patterns must be non-negative")
        if max_candidates < 0:
            raise ValueError("max_candidates must be non-negative")

        orientation_diagnostics = self.orientation_diagnostics(
            max_samples=max_orientation_samples,
        )
        local_summary = orientation_diagnostics["local_orientation_assignment_summary"]
        gauss_code_orientation_diagnostics = None
        if require_gauss_code_match:
            if self.gauss_code is None:
                gauss_code_orientation_diagnostics = {
                    "method": "diagram_fixture_gauss_code_orientation_diagnostics",
                    "notation": self.notation,
                    "matched": False,
                    "skipped": True,
                    "target_gauss_code": None,
                    "checked_sample_count": 0,
                    "matching_sample_count": 0,
                    "matches": [],
                    "notes": ["fixture does not register a source Gauss code"],
                }
                local_samples = []
            else:
                gauss_code_orientation_diagnostics = (
                    _gauss_code_orientation_diagnostics_from_samples(
                        self.diagram_with_signs(),
                        self.gauss_code,
                        local_summary.get("samples", []),
                        max_matches=max_orientation_samples,
                    )
                )
                local_samples = [
                    match["sample"]
                    for match in gauss_code_orientation_diagnostics["matches"]
                ][:max_orientation_samples]
        else:
            local_samples = local_summary.get("samples", [])[:max_orientation_samples]
        all_sign_pattern_count = 2 ** len(self.pd_code)
        target = (
            tuple(float(value) for value in target_pairwise_linking)
            if target_pairwise_linking is not None
            else None
        )
        candidates = []
        considered_sign_patterns = 0
        matching_candidate_count = 0
        matching_sign_samples: dict[tuple[int, ...], set[int]] = {}
        sign_patterns = product((-1, 1), repeat=len(self.pd_code))
        for sign_index, signs in enumerate(sign_patterns):
            if sign_index >= max_sign_patterns:
                break
            considered_sign_patterns += 1
            signs = tuple(signs)
            diagram = self.diagram_with_signs(signs=signs)
            for sample_index, sample in enumerate(local_samples):
                orientation = _orientation_from_local_sample(diagram, sample)
                pairwise_linking = _pd_pairwise_linking_numbers(diagram, orientation)
                if target is not None and tuple(pairwise_linking) != target:
                    continue
                matching_candidate_count += 1
                matching_sign_samples.setdefault(signs, set()).add(sample_index)
                if len(candidates) >= max_candidates:
                    continue
                candidate = {
                    "sample_index": sample_index,
                    "role_orders": sample["role_orders"],
                    "signs": list(signs),
                    "mirror_signs": [-sign for sign in signs],
                    "pairwise_linking": pairwise_linking,
                    "jones_polynomial": jones_polynomial_from_pd(diagram),
                    "orientation": orientation.to_dict(),
                    "signed_pd_input": {
                        "claim_scope": "source_gauss_matched_signed_pd_candidate_replay",
                        "source_notation": self.notation,
                        "source_name": self.name,
                        "source": self.source,
                        "source_url": self.source_url,
                        "diagram": diagram.to_dict(),
                        "orientation": orientation.to_dict(),
                        "role_orders": [list(order) for order in sample["role_orders"]],
                        "signs": list(signs),
                        "pairwise_linking": list(pairwise_linking),
                        "orientation_validation_issues": (
                            orientation.validation_issues(diagram)
                        ),
                    },
                }
                if compute_homfly:
                    homfly = homfly_polynomial_from_pd(
                        diagram,
                        orientation=orientation,
                        max_depth=homfly_max_depth,
                        max_nodes=homfly_max_nodes,
                    )
                    candidate["homfly"] = {
                        "skipped": homfly["skipped"],
                        "method": homfly["method"],
                        "homfly_polynomial": homfly["homfly_polynomial"],
                    }
                    if not homfly["skipped"] and homfly["homfly_polynomial"] is not None:
                        mirror_diagram, mirror_orientation = mirror_signed_pd(
                            diagram,
                            orientation=orientation,
                        )
                        mirrored_homfly = homfly_polynomial_from_pd(
                            mirror_diagram,
                            orientation=mirror_orientation,
                            max_depth=homfly_max_depth,
                            max_nodes=homfly_max_nodes,
                        )
                        expected_mirror = homfly_mirror_polynomial(
                            homfly["homfly_polynomial"]
                        )
                        candidate["homfly_mirror_audit"] = {
                            "expected_mirror_homfly": expected_mirror,
                            "mirrored_homfly": mirrored_homfly["homfly_polynomial"],
                            "matched": (
                                not mirrored_homfly["skipped"]
                                and mirrored_homfly["homfly_polynomial"] == expected_mirror
                            ),
                            "skipped": mirrored_homfly["skipped"],
                            "method": mirrored_homfly["method"],
                        }
                if compute_alexander:
                    variables = tuple(
                        f"t{index + 1}" for index in range(self.component_count)
                    )
                    alexander = multivariable_alexander_from_pd(
                        diagram,
                        orientation=orientation,
                        variables=variables,
                        max_matrix_size=alexander_max_matrix_size,
                        max_minors=alexander_max_minors,
                    )
                    candidate["multivariable_alexander"] = (
                        _candidate_alexander_payload(alexander)
                    )
                candidate["invariant_signature"] = _candidate_invariant_signature(
                    candidate
                )
                candidates.append(candidate)

        matching_sign_summary = _matching_sign_pattern_summary(matching_sign_samples)
        matching_sign_pattern_set = set(matching_sign_samples)
        for candidate in candidates:
            mirror_signs = tuple(-sign for sign in candidate["signs"])
            candidate["mirror_sign_pattern_present"] = (
                mirror_signs in matching_sign_pattern_set
            )

        return {
            "method": "diagram_fixture_signed_candidate_diagnostics",
            "notation": self.notation,
            "has_signed_pd": self.has_signed_pd,
            "orientation_sample_count": len(local_samples),
            "all_sign_pattern_count": all_sign_pattern_count,
            "considered_sign_pattern_count": considered_sign_patterns,
            "target_pairwise_linking": list(target) if target is not None else None,
            "gauss_code_match_required": require_gauss_code_match,
            "gauss_code_orientation_diagnostics": gauss_code_orientation_diagnostics,
            "matching_candidate_count": matching_candidate_count,
            "returned_candidate_count": len(candidates),
            "matching_sign_summary": matching_sign_summary,
            "candidates": candidates,
            "candidate_groups": _candidate_group_summaries(candidates),
            "truncated": (
                all_sign_pattern_count > considered_sign_patterns
                or matching_candidate_count > len(candidates)
            ),
            "orientation_diagnostics": orientation_diagnostics,
            "notes": [
                "signed candidates are diagnostics and are not registered as fixture invariants",
                "candidate signs and local role assignments still require external source convention validation",
                "Gauss-code matching constrains orientation samples when require_gauss_code_match is true",
            ],
        }

    def source_invariant_candidate_diagnostics(
        self,
        *,
        max_orientation_samples: int = 64,
        max_sign_patterns: int | None = None,
        max_candidates: int = 64,
        target_pairwise_linking: tuple[int | float, ...] | None = None,
        compute_homfly: bool = True,
        compute_alexander: bool = True,
        homfly_max_depth: int = 12,
        homfly_max_nodes: int = 2048,
        alexander_max_matrix_size: int = 5,
        alexander_max_minors: int = 128,
    ) -> dict:
        """Compute invariant signatures for source-Gauss-matched sign candidates."""

        from iroll.topology.knot_table import builtin_link_table

        if self.pd_code is None:
            return {
                "method": "diagram_fixture_source_invariant_candidate_diagnostics",
                "notation": self.notation,
                "skipped": True,
                "target_pairwise_linking": None,
                "gauss_code_match_required": True,
                "notes": ["fixture does not have a PD source record"],
            }
        if self.gauss_code is None:
            return {
                "method": "diagram_fixture_source_invariant_candidate_diagnostics",
                "notation": self.notation,
                "skipped": True,
                "target_pairwise_linking": None,
                "gauss_code_match_required": True,
                "notes": ["fixture does not register a source Gauss code"],
            }

        link_table_entry = next(
            (
                entry
                for entry in builtin_link_table()
                if entry["notation"] == self.notation
            ),
            None,
        )
        target = (
            tuple(float(value) for value in target_pairwise_linking)
            if target_pairwise_linking is not None
            else (
                tuple(float(value) for value in link_table_entry["pairwise_linking"])
                if link_table_entry is not None
                else None
            )
        )
        if target is None:
            return {
                "method": "diagram_fixture_source_invariant_candidate_diagnostics",
                "notation": self.notation,
                "skipped": True,
                "target_pairwise_linking": None,
                "link_table_entry": link_table_entry,
                "gauss_code_match_required": True,
                "notes": [
                    "no target pairwise-linking signature was supplied or found in the built-in link table",
                ],
            }

        diagnostics = self.signed_candidate_diagnostics(
            max_orientation_samples=max_orientation_samples,
            max_sign_patterns=(
                2 ** len(self.pd_code)
                if max_sign_patterns is None
                else max_sign_patterns
            ),
            target_pairwise_linking=target,
            max_candidates=max_candidates,
            compute_homfly=compute_homfly,
            compute_alexander=compute_alexander,
            homfly_max_depth=homfly_max_depth,
            homfly_max_nodes=homfly_max_nodes,
            alexander_max_matrix_size=alexander_max_matrix_size,
            alexander_max_minors=alexander_max_minors,
            require_gauss_code_match=True,
        )
        diagnostics["method"] = "diagram_fixture_source_invariant_candidate_diagnostics"
        diagnostics["skipped"] = False
        diagnostics["link_table_entry"] = link_table_entry
        diagnostics["signed_pd_replay_summary"] = _signed_pd_replay_summary(
            diagnostics,
        )
        diagnostics["candidate_convergence"] = _candidate_convergence_summary(
            diagnostics,
        )
        diagnostics["notes"] = [
            "source invariant candidates use source-Gauss-code-matched orientation samples and the target pairwise-linking signature",
            "stable candidate invariants are convention evidence only until signed crossing signs and external normalization are verified",
            *diagnostics["notes"],
        ]
        return diagnostics

    def source_table_invariant_audit(
        self,
        *,
        max_orientation_samples: int = 64,
        max_sign_patterns: int | None = None,
        max_candidates: int = 64,
        target_pairwise_linking: tuple[int | float, ...] | None = None,
        compute_homfly: bool = False,
        compute_alexander: bool = True,
        homfly_max_depth: int = 12,
        homfly_max_nodes: int = 2048,
        alexander_max_matrix_size: int = 5,
        alexander_max_minors: int = 128,
    ) -> dict:
        """Compare source-Gauss-matched candidate convergence with source-table values.

        This report is intentionally separate from registered fixture comparison:
        source-table values can be present before iroll has verified a unique signed
        crossing convention for the PD source.
        """

        diagnostics = self.source_invariant_candidate_diagnostics(
            max_orientation_samples=max_orientation_samples,
            max_sign_patterns=max_sign_patterns,
            max_candidates=max_candidates,
            target_pairwise_linking=target_pairwise_linking,
            compute_homfly=compute_homfly,
            compute_alexander=compute_alexander,
            homfly_max_depth=homfly_max_depth,
            homfly_max_nodes=homfly_max_nodes,
            alexander_max_matrix_size=alexander_max_matrix_size,
            alexander_max_minors=alexander_max_minors,
        )
        convergence = diagnostics.get("candidate_convergence", {})
        invariant_summaries = convergence.get("invariants", {})
        homfly_source_variants = _homfly_source_table_convention_variants(
            self.source_table_homfly_iroll_normalized,
        )
        comparisons = {
            "jones": _source_table_candidate_comparison(
                invariant_summaries.get("jones"),
                source_value=self.source_table_jones_iroll_normalized,
                source_value_raw=self.source_table_jones,
                normalization="source q variable renamed to iroll t; half-power link factor removed when needed",
            ),
            "homfly": _source_table_candidate_comparison(
                invariant_summaries.get("homfly"),
                source_value=self.source_table_homfly_iroll_normalized,
                source_value_raw=self.source_table_homfly,
                normalization="source a,z variables are compared in iroll HOMFLY variable names when candidate HOMFLY is computed",
                source_value_variants=homfly_source_variants,
            ),
            "multivariable_alexander_numerator": _source_table_candidate_comparison(
                invariant_summaries.get("multivariable_alexander"),
                source_value=self.source_table_multivariable_alexander_numerator,
                source_value_raw=self.source_table_multivariable_alexander,
                normalization="source half-power denominator removed; comparison is up to Laurent unit normalization",
            ),
        }
        matched_source_table_invariants = [
            name
            for name, comparison in comparisons.items()
            if comparison["complete_candidate_source_match"]
        ]
        uncomputed_source_table_invariants: list[str] = []
        mismatched_source_table_invariants: list[str] = []
        unstable_source_table_invariants: list[str] = []
        for name, comparison in comparisons.items():
            if comparison["complete_candidate_source_match"]:
                continue
            computed = int(comparison.get("computed_candidate_count", 0) or 0)
            missing = int(comparison.get("missing_candidate_count", 0) or 0)
            skipped = int(comparison.get("skipped_candidate_count", 0) or 0)
            if computed == 0 or missing > 0 or skipped > 0:
                uncomputed_source_table_invariants.append(name)
            elif comparison.get("source_value_seen") is False:
                mismatched_source_table_invariants.append(name)
            else:
                unstable_source_table_invariants.append(name)
        candidate_source_table_match_summary = (
            _source_table_candidate_match_summary(
                diagnostics.get("candidates", []),
                comparisons,
            )
        )
        source_table_candidate_convergence_summary = (
            _source_table_candidate_convergence_summary(
                complete_candidate_set=bool(
                    convergence.get("complete_candidate_set", False)
                ),
                comparisons=comparisons,
                matched_source_table_invariants=matched_source_table_invariants,
                uncomputed_source_table_invariants=uncomputed_source_table_invariants,
                mismatched_source_table_invariants=mismatched_source_table_invariants,
                unstable_source_table_invariants=unstable_source_table_invariants,
            )
        )
        alexander_skipped_common_gcd_attempt_summary = (
            _candidate_alexander_skipped_common_gcd_attempt_summary(
                diagnostics.get("candidates", []),
            )
        )
        alexander_source_divisibility_summary = (
            _candidate_alexander_source_divisibility_summary(
                diagnostics.get("candidates", []),
                source_value=self.source_table_multivariable_alexander_numerator,
                variables=(
                    self.source_table_multivariable_alexander_variables
                    or tuple(f"t{index + 1}" for index in range(self.component_count))
                ),
            )
        )
        comparisons["multivariable_alexander_numerator"][
            "skipped_common_gcd_attempt_summary"
        ] = alexander_skipped_common_gcd_attempt_summary
        comparisons["multivariable_alexander_numerator"][
            "source_numerator_divisibility_summary"
        ] = alexander_source_divisibility_summary
        complete_candidate_set = bool(
            convergence.get("complete_candidate_set", False)
        )
        registration_blocker_summary = _source_table_registration_blocker_summary(
            has_signed_pd=self.has_signed_pd,
            registered_fixture_invariant_claim=False,
            complete_candidate_set=complete_candidate_set,
            uncomputed_source_table_invariants=uncomputed_source_table_invariants,
            mismatched_source_table_invariants=mismatched_source_table_invariants,
            unstable_source_table_invariants=unstable_source_table_invariants,
            complete_source_compatible_unique_sign_pattern_count=(
                candidate_source_table_match_summary[
                    "complete_source_compatible_unique_sign_pattern_count"
                ]
            ),
        )
        homfly_comparison = comparisons["homfly"]
        return {
            "method": "diagram_fixture_source_table_invariant_audit",
            "notation": self.notation,
            "name": self.name,
            "has_signed_pd": self.has_signed_pd,
            "registered_fixture_invariant_claim": False,
            "source": self.source,
            "source_url": self.source_url,
            "source_table": {
                "jones": self.source_table_jones,
                "jones_iroll_normalized": self.source_table_jones_iroll_normalized,
                "homfly": self.source_table_homfly,
                "homfly_iroll_normalized": self.source_table_homfly_iroll_normalized,
                "multivariable_alexander": (
                    self.source_table_multivariable_alexander
                ),
                "multivariable_alexander_numerator": (
                    self.source_table_multivariable_alexander_numerator
                ),
                "multivariable_alexander_variables": (
                    list(self.source_table_multivariable_alexander_variables)
                    if self.source_table_multivariable_alexander_variables is not None
                    else None
                ),
                "notes": list(self.source_table_notes),
            },
            "candidate_diagnostics": diagnostics,
            "comparisons": comparisons,
            "candidate_source_table_match_summary": (
                candidate_source_table_match_summary
            ),
            "source_table_candidate_count": candidate_source_table_match_summary[
                "candidate_count"
            ],
            "source_table_candidate_unique_sign_pattern_count": (
                candidate_source_table_match_summary[
                    "candidate_unique_sign_pattern_count"
                ]
            ),
            "source_table_candidate_unique_sign_patterns": (
                candidate_source_table_match_summary[
                    "candidate_unique_sign_patterns"
                ]
            ),
            "source_table_computed_source_compatible_candidate_count": (
                candidate_source_table_match_summary[
                    "computed_source_compatible_candidate_count"
                ]
            ),
            "source_table_computed_source_compatible_unique_sign_pattern_count": (
                candidate_source_table_match_summary[
                    "computed_source_compatible_unique_sign_pattern_count"
                ]
            ),
            "source_table_computed_source_compatible_unique_sign_patterns": (
                candidate_source_table_match_summary[
                    "computed_source_compatible_unique_sign_patterns"
                ]
            ),
            "source_table_complete_source_compatible_candidate_count": (
                candidate_source_table_match_summary[
                    "complete_source_compatible_candidate_count"
                ]
            ),
            "source_table_complete_source_compatible_unique_sign_pattern_count": (
                candidate_source_table_match_summary[
                    "complete_source_compatible_unique_sign_pattern_count"
                ]
            ),
            "source_table_complete_source_compatible_unique_sign_patterns": (
                candidate_source_table_match_summary[
                    "complete_source_compatible_unique_sign_patterns"
                ]
            ),
            "source_table_top_candidate_count": candidate_source_table_match_summary[
                "top_candidate_count"
            ],
            "source_table_top_candidate_unique_sign_pattern_count": (
                candidate_source_table_match_summary[
                    "top_candidate_unique_sign_pattern_count"
                ]
            ),
            "source_table_top_candidate_unique_sign_patterns": (
                candidate_source_table_match_summary[
                    "top_candidate_unique_sign_patterns"
                ]
            ),
            "source_table_max_matched_source_value_count": (
                candidate_source_table_match_summary[
                    "max_matched_source_value_count"
                ]
            ),
            "source_table_max_matched_candidate_total_count": (
                candidate_source_table_match_summary[
                    "max_matched_candidate_total_count"
                ]
            ),
            "source_table_max_matched_candidate_total_unique_sign_pattern_count": (
                candidate_source_table_match_summary[
                    "max_matched_candidate_total_unique_sign_pattern_count"
                ]
            ),
            "source_table_max_matched_candidate_total_unique_sign_patterns": (
                candidate_source_table_match_summary[
                    "max_matched_candidate_total_unique_sign_patterns"
                ]
            ),
            "source_table_max_matched_candidate_count": (
                candidate_source_table_match_summary[
                    "max_matched_candidate_count"
                ]
            ),
            "source_table_max_matched_candidate_unique_sign_pattern_count": (
                candidate_source_table_match_summary[
                    "max_matched_candidate_unique_sign_pattern_count"
                ]
            ),
            "source_table_max_matched_candidate_unique_sign_patterns": (
                candidate_source_table_match_summary[
                    "max_matched_candidate_unique_sign_patterns"
                ]
            ),
            "source_table_homfly_candidate_unique_value_count": homfly_comparison[
                "candidate_unique_value_count"
            ],
            "source_table_homfly_candidate_unit_normalized_value_count": (
                homfly_comparison["candidate_unit_normalized_value_count"]
            ),
            "source_table_homfly_variant_miss_witness_summary": (
                homfly_comparison.get("source_value_variant_miss_witness_summary")
            ),
            "source_table_homfly_variant_miss_witness_count": int(
                (
                    homfly_comparison.get(
                        "source_value_variant_miss_witness_summary"
                    )
                    or {}
                ).get("variant_miss_witness_count", 0)
                or 0
            ),
            "source_table_homfly_variant_miss_witness_limit": int(
                (
                    homfly_comparison.get(
                        "source_value_variant_miss_witness_summary"
                    )
                    or {}
                ).get("variant_miss_witness_limit", 0)
                or 0
            ),
            "source_table_homfly_variant_miss_witness_truncated": bool(
                (
                    homfly_comparison.get(
                        "source_value_variant_miss_witness_summary"
                    )
                    or {}
                ).get("variant_miss_witness_truncated", False)
            ),
            "source_table_alexander_skipped_common_gcd_attempt_summary": (
                alexander_skipped_common_gcd_attempt_summary
            ),
            "source_table_alexander_skipped_common_gcd_attempt_candidate_count": (
                alexander_skipped_common_gcd_attempt_summary[
                    "candidate_with_attempt_evidence_count"
                ]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count": (
                alexander_skipped_common_gcd_attempt_summary[
                    "not_certified_candidate_count"
                ]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_statuses": (
                alexander_skipped_common_gcd_attempt_summary["statuses"]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_status_counts": (
                alexander_skipped_common_gcd_attempt_summary["status_counts"]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count": (
                alexander_skipped_common_gcd_attempt_summary[
                    "direct_divisor_attempt_evidence_count"
                ]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_min": (
                alexander_skipped_common_gcd_attempt_summary[
                    "direct_divisor_candidate_count_min"
                ]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_max": (
                alexander_skipped_common_gcd_attempt_summary[
                    "direct_divisor_candidate_count_max"
                ]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_divides_all_candidate_count_min": (
                alexander_skipped_common_gcd_attempt_summary[
                    "direct_divisor_divides_all_candidate_count_min"
                ]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_divides_all_candidate_count_max": (
                alexander_skipped_common_gcd_attempt_summary[
                    "direct_divisor_divides_all_candidate_count_max"
                ]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_min": (
                alexander_skipped_common_gcd_attempt_summary[
                    "direct_divisor_failed_candidate_count_min"
                ]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max": (
                alexander_skipped_common_gcd_attempt_summary[
                    "direct_divisor_failed_candidate_count_max"
                ]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed": (
                alexander_skipped_common_gcd_attempt_summary[
                    "direct_divisor_all_candidates_failed"
                ]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_first_failure": (
                alexander_skipped_common_gcd_attempt_summary[
                    "direct_divisor_first_failure"
                ]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count": (
                alexander_skipped_common_gcd_attempt_summary[
                    "support_signature_evidence_count"
                ]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count": (
                alexander_skipped_common_gcd_attempt_summary[
                    "support_signature_variant_count"
                ]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min": (
                alexander_skipped_common_gcd_attempt_summary[
                    "support_signature_input_count_min"
                ]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max": (
                alexander_skipped_common_gcd_attempt_summary[
                    "support_signature_input_count_max"
                ]
            ),
            "source_table_alexander_skipped_common_gcd_attempt_support_signature_counts": (
                alexander_skipped_common_gcd_attempt_summary[
                    "support_signature_counts"
                ]
            ),
            "source_table_alexander_source_numerator_divisibility_summary": (
                alexander_source_divisibility_summary
            ),
            "source_table_candidate_convergence_summary": (
                source_table_candidate_convergence_summary
            ),
            "source_table_candidate_convergence_partial_certified": (
                source_table_candidate_convergence_summary[
                    "partial_source_table_convergence_certified"
                ]
            ),
            "source_table_candidate_convergence_full_certified": (
                source_table_candidate_convergence_summary[
                    "full_source_table_convergence_certified"
                ]
            ),
            "source_table_candidate_convergence_certified_invariant_count": (
                source_table_candidate_convergence_summary[
                    "certified_invariant_count"
                ]
            ),
            "source_table_candidate_convergence_uncertified_invariant_count": (
                source_table_candidate_convergence_summary[
                    "uncertified_invariant_count"
                ]
            ),
            "source_table_candidate_convergence_source_value_seen_invariants": (
                source_table_candidate_convergence_summary[
                    "source_value_seen_invariants"
                ]
            ),
            "source_table_candidate_convergence_source_value_seen_invariant_count": (
                source_table_candidate_convergence_summary[
                    "source_value_seen_invariant_count"
                ]
            ),
            "source_table_candidate_convergence_source_value_seen_but_uncertified_invariants": (
                source_table_candidate_convergence_summary[
                    "source_value_seen_but_uncertified_invariants"
                ]
            ),
            "source_table_candidate_convergence_source_value_seen_but_uncertified_invariant_count": (
                source_table_candidate_convergence_summary[
                    "source_value_seen_but_uncertified_invariant_count"
                ]
            ),
            "matched_source_table_invariants": matched_source_table_invariants,
            "matched_source_table_invariant_count": len(matched_source_table_invariants),
            "uncomputed_source_table_invariants": uncomputed_source_table_invariants,
            "uncomputed_source_table_invariant_count": (
                len(uncomputed_source_table_invariants)
            ),
            "mismatched_source_table_invariants": mismatched_source_table_invariants,
            "mismatched_source_table_invariant_count": (
                len(mismatched_source_table_invariants)
            ),
            "unstable_source_table_invariants": unstable_source_table_invariants,
            "unstable_source_table_invariant_count": (
                len(unstable_source_table_invariants)
            ),
            "complete_candidate_set": complete_candidate_set,
            **registration_blocker_summary,
            "notes": [
                "source-table invariant audits compare external table values with source-Gauss-matched candidate convergence",
                "a match here is convention evidence only and does not register fixture signs or full HOMFLY/Alexander table normalization",
            ],
        }

    def source_pairwise_candidate_diagnostics(
        self,
        *,
        max_orientation_samples: int = 64,
        max_sign_patterns: int | None = None,
        max_candidates: int = 8,
        target_pairwise_linking: tuple[int | float, ...] | None = None,
    ) -> dict:
        """Scan sign patterns using source Gauss-code orientation evidence only."""

        from iroll.topology.knot_table import builtin_link_table
        from iroll.topology.pd import jones_polynomial_from_pd

        if self.pd_code is None:
            return {
                "method": "diagram_fixture_source_pairwise_candidate_diagnostics",
                "notation": self.notation,
                "skipped": True,
                "target_pairwise_linking": None,
                "gauss_code_match_required": True,
                "notes": ["fixture does not have a PD source record"],
            }
        if self.gauss_code is None:
            return {
                "method": "diagram_fixture_source_pairwise_candidate_diagnostics",
                "notation": self.notation,
                "skipped": True,
                "target_pairwise_linking": None,
                "gauss_code_match_required": True,
                "notes": ["fixture does not register a source Gauss code"],
            }
        if max_orientation_samples < 0:
            raise ValueError("max_orientation_samples must be non-negative")
        if max_sign_patterns is not None and max_sign_patterns < 0:
            raise ValueError("max_sign_patterns must be non-negative")
        if max_candidates < 0:
            raise ValueError("max_candidates must be non-negative")

        link_table_entry = next(
            (
                entry
                for entry in builtin_link_table()
                if entry["notation"] == self.notation
            ),
            None,
        )
        target = (
            tuple(float(value) for value in target_pairwise_linking)
            if target_pairwise_linking is not None
            else (
                tuple(float(value) for value in link_table_entry["pairwise_linking"])
                if link_table_entry is not None
                else None
            )
        )
        if target is None:
            return {
                "method": "diagram_fixture_source_pairwise_candidate_diagnostics",
                "notation": self.notation,
                "skipped": True,
                "target_pairwise_linking": None,
                "link_table_entry": link_table_entry,
                "gauss_code_match_required": True,
                "notes": [
                    "no target pairwise-linking signature was supplied or found in the built-in link table",
                ],
            }

        gauss_diagnostics = self.gauss_code_orientation_diagnostics(
            max_orientation_samples=max_orientation_samples,
            max_matches=max_orientation_samples,
        )
        orientation_matches = gauss_diagnostics.get("matches", [])
        all_sign_pattern_count = 2 ** len(self.pd_code)
        effective_max_sign_patterns = (
            all_sign_pattern_count
            if max_sign_patterns is None
            else max_sign_patterns
        )
        candidates = []
        considered_sign_patterns = 0
        matching_candidate_count = 0
        matching_sign_samples: dict[tuple[int, ...], set[int]] = {}

        for sign_index, signs in enumerate(product((-1, 1), repeat=len(self.pd_code))):
            if sign_index >= effective_max_sign_patterns:
                break
            considered_sign_patterns += 1
            signs = tuple(signs)
            diagram = self.diagram_with_signs(signs=signs)
            for match_index, match in enumerate(orientation_matches):
                orientation = _orientation_from_local_sample(diagram, match["sample"])
                pairwise_linking = _pd_pairwise_linking_numbers(diagram, orientation)
                if tuple(pairwise_linking) != target:
                    continue
                matching_candidate_count += 1
                matching_sign_samples.setdefault(signs, set()).add(match_index)
                if len(candidates) >= max_candidates:
                    continue
                candidate = {
                    "sample_index": match_index,
                    "source_sample_index": match["sample_index"],
                    "role_orders": match["role_orders"],
                    "signs": list(signs),
                    "mirror_signs": [-sign for sign in signs],
                    "pairwise_linking": pairwise_linking,
                    "jones_polynomial": jones_polynomial_from_pd(diagram),
                    "orientation": orientation.to_dict(),
                }
                candidate["invariant_signature"] = _candidate_invariant_signature(
                    candidate,
                )
                candidates.append(candidate)

        matching_sign_summary = _matching_sign_pattern_summary(matching_sign_samples)
        matching_sign_pattern_set = set(matching_sign_samples)
        for candidate in candidates:
            mirror_signs = tuple(-sign for sign in candidate["signs"])
            candidate["mirror_sign_pattern_present"] = (
                mirror_signs in matching_sign_pattern_set
            )

        return {
            "method": "diagram_fixture_source_pairwise_candidate_diagnostics",
            "notation": self.notation,
            "skipped": False,
            "has_signed_pd": self.has_signed_pd,
            "gauss_code_match_required": True,
            "target_pairwise_linking": list(target),
            "link_table_entry": link_table_entry,
            "orientation_sample_count": len(orientation_matches),
            "all_sign_pattern_count": all_sign_pattern_count,
            "considered_sign_pattern_count": considered_sign_patterns,
            "matching_candidate_count": matching_candidate_count,
            "returned_candidate_count": len(candidates),
            "matching_sign_summary": matching_sign_summary,
            "candidates": candidates,
            "candidate_groups": _candidate_group_summaries(candidates),
            "truncated": (
                all_sign_pattern_count > considered_sign_patterns
                or matching_candidate_count > len(candidates)
            ),
            "gauss_code_orientation_diagnostics": gauss_diagnostics,
            "notes": [
                "source pairwise candidates use only source-Gauss-code-matched orientation samples",
                "pairwise linking agreement is convention evidence, not a verified signed invariant",
                "HOMFLY and Alexander values are intentionally not computed by this lightweight report",
            ],
        }

    def orientation(self) -> PDOrientation:
        """Return explicit fixture orientation metadata when registered.

        Most signed-PD fixtures already use iroll's default role order
        `(under_in, over_in, under_out, over_out)`. Some external PD sources
        keep the cyclic PD order and need per-crossing role metadata to avoid
        rewriting the source diagram.
        """

        diagram = self.diagram()
        if self.orientation_role_orders is None:
            return PDOrientation.from_signed_pd_roles(diagram)
        try:
            return PDOrientation.from_signed_pd_role_orders(
                diagram,
                self.orientation_role_orders,
                convention="signed_pd_fixture_explicit_role_orders_v1",
            )
        except ValueError as exc:
            raise ValueError(
                f"fixture {self.notation} orientation_role_orders are invalid: {exc}"
            ) from exc

    def to_dict(self) -> dict:
        return {
            "notation": self.notation,
            "name": self.name,
            "kind": self.kind,
            "component_count": self.component_count,
            "pd_code": [list(crossing) for crossing in self.pd_code]
            if self.pd_code is not None
            else None,
            "signs": list(self.signs) if self.signs is not None else None,
            "has_pd_code": self.has_pd_code,
            "has_signed_pd": self.has_signed_pd,
            "expected_jones": self.expected_jones,
            "expected_homfly": self.expected_homfly,
            "expected_homfly_source": self.expected_homfly_source,
            "expected_homfly_notes": list(self.expected_homfly_notes),
            "expected_multivariable_alexander": self.expected_multivariable_alexander,
            "expected_multivariable_alexander_variables": (
                list(self.expected_multivariable_alexander_variables)
                if self.expected_multivariable_alexander_variables is not None
                else None
            ),
            "expected_multivariable_alexander_source": (
                self.expected_multivariable_alexander_source
            ),
            "expected_multivariable_alexander_notes": list(
                self.expected_multivariable_alexander_notes
            ),
            "source_table_jones": self.source_table_jones,
            "source_table_jones_iroll_normalized": (
                self.source_table_jones_iroll_normalized
            ),
            "source_table_homfly": self.source_table_homfly,
            "source_table_homfly_iroll_normalized": (
                self.source_table_homfly_iroll_normalized
            ),
            "source_table_multivariable_alexander": (
                self.source_table_multivariable_alexander
            ),
            "source_table_multivariable_alexander_numerator": (
                self.source_table_multivariable_alexander_numerator
            ),
            "source_table_multivariable_alexander_variables": (
                list(self.source_table_multivariable_alexander_variables)
                if self.source_table_multivariable_alexander_variables is not None
                else None
            ),
            "source_table_notes": list(self.source_table_notes),
            "orientation_role_orders": (
                [list(order) for order in self.orientation_role_orders]
                if self.orientation_role_orders is not None
                else None
            ),
            "gauss_code": (
                [list(component) for component in self.gauss_code]
                if self.gauss_code is not None
                else None
            ),
            "source": self.source,
            "source_url": self.source_url,
            "convention_notes": list(self.convention_notes),
        }


def _orientation_candidate_summary(candidate: dict) -> dict:
    return {
        "role_order": list(candidate["role_order"]),
        "role_mapping": list(candidate["role_mapping"]),
        "component_count": candidate["component_count"],
        "component_count_matches": candidate["component_count_matches"],
        "strict": candidate["strict"],
        "traversals": candidate["traversals"],
        "notes": list(candidate["notes"]),
    }


def _orientation_from_local_sample(
    diagram: PlanarDiagram,
    sample: dict,
) -> PDOrientation:
    crossings = []
    for crossing, role_order in zip(diagram.crossings, sample["role_orders"]):
        crossings.append(
            PDCrossingOrientation(
                under_in=crossing.code[role_order[0]],
                over_in=crossing.code[role_order[1]],
                under_out=crossing.code[role_order[2]],
                over_out=crossing.code[role_order[3]],
            )
        )
    edge_components = tuple(
        sorted(
            (int(label), int(component_index))
            for component_index, traversal in enumerate(sample["traversals"])
            for label in traversal["edges"]
        )
    )
    return PDOrientation(
        tuple(crossings),
        edge_components=edge_components,
        convention="signed_pd_local_role_assignment_v1",
    )


def _gauss_code_orientation_diagnostics_from_samples(
    diagram: PlanarDiagram,
    target_gauss_code: tuple[tuple[int, ...], ...],
    samples: list[dict],
    *,
    max_matches: int,
    allow_reversal: bool = False,
) -> dict:
    matches = []
    matching_sample_count = 0
    for sample_index, sample in enumerate(samples):
        orientation = _orientation_from_local_sample(diagram, sample)
        for positive_strand in ("over", "under"):
            encoded = _gauss_code_from_orientation(
                diagram,
                orientation,
                positive_strand=positive_strand,
            )
            match = _match_gauss_code_components(
                target_gauss_code,
                encoded,
                allow_reversal=allow_reversal,
            )
            if not match["matched"]:
                continue
            matching_sample_count += 1
            if len(matches) < max_matches:
                matches.append(
                    {
                        "sample_index": sample_index,
                        "strand_sign_convention": (
                            f"positive_entries_mark_{positive_strand}_strand"
                        ),
                        "encoded_gauss_code": [
                            list(component) for component in encoded
                        ],
                        "component_matches": match["component_matches"],
                        "role_orders": sample["role_orders"],
                        "traversals": sample["traversals"],
                        "sample": sample,
                    }
                )
            break

    return {
        "matched": bool(matches),
        "checked_sample_count": len(samples),
        "matching_sample_count": matching_sample_count,
        "matches": matches,
    }


def _gauss_code_from_orientation(
    diagram: PlanarDiagram,
    orientation: PDOrientation,
    *,
    positive_strand: str,
) -> tuple[tuple[int, ...], ...]:
    if positive_strand not in {"over", "under"}:
        raise ValueError("positive_strand must be 'over' or 'under'")

    incoming: dict[int, tuple[int, str]] = {}
    for crossing_index, crossing in enumerate(orientation.crossings, start=1):
        incoming[crossing.under_in] = (crossing_index, "under")
        incoming[crossing.over_in] = (crossing_index, "over")

    components = []
    for traversal in orientation.oriented_component_traversals(diagram):
        component = []
        for edge in traversal["edges"]:
            crossing_index, strand = incoming[int(edge)]
            sign = 1 if strand == positive_strand else -1
            component.append(sign * crossing_index)
        components.append(tuple(component))
    return tuple(components)


def _match_gauss_code_components(
    target: tuple[tuple[int, ...], ...],
    observed: tuple[tuple[int, ...], ...],
    *,
    allow_reversal: bool,
) -> dict:
    if len(target) != len(observed):
        return {"matched": False, "component_matches": []}

    used: set[int] = set()
    component_matches = []
    for target_index, target_component in enumerate(target):
        found = None
        for observed_index, observed_component in enumerate(observed):
            if observed_index in used:
                continue
            relation = _gauss_component_relation(
                target_component,
                observed_component,
                allow_reversal=allow_reversal,
            )
            if relation is None:
                continue
            found = {
                "target_component_index": target_index,
                "observed_component_index": observed_index,
                **relation,
            }
            break
        if found is None:
            return {"matched": False, "component_matches": component_matches}
        used.add(int(found["observed_component_index"]))
        component_matches.append(found)

    return {"matched": True, "component_matches": component_matches}


def _gauss_component_relation(
    target: tuple[int, ...],
    observed: tuple[int, ...],
    *,
    allow_reversal: bool,
) -> dict | None:
    rotation = _cyclic_rotation_offset(target, observed)
    if rotation is not None:
        return {"cyclic_shift": rotation, "reversed": False}
    if allow_reversal:
        reversed_observed = tuple(reversed(observed))
        rotation = _cyclic_rotation_offset(target, reversed_observed)
        if rotation is not None:
            return {"cyclic_shift": rotation, "reversed": True}
    return None


def _cyclic_rotation_offset(
    target: tuple[int, ...],
    observed: tuple[int, ...],
) -> int | None:
    if len(target) != len(observed):
        return None
    if not target:
        return 0
    doubled = observed + observed
    target_length = len(target)
    for offset in range(target_length):
        if doubled[offset : offset + target_length] == target:
            return offset
    return None


def _pd_pairwise_linking_numbers(
    diagram: PlanarDiagram,
    orientation: PDOrientation,
) -> list[float]:
    component_map = dict(orientation.edge_components)
    component_count = diagram.component_count or 1
    totals = {
        (first, second): 0
        for first in range(component_count)
        for second in range(first + 1, component_count)
    }
    for crossing, crossing_orientation in zip(diagram.crossings, orientation.crossings):
        under_component = component_map[crossing_orientation.under_in]
        over_component = component_map[crossing_orientation.over_in]
        if under_component == over_component:
            continue
        key = tuple(sorted((under_component, over_component)))
        totals[key] += crossing.sign
    return [
        totals[(first, second)] / 2.0
        for first in range(component_count)
        for second in range(first + 1, component_count)
    ]


def _candidate_invariant_signature(candidate: dict) -> dict:
    homfly = candidate.get("homfly") or {}
    alexander = candidate.get("multivariable_alexander") or {}
    common_gcd_attempt = alexander.get("common_gcd_attempt_evidence")
    if not isinstance(common_gcd_attempt, dict):
        common_gcd_attempt = {}
    attempt_diagnostics = common_gcd_attempt.get("attempt_diagnostics")
    if not isinstance(attempt_diagnostics, dict):
        attempt_diagnostics = {}
    direct_divisor_summary = attempt_diagnostics.get(
        "direct_scanned_minor_divisor_summary"
    )
    if not isinstance(direct_divisor_summary, dict):
        direct_divisor_summary = {}
    first_direct_divisor_failure = direct_divisor_summary.get("first_failure")
    if not isinstance(first_direct_divisor_failure, dict):
        first_direct_divisor_failure = {}
    return {
        "pairwise_linking": list(candidate["pairwise_linking"]),
        "jones_polynomial": candidate.get("jones_polynomial"),
        "homfly_polynomial": homfly.get("homfly_polynomial"),
        "homfly_skipped": homfly.get("skipped"),
        "alexander_polynomial": alexander.get("multivariable_alexander_polynomial"),
        "alexander_method": alexander.get("method"),
        "alexander_skipped": alexander.get("skipped"),
        "alexander_candidate_polynomials": list(
            alexander.get("candidate_polynomials") or []
        ),
        "alexander_notes": list(alexander.get("notes") or []),
        "alexander_common_gcd_attempt_method": common_gcd_attempt.get("method"),
        "alexander_common_gcd_attempt_claim_scope": common_gcd_attempt.get(
            "claim_scope"
        ),
        "alexander_common_gcd_attempt_status": common_gcd_attempt.get("status"),
        "alexander_common_gcd_attempt_certified": common_gcd_attempt.get("certified"),
        "alexander_common_gcd_attempt_full_invariant_certified": (
            common_gcd_attempt.get("full_invariant_certified")
        ),
        "alexander_common_gcd_attempt_input_polynomial_count": (
            common_gcd_attempt.get("input_polynomial_count")
        ),
        "alexander_common_gcd_attempt_unique_input_polynomial_count": (
            common_gcd_attempt.get("unique_input_polynomial_count")
        ),
        "alexander_common_gcd_attempt_common_integer_content": (
            common_gcd_attempt.get("common_integer_content")
        ),
        "alexander_common_gcd_attempt_candidate_methods": list(
            common_gcd_attempt.get("candidate_methods_attempted") or []
        ),
        "alexander_common_gcd_attempt_bounded_search_limits": dict(
            common_gcd_attempt.get("bounded_search_limits") or {}
        ),
        "alexander_common_gcd_attempt_common_variable_support": list(
            attempt_diagnostics.get("common_variable_support") or []
        ),
        "alexander_common_gcd_attempt_union_variable_support": list(
            attempt_diagnostics.get("union_variable_support") or []
        ),
        "alexander_common_gcd_attempt_direct_divisor_candidate_count": (
            direct_divisor_summary.get("candidate_count")
        ),
        "alexander_common_gcd_attempt_direct_divisor_divides_all_candidate_count": (
            direct_divisor_summary.get("divides_all_candidate_count")
        ),
        "alexander_common_gcd_attempt_direct_divisor_failed_candidate_count": (
            direct_divisor_summary.get("failed_candidate_count")
        ),
        "alexander_common_gcd_attempt_direct_divisor_first_failure_candidate": (
            first_direct_divisor_failure.get("candidate_polynomial")
        ),
        "alexander_common_gcd_attempt_direct_divisor_first_failure_input": (
            first_direct_divisor_failure.get("failed_input_polynomial")
        ),
        "alexander_common_gcd_attempt_notes": list(
            common_gcd_attempt.get("notes") or []
        ),
    }


def _candidate_group_summaries(candidates: list[dict]) -> list[dict]:
    groups: dict[tuple, dict] = {}
    for index, candidate in enumerate(candidates):
        signature = candidate["invariant_signature"]
        key = _jsonish_group_key(signature)
        group = groups.setdefault(
            key,
            {
                "signature": signature,
                "count": 0,
                "candidate_indices": [],
                "signs": [],
                "sample_indices": [],
            },
        )
        group["count"] += 1
        group["candidate_indices"].append(index)
        group["signs"].append(list(candidate["signs"]))
        group["sample_indices"].append(candidate["sample_index"])
    return sorted(
        groups.values(),
        key=lambda group: (-group["count"], group["candidate_indices"]),
    )


def _candidate_alexander_payload(alexander: dict) -> dict:
    payload = {
        "skipped": alexander["skipped"],
        "method": alexander["method"],
        "multivariable_alexander_polynomial": alexander[
            "multivariable_alexander_polynomial"
        ],
        "candidate_polynomials": alexander["candidate_polynomials"],
    }
    if "requires_normalization" in alexander:
        payload["requires_normalization"] = alexander["requires_normalization"]
    if "notes" in alexander:
        payload["notes"] = list(alexander.get("notes") or [])
    for key in (
        "admissible_minor_summary",
        "common_gcd_evidence",
        "common_gcd_attempt_evidence",
    ):
        value = alexander.get(key)
        if isinstance(value, dict):
            payload[key] = value
    return payload


def _candidate_alexander_skipped_common_gcd_attempt_summary(
    candidates: list[dict],
) -> dict:
    skipped_count = 0
    evidence_indices: list[int] = []
    status_counts: dict[str, int] = {}
    input_counts: list[int] = []
    unique_input_counts: list[int] = []
    common_integer_contents: list[int] = []
    candidate_methods: list[str] = []
    attempt_notes: list[str] = []
    limit_keys: dict[tuple, dict] = {}
    direct_divisor_candidate_counts: list[int] = []
    direct_divisor_divides_all_counts: list[int] = []
    direct_divisor_failed_counts: list[int] = []
    first_direct_divisor_failure: dict | None = None
    support_signature_evidence_count = 0
    support_signature_groups: dict[tuple[str, ...], dict] = {}

    for index, candidate in enumerate(candidates):
        alexander = candidate.get("multivariable_alexander")
        if not isinstance(alexander, dict) or alexander.get("skipped") is not True:
            continue
        skipped_count += 1
        evidence = alexander.get("common_gcd_attempt_evidence")
        if not isinstance(evidence, dict):
            continue
        evidence_indices.append(index)
        status = str(evidence.get("status") or "")
        if status:
            status_counts[status] = status_counts.get(status, 0) + 1
        input_count = _optional_int(evidence.get("input_polynomial_count"))
        if input_count is not None:
            input_counts.append(input_count)
        unique_input_count = _optional_int(
            evidence.get("unique_input_polynomial_count")
        )
        if unique_input_count is not None:
            unique_input_counts.append(unique_input_count)
        common_integer_content = _optional_int(evidence.get("common_integer_content"))
        if common_integer_content is not None:
            common_integer_contents.append(common_integer_content)
        for method in evidence.get("candidate_methods_attempted") or []:
            method_text = str(method)
            if method_text and method_text not in candidate_methods:
                candidate_methods.append(method_text)
        for note in evidence.get("notes") or []:
            note_text = str(note)
            if note_text and note_text not in attempt_notes:
                attempt_notes.append(note_text)
        limits = evidence.get("bounded_search_limits")
        if isinstance(limits, dict):
            limit_keys.setdefault(_jsonish_group_key(limits), limits)
        attempt_diagnostics = evidence.get("attempt_diagnostics")
        if isinstance(attempt_diagnostics, dict):
            support_rows = attempt_diagnostics.get("support_signature_counts")
            support_signature_seen = False
            if isinstance(support_rows, list):
                for row in support_rows:
                    if not isinstance(row, dict):
                        continue
                    variables_value = row.get("variables")
                    if not isinstance(variables_value, list):
                        continue
                    signature = tuple(str(variable) for variable in variables_value)
                    input_count = _optional_int(row.get("input_count"))
                    group = support_signature_groups.setdefault(
                        signature,
                        {
                            "variables": list(signature),
                            "candidate_count": 0,
                            "input_counts": [],
                        },
                    )
                    group["candidate_count"] += 1
                    if input_count is not None:
                        group["input_counts"].append(input_count)
                    support_signature_seen = True
            if support_signature_seen:
                support_signature_evidence_count += 1
            direct_summary = attempt_diagnostics.get(
                "direct_scanned_minor_divisor_summary"
            )
            if isinstance(direct_summary, dict):
                candidate_count = _optional_int(direct_summary.get("candidate_count"))
                if candidate_count is not None:
                    direct_divisor_candidate_counts.append(candidate_count)
                divides_all_count = _optional_int(
                    direct_summary.get("divides_all_candidate_count")
                )
                if divides_all_count is not None:
                    direct_divisor_divides_all_counts.append(divides_all_count)
                failed_count = _optional_int(direct_summary.get("failed_candidate_count"))
                if failed_count is not None:
                    direct_divisor_failed_counts.append(failed_count)
                failure = direct_summary.get("first_failure")
                if first_direct_divisor_failure is None and isinstance(
                    failure,
                    dict,
                ):
                    first_direct_divisor_failure = dict(failure)

    statuses = list(status_counts)
    limit_variants = list(limit_keys.values())
    direct_divisor_evidence_count = len(direct_divisor_candidate_counts)
    support_signature_counts = [
        {
            "variables": list(signature),
            "candidate_count": group["candidate_count"],
            "input_count_min": (
                min(group["input_counts"]) if group["input_counts"] else 0
            ),
            "input_count_max": (
                max(group["input_counts"]) if group["input_counts"] else 0
            ),
        }
        for signature, group in sorted(
            support_signature_groups.items(),
            key=lambda item: (item[0], item[1]["candidate_count"]),
        )
    ]
    support_signature_input_counts = [
        count
        for group in support_signature_groups.values()
        for count in group["input_counts"]
    ]
    return {
        "method": "diagram_fixture_alexander_skipped_common_gcd_attempt_summary",
        "skipped_candidate_count": skipped_count,
        "candidate_with_attempt_evidence_count": len(evidence_indices),
        "candidate_without_attempt_evidence_count": max(
            0,
            skipped_count - len(evidence_indices),
        ),
        "candidate_indices": evidence_indices,
        "statuses": statuses,
        "status_counts": [
            {"status": status, "candidate_count": status_counts[status]}
            for status in statuses
        ],
        "not_certified_candidate_count": status_counts.get("not_certified", 0),
        "all_attempts_not_certified": bool(evidence_indices)
        and len(evidence_indices) == status_counts.get("not_certified", 0),
        "input_polynomial_count_min": min(input_counts) if input_counts else 0,
        "input_polynomial_count_max": max(input_counts) if input_counts else 0,
        "unique_input_polynomial_count_min": (
            min(unique_input_counts) if unique_input_counts else 0
        ),
        "unique_input_polynomial_count_max": (
            max(unique_input_counts) if unique_input_counts else 0
        ),
        "common_integer_contents": sorted(set(common_integer_contents)),
        "candidate_methods_attempted": candidate_methods,
        "candidate_method_count": len(candidate_methods),
        "bounded_search_limit_variant_count": len(limit_variants),
        "bounded_search_limits": limit_variants[0] if len(limit_variants) == 1 else None,
        "direct_divisor_attempt_evidence_count": direct_divisor_evidence_count,
        "direct_divisor_candidate_count_min": (
            min(direct_divisor_candidate_counts)
            if direct_divisor_candidate_counts
            else 0
        ),
        "direct_divisor_candidate_count_max": (
            max(direct_divisor_candidate_counts)
            if direct_divisor_candidate_counts
            else 0
        ),
        "direct_divisor_divides_all_candidate_count_min": (
            min(direct_divisor_divides_all_counts)
            if direct_divisor_divides_all_counts
            else 0
        ),
        "direct_divisor_divides_all_candidate_count_max": (
            max(direct_divisor_divides_all_counts)
            if direct_divisor_divides_all_counts
            else 0
        ),
        "direct_divisor_failed_candidate_count_min": (
            min(direct_divisor_failed_counts) if direct_divisor_failed_counts else 0
        ),
        "direct_divisor_failed_candidate_count_max": (
            max(direct_divisor_failed_counts) if direct_divisor_failed_counts else 0
        ),
        "direct_divisor_all_candidates_failed": bool(direct_divisor_evidence_count)
        and all(count == 0 for count in direct_divisor_divides_all_counts),
        "direct_divisor_first_failure": first_direct_divisor_failure,
        "support_signature_evidence_count": support_signature_evidence_count,
        "support_signature_variant_count": len(support_signature_counts),
        "support_signature_input_count_min": (
            min(support_signature_input_counts)
            if support_signature_input_counts
            else 0
        ),
        "support_signature_input_count_max": (
            max(support_signature_input_counts)
            if support_signature_input_counts
            else 0
        ),
        "support_signature_counts": support_signature_counts,
        "notes": [
            "summary covers skipped multi-variable Alexander common-gcd attempt evidence on returned candidates",
            "full multivariate Laurent gcd and fixture-certified admissible-minor normalization remain unclaimed",
        ],
    }


def _candidate_alexander_source_divisibility_summary(
    candidates: list[dict],
    *,
    source_value: str | None,
    variables: Sequence[str],
) -> dict:
    from iroll.topology.multivariable_alexander import (
        multivariable_alexander_source_polynomial_divisibility_audit,
    )

    checked_indices: list[int] = []
    status_counts: dict[str, int] = {}
    failed_input_counts: list[int] = []
    unique_input_counts: list[int] = []
    first_failed_input_polynomial: str | None = None
    first_failed_candidate_index: int | None = None

    for index, candidate in enumerate(candidates):
        alexander = candidate.get("multivariable_alexander")
        if not isinstance(alexander, dict) or alexander.get("skipped") is not True:
            continue
        evidence = alexander.get("common_gcd_attempt_evidence")
        if not isinstance(evidence, dict):
            continue
        input_polynomials = evidence.get("unique_input_polynomials") or evidence.get(
            "input_polynomials",
        )
        if not input_polynomials:
            continue
        audit = multivariable_alexander_source_polynomial_divisibility_audit(
            source_polynomial=source_value,
            input_polynomials=[str(value) for value in input_polynomials],
            variables=variables,
        )
        alexander["source_numerator_divisibility_audit"] = audit
        checked_indices.append(index)
        status = str(audit.get("status") or "")
        if status:
            status_counts[status] = status_counts.get(status, 0) + 1
        failed_count = _optional_int(audit.get("failed_input_count"))
        if failed_count is not None:
            failed_input_counts.append(failed_count)
        unique_count = _optional_int(audit.get("unique_input_polynomial_count"))
        if unique_count is not None:
            unique_input_counts.append(unique_count)
        if first_failed_input_polynomial is None and failed_count:
            first_failed_candidate_index = index
            failed_indices = audit.get("failed_input_indices") or []
            division_records = audit.get("division_records") or []
            if failed_indices and isinstance(division_records, list):
                failed_index = int(failed_indices[0])
                if 0 <= failed_index < len(division_records):
                    record = division_records[failed_index]
                    if isinstance(record, dict):
                        first_failed_input_polynomial = str(
                            record.get("input_polynomial"),
                        )

    statuses = list(status_counts)
    checked_count = len(checked_indices)
    source_divides_all_count = status_counts.get("all_inputs_divisible", 0)
    failed_candidate_count = checked_count - source_divides_all_count
    return {
        "method": "diagram_fixture_alexander_source_numerator_divisibility_summary",
        "source_value": source_value,
        "variables": list(variables),
        "checked_candidate_count": checked_count,
        "candidate_indices": checked_indices,
        "statuses": statuses,
        "status_counts": [
            {"status": status, "candidate_count": status_counts[status]}
            for status in statuses
        ],
        "source_divides_all_candidate_count": source_divides_all_count,
        "source_division_failed_candidate_count": failed_candidate_count,
        "all_checked_candidates_divisible": bool(checked_count)
        and source_divides_all_count == checked_count,
        "failed_input_count_min": min(failed_input_counts) if failed_input_counts else 0,
        "failed_input_count_max": max(failed_input_counts) if failed_input_counts else 0,
        "unique_input_polynomial_count_min": (
            min(unique_input_counts) if unique_input_counts else 0
        ),
        "unique_input_polynomial_count_max": (
            max(unique_input_counts) if unique_input_counts else 0
        ),
        "first_failed_candidate_index": first_failed_candidate_index,
        "first_failed_input_polynomial": first_failed_input_polynomial,
        "full_invariant_certified": False,
        "notes": [
            "source numerator divisibility is checked only against skipped candidate bounded scanned Fox-minor inputs",
            "failure is negative evidence for promoting the source numerator under the current scanned-minor convention",
            "full multivariate Laurent gcd and fixture-certified admissible-minor normalization remain unclaimed",
        ],
    }


def _optional_int(value) -> int | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _jsonish_group_key(value):
    if isinstance(value, dict):
        return tuple(
            (str(key), _jsonish_group_key(child))
            for key, child in sorted(value.items(), key=lambda item: str(item[0]))
        )
    if isinstance(value, (list, tuple)):
        return tuple(_jsonish_group_key(child) for child in value)
    if isinstance(value, set):
        return tuple(sorted(_jsonish_group_key(child) for child in value))
    return value


def _candidate_convergence_summary(diagnostics: dict) -> dict:
    candidates = list(diagnostics.get("candidates", []))
    complete_candidate_set = (
        diagnostics.get("matching_candidate_count") == len(candidates)
        and not diagnostics.get("truncated", False)
    )
    invariant_summaries = {
        "jones": _candidate_value_convergence(
            candidates,
            value_getter=lambda candidate: candidate.get("jones_polynomial"),
            skipped_getter=lambda candidate: None,
            complete_candidate_set=complete_candidate_set,
        ),
        "homfly": _candidate_value_convergence(
            candidates,
            value_getter=lambda candidate: (candidate.get("homfly") or {}).get(
                "homfly_polynomial"
            ),
            skipped_getter=lambda candidate: (candidate.get("homfly") or {}).get(
                "skipped"
            ),
            complete_candidate_set=complete_candidate_set,
        ),
        "multivariable_alexander": _candidate_value_convergence(
            candidates,
            value_getter=lambda candidate: (
                candidate.get("multivariable_alexander") or {}
            ).get("multivariable_alexander_polynomial"),
            skipped_getter=lambda candidate: (
                candidate.get("multivariable_alexander") or {}
            ).get("skipped"),
            complete_candidate_set=complete_candidate_set,
        ),
    }
    stable_invariants = [
        name
        for name, summary in invariant_summaries.items()
        if summary["stable_across_complete_candidates"]
    ]
    return {
        "method": "diagram_fixture_source_invariant_candidate_convergence",
        "complete_candidate_set": complete_candidate_set,
        "matching_candidate_count": diagnostics.get("matching_candidate_count", 0),
        "returned_candidate_count": len(candidates),
        "candidate_group_count": len(diagnostics.get("candidate_groups", [])),
        "stable_invariants": stable_invariants,
        "invariants": invariant_summaries,
        "notes": [
            "convergence is computed over returned source-matched candidates",
            "stable_across_complete_candidates is true only when every matching candidate was returned and has one non-skipped value",
        ],
    }


def _signed_pd_replay_summary(diagnostics: dict) -> dict:
    candidates = list(diagnostics.get("candidates", []))
    replay_rows = []
    missing_replay_count = 0
    invalid_claim_scope_count = 0
    notation_mismatch_count = 0
    sign_mismatch_count = 0
    role_order_mismatch_count = 0
    pairwise_linking_mismatch_count = 0
    orientation_issue_count = 0
    missing_diagram_or_orientation_count = 0
    valid_replay_count = 0
    notation = diagnostics.get("notation")
    target_pairwise_linking = diagnostics.get("target_pairwise_linking")

    for index, candidate in enumerate(candidates):
        replay = candidate.get("signed_pd_input")
        if not isinstance(replay, dict):
            missing_replay_count += 1
            replay_rows.append(
                {
                    "candidate_index": index,
                    "has_replay": False,
                    "valid_replay": False,
                    "issue_codes": ["missing_signed_pd_input"],
                }
            )
            continue

        issue_codes = []
        if replay.get("claim_scope") != "source_gauss_matched_signed_pd_candidate_replay":
            invalid_claim_scope_count += 1
            issue_codes.append("invalid_claim_scope")
        if replay.get("source_notation") != notation:
            notation_mismatch_count += 1
            issue_codes.append("source_notation_mismatch")
        if replay.get("signs") != candidate.get("signs"):
            sign_mismatch_count += 1
            issue_codes.append("signs_mismatch")
        expected_role_orders = [
            list(order) for order in candidate.get("role_orders", [])
        ]
        if replay.get("role_orders") != expected_role_orders:
            role_order_mismatch_count += 1
            issue_codes.append("role_orders_mismatch")
        if (
            target_pairwise_linking is not None
            and replay.get("pairwise_linking") != target_pairwise_linking
        ):
            pairwise_linking_mismatch_count += 1
            issue_codes.append("pairwise_linking_mismatch")
        orientation_validation_issues = replay.get("orientation_validation_issues")
        if orientation_validation_issues:
            orientation_issue_count += 1
            issue_codes.append("orientation_validation_issues_present")
        if not isinstance(replay.get("diagram"), dict) or not isinstance(
            replay.get("orientation"),
            dict,
        ):
            missing_diagram_or_orientation_count += 1
            issue_codes.append("missing_diagram_or_orientation")

        valid_replay = not issue_codes
        if valid_replay:
            valid_replay_count += 1
        replay_rows.append(
            {
                "candidate_index": index,
                "has_replay": True,
                "valid_replay": valid_replay,
                "issue_codes": issue_codes,
            }
        )

    checked_candidate_count = len(candidates)
    return {
        "method": "source_gauss_matched_signed_pd_replay_summary",
        "claim_scope": "source_candidate_replay_self_consistency",
        "checked_candidate_count": checked_candidate_count,
        "valid_replay_count": valid_replay_count,
        "missing_replay_count": missing_replay_count,
        "invalid_claim_scope_count": invalid_claim_scope_count,
        "source_notation_mismatch_count": notation_mismatch_count,
        "sign_mismatch_count": sign_mismatch_count,
        "role_order_mismatch_count": role_order_mismatch_count,
        "pairwise_linking_mismatch_count": pairwise_linking_mismatch_count,
        "orientation_issue_count": orientation_issue_count,
        "missing_diagram_or_orientation_count": missing_diagram_or_orientation_count,
        "all_returned_candidates_have_valid_replay": (
            checked_candidate_count > 0
            and valid_replay_count == checked_candidate_count
        ),
        "rows": replay_rows,
        "notes": [
            "replay self-consistency covers returned source-Gauss-matched candidates only",
            "valid replay metadata is convention evidence and does not register signed fixture values",
        ],
    }


def _candidate_value_convergence(
    candidates: list[dict],
    *,
    value_getter,
    skipped_getter,
    complete_candidate_set: bool,
) -> dict:
    values = []
    skipped_count = 0
    missing_count = 0
    for candidate in candidates:
        skipped = skipped_getter(candidate)
        if skipped is True:
            skipped_count += 1
        value = value_getter(candidate)
        if value is None:
            missing_count += 1
        else:
            values.append(value)
    unique_values = list(dict.fromkeys(values))
    return {
        "computed_candidate_count": len(values),
        "skipped_candidate_count": skipped_count,
        "missing_candidate_count": missing_count,
        "unique_value_count": len(unique_values),
        "unique_values": unique_values,
        "stable_across_returned_candidates": (
            len(candidates) > 0
            and len(unique_values) == 1
            and skipped_count == 0
            and missing_count == 0
        ),
        "stable_across_complete_candidates": (
            complete_candidate_set
            and len(candidates) > 0
            and len(unique_values) == 1
            and skipped_count == 0
            and missing_count == 0
        ),
    }


def _homfly_source_table_convention_variants(source_value: str | None) -> list[dict]:
    if source_value is None:
        return []
    from iroll.topology.homfly import homfly_polynomial_convention_variants

    try:
        return [
            {
                **variant,
                "unit_normalized_polynomial": _homfly_unit_normalized_polynomial(
                    variant.get("polynomial")
                ),
            }
            for variant in homfly_polynomial_convention_variants(source_value)
        ]
    except ValueError as exc:
        return [
            {
                "name": "parse_error",
                "invert_a": False,
                "negate_z": False,
                "invert_z": False,
                "polynomial": None,
                "unit_normalized_polynomial": None,
                "error": str(exc),
            }
        ]


def _homfly_unit_normalized_polynomial(polynomial: str | None) -> str | None:
    if polynomial is None:
        return None
    from iroll.topology.polynomial import parse_multivariate_laurent_polynomial

    try:
        return (
            parse_multivariate_laurent_polynomial(polynomial, variables=("a", "z"))
            .normalize_unit()
            .format()
        )
    except ValueError:
        return None


_SOURCE_TABLE_HOMFLY_VARIANT_RESOLUTION_STATUS_CODES = {
    "": 0,
    "no_source_value": 1,
    "not_computed": 2,
    "source_value_seen": 3,
    "source_variant_seen": 4,
    "source_value_unit_normalized_seen": 5,
    "source_variant_unit_normalized_seen": 6,
    "source_variants_missed": 7,
}


def _source_table_homfly_variant_resolution_status_code(status: str) -> int:
    return _SOURCE_TABLE_HOMFLY_VARIANT_RESOLUTION_STATUS_CODES.get(status, 0)


_SOURCE_TABLE_SOURCE_MATCH_RESOLUTION_STATUS_CODES = {
    "": 0,
    "no_source_value": 1,
    "not_computed": 2,
    "complete_source_match": 3,
    "returned_source_match_incomplete": 4,
    "source_seen_with_incomplete_candidates": 5,
    "source_seen_unstable": 6,
    "candidate_values_missing_or_skipped": 7,
    "source_missed_with_candidates": 8,
}


def _source_table_source_match_resolution_status_code(status: str) -> int:
    return _SOURCE_TABLE_SOURCE_MATCH_RESOLUTION_STATUS_CODES.get(status, 0)


def _source_table_source_match_resolution_status(
    *,
    source_value_present: bool,
    computed_candidate_count: int,
    missing_candidate_count: int,
    skipped_candidate_count: int,
    stable_across_complete_candidates: bool,
    stable_across_returned_candidates: bool,
    source_value_seen: bool,
) -> str:
    if not source_value_present:
        return "no_source_value"
    if computed_candidate_count <= 0:
        return "not_computed"
    if stable_across_complete_candidates and source_value_seen:
        return "complete_source_match"
    if stable_across_returned_candidates and source_value_seen:
        return "returned_source_match_incomplete"
    if source_value_seen and (missing_candidate_count > 0 or skipped_candidate_count > 0):
        return "source_seen_with_incomplete_candidates"
    if source_value_seen:
        return "source_seen_unstable"
    if missing_candidate_count > 0 or skipped_candidate_count > 0:
        return "candidate_values_missing_or_skipped"
    return "source_missed_with_candidates"


def _source_table_source_match_resolution_fields(
    *,
    source_value_present: bool,
    computed_candidate_count: int,
    missing_candidate_count: int,
    skipped_candidate_count: int,
    stable_across_complete_candidates: bool,
    stable_across_returned_candidates: bool,
    source_value_seen: bool,
) -> dict[str, int | str]:
    status = _source_table_source_match_resolution_status(
        source_value_present=source_value_present,
        computed_candidate_count=computed_candidate_count,
        missing_candidate_count=missing_candidate_count,
        skipped_candidate_count=skipped_candidate_count,
        stable_across_complete_candidates=stable_across_complete_candidates,
        stable_across_returned_candidates=stable_across_returned_candidates,
        source_value_seen=source_value_seen,
    )
    return {
        "source_match_resolution_status": status,
        "source_match_resolution_status_code": (
            _source_table_source_match_resolution_status_code(status)
        ),
    }


def _source_table_homfly_variant_resolution_status(
    *,
    source_value_present: bool,
    computed_candidate_count: int,
    source_value_seen: bool,
    source_value_seen_variant_count: int,
    source_value_seen_after_unit_normalization: bool,
    source_value_seen_unit_normalized_variant_count: int,
) -> str:
    if not source_value_present:
        return "no_source_value"
    if computed_candidate_count <= 0:
        return "not_computed"
    if source_value_seen:
        return "source_value_seen"
    if source_value_seen_variant_count > 0:
        return "source_variant_seen"
    if source_value_seen_after_unit_normalization:
        return "source_value_unit_normalized_seen"
    if source_value_seen_unit_normalized_variant_count > 0:
        return "source_variant_unit_normalized_seen"
    return "source_variants_missed"


def _source_table_homfly_variant_resolution_fields(
    *,
    source_value_present: bool,
    computed_candidate_count: int,
    source_value_seen: bool,
    source_value_seen_variant_count: int,
    source_value_seen_after_unit_normalization: bool,
    source_value_seen_unit_normalized_variant_count: int,
) -> dict[str, int | str]:
    status = _source_table_homfly_variant_resolution_status(
        source_value_present=source_value_present,
        computed_candidate_count=computed_candidate_count,
        source_value_seen=source_value_seen,
        source_value_seen_variant_count=source_value_seen_variant_count,
        source_value_seen_after_unit_normalization=(
            source_value_seen_after_unit_normalization
        ),
        source_value_seen_unit_normalized_variant_count=(
            source_value_seen_unit_normalized_variant_count
        ),
    )
    return {
        "source_value_variant_resolution_status": status,
        "source_value_variant_resolution_status_code": (
            _source_table_homfly_variant_resolution_status_code(status)
        ),
    }

def _source_table_homfly_variant_miss_witness_summary(
    *,
    source_value: str | None,
    source_value_unit_normalized: str | None,
    candidate_unique_values: list,
    candidate_unit_normalized_values: list,
    variant_records: list[dict],
    variant_resolution_status: str,
) -> dict:
    witness_limit = _SOURCE_TABLE_HOMFLY_VARIANT_MISS_WITNESS_LIMIT
    candidate_unique_value_count = len(candidate_unique_values)
    candidate_unit_normalized_value_count = len(candidate_unit_normalized_values)
    source_variant_count = len(variant_records)
    source_variant_seen_count = sum(
        1 for variant in variant_records if variant.get("source_value_seen", False)
    )
    source_unit_normalized_variant_count = sum(
        1
        for variant in variant_records
        if variant.get("unit_normalized_polynomial") is not None
    )
    source_unit_normalized_variant_seen_count = sum(
        1
        for variant in variant_records
        if variant.get("source_value_seen_after_unit_normalization", False)
    )
    missed_variants = (
        [
            variant
            for variant in variant_records
            if not variant.get("source_value_seen", False)
            and not variant.get("source_value_seen_after_unit_normalization", False)
        ]
        if variant_resolution_status == "source_variants_missed"
        else []
    )
    first_candidate_value = (
        str(candidate_unique_values[0]) if candidate_unique_values else None
    )
    first_candidate_unit_normalized_value = (
        str(candidate_unit_normalized_values[0])
        if candidate_unit_normalized_values
        else None
    )
    witnesses = [
        {
            "variant_name": str(variant.get("name") or ""),
            "variant_polynomial": variant.get("polynomial"),
            "variant_unit_normalized_polynomial": variant.get(
                "unit_normalized_polynomial"
            ),
            "source_value_seen": bool(variant.get("source_value_seen", False)),
            "source_value_seen_after_unit_normalization": bool(
                variant.get("source_value_seen_after_unit_normalization", False)
            ),
            "candidate_unique_value_count": candidate_unique_value_count,
            "candidate_unit_normalized_value_count": (
                candidate_unit_normalized_value_count
            ),
            "first_candidate_value": first_candidate_value,
            "first_candidate_unit_normalized_value": (
                first_candidate_unit_normalized_value
            ),
        }
        for variant in missed_variants[:witness_limit]
    ]
    witness_count = len(missed_variants)
    return {
        "method": "source_table_homfly_variant_miss_witness_summary",
        "claim_scope": "source_table_homfly_convention_mismatch_audit",
        "source_value_variant_resolution_status": variant_resolution_status,
        "source_value": source_value,
        "source_value_unit_normalized": source_value_unit_normalized,
        "candidate_unique_value_count": candidate_unique_value_count,
        "candidate_unit_normalized_value_count": candidate_unit_normalized_value_count,
        "source_variant_count": source_variant_count,
        "source_variant_seen_count": source_variant_seen_count,
        "source_variant_miss_count": max(
            0,
            source_variant_count - source_variant_seen_count,
        ),
        "source_unit_normalized_variant_count": source_unit_normalized_variant_count,
        "source_unit_normalized_variant_seen_count": (
            source_unit_normalized_variant_seen_count
        ),
        "source_unit_normalized_variant_miss_count": max(
            0,
            source_unit_normalized_variant_count
            - source_unit_normalized_variant_seen_count,
        ),
        "variant_miss_witness_count": witness_count,
        "variant_miss_witness_limit": witness_limit,
        "variant_miss_witness_truncated": witness_count > witness_limit,
        "variant_miss_witnesses": witnesses,
        "first_variant_miss_witness": witnesses[0] if witnesses else None,
        "full_table_normalization_certified": False,
        "registered_fixture_invariant_claim": False,
        "notes": [
            "bounded source-table HOMFLY convention-variant miss audit only",
        ]
        if witness_count
        else [],
    }

def _source_table_candidate_comparison(
    candidate_summary: dict | None,
    *,
    source_value: str | None,
    source_value_raw: str | None,
    normalization: str,
    source_value_variants: list[dict] | None = None,
) -> dict:
    tracks_homfly_variants = source_value_variants is not None
    variant_records = [
        {
            "name": str(variant.get("name")),
            "invert_a": bool(variant.get("invert_a", False)),
            "negate_z": bool(variant.get("negate_z", False)),
            "invert_z": bool(variant.get("invert_z", False)),
            "polynomial": variant.get("polynomial"),
            "unit_normalized_polynomial": variant.get(
                "unit_normalized_polynomial"
            ),
            **({"error": str(variant["error"])} if "error" in variant else {}),
        }
        for variant in (source_value_variants or [])
    ]
    source_value_unit_normalized = (
        _homfly_unit_normalized_polynomial(source_value)
        if source_value_variants
        else None
    )
    source_value_unit_normalized_variant_count = sum(
        1
        for variant in variant_records
        if variant.get("unit_normalized_polynomial") is not None
    )
    if candidate_summary is None:
        source_match_resolution_fields = _source_table_source_match_resolution_fields(
            source_value_present=source_value is not None,
            computed_candidate_count=0,
            missing_candidate_count=0,
            skipped_candidate_count=0,
            stable_across_complete_candidates=False,
            stable_across_returned_candidates=False,
            source_value_seen=False,
        )
        homfly_variant_resolution_fields = (
            _source_table_homfly_variant_resolution_fields(
                source_value_present=source_value is not None,
                computed_candidate_count=0,
                source_value_seen=False,
                source_value_seen_variant_count=0,
                source_value_seen_after_unit_normalization=False,
                source_value_seen_unit_normalized_variant_count=0,
            )
            if tracks_homfly_variants
            else {}
        )
        homfly_variant_miss_witness_summary = (
            _source_table_homfly_variant_miss_witness_summary(
                source_value=source_value,
                source_value_unit_normalized=source_value_unit_normalized,
                candidate_unique_values=[],
                candidate_unit_normalized_values=[],
                variant_records=[
                    {**variant, "source_value_seen": False}
                    for variant in variant_records
                ],
                variant_resolution_status=str(
                    homfly_variant_resolution_fields.get(
                        "source_value_variant_resolution_status",
                        "",
                    )
                ),
            )
            if tracks_homfly_variants
            else None
        )
        return {
            "source_value": source_value,
            "source_value_raw": source_value_raw,
            "source_value_unit_normalized": source_value_unit_normalized,
            "normalization": normalization,
            "source_value_present": source_value is not None,
            "source_value_seen": False,
            "computed_candidate_count": 0,
            "skipped_candidate_count": 0,
            "missing_candidate_count": 0,
            "candidate_unique_values": [],
            "candidate_unique_value_count": 0,
            "candidate_unit_normalized_values": [],
            "candidate_unit_normalized_value_count": 0,
            "stable_across_complete_candidates": False,
            "stable_across_returned_candidates": False,
            "complete_candidate_source_match": False,
            "returned_candidate_source_match": False,
            **source_match_resolution_fields,
            "source_value_variant_count": len(variant_records),
            "source_value_variants": [
                {**variant, "source_value_seen": False}
                for variant in variant_records
            ],
            "source_value_seen_variant_names": [],
            "source_value_seen_variant_count": 0,
            "source_value_any_variant_seen": False,
            "source_value_seen_after_unit_normalization": False,
            "source_value_unit_normalized_variant_count": (
                source_value_unit_normalized_variant_count
            ),
            "source_value_seen_unit_normalized_variant_names": [],
            "source_value_seen_unit_normalized_variant_count": 0,
            "source_value_any_unit_normalized_variant_seen": False,
            **homfly_variant_resolution_fields,
            "source_value_variant_miss_witness_summary": (
                homfly_variant_miss_witness_summary
            ),
            "notes": ["candidate convergence summary is unavailable"],
        }

    unique_values = list(candidate_summary.get("unique_values", []))
    unique_value_set = set(unique_values)
    candidate_unit_normalized_values = (
        sorted(
            {
                normalized
                for value in unique_values
                for normalized in [_homfly_unit_normalized_polynomial(str(value))]
                if normalized is not None
            }
        )
        if source_value_variants
        else []
    )
    candidate_unit_normalized_value_set = set(candidate_unit_normalized_values)
    source_value_seen = source_value is not None and source_value in unique_values
    source_value_seen_after_unit_normalization = (
        source_value_unit_normalized is not None
        and source_value_unit_normalized in candidate_unit_normalized_value_set
    )
    variant_records = [
        {
            **variant,
            "source_value_seen": (
                variant.get("polynomial") is not None
                and variant.get("polynomial") in unique_value_set
            ),
            "source_value_seen_after_unit_normalization": (
                variant.get("unit_normalized_polynomial") is not None
                and variant.get("unit_normalized_polynomial")
                in candidate_unit_normalized_value_set
            ),
        }
        for variant in variant_records
    ]
    source_value_seen_variant_names = [
        str(variant["name"])
        for variant in variant_records
        if variant["source_value_seen"]
    ]
    source_value_seen_unit_normalized_variant_names = [
        str(variant["name"])
        for variant in variant_records
        if variant["source_value_seen_after_unit_normalization"]
    ]
    stable_complete = bool(
        candidate_summary.get("stable_across_complete_candidates", False)
    )
    stable_returned = bool(
        candidate_summary.get("stable_across_returned_candidates", False)
    )
    notes = []
    if source_value is None:
        notes.append("source table does not provide a normalized comparison value")
    if not source_value_seen and source_value is not None:
        notes.append("normalized source value was not seen among candidate values")
    if (
        source_value_variants
        and source_value is not None
        and not source_value_seen
        and int(candidate_summary.get("computed_candidate_count", 0) or 0) > 0
    ):
        if source_value_seen_variant_names:
            notes.append(
                "a normalized source convention variant was seen among candidate values"
            )
        else:
            notes.append(
                "no normalized source convention variant was seen among candidate values"
            )
        if source_value_seen_unit_normalized_variant_names:
            notes.append(
                "a source convention variant matched after Laurent-unit normalization"
            )
        else:
            notes.append(
                "no source convention variant matched after Laurent-unit normalization"
            )
    if source_value_seen and not stable_complete:
        notes.append(
            "normalized source value appears, but candidates are not fully stable across the complete returned set"
        )
    if stable_complete and source_value_seen:
        notes.append("complete source-matched candidate set converges to the normalized source value")
    computed_candidate_count = int(
        candidate_summary.get("computed_candidate_count", 0) or 0
    )
    skipped_candidate_count = int(
        candidate_summary.get("skipped_candidate_count", 0) or 0
    )
    missing_candidate_count = int(
        candidate_summary.get("missing_candidate_count", 0) or 0
    )
    homfly_variant_resolution_fields = (
        _source_table_homfly_variant_resolution_fields(
            source_value_present=source_value is not None,
            computed_candidate_count=computed_candidate_count,
            source_value_seen=source_value_seen,
            source_value_seen_variant_count=len(source_value_seen_variant_names),
            source_value_seen_after_unit_normalization=(
                source_value_seen_after_unit_normalization
            ),
            source_value_seen_unit_normalized_variant_count=len(
                source_value_seen_unit_normalized_variant_names
            ),
        )
        if tracks_homfly_variants
        else {}
    )
    homfly_variant_miss_witness_summary = (
        _source_table_homfly_variant_miss_witness_summary(
            source_value=source_value,
            source_value_unit_normalized=source_value_unit_normalized,
            candidate_unique_values=unique_values,
            candidate_unit_normalized_values=candidate_unit_normalized_values,
            variant_records=variant_records,
            variant_resolution_status=str(
                homfly_variant_resolution_fields.get(
                    "source_value_variant_resolution_status",
                    "",
                )
            ),
        )
        if tracks_homfly_variants
        else None
    )
    source_match_resolution_fields = _source_table_source_match_resolution_fields(
        source_value_present=source_value is not None,
        computed_candidate_count=computed_candidate_count,
        missing_candidate_count=missing_candidate_count,
        skipped_candidate_count=skipped_candidate_count,
        stable_across_complete_candidates=stable_complete,
        stable_across_returned_candidates=stable_returned,
        source_value_seen=source_value_seen,
    )
    return {
        "source_value": source_value,
        "source_value_raw": source_value_raw,
        "source_value_unit_normalized": source_value_unit_normalized,
        "normalization": normalization,
        "source_value_present": source_value is not None,
        "source_value_seen": source_value_seen,
        "computed_candidate_count": computed_candidate_count,
        "skipped_candidate_count": skipped_candidate_count,
        "missing_candidate_count": missing_candidate_count,
        "candidate_unique_values": unique_values,
        "candidate_unique_value_count": len(unique_values),
        "candidate_unit_normalized_values": candidate_unit_normalized_values,
        "candidate_unit_normalized_value_count": len(candidate_unit_normalized_values),
        "stable_across_complete_candidates": stable_complete,
        "stable_across_returned_candidates": stable_returned,
        "complete_candidate_source_match": stable_complete and source_value_seen,
        "returned_candidate_source_match": stable_returned and source_value_seen,
        **source_match_resolution_fields,
        "source_value_variant_count": len(variant_records),
        "source_value_variants": variant_records,
        "source_value_seen_variant_names": source_value_seen_variant_names,
        "source_value_seen_variant_count": len(source_value_seen_variant_names),
        "source_value_any_variant_seen": bool(source_value_seen_variant_names),
        "source_value_seen_after_unit_normalization": (
            source_value_seen_after_unit_normalization
        ),
        "source_value_unit_normalized_variant_count": (
            source_value_unit_normalized_variant_count
        ),
        "source_value_seen_unit_normalized_variant_names": (
            source_value_seen_unit_normalized_variant_names
        ),
        "source_value_seen_unit_normalized_variant_count": len(
            source_value_seen_unit_normalized_variant_names
        ),
        "source_value_any_unit_normalized_variant_seen": bool(
            source_value_seen_unit_normalized_variant_names
        ),
        **homfly_variant_resolution_fields,
        "source_value_variant_miss_witness_summary": (
            homfly_variant_miss_witness_summary
        ),
        "notes": notes,
    }


def _source_table_candidate_match_summary(
    candidates: list[dict],
    comparisons: dict[str, dict],
    *,
    max_top_candidates: int = 16,
) -> dict:
    source_value_names = [
        name
        for name, comparison in comparisons.items()
        if comparison.get("source_value_present") is True
    ]
    records = []
    for index, candidate in enumerate(candidates):
        matched = []
        mismatched = []
        missing = []
        skipped = []
        for name in source_value_names:
            comparison = comparisons[name]
            source_value = comparison.get("source_value")
            value, was_skipped = _candidate_source_table_value(candidate, name)
            if was_skipped is True:
                skipped.append(name)
                continue
            if value is None:
                missing.append(name)
                continue
            if value == source_value:
                matched.append(name)
            else:
                mismatched.append(name)
        computed_compatible = bool(matched) and not mismatched
        complete_compatible = (
            len(source_value_names) > 0
            and len(matched) == len(source_value_names)
            and not mismatched
            and not missing
            and not skipped
        )
        record = {
            "candidate_index": index,
            "sample_index": candidate.get("sample_index"),
            "source_sample_index": candidate.get("source_sample_index"),
            "signs": list(candidate.get("signs", [])),
            "matched_source_values": matched,
            "mismatched_source_values": mismatched,
            "missing_source_values": missing,
            "skipped_source_values": skipped,
            "matched_source_value_count": len(matched),
            "mismatched_source_value_count": len(mismatched),
            "missing_source_value_count": len(missing),
            "skipped_source_value_count": len(skipped),
            "computed_source_compatible": computed_compatible,
            "complete_source_compatible": complete_compatible,
        }
        records.append(record)

    def unique_sign_patterns(rows: list[dict]) -> list[list[int]]:
        patterns: list[list[int]] = []
        for row in rows:
            signs = list(row["signs"])
            if signs not in patterns:
                patterns.append(signs)
        return patterns

    candidate_unique_sign_patterns = unique_sign_patterns(records)
    compatible_records = [
        record for record in records if record["computed_source_compatible"]
    ]
    complete_records = [
        record for record in records if record["complete_source_compatible"]
    ]
    top_candidates = sorted(
        compatible_records,
        key=lambda record: (
            -record["matched_source_value_count"],
            record["mismatched_source_value_count"],
            record["missing_source_value_count"] + record["skipped_source_value_count"],
            record["candidate_index"],
        ),
    )[:max_top_candidates]
    top_candidate_unique_sign_patterns = []
    for record in top_candidates:
        signs = list(record["signs"])
        if signs not in top_candidate_unique_sign_patterns:
            top_candidate_unique_sign_patterns.append(signs)
    max_matched = max(
        (record["matched_source_value_count"] for record in records),
        default=0,
    )
    max_matched_all_candidates = sorted(
        [
            record
            for record in records
            if max_matched > 0
            and record["matched_source_value_count"] == max_matched
        ],
        key=lambda record: (
            record["mismatched_source_value_count"],
            record["missing_source_value_count"] + record["skipped_source_value_count"],
            record["candidate_index"],
        ),
    )
    max_matched_candidates = max_matched_all_candidates[:max_top_candidates]
    max_matched_candidate_unique_sign_patterns = []
    for record in max_matched_candidates:
        signs = list(record["signs"])
        if signs not in max_matched_candidate_unique_sign_patterns:
            max_matched_candidate_unique_sign_patterns.append(signs)
    computed_source_compatible_unique_sign_patterns = unique_sign_patterns(
        compatible_records
    )
    complete_source_compatible_unique_sign_patterns = unique_sign_patterns(
        complete_records
    )
    max_matched_candidate_total_unique_sign_patterns = unique_sign_patterns(
        max_matched_all_candidates
    )
    return {
        "method": "diagram_fixture_source_table_candidate_match_summary",
        "source_value_comparison_count": len(source_value_names),
        "source_value_names": source_value_names,
        "candidate_count": len(records),
        "candidate_unique_sign_pattern_count": len(candidate_unique_sign_patterns),
        "candidate_unique_sign_patterns": candidate_unique_sign_patterns,
        "computed_source_compatible_candidate_count": len(compatible_records),
        "computed_source_compatible_unique_sign_pattern_count": len(
            computed_source_compatible_unique_sign_patterns
        ),
        "computed_source_compatible_unique_sign_patterns": (
            computed_source_compatible_unique_sign_patterns
        ),
        "complete_source_compatible_candidate_count": len(complete_records),
        "complete_source_compatible_unique_sign_pattern_count": len(
            complete_source_compatible_unique_sign_patterns
        ),
        "complete_source_compatible_unique_sign_patterns": (
            complete_source_compatible_unique_sign_patterns
        ),
        "max_matched_source_value_count": max_matched,
        "max_matched_candidate_total_count": len(max_matched_all_candidates),
        "max_matched_candidate_total_unique_sign_pattern_count": len(
            max_matched_candidate_total_unique_sign_patterns
        ),
        "max_matched_candidate_total_unique_sign_patterns": (
            max_matched_candidate_total_unique_sign_patterns
        ),
        "max_matched_candidate_count": len(max_matched_candidates),
        "max_matched_candidate_unique_sign_pattern_count": len(
            max_matched_candidate_unique_sign_patterns
        ),
        "max_matched_candidate_unique_sign_patterns": (
            max_matched_candidate_unique_sign_patterns
        ),
        "max_matched_candidates": max_matched_candidates,
        "top_candidate_count": len(top_candidates),
        "top_candidate_unique_sign_pattern_count": len(
            top_candidate_unique_sign_patterns
        ),
        "top_candidate_unique_sign_patterns": top_candidate_unique_sign_patterns,
        "top_candidates": top_candidates,
        "notes": [
            "computed_source_compatible candidates have no mismatch among source-table values that were computed for that candidate",
            "complete_source_compatible requires every normalized source-table value to be computed and matched",
        ],
    }


def _source_table_candidate_convergence_summary(
    *,
    complete_candidate_set: bool,
    comparisons: dict[str, dict],
    matched_source_table_invariants: list[str],
    uncomputed_source_table_invariants: list[str],
    mismatched_source_table_invariants: list[str],
    unstable_source_table_invariants: list[str],
) -> dict:
    source_value_names = [
        name
        for name, comparison in comparisons.items()
        if comparison.get("source_value_present") is True
    ]
    source_value_seen_invariants = [
        name
        for name in source_value_names
        if comparisons[name].get("source_value_seen") is True
    ]
    source_value_seen_but_uncertified_invariants = [
        name
        for name in source_value_seen_invariants
        if name not in matched_source_table_invariants
    ]
    uncertified_invariants = [
        *uncomputed_source_table_invariants,
        *mismatched_source_table_invariants,
        *unstable_source_table_invariants,
    ]
    certified_count = len(matched_source_table_invariants)
    source_value_count = len(source_value_names)
    partial_certified = bool(complete_candidate_set and certified_count > 0)
    full_certified = bool(
        complete_candidate_set
        and source_value_count > 0
        and certified_count == source_value_count
        and not uncertified_invariants
    )
    notes = [
        "source-table candidate convergence is convention evidence only",
        "partial certification records stable complete-candidate matches without registering fixture signs",
    ]
    if not complete_candidate_set:
        notes.append("candidate set is incomplete under the bounded scan")
    if uncertified_invariants:
        notes.append(
            "uncertified source-table invariants remain: "
            + ",".join(uncertified_invariants)
        )
    return {
        "method": "diagram_fixture_source_table_candidate_convergence_summary",
        "claim_scope": "source_table_candidate_convergence",
        "complete_candidate_set": complete_candidate_set,
        "source_value_comparison_count": source_value_count,
        "source_value_seen_invariants": source_value_seen_invariants,
        "source_value_seen_invariant_count": len(source_value_seen_invariants),
        "source_value_seen_but_uncertified_invariants": (
            source_value_seen_but_uncertified_invariants
        ),
        "source_value_seen_but_uncertified_invariant_count": len(
            source_value_seen_but_uncertified_invariants
        ),
        "certified_invariants": list(matched_source_table_invariants),
        "certified_invariant_count": certified_count,
        "uncertified_invariants": uncertified_invariants,
        "uncertified_invariant_count": len(uncertified_invariants),
        "uncomputed_invariants": list(uncomputed_source_table_invariants),
        "uncomputed_invariant_count": len(uncomputed_source_table_invariants),
        "mismatched_invariants": list(mismatched_source_table_invariants),
        "mismatched_invariant_count": len(mismatched_source_table_invariants),
        "unstable_invariants": list(unstable_source_table_invariants),
        "unstable_invariant_count": len(unstable_source_table_invariants),
        "partial_source_table_convergence_certified": partial_certified,
        "full_source_table_convergence_certified": full_certified,
        "notes": notes,
    }


def _source_table_registration_blocker_summary(
    *,
    has_signed_pd: bool,
    registered_fixture_invariant_claim: bool,
    complete_candidate_set: bool,
    uncomputed_source_table_invariants: list[str],
    mismatched_source_table_invariants: list[str],
    unstable_source_table_invariants: list[str],
    complete_source_compatible_unique_sign_pattern_count: int,
) -> dict[str, object]:
    blockers: list[str] = []
    details: dict[str, object] = {}

    def add_blocker(code: str, detail: object | None = None) -> None:
        blockers.append(code)
        if detail is not None:
            details[code] = detail

    if not has_signed_pd:
        add_blocker("fixture_signs_not_registered")
    if not registered_fixture_invariant_claim:
        add_blocker("registered_fixture_invariant_claim_disabled")
    if not complete_candidate_set:
        add_blocker("candidate_set_incomplete")
    if uncomputed_source_table_invariants:
        add_blocker(
            "source_table_values_uncomputed",
            list(uncomputed_source_table_invariants),
        )
    if mismatched_source_table_invariants:
        add_blocker(
            "source_table_values_mismatched",
            list(mismatched_source_table_invariants),
        )
    if unstable_source_table_invariants:
        add_blocker(
            "source_table_values_unstable",
            list(unstable_source_table_invariants),
        )
    if complete_source_compatible_unique_sign_pattern_count != 1:
        add_blocker(
            "source_compatible_sign_pattern_not_unique",
            {
                "complete_source_compatible_unique_sign_pattern_count": (
                    complete_source_compatible_unique_sign_pattern_count
                ),
            },
        )

    return {
        "source_table_registration_ready": len(blockers) == 0,
        "source_table_registration_blockers": blockers,
        "source_table_registration_blocker_count": len(blockers),
        "source_table_registration_blocker_details": details,
    }


def _candidate_source_table_value(candidate: dict, name: str) -> tuple[str | None, bool]:
    if name == "jones":
        return candidate.get("jones_polynomial"), False
    if name == "homfly":
        homfly = candidate.get("homfly")
        if isinstance(homfly, dict):
            return homfly.get("homfly_polynomial"), bool(homfly.get("skipped", False))
        return None, False
    if name == "multivariable_alexander_numerator":
        alexander = candidate.get("multivariable_alexander")
        if isinstance(alexander, dict):
            return (
                alexander.get("multivariable_alexander_polynomial"),
                bool(alexander.get("skipped", False)),
            )
        return None, False
    return None, False


def _matching_sign_pattern_summary(
    matching_sign_samples: dict[tuple[int, ...], set[int]],
    *,
    max_reported_sign_patterns: int = 64,
    max_reported_mirror_pairs: int = 64,
) -> dict:
    """Summarize all matching signs without computing heavy invariants for each one."""

    sorted_patterns = sorted(matching_sign_samples)
    sign_pattern_records = [
        {
            "signs": list(signs),
            "matching_sample_indices": sorted(matching_sign_samples[signs]),
            "matching_candidate_count": len(matching_sign_samples[signs]),
        }
        for signs in sorted_patterns[:max_reported_sign_patterns]
    ]
    per_sample_counts: dict[int, int] = {}
    for sample_indices in matching_sign_samples.values():
        for sample_index in sample_indices:
            per_sample_counts[sample_index] = per_sample_counts.get(sample_index, 0) + 1

    pattern_set = set(sorted_patterns)
    mirror_pairs = []
    seen: set[tuple[int, ...]] = set()
    for signs in sorted_patterns:
        if signs in seen:
            continue
        mirrored = tuple(-sign for sign in signs)
        canonical = min(signs, mirrored)
        mirrored_canonical = tuple(-sign for sign in canonical)
        mirror_pairs.append(
            {
                "canonical_signs": list(canonical),
                "mirrored_signs": list(mirrored_canonical),
                "canonical_present": canonical in pattern_set,
                "mirrored_present": mirrored_canonical in pattern_set,
                "canonical_sample_indices": sorted(
                    matching_sign_samples.get(canonical, set())
                ),
                "mirrored_sample_indices": sorted(
                    matching_sign_samples.get(mirrored_canonical, set())
                ),
            }
        )
        seen.add(signs)
        seen.add(mirrored)

    reported_mirror_pairs = mirror_pairs[:max_reported_mirror_pairs]
    mirror_pair_all_present_count = sum(
        1
        for pair in mirror_pairs
        if pair["canonical_present"] and pair["mirrored_present"]
    )
    return {
        "method": "matching_sign_pattern_summary",
        "unique_sign_pattern_count": len(sorted_patterns),
        "reported_sign_pattern_count": len(sign_pattern_records),
        "sign_patterns_truncated": len(sorted_patterns) > len(sign_pattern_records),
        "sign_patterns": sign_pattern_records,
        "per_sample_matching_counts": [
            {
                "sample_index": sample_index,
                "matching_sign_pattern_count": per_sample_counts[sample_index],
            }
            for sample_index in sorted(per_sample_counts)
        ],
        "mirror_pair_count": len(mirror_pairs),
        "reported_mirror_pair_count": len(reported_mirror_pairs),
        "mirror_pairs_truncated": len(mirror_pairs) > len(reported_mirror_pairs),
        "mirror_pair_all_present_count": mirror_pair_all_present_count,
        "all_mirror_pairs_present": mirror_pair_all_present_count == len(mirror_pairs),
        "mirror_pairs": reported_mirror_pairs,
        "notes": [
            "mirror sign pairing flips every crossing sign and does not prove table identity",
            "this summary avoids heavy invariant evaluation for every matching candidate",
        ],
    }


STANDARD_DIAGRAM_FIXTURES = [
    DiagramFixture(
        notation="0_1",
        name="unknot",
        kind="knot",
        component_count=1,
        pd_code=(),
        signs=(),
        expected_jones="1",
        expected_homfly="1",
        expected_homfly_source="iroll HOMFLY normalization",
        expected_homfly_notes=("P(unknot)=1 by convention",),
        expected_multivariable_alexander="1",
        expected_multivariable_alexander_variables=("t",),
        expected_multivariable_alexander_source=(
            "iroll zero-crossing Alexander terminal normalization"
        ),
        expected_multivariable_alexander_notes=(
            "zero-crossing unknot terminal equals 1 by convention",
            "no Wirtinger/Fox presentation exists for a zero-crossing diagram",
        ),
        convention_notes=("zero-crossing unknot normalization",),
    ),
    DiagramFixture(
        notation="L0a1",
        name="two-component unlink",
        kind="link",
        component_count=2,
        pd_code=(),
        signs=(),
        expected_homfly="-a^-1*z^-1 + a*z^-1",
        expected_homfly_source="iroll HOMFLY split-union normalization",
        expected_homfly_notes=("two-component unlink equals ((a - a^-1) / z)",),
        expected_multivariable_alexander="0",
        expected_multivariable_alexander_variables=("t1", "t2"),
        expected_multivariable_alexander_source=(
            "iroll zero-crossing Alexander terminal normalization"
        ),
        expected_multivariable_alexander_notes=(
            "zero-crossing multi-component unlink terminal equals 0 under the current iroll convention",
            "no Wirtinger/Fox presentation exists for a zero-crossing diagram",
        ),
        convention_notes=("zero-crossing two-component unlink record",),
    ),
    DiagramFixture(
        notation="L2a1",
        name="Hopf link",
        kind="link",
        component_count=2,
        pd_code=((1, 4, 2, 3), (3, 2, 4, 1)),
        signs=(1, -1),
        expected_jones="-t^-1 - t",
        expected_homfly="-a^-3*z^-1 + a^-1*z^-1 + a^-1*z",
        expected_homfly_source="iroll bounded recursive HOMFLY regression",
        expected_homfly_notes=(
            "computed from the signed-PD fixture under iroll's HOMFLY convention",
            "external table normalization confirmation remains pending",
        ),
        expected_multivariable_alexander="1",
        expected_multivariable_alexander_variables=("t1", "t2"),
        expected_multivariable_alexander_source="iroll signed-PD Wirtinger/Fox regression",
        expected_multivariable_alexander_notes=(
            "conservative common divisor of bounded signed-PD Fox square minors",
            "fixture-backed admissible-minor convention confirmation remains pending",
        ),
        convention_notes=("signed PD convention used by iroll Jones state-sum tests",),
    ),
    DiagramFixture(
        notation="3_1",
        name="left-handed trefoil",
        kind="knot",
        component_count=1,
        pd_code=((1, 4, 2, 5), (3, 6, 4, 1), (5, 2, 6, 3)),
        signs=(-1, -1, -1),
        expected_jones="-t^-4 + t^-3 + t^-1",
        expected_homfly="2a^2 + a^2*z^2 - a^4",
        expected_homfly_source="iroll bounded recursive HOMFLY regression",
        expected_homfly_notes=(
            "computed from the signed-PD fixture under iroll's HOMFLY convention",
            "external table normalization confirmation remains pending",
        ),
        expected_multivariable_alexander="1 - t + t^2",
        expected_multivariable_alexander_variables=("t",),
        expected_multivariable_alexander_source="iroll signed-PD Wirtinger/Fox regression",
        expected_multivariable_alexander_notes=(
            "one-variable specialization from generated signed-PD Wirtinger presentation",
            "fixture-backed admissible-minor convention confirmation remains pending",
        ),
        convention_notes=("left-handed orientation under iroll signed-PD convention",),
    ),
    DiagramFixture(
        notation="4_1",
        name="figure-eight knot",
        kind="knot",
        component_count=1,
        pd_code=((4, 2, 5, 1), (8, 6, 1, 5), (6, 3, 7, 4), (2, 7, 3, 8)),
        signs=(1, 1, -1, -1),
        expected_jones="t^-2 - t^-1 + 1 - t + t^2",
        expected_homfly="a^-2 - 1 - z^2 + a^2",
        expected_homfly_source="Knot Atlas HOMFLYPT table",
        expected_homfly_notes=(
            "computed from the documented Knot Atlas cyclic PD convention",
            "matches the Knot Atlas a,z normalization exactly",
            "the previous internal regression omitted free-circle split-union factors and is intentionally superseded",
        ),
        expected_multivariable_alexander="1 - 3t + t^2",
        expected_multivariable_alexander_variables=("t",),
        expected_multivariable_alexander_source=(
            "iroll explicit-orientation signed-PD Wirtinger/Fox regression"
        ),
        expected_multivariable_alexander_notes=(
            "one-variable Alexander polynomial from the generated explicit-orientation Wirtinger presentation",
            "matches the built-in 4_1 Alexander table value under iroll's unit normalization",
        ),
        orientation_role_orders=(
            (0, 3, 2, 1),
            (0, 3, 2, 1),
            (0, 1, 2, 3),
            (0, 1, 2, 3),
        ),
        source="Knot Atlas",
        source_url="https://katlas.org/wiki/4_1",
        convention_notes=(
            "PD source is Knot Atlas and edge labels increase along the oriented component",
            "X[i,j,k,l] starts at incoming lower edge; documented Xp/Xm upper-strand directions determine signs",
            "orientation_role_orders translate the external cyclic PD source into explicit iroll under/over in/out metadata",
        ),
    ),
    DiagramFixture(
        notation="L5a1",
        name="Whitehead link",
        kind="link",
        component_count=2,
        pd_code=((6, 1, 7, 2), (10, 7, 5, 8), (4, 5, 1, 6), (2, 10, 3, 9), (8, 4, 9, 3)),
        signs=None,
        gauss_code=((1, -4, 5, -3), (3, -1, 2, -5, 4, -2)),
        source_table_jones=(
            "q^-7/2 - 2q^-5/2 + q^-3/2 - 2q^-1/2 + q^1/2 - q^3/2"
        ),
        source_table_jones_iroll_normalized=(
            "t^-2 - 2t^-1 + 1 - 2t + t^2 - t^3"
        ),
        source_table_homfly=(
            "-a^3*z + a*z^3 + 2a*z + a*z^-1 - a^-1*z - a^-1*z^-1"
        ),
        source_table_homfly_iroll_normalized=(
            "-a^3*z + a*z^3 + 2a*z + a*z^-1 - a^-1*z - a^-1*z^-1"
        ),
        source_table_multivariable_alexander=(
            "(u - 1)*(v - 1)/(sqrt(u)*sqrt(v))"
        ),
        source_table_multivariable_alexander_numerator=(
            "1 - t2 - t1 + t1*t2"
        ),
        source_table_multivariable_alexander_variables=("t1", "t2"),
        source_table_notes=(
            "Knot Atlas source table uses u,v and half-power normalization for the multi-variable Alexander polynomial",
            "iroll source-table audit compares the de-half-powered numerator up to Laurent-unit normalization",
        ),
        source="Knot Atlas",
        source_url="https://katlas.org/wiki/L5a1",
        convention_notes=(
            "unsigned PD recorded; signed crossing signs require verification before algorithmic invariant tests",
            "source Gauss code constrains orientation-role diagnostics but does not register fixture invariants",
        ),
    ),
    DiagramFixture(
        notation="L6a4",
        name="Borromean rings",
        kind="link",
        component_count=3,
        pd_code=(
            (6, 1, 7, 2),
            (12, 8, 9, 7),
            (4, 12, 1, 11),
            (10, 5, 11, 6),
            (8, 4, 5, 3),
            (2, 9, 3, 10),
        ),
        signs=None,
        gauss_code=((1, -6, 5, -3), (4, -1, 2, -5), (6, -4, 3, -2)),
        source_table_jones=(
            "-q^3 - q^-3 + 3q^2 + 3q^-2 - 2q - 2q^-1 + 4"
        ),
        source_table_jones_iroll_normalized=(
            "-t^-3 + 3t^-2 - 2t^-1 + 4 - 2t + 3t^2 - t^3"
        ),
        source_table_homfly=(
            "-a^2*z^2 - a^-2*z^2 + a^2*z^-2 + a^-2*z^-2 + z^4 + 2z^2 - 2z^-2"
        ),
        source_table_homfly_iroll_normalized=(
            "-a^2*z^2 - a^-2*z^2 + a^2*z^-2 + a^-2*z^-2 + z^4 + 2z^2 - 2z^-2"
        ),
        source_table_multivariable_alexander=(
            "(u - 1)*(v - 1)*(w - 1)/(sqrt(u)*sqrt(v)*sqrt(w))"
        ),
        source_table_multivariable_alexander_numerator=(
            "1 - t3 - t2 + t2*t3 - t1 + t1*t3 + t1*t2 - t1*t2*t3"
        ),
        source_table_multivariable_alexander_variables=("t1", "t2", "t3"),
        source_table_notes=(
            "Knot Atlas source table uses u,v,w and half-power normalization for the multi-variable Alexander polynomial",
            "iroll source-table audit compares the de-half-powered numerator up to Laurent-unit normalization",
        ),
        source="Knot Atlas",
        source_url="https://katlas.org/wiki/L6a4",
        convention_notes=(
            "unsigned PD recorded from Knot Atlas; signed crossing signs require verification before algorithmic invariant tests",
            "source Gauss code constrains orientation-role diagnostics but does not register fixture invariants",
        ),
    ),
]


def standard_diagram_fixtures() -> list[DiagramFixture]:
    return list(STANDARD_DIAGRAM_FIXTURES)


def get_diagram_fixture(notation: str) -> DiagramFixture:
    for fixture in STANDARD_DIAGRAM_FIXTURES:
        if fixture.notation == notation:
            return fixture
    raise KeyError(notation)


def _broad_noisy_curve_robustness_raw_report() -> dict[str, Any]:
    """Run the deterministic six-family noisy-curve certification matrix."""

    import numpy as np

    from iroll.core.curve import Polyline3D
    from iroll.reports import (
        imgui_geometry_payload_from_report,
        validate_report,
    )
    from iroll.topology.analyze import analyze_curve

    direction = [0.2, -0.4, 1.0]
    family_rows: list[dict[str, Any]] = []
    for (
        name,
        source_point_count,
        resample_point_count,
        base_radius,
        x_scale,
        y_scale,
        radial_scale,
        axial_scale,
        lobes,
    ) in _BROAD_NOISY_CURVE_FAMILY_SPECS:
        theta = np.linspace(
            0.0,
            2.0 * np.pi,
            source_point_count,
            endpoint=False,
        )
        radial_noise = radial_scale * (
            np.sin(lobes[0] * theta) + 0.5 * np.cos(lobes[1] * theta)
        )
        twist = 0.25 * radial_scale * np.sin(
            (lobes[0] + lobes[2]) * theta
        )
        radius = base_radius + radial_noise
        points = np.column_stack(
            [
                x_scale * radius * np.cos(theta + twist),
                y_scale * radius * np.sin(theta + twist),
                axial_scale * np.sin(lobes[2] * theta),
            ]
        )
        curve = Polyline3D(
            points,
            closed=True,
            name=name,
            metadata={
                "fixture": name,
                "certification_pack": "broad_noisy_curve",
            },
        )
        resampled = curve.resample_by_count(resample_point_count)
        curve_report = analyze_curve(
            resampled,
            direction=direction,
            backend="numpy",
        )
        imgui_geometry = imgui_geometry_payload_from_report(curve_report)
        curvature = resampled.curvature()
        torsion = resampled.torsion()
        validation_checks = {
            "resampled_curve_closed": resampled.closed is True,
            "resampled_point_count_matches": (
                resampled.point_count == resample_point_count
            ),
            "arc_length_positive_finite": (
                math.isfinite(float(resampled.arc_length()))
                and float(resampled.arc_length()) > 0.0
            ),
            "curvature_all_finite": bool(np.isfinite(curvature).all()),
            "torsion_all_finite": bool(np.isfinite(torsion).all()),
            "curve_report_schema_valid": not validate_report(
                curve_report,
                kind="curve",
            ),
            "curve_report_name_matches": (
                curve_report.get("input", {}).get("name") == name
            ),
            "curve_report_point_count_matches": (
                curve_report.get("input", {}).get("point_count")
                == resample_point_count
            ),
            "curve_report_closed": (
                curve_report.get("geometry", {}).get("closed") is True
            ),
            "curve_report_numpy_backend": (
                curve_report.get("runtime", {}).get("requested_backend")
                == "numpy"
            ),
            "imgui_projection_method": (
                imgui_geometry.get("method")
                == "imgui_geometry_payload_from_report"
            ),
            "imgui_projection_point_count_matches": (
                imgui_geometry.get("geometry_point_count")
                == resample_point_count
            ),
            "imgui_projection_single_closed_component": (
                imgui_geometry.get("component_count") == 1
                and imgui_geometry.get("component_point_counts")
                == [resample_point_count]
                and imgui_geometry.get("component_closed") == [1]
            ),
            "imgui_projection_matches_curve_report": (
                imgui_geometry_payload_from_report(curve_report)
                == imgui_geometry
            ),
        }
        family_rows.append(
            {
                "family": name,
                "configuration": {
                    "source_point_count": source_point_count,
                    "resample_point_count": resample_point_count,
                    "base_radius": base_radius,
                    "x_scale": x_scale,
                    "y_scale": y_scale,
                    "radial_scale": radial_scale,
                    "axial_scale": axial_scale,
                    "lobes": list(lobes),
                },
                "construction_source": {
                    "source_kind": "deterministic_synthetic_parametric_curve",
                    "source_method": (
                        "analytic radial/axial harmonic perturbation followed by "
                        "arc-length resampling"
                    ),
                    "source_url_applicable": False,
                    "source_url": None,
                },
                "expected_invariant": {
                    "scope": (
                        "finite_schema_valid_closed_single_component_geometry"
                    ),
                    "closed": True,
                    "component_count": 1,
                    "point_count": resample_point_count,
                    "strict_json_finite": True,
                },
                "convention_normalization": {
                    "sampling_parameterization": (
                        "theta_in_[0,2pi)_with_endpoint_excluded"
                    ),
                    "closed_curve_storage": (
                        "first_point_not_duplicated_at_endpoint"
                    ),
                    "resampling": "arc_length_resample_by_count",
                    "analysis_backend": "numpy",
                    "analysis_projection_direction": direction,
                    "imgui_projection": (
                        "imgui_geometry_payload_from_report_without_topology_recompute"
                    ),
                },
                "numeric_tolerance": {
                    "comparison_mode": (
                        "deterministic_exact_json_replay_plus_finite_numeric_checks"
                    ),
                    "relative_tolerance": 1e-12,
                    "absolute_tolerance": 1e-15,
                    "finite_values_required": True,
                    "minimum_segment_length": 1e-12,
                },
                "known_limitations": [
                    (
                        "synthetic deterministic harmonic-noise families do not "
                        "form a statistical random-noise confidence envelope"
                    ),
                    (
                        "certification covers the NumPy CPU analysis path and "
                        "does not claim Rust or GPU parity"
                    ),
                    (
                        "expected invariants are robustness/schema/geometry "
                        "projections, not a named knot-type classification claim"
                    ),
                ],
                "arc_length": float(resampled.arc_length()),
                "curvature_sample_count": int(curvature.size),
                "torsion_sample_count": int(torsion.size),
                "curve_report": curve_report,
                "imgui_geometry_payload": imgui_geometry,
                "validation_checks": validation_checks,
                "validation_check_count": len(validation_checks),
                "validation_passed_check_count": sum(
                    1 for passed in validation_checks.values() if passed
                ),
                "validation_failed_checks": [
                    check
                    for check, passed in validation_checks.items()
                    if not passed
                ],
                "passed": all(validation_checks.values()),
            }
        )

    failed_families = [row for row in family_rows if row["passed"] is not True]
    completion_claimed = (
        len(family_rows) == len(_BROAD_NOISY_CURVE_FAMILY_SPECS)
        and not failed_families
    )
    return {
        "artifact_schema_version": 1,
        "method": "broad_noisy_curve_robustness_certification",
        "claim_scope": "broad_noisy_sampled_curve_robustness_certification",
        "direction": direction,
        "requested_backend": "numpy",
        "representative_curve_family_count": len(family_rows),
        "expected_representative_curve_family_count": len(
            _BROAD_NOISY_CURVE_FAMILY_SPECS
        ),
        "representative_curve_families": [
            str(row["family"]) for row in family_rows
        ],
        "report_backends": ["curve_report", "imgui_geometry_payload"],
        "curve_families": family_rows,
        "completed_family_count": len(family_rows) - len(failed_families),
        "failed_family_count": len(failed_families),
        "failed_families": [str(row["family"]) for row in failed_families],
        "completion_claimed": completion_claimed,
    }


def broad_noisy_curve_robustness_imgui_analysis_from_raw(
    raw: Mapping[str, Any],
) -> dict[str, Any]:
    """Derive the retained ImGui analysis projection from one raw report."""

    source_raw_canonical_sha256 = sha256(
        json.dumps(
            dict(raw),
            allow_nan=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()
    family_value = raw.get("curve_families")
    family_rows = (
        list(family_value)
        if isinstance(family_value, Sequence)
        and not isinstance(family_value, (str, bytes))
        else []
    )
    summaries: list[dict[str, Any]] = []
    for value in family_rows:
        row = value if isinstance(value, Mapping) else {}
        configuration = row.get("configuration")
        configuration = configuration if isinstance(configuration, Mapping) else {}
        report = row.get("curve_report")
        report = report if isinstance(report, Mapping) else {}
        report_input = report.get("input")
        report_input = report_input if isinstance(report_input, Mapping) else {}
        report_geometry = report.get("geometry")
        report_geometry = (
            report_geometry if isinstance(report_geometry, Mapping) else {}
        )
        imgui = row.get("imgui_geometry_payload")
        imgui = imgui if isinstance(imgui, Mapping) else {}
        validation_checks = row.get("validation_checks")
        validation_checks = (
            validation_checks
            if isinstance(validation_checks, Mapping)
            else {}
        )
        construction_source = row.get("construction_source")
        construction_source = (
            construction_source
            if isinstance(construction_source, Mapping)
            else {}
        )
        expected_invariant = row.get("expected_invariant")
        expected_invariant = (
            expected_invariant
            if isinstance(expected_invariant, Mapping)
            else {}
        )
        convention_normalization = row.get("convention_normalization")
        convention_normalization = (
            convention_normalization
            if isinstance(convention_normalization, Mapping)
            else {}
        )
        numeric_tolerance = row.get("numeric_tolerance")
        numeric_tolerance = (
            numeric_tolerance
            if isinstance(numeric_tolerance, Mapping)
            else {}
        )
        known_limitations = row.get("known_limitations")
        known_limitations = (
            list(known_limitations)
            if isinstance(known_limitations, Sequence)
            and not isinstance(known_limitations, (str, bytes))
            else []
        )
        projection_counts_match = (
            report_input.get("point_count")
            == configuration.get("resample_point_count")
            == imgui.get("geometry_point_count")
            and imgui.get("component_point_counts")
            == [configuration.get("resample_point_count")]
        )
        projection_closed_matches = (
            report_geometry.get("closed") is True
            and imgui.get("component_closed") == [1]
        )
        summary_completion_claimed = (
            row.get("passed") is True
            and bool(validation_checks)
            and all(value is True for value in validation_checks.values())
            and projection_counts_match
            and projection_closed_matches
        )
        summaries.append(
            {
                "family": row.get("family"),
                "source_point_count": configuration.get("source_point_count"),
                "resample_point_count": configuration.get(
                    "resample_point_count"
                ),
                "construction_source_kind": construction_source.get(
                    "source_kind"
                ),
                "source_url_applicable": construction_source.get(
                    "source_url_applicable"
                ),
                "expected_invariant_scope": expected_invariant.get("scope"),
                "resampling_convention": convention_normalization.get(
                    "resampling"
                ),
                "numeric_comparison_mode": numeric_tolerance.get(
                    "comparison_mode"
                ),
                "known_limitation_count": len(known_limitations),
                "curve_report_point_count": report_input.get("point_count"),
                "curve_report_closed": report_geometry.get("closed") is True,
                "curve_report_crossing_count": (
                    report.get("topology", {}).get("crossing_count")
                    if isinstance(report.get("topology"), Mapping)
                    else None
                ),
                "imgui_geometry_point_count": imgui.get(
                    "geometry_point_count"
                ),
                "imgui_component_count": imgui.get("component_count"),
                "imgui_projected_crossing_count": imgui.get(
                    "projected_crossing_count"
                ),
                "imgui_contact_count": imgui.get("contact_count"),
                "projection_counts_match": projection_counts_match,
                "projection_closed_matches": projection_closed_matches,
                "validation_check_count": row.get("validation_check_count"),
                "validation_passed_check_count": row.get(
                    "validation_passed_check_count"
                ),
                "completion_claimed": summary_completion_claimed,
            }
        )
    completed_count = sum(
        1 for summary in summaries if summary["completion_claimed"] is True
    )
    representative_count = raw.get("representative_curve_family_count")
    completion_claimed = (
        raw.get("completion_claimed") is True
        and representative_count == len(_BROAD_NOISY_CURVE_FAMILY_SPECS)
        and len(summaries) == representative_count
        and completed_count == representative_count
    )
    return {
        "artifact_schema_version": 1,
        "method": "broad_noisy_curve_robustness_imgui_analysis",
        "source_method": raw.get("method"),
        "source_raw_canonical_sha256": source_raw_canonical_sha256,
        "claim_scope": raw.get("claim_scope"),
        "representative_curve_family_count": representative_count,
        "representative_curve_families": raw.get(
            "representative_curve_families"
        ),
        "report_backends": raw.get("report_backends"),
        "curve_report_count": len(summaries),
        "imgui_geometry_payload_count": len(summaries),
        "completed_family_count": completed_count,
        "failed_family_count": len(summaries) - completed_count,
        "family_summaries": summaries,
        "completion_claimed": completion_claimed,
    }


def broad_noisy_curve_robustness_imgui_host_from_raw(
    raw: Mapping[str, Any],
    *,
    analysis: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Derive the multi-geometry host projection from raw retained evidence."""

    resolved_analysis = (
        dict(analysis)
        if isinstance(analysis, Mapping)
        else broad_noisy_curve_robustness_imgui_analysis_from_raw(raw)
    )
    source_raw_canonical_sha256 = sha256(
        json.dumps(
            dict(raw),
            allow_nan=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()
    source_analysis_canonical_sha256 = sha256(
        json.dumps(
            resolved_analysis,
            allow_nan=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()
    family_value = raw.get("curve_families")
    family_rows = (
        list(family_value)
        if isinstance(family_value, Sequence)
        and not isinstance(family_value, (str, bytes))
        else []
    )
    geometry_payloads = [
        dict(row["imgui_geometry_payload"])
        for row in family_rows
        if isinstance(row, Mapping)
        and isinstance(row.get("imgui_geometry_payload"), Mapping)
    ]
    representative_count = raw.get("representative_curve_family_count")
    completion_claimed = (
        raw.get("completion_claimed") is True
        and resolved_analysis.get("completion_claimed") is True
        and representative_count == len(_BROAD_NOISY_CURVE_FAMILY_SPECS)
        and len(geometry_payloads) == representative_count
    )
    return {
        "artifact_schema_version": 1,
        "method": "broad_noisy_curve_robustness_imgui_host",
        "source_method": raw.get("method"),
        "source_raw_canonical_sha256": source_raw_canonical_sha256,
        "source_analysis_canonical_sha256": (
            source_analysis_canonical_sha256
        ),
        "claim_scope": raw.get("claim_scope"),
        "representative_curve_family_count": representative_count,
        "representative_curve_families": raw.get(
            "representative_curve_families"
        ),
        "report_backends": raw.get("report_backends"),
        "geometry_payload_count": len(geometry_payloads),
        "geometry_payloads": geometry_payloads,
        "analysis": resolved_analysis,
        "completion_claimed": completion_claimed,
        "notes": [
            "raw curve reports remain the authoritative computation evidence",
            "geometry_payloads are deterministic Dear ImGui projections of those reports",
        ],
    }


@lru_cache(maxsize=1)
def _broad_noisy_curve_robustness_canonical_json_texts() -> tuple[str, str, str]:
    raw = _broad_noisy_curve_robustness_raw_report()
    analysis = broad_noisy_curve_robustness_imgui_analysis_from_raw(raw)
    host = broad_noisy_curve_robustness_imgui_host_from_raw(
        raw,
        analysis=analysis,
    )
    return tuple(
        json.dumps(
            payload,
            allow_nan=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        for payload in (raw, analysis, host)
    )


def broad_noisy_curve_robustness_certification_payloads() -> dict[str, dict]:
    """Return fresh copies of the deterministic raw/analysis/host payloads."""

    raw_text, analysis_text, host_text = (
        _broad_noisy_curve_robustness_canonical_json_texts()
    )
    return {
        "raw": json.loads(raw_text),
        "analysis": json.loads(analysis_text),
        "host": json.loads(host_text),
    }


def broad_noisy_curve_robustness_certification_pack_from_json_bytes(
    raw_bytes: bytes,
    analysis_bytes: bytes,
    host_bytes: bytes,
    *,
    raw_filename: str = _BROAD_NOISY_CURVE_ROBUSTNESS_FILENAMES["raw"],
    analysis_filename: str = _BROAD_NOISY_CURVE_ROBUSTNESS_FILENAMES[
        "analysis"
    ],
    host_filename: str = _BROAD_NOISY_CURVE_ROBUSTNESS_FILENAMES["host"],
    artifact_name: str = "iroll-broad-noisy-curve-robustness-${{ matrix.os }}",
) -> dict[str, Any]:
    """Build the manifest for retained noisy-curve raw/analysis/host files."""

    raw = json.loads(raw_bytes.decode("utf-8-sig"))
    completion_claimed = (
        isinstance(raw, Mapping) and raw.get("completion_claimed") is True
    )
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "broad_noisy_curve_robustness_certification_pack",
        "claim_scope": "broad_noisy_sampled_curve_robustness_certification",
        "source_method": "iroll broad-noisy-curve-robustness-pack-producer",
        "artifact_name": artifact_name,
        "raw_filename": raw_filename,
        "raw_sha256": sha256(raw_bytes).hexdigest(),
        "analysis_filename": analysis_filename,
        "analysis_sha256": sha256(analysis_bytes).hexdigest(),
        "host_filename": host_filename,
        "host_sha256": sha256(host_bytes).hexdigest(),
        "representative_curve_family_count": raw.get(
            "representative_curve_family_count"
        )
        if isinstance(raw, Mapping)
        else None,
        "representative_curve_families": list(
            raw.get("representative_curve_families", [])
        )
        if isinstance(raw, Mapping)
        and isinstance(raw.get("representative_curve_families"), list)
        else [],
        "report_backends": list(raw.get("report_backends", []))
        if isinstance(raw, Mapping)
        and isinstance(raw.get("report_backends"), list)
        else [],
        "completion_claimed": completion_claimed,
        "template_placeholder": False,
    }


def broad_noisy_curve_robustness_certification_pack_with_external_files(
    pack: Mapping[str, Any],
    *,
    raw_bytes: bytes,
    analysis_bytes: bytes,
    host_bytes: bytes,
    raw_filename: str,
    analysis_filename: str,
    host_filename: str,
) -> dict[str, Any]:
    """Attach exact noisy-curve external bytes for bundle preflight."""

    payload = dict(pack)
    payload["_external_file_evidence"] = {
        "raw": {
            "filename": raw_filename,
            "sha256": sha256(raw_bytes).hexdigest(),
            "content_base64": base64.b64encode(raw_bytes).decode("ascii"),
        },
        "analysis": {
            "filename": analysis_filename,
            "sha256": sha256(analysis_bytes).hexdigest(),
            "content_base64": base64.b64encode(analysis_bytes).decode("ascii"),
        },
        "host": {
            "filename": host_filename,
            "sha256": sha256(host_bytes).hexdigest(),
            "content_base64": base64.b64encode(host_bytes).decode("ascii"),
        },
    }
    return payload


def release_grade_high_point_performance_pack_from_json_bytes(
    raw_bytes: bytes,
    analysis_bytes: bytes,
    host_bytes: bytes,
    *,
    raw_filename: str = _RELEASE_GRADE_HIGH_POINT_PERFORMANCE_FILENAMES["raw"],
    analysis_filename: str = _RELEASE_GRADE_HIGH_POINT_PERFORMANCE_FILENAMES[
        "analysis"
    ],
    host_filename: str = _RELEASE_GRADE_HIGH_POINT_PERFORMANCE_FILENAMES["host"],
    artifact_name: str = (
        "iroll-release-grade-high-point-performance-${{ matrix.os }}"
    ),
) -> dict[str, Any]:
    """Build the manifest for independently retained high-point evidence files."""

    raw = json.loads(raw_bytes.decode("utf-8-sig"))
    speedup = raw.get("speedup_evidence", {}) if isinstance(raw, Mapping) else {}
    rust_binary_provenance = (
        raw.get("rust_module_binary_provenance", {})
        if isinstance(raw, Mapping)
        else {}
    )
    release_claimed = (
        isinstance(speedup, Mapping)
        and speedup.get("release_grade_speedup_claimed") is True
    )
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "release_grade_high_point_performance_pack",
        "claim_scope": "release_grade_high_point_performance_certification",
        "source_method": "iroll release-grade-high-point-performance-pack-producer",
        "artifact_name": artifact_name,
        "raw_filename": raw_filename,
        "raw_sha256": sha256(raw_bytes).hexdigest(),
        "analysis_filename": analysis_filename,
        "analysis_sha256": sha256(analysis_bytes).hexdigest(),
        "host_filename": host_filename,
        "host_sha256": sha256(host_bytes).hexdigest(),
        "point_sizes": list(raw.get("point_sizes", []))
        if isinstance(raw, Mapping)
        else [],
        "backends": list(raw.get("backends", []))
        if isinstance(raw, Mapping)
        else [],
        "repeat": raw.get("repeat") if isinstance(raw, Mapping) else None,
        "warmup": raw.get("warmup") if isinstance(raw, Mapping) else None,
        "speedup_threshold": speedup.get("speedup_threshold")
        if isinstance(speedup, Mapping)
        else None,
        "minimum_repeat_for_release_claim": speedup.get(
            "minimum_repeat_for_release_claim"
        )
        if isinstance(speedup, Mapping)
        else None,
        "rust_module_binary_provenance": (
            dict(rust_binary_provenance)
            if isinstance(rust_binary_provenance, Mapping)
            else {}
        ),
        "release_grade_speedup_claimed": release_claimed,
        "completion_claimed": release_claimed,
        "template_placeholder": False,
    }


def release_grade_high_point_performance_pack_with_external_files(
    pack: Mapping[str, Any],
    *,
    raw_bytes: bytes,
    analysis_bytes: bytes,
    host_bytes: bytes,
    raw_filename: str,
    analysis_filename: str,
    host_filename: str,
) -> dict[str, Any]:
    """Attach exact external bytes for bundle or independent-file preflight."""

    payload = dict(pack)
    payload["_external_file_evidence"] = {
        "raw": {
            "filename": raw_filename,
            "sha256": sha256(raw_bytes).hexdigest(),
            "content_base64": base64.b64encode(raw_bytes).decode("ascii"),
        },
        "analysis": {
            "filename": analysis_filename,
            "sha256": sha256(analysis_bytes).hexdigest(),
            "content_base64": base64.b64encode(analysis_bytes).decode("ascii"),
        },
        "host": {
            "filename": host_filename,
            "sha256": sha256(host_bytes).hexdigest(),
            "content_base64": base64.b64encode(host_bytes).decode("ascii"),
        },
    }
    return payload


def _release_grade_high_point_timing_recomputation(
    raw: Mapping[str, Any],
) -> dict[str, Any]:
    """Rebuild the release speedup gate from the retained timing samples."""

    expected_backends = ("numpy", "rust")
    expected_workloads = (
        "crossings",
        "contacts",
        "writhe",
        "gaussian_linking",
    )
    expected_keys = {
        (backend, workload, 128)
        for backend in expected_backends
        for workload in expected_workloads
    }
    repeat = raw.get("repeat")
    warmup = raw.get("warmup")
    results_value = raw.get("results")
    results_is_sequence = isinstance(results_value, Sequence) and not isinstance(
        results_value,
        (str, bytes),
    )
    results = list(results_value) if results_is_sequence else []
    rows = [row for row in results if isinstance(row, Mapping)]

    row_keys: list[tuple[str, str, int]] = []
    row_key_shape_valid = True
    for row in rows:
        backend = row.get("backend")
        workload = row.get("workload")
        points = row.get("points")
        if (
            isinstance(backend, str)
            and backend in expected_backends
            and isinstance(workload, str)
            and workload in expected_workloads
            and isinstance(points, int)
            and not isinstance(points, bool)
            and points == 128
        ):
            row_keys.append((backend, workload, points))
        else:
            row_key_shape_valid = False

    seconds_lengths_match = len(rows) == len(expected_keys)
    seconds_positive_finite = len(rows) == len(expected_keys)
    seconds_medians_match = len(rows) == len(expected_keys)
    seconds_minima_match = len(rows) == len(expected_keys)
    sample_medians: dict[tuple[str, str, int], float] = {}

    def positive_finite_number(value: Any) -> bool:
        return (
            isinstance(value, (int, float))
            and not isinstance(value, bool)
            and math.isfinite(float(value))
            and float(value) > 0.0
        )

    def exact_int(value: Any, expected: int) -> bool:
        return (
            isinstance(value, int)
            and not isinstance(value, bool)
            and value == expected
        )

    def numbers_match(actual: Any, expected: float) -> bool:
        return (
            isinstance(actual, (int, float))
            and not isinstance(actual, bool)
            and math.isfinite(float(actual))
            and math.isclose(
                float(actual),
                float(expected),
                rel_tol=1e-12,
                abs_tol=1e-15,
            )
        )

    for row in rows:
        seconds_value = row.get("seconds")
        seconds_is_sequence = isinstance(
            seconds_value, Sequence
        ) and not isinstance(seconds_value, (str, bytes))
        seconds = list(seconds_value) if seconds_is_sequence else []
        row_length_matches = (
            isinstance(repeat, int)
            and not isinstance(repeat, bool)
            and len(seconds) == repeat
        )
        row_seconds_valid = row_length_matches and all(
            positive_finite_number(value) for value in seconds
        )
        seconds_lengths_match = seconds_lengths_match and row_length_matches
        seconds_positive_finite = seconds_positive_finite and row_seconds_valid
        if not row_seconds_valid:
            seconds_medians_match = False
            seconds_minima_match = False
            continue
        computed_median = float(median(float(value) for value in seconds))
        computed_minimum = min(float(value) for value in seconds)
        row_median_matches = numbers_match(
            row.get("seconds_median"), computed_median
        )
        row_minimum_matches = numbers_match(row.get("seconds_min"), computed_minimum)
        seconds_medians_match = seconds_medians_match and row_median_matches
        seconds_minima_match = seconds_minima_match and row_minimum_matches
        backend = row.get("backend")
        workload = row.get("workload")
        points = row.get("points")
        if (
            isinstance(backend, str)
            and isinstance(workload, str)
            and isinstance(points, int)
            and not isinstance(points, bool)
        ):
            key = (backend, workload, points)
            if key not in sample_medians:
                sample_medians[key] = computed_median

    exact_row_count = len(results) == len(expected_keys) and len(rows) == len(results)
    unique_rows = (
        exact_row_count
        and row_key_shape_valid
        and len(row_keys) == len(set(row_keys))
    )
    expected_row_coverage = unique_rows and set(row_keys) == expected_keys
    rows_completed = exact_row_count and all(
        row.get("status") == "completed" for row in rows
    )
    row_repeat_matches = exact_row_count and all(
        exact_int(row.get("repeat"), 3) for row in rows
    )
    row_warmup_matches = exact_row_count and all(
        exact_int(row.get("warmup"), 1) for row in rows
    )

    speedup = raw.get("speedup_evidence")
    speedup = speedup if isinstance(speedup, Mapping) else {}
    rust_binary_provenance = raw.get("rust_module_binary_provenance")
    rust_binary_provenance = (
        rust_binary_provenance
        if isinstance(rust_binary_provenance, Mapping)
        else {}
    )
    threshold = 1.25
    recomputed_rows: list[dict[str, Any]] = []
    if expected_row_coverage and expected_keys.issubset(sample_medians):
        for workload in sorted(expected_workloads):
            numpy_seconds = sample_medians[("numpy", workload, 128)]
            rust_seconds = sample_medians[("rust", workload, 128)]
            ratio = numpy_seconds / rust_seconds
            recomputed_rows.append(
                {
                    "workload": workload,
                    "points": 128,
                    "numpy_seconds_median": numpy_seconds,
                    "rust_seconds_median": rust_seconds,
                    "speedup_vs_baseline": ratio,
                    "meets_threshold": ratio >= threshold,
                    "fastest_backend": (
                        "numpy" if numpy_seconds <= rust_seconds else "rust"
                    ),
                    "fastest_seconds_median": min(numpy_seconds, rust_seconds),
                }
            )

    threshold_rows = [row for row in recomputed_rows if row["meets_threshold"]]
    threshold_count = len(threshold_rows)
    repeat_satisfied = repeat == 3

    raw_provenance = raw.get("rust_module_binary_provenance")
    raw_provenance = (
        raw_provenance if isinstance(raw_provenance, Mapping) else {}
    )
    provenance_available = raw_provenance.get("available") is True
    provenance_release_profile = raw_provenance.get("build_profile") == "release"
    provenance_byte_count = raw_provenance.get("byte_count")
    provenance_positive_byte_count = (
        isinstance(provenance_byte_count, int)
        and not isinstance(provenance_byte_count, bool)
        and provenance_byte_count > 0
    )
    provenance_sha256 = raw_provenance.get("sha256")
    provenance_sha256_valid = (
        isinstance(provenance_sha256, str)
        and len(provenance_sha256) == 64
        and all(
            character in "0123456789abcdefABCDEF"
            for character in provenance_sha256
        )
    )
    provenance_blocking_reasons: list[str] = []
    if not provenance_available:
        provenance_blocking_reasons.append("rust_module_binary_unavailable")
    if not provenance_release_profile:
        provenance_blocking_reasons.append(
            "rust_module_build_profile_not_release"
        )
    if not provenance_positive_byte_count:
        provenance_blocking_reasons.append(
            "rust_module_binary_byte_count_invalid"
        )
    if not provenance_sha256_valid:
        provenance_blocking_reasons.append("rust_module_binary_sha256_invalid")
    provenance_satisfied = not provenance_blocking_reasons
    recomputed_release_claim = (
        repeat_satisfied
        and threshold_count >= 1
        and provenance_satisfied
    )

    comparisons_value = speedup.get("comparisons")
    comparisons = (
        list(comparisons_value)
        if isinstance(comparisons_value, Sequence)
        and not isinstance(comparisons_value, (str, bytes))
        else []
    )
    comparisons_match = len(comparisons) == len(recomputed_rows) == 4
    comparisons_by_key: dict[tuple[str, int], Mapping[str, Any]] = {}
    for comparison in comparisons:
        if not isinstance(comparison, Mapping):
            comparisons_match = False
            continue
        comparison_workload = comparison.get("workload")
        comparison_points = comparison.get("points")
        if (
            not isinstance(comparison_workload, str)
            or not isinstance(comparison_points, int)
            or isinstance(comparison_points, bool)
        ):
            comparisons_match = False
            continue
        key = (comparison_workload, comparison_points)
        if key in comparisons_by_key:
            comparisons_match = False
        comparisons_by_key[key] = comparison
    for derived in recomputed_rows:
        comparison = comparisons_by_key.get(
            (derived["workload"], derived["points"])
        )
        if not isinstance(comparison, Mapping):
            comparisons_match = False
            continue
        backend_speedups_value = comparison.get("backend_speedups")
        backend_speedups = (
            list(backend_speedups_value)
            if isinstance(backend_speedups_value, Sequence)
            and not isinstance(backend_speedups_value, (str, bytes))
            else []
        )
        backend_speedup = (
            backend_speedups[0]
            if len(backend_speedups) == 1
            and isinstance(backend_speedups[0], Mapping)
            else {}
        )
        comparisons_match = comparisons_match and all(
            (
                comparison.get("baseline_backend") == "numpy",
                comparison.get("status") == "completed",
                comparison.get("fastest_backend") == derived["fastest_backend"],
                numbers_match(
                    comparison.get("baseline_seconds_median"),
                    derived["numpy_seconds_median"],
                ),
                numbers_match(
                    comparison.get("fastest_seconds_median"),
                    derived["fastest_seconds_median"],
                ),
                backend_speedup.get("backend") == "rust",
                numbers_match(
                    backend_speedup.get("seconds_median"),
                    derived["rust_seconds_median"],
                ),
                numbers_match(
                    backend_speedup.get("speedup_vs_baseline"),
                    derived["speedup_vs_baseline"],
                ),
                backend_speedup.get("meets_threshold")
                is derived["meets_threshold"],
            )
        )

    candidate_value = speedup.get("candidate_speedups")
    candidates = (
        list(candidate_value)
        if isinstance(candidate_value, Sequence)
        and not isinstance(candidate_value, (str, bytes))
        else []
    )
    candidates_match = len(candidates) == threshold_count
    candidates_by_key: dict[tuple[str, int, str], Mapping[str, Any]] = {}
    for candidate in candidates:
        if not isinstance(candidate, Mapping):
            candidates_match = False
            continue
        candidate_workload = candidate.get("workload")
        candidate_points = candidate.get("points")
        candidate_backend = candidate.get("backend")
        if (
            not isinstance(candidate_workload, str)
            or not isinstance(candidate_points, int)
            or isinstance(candidate_points, bool)
            or not isinstance(candidate_backend, str)
        ):
            candidates_match = False
            continue
        key = (
            candidate_workload,
            candidate_points,
            candidate_backend,
        )
        if key in candidates_by_key:
            candidates_match = False
        candidates_by_key[key] = candidate
    for derived in threshold_rows:
        candidate = candidates_by_key.get(
            (derived["workload"], derived["points"], "rust")
        )
        if not isinstance(candidate, Mapping):
            candidates_match = False
            continue
        candidates_match = candidates_match and all(
            (
                candidate.get("meets_threshold") is True,
                numbers_match(
                    candidate.get("seconds_median"),
                    derived["rust_seconds_median"],
                ),
                numbers_match(
                    candidate.get("speedup_vs_baseline"),
                    derived["speedup_vs_baseline"],
                ),
            )
        )

    release_gate = speedup.get("release_gate")
    release_gate = release_gate if isinstance(release_gate, Mapping) else {}
    threshold_counts_match = (
        release_gate.get("threshold_candidate_count") == threshold_count
        and release_gate.get("threshold_candidate_count_by_backend")
        == {"rust": threshold_count}
    )
    comparison_counts_match = (
        release_gate.get("comparison_count") == len(recomputed_rows) == 4
        and release_gate.get("completed_comparison_count")
        == len(recomputed_rows)
        and release_gate.get("missing_baseline_count") == 0
    )
    release_claims_match = (
        speedup.get("release_grade_speedup_claimed")
        is recomputed_release_claim
        and release_gate.get("release_grade_speedup_claimed")
        is recomputed_release_claim
        and release_gate.get("release_grade_speedup_claimed_by_backend")
        == {"rust": recomputed_release_claim}
    )
    expected_blocking_reasons: list[str] = []
    if not repeat_satisfied:
        expected_blocking_reasons.append("repeat_below_minimum")
    if threshold_count == 0:
        expected_blocking_reasons.append("no_backend_met_speedup_threshold")
    if threshold_count > 0 and not provenance_satisfied:
        expected_blocking_reasons.extend(provenance_blocking_reasons)
    blocking_reasons_match = (
        release_gate.get("blocking_reasons") == expected_blocking_reasons
    )

    backend_summary = speedup.get("backend_candidate_summary")
    backend_summary = backend_summary if isinstance(backend_summary, Mapping) else {}
    rust_summary = backend_summary.get("rust")
    rust_summary = rust_summary if isinstance(rust_summary, Mapping) else {}
    max_threshold_speedup = (
        max(row["speedup_vs_baseline"] for row in threshold_rows)
        if threshold_rows
        else None
    )
    max_speedup_matches = (
        rust_summary.get("max_speedup_vs_baseline") is None
        if max_threshold_speedup is None
        else numbers_match(
            rust_summary.get("max_speedup_vs_baseline"),
            max_threshold_speedup,
        )
    )
    rust_summary_matches = all(
        (
            set(backend_summary) == {"rust"},
            rust_summary.get("threshold_candidate_count") == threshold_count,
            rust_summary.get("threshold_workloads")
            == sorted(row["workload"] for row in threshold_rows),
            rust_summary.get("threshold_point_sizes")
            == ([128] if threshold_rows else []),
            rust_summary.get("fastest_comparison_count")
            == sum(
                1
                for row in recomputed_rows
                if row["fastest_backend"] == "rust"
            ),
            max_speedup_matches,
            rust_summary.get("release_grade_speedup_claimed")
            is recomputed_release_claim,
        )
    )

    matrix_summary = raw.get("matrix_summary")
    matrix_summary = matrix_summary if isinstance(matrix_summary, Mapping) else {}
    matrix_status_counts = matrix_summary.get("status_counts")
    speedup_provenance = speedup.get("rust_module_binary_provenance")
    speedup_provenance = (
        speedup_provenance if isinstance(speedup_provenance, Mapping) else {}
    )
    provenance_gate = speedup.get("rust_module_binary_provenance_gate")
    provenance_gate = (
        provenance_gate if isinstance(provenance_gate, Mapping) else {}
    )
    normalized_raw_provenance = {
        "available": provenance_available,
        "build_profile": (
            raw_provenance.get("build_profile")
            if isinstance(raw_provenance.get("build_profile"), str)
            else None
        ),
        "canonical_path": (
            raw_provenance.get("canonical_path")
            if isinstance(raw_provenance.get("canonical_path"), str)
            else None
        ),
        "byte_count": (
            provenance_byte_count if provenance_positive_byte_count else 0
        ),
        "sha256": (
            provenance_sha256.lower() if provenance_sha256_valid else None
        ),
    }
    backend_report = raw.get("backend_report")
    backend_report = (
        backend_report if isinstance(backend_report, Mapping) else {}
    )
    backend_rows = backend_report.get("backends")
    backend_rows = backend_rows if isinstance(backend_rows, Mapping) else {}
    rust_backend = backend_rows.get("rust")
    rust_backend = rust_backend if isinstance(rust_backend, Mapping) else {}
    rust_backend_info = rust_backend.get("backend_info")
    rust_backend_info = (
        rust_backend_info if isinstance(rust_backend_info, Mapping) else {}
    )
    backend_provenance = rust_backend.get("module_binary_provenance")
    backend_provenance = (
        backend_provenance if isinstance(backend_provenance, Mapping) else {}
    )
    checks = {
        "raw_workloads": raw.get("workloads") == list(expected_workloads),
        "raw_results_array": results_is_sequence and len(rows) == len(results),
        "raw_result_row_count": exact_row_count,
        "raw_result_unique_rows": unique_rows,
        "raw_result_expected_rows": expected_row_coverage,
        "raw_result_status_completed": rows_completed,
        "raw_repeat_strict_int": exact_int(repeat, 3),
        "raw_warmup_strict_int": exact_int(warmup, 1),
        "raw_result_repeat_matches": row_repeat_matches,
        "raw_result_warmup_matches": row_warmup_matches,
        "raw_result_seconds_length_matches_repeat": seconds_lengths_match,
        "raw_result_seconds_positive_finite": seconds_positive_finite,
        "raw_result_seconds_median_matches_samples": seconds_medians_match,
        "raw_result_seconds_min_matches_samples": seconds_minima_match,
        "raw_matrix_row_counts_match_results": (
            exact_int(matrix_summary.get("expected_row_count"), len(expected_keys))
            and exact_int(matrix_summary.get("row_count"), len(results))
            and exact_int(matrix_summary.get("completed_count"), len(results))
            and exact_int(matrix_summary.get("skipped_count"), 0)
            and exact_int(matrix_summary.get("failed_count"), 0)
        ),
        "raw_status_counts_match_results": (
            exact_int(raw.get("completed_count"), len(expected_keys))
            and exact_int(raw.get("skipped_count"), 0)
            and exact_int(raw.get("failed_count"), 0)
        ),
        "raw_matrix_status_counts_match_results": (
            isinstance(matrix_status_counts, Mapping)
            and set(matrix_status_counts) == {"completed", "skipped", "failed"}
            and exact_int(matrix_status_counts.get("completed"), len(expected_keys))
            and exact_int(matrix_status_counts.get("skipped"), 0)
            and exact_int(matrix_status_counts.get("failed"), 0)
        ),
        "raw_matrix_has_no_failures": (
            matrix_summary.get("has_failures") is False
        ),
        "recomputed_speedup_workload_count": len(recomputed_rows) == 4,
        "recomputed_speedup_threshold_candidate_available": threshold_count >= 1,
        "raw_rust_binary_provenance_available": provenance_available,
        "raw_rust_binary_provenance_release_profile": (
            provenance_release_profile
        ),
        "raw_rust_binary_provenance_positive_byte_count": (
            provenance_positive_byte_count
        ),
        "raw_rust_binary_provenance_sha256_valid": provenance_sha256_valid,
        "raw_rust_binary_provenance_canonical_path": (
            isinstance(raw_provenance.get("canonical_path"), str)
            and bool(raw_provenance.get("canonical_path"))
        ),
        "raw_rust_binary_provenance_backend_matches": (
            backend_provenance == raw_provenance
            and rust_backend_info.get("build_profile") == "release"
            and rust_backend_info.get("debug_assertions") is False
        ),
        "speedup_rust_binary_provenance_matches_raw": (
            speedup_provenance == normalized_raw_provenance
        ),
        "speedup_rust_binary_provenance_gate_matches_raw": (
            provenance_gate.get("required") is True
            and provenance_gate.get("available") is provenance_available
            and provenance_gate.get("release_profile")
            is provenance_release_profile
            and provenance_gate.get("positive_byte_count")
            is provenance_positive_byte_count
            and provenance_gate.get("sha256_valid")
            is provenance_sha256_valid
            and provenance_gate.get("satisfied") is provenance_satisfied
            and provenance_gate.get("blocking_reasons")
            == provenance_blocking_reasons
            and provenance_gate.get("provenance") == normalized_raw_provenance
        ),
        "release_gate_rust_binary_provenance_matches_recomputed": (
            release_gate.get("rust_module_binary_provenance_satisfied")
            is provenance_satisfied
            and release_gate.get(
                "rust_module_binary_provenance_blocking_reasons"
            )
            == provenance_blocking_reasons
        ),
        "speedup_baseline_backend": speedup.get("baseline_backend") == "numpy",
        "speedup_comparisons_match_recomputed": comparisons_match,
        "speedup_candidate_speedup_count_matches_recomputed": (
            speedup.get("candidate_speedup_count") == threshold_count
        ),
        "speedup_candidate_speedups_match_recomputed": candidates_match,
        "release_gate_comparison_counts_match_recomputed": comparison_counts_match,
        "release_gate_threshold_counts_match_recomputed": threshold_counts_match,
        "release_gate_claims_match_recomputed": release_claims_match,
        "release_gate_blocking_reasons_match_recomputed": blocking_reasons_match,
        "rust_summary_matches_recomputed": rust_summary_matches,
    }
    return {
        "checks": checks,
        "expected_result_row_count": len(expected_keys),
        "result_row_count": len(results),
        "unique_result_row_count": len(set(row_keys)),
        "recomputed_workload_speedups": recomputed_rows,
        "recomputed_threshold_candidate_count": threshold_count,
        "rust_module_binary_provenance": normalized_raw_provenance,
        "rust_module_binary_provenance_satisfied": provenance_satisfied,
        "rust_module_binary_provenance_blocking_reasons": (
            provenance_blocking_reasons
        ),
        "recomputed_release_grade_speedup_claimed": recomputed_release_claim,
    }


def _json_numbers_are_finite(value: Any) -> bool:
    if isinstance(value, Mapping):
        return all(_json_numbers_are_finite(item) for item in value.values())
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return all(_json_numbers_are_finite(item) for item in value)
    if isinstance(value, float):
        return math.isfinite(value)
    return True


def _broad_noisy_curve_robustness_certification_pack_evidence(
    pack: Mapping[str, Any] | None,
) -> dict[str, Any]:
    """Fail-closed audit of retained deterministic noisy-curve evidence."""

    if not isinstance(pack, Mapping):
        return {
            "available": False,
            "certified": False,
            "evidence_id": "broad_noisy_curve_robustness_certification_pack",
            "evidence_kind": "completion_evidence_artifact",
            "artifact_kind": None,
            "claim_scope": None,
            "required_check_count": 1,
            "passed_check_count": 0,
            "failed_check_count": 1,
            "failed_checks": [
                "broad_noisy_curve_robustness_certification_pack_available"
            ],
            "artifact_file_count": 0,
            "artifact_files": [],
            "completion_claimed": False,
        }

    checks: dict[str, bool] = {
        "artifact_schema_version": pack.get("artifact_schema_version") == 1,
        "artifact_kind": (
            pack.get("artifact_kind")
            == "broad_noisy_curve_robustness_certification_pack"
        ),
        "claim_scope": (
            pack.get("claim_scope")
            == "broad_noisy_sampled_curve_robustness_certification"
        ),
        "source_method": (
            pack.get("source_method")
            == "iroll broad-noisy-curve-robustness-pack-producer"
        ),
        "artifact_name": (
            pack.get("artifact_name")
            == "iroll-broad-noisy-curve-robustness-${{ matrix.os }}"
        ),
        "template_placeholder_not_true": pack.get("template_placeholder") is not True,
    }
    external = pack.get("_external_file_evidence")
    external = external if isinstance(external, Mapping) else {}
    parsed_payloads: dict[str, Mapping[str, Any]] = {}
    file_rows: list[dict[str, Any]] = []
    for role, expected_filename in _BROAD_NOISY_CURVE_ROBUSTNESS_FILENAMES.items():
        filename_field = f"{role}_filename"
        sha_field = f"{role}_sha256"
        row = external.get(role)
        row_mapping = row if isinstance(row, Mapping) else {}
        content_base64 = row_mapping.get("content_base64")
        decoded: bytes | None = None
        if isinstance(content_base64, str) and content_base64:
            try:
                decoded = base64.b64decode(content_base64, validate=True)
            except (ValueError, binascii.Error):
                decoded = None
        actual_sha256 = sha256(decoded).hexdigest() if decoded is not None else None
        declared_sha256 = pack.get(sha_field)
        external_sha256 = row_mapping.get("sha256")
        checks[f"{role}_external_file_available"] = decoded is not None
        checks[f"{role}_filename"] = (
            pack.get(filename_field) == expected_filename
            and row_mapping.get("filename") == expected_filename
        )
        checks[f"{role}_sha256"] = (
            isinstance(declared_sha256, str)
            and len(declared_sha256) == 64
            and declared_sha256 == actual_sha256
            and external_sha256 == actual_sha256
        )
        parsed: Any = None
        if decoded is not None:
            try:
                parsed = json.loads(decoded.decode("utf-8-sig"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                parsed = None
        checks[f"{role}_json_object"] = isinstance(parsed, Mapping)
        checks[f"{role}_json_numbers_finite"] = (
            isinstance(parsed, Mapping) and _json_numbers_are_finite(parsed)
        )
        if isinstance(parsed, Mapping):
            parsed_payloads[role] = parsed
        file_rows.append(
            {
                "role": role,
                "filename": row_mapping.get("filename"),
                "expected_filename": expected_filename,
                "byte_count": len(decoded) if decoded is not None else 0,
                "declared_sha256": declared_sha256,
                "external_sha256": external_sha256,
                "actual_sha256": actual_sha256,
                "sha256_verified": checks[f"{role}_sha256"],
                "json_object_verified": checks[f"{role}_json_object"],
            }
        )

    raw = parsed_payloads.get("raw", {})
    analysis = parsed_payloads.get("analysis", {})
    host = parsed_payloads.get("host", {})
    try:
        expected_payloads = broad_noisy_curve_robustness_certification_payloads()
    except Exception:
        expected_payloads = {}
    expected_raw = expected_payloads.get("raw", {})
    expected_analysis = expected_payloads.get("analysis", {})
    expected_host = expected_payloads.get("host", {})
    checks["deterministic_producer_recomputation_available"] = (
        isinstance(expected_raw, Mapping)
        and isinstance(expected_analysis, Mapping)
        and isinstance(expected_host, Mapping)
        and bool(expected_raw)
    )

    expected_family_names = [
        str(spec[0]) for spec in _BROAD_NOISY_CURVE_FAMILY_SPECS
    ]
    family_value = raw.get("curve_families")
    family_rows = (
        list(family_value)
        if isinstance(family_value, Sequence)
        and not isinstance(family_value, (str, bytes))
        else []
    )
    mapping_family_rows = [
        row for row in family_rows if isinstance(row, Mapping)
    ]
    family_names = [
        str(row.get("family")) for row in mapping_family_rows
    ]
    checks.update(
        {
            "raw_matches_deterministic_producer_recomputation": (
                bool(expected_raw) and raw == expected_raw
            ),
            "raw_artifact_schema_version": raw.get("artifact_schema_version") == 1,
            "raw_method": (
                raw.get("method")
                == "broad_noisy_curve_robustness_certification"
            ),
            "raw_claim_scope": (
                raw.get("claim_scope")
                == "broad_noisy_sampled_curve_robustness_certification"
            ),
            "raw_direction": raw.get("direction") == [0.2, -0.4, 1.0],
            "raw_requested_backend": raw.get("requested_backend") == "numpy",
            "raw_report_backends": (
                raw.get("report_backends")
                == ["curve_report", "imgui_geometry_payload"]
            ),
            "raw_exact_family_row_count": (
                len(family_rows) == len(_BROAD_NOISY_CURVE_FAMILY_SPECS)
                and len(mapping_family_rows) == len(family_rows)
            ),
            "raw_family_names_exact": family_names == expected_family_names,
            "raw_family_names_unique": (
                len(family_names) == len(set(family_names))
            ),
            "raw_family_summary_names_exact": (
                raw.get("representative_curve_families")
                == expected_family_names
            ),
            "raw_family_count": (
                raw.get("representative_curve_family_count")
                == len(_BROAD_NOISY_CURVE_FAMILY_SPECS)
            ),
            "raw_expected_family_count": (
                raw.get("expected_representative_curve_family_count")
                == len(_BROAD_NOISY_CURVE_FAMILY_SPECS)
            ),
            "raw_completed_family_count": (
                raw.get("completed_family_count")
                == len(_BROAD_NOISY_CURVE_FAMILY_SPECS)
            ),
            "raw_failed_family_count": raw.get("failed_family_count") == 0,
            "raw_failed_families_empty": raw.get("failed_families") == [],
            "raw_completion_claimed": raw.get("completion_claimed") is True,
        }
    )

    try:
        from iroll.reports import (
            imgui_geometry_payload_from_report,
            validate_report,
        )
    except Exception:
        imgui_geometry_payload_from_report = None
        validate_report = None
    family_reports_valid = len(mapping_family_rows) == len(
        _BROAD_NOISY_CURVE_FAMILY_SPECS
    )
    family_projections_match = family_reports_valid
    family_validation_checks_true = family_reports_valid
    family_validation_counts_match = family_reports_valid
    family_rows_passed = family_reports_valid
    family_point_counts_match = family_reports_valid
    family_metadata_complete = family_reports_valid
    family_source_metadata_valid = family_reports_valid
    family_expected_invariant_metadata_valid = family_reports_valid
    family_convention_metadata_valid = family_reports_valid
    family_numeric_tolerance_metadata_valid = family_reports_valid
    family_known_limitations_nonempty = family_reports_valid
    for row in mapping_family_rows:
        configuration = row.get("configuration")
        configuration = configuration if isinstance(configuration, Mapping) else {}
        report = row.get("curve_report")
        report = report if isinstance(report, Mapping) else {}
        imgui = row.get("imgui_geometry_payload")
        imgui = imgui if isinstance(imgui, Mapping) else {}
        validation_checks = row.get("validation_checks")
        validation_checks = (
            validation_checks
            if isinstance(validation_checks, Mapping)
            else {}
        )
        construction_source = row.get("construction_source")
        construction_source = (
            construction_source
            if isinstance(construction_source, Mapping)
            else {}
        )
        expected_invariant = row.get("expected_invariant")
        expected_invariant = (
            expected_invariant
            if isinstance(expected_invariant, Mapping)
            else {}
        )
        convention_normalization = row.get("convention_normalization")
        convention_normalization = (
            convention_normalization
            if isinstance(convention_normalization, Mapping)
            else {}
        )
        numeric_tolerance = row.get("numeric_tolerance")
        numeric_tolerance = (
            numeric_tolerance
            if isinstance(numeric_tolerance, Mapping)
            else {}
        )
        known_limitations_value = row.get("known_limitations")
        known_limitations = (
            list(known_limitations_value)
            if isinstance(known_limitations_value, Sequence)
            and not isinstance(known_limitations_value, (str, bytes))
            else []
        )
        if callable(validate_report):
            try:
                report_valid = not validate_report(report, kind="curve")
            except Exception:
                report_valid = False
        else:
            report_valid = False
        family_reports_valid = family_reports_valid and report_valid
        if callable(imgui_geometry_payload_from_report):
            try:
                projection_matches = (
                    imgui_geometry_payload_from_report(report) == imgui
                )
            except Exception:
                projection_matches = False
        else:
            projection_matches = False
        family_projections_match = (
            family_projections_match and projection_matches
        )
        family_validation_checks_true = (
            family_validation_checks_true
            and bool(validation_checks)
            and all(value is True for value in validation_checks.values())
        )
        family_validation_counts_match = (
            family_validation_counts_match
            and row.get("validation_check_count") == len(validation_checks)
            and row.get("validation_passed_check_count")
            == sum(1 for passed in validation_checks.values() if passed is True)
            and row.get("validation_failed_checks")
            == [
                name
                for name, passed in validation_checks.items()
                if passed is not True
            ]
        )
        family_rows_passed = family_rows_passed and row.get("passed") is True
        report_input = report.get("input")
        report_input = report_input if isinstance(report_input, Mapping) else {}
        family_point_counts_match = (
            family_point_counts_match
            and report_input.get("point_count")
            == configuration.get("resample_point_count")
            == imgui.get("geometry_point_count")
            and imgui.get("component_point_counts")
            == [configuration.get("resample_point_count")]
        )
        source_metadata_valid = (
            construction_source.get("source_kind")
            == "deterministic_synthetic_parametric_curve"
            and isinstance(construction_source.get("source_method"), str)
            and bool(construction_source.get("source_method"))
            and construction_source.get("source_url_applicable") is False
            and construction_source.get("source_url") is None
        )
        expected_invariant_metadata_valid = (
            expected_invariant.get("scope")
            == "finite_schema_valid_closed_single_component_geometry"
            and expected_invariant.get("closed") is True
            and expected_invariant.get("component_count") == 1
            and expected_invariant.get("point_count")
            == configuration.get("resample_point_count")
            and expected_invariant.get("strict_json_finite") is True
        )
        convention_metadata_valid = (
            convention_normalization.get("sampling_parameterization")
            == "theta_in_[0,2pi)_with_endpoint_excluded"
            and convention_normalization.get("closed_curve_storage")
            == "first_point_not_duplicated_at_endpoint"
            and convention_normalization.get("resampling")
            == "arc_length_resample_by_count"
            and convention_normalization.get("analysis_backend") == "numpy"
            and convention_normalization.get("analysis_projection_direction")
            == [0.2, -0.4, 1.0]
            and convention_normalization.get("imgui_projection")
            == "imgui_geometry_payload_from_report_without_topology_recompute"
        )
        numeric_tolerance_metadata_valid = (
            numeric_tolerance.get("comparison_mode")
            == "deterministic_exact_json_replay_plus_finite_numeric_checks"
            and numeric_tolerance.get("relative_tolerance") == 1e-12
            and numeric_tolerance.get("absolute_tolerance") == 1e-15
            and numeric_tolerance.get("finite_values_required") is True
            and numeric_tolerance.get("minimum_segment_length") == 1e-12
        )
        known_limitations_nonempty = (
            len(known_limitations) >= 3
            and all(isinstance(value, str) and value for value in known_limitations)
        )
        family_source_metadata_valid = (
            family_source_metadata_valid and source_metadata_valid
        )
        family_expected_invariant_metadata_valid = (
            family_expected_invariant_metadata_valid
            and expected_invariant_metadata_valid
        )
        family_convention_metadata_valid = (
            family_convention_metadata_valid and convention_metadata_valid
        )
        family_numeric_tolerance_metadata_valid = (
            family_numeric_tolerance_metadata_valid
            and numeric_tolerance_metadata_valid
        )
        family_known_limitations_nonempty = (
            family_known_limitations_nonempty and known_limitations_nonempty
        )
        family_metadata_complete = (
            family_metadata_complete
            and source_metadata_valid
            and expected_invariant_metadata_valid
            and convention_metadata_valid
            and numeric_tolerance_metadata_valid
            and known_limitations_nonempty
        )
    checks.update(
        {
            "raw_curve_reports_schema_valid": family_reports_valid,
            "raw_imgui_geometry_projections_match_curve_reports": (
                family_projections_match
            ),
            "raw_family_validation_checks_all_true": (
                family_validation_checks_true
            ),
            "raw_family_validation_counts_match": (
                family_validation_counts_match
            ),
            "raw_family_rows_passed": family_rows_passed,
            "raw_family_point_counts_match_across_projections": (
                family_point_counts_match
            ),
            "raw_family_metadata_complete": family_metadata_complete,
            "raw_family_construction_source_metadata_valid": (
                family_source_metadata_valid
            ),
            "raw_family_expected_invariant_metadata_valid": (
                family_expected_invariant_metadata_valid
            ),
            "raw_family_convention_normalization_metadata_valid": (
                family_convention_metadata_valid
            ),
            "raw_family_numeric_tolerance_metadata_valid": (
                family_numeric_tolerance_metadata_valid
            ),
            "raw_family_known_limitations_nonempty": (
                family_known_limitations_nonempty
            ),
        }
    )

    try:
        analysis_from_raw = (
            broad_noisy_curve_robustness_imgui_analysis_from_raw(raw)
        )
    except Exception:
        analysis_from_raw = {}
    checks.update(
        {
            "analysis_matches_raw_projection": (
                bool(analysis_from_raw) and analysis == analysis_from_raw
            ),
            "analysis_matches_deterministic_producer_recomputation": (
                bool(expected_analysis) and analysis == expected_analysis
            ),
            "analysis_method": (
                analysis.get("method")
                == "broad_noisy_curve_robustness_imgui_analysis"
            ),
            "analysis_family_count": (
                analysis.get("representative_curve_family_count")
                == len(_BROAD_NOISY_CURVE_FAMILY_SPECS)
                and analysis.get("curve_report_count")
                == len(_BROAD_NOISY_CURVE_FAMILY_SPECS)
                and analysis.get("imgui_geometry_payload_count")
                == len(_BROAD_NOISY_CURVE_FAMILY_SPECS)
            ),
            "analysis_completed_family_count": (
                analysis.get("completed_family_count")
                == len(_BROAD_NOISY_CURVE_FAMILY_SPECS)
                and analysis.get("failed_family_count") == 0
            ),
            "analysis_completion_claimed": (
                analysis.get("completion_claimed") is True
            ),
        }
    )
    try:
        host_from_raw = broad_noisy_curve_robustness_imgui_host_from_raw(
            raw,
            analysis=analysis,
        )
    except Exception:
        host_from_raw = {}
    checks.update(
        {
            "host_matches_raw_analysis_projection": (
                bool(host_from_raw) and host == host_from_raw
            ),
            "host_matches_deterministic_producer_recomputation": (
                bool(expected_host) and host == expected_host
            ),
            "host_method": (
                host.get("method")
                == "broad_noisy_curve_robustness_imgui_host"
            ),
            "host_analysis_matches_analysis_file": (
                host.get("analysis") == analysis
            ),
            "host_family_count": (
                host.get("representative_curve_family_count")
                == len(_BROAD_NOISY_CURVE_FAMILY_SPECS)
                and host.get("geometry_payload_count")
                == len(_BROAD_NOISY_CURVE_FAMILY_SPECS)
            ),
            "host_completion_claimed": host.get("completion_claimed") is True,
        }
    )
    checks.update(
        {
            "pack_family_count_matches_raw": (
                pack.get("representative_curve_family_count")
                == raw.get("representative_curve_family_count")
            ),
            "pack_family_names_match_raw": (
                pack.get("representative_curve_families")
                == raw.get("representative_curve_families")
            ),
            "pack_report_backends_match_raw": (
                pack.get("report_backends") == raw.get("report_backends")
            ),
            "pack_completion_claimed": pack.get("completion_claimed") is True,
        }
    )
    failed_checks = [name for name, passed in checks.items() if not passed]
    return {
        "available": True,
        "certified": not failed_checks,
        "evidence_id": "broad_noisy_curve_robustness_certification_pack",
        "evidence_kind": "completion_evidence_artifact",
        "artifact_kind": pack.get("artifact_kind"),
        "claim_scope": pack.get("claim_scope"),
        "source_method": pack.get("source_method"),
        "artifact_name": pack.get("artifact_name"),
        "representative_curve_family_count": pack.get(
            "representative_curve_family_count"
        ),
        "representative_curve_families": pack.get(
            "representative_curve_families"
        ),
        "report_backends": pack.get("report_backends"),
        "artifact_file_count": len(file_rows),
        "artifact_files": file_rows,
        "required_check_count": len(checks),
        "passed_check_count": len(checks) - len(failed_checks),
        "failed_check_count": len(failed_checks),
        "failed_checks": failed_checks,
        "checks": checks,
        "completion_claimed": not failed_checks,
    }


def _release_grade_high_point_performance_pack_evidence(
    pack: Mapping[str, Any] | None,
) -> dict[str, Any]:
    if not isinstance(pack, Mapping):
        return {
            "available": False,
            "certified": False,
            "evidence_id": "release_grade_high_point_performance_pack",
            "evidence_kind": "completion_evidence_artifact",
            "artifact_kind": None,
            "claim_scope": None,
            "required_check_count": 1,
            "passed_check_count": 0,
            "failed_check_count": 1,
            "failed_checks": ["release_grade_high_point_performance_pack_available"],
            "artifact_file_count": 0,
            "artifact_files": [],
            "completion_claimed": False,
        }

    checks: dict[str, bool] = {
        "artifact_schema_version": pack.get("artifact_schema_version") == 1,
        "artifact_kind": (
            pack.get("artifact_kind")
            == "release_grade_high_point_performance_pack"
        ),
        "claim_scope": (
            pack.get("claim_scope")
            == "release_grade_high_point_performance_certification"
        ),
        "source_method": (
            pack.get("source_method")
            == "iroll release-grade-high-point-performance-pack-producer"
        ),
        "artifact_name": (
            pack.get("artifact_name")
            == "iroll-release-grade-high-point-performance-${{ matrix.os }}"
        ),
        "template_placeholder_not_true": pack.get("template_placeholder") is not True,
    }
    external = pack.get("_external_file_evidence")
    if not isinstance(external, Mapping):
        external = {}
    parsed_payloads: dict[str, Mapping[str, Any]] = {}
    file_rows: list[dict[str, Any]] = []
    for role, expected_filename in _RELEASE_GRADE_HIGH_POINT_PERFORMANCE_FILENAMES.items():
        filename_field = f"{role}_filename"
        sha_field = f"{role}_sha256"
        row = external.get(role)
        row_mapping = row if isinstance(row, Mapping) else {}
        content_base64 = row_mapping.get("content_base64")
        decoded: bytes | None = None
        if isinstance(content_base64, str) and content_base64:
            try:
                decoded = base64.b64decode(content_base64, validate=True)
            except (ValueError, binascii.Error):
                decoded = None
        actual_sha256 = sha256(decoded).hexdigest() if decoded is not None else None
        declared_sha256 = pack.get(sha_field)
        external_sha256 = row_mapping.get("sha256")
        checks[f"{role}_external_file_available"] = decoded is not None
        checks[f"{role}_filename"] = (
            pack.get(filename_field) == expected_filename
            and row_mapping.get("filename") == expected_filename
        )
        checks[f"{role}_sha256"] = (
            isinstance(declared_sha256, str)
            and len(declared_sha256) == 64
            and declared_sha256 == actual_sha256
            and external_sha256 == actual_sha256
        )
        parsed: Any = None
        if decoded is not None:
            try:
                parsed = json.loads(decoded.decode("utf-8-sig"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                parsed = None
        checks[f"{role}_json_object"] = isinstance(parsed, Mapping)
        if isinstance(parsed, Mapping):
            parsed_payloads[role] = parsed
        file_rows.append(
            {
                "role": role,
                "filename": row_mapping.get("filename"),
                "expected_filename": expected_filename,
                "byte_count": len(decoded) if decoded is not None else 0,
                "declared_sha256": declared_sha256,
                "external_sha256": external_sha256,
                "actual_sha256": actual_sha256,
                "sha256_verified": checks[f"{role}_sha256"],
                "json_object_verified": checks[f"{role}_json_object"],
            }
        )

    raw = parsed_payloads.get("raw", {})
    analysis = parsed_payloads.get("analysis", {})
    host = parsed_payloads.get("host", {})
    speedup = raw.get("speedup_evidence")
    speedup = speedup if isinstance(speedup, Mapping) else {}
    rust_binary_provenance = raw.get("rust_module_binary_provenance")
    rust_binary_provenance = (
        rust_binary_provenance
        if isinstance(rust_binary_provenance, Mapping)
        else {}
    )
    release_gate = speedup.get("release_gate")
    release_gate = release_gate if isinstance(release_gate, Mapping) else {}
    backend_claims = release_gate.get("release_grade_speedup_claimed_by_backend")
    backend_claims = backend_claims if isinstance(backend_claims, Mapping) else {}
    backend_summary = speedup.get("backend_candidate_summary")
    backend_summary = backend_summary if isinstance(backend_summary, Mapping) else {}
    rust_summary = backend_summary.get("rust")
    rust_summary = rust_summary if isinstance(rust_summary, Mapping) else {}
    matrix_summary = raw.get("matrix_summary")
    matrix_summary = matrix_summary if isinstance(matrix_summary, Mapping) else {}
    completed_count = raw.get("completed_count", matrix_summary.get("completed_count"))
    failed_count = raw.get("failed_count", matrix_summary.get("failed_count"))
    timing_recomputation = _release_grade_high_point_timing_recomputation(raw)
    checks.update(timing_recomputation["checks"])
    checks.update(
        {
            "raw_method": raw.get("method") == "iroll_core_benchmark_matrix",
            "raw_point_sizes": raw.get("point_sizes") == [128],
            "raw_backends": raw.get("backends") == ["numpy", "rust"],
            "raw_repeat": raw.get("repeat") == 3,
            "raw_warmup": raw.get("warmup") == 1,
            "raw_all_requested_rows_completed": (
                matrix_summary.get("all_requested_rows_completed") is True
            ),
            "raw_completed_count": completed_count == 8,
            "raw_failed_count": failed_count == 0,
            "speedup_method": (
                speedup.get("method") == "iroll_core_benchmark_speedup_evidence"
            ),
            "speedup_repeat": speedup.get("repeat") == 3,
            "speedup_minimum_repeat": (
                speedup.get("minimum_repeat_for_release_claim") == 3
            ),
            "speedup_threshold": speedup.get("speedup_threshold") == 1.25,
            "speedup_release_grade_claimed": (
                speedup.get("release_grade_speedup_claimed") is True
            ),
            "release_gate_repeat_satisfied": (
                release_gate.get("repeat_satisfied") is True
            ),
            "release_gate_threshold_candidate": (
                isinstance(release_gate.get("threshold_candidate_count"), int)
                and release_gate.get("threshold_candidate_count") >= 1
            ),
            "release_gate_claimed": (
                release_gate.get("release_grade_speedup_claimed") is True
            ),
            "release_gate_rust_claimed": backend_claims.get("rust") is True,
            "rust_summary_claimed": (
                rust_summary.get("release_grade_speedup_claimed") is True
            ),
            "rust_summary_threshold_candidate": (
                isinstance(rust_summary.get("threshold_candidate_count"), int)
                and rust_summary.get("threshold_candidate_count") >= 1
            ),
            "rust_summary_point_sizes": (
                rust_summary.get("threshold_point_sizes") == [128]
            ),
        }
    )
    gpu_evidence = raw.get("cuda_gpu_benchmark_evidence")
    gpu_evidence = gpu_evidence if isinstance(gpu_evidence, Mapping) else {}
    checks["gpu_release_grade_claim_not_misused"] = (
        gpu_evidence.get("gpu_backend_requested") is False
        and gpu_evidence.get("release_grade_gpu_speedup_claimed") is False
    )

    analysis_summaries = analysis.get("analysis_summaries")
    analysis_summaries = (
        analysis_summaries
        if isinstance(analysis_summaries, Sequence)
        and not isinstance(analysis_summaries, (str, bytes))
        else []
    )
    benchmark_summaries = [
        row
        for row in analysis_summaries
        if isinstance(row, Mapping)
        and row.get("source_method") == "iroll_core_benchmark_matrix"
    ]
    benchmark_summary = benchmark_summaries[0] if len(benchmark_summaries) == 1 else {}
    checks.update(
        {
            "analysis_completed_count_matches_raw": (
                analysis.get("analysis_benchmark_matrix_completed_row_count")
                == completed_count
            ),
            "analysis_failed_count_matches_raw": (
                analysis.get("analysis_benchmark_matrix_failed_row_count")
                == failed_count
            ),
            "analysis_release_claim_matches_raw": (
                analysis.get("analysis_benchmark_speedup_release_grade_claimed_count")
                == (1 if speedup.get("release_grade_speedup_claimed") is True else 0)
            ),
            "analysis_speedup_projection_matches_recomputed": (
                analysis.get("analysis_benchmark_speedup_candidate_count")
                == timing_recomputation["recomputed_threshold_candidate_count"]
                and analysis.get(
                    "analysis_benchmark_speedup_threshold_candidate_count"
                )
                == timing_recomputation["recomputed_threshold_candidate_count"]
                and analysis.get(
                    "analysis_benchmark_speedup_completed_comparison_count"
                )
                == len(timing_recomputation["recomputed_workload_speedups"])
                and analysis.get(
                    "analysis_benchmark_speedup_missing_baseline_count"
                )
                == 0
                and analysis.get(
                    "analysis_benchmark_speedup_release_grade_claimed_count"
                )
                == (
                    1
                    if timing_recomputation[
                        "recomputed_release_grade_speedup_claimed"
                    ]
                    else 0
                )
            ),
            "analysis_gpu_nonclaim_matches_raw": (
                analysis.get(
                    "analysis_benchmark_cuda_gpu_release_grade_speedup_claimed_count"
                )
                == 0
            ),
            "analysis_single_benchmark_summary": len(benchmark_summaries) == 1,
            "analysis_summary_release_claimed": (
                benchmark_summary.get("benchmark_speedup_release_grade_claimed")
                is True
            ),
            "analysis_summary_repeat_satisfied": (
                benchmark_summary.get("benchmark_speedup_repeat_satisfied") is True
            ),
            "analysis_summary_speedup_projection_matches_recomputed": (
                benchmark_summary.get("benchmark_speedup_candidate_count")
                == timing_recomputation["recomputed_threshold_candidate_count"]
                and benchmark_summary.get(
                    "benchmark_speedup_threshold_candidate_count"
                )
                == timing_recomputation["recomputed_threshold_candidate_count"]
                and benchmark_summary.get(
                    "benchmark_speedup_completed_comparison_count"
                )
                == len(timing_recomputation["recomputed_workload_speedups"])
                and benchmark_summary.get(
                    "benchmark_speedup_release_grade_claimed"
                )
                is timing_recomputation[
                    "recomputed_release_grade_speedup_claimed"
                ]
            ),
        }
    )
    host_analysis = host.get("analysis")
    host_analysis_mapping = (
        host_analysis if isinstance(host_analysis, Mapping) else {}
    )
    host_analysis_summaries = host_analysis_mapping.get("analysis_summaries")
    host_analysis_summaries = (
        host_analysis_summaries
        if isinstance(host_analysis_summaries, Sequence)
        and not isinstance(host_analysis_summaries, (str, bytes))
        else []
    )
    host_benchmark_summaries = [
        row
        for row in host_analysis_summaries
        if isinstance(row, Mapping)
        and row.get("source_method") == "iroll_core_benchmark_matrix"
    ]
    host_benchmark_summary = (
        host_benchmark_summaries[0]
        if len(host_benchmark_summaries) == 1
        else {}
    )
    analysis_benchmark_fields = {
        key: value
        for key, value in analysis.items()
        if isinstance(key, str) and key.startswith("analysis_benchmark_")
    }
    host_benchmark_fields = {
        key: value
        for key, value in host_analysis_mapping.items()
        if isinstance(key, str) and key.startswith("analysis_benchmark_")
    }
    checks.update(
        {
            "host_method": host.get("method") == "imgui_host_payload",
            "host_analysis_object": isinstance(host_analysis, Mapping),
            "host_analysis_single_benchmark_summary": (
                len(host_benchmark_summaries) == 1
            ),
            "host_benchmark_summary_matches_analysis_file": (
                bool(benchmark_summary)
                and host_benchmark_summary == benchmark_summary
            ),
            "host_benchmark_counts_match_analysis_file": (
                bool(analysis_benchmark_fields)
                and host_benchmark_fields == analysis_benchmark_fields
            ),
        }
    )
    checks.update(
        {
            "pack_point_sizes_match_raw": pack.get("point_sizes") == raw.get("point_sizes"),
            "pack_backends_match_raw": pack.get("backends") == raw.get("backends"),
            "pack_repeat_matches_raw": pack.get("repeat") == raw.get("repeat"),
            "pack_warmup_matches_raw": pack.get("warmup") == raw.get("warmup"),
            "pack_speedup_threshold_matches_raw": (
                pack.get("speedup_threshold") == speedup.get("speedup_threshold")
            ),
            "pack_minimum_repeat_matches_raw": (
                pack.get("minimum_repeat_for_release_claim")
                == speedup.get("minimum_repeat_for_release_claim")
            ),
            "pack_rust_module_binary_provenance_matches_raw": (
                pack.get("rust_module_binary_provenance")
                == rust_binary_provenance
            ),
            "pack_rust_module_binary_provenance_release_profile": (
                isinstance(pack.get("rust_module_binary_provenance"), Mapping)
                and pack["rust_module_binary_provenance"].get("available")
                is True
                and pack["rust_module_binary_provenance"].get("build_profile")
                == "release"
                and isinstance(
                    pack["rust_module_binary_provenance"].get("byte_count"),
                    int,
                )
                and not isinstance(
                    pack["rust_module_binary_provenance"].get("byte_count"),
                    bool,
                )
                and pack["rust_module_binary_provenance"].get("byte_count") > 0
                and isinstance(
                    pack["rust_module_binary_provenance"].get("sha256"), str
                )
                and len(pack["rust_module_binary_provenance"]["sha256"]) == 64
            ),
            "pack_release_grade_speedup_claimed": (
                pack.get("release_grade_speedup_claimed") is True
                and speedup.get("release_grade_speedup_claimed") is True
            ),
            "pack_release_claim_matches_recomputed": (
                pack.get("release_grade_speedup_claimed")
                is timing_recomputation[
                    "recomputed_release_grade_speedup_claimed"
                ]
            ),
            "completion_claimed": pack.get("completion_claimed") is True,
        }
    )
    failed_checks = [name for name, passed in checks.items() if not passed]
    return {
        "available": True,
        "certified": not failed_checks,
        "evidence_id": "release_grade_high_point_performance_pack",
        "evidence_kind": "completion_evidence_artifact",
        "artifact_kind": pack.get("artifact_kind"),
        "claim_scope": pack.get("claim_scope"),
        "source_method": pack.get("source_method"),
        "artifact_name": pack.get("artifact_name"),
        "point_sizes": pack.get("point_sizes"),
        "backends": pack.get("backends"),
        "repeat": pack.get("repeat"),
        "warmup": pack.get("warmup"),
        "speedup_threshold": pack.get("speedup_threshold"),
        "minimum_repeat_for_release_claim": pack.get(
            "minimum_repeat_for_release_claim"
        ),
        "rust_module_binary_provenance": pack.get(
            "rust_module_binary_provenance"
        ),
        "release_grade_speedup_claimed": (
            pack.get("release_grade_speedup_claimed") is True
        ),
        "timing_recomputation": {
            key: value
            for key, value in timing_recomputation.items()
            if key != "checks"
        },
        "artifact_file_count": len(file_rows),
        "artifact_files": file_rows,
        "required_check_count": len(checks),
        "passed_check_count": len(checks) - len(failed_checks),
        "failed_check_count": len(failed_checks),
        "failed_checks": failed_checks,
        "checks": checks,
        "completion_claimed": not failed_checks,
    }


def cross_workstream_validation_pack_audit(
    *,
    required_notations: Sequence[str] | None = None,
    completion_evidence_bundle: Mapping[str, Any] | None = None,
    verified_signed_crossing_assignments: Sequence[Mapping[str, Any]] | None = None,
    production_imgui_renderer_framebuffer_pack: Mapping[str, Any] | None = None,
    signed_release_publication_manifest: Mapping[str, Any] | None = None,
    full_homfly_pt_evaluation_certification_pack: Mapping[str, Any] | None = None,
    full_multivariable_alexander_normalization_certification_pack: (
        Mapping[str, Any] | None
    ) = None,
    broad_noisy_curve_robustness_certification_pack: (
        Mapping[str, Any] | None
    ) = None,
    release_grade_high_point_performance_pack: Mapping[str, Any] | None = None,
) -> dict:
    """Audit fixture metadata needed by the final cross-workstream checklist."""

    bundle_evidence = _cross_workstream_completion_evidence_bundle_evidence(
        completion_evidence_bundle
    )
    bundle_payload = bundle_evidence["payload"]
    bundled_verified_assignments = bundle_payload.get(
        "verified_signed_crossing_assignments"
    )
    if not isinstance(bundled_verified_assignments, Sequence) or isinstance(
        bundled_verified_assignments,
        (str, bytes),
    ):
        bundled_verified_assignments = []
    all_verified_signed_assignments = [
        assignment
        for assignment in bundled_verified_assignments
        if isinstance(assignment, Mapping)
    ]
    all_verified_signed_assignments.extend(
        assignment
        for assignment in verified_signed_crossing_assignments or []
        if isinstance(assignment, Mapping)
    )
    production_imgui_renderer_framebuffer_pack = (
        production_imgui_renderer_framebuffer_pack
        or bundle_payload.get("production_imgui_renderer_framebuffer_pack")
    )
    signed_release_publication_manifest = (
        signed_release_publication_manifest
        or bundle_payload.get("signed_release_publication_manifest")
    )
    full_homfly_pt_evaluation_certification_pack = (
        full_homfly_pt_evaluation_certification_pack
        or bundle_payload.get("full_homfly_pt_evaluation_certification_pack")
    )
    full_multivariable_alexander_normalization_certification_pack = (
        full_multivariable_alexander_normalization_certification_pack
        or bundle_payload.get(
            "full_multivariable_alexander_normalization_certification_pack"
        )
    )
    broad_noisy_curve_robustness_certification_pack = (
        broad_noisy_curve_robustness_certification_pack
        or bundle_payload.get(
            "broad_noisy_curve_robustness_certification_pack"
        )
        or (
            completion_evidence_bundle.get(
                "broad_noisy_curve_robustness_certification_pack"
            )
            if isinstance(completion_evidence_bundle, Mapping)
            else None
        )
    )
    release_grade_high_point_performance_pack = (
        release_grade_high_point_performance_pack
        or bundle_payload.get("release_grade_high_point_performance_pack")
        or (
            completion_evidence_bundle.get(
                "release_grade_high_point_performance_pack"
            )
            if isinstance(completion_evidence_bundle, Mapping)
            else None
        )
    )

    required = tuple(required_notations or _CROSS_WORKSTREAM_REQUIRED_DIAGRAM_FIXTURES)
    fixture_by_notation = {fixture.notation: fixture for fixture in STANDARD_DIAGRAM_FIXTURES}
    rows = []
    missing_notations = []
    signed_fixture_blockers = []
    metadata_blockers = []
    verified_assignment_evidence_by_notation = (
        _verified_signed_crossing_assignment_evidence_by_notation(
            all_verified_signed_assignments
        )
    )
    verified_signed_assignment_notations = [
        str(assignment.get("notation") or "")
        for assignment in all_verified_signed_assignments
        if isinstance(assignment, Mapping)
    ]
    verified_signed_assignment_notation_counts = {
        notation: verified_signed_assignment_notations.count(notation)
        for notation in sorted(set(verified_signed_assignment_notations))
        if notation
    }
    duplicate_verified_signed_assignment_notations = [
        notation
        for notation, count in verified_signed_assignment_notation_counts.items()
        if count > 1
    ]
    missing_notation_verified_signed_assignment_count = sum(
        1 for notation in verified_signed_assignment_notations if not notation
    )
    unexpected_verified_signed_assignment_notations = [
        notation
        for notation in sorted(verified_signed_assignment_notation_counts)
        if notation not in required
    ]
    signed_fixture_certification_evidence = []
    for notation in required:
        fixture = fixture_by_notation.get(notation)
        if fixture is None:
            missing_notations.append(notation)
            metadata_blockers.append(
                {
                    "notation": notation,
                    "code": "required_fixture_missing",
                    "reason": "the required validation-pack fixture is not registered",
                }
            )
            continue
        row = _cross_workstream_validation_pack_fixture_row(fixture)
        assignment_evidence = verified_assignment_evidence_by_notation.get(notation)
        if assignment_evidence is not None:
            row["verified_signed_crossing_assignment"] = assignment_evidence
            row["verified_signed_crossing_assignment_available"] = (
                assignment_evidence["certified"] is True
            )
            if assignment_evidence["certified"] is True:
                row["has_signed_pd"] = True
                row["registration_status"] = (
                    "verified_signed_crossing_assignment_pack"
                )
                signed_fixture_certification_evidence.append(assignment_evidence)
        rows.append(row)
        metadata_blockers.extend(row["metadata_blockers"])
        if not row["has_signed_pd"]:
            candidate_evidence = _signed_fixture_candidate_blocker_evidence(fixture)
            signed_fixture_blockers.append(
                {
                    "notation": notation,
                    "code": "signed_pd_not_registered",
                    "registration_status": row["registration_status"],
                    "source": row["source"],
                    "source_url": row["source_url"],
                    "has_signed_pd": row["has_signed_pd"],
                    "has_gauss_code": row["has_gauss_code"],
                    "source_table_homfly_available": row[
                        "source_table_homfly_available"
                    ],
                    "source_table_multivariable_alexander_available": row[
                        "source_table_multivariable_alexander_available"
                    ],
                    "source_table_multivariable_alexander_numerator_available": row[
                        "source_table_multivariable_alexander_numerator_available"
                    ],
                    "source_candidate_evidence": candidate_evidence,
                    "source_candidate_evidence_available": (
                        candidate_evidence["available"]
                    ),
                    "source_candidate_matching_candidate_count": (
                        candidate_evidence["matching_candidate_count"]
                    ),
                    "source_candidate_unique_sign_pattern_count": (
                        candidate_evidence["unique_sign_pattern_count"]
                    ),
                    "source_candidate_replay_all_valid": (
                        candidate_evidence["all_returned_candidates_have_valid_replay"]
                    ),
                    "required_evidence": (
                        "verified signed crossing assignment for the source-table "
                        "fixture under the documented iroll PD convention"
                    ),
                    "current_evidence": (
                        "source-table and diagnostic metadata are available, but "
                        "the fixture remains unsigned and unregistered; "
                        "source-Gauss/pairwise candidate evidence is not unique"
                    ),
                    "missing_artifact": "verified_signed_crossing_assignment",
                    "reason": (
                        "fixture has source-table or diagnostic metadata but no verified "
                        "signed crossing assignment"
                    ),
                }
            )

    for notation in duplicate_verified_signed_assignment_notations:
        signed_fixture_blockers.append(
            {
                "notation": notation,
                "code": "verified_signed_crossing_assignment_duplicate",
                "registration_status": "duplicate_verified_signed_crossing_assignment",
                "source": "completion evidence input",
                "source_url": None,
                "has_signed_pd": False,
                "has_gauss_code": False,
                "source_table_homfly_available": False,
                "source_table_multivariable_alexander_available": False,
                "source_table_multivariable_alexander_numerator_available": False,
                "source_candidate_evidence_available": False,
                "source_candidate_matching_candidate_count": 0,
                "source_candidate_unique_sign_pattern_count": 0,
                "source_candidate_replay_all_valid": False,
                "required_evidence": (
                    "exactly one verified signed crossing assignment for each "
                    "required source-table fixture notation"
                ),
                "current_evidence": (
                    "multiple verified signed crossing assignment inputs claim "
                    f"notation {notation}"
                ),
                "missing_artifact": "verified_signed_crossing_assignment",
                "reason": (
                    "duplicate verified signed crossing assignment notation would "
                    "make final fixture registration ambiguous"
                ),
            }
        )
    for notation in unexpected_verified_signed_assignment_notations:
        signed_fixture_blockers.append(
            {
                "notation": notation,
                "code": "verified_signed_crossing_assignment_unexpected_notation",
                "registration_status": "unexpected_verified_signed_crossing_assignment",
                "source": "completion evidence input",
                "source_url": None,
                "has_signed_pd": False,
                "has_gauss_code": False,
                "source_table_homfly_available": False,
                "source_table_multivariable_alexander_available": False,
                "source_table_multivariable_alexander_numerator_available": False,
                "source_candidate_evidence_available": False,
                "source_candidate_matching_candidate_count": 0,
                "source_candidate_unique_sign_pattern_count": 0,
                "source_candidate_replay_all_valid": False,
                "required_evidence": (
                    "verified signed crossing assignments only for required "
                    "source-table fixture notations"
                ),
                "current_evidence": (
                    "a verified signed crossing assignment input claims "
                    f"unexpected notation {notation}"
                ),
                "missing_artifact": "verified_signed_crossing_assignment",
                "reason": (
                    "unexpected verified signed crossing assignment notation is "
                    "outside the final completion fixture scope"
                ),
            }
        )
    if missing_notation_verified_signed_assignment_count:
        signed_fixture_blockers.append(
            {
                "notation": "",
                "code": "verified_signed_crossing_assignment_missing_notation",
                "registration_status": "malformed_verified_signed_crossing_assignment",
                "source": "completion evidence input",
                "source_url": None,
                "has_signed_pd": False,
                "has_gauss_code": False,
                "source_table_homfly_available": False,
                "source_table_multivariable_alexander_available": False,
                "source_table_multivariable_alexander_numerator_available": False,
                "source_candidate_evidence_available": False,
                "source_candidate_matching_candidate_count": 0,
                "source_candidate_unique_sign_pattern_count": 0,
                "source_candidate_replay_all_valid": False,
                "required_evidence": (
                    "each verified signed crossing assignment input must name "
                    "one required source-table fixture notation"
                ),
                "current_evidence": (
                    "one or more verified signed crossing assignment inputs have "
                    "missing or blank notation"
                ),
                "missing_artifact": "verified_signed_crossing_assignment",
                "reason": (
                    "missing verified signed crossing assignment notation would "
                    "let a malformed input be silently ignored"
                ),
            }
        )

    signed_fixture_complete = not signed_fixture_blockers
    metadata_complete = not missing_notations and not metadata_blockers
    production_imgui_pack_evidence = (
        _production_imgui_renderer_framebuffer_pack_evidence(
            production_imgui_renderer_framebuffer_pack
        )
    )
    production_imgui_renderer_verified = production_imgui_pack_evidence[
        "certified"
    ]
    signed_release_publication_evidence = (
        _signed_release_publication_manifest_evidence(
            signed_release_publication_manifest
        )
    )
    release_artifacts_published = signed_release_publication_evidence[
        "certified"
    ]
    full_homfly_pt_evaluation_evidence = (
        _full_homfly_pt_evaluation_certification_pack_evidence(
            full_homfly_pt_evaluation_certification_pack
        )
    )
    full_homfly_pt_evaluation_certified = full_homfly_pt_evaluation_evidence[
        "certified"
    ]
    full_multivariable_alexander_normalization_evidence = (
        _full_multivariable_alexander_normalization_certification_pack_evidence(
            full_multivariable_alexander_normalization_certification_pack
        )
    )
    full_multivariable_alexander_normalization_certified = (
        full_multivariable_alexander_normalization_evidence["certified"]
    )
    release_grade_high_point_performance_evidence = (
        _release_grade_high_point_performance_pack_evidence(
            release_grade_high_point_performance_pack
        )
    )
    broad_noisy_curve_robustness_evidence = (
        _broad_noisy_curve_robustness_certification_pack_evidence(
            broad_noisy_curve_robustness_certification_pack
        )
    )
    non_diagram_requirements = _cross_workstream_non_diagram_requirements(
        production_imgui_renderer_framebuffer_pack_evidence=(
            production_imgui_pack_evidence
        ),
        broad_noisy_curve_robustness_certification_pack_evidence=(
            broad_noisy_curve_robustness_evidence
        ),
        release_grade_high_point_performance_pack_evidence=(
            release_grade_high_point_performance_evidence
        ),
    )
    non_diagram_fixture_metadata_complete_count = sum(
        1
        for row in non_diagram_requirements
        if row.get("metadata_complete") is True
    )
    non_diagram_fixture_metadata_incomplete_requirements = [
        str(row["requirement"])
        for row in non_diagram_requirements
        if row.get("metadata_complete") is not True
    ]
    open_non_diagram_requirements = [
        row for row in non_diagram_requirements if row["status"] != "available"
    ]
    non_diagram_blocker_code_by_requirement = {
        "noisy sampled curves": "noisy_sampled_curves_partial",
        "high-point-count performance curves": (
            "high_point_count_performance_curves_partial"
        ),
        "native ImGui screenshot/framebuffer fixtures": (
            "native_imgui_screenshot_framebuffer_fixtures_partial"
        ),
    }
    for row in open_non_diagram_requirements:
        row["blocker_code"] = non_diagram_blocker_code_by_requirement.get(
            row["requirement"],
            f"non_diagram_requirement_{row['status']}",
        )
    final_completion_blockers = []
    for blocker in signed_fixture_blockers:
        final_completion_blockers.append(
            {
                "kind": "signed_fixture",
                **blocker,
            }
        )
    for row in open_non_diagram_requirements:
        status = row["status"]
        code = row["blocker_code"]
        final_completion_blockers.append(
            {
                "kind": "non_diagram_requirement",
                "code": code,
                "requirement": row["requirement"],
                "status": status,
                "required_evidence": row.get("required_evidence"),
                "current_evidence": row.get("current_evidence", row["evidence"]),
                "missing_artifact": row.get("missing_artifact"),
                "missing_artifact_id": row.get("missing_artifact"),
                "retained_evidence": row.get(
                    "retained_evidence",
                    [],
                ),
                "completion_claimed": row.get("completion_claimed", False),
                "reason": row["evidence"],
            }
        )
    final_completion_non_claims = (
        {
            "gate": "full_homfly_pt_evaluation",
            "code": "full_homfly_pt_evaluation_not_certified",
            "passed": full_homfly_pt_evaluation_certified,
            "required_evidence": (
                "arbitrary signed-PD HOMFLY-PT evaluation certification and "
                "external table-normalization coverage"
            ),
            "current_evidence": (
                "certified full HOMFLY-PT evaluation pack"
                if full_homfly_pt_evaluation_certified
                else (
                    "registered fixtures, local skein identities, input certification, "
                    "and bounded generated small-diagram coverage only"
                )
            ),
            "missing_artifact": "full_homfly_pt_evaluation_certification_pack",
            "missing_artifact_id": "full_homfly_pt_evaluation_certification_pack",
            "retained_evidence": (
                [dict(full_homfly_pt_evaluation_evidence)]
                if full_homfly_pt_evaluation_certified
                else [
                    {
                        "evidence_id": "homfly_registered_fixture_acceptance_report",
                        "evidence_kind": "repository_test",
                        "source_method": "homfly_fixture_acceptance_report",
                        "claim_scope": "registered_fixture_homfly_regression_evidence",
                        "completion_claimed": False,
                    },
                    {
                        "evidence_id": "homfly_small_diagram_generated_coverage_report",
                        "evidence_kind": "repository_test",
                        "source_method": "homfly_small_diagram_coverage_report",
                        "claim_scope": "bounded_generated_homfly_small_diagram_evidence",
                        "completion_claimed": False,
                    },
                ]
            ),
        },
        {
            "gate": "full_multivariable_alexander_normalization",
            "code": "full_multivariable_alexander_normalization_not_certified",
            "passed": full_multivariable_alexander_normalization_certified,
            "required_evidence": (
                "full signed-PD Wirtinger/Fox multi-variable Alexander "
                "normalization certification across admissible minors"
            ),
            "current_evidence": (
                "certified full multi-variable Alexander normalization pack"
                if full_multivariable_alexander_normalization_certified
                else (
                    "registered fixtures, bounded scanned-gcd evidence, and bounded "
                    "generated signed-PD branch coverage only"
                )
            ),
            "missing_artifact": (
                "full_multivariable_alexander_normalization_certification_pack"
            ),
            "missing_artifact_id": (
                "full_multivariable_alexander_normalization_certification_pack"
            ),
            "retained_evidence": (
                [dict(full_multivariable_alexander_normalization_evidence)]
                if full_multivariable_alexander_normalization_certified
                else [
                    {
                        "evidence_id": "alexander_registered_fixture_acceptance_report",
                        "evidence_kind": "repository_test",
                        "source_method": "multivariable_alexander_fixture_acceptance_report",
                        "claim_scope": "registered_fixture_alexander_regression_evidence",
                        "completion_claimed": False,
                    },
                    {
                        "evidence_id": "alexander_generated_signed_pd_coverage_report",
                        "evidence_kind": "repository_test",
                        "source_method": "multivariable_alexander_signed_pd_coverage_report",
                        "claim_scope": "bounded_generated_alexander_signed_pd_evidence",
                        "completion_claimed": False,
                    },
                ]
            ),
        },
        {
            "gate": "production_imgui_renderer",
            "code": "production_imgui_renderer_not_verified",
            "passed": production_imgui_renderer_verified,
            "required_evidence": (
                "real host-controlled Dear ImGui renderer screenshot/framebuffer "
                "verification"
            ),
            "current_evidence": (
                "certified production Dear ImGui renderer framebuffer pack"
                if production_imgui_renderer_verified
                else (
                    "repository test-stub framebuffer and retained dynamic-loader "
                    "smoke evidence only"
                )
            ),
            "missing_artifact": "production_imgui_renderer_framebuffer_pack",
            "missing_artifact_id": "production_imgui_renderer_framebuffer_pack",
            "retained_evidence": (
                [dict(production_imgui_pack_evidence)]
                if production_imgui_renderer_verified
                else [
                    {
                        "evidence_id": "imgui_test_stub_framebuffer_smoke_retained_pack",
                        "evidence_kind": "ci_retained_artifact",
                        "source_method": "imgui_test_stub_framebuffer_smoke",
                        "claim_scope": "repository_imgui_test_stub_draw_list_framebuffer_estimate",
                        "real_graphics_backend_framebuffer_verified": False,
                        "screenshot_verified": False,
                        "completion_claimed": False,
                    },
                    {
                        "evidence_id": "imgui_real_kernel_loader_smoke_retained_pack",
                        "evidence_kind": "ci_retained_artifact",
                        "source_method": "imgui_real_kernel_loader_smoke",
                        "claim_scope": "runtime_loader_real_rust_dynamic_library_contract",
                        "real_graphics_backend_framebuffer_verified": False,
                        "screenshot_verified": False,
                        "completion_claimed": False,
                    },
                ]
            ),
        },
        {
            "gate": "release_artifacts",
            "code": "release_artifacts_not_published",
            "passed": release_artifacts_published,
            "required_evidence": (
                "signed published release artifacts and platform package index "
                "availability"
            ),
            "current_evidence": (
                "certified signed release publication manifest"
                if release_artifacts_published
                else (
                    "unsigned CI wheel/manifest retained metadata and non-publication "
                    "non-claims only"
                )
            ),
            "missing_artifact": "signed_release_publication_manifest",
            "missing_artifact_id": "signed_release_publication_manifest",
            "retained_evidence": (
                [dict(signed_release_publication_evidence)]
                if release_artifacts_published
                else [
                    {
                        "evidence_id": "rust_wheel_retained_metadata_manifest",
                        "evidence_kind": "ci_retained_artifact",
                        "source_method": "rust_wheel_retained_metadata_manifest",
                        "claim_scope": "unsigned_ci_rust_wheel_artifact_index",
                        "signed_release_artifacts_published": False,
                        "publication_claimed": False,
                        "completion_claimed": False,
                    },
                    {
                        "evidence_id": "imgui_windows_retained_artifacts_manifest",
                        "evidence_kind": "ci_retained_artifact",
                        "source_method": "imgui_windows_retained_artifacts_manifest",
                        "claim_scope": "windows_dear_imgui_retained_artifact_manifest",
                        "signed_release_artifacts_published": False,
                        "production_renderer_verified": False,
                        "completion_claimed": False,
                    },
                ]
            ),
        },
    )
    for non_claim in final_completion_non_claims:
        if not non_claim["passed"]:
            final_completion_blockers.append(
                {
                    "kind": "completion_gate",
                    "code": non_claim["code"],
                    "gate": non_claim["gate"],
                    "required_evidence": non_claim["required_evidence"],
                    "current_evidence": non_claim["current_evidence"],
                    "missing_artifact": non_claim["missing_artifact"],
                    "missing_artifact_id": non_claim["missing_artifact_id"],
                    "retained_evidence": non_claim.get("retained_evidence", []),
                    "reason": "required final-completion gate is not certified",
                }
            )
    final_completion_blocker_code_counts: dict[str, int] = {}
    for blocker in final_completion_blockers:
        code = blocker["code"]
        final_completion_blocker_code_counts[code] = (
            final_completion_blocker_code_counts.get(code, 0) + 1
        )
    retained_evidence_entries = [
        evidence
        for blocker in final_completion_blockers
        for evidence in blocker.get("retained_evidence", [])
        if isinstance(evidence, dict)
    ]
    retained_evidence_ids = sorted(
        {
            str(evidence["evidence_id"])
            for evidence in retained_evidence_entries
            if evidence.get("evidence_id")
        }
    )
    retained_evidence_claimed_count = sum(
        1
        for evidence in retained_evidence_entries
        if evidence.get("completion_claimed") is True
    )
    retained_evidence_release_grade_claimed_count = sum(
        1
        for evidence in retained_evidence_entries
        if evidence.get("release_grade_speedup_claimed") is True
    )
    retained_evidence_real_backend_claimed_count = sum(
        1
        for evidence in retained_evidence_entries
        if evidence.get("real_graphics_backend_framebuffer_verified") is True
    )
    retained_evidence_screenshot_claimed_count = sum(
        1
        for evidence in retained_evidence_entries
        if evidence.get("screenshot_verified") is True
    )
    retained_evidence_non_claim_consistency = {
        "claim_scope": "validation_pack_retained_evidence_non_claim_consistency",
        "entry_count": len(retained_evidence_entries),
        "evidence_id_count": len(retained_evidence_ids),
        "top_level_entry_count": len(retained_evidence_entries),
        "top_level_evidence_id_count": len(retained_evidence_ids),
        "completion_claimed_count": retained_evidence_claimed_count,
        "release_grade_speedup_claimed_count": (
            retained_evidence_release_grade_claimed_count
        ),
        "real_graphics_backend_framebuffer_verified_count": (
            retained_evidence_real_backend_claimed_count
        ),
        "screenshot_verified_count": retained_evidence_screenshot_claimed_count,
        "all_non_claimed": (
            retained_evidence_claimed_count == 0
            and retained_evidence_release_grade_claimed_count == 0
            and retained_evidence_real_backend_claimed_count == 0
            and retained_evidence_screenshot_claimed_count == 0
        ),
        "entry_count_matches_top_level": (
            len(retained_evidence_entries) == len(retained_evidence_entries)
        ),
        "evidence_id_count_matches_top_level": (
            len(retained_evidence_ids) == len(retained_evidence_ids)
        ),
        "completion_claimed_count_matches_top_level": (
            retained_evidence_claimed_count == retained_evidence_claimed_count
        ),
        "release_grade_speedup_claimed_count_matches_top_level": (
            retained_evidence_release_grade_claimed_count
            == retained_evidence_release_grade_claimed_count
        ),
        "real_graphics_backend_framebuffer_verified_count_matches_top_level": (
            retained_evidence_real_backend_claimed_count
            == retained_evidence_real_backend_claimed_count
        ),
        "screenshot_verified_count_matches_top_level": (
            retained_evidence_screenshot_claimed_count
            == retained_evidence_screenshot_claimed_count
        ),
        "matched": (
            retained_evidence_claimed_count == 0
            and retained_evidence_release_grade_claimed_count == 0
            and retained_evidence_real_backend_claimed_count == 0
            and retained_evidence_screenshot_claimed_count == 0
        ),
    }
    retained_evidence_artifact_file_rows = []
    retained_evidence_artifact_file_references: list[str] = []
    for evidence in retained_evidence_entries:
        artifact_files = [
            str(path)
            for path in evidence.get("artifact_files", [])
            if isinstance(path, str) and path
        ]
        raw_files = [
            path
            for path in artifact_files
            if not path.endswith("-imgui-analysis.json")
            and not path.endswith("-imgui-host.json")
        ]
        analysis_files = [
            path for path in artifact_files if path.endswith("-imgui-analysis.json")
        ]
        host_files = [
            path for path in artifact_files if path.endswith("-imgui-host.json")
        ]
        is_artifact_evidence = bool(artifact_files)
        complete_raw_analysis_host_group = (
            is_artifact_evidence
            and len(raw_files) == 1
            and len(analysis_files) == 1
            and len(host_files) == 1
            and len(artifact_files) == 3
        )
        retained_evidence_artifact_file_references.extend(artifact_files)
        retained_evidence_artifact_file_rows.append(
            {
                "evidence_id": evidence.get("evidence_id"),
                "evidence_kind": evidence.get("evidence_kind"),
                "artifact_name": evidence.get("artifact_name"),
                "artifact_file_count": len(artifact_files),
                "artifact_files": artifact_files,
                "raw_file_count": len(raw_files),
                "raw_files": raw_files,
                "analysis_file_count": len(analysis_files),
                "analysis_files": analysis_files,
                "host_file_count": len(host_files),
                "host_files": host_files,
                "is_artifact_evidence": is_artifact_evidence,
                "complete_raw_analysis_host_group": (
                    complete_raw_analysis_host_group
                ),
                "completion_claimed": evidence.get("completion_claimed"),
            }
        )
    retained_evidence_artifact_rows = [
        row
        for row in retained_evidence_artifact_file_rows
        if row["is_artifact_evidence"]
    ]
    retained_evidence_incomplete_artifact_rows = [
        row
        for row in retained_evidence_artifact_rows
        if not row["complete_raw_analysis_host_group"]
    ]
    retained_evidence_artifact_file_consistency = {
        "claim_scope": (
            "validation_pack_retained_evidence_artifact_file_consistency"
        ),
        "entry_count": len(retained_evidence_entries),
        "artifact_evidence_count": len(retained_evidence_artifact_rows),
        "non_artifact_evidence_count": (
            len(retained_evidence_entries) - len(retained_evidence_artifact_rows)
        ),
        "artifact_file_reference_count": len(
            retained_evidence_artifact_file_references
        ),
        "unique_artifact_file_count": len(
            set(retained_evidence_artifact_file_references)
        ),
        "raw_file_count": sum(
            row["raw_file_count"] for row in retained_evidence_artifact_file_rows
        ),
        "analysis_file_count": sum(
            row["analysis_file_count"]
            for row in retained_evidence_artifact_file_rows
        ),
        "host_file_count": sum(
            row["host_file_count"] for row in retained_evidence_artifact_file_rows
        ),
        "complete_raw_analysis_host_group_count": sum(
            1
            for row in retained_evidence_artifact_rows
            if row["complete_raw_analysis_host_group"]
        ),
        "incomplete_artifact_group_count": len(
            retained_evidence_incomplete_artifact_rows
        ),
        "artifact_file_reference_count_matches_groups": (
            len(retained_evidence_artifact_file_references)
            == len(retained_evidence_artifact_rows) * 3
        ),
        "raw_analysis_host_file_counts_matched": (
            sum(
                row["raw_file_count"]
                for row in retained_evidence_artifact_file_rows
            )
            == len(retained_evidence_artifact_rows)
            and sum(
                row["analysis_file_count"]
                for row in retained_evidence_artifact_file_rows
            )
            == len(retained_evidence_artifact_rows)
            and sum(
                row["host_file_count"]
                for row in retained_evidence_artifact_file_rows
            )
            == len(retained_evidence_artifact_rows)
        ),
        "all_artifact_evidence_groups_complete": (
            len(retained_evidence_incomplete_artifact_rows) == 0
        ),
        "all_artifact_files_unique": (
            len(retained_evidence_artifact_file_references)
            == len(set(retained_evidence_artifact_file_references))
        ),
        "matched": (
            len(retained_evidence_incomplete_artifact_rows) == 0
            and len(retained_evidence_artifact_file_references)
            == len(retained_evidence_artifact_rows) * 3
            and len(retained_evidence_artifact_file_references)
            == len(set(retained_evidence_artifact_file_references))
        ),
        "rows": retained_evidence_artifact_file_rows,
        "artifact_rows": retained_evidence_artifact_rows,
        "incomplete_artifact_rows": retained_evidence_incomplete_artifact_rows,
    }
    final_completion_blocker_evidence_links = []
    for blocker_index, blocker in enumerate(final_completion_blockers):
        retained_evidence = [
            evidence
            for evidence in blocker.get("retained_evidence", [])
            if isinstance(evidence, dict)
        ]
        retained_ids = sorted(
            {
                str(evidence["evidence_id"])
                for evidence in retained_evidence
                if evidence.get("evidence_id")
            }
        )
        completion_claimed_count = sum(
            1
            for evidence in retained_evidence
            if evidence.get("completion_claimed") is True
        )
        release_grade_claimed_count = sum(
            1
            for evidence in retained_evidence
            if evidence.get("release_grade_speedup_claimed") is True
        )
        real_backend_claimed_count = sum(
            1
            for evidence in retained_evidence
            if evidence.get("real_graphics_backend_framebuffer_verified") is True
        )
        screenshot_verified_count = sum(
            1
            for evidence in retained_evidence
            if evidence.get("screenshot_verified") is True
        )
        final_completion_blocker_evidence_links.append(
            {
                "blocker_index": blocker_index,
                "blocker_kind": blocker.get("kind"),
                "blocker_code": blocker.get("code"),
                "blocker_label": (
                    blocker.get("gate")
                    or blocker.get("requirement")
                    or blocker.get("notation")
                    or blocker.get("code")
                ),
                "missing_artifact": blocker.get("missing_artifact"),
                "required_evidence_present": bool(blocker.get("required_evidence")),
                "current_evidence_present": bool(blocker.get("current_evidence")),
                "retained_evidence_count": len(retained_evidence),
                "retained_evidence_ids": retained_ids,
                "retained_evidence_completion_claimed_count": (
                    completion_claimed_count
                ),
                "retained_evidence_release_grade_speedup_claimed_count": (
                    release_grade_claimed_count
                ),
                "retained_evidence_real_graphics_backend_framebuffer_verified_count": (
                    real_backend_claimed_count
                ),
                "retained_evidence_screenshot_verified_count": (
                    screenshot_verified_count
                ),
                "retained_evidence_all_non_claimed": (
                    completion_claimed_count == 0
                    and release_grade_claimed_count == 0
                    and real_backend_claimed_count == 0
                    and screenshot_verified_count == 0
                ),
            }
        )
    linked_blocker_count = sum(
        1
        for link in final_completion_blocker_evidence_links
        if link["retained_evidence_count"] > 0
    )
    link_retained_evidence_reference_count = sum(
        link["retained_evidence_count"]
        for link in final_completion_blocker_evidence_links
    )
    link_retained_evidence_ids = sorted(
        {
            evidence_id
            for link in final_completion_blocker_evidence_links
            for evidence_id in link["retained_evidence_ids"]
        }
    )
    link_retained_evidence_claimed_count = sum(
        link["retained_evidence_completion_claimed_count"]
        for link in final_completion_blocker_evidence_links
    )
    link_release_grade_claimed_count = sum(
        link["retained_evidence_release_grade_speedup_claimed_count"]
        for link in final_completion_blocker_evidence_links
    )
    link_real_backend_claimed_count = sum(
        link["retained_evidence_real_graphics_backend_framebuffer_verified_count"]
        for link in final_completion_blocker_evidence_links
    )
    link_screenshot_verified_count = sum(
        link["retained_evidence_screenshot_verified_count"]
        for link in final_completion_blocker_evidence_links
    )
    retained_evidence_link_non_claim_consistency_matches = (
        link_retained_evidence_claimed_count == retained_evidence_claimed_count
        and link_release_grade_claimed_count
        == retained_evidence_release_grade_claimed_count
        and link_real_backend_claimed_count == retained_evidence_real_backend_claimed_count
        and link_screenshot_verified_count == retained_evidence_screenshot_claimed_count
    )
    link_blocker_label_present_count = sum(
        1 for link in final_completion_blocker_evidence_links if link["blocker_label"]
    )
    link_blocker_code_present_count = sum(
        1 for link in final_completion_blocker_evidence_links if link["blocker_code"]
    )
    link_missing_artifact_present_count = sum(
        1
        for link in final_completion_blocker_evidence_links
        if link["missing_artifact"]
    )
    link_required_evidence_present_count = sum(
        1
        for link in final_completion_blocker_evidence_links
        if link["required_evidence_present"]
    )
    link_current_evidence_present_count = sum(
        1
        for link in final_completion_blocker_evidence_links
        if link["current_evidence_present"]
    )
    all_link_machine_fields_present = all(
        link["blocker_label"]
        and link["blocker_code"]
        and link["missing_artifact"]
        and link["required_evidence_present"]
        and link["current_evidence_present"]
        for link in final_completion_blocker_evidence_links
    )
    final_completion_blocker_evidence_link_consistency = {
        "claim_scope": (
            "validation_pack_final_completion_blocker_retained_evidence_link_consistency"
        ),
        "blocker_count": len(final_completion_blockers),
        "linked_blocker_count": linked_blocker_count,
        "unlinked_blocker_count": (
            len(final_completion_blockers) - linked_blocker_count
        ),
        "retained_evidence_reference_count": (
            link_retained_evidence_reference_count
        ),
        "retained_evidence_id_count": len(link_retained_evidence_ids),
        "retained_evidence_reference_count_matches_top_level": (
            link_retained_evidence_reference_count == len(retained_evidence_entries)
        ),
        "retained_evidence_id_count_matches_top_level": (
            link_retained_evidence_ids == retained_evidence_ids
        ),
        "retained_evidence_non_claim_consistency_matches_top_level": (
            retained_evidence_link_non_claim_consistency_matches
        ),
        "blocker_label_present_count": link_blocker_label_present_count,
        "blocker_code_present_count": link_blocker_code_present_count,
        "missing_artifact_present_count": link_missing_artifact_present_count,
        "required_evidence_present_count": link_required_evidence_present_count,
        "current_evidence_present_count": link_current_evidence_present_count,
        "all_blockers_have_machine_audit_fields": (
            all_link_machine_fields_present
        ),
        "matched": (
            len(final_completion_blocker_evidence_links)
            == len(final_completion_blockers)
            and link_retained_evidence_reference_count == len(retained_evidence_entries)
            and link_retained_evidence_ids == retained_evidence_ids
            and retained_evidence_link_non_claim_consistency_matches
            and all_link_machine_fields_present
        ),
    }
    blocker_evidence_link_kinds = sorted(
        {
            str(link["blocker_kind"])
            for link in final_completion_blocker_evidence_links
            if link.get("blocker_kind")
        }
    )
    blocker_evidence_link_kind_summary = []
    for blocker_kind in blocker_evidence_link_kinds:
        kind_links = [
            link
            for link in final_completion_blocker_evidence_links
            if link.get("blocker_kind") == blocker_kind
        ]
        kind_evidence_ids = sorted(
            {
                evidence_id
                for link in kind_links
                for evidence_id in link["retained_evidence_ids"]
            }
        )
        kind_linked_count = sum(
            1 for link in kind_links if link["retained_evidence_count"] > 0
        )
        blocker_evidence_link_kind_summary.append(
            {
                "blocker_kind": blocker_kind,
                "blocker_count": len(kind_links),
                "linked_blocker_count": kind_linked_count,
                "unlinked_blocker_count": len(kind_links) - kind_linked_count,
                "retained_evidence_reference_count": sum(
                    link["retained_evidence_count"] for link in kind_links
                ),
                "retained_evidence_id_count": len(kind_evidence_ids),
                "retained_evidence_ids": kind_evidence_ids,
                "retained_evidence_completion_claimed_count": sum(
                    link["retained_evidence_completion_claimed_count"]
                    for link in kind_links
                ),
                "retained_evidence_release_grade_speedup_claimed_count": sum(
                    link["retained_evidence_release_grade_speedup_claimed_count"]
                    for link in kind_links
                ),
                "retained_evidence_real_graphics_backend_framebuffer_verified_count": sum(
                    link[
                        "retained_evidence_real_graphics_backend_framebuffer_verified_count"
                    ]
                    for link in kind_links
                ),
                "retained_evidence_screenshot_verified_count": sum(
                    link["retained_evidence_screenshot_verified_count"]
                    for link in kind_links
                ),
                "retained_evidence_non_claimed_link_count": sum(
                    1
                    for link in kind_links
                    if link["retained_evidence_all_non_claimed"]
                ),
            }
        )
    blocker_evidence_link_kind_summary_by_kind = {
        row["blocker_kind"]: row for row in blocker_evidence_link_kind_summary
    }
    blocker_evidence_link_kind_detail_rows = []
    for blocker_kind in blocker_evidence_link_kinds:
        summary_row = blocker_evidence_link_kind_summary_by_kind.get(
            blocker_kind, {}
        )
        kind_links = [
            link
            for link in final_completion_blocker_evidence_links
            if link.get("blocker_kind") == blocker_kind
        ]
        expected_linked_count = sum(
            1 for link in kind_links if link["retained_evidence_count"] > 0
        )
        expected_unlinked_count = len(kind_links) - expected_linked_count
        expected_reference_count = sum(
            link["retained_evidence_count"] for link in kind_links
        )
        expected_evidence_ids = sorted(
            {
                evidence_id
                for link in kind_links
                for evidence_id in link["retained_evidence_ids"]
            }
        )
        expected_completion_claimed_count = sum(
            link["retained_evidence_completion_claimed_count"]
            for link in kind_links
        )
        expected_release_claimed_count = sum(
            link["retained_evidence_release_grade_speedup_claimed_count"]
            for link in kind_links
        )
        expected_real_backend_claimed_count = sum(
            link["retained_evidence_real_graphics_backend_framebuffer_verified_count"]
            for link in kind_links
        )
        expected_screenshot_verified_count = sum(
            link["retained_evidence_screenshot_verified_count"]
            for link in kind_links
        )
        expected_non_claimed_link_count = sum(
            1 for link in kind_links if link["retained_evidence_all_non_claimed"]
        )
        blocker_count_matched = summary_row.get("blocker_count") == len(kind_links)
        linked_count_matched = (
            summary_row.get("linked_blocker_count") == expected_linked_count
        )
        unlinked_count_matched = (
            summary_row.get("unlinked_blocker_count") == expected_unlinked_count
        )
        reference_count_matched = (
            summary_row.get("retained_evidence_reference_count")
            == expected_reference_count
        )
        evidence_ids_matched = (
            sorted(summary_row.get("retained_evidence_ids", []))
            == expected_evidence_ids
        )
        non_claim_counts_matched = (
            summary_row.get("retained_evidence_completion_claimed_count")
            == expected_completion_claimed_count
            and summary_row.get(
                "retained_evidence_release_grade_speedup_claimed_count"
            )
            == expected_release_claimed_count
            and summary_row.get(
                "retained_evidence_real_graphics_backend_framebuffer_verified_count"
            )
            == expected_real_backend_claimed_count
            and summary_row.get("retained_evidence_screenshot_verified_count")
            == expected_screenshot_verified_count
            and summary_row.get("retained_evidence_non_claimed_link_count")
            == expected_non_claimed_link_count
        )
        blocker_evidence_link_kind_detail_rows.append(
            {
                "blocker_kind": blocker_kind,
                "summary_blocker_count": summary_row.get("blocker_count", 0),
                "expected_blocker_count": len(kind_links),
                "blocker_count_matched": blocker_count_matched,
                "summary_linked_blocker_count": summary_row.get(
                    "linked_blocker_count", 0
                ),
                "expected_linked_blocker_count": expected_linked_count,
                "linked_blocker_count_matched": linked_count_matched,
                "summary_unlinked_blocker_count": summary_row.get(
                    "unlinked_blocker_count", 0
                ),
                "expected_unlinked_blocker_count": expected_unlinked_count,
                "unlinked_blocker_count_matched": unlinked_count_matched,
                "summary_retained_evidence_reference_count": summary_row.get(
                    "retained_evidence_reference_count", 0
                ),
                "expected_retained_evidence_reference_count": (
                    expected_reference_count
                ),
                "retained_evidence_reference_count_matched": (
                    reference_count_matched
                ),
                "summary_retained_evidence_ids": sorted(
                    summary_row.get("retained_evidence_ids", [])
                ),
                "expected_retained_evidence_ids": expected_evidence_ids,
                "retained_evidence_ids_matched": evidence_ids_matched,
                "summary_retained_evidence_completion_claimed_count": (
                    summary_row.get(
                        "retained_evidence_completion_claimed_count", 0
                    )
                ),
                "expected_retained_evidence_completion_claimed_count": (
                    expected_completion_claimed_count
                ),
                "summary_retained_evidence_release_grade_speedup_claimed_count": (
                    summary_row.get(
                        "retained_evidence_release_grade_speedup_claimed_count",
                        0,
                    )
                ),
                "expected_retained_evidence_release_grade_speedup_claimed_count": (
                    expected_release_claimed_count
                ),
                "summary_retained_evidence_real_graphics_backend_framebuffer_verified_count": (
                    summary_row.get(
                        "retained_evidence_real_graphics_backend_framebuffer_verified_count",
                        0,
                    )
                ),
                "expected_retained_evidence_real_graphics_backend_framebuffer_verified_count": (
                    expected_real_backend_claimed_count
                ),
                "summary_retained_evidence_screenshot_verified_count": (
                    summary_row.get(
                        "retained_evidence_screenshot_verified_count", 0
                    )
                ),
                "expected_retained_evidence_screenshot_verified_count": (
                    expected_screenshot_verified_count
                ),
                "summary_retained_evidence_non_claimed_link_count": (
                    summary_row.get("retained_evidence_non_claimed_link_count", 0)
                ),
                "expected_retained_evidence_non_claimed_link_count": (
                    expected_non_claimed_link_count
                ),
                "retained_evidence_non_claim_counts_matched": (
                    non_claim_counts_matched
                ),
                "matched": (
                    blocker_count_matched
                    and linked_count_matched
                    and unlinked_count_matched
                    and reference_count_matched
                    and evidence_ids_matched
                    and non_claim_counts_matched
                ),
            }
        )
    blocker_evidence_link_kind_mismatched_count = sum(
        1 for row in blocker_evidence_link_kind_detail_rows if not row["matched"]
    )
    final_completion_blocker_evidence_link_kind_summary_detail_consistency = {
        "claim_scope": (
            "validation_pack_final_completion_blocker_retained_evidence_link_kind_summary_detail_consistency"
        ),
        "summary_row_count": len(blocker_evidence_link_kind_summary),
        "checked_blocker_kind_count": len(blocker_evidence_link_kind_detail_rows),
        "blocker_count": len(final_completion_blocker_evidence_links),
        "linked_blocker_count": linked_blocker_count,
        "unlinked_blocker_count": (
            len(final_completion_blocker_evidence_links) - linked_blocker_count
        ),
        "retained_evidence_reference_count": (
            link_retained_evidence_reference_count
        ),
        "retained_evidence_id_count": len(link_retained_evidence_ids),
        "retained_evidence_completion_claimed_count": (
            link_retained_evidence_claimed_count
        ),
        "retained_evidence_release_grade_speedup_claimed_count": (
            link_release_grade_claimed_count
        ),
        "retained_evidence_real_graphics_backend_framebuffer_verified_count": (
            link_real_backend_claimed_count
        ),
        "retained_evidence_screenshot_verified_count": (
            link_screenshot_verified_count
        ),
        "retained_evidence_non_claimed_link_count": sum(
            row["retained_evidence_non_claimed_link_count"]
            for row in blocker_evidence_link_kind_summary
        ),
        "blocker_count_matched_count": sum(
            1
            for row in blocker_evidence_link_kind_detail_rows
            if row["blocker_count_matched"]
        ),
        "linked_blocker_count_matched_count": sum(
            1
            for row in blocker_evidence_link_kind_detail_rows
            if row["linked_blocker_count_matched"]
        ),
        "unlinked_blocker_count_matched_count": sum(
            1
            for row in blocker_evidence_link_kind_detail_rows
            if row["unlinked_blocker_count_matched"]
        ),
        "retained_evidence_reference_count_matched_count": sum(
            1
            for row in blocker_evidence_link_kind_detail_rows
            if row["retained_evidence_reference_count_matched"]
        ),
        "retained_evidence_ids_matched_count": sum(
            1
            for row in blocker_evidence_link_kind_detail_rows
            if row["retained_evidence_ids_matched"]
        ),
        "retained_evidence_non_claim_counts_matched_count": sum(
            1
            for row in blocker_evidence_link_kind_detail_rows
            if row["retained_evidence_non_claim_counts_matched"]
        ),
        "mismatched_summary_row_count": blocker_evidence_link_kind_mismatched_count,
        "summary_blocker_count_total_matches_top_level": (
            sum(row["blocker_count"] for row in blocker_evidence_link_kind_summary)
            == len(final_completion_blocker_evidence_links)
        ),
        "summary_retained_evidence_reference_count_total_matches_top_level": (
            sum(
                row["retained_evidence_reference_count"]
                for row in blocker_evidence_link_kind_summary
            )
            == link_retained_evidence_reference_count
        ),
        "summary_retained_evidence_ids_match_top_level": (
            sorted(
                {
                    evidence_id
                    for row in blocker_evidence_link_kind_summary
                    for evidence_id in row["retained_evidence_ids"]
                }
            )
            == link_retained_evidence_ids
        ),
        "matched": blocker_evidence_link_kind_mismatched_count == 0
        and sum(row["blocker_count"] for row in blocker_evidence_link_kind_summary)
        == len(final_completion_blocker_evidence_links)
        and sum(
            row["retained_evidence_reference_count"]
            for row in blocker_evidence_link_kind_summary
        )
        == link_retained_evidence_reference_count
        and sorted(
            {
                evidence_id
                for row in blocker_evidence_link_kind_summary
                for evidence_id in row["retained_evidence_ids"]
            }
        )
        == link_retained_evidence_ids,
        "rows": blocker_evidence_link_kind_detail_rows,
        "blocker_kind_rows": blocker_evidence_link_kind_detail_rows,
    }
    missing_artifact_references = [
        str(blocker["missing_artifact"])
        for blocker in final_completion_blockers
        if blocker.get("missing_artifact")
    ]
    missing_artifact_ids = sorted(set(missing_artifact_references))
    final_completion_missing_artifact_count = len(missing_artifact_ids)
    final_completion_missing_artifact_signature = "|".join(missing_artifact_ids)
    missing_artifact_reference_counts = {
        artifact_id: missing_artifact_references.count(artifact_id)
        for artifact_id in missing_artifact_ids
    }
    final_completion_missing_artifact_summary = [
        {
            "missing_artifact": artifact_id,
            "blocker_count": missing_artifact_reference_counts[artifact_id],
            "blocker_codes": sorted(
                {
                    str(blocker["code"])
                    for blocker in final_completion_blockers
                    if blocker.get("missing_artifact") == artifact_id
                    and blocker.get("code")
                }
            ),
            "blocker_labels": sorted(
                {
                    str(
                        blocker.get("gate")
                        or blocker.get("requirement")
                        or blocker.get("notation")
                        or blocker.get("code")
                    )
                    for blocker in final_completion_blockers
                    if blocker.get("missing_artifact") == artifact_id
                }
            ),
        }
        for artifact_id in missing_artifact_ids
    ]
    final_completion_missing_artifact_summary_consistency = {
        "claim_scope": "validation_pack_final_completion_missing_artifact_summary_consistency",
        "reference_count": len(missing_artifact_references),
        "unique_missing_artifact_count": len(missing_artifact_ids),
        "summary_row_count": len(final_completion_missing_artifact_summary),
        "blocker_count": len(final_completion_blockers),
        "references_match_blocker_count": (
            len(missing_artifact_references) == len(final_completion_blockers)
        ),
        "summary_row_count_matches_unique_missing_artifacts": (
            len(final_completion_missing_artifact_summary)
            == len(missing_artifact_ids)
        ),
        "all_blockers_have_missing_artifact": (
            len(missing_artifact_references) == len(final_completion_blockers)
        ),
        "missing_artifacts": missing_artifact_ids,
        "top_level_missing_artifact_count": final_completion_missing_artifact_count,
        "top_level_missing_artifacts": missing_artifact_ids,
        "top_level_missing_artifact_signature": (
            final_completion_missing_artifact_signature
        ),
        "top_level_missing_artifact_count_matches_summary": (
            final_completion_missing_artifact_count
            == len(final_completion_missing_artifact_summary)
        ),
        "top_level_missing_artifacts_match_summary": (
            missing_artifact_ids
            == sorted(
                str(row["missing_artifact"])
                for row in final_completion_missing_artifact_summary
            )
        ),
        "matched": (
            len(missing_artifact_references) == len(final_completion_blockers)
            and len(final_completion_missing_artifact_summary)
            == len(missing_artifact_ids)
            and final_completion_missing_artifact_count
            == len(final_completion_missing_artifact_summary)
            and missing_artifact_ids
            == sorted(
                str(row["missing_artifact"])
                for row in final_completion_missing_artifact_summary
            )
        ),
    }
    missing_artifact_summary_by_id = {
        row["missing_artifact"]: row
        for row in final_completion_missing_artifact_summary
    }
    missing_artifact_detail_consistency_rows = []
    for artifact_id in missing_artifact_ids:
        summary_row = missing_artifact_summary_by_id.get(artifact_id, {})
        blocker_rows = [
            blocker
            for blocker in final_completion_blockers
            if blocker.get("missing_artifact") == artifact_id
        ]
        expected_codes = sorted(
            {
                str(blocker["code"])
                for blocker in blocker_rows
                if blocker.get("code")
            }
        )
        expected_labels = sorted(
            {
                str(
                    blocker.get("gate")
                    or blocker.get("requirement")
                    or blocker.get("notation")
                    or blocker.get("code")
                )
                for blocker in blocker_rows
            }
        )
        summary_codes = sorted(
            str(code) for code in summary_row.get("blocker_codes", [])
        )
        summary_labels = sorted(
            str(label) for label in summary_row.get("blocker_labels", [])
        )
        count_matched = summary_row.get("blocker_count") == len(blocker_rows)
        codes_matched = summary_codes == expected_codes
        labels_matched = summary_labels == expected_labels
        missing_artifact_detail_consistency_rows.append(
            {
                "missing_artifact": artifact_id,
                "summary_row_present": bool(summary_row),
                "summary_blocker_count": summary_row.get("blocker_count", 0),
                "expected_blocker_count": len(blocker_rows),
                "blocker_count_matched": count_matched,
                "summary_blocker_codes": summary_codes,
                "expected_blocker_codes": expected_codes,
                "blocker_codes_matched": codes_matched,
                "summary_blocker_labels": summary_labels,
                "expected_blocker_labels": expected_labels,
                "blocker_labels_matched": labels_matched,
                "matched": (
                    bool(summary_row)
                    and count_matched
                    and codes_matched
                    and labels_matched
                ),
            }
        )
    missing_artifact_detail_mismatched_count = sum(
        1
        for row in missing_artifact_detail_consistency_rows
        if not row["matched"]
    )
    final_completion_missing_artifact_summary_detail_consistency = {
        "claim_scope": (
            "validation_pack_final_completion_missing_artifact_summary_detail_consistency"
        ),
        "summary_row_count": len(final_completion_missing_artifact_summary),
        "unique_missing_artifact_count": len(missing_artifact_ids),
        "checked_missing_artifact_count": len(missing_artifact_detail_consistency_rows),
        "blocker_count": len(final_completion_blockers),
        "blocker_code_reference_count": sum(
            len(row.get("blocker_codes", []))
            for row in final_completion_missing_artifact_summary
        ),
        "blocker_label_reference_count": sum(
            len(row.get("blocker_labels", []))
            for row in final_completion_missing_artifact_summary
        ),
        "summary_blocker_count_total": sum(
            int(row.get("blocker_count", 0) or 0)
            for row in final_completion_missing_artifact_summary
        ),
        "blocker_count_matched_count": sum(
            1
            for row in missing_artifact_detail_consistency_rows
            if row["blocker_count_matched"]
        ),
        "blocker_codes_matched_count": sum(
            1
            for row in missing_artifact_detail_consistency_rows
            if row["blocker_codes_matched"]
        ),
        "blocker_labels_matched_count": sum(
            1
            for row in missing_artifact_detail_consistency_rows
            if row["blocker_labels_matched"]
        ),
        "mismatched_summary_row_count": missing_artifact_detail_mismatched_count,
        "all_summary_rows_present": all(
            row["summary_row_present"]
            for row in missing_artifact_detail_consistency_rows
        ),
        "all_blocker_counts_matched": all(
            row["blocker_count_matched"]
            for row in missing_artifact_detail_consistency_rows
        ),
        "all_blocker_codes_matched": all(
            row["blocker_codes_matched"]
            for row in missing_artifact_detail_consistency_rows
        ),
        "all_blocker_labels_matched": all(
            row["blocker_labels_matched"]
            for row in missing_artifact_detail_consistency_rows
        ),
        "summary_blocker_count_total_matches_top_level": (
            sum(
                int(row.get("blocker_count", 0) or 0)
                for row in final_completion_missing_artifact_summary
            )
            == len(final_completion_blockers)
        ),
        "matched": missing_artifact_detail_mismatched_count == 0
        and sum(
            int(row.get("blocker_count", 0) or 0)
            for row in final_completion_missing_artifact_summary
        )
        == len(final_completion_blockers),
        "rows": missing_artifact_detail_consistency_rows,
        "missing_artifact_rows": missing_artifact_detail_consistency_rows,
    }
    blocker_evidence_field_rows = []
    blocker_kind_counts: dict[str, dict[str, int]] = {}
    for blocker_index, blocker in enumerate(final_completion_blockers):
        kind = str(blocker.get("kind") or "")
        label = (
            blocker.get("gate")
            or blocker.get("requirement")
            or blocker.get("notation")
            or blocker.get("code")
        )
        row = {
            "blocker_index": blocker_index,
            "blocker_kind": kind,
            "blocker_code": blocker.get("code"),
            "blocker_label": label,
            "missing_artifact_present": bool(blocker.get("missing_artifact")),
            "required_evidence_present": bool(blocker.get("required_evidence")),
            "current_evidence_present": bool(blocker.get("current_evidence")),
        }
        row["all_evidence_fields_present"] = (
            bool(row["blocker_code"])
            and bool(row["blocker_label"])
            and row["missing_artifact_present"]
            and row["required_evidence_present"]
            and row["current_evidence_present"]
        )
        blocker_evidence_field_rows.append(row)
        kind_row = blocker_kind_counts.setdefault(
            kind,
            {
                "blocker_count": 0,
                "missing_artifact_present_count": 0,
                "required_evidence_present_count": 0,
                "current_evidence_present_count": 0,
                "all_evidence_fields_present_count": 0,
            },
        )
        kind_row["blocker_count"] += 1
        if row["missing_artifact_present"]:
            kind_row["missing_artifact_present_count"] += 1
        if row["required_evidence_present"]:
            kind_row["required_evidence_present_count"] += 1
        if row["current_evidence_present"]:
            kind_row["current_evidence_present_count"] += 1
        if row["all_evidence_fields_present"]:
            kind_row["all_evidence_fields_present_count"] += 1
    final_completion_blocker_evidence_field_summary = [
        {"blocker_kind": kind, **blocker_kind_counts[kind]}
        for kind in sorted(blocker_kind_counts)
    ]
    evidence_field_missing_artifact_count = sum(
        1 for row in blocker_evidence_field_rows if row["missing_artifact_present"]
    )
    evidence_field_required_count = sum(
        1 for row in blocker_evidence_field_rows if row["required_evidence_present"]
    )
    evidence_field_current_count = sum(
        1 for row in blocker_evidence_field_rows if row["current_evidence_present"]
    )
    evidence_field_all_present_count = sum(
        1 for row in blocker_evidence_field_rows if row["all_evidence_fields_present"]
    )
    final_completion_blocker_evidence_field_consistency = {
        "claim_scope": "validation_pack_final_completion_blocker_evidence_field_consistency",
        "blocker_count": len(final_completion_blockers),
        "summary_row_count": len(final_completion_blocker_evidence_field_summary),
        "missing_artifact_present_count": evidence_field_missing_artifact_count,
        "required_evidence_present_count": evidence_field_required_count,
        "current_evidence_present_count": evidence_field_current_count,
        "all_evidence_fields_present_count": evidence_field_all_present_count,
        "all_blockers_have_missing_artifact": (
            evidence_field_missing_artifact_count == len(final_completion_blockers)
        ),
        "all_blockers_have_required_evidence": (
            evidence_field_required_count == len(final_completion_blockers)
        ),
        "all_blockers_have_current_evidence": (
            evidence_field_current_count == len(final_completion_blockers)
        ),
        "all_blockers_have_evidence_fields": (
            evidence_field_all_present_count == len(final_completion_blockers)
        ),
        "matched": (
            evidence_field_all_present_count == len(final_completion_blockers)
            and sum(
                row["blocker_count"]
                for row in final_completion_blocker_evidence_field_summary
            )
            == len(final_completion_blockers)
        ),
    }
    evidence_field_summary_by_kind = {
        row["blocker_kind"]: row
        for row in final_completion_blocker_evidence_field_summary
    }
    evidence_field_summary_detail_rows = []
    for kind in sorted(blocker_kind_counts):
        summary_row = evidence_field_summary_by_kind.get(kind, {})
        kind_rows = [
            row
            for row in blocker_evidence_field_rows
            if row.get("blocker_kind") == kind
        ]
        expected_blocker_count = len(kind_rows)
        expected_missing_count = sum(
            1 for row in kind_rows if row["missing_artifact_present"]
        )
        expected_required_count = sum(
            1 for row in kind_rows if row["required_evidence_present"]
        )
        expected_current_count = sum(
            1 for row in kind_rows if row["current_evidence_present"]
        )
        expected_all_count = sum(
            1 for row in kind_rows if row["all_evidence_fields_present"]
        )
        blocker_count_matched = (
            summary_row.get("blocker_count") == expected_blocker_count
        )
        missing_count_matched = (
            summary_row.get("missing_artifact_present_count")
            == expected_missing_count
        )
        required_count_matched = (
            summary_row.get("required_evidence_present_count")
            == expected_required_count
        )
        current_count_matched = (
            summary_row.get("current_evidence_present_count")
            == expected_current_count
        )
        all_count_matched = (
            summary_row.get("all_evidence_fields_present_count")
            == expected_all_count
        )
        evidence_field_summary_detail_rows.append(
            {
                "blocker_kind": kind,
                "summary_row_present": bool(summary_row),
                "summary_blocker_count": summary_row.get("blocker_count", 0),
                "expected_blocker_count": expected_blocker_count,
                "blocker_count_matched": blocker_count_matched,
                "summary_missing_artifact_present_count": summary_row.get(
                    "missing_artifact_present_count", 0
                ),
                "expected_missing_artifact_present_count": (
                    expected_missing_count
                ),
                "missing_artifact_present_count_matched": (
                    missing_count_matched
                ),
                "summary_required_evidence_present_count": summary_row.get(
                    "required_evidence_present_count", 0
                ),
                "expected_required_evidence_present_count": (
                    expected_required_count
                ),
                "required_evidence_present_count_matched": (
                    required_count_matched
                ),
                "summary_current_evidence_present_count": summary_row.get(
                    "current_evidence_present_count", 0
                ),
                "expected_current_evidence_present_count": (
                    expected_current_count
                ),
                "current_evidence_present_count_matched": current_count_matched,
                "summary_all_evidence_fields_present_count": summary_row.get(
                    "all_evidence_fields_present_count", 0
                ),
                "expected_all_evidence_fields_present_count": expected_all_count,
                "all_evidence_fields_present_count_matched": all_count_matched,
                "matched": (
                    bool(summary_row)
                    and blocker_count_matched
                    and missing_count_matched
                    and required_count_matched
                    and current_count_matched
                    and all_count_matched
                ),
            }
        )
    evidence_field_summary_detail_mismatched_count = sum(
        1 for row in evidence_field_summary_detail_rows if not row["matched"]
    )
    final_completion_blocker_evidence_field_summary_detail_consistency = {
        "claim_scope": (
            "validation_pack_final_completion_blocker_evidence_field_summary_detail_consistency"
        ),
        "summary_row_count": len(final_completion_blocker_evidence_field_summary),
        "checked_blocker_kind_count": len(evidence_field_summary_detail_rows),
        "blocker_count": len(final_completion_blockers),
        "missing_artifact_present_count": evidence_field_missing_artifact_count,
        "required_evidence_present_count": evidence_field_required_count,
        "current_evidence_present_count": evidence_field_current_count,
        "all_evidence_fields_present_count": evidence_field_all_present_count,
        "summary_blocker_count_total": sum(
            int(row.get("blocker_count", 0) or 0)
            for row in final_completion_blocker_evidence_field_summary
        ),
        "blocker_count_matched_count": sum(
            1
            for row in evidence_field_summary_detail_rows
            if row["blocker_count_matched"]
        ),
        "missing_artifact_present_count_matched_count": sum(
            1
            for row in evidence_field_summary_detail_rows
            if row["missing_artifact_present_count_matched"]
        ),
        "required_evidence_present_count_matched_count": sum(
            1
            for row in evidence_field_summary_detail_rows
            if row["required_evidence_present_count_matched"]
        ),
        "current_evidence_present_count_matched_count": sum(
            1
            for row in evidence_field_summary_detail_rows
            if row["current_evidence_present_count_matched"]
        ),
        "all_evidence_fields_present_count_matched_count": sum(
            1
            for row in evidence_field_summary_detail_rows
            if row["all_evidence_fields_present_count_matched"]
        ),
        "mismatched_summary_row_count": evidence_field_summary_detail_mismatched_count,
        "all_summary_rows_present": all(
            row["summary_row_present"]
            for row in evidence_field_summary_detail_rows
        ),
        "all_blocker_counts_matched": all(
            row["blocker_count_matched"]
            for row in evidence_field_summary_detail_rows
        ),
        "all_evidence_field_counts_matched": all(
            row["missing_artifact_present_count_matched"]
            and row["required_evidence_present_count_matched"]
            and row["current_evidence_present_count_matched"]
            and row["all_evidence_fields_present_count_matched"]
            for row in evidence_field_summary_detail_rows
        ),
        "summary_blocker_count_total_matches_top_level": (
            sum(
                int(row.get("blocker_count", 0) or 0)
                for row in final_completion_blocker_evidence_field_summary
            )
            == len(final_completion_blockers)
        ),
        "matched": evidence_field_summary_detail_mismatched_count == 0
        and sum(
            int(row.get("blocker_count", 0) or 0)
            for row in final_completion_blocker_evidence_field_summary
        )
        == len(final_completion_blockers),
        "rows": evidence_field_summary_detail_rows,
        "blocker_kind_rows": evidence_field_summary_detail_rows,
    }
    blocker_kind_summary_counts: dict[str, dict[str, object]] = {}
    for blocker in final_completion_blockers:
        kind = str(blocker.get("kind") or "")
        row = blocker_kind_summary_counts.setdefault(
            kind,
            {
                "blocker_count": 0,
                "blocker_codes": [],
                "missing_artifacts": [],
            },
        )
        row["blocker_count"] = int(row["blocker_count"]) + 1
        code = blocker.get("code")
        if code and code not in row["blocker_codes"]:
            row["blocker_codes"].append(code)
        missing_artifact = blocker.get("missing_artifact")
        if (
            missing_artifact
            and missing_artifact not in row["missing_artifacts"]
        ):
            row["missing_artifacts"].append(missing_artifact)
    final_completion_blocker_kind_summary = [
        {
            "blocker_kind": kind,
            "blocker_count": int(blocker_kind_summary_counts[kind]["blocker_count"]),
            "blocker_codes": sorted(blocker_kind_summary_counts[kind]["blocker_codes"]),
            "missing_artifacts": sorted(
                blocker_kind_summary_counts[kind]["missing_artifacts"]
            ),
        }
        for kind in sorted(blocker_kind_summary_counts)
    ]
    final_completion_blocker_kind_count_by_kind = {
        row["blocker_kind"]: row["blocker_count"]
        for row in final_completion_blocker_kind_summary
    }
    final_completion_blocker_kind_summary_blocker_count = sum(
        row["blocker_count"] for row in final_completion_blocker_kind_summary
    )
    final_completion_blocker_kind_consistency = {
        "claim_scope": "validation_pack_final_completion_blocker_kind_consistency",
        "blocker_count": len(final_completion_blockers),
        "summary_row_count": len(final_completion_blocker_kind_summary),
        "summary_blocker_count": final_completion_blocker_kind_summary_blocker_count,
        "kind_count_total": final_completion_blocker_kind_summary_blocker_count,
        "blocker_kind_count": len(final_completion_blocker_kind_summary),
        "kind_count": len(final_completion_blocker_kind_summary),
        "blocker_kind_counts": final_completion_blocker_kind_count_by_kind,
        "kind_counts": final_completion_blocker_kind_count_by_kind,
        "signed_fixture_blocker_count": final_completion_blocker_kind_count_by_kind.get(
            "signed_fixture", 0
        ),
        "non_diagram_requirement_blocker_count": (
            final_completion_blocker_kind_count_by_kind.get(
                "non_diagram_requirement", 0
            )
        ),
        "completion_gate_blocker_count": final_completion_blocker_kind_count_by_kind.get(
            "completion_gate", 0
        ),
        "all_blockers_have_kind": all(
            bool(blocker.get("kind")) for blocker in final_completion_blockers
        ),
        "summary_blocker_count_matches_top_level": (
            final_completion_blocker_kind_summary_blocker_count
            == len(final_completion_blockers)
        ),
        "kind_count_total_matches_blocker_count": (
            final_completion_blocker_kind_summary_blocker_count
            == len(final_completion_blockers)
        ),
        "unique_kind_count_matches_summary": (
            len(final_completion_blocker_kind_count_by_kind)
            == len(final_completion_blocker_kind_summary)
        ),
        "matched": (
            final_completion_blocker_kind_summary_blocker_count
            == len(final_completion_blockers)
            and len(final_completion_blocker_kind_count_by_kind)
            == len(final_completion_blocker_kind_summary)
            and all(
                bool(blocker.get("kind")) for blocker in final_completion_blockers
            )
        ),
    }
    blocker_kind_summary_by_kind = {
        row["blocker_kind"]: row for row in final_completion_blocker_kind_summary
    }
    blocker_kind_summary_detail_rows = []
    for kind in sorted(final_completion_blocker_kind_count_by_kind):
        summary_row = blocker_kind_summary_by_kind.get(kind, {})
        kind_blockers = [
            blocker
            for blocker in final_completion_blockers
            if blocker.get("kind") == kind
        ]
        expected_codes = sorted(
            {
                str(blocker["code"])
                for blocker in kind_blockers
                if blocker.get("code")
            }
        )
        expected_missing_artifacts = sorted(
            {
                str(blocker["missing_artifact"])
                for blocker in kind_blockers
                if blocker.get("missing_artifact")
            }
        )
        summary_codes = sorted(
            str(code) for code in summary_row.get("blocker_codes", [])
        )
        summary_missing_artifacts = sorted(
            str(artifact)
            for artifact in summary_row.get("missing_artifacts", [])
        )
        blocker_count_matched = (
            summary_row.get("blocker_count") == len(kind_blockers)
        )
        codes_matched = summary_codes == expected_codes
        missing_artifacts_matched = (
            summary_missing_artifacts == expected_missing_artifacts
        )
        blocker_kind_summary_detail_rows.append(
            {
                "blocker_kind": kind,
                "summary_row_present": bool(summary_row),
                "summary_blocker_count": summary_row.get("blocker_count", 0),
                "expected_blocker_count": len(kind_blockers),
                "blocker_count_matched": blocker_count_matched,
                "summary_blocker_codes": summary_codes,
                "expected_blocker_codes": expected_codes,
                "blocker_codes_matched": codes_matched,
                "summary_missing_artifacts": summary_missing_artifacts,
                "expected_missing_artifacts": expected_missing_artifacts,
                "missing_artifacts_matched": missing_artifacts_matched,
                "matched": (
                    bool(summary_row)
                    and blocker_count_matched
                    and codes_matched
                    and missing_artifacts_matched
                ),
            }
        )
    blocker_kind_summary_detail_mismatched_count = sum(
        1 for row in blocker_kind_summary_detail_rows if not row["matched"]
    )
    blocker_kind_summary_detail_missing_artifacts = sorted(
        {
            artifact
            for row in final_completion_blocker_kind_summary
            for artifact in row.get("missing_artifacts", [])
        }
    )
    final_completion_blocker_kind_summary_detail_consistency = {
        "claim_scope": (
            "validation_pack_final_completion_blocker_kind_summary_detail_consistency"
        ),
        "summary_row_count": len(final_completion_blocker_kind_summary),
        "kind_count": len(final_completion_blocker_kind_summary),
        "checked_blocker_kind_count": len(blocker_kind_summary_detail_rows),
        "blocker_count": len(final_completion_blockers),
        "blocker_code_reference_count": sum(
            len(row.get("blocker_codes", []))
            for row in final_completion_blocker_kind_summary
        ),
        "unique_blocker_code_reference_count": sum(
            len(row.get("blocker_codes", []))
            for row in final_completion_blocker_kind_summary
        ),
        "missing_artifact_reference_count": sum(
            len(row.get("missing_artifacts", []))
            for row in final_completion_blocker_kind_summary
        ),
        "unique_missing_artifact_reference_count": sum(
            len(row.get("missing_artifacts", []))
            for row in final_completion_blocker_kind_summary
        ),
        "unique_missing_artifact_count": len(
            blocker_kind_summary_detail_missing_artifacts
        ),
        "summary_blocker_count_total": sum(
            int(row.get("blocker_count", 0) or 0)
            for row in final_completion_blocker_kind_summary
        ),
        "blocker_count_matched_count": sum(
            1
            for row in blocker_kind_summary_detail_rows
            if row["blocker_count_matched"]
        ),
        "blocker_codes_matched_count": sum(
            1
            for row in blocker_kind_summary_detail_rows
            if row["blocker_codes_matched"]
        ),
        "missing_artifacts_matched_count": sum(
            1
            for row in blocker_kind_summary_detail_rows
            if row["missing_artifacts_matched"]
        ),
        "mismatched_summary_row_count": (
            blocker_kind_summary_detail_mismatched_count
        ),
        "all_summary_rows_present": all(
            row["summary_row_present"]
            for row in blocker_kind_summary_detail_rows
        ),
        "all_blocker_counts_matched": all(
            row["blocker_count_matched"]
            for row in blocker_kind_summary_detail_rows
        ),
        "all_blocker_codes_matched": all(
            row["blocker_codes_matched"]
            for row in blocker_kind_summary_detail_rows
        ),
        "all_missing_artifacts_matched": all(
            row["missing_artifacts_matched"]
            for row in blocker_kind_summary_detail_rows
        ),
        "summary_blocker_count_total_matches_top_level": (
            sum(
                int(row.get("blocker_count", 0) or 0)
                for row in final_completion_blocker_kind_summary
            )
            == len(final_completion_blockers)
        ),
        "matched": blocker_kind_summary_detail_mismatched_count == 0
        and sum(
            int(row.get("blocker_count", 0) or 0)
            for row in final_completion_blocker_kind_summary
        )
        == len(final_completion_blockers),
        "rows": blocker_kind_summary_detail_rows,
        "kind_rows": blocker_kind_summary_detail_rows,
    }
    final_completion_blocker_codes = sorted(final_completion_blocker_code_counts)
    final_completion_blocker_signature = ",".join(
        f"{code}:{final_completion_blocker_code_counts[code]}"
        for code in final_completion_blocker_codes
    )
    final_completion_blocker_code_count_total = sum(
        final_completion_blocker_code_counts.values()
    )
    final_completion_blocker_code_signature_from_counts = ",".join(
        f"{code}:{final_completion_blocker_code_counts[code]}"
        for code in sorted(final_completion_blocker_code_counts)
    )
    final_completion_blocker_code_summary = []
    for code in final_completion_blocker_codes:
        code_blockers = [
            blocker
            for blocker in final_completion_blockers
            if blocker.get("code") == code
        ]
        blocker_kinds = sorted(
            {
                str(blocker["kind"])
                for blocker in code_blockers
                if blocker.get("kind")
            }
        )
        blocker_labels = sorted(
            {
                str(
                    blocker.get("gate")
                    or blocker.get("requirement")
                    or blocker.get("notation")
                    or blocker.get("code")
                )
                for blocker in code_blockers
            }
        )
        missing_artifacts = sorted(
            {
                str(blocker["missing_artifact"])
                for blocker in code_blockers
                if blocker.get("missing_artifact")
            }
        )
        final_completion_blocker_code_summary.append(
            {
                "blocker_code": code,
                "blocker_count": len(code_blockers),
                "blocker_kinds": blocker_kinds,
                "blocker_labels": blocker_labels,
                "missing_artifacts": missing_artifacts,
            }
        )
    blocker_code_summary_by_code = {
        row["blocker_code"]: row for row in final_completion_blocker_code_summary
    }
    blocker_code_summary_detail_rows = []
    for code in final_completion_blocker_codes:
        summary_row = blocker_code_summary_by_code.get(code, {})
        code_blockers = [
            blocker
            for blocker in final_completion_blockers
            if blocker.get("code") == code
        ]
        expected_kinds = sorted(
            {
                str(blocker["kind"])
                for blocker in code_blockers
                if blocker.get("kind")
            }
        )
        expected_labels = sorted(
            {
                str(
                    blocker.get("gate")
                    or blocker.get("requirement")
                    or blocker.get("notation")
                    or blocker.get("code")
                )
                for blocker in code_blockers
            }
        )
        expected_missing_artifacts = sorted(
            {
                str(blocker["missing_artifact"])
                for blocker in code_blockers
                if blocker.get("missing_artifact")
            }
        )
        summary_kinds = sorted(
            str(kind) for kind in summary_row.get("blocker_kinds", [])
        )
        summary_labels = sorted(
            str(label) for label in summary_row.get("blocker_labels", [])
        )
        summary_missing_artifacts = sorted(
            str(artifact)
            for artifact in summary_row.get("missing_artifacts", [])
        )
        blocker_count_matched = (
            summary_row.get("blocker_count") == len(code_blockers)
        )
        kinds_matched = summary_kinds == expected_kinds
        labels_matched = summary_labels == expected_labels
        missing_artifacts_matched = (
            summary_missing_artifacts == expected_missing_artifacts
        )
        blocker_code_summary_detail_rows.append(
            {
                "blocker_code": code,
                "summary_row_present": bool(summary_row),
                "summary_blocker_count": summary_row.get("blocker_count", 0),
                "expected_blocker_count": len(code_blockers),
                "blocker_count_matched": blocker_count_matched,
                "summary_blocker_kinds": summary_kinds,
                "expected_blocker_kinds": expected_kinds,
                "blocker_kinds_matched": kinds_matched,
                "summary_blocker_labels": summary_labels,
                "expected_blocker_labels": expected_labels,
                "blocker_labels_matched": labels_matched,
                "summary_missing_artifacts": summary_missing_artifacts,
                "expected_missing_artifacts": expected_missing_artifacts,
                "missing_artifacts_matched": missing_artifacts_matched,
                "matched": (
                    bool(summary_row)
                    and blocker_count_matched
                    and kinds_matched
                    and labels_matched
                    and missing_artifacts_matched
                ),
            }
        )
    blocker_code_summary_detail_mismatched_count = sum(
        1 for row in blocker_code_summary_detail_rows if not row["matched"]
    )
    blocker_code_summary_detail_missing_artifacts = sorted(
        {
            artifact
            for row in final_completion_blocker_code_summary
            for artifact in row.get("missing_artifacts", [])
        }
    )
    final_completion_blocker_code_summary_detail_consistency = {
        "claim_scope": (
            "validation_pack_final_completion_blocker_code_summary_detail_consistency"
        ),
        "summary_row_count": len(final_completion_blocker_code_summary),
        "code_count": len(final_completion_blocker_codes),
        "checked_blocker_code_count": len(blocker_code_summary_detail_rows),
        "blocker_count": len(final_completion_blockers),
        "blocker_kind_reference_count": sum(
            len(row.get("blocker_kinds", []))
            for row in final_completion_blocker_code_summary
        ),
        "blocker_label_reference_count": sum(
            len(row.get("blocker_labels", []))
            for row in final_completion_blocker_code_summary
        ),
        "missing_artifact_reference_count": sum(
            len(row.get("missing_artifacts", []))
            for row in final_completion_blocker_code_summary
        ),
        "unique_missing_artifact_count": len(
            blocker_code_summary_detail_missing_artifacts
        ),
        "summary_blocker_count_total": sum(
            row["blocker_count"] for row in final_completion_blocker_code_summary
        ),
        "blocker_count_matched_count": sum(
            1
            for row in blocker_code_summary_detail_rows
            if row["blocker_count_matched"]
        ),
        "blocker_kinds_matched_count": sum(
            1
            for row in blocker_code_summary_detail_rows
            if row["blocker_kinds_matched"]
        ),
        "blocker_labels_matched_count": sum(
            1
            for row in blocker_code_summary_detail_rows
            if row["blocker_labels_matched"]
        ),
        "missing_artifacts_matched_count": sum(
            1
            for row in blocker_code_summary_detail_rows
            if row["missing_artifacts_matched"]
        ),
        "mismatched_summary_row_count": (
            blocker_code_summary_detail_mismatched_count
        ),
        "all_summary_rows_present": all(
            row["summary_row_present"] for row in blocker_code_summary_detail_rows
        ),
        "all_blocker_counts_matched": all(
            row["blocker_count_matched"]
            for row in blocker_code_summary_detail_rows
        ),
        "all_blocker_kinds_matched": all(
            row["blocker_kinds_matched"]
            for row in blocker_code_summary_detail_rows
        ),
        "all_blocker_labels_matched": all(
            row["blocker_labels_matched"]
            for row in blocker_code_summary_detail_rows
        ),
        "all_missing_artifacts_matched": all(
            row["missing_artifacts_matched"]
            for row in blocker_code_summary_detail_rows
        ),
        "summary_blocker_count_total_matches_top_level": (
            sum(
                int(row.get("blocker_count", 0) or 0)
                for row in final_completion_blocker_code_summary
            )
            == len(final_completion_blockers)
        ),
        "matched": blocker_code_summary_detail_mismatched_count == 0
        and sum(
            int(row.get("blocker_count", 0) or 0)
            for row in final_completion_blocker_code_summary
        )
        == len(final_completion_blockers),
        "rows": blocker_code_summary_detail_rows,
        "code_rows": blocker_code_summary_detail_rows,
    }
    final_completion_blocker_code_consistency = {
        "claim_scope": "validation_pack_final_completion_blocker_code_consistency",
        "blocker_count": len(final_completion_blockers),
        "code_count": len(final_completion_blocker_codes),
        "top_level_code_count": len(final_completion_blocker_code_counts),
        "code_count_total": final_completion_blocker_code_count_total,
        "blocker_codes": final_completion_blocker_codes,
        "code_counts": dict(final_completion_blocker_code_counts),
        "signature": final_completion_blocker_signature,
        "signature_from_counts": final_completion_blocker_code_signature_from_counts,
        "all_blockers_have_code": all(
            bool(blocker.get("code")) for blocker in final_completion_blockers
        ),
        "code_count_total_matches_blocker_count": (
            final_completion_blocker_code_count_total
            == len(final_completion_blockers)
        ),
        "unique_code_count_matches_top_level": (
            len(final_completion_blocker_codes)
            == len(final_completion_blocker_code_counts)
        ),
        "codes_match_top_level": (
            final_completion_blocker_codes
            == sorted(final_completion_blocker_code_counts)
        ),
        "signature_matches_counts": (
            final_completion_blocker_signature
            == final_completion_blocker_code_signature_from_counts
        ),
        "matched": (
            final_completion_blocker_code_count_total
            == len(final_completion_blockers)
            and len(final_completion_blocker_codes)
            == len(final_completion_blocker_code_counts)
            and final_completion_blocker_codes
            == sorted(final_completion_blocker_code_counts)
            and final_completion_blocker_signature
            == final_completion_blocker_code_signature_from_counts
            and all(
                bool(blocker.get("code")) for blocker in final_completion_blockers
            )
        ),
    }
    final_completion_blocker_gate_summary: dict[str, dict] = {}
    for blocker in final_completion_blockers:
        kind = blocker.get("kind")
        if kind == "signed_fixture":
            gate = "signed_diagram_fixture_registration"
        elif kind == "non_diagram_requirement":
            gate = "non_diagram_requirements"
        else:
            gate = str(blocker.get("gate") or "unknown")
        row = final_completion_blocker_gate_summary.setdefault(
            gate,
            {
                "gate": gate,
                "blocker_count": 0,
                "blocker_codes": [],
                "missing_artifacts": [],
                "retained_evidence_count": 0,
            },
        )
        row["blocker_count"] += 1
        code = blocker.get("code")
        if code and code not in row["blocker_codes"]:
            row["blocker_codes"].append(code)
        missing_artifact = blocker.get("missing_artifact")
        if (
            missing_artifact
            and missing_artifact not in row["missing_artifacts"]
        ):
            row["missing_artifacts"].append(missing_artifact)
        row["retained_evidence_count"] += len(
            [
                evidence
                for evidence in blocker.get("retained_evidence", [])
                if isinstance(evidence, dict)
            ]
        )
    final_completion_blocker_gate_summary_rows = []
    for gate in sorted(final_completion_blocker_gate_summary):
        row = final_completion_blocker_gate_summary[gate]
        final_completion_blocker_gate_summary_rows.append(
            {
                **row,
                "blocker_codes": sorted(row["blocker_codes"]),
                "missing_artifacts": sorted(row["missing_artifacts"]),
            }
        )
    blocker_gate_summary_by_gate = {
        row["gate"]: row for row in final_completion_blocker_gate_summary_rows
    }
    gate_summary_detail_rows = []
    for gate in sorted(final_completion_blocker_gate_summary):
        summary_row = blocker_gate_summary_by_gate.get(gate, {})
        gate_blockers = []
        for blocker in final_completion_blockers:
            kind = blocker.get("kind")
            if kind == "signed_fixture":
                blocker_gate = "signed_diagram_fixture_registration"
            elif kind == "non_diagram_requirement":
                blocker_gate = "non_diagram_requirements"
            else:
                blocker_gate = str(blocker.get("gate") or "unknown")
            if blocker_gate == gate:
                gate_blockers.append(blocker)
        expected_codes = sorted(
            {
                str(blocker["code"])
                for blocker in gate_blockers
                if blocker.get("code")
            }
        )
        expected_missing_artifacts = sorted(
            {
                str(blocker["missing_artifact"])
                for blocker in gate_blockers
                if blocker.get("missing_artifact")
            }
        )
        expected_retained_evidence_count = sum(
            len(
                [
                    evidence
                    for evidence in blocker.get("retained_evidence", [])
                    if isinstance(evidence, dict)
                ]
            )
            for blocker in gate_blockers
        )
        summary_codes = sorted(
            str(code) for code in summary_row.get("blocker_codes", [])
        )
        summary_missing_artifacts = sorted(
            str(artifact)
            for artifact in summary_row.get("missing_artifacts", [])
        )
        blocker_count_matched = (
            summary_row.get("blocker_count") == len(gate_blockers)
        )
        codes_matched = summary_codes == expected_codes
        missing_artifacts_matched = (
            summary_missing_artifacts == expected_missing_artifacts
        )
        retained_evidence_count_matched = (
            summary_row.get("retained_evidence_count")
            == expected_retained_evidence_count
        )
        gate_summary_detail_rows.append(
            {
                "gate": gate,
                "summary_row_present": bool(summary_row),
                "summary_blocker_count": summary_row.get("blocker_count", 0),
                "expected_blocker_count": len(gate_blockers),
                "blocker_count_matched": blocker_count_matched,
                "summary_blocker_codes": summary_codes,
                "expected_blocker_codes": expected_codes,
                "blocker_codes_matched": codes_matched,
                "summary_missing_artifacts": summary_missing_artifacts,
                "expected_missing_artifacts": expected_missing_artifacts,
                "missing_artifacts_matched": missing_artifacts_matched,
                "summary_retained_evidence_count": summary_row.get(
                    "retained_evidence_count", 0
                ),
                "expected_retained_evidence_count": (
                    expected_retained_evidence_count
                ),
                "retained_evidence_count_matched": (
                    retained_evidence_count_matched
                ),
                "matched": (
                    bool(summary_row)
                    and blocker_count_matched
                    and codes_matched
                    and missing_artifacts_matched
                    and retained_evidence_count_matched
                ),
            }
        )
    gate_summary_detail_mismatched_count = sum(
        1 for row in gate_summary_detail_rows if not row["matched"]
    )
    gate_summary_detail_missing_artifacts = sorted(
        {
            artifact
            for row in final_completion_blocker_gate_summary_rows
            for artifact in row.get("missing_artifacts", [])
        }
    )
    final_completion_open_gate_blocker_summary_detail_consistency = {
        "claim_scope": (
            "validation_pack_final_completion_open_gate_blocker_summary_detail_consistency"
        ),
        "summary_gate_count": len(final_completion_blocker_gate_summary_rows),
        "checked_gate_count": len(gate_summary_detail_rows),
        "blocker_count": len(final_completion_blockers),
        "blocker_code_reference_count": sum(
            len(row.get("blocker_codes", []))
            for row in final_completion_blocker_gate_summary_rows
        ),
        "missing_artifact_reference_count": sum(
            len(row.get("missing_artifacts", []))
            for row in final_completion_blocker_gate_summary_rows
        ),
        "unique_missing_artifact_count": len(gate_summary_detail_missing_artifacts),
        "retained_evidence_reference_count": sum(
            int(row.get("retained_evidence_count", 0) or 0)
            for row in final_completion_blocker_gate_summary_rows
        ),
        "summary_blocker_count_total": sum(
            int(row.get("blocker_count", 0) or 0)
            for row in final_completion_blocker_gate_summary_rows
        ),
        "blocker_count_matched_count": sum(
            1 for row in gate_summary_detail_rows if row["blocker_count_matched"]
        ),
        "blocker_codes_matched_count": sum(
            1 for row in gate_summary_detail_rows if row["blocker_codes_matched"]
        ),
        "missing_artifacts_matched_count": sum(
            1 for row in gate_summary_detail_rows if row["missing_artifacts_matched"]
        ),
        "retained_evidence_count_matched_count": sum(
            1
            for row in gate_summary_detail_rows
            if row["retained_evidence_count_matched"]
        ),
        "mismatched_summary_row_count": gate_summary_detail_mismatched_count,
        "all_summary_rows_present": all(
            row["summary_row_present"] for row in gate_summary_detail_rows
        ),
        "all_blocker_counts_matched": all(
            row["blocker_count_matched"] for row in gate_summary_detail_rows
        ),
        "all_blocker_codes_matched": all(
            row["blocker_codes_matched"] for row in gate_summary_detail_rows
        ),
        "all_missing_artifacts_matched": all(
            row["missing_artifacts_matched"] for row in gate_summary_detail_rows
        ),
        "all_retained_evidence_counts_matched": all(
            row["retained_evidence_count_matched"]
            for row in gate_summary_detail_rows
        ),
        "summary_blocker_count_total_matches_top_level": (
            sum(
                int(row.get("blocker_count", 0) or 0)
                for row in final_completion_blocker_gate_summary_rows
            )
            == len(final_completion_blockers)
        ),
        "retained_evidence_reference_count_matches_top_level": (
            sum(
                int(row.get("retained_evidence_count", 0) or 0)
                for row in final_completion_blocker_gate_summary_rows
            )
            == len(retained_evidence_entries)
        ),
        "matched": gate_summary_detail_mismatched_count == 0
        and sum(
            int(row.get("blocker_count", 0) or 0)
            for row in final_completion_blocker_gate_summary_rows
        )
        == len(final_completion_blockers)
        and sum(
            int(row.get("retained_evidence_count", 0) or 0)
            for row in final_completion_blocker_gate_summary_rows
        )
        == len(retained_evidence_entries),
        "rows": gate_summary_detail_rows,
        "gate_rows": gate_summary_detail_rows,
    }
    signed_blocker_codes = sorted(
        {blocker["code"] for blocker in signed_fixture_blockers}
    )
    non_diagram_blocker_codes = sorted(
        {
            non_diagram_blocker_code_by_requirement.get(
                row["requirement"],
                f"non_diagram_requirement_{row['status']}",
            )
            for row in open_non_diagram_requirements
        }
    )
    final_completion_gate_checks = [
        {
            "gate": "required_diagram_fixture_metadata",
            "passed": metadata_complete,
            "blocker_count": len(metadata_blockers),
            "blocker_codes": sorted({blocker["code"] for blocker in metadata_blockers}),
        },
        {
            "gate": "signed_diagram_fixture_registration",
            "passed": signed_fixture_complete,
            "blocker_count": len(signed_fixture_blockers),
            "blocker_codes": signed_blocker_codes,
            "blocked_notations": [blocker["notation"] for blocker in signed_fixture_blockers],
            "retained_evidence": signed_fixture_certification_evidence,
        },
        {
            "gate": "non_diagram_requirements",
            "passed": not open_non_diagram_requirements,
            "blocker_count": len(open_non_diagram_requirements),
            "blocker_codes": non_diagram_blocker_codes,
            "blocked_requirements": [
                row["requirement"] for row in open_non_diagram_requirements
            ],
        },
    ]
    final_completion_gate_checks.extend(
        {
            "gate": non_claim["gate"],
            "passed": non_claim["passed"],
            "blocker_count": 0 if non_claim["passed"] else 1,
            "blocker_codes": [] if non_claim["passed"] else [non_claim["code"]],
            "required_evidence": non_claim["required_evidence"],
            "current_evidence": non_claim["current_evidence"],
            "missing_artifact": non_claim["missing_artifact"],
            "missing_artifact_id": non_claim["missing_artifact_id"],
            "retained_evidence": non_claim.get("retained_evidence", []),
        }
        for non_claim in final_completion_non_claims
    )
    for blocker in final_completion_blockers:
        artifact_filenames = _completion_evidence_artifact_filenames(
            str(blocker.get("missing_artifact") or "")
        )
        if artifact_filenames:
            blocker["completion_evidence_artifact_filename_count"] = len(
                artifact_filenames
            )
            blocker["completion_evidence_artifact_filenames"] = artifact_filenames
            blocker["completion_evidence_artifact_filename_signature"] = "|".join(
                artifact_filenames
            )
    for gate_row in final_completion_gate_checks:
        missing_artifacts = []
        if gate_row.get("missing_artifact"):
            missing_artifacts.append(str(gate_row["missing_artifact"]))
        elif gate_row.get("gate") == "signed_diagram_fixture_registration":
            if gate_row.get("passed") is not True:
                missing_artifacts.append("verified_signed_crossing_assignment")
        elif gate_row.get("gate") == "non_diagram_requirements":
            missing_artifacts.extend(
                str(row["missing_artifact"])
                for row in open_non_diagram_requirements
                if row.get("missing_artifact")
            )
        artifact_filenames = [
            filename
            for missing_artifact in sorted(set(missing_artifacts))
            for filename in _completion_evidence_artifact_filenames(missing_artifact)
        ]
        if artifact_filenames:
            gate_row["completion_evidence_artifact_filename_count"] = len(
                artifact_filenames
            )
            gate_row["completion_evidence_artifact_filenames"] = artifact_filenames
            gate_row["completion_evidence_artifact_filename_signature"] = "|".join(
                artifact_filenames
            )
    failed_gate_rows = [
        row for row in final_completion_gate_checks if not row["passed"]
    ]
    failed_gate_names_in_order = [str(row["gate"]) for row in failed_gate_rows]
    failed_gate_names = sorted(str(row["gate"]) for row in failed_gate_rows)
    summary_gate_names = [
        row["gate"] for row in final_completion_blocker_gate_summary_rows
    ]
    final_completion_blocker_gate_summary_consistency = {
        "claim_scope": "final_completion_open_gate_blocker_summary_consistency",
        "failed_gate_count": len(failed_gate_rows),
        "summary_gate_count": len(final_completion_blocker_gate_summary_rows),
        "blocker_count": len(final_completion_blockers),
        "summary_blocker_count": sum(
            row["blocker_count"]
            for row in final_completion_blocker_gate_summary_rows
        ),
        "failed_gates": failed_gate_names,
        "summary_gates": summary_gate_names,
        "gate_sets_matched": failed_gate_names == summary_gate_names,
        "blocker_count_matched": (
            len(final_completion_blockers)
            == sum(
                row["blocker_count"]
                for row in final_completion_blocker_gate_summary_rows
            )
        ),
        "all_blockers_have_gate": "unknown" not in summary_gate_names,
    }
    blocker_summary_by_gate = {
        row["gate"]: row for row in final_completion_blocker_gate_summary_rows
    }
    final_completion_gate_blocker_consistency_rows = []
    for gate_row in final_completion_gate_checks:
        gate = str(gate_row["gate"])
        summary_row = blocker_summary_by_gate.get(gate, {})
        gate_blocker_codes = sorted(
            str(code) for code in gate_row.get("blocker_codes", [])
        )
        summary_blocker_codes = sorted(
            str(code) for code in summary_row.get("blocker_codes", [])
        )
        gate_blocker_count = int(gate_row.get("blocker_count", 0) or 0)
        summary_blocker_count = int(
            summary_row.get("blocker_count", 0) or 0
        )
        final_completion_gate_blocker_consistency_rows.append(
            {
                "gate": gate,
                "passed": bool(gate_row.get("passed")),
                "gate_blocker_count": gate_blocker_count,
                "summary_blocker_count": summary_blocker_count,
                "blocker_count_matched": (
                    gate_blocker_count == summary_blocker_count
                ),
                "gate_blocker_codes": gate_blocker_codes,
                "summary_blocker_codes": summary_blocker_codes,
                "blocker_codes_matched": (
                    gate_blocker_codes == summary_blocker_codes
                ),
            }
        )
    final_completion_gate_blocker_count_matched_count = sum(
        1
        for row in final_completion_gate_blocker_consistency_rows
        if row["blocker_count_matched"]
    )
    final_completion_gate_blocker_codes_matched_count = sum(
        1
        for row in final_completion_gate_blocker_consistency_rows
        if row["blocker_codes_matched"]
    )
    final_completion_gate_blocker_mismatched_count = sum(
        1
        for row in final_completion_gate_blocker_consistency_rows
        if not (row["blocker_count_matched"] and row["blocker_codes_matched"])
    )
    final_completion_gate_blocker_consistency = {
        "claim_scope": "validation_pack_final_completion_gate_blocker_consistency",
        "gate_check_count": len(final_completion_gate_checks),
        "summary_gate_count": len(final_completion_blocker_gate_summary_rows),
        "checked_gate_count": len(final_completion_gate_blocker_consistency_rows),
        "matched_gate_count": (
            len(final_completion_gate_blocker_consistency_rows)
            - final_completion_gate_blocker_mismatched_count
        ),
        "mismatched_gate_count": final_completion_gate_blocker_mismatched_count,
        "blocker_count_matched_gate_count": (
            final_completion_gate_blocker_count_matched_count
        ),
        "blocker_codes_matched_gate_count": (
            final_completion_gate_blocker_codes_matched_count
        ),
        "all_gate_blocker_counts_matched": (
            final_completion_gate_blocker_count_matched_count
            == len(final_completion_gate_blocker_consistency_rows)
        ),
        "all_gate_blocker_codes_matched": (
            final_completion_gate_blocker_codes_matched_count
            == len(final_completion_gate_blocker_consistency_rows)
        ),
        "matched": final_completion_gate_blocker_mismatched_count == 0,
        "gate_rows": final_completion_gate_blocker_consistency_rows,
    }
    completion_gate_blockers_by_gate = {
        str(blocker.get("gate")): blocker
        for blocker in final_completion_blockers
        if blocker.get("kind") == "completion_gate"
    }
    gate_checks_by_gate = {
        str(row.get("gate")): row for row in final_completion_gate_checks
    }
    non_claim_top_level_field_by_gate = {
        "full_homfly_pt_evaluation": "full_homfly_pt_evaluation_certified",
        "full_multivariable_alexander_normalization": (
            "full_multivariable_alexander_normalization_certified"
        ),
        "production_imgui_renderer": "production_imgui_renderer_verified",
        "release_artifacts": "release_artifacts_published",
    }
    non_claim_top_level_values = {
        "full_homfly_pt_evaluation_certified": full_homfly_pt_evaluation_certified,
        "full_multivariable_alexander_normalization_certified": (
            full_multivariable_alexander_normalization_certified
        ),
        "production_imgui_renderer_verified": production_imgui_renderer_verified,
        "release_artifacts_published": release_artifacts_published,
    }
    final_completion_non_claim_gate_consistency_rows = []
    for non_claim in final_completion_non_claims:
        gate = str(non_claim["gate"])
        top_level_field = non_claim_top_level_field_by_gate[gate]
        top_level_value = non_claim_top_level_values[top_level_field]
        blocker = completion_gate_blockers_by_gate.get(gate, {})
        gate_check = gate_checks_by_gate.get(gate, {})
        blocker_present = bool(blocker)
        gate_check_present = bool(gate_check)
        gate_check_failed = gate_check_present and gate_check.get("passed") is False
        certified_path = top_level_value is True and non_claim["passed"] is True
        blocker_code_matched = (
            certified_path and not blocker_present
        ) or blocker.get("code") == non_claim["code"]
        blocker_missing_artifact_matched = (
            certified_path and not blocker_present
        ) or (
            blocker.get("missing_artifact") == non_claim["missing_artifact"]
        )
        certified_path_matched = (
            certified_path
            and gate_check_present
            and gate_check.get("passed") is True
            and gate_check.get("blocker_count") == 0
            and gate_check.get("blocker_codes", []) == []
            and not blocker_present
        )
        non_claim_path_matched = (
            top_level_value is False
            and non_claim["passed"] is False
            and gate_check_failed
            and blocker_present
            and blocker_code_matched
            and blocker_missing_artifact_matched
        )
        final_completion_non_claim_gate_consistency_rows.append(
            {
                "gate": gate,
                "top_level_field": top_level_field,
                "top_level_value": top_level_value,
                "expected_passed": bool(non_claim["passed"]),
                "gate_check_present": gate_check_present,
                "gate_check_failed": gate_check_failed,
                "blocker_present": blocker_present,
                "blocker_code": blocker.get("code"),
                "expected_blocker_code": non_claim["code"],
                "blocker_code_matched": blocker_code_matched,
                "missing_artifact": blocker.get("missing_artifact"),
                "expected_missing_artifact": non_claim["missing_artifact"],
                "missing_artifact_matched": blocker_missing_artifact_matched,
                "certified_path": certified_path,
                "matched": certified_path_matched or non_claim_path_matched,
            }
        )
    final_completion_non_claim_gate_consistency = {
        "claim_scope": "validation_pack_final_completion_non_claim_gate_consistency",
        "non_claim_field_count": len(final_completion_non_claim_gate_consistency_rows),
        "non_claim_gate_count": len(final_completion_non_claim_gate_consistency_rows),
        "false_non_claim_field_count": sum(
            1
            for row in final_completion_non_claim_gate_consistency_rows
            if row["top_level_value"] is False
        ),
        "top_level_false_count": sum(
            1
            for row in final_completion_non_claim_gate_consistency_rows
            if row["top_level_value"] is False
        ),
        "completion_gate_check_count": sum(
            1
            for row in final_completion_non_claim_gate_consistency_rows
            if row["gate_check_present"]
        ),
        "gate_check_failed_count": sum(
            1
            for row in final_completion_non_claim_gate_consistency_rows
            if row["gate_check_failed"]
        ),
        "completion_gate_blocker_count": sum(
            1
            for row in final_completion_non_claim_gate_consistency_rows
            if row["blocker_present"]
        ),
        "missing_artifact_reference_count": sum(
            1
            for row in final_completion_non_claim_gate_consistency_rows
            if row["missing_artifact"]
        ),
        "unique_missing_artifact_count": len(
            {
                row["missing_artifact"]
                for row in final_completion_non_claim_gate_consistency_rows
                if row["missing_artifact"]
            }
        ),
        "blocker_code_matched_count": sum(
            1
            for row in final_completion_non_claim_gate_consistency_rows
            if row["blocker_code_matched"]
        ),
        "missing_artifact_matched_count": sum(
            1
            for row in final_completion_non_claim_gate_consistency_rows
            if row["missing_artifact_matched"]
        ),
        "matched_gate_count": sum(
            1
            for row in final_completion_non_claim_gate_consistency_rows
            if row["matched"]
        ),
        "matched_non_claim_field_count": sum(
            1
            for row in final_completion_non_claim_gate_consistency_rows
            if row["matched"]
        ),
        "mismatched_non_claim_field_count": sum(
            1
            for row in final_completion_non_claim_gate_consistency_rows
            if not row["matched"]
        ),
        "all_non_claim_fields_false": all(
            row["top_level_value"] is False
            for row in final_completion_non_claim_gate_consistency_rows
        ),
        "all_top_level_values_false": all(
            row["top_level_value"] is False
            for row in final_completion_non_claim_gate_consistency_rows
        ),
        "all_false_fields_have_failed_gate": all(
            row["gate_check_failed"]
            for row in final_completion_non_claim_gate_consistency_rows
            if row["top_level_value"] is False
        ),
        "all_gate_checks_failed": all(
            row["gate_check_failed"]
            for row in final_completion_non_claim_gate_consistency_rows
        ),
        "all_false_fields_have_completion_gate_blocker": all(
            row["blocker_present"]
            for row in final_completion_non_claim_gate_consistency_rows
            if row["top_level_value"] is False
        ),
        "all_completion_gate_blockers_present": all(
            row["blocker_present"]
            for row in final_completion_non_claim_gate_consistency_rows
        ),
        "all_false_fields_have_missing_artifact": all(
            bool(row["missing_artifact"])
            for row in final_completion_non_claim_gate_consistency_rows
            if row["top_level_value"] is False
        ),
        "all_blocker_codes_matched": all(
            row["blocker_code_matched"]
            for row in final_completion_non_claim_gate_consistency_rows
        ),
        "all_missing_artifacts_matched": all(
            row["missing_artifact_matched"]
            for row in final_completion_non_claim_gate_consistency_rows
        ),
        "matched": all(
            row["matched"]
            for row in final_completion_non_claim_gate_consistency_rows
        ),
        "rows": final_completion_non_claim_gate_consistency_rows,
        "gate_rows": final_completion_non_claim_gate_consistency_rows,
    }
    completion_gate_evidence_consistency_rows = []
    for non_claim in final_completion_non_claims:
        gate = str(non_claim["gate"])
        top_level_field = non_claim_top_level_field_by_gate[gate]
        top_level_value = non_claim_top_level_values[top_level_field]
        blocker = completion_gate_blockers_by_gate.get(gate, {})
        gate_check = gate_checks_by_gate.get(gate, {})
        certified_path = top_level_value is True and non_claim["passed"] is True
        blocker_code_matched = (
            certified_path and not blocker
        ) or blocker.get("code") == non_claim["code"]
        gate_code_matched = gate_check.get("blocker_codes", []) == (
            [] if certified_path else [non_claim["code"]]
        )
        evidence_rows = [gate_check, non_claim]
        if not certified_path:
            evidence_rows.insert(0, blocker)
        required_evidence_matched = all(
            row.get("required_evidence") == non_claim["required_evidence"]
            for row in evidence_rows
        )
        current_evidence_matched = all(
            row.get("current_evidence") == non_claim["current_evidence"]
            for row in evidence_rows
        )
        missing_artifact_matched = all(
            row.get("missing_artifact") == non_claim["missing_artifact"]
            for row in evidence_rows
        )
        missing_artifact_id_matched = all(
            row.get("missing_artifact_id") == non_claim["missing_artifact_id"]
            for row in evidence_rows
        )
        blocker_retained_evidence = list(blocker.get("retained_evidence", []))
        gate_retained_evidence = list(gate_check.get("retained_evidence", []))
        expected_retained_evidence = list(non_claim.get("retained_evidence", []))
        blocker_retained_evidence_ids = sorted(
            str(row.get("evidence_id"))
            for row in blocker_retained_evidence
            if isinstance(row, dict) and row.get("evidence_id")
        )
        gate_retained_evidence_ids = sorted(
            str(row.get("evidence_id"))
            for row in gate_retained_evidence
            if isinstance(row, dict) and row.get("evidence_id")
        )
        expected_retained_evidence_ids = sorted(
            str(row.get("evidence_id"))
            for row in expected_retained_evidence
            if isinstance(row, dict) and row.get("evidence_id")
        )
        if certified_path:
            selected_retained_evidence = gate_retained_evidence
            selected_retained_evidence_ids = gate_retained_evidence_ids
            retained_evidence_ids_matched = (
                gate_retained_evidence_ids == expected_retained_evidence_ids
            )
            evidence_source = gate_check
        else:
            selected_retained_evidence = blocker_retained_evidence
            selected_retained_evidence_ids = blocker_retained_evidence_ids
            retained_evidence_ids_matched = (
                blocker_retained_evidence_ids
                == gate_retained_evidence_ids
                == expected_retained_evidence_ids
            )
            evidence_source = blocker
        certified_path_matched = (
            certified_path
            and bool(gate_check)
            and gate_check.get("passed") is True
            and gate_check.get("blocker_count") == 0
            and not blocker
            and blocker_code_matched
            and gate_code_matched
            and required_evidence_matched
            and current_evidence_matched
            and missing_artifact_matched
            and missing_artifact_id_matched
            and retained_evidence_ids_matched
        )
        non_claim_path_matched = (
            not certified_path
            and bool(gate_check)
            and bool(blocker)
            and gate_check.get("passed") is False
            and gate_check.get("blocker_count") == 1
            and blocker.get("kind") == "completion_gate"
            and blocker_code_matched
            and gate_code_matched
            and required_evidence_matched
            and current_evidence_matched
            and missing_artifact_matched
            and missing_artifact_id_matched
            and retained_evidence_ids_matched
            and top_level_value is False
        )
        completion_gate_evidence_consistency_rows.append(
            {
                "gate": gate,
                "top_level_field": top_level_field,
                "top_level_value": top_level_value,
                "gate_check_present": bool(gate_check),
                "gate_passed": gate_check.get("passed"),
                "gate_blocker_count": gate_check.get("blocker_count"),
                "blocker_present": bool(blocker),
                "blocker_kind": blocker.get("kind"),
                "blocker_code": blocker.get("code"),
                "expected_blocker_code": non_claim["code"],
                "gate_code_matched": gate_code_matched,
                "blocker_code_matched": blocker_code_matched,
                "required_evidence_matched": required_evidence_matched,
                "current_evidence_matched": current_evidence_matched,
                "missing_artifact_matched": missing_artifact_matched,
                "missing_artifact_id_matched": missing_artifact_id_matched,
                "retained_evidence_count": len(selected_retained_evidence),
                "gate_retained_evidence_count": len(gate_retained_evidence),
                "expected_retained_evidence_count": len(
                    expected_retained_evidence
                ),
                "retained_evidence_ids": selected_retained_evidence_ids,
                "gate_retained_evidence_ids": gate_retained_evidence_ids,
                "expected_retained_evidence_ids": expected_retained_evidence_ids,
                "retained_evidence_ids_matched": retained_evidence_ids_matched,
                "required_evidence": evidence_source.get("required_evidence"),
                "expected_required_evidence": non_claim["required_evidence"],
                "current_evidence": evidence_source.get("current_evidence"),
                "expected_current_evidence": non_claim["current_evidence"],
                "missing_artifact": evidence_source.get("missing_artifact"),
                "expected_missing_artifact": non_claim["missing_artifact"],
                "missing_artifact_id": evidence_source.get("missing_artifact_id"),
                "expected_missing_artifact_id": non_claim["missing_artifact_id"],
                "certified_path": certified_path,
                "matched": certified_path_matched or non_claim_path_matched,
            }
        )
    completion_gate_evidence_mismatched_count = sum(
        1
        for row in completion_gate_evidence_consistency_rows
        if not row["matched"]
    )
    final_completion_completion_gate_evidence_consistency = {
        "claim_scope": (
            "validation_pack_final_completion_completion_gate_evidence_consistency"
        ),
        "gate_count": len(final_completion_non_claims),
        "gate_check_count": len(completion_gate_evidence_consistency_rows),
        "completion_gate_blocker_count": len(completion_gate_blockers_by_gate),
        "failed_gate_count": sum(
            1
            for row in completion_gate_evidence_consistency_rows
            if row["gate_passed"] is False
        ),
        "top_level_false_count": sum(
            1
            for row in completion_gate_evidence_consistency_rows
            if row["top_level_value"] is False
        ),
        "blocker_code_matched_count": sum(
            1
            for row in completion_gate_evidence_consistency_rows
            if row["blocker_code_matched"]
        ),
        "gate_code_matched_count": sum(
            1
            for row in completion_gate_evidence_consistency_rows
            if row["gate_code_matched"]
        ),
        "required_evidence_matched_count": sum(
            1
            for row in completion_gate_evidence_consistency_rows
            if row["required_evidence_matched"]
        ),
        "current_evidence_matched_count": sum(
            1
            for row in completion_gate_evidence_consistency_rows
            if row["current_evidence_matched"]
        ),
        "missing_artifact_matched_count": sum(
            1
            for row in completion_gate_evidence_consistency_rows
            if row["missing_artifact_matched"]
        ),
        "missing_artifact_id_matched_count": sum(
            1
            for row in completion_gate_evidence_consistency_rows
            if row["missing_artifact_id_matched"]
        ),
        "retained_evidence_reference_count": sum(
            row["retained_evidence_count"]
            for row in completion_gate_evidence_consistency_rows
        ),
        "retained_evidence_id_count": len(
            {
                evidence_id
                for row in completion_gate_evidence_consistency_rows
                for evidence_id in row["retained_evidence_ids"]
            }
        ),
        "retained_evidence_ids_matched_count": sum(
            1
            for row in completion_gate_evidence_consistency_rows
            if row["retained_evidence_ids_matched"]
        ),
        "mismatched_gate_count": completion_gate_evidence_mismatched_count,
        "all_gate_checks_present": all(
            row["gate_check_present"]
            for row in completion_gate_evidence_consistency_rows
        ),
        "all_completion_gate_blockers_present": all(
            row["blocker_present"]
            for row in completion_gate_evidence_consistency_rows
        ),
        "all_completion_gates_failed": all(
            row["gate_passed"] is False
            for row in completion_gate_evidence_consistency_rows
        ),
        "all_top_level_fields_false": all(
            row["top_level_value"] is False
            for row in completion_gate_evidence_consistency_rows
        ),
        "all_evidence_fields_matched": all(
            row["required_evidence_matched"]
            and row["current_evidence_matched"]
            and row["missing_artifact_matched"]
            and row["missing_artifact_id_matched"]
            and row["retained_evidence_ids_matched"]
            for row in completion_gate_evidence_consistency_rows
        ),
        "expected_completion_gate_blocker_count": sum(
            1
            for row in completion_gate_evidence_consistency_rows
            if row["top_level_value"] is False
        ),
        "matched": completion_gate_evidence_mismatched_count == 0
        and len(completion_gate_blockers_by_gate)
        == sum(
            1
            for row in completion_gate_evidence_consistency_rows
            if row["top_level_value"] is False
        ),
        "rows": completion_gate_evidence_consistency_rows,
        "gate_rows": completion_gate_evidence_consistency_rows,
    }
    final_completion_ready = all(row["passed"] for row in final_completion_gate_checks)
    required_check_rows = [
        {
            "check": "required_diagram_fixture_metadata",
            "top_level_field": "required_diagram_fixture_metadata_complete",
            "passed": metadata_complete,
            "blocker_count": len(metadata_blockers),
            "blocker_codes": sorted(
                {
                    str(blocker.get("code"))
                    for blocker in metadata_blockers
                    if blocker.get("code")
                }
            ),
            "expected_passed": True,
            "matched": metadata_complete is True and len(metadata_blockers) == 0,
        },
        {
            "check": "signed_diagram_fixture_registration",
            "top_level_field": "signed_diagram_fixture_registration_complete",
            "passed": signed_fixture_complete,
            "blocker_count": len(signed_fixture_blockers),
            "blocker_codes": sorted(
                {
                    str(blocker.get("code"))
                    for blocker in signed_fixture_blockers
                    if blocker.get("code")
                }
            ),
            "expected_passed": True,
            "matched": signed_fixture_complete is True
            and len(signed_fixture_blockers) == 0,
        },
        {
            "check": "non_diagram_requirements",
            "top_level_field": "open_non_diagram_requirement_count",
            "passed": not open_non_diagram_requirements,
            "blocker_count": len(open_non_diagram_requirements),
            "blocker_codes": sorted(
                {
                    non_diagram_blocker_code_by_requirement.get(
                        row["requirement"],
                        f"non_diagram_requirement_{row['status']}",
                    )
                    for row in open_non_diagram_requirements
                }
            ),
            "expected_passed": True,
            "matched": not open_non_diagram_requirements,
        },
    ]
    required_check_count = len(required_check_rows)
    passed_required_check_count = sum(1 for row in required_check_rows if row["passed"])
    failed_required_check_count = required_check_count - passed_required_check_count
    required_check_mismatched_count = sum(
        1 for row in required_check_rows if not row["matched"]
    )
    final_completion_required_check_consistency = {
        "claim_scope": "validation_pack_final_completion_required_check_consistency",
        "required_check_count": required_check_count,
        "passed_required_check_count": passed_required_check_count,
        "failed_required_check_count": failed_required_check_count,
        "mismatched_required_check_count": required_check_mismatched_count,
        "metadata_check_passed": metadata_complete,
        "signed_fixture_check_passed": signed_fixture_complete,
        "non_diagram_check_passed": not open_non_diagram_requirements,
        "metadata_blocker_count": len(metadata_blockers),
        "signed_fixture_blocker_count": len(signed_fixture_blockers),
        "open_non_diagram_requirement_count": len(open_non_diagram_requirements),
        "final_completion_ready": final_completion_ready,
        "final_completion_ready_expected": all(
            row["passed"] for row in required_check_rows
        ),
        "final_completion_ready_matches_required_checks": (
            final_completion_ready == all(row["passed"] for row in required_check_rows)
        ),
        "all_required_checks_matched": required_check_mismatched_count == 0,
        "matched": required_check_mismatched_count == 0
        and final_completion_ready
        == all(row["passed"] for row in required_check_rows),
        "rows": required_check_rows,
        "required_check_rows": required_check_rows,
    }
    fixture_rows_by_notation = {
        str(row["notation"]): row for row in rows if row.get("notation")
    }
    gate_rows_by_gate = {
        str(row["gate"]): row for row in final_completion_gate_checks
    }
    required_fixture_metadata_gate = gate_rows_by_gate.get(
        "required_diagram_fixture_metadata",
        {},
    )
    required_fixture_metadata_consistency_rows = []
    for notation in required:
        row = fixture_rows_by_notation.get(notation, {})
        metadata_blocker_count = len(
            [
                blocker
                for blocker in row.get("metadata_blockers", [])
                if isinstance(blocker, dict)
            ]
        )
        source_url_required = row.get("source_url_required")
        source_url = row.get("source_url")
        source_url_http_or_https = row.get("source_url_http_or_https")
        source_url_valid_when_applicable = row.get(
            "source_url_http_or_https_when_applicable"
        )
        source_url_requirement_satisfied = (
            source_url_required is False
            or (
                source_url_required is True
                and bool(source_url)
                and source_url_valid_when_applicable is True
            )
        )
        metadata_complete_matched = (
            bool(row)
            and row.get("metadata_complete") is True
            and metadata_blocker_count == 0
            and source_url_requirement_satisfied
        )
        required_fixture_metadata_consistency_rows.append(
            {
                "notation": notation,
                "row_present": bool(row),
                "metadata_complete": row.get("metadata_complete"),
                "metadata_blocker_count": metadata_blocker_count,
                "metadata_blockers": row.get("metadata_blockers", []),
                "registration_status": row.get("registration_status"),
                "has_pd_code": row.get("has_pd_code"),
                "has_signed_pd": row.get("has_signed_pd"),
                "has_gauss_code": row.get("has_gauss_code"),
                "source": row.get("source"),
                "source_url": source_url,
                "source_url_required": source_url_required,
                "source_url_scheme": row.get("source_url_scheme"),
                "source_url_domain": row.get("source_url_domain"),
                "source_url_http_or_https": source_url_http_or_https,
                "source_url_http_or_https_when_applicable": (
                    source_url_valid_when_applicable
                ),
                "source_url_requirement_satisfied": (
                    source_url_requirement_satisfied
                ),
                "expected_homfly_available": row.get(
                    "expected_homfly_available"
                ),
                "expected_multivariable_alexander_available": row.get(
                    "expected_multivariable_alexander_available"
                ),
                "expected_jones_available": row.get(
                    "expected_jones_available"
                ),
                "convention_note_count": row.get("convention_note_count"),
                "metadata_checks": row.get("metadata_checks", {}),
                "metadata_complete_matched": metadata_complete_matched,
                "matched": metadata_complete_matched,
            }
        )
    required_fixture_metadata_mismatched_count = sum(
        1
        for row in required_fixture_metadata_consistency_rows
        if not row["matched"]
    )
    required_fixture_metadata_gate_passed = (
        required_fixture_metadata_gate.get("passed") is True
    )
    required_fixture_metadata_gate_blocker_count = (
        _optional_int(required_fixture_metadata_gate.get("blocker_count")) or 0
    )
    final_completion_required_diagram_fixture_metadata_consistency = {
        "claim_scope": (
            "validation_pack_final_completion_required_diagram_fixture_metadata_consistency"
        ),
        "required_fixture_count": len(required),
        "registered_fixture_count": len(rows),
        "missing_fixture_count": len(missing_notations),
        "metadata_complete_fixture_count": sum(
            1
            for row in required_fixture_metadata_consistency_rows
            if row["metadata_complete"] is True
        ),
        "metadata_incomplete_fixture_count": sum(
            1
            for row in required_fixture_metadata_consistency_rows
            if row["metadata_complete"] is not True
        ),
        "mismatched_fixture_count": required_fixture_metadata_mismatched_count,
        "metadata_blocker_count": len(metadata_blockers),
        "row_metadata_blocker_count": sum(
            row["metadata_blocker_count"]
            for row in required_fixture_metadata_consistency_rows
        ),
        "gate_passed": required_fixture_metadata_gate_passed,
        "gate_blocker_count": required_fixture_metadata_gate_blocker_count,
        "gate_blocker_codes": list(
            required_fixture_metadata_gate.get("blocker_codes", [])
        ),
        "required_fixtures_match_rows": (
            list(required) == [row["notation"] for row in required_fixture_metadata_consistency_rows]
        ),
        "all_required_fixtures_registered": len(missing_notations) == 0
        and len(rows) == len(required),
        "all_fixture_metadata_complete": (
            required_fixture_metadata_mismatched_count == 0
        ),
        "top_level_metadata_complete_matched": (
            metadata_complete
            == (
                len(missing_notations) == 0
                and len(metadata_blockers) == 0
                and required_fixture_metadata_mismatched_count == 0
            )
        ),
        "top_level_metadata_blocker_count_matched": (
            len(metadata_blockers)
            == sum(
                row["metadata_blocker_count"]
                for row in required_fixture_metadata_consistency_rows
            )
        ),
        "gate_passed_matches_metadata_complete": (
            required_fixture_metadata_gate_passed == metadata_complete
        ),
        "gate_blocker_count_matched": (
            required_fixture_metadata_gate_blocker_count
            == len(metadata_blockers)
        ),
        "matched": required_fixture_metadata_mismatched_count == 0
        and len(missing_notations) == 0
        and len(rows) == len(required)
        and metadata_complete is True
        and len(metadata_blockers) == 0
        and required_fixture_metadata_gate_passed is True
        and required_fixture_metadata_gate_blocker_count == 0,
        "rows": required_fixture_metadata_consistency_rows,
        "fixture_rows": required_fixture_metadata_consistency_rows,
    }
    signed_fixture_blockers_by_notation = {
        str(blocker.get("notation")): blocker for blocker in signed_fixture_blockers
    }
    signed_fixture_final_blockers_by_notation = {
        str(blocker.get("notation")): blocker
        for blocker in final_completion_blockers
        if blocker.get("kind") == "signed_fixture"
    }
    signed_fixture_consistency_rows = []
    signed_fixture_fields_to_match = (
        "code",
        "registration_status",
        "source",
        "source_url",
        "has_signed_pd",
        "has_gauss_code",
        "source_table_homfly_available",
        "source_table_multivariable_alexander_available",
        "source_table_multivariable_alexander_numerator_available",
        "required_evidence",
        "current_evidence",
        "missing_artifact",
        "source_candidate_matching_candidate_count",
        "source_candidate_unique_sign_pattern_count",
        "source_candidate_replay_all_valid",
    )
    for notation, blocker in signed_fixture_blockers_by_notation.items():
        final_blocker = signed_fixture_final_blockers_by_notation.get(notation, {})
        field_matches = {
            field: final_blocker.get(field) == blocker.get(field)
            for field in signed_fixture_fields_to_match
        }
        source_candidate_evidence = (
            final_blocker.get("source_candidate_evidence")
            if isinstance(final_blocker.get("source_candidate_evidence"), dict)
            else {}
        )
        source_candidate_available = (
            final_blocker.get("source_candidate_evidence_available") is True
        )
        source_candidate_not_unique = (
            source_candidate_evidence.get("registration_blocker_code")
            == "source_candidate_not_unique"
        )
        source_candidate_replay_all_valid = (
            final_blocker.get("source_candidate_replay_all_valid") is True
        )
        signed_fixture_consistency_rows.append(
            {
                "notation": notation,
                "blocker_present": bool(final_blocker),
                "blocker_code": final_blocker.get("code"),
                "expected_blocker_code": blocker.get("code"),
                "registration_status": final_blocker.get("registration_status"),
                "expected_registration_status": blocker.get("registration_status"),
                "source_url": final_blocker.get("source_url"),
                "expected_source_url": blocker.get("source_url"),
                "has_signed_pd": final_blocker.get("has_signed_pd"),
                "expected_has_signed_pd": blocker.get("has_signed_pd"),
                "missing_artifact": final_blocker.get("missing_artifact"),
                "expected_missing_artifact": blocker.get("missing_artifact"),
                "source_candidate_evidence_available": source_candidate_available,
                "source_candidate_matching_candidate_count": final_blocker.get(
                    "source_candidate_matching_candidate_count"
                ),
                "source_candidate_unique_sign_pattern_count": final_blocker.get(
                    "source_candidate_unique_sign_pattern_count"
                ),
                "source_candidate_replay_all_valid": (
                    source_candidate_replay_all_valid
                ),
                "source_candidate_not_unique": source_candidate_not_unique,
                "source_candidate_registration_blocker_code": (
                    source_candidate_evidence.get("registration_blocker_code")
                ),
                "field_matches": field_matches,
                "all_fields_matched": all(field_matches.values()),
                "unsigned_non_claim_preserved": (
                    final_blocker.get("has_signed_pd") is False
                    and blocker.get("has_signed_pd") is False
                ),
                "source_table_metadata_available": (
                    final_blocker.get("source_table_homfly_available") is True
                    and final_blocker.get(
                        "source_table_multivariable_alexander_available"
                    )
                    is True
                    and final_blocker.get(
                        "source_table_multivariable_alexander_numerator_available"
                    )
                    is True
                ),
                "matched": bool(final_blocker)
                and all(field_matches.values())
                and final_blocker.get("has_signed_pd") is False
                and blocker.get("has_signed_pd") is False,
            }
        )
    signed_fixture_mismatched_count = sum(
        1 for row in signed_fixture_consistency_rows if not row["matched"]
    )
    final_completion_signed_fixture_consistency = {
        "claim_scope": "validation_pack_final_completion_signed_fixture_consistency",
        "signed_fixture_blocker_count": len(signed_fixture_blockers),
        "final_blocker_count": len(signed_fixture_final_blockers_by_notation),
        "matched_fixture_count": (
            len(signed_fixture_consistency_rows) - signed_fixture_mismatched_count
        ),
        "mismatched_fixture_count": signed_fixture_mismatched_count,
        "source_url_present_count": sum(
            1 for row in signed_fixture_consistency_rows if row["source_url"]
        ),
        "unsigned_non_claim_preserved_count": sum(
            1
            for row in signed_fixture_consistency_rows
            if row["unsigned_non_claim_preserved"]
        ),
        "source_table_metadata_available_count": sum(
            1
            for row in signed_fixture_consistency_rows
            if row["source_table_metadata_available"]
        ),
        "missing_artifact_matched_count": sum(
            1
            for row in signed_fixture_consistency_rows
            if row["field_matches"]["missing_artifact"]
        ),
        "evidence_fields_matched_count": sum(
            1
            for row in signed_fixture_consistency_rows
            if row["field_matches"]["required_evidence"]
            and row["field_matches"]["current_evidence"]
        ),
        "source_candidate_evidence_available_count": sum(
            1
            for row in signed_fixture_consistency_rows
            if row["source_candidate_evidence_available"]
        ),
        "source_candidate_not_unique_count": sum(
            1
            for row in signed_fixture_consistency_rows
            if row["source_candidate_not_unique"]
        ),
        "source_candidate_replay_all_valid_count": sum(
            1
            for row in signed_fixture_consistency_rows
            if row["source_candidate_replay_all_valid"]
        ),
        "source_candidate_matching_candidate_count_total": sum(
            int(row["source_candidate_matching_candidate_count"] or 0)
            for row in signed_fixture_consistency_rows
        ),
        "source_candidate_unique_sign_pattern_count_total": sum(
            int(row["source_candidate_unique_sign_pattern_count"] or 0)
            for row in signed_fixture_consistency_rows
        ),
        "all_signed_fixture_blockers_have_final_blockers": all(
            row["blocker_present"] for row in signed_fixture_consistency_rows
        ),
        "all_final_blockers_have_signed_fixture_rows": (
            len(signed_fixture_final_blockers_by_notation)
            == len(signed_fixture_blockers)
        ),
        "all_missing_artifacts_matched": all(
            row["field_matches"]["missing_artifact"]
            for row in signed_fixture_consistency_rows
        ),
        "all_evidence_fields_matched": all(
            row["field_matches"]["required_evidence"]
            and row["field_matches"]["current_evidence"]
            for row in signed_fixture_consistency_rows
        ),
        "all_unsigned_non_claims_preserved": all(
            row["unsigned_non_claim_preserved"]
            for row in signed_fixture_consistency_rows
        ),
        "all_source_table_metadata_available": all(
            row["source_table_metadata_available"]
            for row in signed_fixture_consistency_rows
        ),
        "all_source_candidate_evidence_available": all(
            row["source_candidate_evidence_available"]
            for row in signed_fixture_consistency_rows
        ),
        "all_source_candidates_not_unique": all(
            row["source_candidate_not_unique"]
            for row in signed_fixture_consistency_rows
        ),
        "all_source_candidate_replays_valid": all(
            row["source_candidate_replay_all_valid"]
            for row in signed_fixture_consistency_rows
        ),
        "matched": signed_fixture_mismatched_count == 0
        and len(signed_fixture_final_blockers_by_notation)
        == len(signed_fixture_blockers),
        "rows": signed_fixture_consistency_rows,
        "fixture_rows": signed_fixture_consistency_rows,
    }
    non_diagram_blockers_by_requirement = {
        str(blocker.get("requirement")): blocker
        for blocker in final_completion_blockers
        if blocker.get("kind") == "non_diagram_requirement"
    }
    non_diagram_requirement_consistency_rows = []
    for row in open_non_diagram_requirements:
        requirement = row["requirement"]
        blocker = non_diagram_blockers_by_requirement.get(requirement, {})
        expected_code = non_diagram_blocker_code_by_requirement.get(
            requirement,
            f"non_diagram_requirement_{row['status']}",
        )
        row_retained_count = len(
            [e for e in row.get("retained_evidence", []) if isinstance(e, dict)]
        )
        blocker_retained_count = len(
            [
                e
                for e in blocker.get("retained_evidence", [])
                if isinstance(e, dict)
            ]
        )
        row_retained_ids = sorted(
            {
                str(e["evidence_id"])
                for e in row.get("retained_evidence", [])
                if isinstance(e, dict) and e.get("evidence_id")
            }
        )
        blocker_retained_ids = sorted(
            {
                str(e["evidence_id"])
                for e in blocker.get("retained_evidence", [])
                if isinstance(e, dict) and e.get("evidence_id")
            }
        )
        evidence_fields_matched = (
            blocker.get("required_evidence") == row.get("required_evidence")
            and blocker.get("current_evidence") == row.get("current_evidence")
        )
        missing_artifact_matched = (
            blocker.get("missing_artifact") == row.get("missing_artifact")
        )
        retained_evidence_count_matched = (
            blocker_retained_count == row_retained_count
        )
        retained_evidence_ids_matched = row_retained_ids == blocker_retained_ids
        completion_claimed_matched = (
            blocker.get("completion_claimed") is False
            and row.get("completion_claimed") is False
        )
        non_diagram_requirement_consistency_rows.append(
            {
                "requirement": requirement,
                "status": row["status"],
                "blocker_present": bool(blocker),
                "blocker_code": blocker.get("code"),
                "expected_blocker_code": expected_code,
                "blocker_code_matched": blocker.get("code") == expected_code,
                "missing_artifact": blocker.get("missing_artifact"),
                "expected_missing_artifact": row.get("missing_artifact"),
                "missing_artifact_matched": missing_artifact_matched,
                "evidence_fields_matched": evidence_fields_matched,
                "retained_evidence_count": row_retained_count,
                "blocker_retained_evidence_count": blocker_retained_count,
                "retained_evidence_count_matched": (
                    retained_evidence_count_matched
                ),
                "retained_evidence_ids": row_retained_ids,
                "blocker_retained_evidence_ids": blocker_retained_ids,
                "retained_evidence_ids_matched": retained_evidence_ids_matched,
                "completion_claimed": blocker.get("completion_claimed"),
                "expected_completion_claimed": row.get("completion_claimed"),
                "completion_claimed_matched": completion_claimed_matched,
                "matched": (
                    bool(blocker)
                    and blocker.get("code") == expected_code
                    and missing_artifact_matched
                    and evidence_fields_matched
                    and retained_evidence_count_matched
                    and retained_evidence_ids_matched
                    and completion_claimed_matched
                ),
            }
        )
    non_diagram_retained_evidence_ids = sorted(
        {
            evidence_id
            for row in non_diagram_requirement_consistency_rows
            for evidence_id in row["retained_evidence_ids"]
        }
    )
    non_diagram_top_level_retained_evidence_count = sum(
        len(
            [
                e
                for e in row.get("retained_evidence", [])
                if isinstance(e, dict)
            ]
        )
        for row in open_non_diagram_requirements
    )
    non_diagram_top_level_retained_evidence_id_count = len(
        {
            str(e["evidence_id"])
            for row in open_non_diagram_requirements
            for e in row.get("retained_evidence", [])
            if isinstance(e, dict) and e.get("evidence_id")
        }
    )
    non_diagram_requirement_mismatched_count = sum(
        1 for row in non_diagram_requirement_consistency_rows if not row["matched"]
    )
    final_completion_non_diagram_requirement_consistency = {
        "claim_scope": (
            "validation_pack_final_completion_non_diagram_requirement_consistency"
        ),
        "requirement_count": len(non_diagram_requirements),
        "open_requirement_count": len(open_non_diagram_requirements),
        "blocker_count": len(non_diagram_blockers_by_requirement),
        "matched_requirement_count": (
            len(non_diagram_requirement_consistency_rows)
            - non_diagram_requirement_mismatched_count
        ),
        "mismatched_requirement_count": (
            non_diagram_requirement_mismatched_count
        ),
        "retained_evidence_reference_count": sum(
            row["retained_evidence_count"]
            for row in non_diagram_requirement_consistency_rows
        ),
        "retained_evidence_id_count": len(non_diagram_retained_evidence_ids),
        "retained_evidence_ids": non_diagram_retained_evidence_ids,
        "retained_evidence_reference_count_matches_top_level": (
            sum(
                row["retained_evidence_count"]
                for row in non_diagram_requirement_consistency_rows
            )
            == non_diagram_top_level_retained_evidence_count
        ),
        "retained_evidence_id_count_matches_top_level": (
            len(non_diagram_retained_evidence_ids)
            == non_diagram_top_level_retained_evidence_id_count
        ),
        "missing_artifact_matched_count": sum(
            1
            for row in non_diagram_requirement_consistency_rows
            if row["missing_artifact_matched"]
        ),
        "evidence_fields_matched_count": sum(
            1
            for row in non_diagram_requirement_consistency_rows
            if row["evidence_fields_matched"]
        ),
        "retained_evidence_count_matched_count": sum(
            1
            for row in non_diagram_requirement_consistency_rows
            if row["retained_evidence_count_matched"]
        ),
        "retained_evidence_ids_matched_count": sum(
            1
            for row in non_diagram_requirement_consistency_rows
            if row["retained_evidence_ids_matched"]
        ),
        "completion_claimed_false_count": sum(
            1
            for row in non_diagram_requirement_consistency_rows
            if row["completion_claimed"] is False
        ),
        "all_open_requirements_have_blockers": all(
            row["blocker_present"]
            for row in non_diagram_requirement_consistency_rows
        ),
        "all_blockers_have_open_requirements": (
            len(non_diagram_blockers_by_requirement)
            == len(open_non_diagram_requirements)
        ),
        "all_missing_artifacts_matched": all(
            row["missing_artifact_matched"]
            for row in non_diagram_requirement_consistency_rows
        ),
        "all_evidence_fields_matched": all(
            row["evidence_fields_matched"]
            for row in non_diagram_requirement_consistency_rows
        ),
        "all_retained_evidence_counts_matched": all(
            row["retained_evidence_count_matched"]
            for row in non_diagram_requirement_consistency_rows
        ),
        "all_retained_evidence_ids_matched": all(
            row["retained_evidence_ids_matched"]
            for row in non_diagram_requirement_consistency_rows
        ),
        "all_completion_claims_false": all(
            row["completion_claimed_matched"]
            for row in non_diagram_requirement_consistency_rows
        ),
        "matched": non_diagram_requirement_mismatched_count == 0
        and len(non_diagram_blockers_by_requirement)
        == len(open_non_diagram_requirements)
        and sum(
            row["retained_evidence_count"]
            for row in non_diagram_requirement_consistency_rows
        )
        == non_diagram_top_level_retained_evidence_count
        and len(non_diagram_retained_evidence_ids)
        == non_diagram_top_level_retained_evidence_id_count,
        "rows": non_diagram_requirement_consistency_rows,
        "requirement_rows": non_diagram_requirement_consistency_rows,
    }
    fixture_source_url_shape_summary = (
        _cross_workstream_fixture_source_url_shape_summary(rows)
    )
    fixture_known_limitations_summary = (
        _cross_workstream_fixture_known_limitations_summary(rows)
    )
    return {
        "method": "cross_workstream_validation_pack_audit",
        "claim_scope": "final_completion_checklist_metadata_audit",
        "completion_evidence_bundle": bundle_evidence,
        "completion_evidence_bundle_available": bundle_evidence["available"],
        "completion_evidence_bundle_certified": bundle_evidence["certified"],
        "required_check_count": required_check_count,
        "passed_check_count": passed_required_check_count,
        "failed_check_count": failed_required_check_count,
        "final_completion_required_check_consistency": (
            final_completion_required_check_consistency
        ),
        "final_completion_required_diagram_fixture_metadata_consistency": (
            final_completion_required_diagram_fixture_metadata_consistency
        ),
        "final_completion_signed_fixture_consistency": (
            final_completion_signed_fixture_consistency
        ),
        "final_completion_non_diagram_requirement_consistency": (
            final_completion_non_diagram_requirement_consistency
        ),
        "fixture_source_url_shape_summary": fixture_source_url_shape_summary,
        "fixture_known_limitations_summary": fixture_known_limitations_summary,
        "required_diagram_fixture_notations": list(required),
        "required_diagram_fixture_count": len(required),
        "registered_required_diagram_fixture_count": len(rows),
        "missing_required_diagram_fixture_count": len(missing_notations),
        "missing_required_diagram_fixture_notations": missing_notations,
        "required_diagram_fixture_metadata_complete": metadata_complete,
        "metadata_blocker_count": len(metadata_blockers),
        "metadata_blockers": metadata_blockers,
        "signed_diagram_fixture_registration_complete": signed_fixture_complete,
        "verified_signed_assignment_input_count": len(
            all_verified_signed_assignments
        ),
        "verified_signed_assignment_notation_counts": (
            verified_signed_assignment_notation_counts
        ),
        "duplicate_verified_signed_assignment_notation_count": len(
            duplicate_verified_signed_assignment_notations
        ),
        "duplicate_verified_signed_assignment_notations": (
            duplicate_verified_signed_assignment_notations
        ),
        "missing_notation_verified_signed_assignment_count": (
            missing_notation_verified_signed_assignment_count
        ),
        "unexpected_verified_signed_assignment_notation_count": len(
            unexpected_verified_signed_assignment_notations
        ),
        "unexpected_verified_signed_assignment_notations": (
            unexpected_verified_signed_assignment_notations
        ),
        "unsigned_required_fixture_count": len(signed_fixture_blockers),
        "signed_fixture_blockers": signed_fixture_blockers,
        "non_diagram_requirement_count": len(non_diagram_requirements),
        "open_non_diagram_requirement_count": len(open_non_diagram_requirements),
        "non_diagram_fixture_metadata_complete": (
            not non_diagram_fixture_metadata_incomplete_requirements
        ),
        "non_diagram_fixture_metadata_complete_count": (
            non_diagram_fixture_metadata_complete_count
        ),
        "non_diagram_fixture_metadata_incomplete_count": len(
            non_diagram_fixture_metadata_incomplete_requirements
        ),
        "non_diagram_fixture_metadata_incomplete_requirements": (
            non_diagram_fixture_metadata_incomplete_requirements
        ),
        "non_diagram_requirements": non_diagram_requirements,
        "broad_noisy_curve_robustness_certification_pack_evidence": (
            broad_noisy_curve_robustness_evidence
        ),
        "broad_noisy_curve_robustness_certified": (
            broad_noisy_curve_robustness_evidence["certified"]
        ),
        "release_grade_high_point_performance_pack_evidence": (
            release_grade_high_point_performance_evidence
        ),
        "release_grade_high_point_performance_certified": (
            release_grade_high_point_performance_evidence["certified"]
        ),
        "final_completion_gate_count": len(final_completion_gate_checks),
        "final_completion_passed_gate_count": sum(
            1 for row in final_completion_gate_checks if row["passed"]
        ),
        "final_completion_failed_gate_count": sum(
            1 for row in final_completion_gate_checks if not row["passed"]
        ),
        "final_completion_failed_gates": failed_gate_names_in_order,
        "final_completion_failed_gate_signature": "|".join(
            failed_gate_names_in_order
        ),
        "final_completion_gate_checks": final_completion_gate_checks,
        "final_completion_blocker_count": len(final_completion_blockers),
        "final_completion_blocker_code_count": len(
            final_completion_blocker_code_counts
        ),
        "final_completion_blocker_codes": final_completion_blocker_codes,
        "final_completion_blocker_code_counts": final_completion_blocker_code_counts,
        "final_completion_blocker_signature": final_completion_blocker_signature,
        "final_completion_missing_artifact_count": (
            final_completion_missing_artifact_count
        ),
        "final_completion_missing_artifacts": missing_artifact_ids,
        "final_completion_missing_artifact_signature": (
            final_completion_missing_artifact_signature
        ),
        "final_completion_blocker_kind_summary": (
            final_completion_blocker_kind_summary
        ),
        "final_completion_blocker_kind_consistency": (
            final_completion_blocker_kind_consistency
        ),
        "final_completion_blocker_kind_summary_detail_consistency": (
            final_completion_blocker_kind_summary_detail_consistency
        ),
        "final_completion_blocker_code_summary": (
            final_completion_blocker_code_summary
        ),
        "final_completion_blocker_code_summary_detail_consistency": (
            final_completion_blocker_code_summary_detail_consistency
        ),
        "final_completion_blocker_code_consistency": (
            final_completion_blocker_code_consistency
        ),
        "final_completion_open_gate_blocker_summary": (
            final_completion_blocker_gate_summary_rows
        ),
        "final_completion_open_gate_blocker_summary_consistency": (
            final_completion_blocker_gate_summary_consistency
        ),
        "final_completion_open_gate_blocker_summary_detail_consistency": (
            final_completion_open_gate_blocker_summary_detail_consistency
        ),
        "final_completion_gate_blocker_consistency": (
            final_completion_gate_blocker_consistency
        ),
        "final_completion_non_claim_gate_consistency": (
            final_completion_non_claim_gate_consistency
        ),
        "final_completion_completion_gate_evidence_consistency": (
            final_completion_completion_gate_evidence_consistency
        ),
        "final_completion_blockers": final_completion_blockers,
        "retained_evidence_count": len(retained_evidence_entries),
        "retained_evidence_id_count": len(retained_evidence_ids),
        "retained_evidence_ids": retained_evidence_ids,
        "retained_evidence_completion_claimed_count": retained_evidence_claimed_count,
        "retained_evidence_release_grade_speedup_claimed_count": (
            retained_evidence_release_grade_claimed_count
        ),
        "retained_evidence_real_graphics_backend_framebuffer_verified_count": (
            retained_evidence_real_backend_claimed_count
        ),
        "retained_evidence_screenshot_verified_count": (
            retained_evidence_screenshot_claimed_count
        ),
        "retained_evidence_all_non_claimed": retained_evidence_non_claim_consistency[
            "all_non_claimed"
        ],
        "retained_evidence_non_claim_consistency": (
            retained_evidence_non_claim_consistency
        ),
        "retained_evidence_artifact_file_consistency": (
            retained_evidence_artifact_file_consistency
        ),
        "final_completion_blocker_evidence_links": (
            final_completion_blocker_evidence_links
        ),
        "final_completion_blocker_evidence_link_consistency": (
            final_completion_blocker_evidence_link_consistency
        ),
        "final_completion_blocker_evidence_link_kind_summary": (
            blocker_evidence_link_kind_summary
        ),
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency": (
            final_completion_blocker_evidence_link_kind_summary_detail_consistency
        ),
        "final_completion_missing_artifact_summary": (
            final_completion_missing_artifact_summary
        ),
        "final_completion_missing_artifact_summary_consistency": (
            final_completion_missing_artifact_summary_consistency
        ),
        "final_completion_missing_artifact_summary_detail_consistency": (
            final_completion_missing_artifact_summary_detail_consistency
        ),
        "final_completion_blocker_evidence_field_summary": (
            final_completion_blocker_evidence_field_summary
        ),
        "final_completion_blocker_evidence_field_rows": (
            blocker_evidence_field_rows
        ),
        "final_completion_blocker_evidence_field_consistency": (
            final_completion_blocker_evidence_field_consistency
        ),
        "final_completion_blocker_evidence_field_summary_detail_consistency": (
            final_completion_blocker_evidence_field_summary_detail_consistency
        ),
        "final_completion_ready": final_completion_ready,
        "full_homfly_pt_evaluation_certified": full_homfly_pt_evaluation_certified,
        "full_multivariable_alexander_normalization_certified": (
            full_multivariable_alexander_normalization_certified
        ),
        "production_imgui_renderer_verified": production_imgui_renderer_verified,
        "release_artifacts_published": release_artifacts_published,
        "fixtures": rows,
        "notes": [
            "this audit checks validation-pack metadata and known open gates only",
            "source-table rows for unsigned fixtures are convention evidence, not registered signed fixture claims",
            "a clean metadata audit does not certify full HOMFLY evaluation, full Alexander normalization, production rendering, or release publication",
        ],
    }


def _cross_workstream_source_url_shape(source_url: str | None) -> dict[str, object]:
    if not source_url:
        return {
            "source_url_scheme": None,
            "source_url_domain": None,
            "source_url_http_or_https": True,
        }
    parsed = urlparse(source_url)
    scheme = parsed.scheme or None
    domain = parsed.netloc or None
    return {
        "source_url_scheme": scheme,
        "source_url_domain": domain,
        "source_url_http_or_https": (
            scheme in {"http", "https"} and bool(domain)
        ),
    }


def _cross_workstream_fixture_source_url_shape_summary(
    rows: Sequence[dict],
) -> dict[str, object]:
    row_count = len(rows)
    source_url_rows = [row for row in rows if row.get("source_url")]
    required_rows = [row for row in rows if row.get("source_url_required") is True]
    http_rows = [
        row for row in source_url_rows if row.get("source_url_http_or_https") is True
    ]
    requirement_satisfied_rows = [
        row
        for row in required_rows
        if row.get("source_url")
        and row.get("source_url_http_or_https_when_applicable") is True
    ]
    scheme_counts: dict[str, int] = {}
    domain_counts: dict[str, int] = {}
    for row in source_url_rows:
        scheme = row.get("source_url_scheme")
        if scheme:
            scheme_text = str(scheme)
            scheme_counts[scheme_text] = scheme_counts.get(scheme_text, 0) + 1
        domain = row.get("source_url_domain")
        if domain:
            domain_text = str(domain)
            domain_counts[domain_text] = domain_counts.get(domain_text, 0) + 1
    scheme_count_total = sum(scheme_counts.values())
    domain_count_total = sum(domain_counts.values())
    return {
        "claim_scope": "validation_pack_fixture_source_url_shape_summary",
        "fixture_row_count": row_count,
        "source_url_row_count": len(source_url_rows),
        "external_source_url_row_count": len(source_url_rows),
        "source_url_required_count": len(required_rows),
        "source_url_http_or_https_count": len(http_rows),
        "source_url_requirement_satisfied_count": len(requirement_satisfied_rows),
        "source_url_scheme_counts": dict(sorted(scheme_counts.items())),
        "source_url_domain_counts": dict(sorted(domain_counts.items())),
        "source_url_scheme_count_total": scheme_count_total,
        "source_url_domain_count_total": domain_count_total,
        "source_url_scheme_count_matched": scheme_count_total == len(source_url_rows),
        "source_url_domain_count_matched": domain_count_total == len(source_url_rows),
        "source_url_http_or_https_count_matched": (
            len(http_rows) == len(source_url_rows)
        ),
        "source_url_requirement_satisfied_count_matched": (
            len(requirement_satisfied_rows) == len(required_rows)
        ),
        "matched": (
            scheme_count_total == len(source_url_rows)
            and domain_count_total == len(source_url_rows)
            and len(http_rows) == len(source_url_rows)
            and len(requirement_satisfied_rows) == len(required_rows)
        ),
    }


def _cross_workstream_fixture_known_limitations_summary(
    rows: Sequence[dict],
) -> dict[str, object]:
    available_rows = [
        row
        for row in rows
        if isinstance(row.get("metadata_checks"), dict)
        and row["metadata_checks"].get("known_limitations_available") is True
    ]
    unavailable_count = len(rows) - len(available_rows)
    note_count_total = sum(
        int(row.get("convention_note_count") or 0)
        + int(row.get("expected_homfly_note_count") or 0)
        + int(row.get("expected_multivariable_alexander_note_count") or 0)
        + int(row.get("source_table_note_count") or 0)
        for row in rows
    )
    return {
        "claim_scope": "validation_pack_fixture_known_limitations_summary",
        "fixture_row_count": len(rows),
        "known_limitations_available_count": len(available_rows),
        "known_limitations_unavailable_count": unavailable_count,
        "known_limitations_note_count_total": note_count_total,
        "known_limitations_requirement_satisfied_count": len(available_rows),
        "known_limitations_requirement_satisfied_count_matched": (
            len(available_rows) == len(rows)
        ),
        "known_limitations_unavailable_count_matched": (
            unavailable_count == len(rows) - len(available_rows)
        ),
        "matched": (
            len(available_rows) == len(rows)
            and unavailable_count == 0
            and note_count_total >= len(rows)
        ),
    }


def _cross_workstream_validation_pack_fixture_row(fixture: DiagramFixture) -> dict:
    expected_homfly_available = bool(fixture.expected_homfly or fixture.source_table_homfly)
    expected_alexander_available = bool(
        fixture.expected_multivariable_alexander
        or fixture.source_table_multivariable_alexander
        or fixture.source_table_multivariable_alexander_numerator
    )
    expected_jones_available = bool(fixture.expected_jones or fixture.source_table_jones)
    source_url_required = fixture.source != "iroll"
    source_url_available = bool(fixture.source_url)
    source_url_shape = _cross_workstream_source_url_shape(fixture.source_url)
    source_url_http_or_https = bool(source_url_shape["source_url_http_or_https"])
    source_url_valid_when_applicable = (
        True
        if not source_url_required or not source_url_available
        else source_url_http_or_https
    )
    construction_available = fixture.has_pd_code or fixture.source == "iroll"
    convention_available = bool(
        fixture.convention_notes
        or fixture.expected_homfly_notes
        or fixture.expected_multivariable_alexander_notes
        or fixture.source_table_notes
    )
    limitation_available = bool(
        fixture.expected_homfly_notes
        or fixture.expected_multivariable_alexander_notes
        or fixture.source_table_notes
        or fixture.convention_notes
    )
    metadata_blockers = []
    checks = {
        "construction_or_source_available": construction_available,
        "expected_homfly_or_source_table_available": expected_homfly_available,
        "expected_alexander_or_source_table_available": expected_alexander_available,
        "convention_or_normalization_notes_available": convention_available,
        "known_limitations_available": limitation_available,
        "source_url_available_when_applicable": (
            source_url_available if source_url_required else True
        ),
        "source_url_http_or_https_when_applicable": (
            source_url_valid_when_applicable
        ),
    }
    for code, passed in checks.items():
        if not passed:
            metadata_blockers.append(
                {
                    "notation": fixture.notation,
                    "code": code,
                    "reason": "required validation-pack fixture metadata is missing",
                }
            )
    return {
        "notation": fixture.notation,
        "name": fixture.name,
        "kind": fixture.kind,
        "component_count": fixture.component_count,
        "source": fixture.source,
        "source_url": fixture.source_url,
        "source_url_required": source_url_required,
        "source_url_scheme": source_url_shape["source_url_scheme"],
        "source_url_domain": source_url_shape["source_url_domain"],
        "source_url_http_or_https": source_url_http_or_https,
        "source_url_http_or_https_when_applicable": (
            source_url_valid_when_applicable
        ),
        "has_pd_code": fixture.has_pd_code,
        "has_signed_pd": fixture.has_signed_pd,
        "has_gauss_code": fixture.gauss_code is not None,
        "expected_jones_available": expected_jones_available,
        "expected_homfly_available": expected_homfly_available,
        "expected_homfly_source": fixture.expected_homfly_source,
        "source_table_homfly_available": fixture.source_table_homfly is not None,
        "expected_multivariable_alexander_available": expected_alexander_available,
        "expected_multivariable_alexander_source": (
            fixture.expected_multivariable_alexander_source
        ),
        "source_table_multivariable_alexander_available": (
            fixture.source_table_multivariable_alexander is not None
        ),
        "source_table_multivariable_alexander_numerator_available": (
            fixture.source_table_multivariable_alexander_numerator is not None
        ),
        "orientation_role_orders_available": fixture.orientation_role_orders is not None,
        "convention_note_count": len(fixture.convention_notes),
        "expected_homfly_note_count": len(fixture.expected_homfly_notes),
        "expected_multivariable_alexander_note_count": len(
            fixture.expected_multivariable_alexander_notes
        ),
        "source_table_note_count": len(fixture.source_table_notes),
        "metadata_checks": checks,
        "metadata_complete": not metadata_blockers,
        "metadata_blockers": metadata_blockers,
        "registration_status": (
            "registered_signed_fixture"
            if fixture.has_signed_pd
            else "source_table_unsigned_fixture_pending_sign_registration"
        ),
    }


def _signed_fixture_candidate_blocker_evidence(fixture: DiagramFixture) -> dict:
    if fixture.has_signed_pd:
        return {
            "claim_scope": "signed_fixture_candidate_blocker_evidence",
            "available": False,
            "skipped": True,
            "reason": "fixture already has a signed-PD registration",
            "matching_candidate_count": 0,
            "returned_candidate_count": 0,
            "unique_sign_pattern_count": 0,
            "mirror_pair_count": 0,
            "candidate_group_count": 0,
            "complete_candidate_set": False,
            "stable_invariants": [],
            "replay_checked_candidate_count": 0,
            "replay_valid_replay_count": 0,
            "all_returned_candidates_have_valid_replay": False,
            "registration_blocker_code": "signed_fixture_already_registered",
            "notes": [
                "candidate blocker evidence is emitted only for unsigned required fixtures",
            ],
        }
    if fixture.pd_code is None or fixture.gauss_code is None:
        return {
            "claim_scope": "signed_fixture_candidate_blocker_evidence",
            "available": False,
            "skipped": True,
            "reason": "fixture lacks PD or source Gauss-code metadata",
            "matching_candidate_count": 0,
            "returned_candidate_count": 0,
            "unique_sign_pattern_count": 0,
            "mirror_pair_count": 0,
            "candidate_group_count": 0,
            "complete_candidate_set": False,
            "stable_invariants": [],
            "replay_checked_candidate_count": 0,
            "replay_valid_replay_count": 0,
            "all_returned_candidates_have_valid_replay": False,
            "registration_blocker_code": "source_candidate_metadata_missing",
            "notes": [
                "source candidate evidence requires both a PD source and source Gauss code",
            ],
        }

    diagnostics = fixture.source_invariant_candidate_diagnostics(
        max_orientation_samples=64,
        max_candidates=2 ** len(fixture.pd_code),
        compute_homfly=False,
        compute_alexander=False,
    )
    matching_sign_summary = diagnostics.get("matching_sign_summary") or {}
    convergence = diagnostics.get("candidate_convergence") or {}
    replay_summary = diagnostics.get("signed_pd_replay_summary") or {}
    unique_sign_pattern_count = int(
        matching_sign_summary.get("unique_sign_pattern_count", 0) or 0
    )
    matching_candidate_count = int(
        diagnostics.get("matching_candidate_count", 0) or 0
    )
    complete_candidate_set = bool(convergence.get("complete_candidate_set", False))
    unique_candidate = complete_candidate_set and unique_sign_pattern_count == 1
    stable_invariants = list(convergence.get("stable_invariants", []))
    registration_blocker_code = (
        "source_candidate_not_unique"
        if not unique_candidate
        else "source_candidate_requires_external_verification"
    )
    readiness_checks = {
        "source_url_available": bool(fixture.source_url),
        "complete_candidate_set": complete_candidate_set,
        "unique_sign_pattern": unique_sign_pattern_count == 1,
        "source_candidate_replay_valid": bool(
            replay_summary.get("all_returned_candidates_have_valid_replay", False)
        ),
        "invariant_table_values_verified": False,
        "external_source_assignment_verified": False,
    }
    readiness_blockers = [
        code for code, passed in readiness_checks.items() if not passed
    ]
    return {
        "claim_scope": "signed_fixture_candidate_blocker_evidence",
        "available": True,
        "skipped": False,
        "source_method": diagnostics.get("method"),
        "gauss_code_match_required": bool(
            diagnostics.get("gauss_code_match_required", False)
        ),
        "target_pairwise_linking": diagnostics.get("target_pairwise_linking"),
        "orientation_sample_count": int(
            diagnostics.get("orientation_sample_count", 0) or 0
        ),
        "matching_candidate_count": matching_candidate_count,
        "returned_candidate_count": int(
            diagnostics.get("returned_candidate_count", 0) or 0
        ),
        "unique_sign_pattern_count": unique_sign_pattern_count,
        "mirror_pair_count": int(matching_sign_summary.get("mirror_pair_count", 0) or 0),
        "candidate_group_count": int(convergence.get("candidate_group_count", 0) or 0),
        "complete_candidate_set": complete_candidate_set,
        "stable_invariants": stable_invariants,
        "stable_invariant_count": len(stable_invariants),
        "replay_checked_candidate_count": int(
            replay_summary.get("checked_candidate_count", 0) or 0
        ),
        "replay_valid_replay_count": int(
            replay_summary.get("valid_replay_count", 0) or 0
        ),
        "all_returned_candidates_have_valid_replay": bool(
            replay_summary.get("all_returned_candidates_have_valid_replay", False)
        ),
        "unique_candidate": unique_candidate,
        "registration_blocker_code": registration_blocker_code,
        "registration_ready": False,
        "verified_assignment_readiness": {
            "claim_scope": "verified_signed_crossing_assignment_readiness",
            "ready": False,
            "check_count": len(readiness_checks),
            "passed_check_count": sum(1 for passed in readiness_checks.values() if passed),
            "failed_check_count": len(readiness_blockers),
            "checks": readiness_checks,
            "blockers": readiness_blockers,
            "blocker_count": len(readiness_blockers),
            "required_artifact": "verified_signed_crossing_assignment",
            "notes": [
                "readiness summarizes why the source candidate set cannot be promoted automatically",
                "external source assignment verification remains required before fixture registration",
            ],
        },
        "notes": [
            "source candidate evidence is bounded convention-reconciliation evidence",
            "verified signed crossing assignment and external normalization remain required",
        ],
    }


def verified_signed_crossing_assignment_readiness_report(
    notations: Sequence[str] | None = None,
) -> dict:
    """Report source-candidate readiness for verified signed assignment packs."""

    required = tuple(notations or ("L5a1", "L6a4"))
    fixture_by_notation = {fixture.notation: fixture for fixture in STANDARD_DIAGRAM_FIXTURES}
    rows: list[dict] = []
    missing_notations: list[str] = []
    blocker_counts: dict[str, int] = {}
    for notation in required:
        fixture = fixture_by_notation.get(notation)
        if fixture is None:
            missing_notations.append(notation)
            row = {
                "notation": notation,
                "available": False,
                "registration_ready": False,
                "verified_assignment_readiness_ready": False,
                "readiness_blockers": ["required_fixture_missing"],
                "readiness_blocker_count": 1,
                "registration_blocker_code": "required_fixture_missing",
                "required_artifact": "verified_signed_crossing_assignment",
            }
        else:
            evidence = _signed_fixture_candidate_blocker_evidence(fixture)
            readiness = evidence.get("verified_assignment_readiness") or {}
            blockers = list(readiness.get("blockers", []))
            row = {
                "notation": notation,
                "source_url": fixture.source_url,
                "available": evidence.get("available") is True,
                "skipped": evidence.get("skipped") is True,
                "registration_ready": evidence.get("registration_ready") is True,
                "verified_assignment_readiness_ready": readiness.get("ready") is True,
                "matching_candidate_count": evidence.get("matching_candidate_count", 0),
                "returned_candidate_count": evidence.get("returned_candidate_count", 0),
                "unique_sign_pattern_count": evidence.get("unique_sign_pattern_count", 0),
                "mirror_pair_count": evidence.get("mirror_pair_count", 0),
                "complete_candidate_set": evidence.get("complete_candidate_set") is True,
                "stable_invariants": list(evidence.get("stable_invariants", [])),
                "stable_invariant_count": evidence.get("stable_invariant_count", 0),
                "replay_checked_candidate_count": evidence.get(
                    "replay_checked_candidate_count", 0
                ),
                "replay_valid_replay_count": evidence.get(
                    "replay_valid_replay_count", 0
                ),
                "all_returned_candidates_have_valid_replay": evidence.get(
                    "all_returned_candidates_have_valid_replay"
                )
                is True,
                "unique_candidate": evidence.get("unique_candidate") is True,
                "registration_blocker_code": evidence.get(
                    "registration_blocker_code"
                ),
                "readiness_check_count": readiness.get("check_count", 0),
                "readiness_passed_check_count": readiness.get("passed_check_count", 0),
                "readiness_failed_check_count": readiness.get("failed_check_count", 0),
                "readiness_blockers": blockers,
                "readiness_blocker_count": len(blockers),
                "required_artifact": readiness.get(
                    "required_artifact", "verified_signed_crossing_assignment"
                ),
            }
        rows.append(row)
        for blocker in row["readiness_blockers"]:
            blocker_counts[blocker] = blocker_counts.get(blocker, 0) + 1

    blocker_codes = sorted(blocker_counts)
    ready_rows = [
        row for row in rows if row.get("verified_assignment_readiness_ready") is True
    ]
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "verified_signed_crossing_assignment_readiness_report",
        "claim_scope": "verified_signed_crossing_assignment_readiness",
        "source_method": "iroll verified-signed-crossing-assignment-readiness",
        "required_artifact": "verified_signed_crossing_assignment",
        "required_notations": list(required),
        "required_notation_count": len(required),
        "missing_required_notations": missing_notations,
        "missing_required_notation_count": len(missing_notations),
        "readiness_row_count": len(rows),
        "readiness_ready_count": len(ready_rows),
        "readiness_all_ready": len(ready_rows) == len(rows) and not missing_notations,
        "readiness_blocker_count": sum(blocker_counts.values()),
        "readiness_blocker_codes": blocker_codes,
        "readiness_blocker_code_counts": {
            code: blocker_counts[code] for code in blocker_codes
        },
        "readiness_blocker_signature": ",".join(
            f"{code}:{blocker_counts[code]}" for code in blocker_codes
        ),
        "readiness_rows": rows,
        "completion_claimed": False,
        "notes": [
            "readiness is pre-certification evidence for signed assignment production",
            "readiness_all_ready=false means verified_signed_crossing_assignment artifacts are still missing",
        ],
    }


def _readiness_blocker_summary(readiness_blockers: Sequence[str]) -> dict:
    blocker_codes = sorted(set(readiness_blockers))
    blocker_counts = {
        code: sum(1 for blocker in readiness_blockers if blocker == code)
        for code in blocker_codes
    }
    return {
        "readiness_blocker_codes": blocker_codes,
        "readiness_blocker_code_counts": {
            code: blocker_counts[code] for code in blocker_codes
        },
        "readiness_blocker_count_signature": ",".join(
            f"{code}:{blocker_counts[code]}" for code in blocker_codes
        ),
    }


def production_imgui_renderer_framebuffer_readiness_report(
    production_imgui_renderer_framebuffer_pack: Mapping[str, Any] | None = None,
) -> dict:
    """Report readiness for the production ImGui framebuffer evidence pack."""

    evidence = _production_imgui_renderer_framebuffer_pack_evidence(
        production_imgui_renderer_framebuffer_pack
    )
    audit = cross_workstream_validation_pack_audit(
        production_imgui_renderer_framebuffer_pack=(
            production_imgui_renderer_framebuffer_pack
        )
    )
    gate_checks = {
        row.get("gate"): row for row in audit.get("final_completion_gate_checks", [])
    }
    production_gate = gate_checks.get("production_imgui_renderer", {})
    retained_evidence = list(production_gate.get("retained_evidence", []))
    retained_real_backend_count = sum(
        1
        for row in retained_evidence
        if row.get("real_graphics_backend_framebuffer_verified") is True
    )
    retained_screenshot_count = sum(
        1 for row in retained_evidence if row.get("screenshot_verified") is True
    )
    failed_check_to_blocker = {
        "passed": "passed",
        "render_frame_count_positive": "render_frame_count",
        "framebuffer_touched": "framebuffer_touched",
        "framebuffer_touched_unit_flag": "framebuffer_touched",
        "estimated_nonzero_pixels": "estimated_nonzero_pixels",
        "real_graphics_backend_framebuffer_verified": (
            "real_graphics_backend_framebuffer_verified"
        ),
        "screenshot_verified": "screenshot_verified",
        "graphics_backend_name_available": "graphics_backend_name",
        "graphics_backend_name_not_test_or_stub": "graphics_backend_name",
        "framebuffer_width_positive": "framebuffer_width",
        "framebuffer_height_positive": "framebuffer_height",
        "screenshot_url_http": "screenshot_url",
    }
    default_blockers = [
        "estimated_nonzero_pixels",
        "framebuffer_height",
        "framebuffer_touched",
        "framebuffer_width",
        "graphics_backend_name",
        "passed",
        "real_graphics_backend_framebuffer_verified",
        "render_frame_count",
        "screenshot_url",
        "screenshot_verified",
    ]
    if evidence.get("available") is not True:
        readiness_blockers = list(default_blockers)
    else:
        readiness_blockers = sorted(
            {
                failed_check_to_blocker[check]
                for check in evidence.get("failed_checks", [])
                if check in failed_check_to_blocker
            }
        )
    readiness_checks = {
        "passed": "passed" not in readiness_blockers,
        "render_frame_count": "render_frame_count" not in readiness_blockers,
        "framebuffer_touched": "framebuffer_touched" not in readiness_blockers,
        "estimated_nonzero_pixels": (
            "estimated_nonzero_pixels" not in readiness_blockers
        ),
        "graphics_backend_name": "graphics_backend_name" not in readiness_blockers,
        "framebuffer_width": "framebuffer_width" not in readiness_blockers,
        "framebuffer_height": "framebuffer_height" not in readiness_blockers,
        "real_graphics_backend_framebuffer_verified": (
            "real_graphics_backend_framebuffer_verified" not in readiness_blockers
        ),
        "screenshot_url": "screenshot_url" not in readiness_blockers,
        "screenshot_verified": "screenshot_verified" not in readiness_blockers,
    }
    readiness_ready = evidence.get("certified") is True and not readiness_blockers
    blocker_summary = _readiness_blocker_summary(readiness_blockers)
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "production_imgui_renderer_framebuffer_readiness_report",
        "claim_scope": "production_imgui_renderer_framebuffer_readiness",
        "source_method": "iroll production-imgui-renderer-framebuffer-readiness",
        "required_artifact": "production_imgui_renderer_framebuffer_pack",
        "readiness_all_ready": readiness_ready,
        "readiness_check_count": len(readiness_checks),
        "readiness_passed_check_count": sum(
            1 for passed in readiness_checks.values() if passed
        ),
        "readiness_failed_check_count": len(readiness_blockers),
        "readiness_checks": readiness_checks,
        "readiness_blockers": readiness_blockers,
        "readiness_blocker_count": len(readiness_blockers),
        **blocker_summary,
        "readiness_blocker_signature": ",".join(readiness_blockers),
        "production_pack_available": evidence.get("available") is True,
        "production_pack_certified": evidence.get("certified") is True,
        "production_pack_evidence": evidence,
        "production_gate_passed": production_gate.get("passed") is True,
        "production_gate_blocker_count": int(
            production_gate.get("blocker_count", 0) or 0
        ),
        "retained_evidence_count": len(retained_evidence),
        "retained_evidence": retained_evidence,
        "retained_real_graphics_backend_framebuffer_verified_count": (
            retained_real_backend_count
        ),
        "retained_screenshot_verified_count": retained_screenshot_count,
        "retained_stub_framebuffer_smoke_count": sum(
            1
            for row in retained_evidence
            if row.get("source_method") == "imgui_test_stub_framebuffer_smoke"
        ),
        "completion_claimed": False,
        "notes": [
            "readiness distinguishes repository stub framebuffer evidence from production renderer evidence",
            "a certified production framebuffer pack is still required before final completion",
        ],
    }


def signed_release_publication_readiness_report(
    signed_release_publication_manifest: Mapping[str, Any] | None = None,
) -> dict:
    """Report readiness for the signed release publication manifest."""

    evidence = _signed_release_publication_manifest_evidence(
        signed_release_publication_manifest
    )
    audit = cross_workstream_validation_pack_audit(
        signed_release_publication_manifest=signed_release_publication_manifest
    )
    gate_checks = {
        row.get("gate"): row for row in audit.get("final_completion_gate_checks", [])
    }
    release_gate = gate_checks.get("release_artifacts", {})
    retained_evidence = list(release_gate.get("retained_evidence", []))
    retained_signed_count = sum(
        1
        for row in retained_evidence
        if row.get("signed_release_artifacts_published") is True
    )
    retained_publication_count = sum(
        1 for row in retained_evidence if row.get("publication_claimed") is True
    )
    retained_platform_count = sum(
        1
        for row in retained_evidence
        if row.get("platform_index_publication_claimed") is True
    )
    failed_check_to_blocker = {
        "artifact_schema_version": "manifest_contract",
        "artifact_kind": "manifest_contract",
        "claim_scope": "manifest_contract",
        "template_placeholder_not_true": "manifest_contract",
        "release_version_available": "release_version",
        "artifact_set_is_one_wheel_and_one_sdist": "release_version",
        "artifact_filenames_match_release_version": "release_version",
        "signed_release_artifacts_published": "signed_release_artifacts_published",
        "publication_claimed": "publication_claimed",
        "platform_index_publication_claimed": "platform_index_publication_claimed",
        "published_artifact_count": "published_artifact_count",
        "signature_count": "signature_count",
        "signature_count_matches_published_artifact_count": "signature_count",
        "package_index_url_available": "package_index_url",
        "package_index_url_http": "package_index_url",
        "package_index_url_not_artifact_or_signature_url": "package_index_url",
        "artifact_urls_available": "artifact_urls",
        "artifact_urls_items_nonempty_strings": "artifact_urls",
        "artifact_url_count_matches_published_artifact_count": "artifact_urls",
        "artifact_urls_http": "artifact_urls",
        "artifact_urls_unique": "artifact_urls",
        "artifact_url_filenames_unique": "artifact_urls",
        "artifact_urls_disjoint_from_signature_urls": "artifact_urls",
        "artifact_sha256s_available": "artifact_sha256s",
        "artifact_sha256s_items_nonempty_strings": "artifact_sha256s",
        "artifact_sha256_count_matches_published_artifact_count": (
            "artifact_sha256s"
        ),
        "artifact_sha256_count_matches_artifact_url_count": "artifact_sha256s",
        "artifact_sha256s_hex": "artifact_sha256s",
        "artifact_sha256s_unique": "artifact_sha256s",
        "artifact_url_sha256_pairs_unique": "artifact_sha256s",
        "artifact_sha256s_disjoint_from_signature_sha256s": (
            "artifact_sha256s"
        ),
        "signature_urls_available": "signature_urls",
        "signature_urls_items_nonempty_strings": "signature_urls",
        "signature_url_count_matches_signature_count": "signature_urls",
        "signature_urls_http": "signature_urls",
        "signature_urls_unique": "signature_urls",
        "signature_url_filenames_unique": "signature_urls",
        "signature_url_filenames_have_signature_extension": "signature_urls",
        "signature_urls_match_artifact_url_filenames": "signature_urls",
        "signature_sha256s_available": "signature_sha256s",
        "signature_sha256s_items_nonempty_strings": "signature_sha256s",
        "signature_sha256_count_matches_signature_count": "signature_sha256s",
        "signature_sha256_count_matches_signature_url_count": (
            "signature_sha256s"
        ),
        "signature_sha256s_hex": "signature_sha256s",
        "signature_sha256s_unique": "signature_sha256s",
        "signature_url_sha256_pairs_unique": "signature_sha256s",
    }
    failed_check_to_blocker.update(
        {
            check: "source_alignment"
            for check in (
                "source_alignment_object",
                "source_alignment_current_source_path",
                "source_alignment_wheel_member_path",
                "source_alignment_sdist_member_suffix",
                "source_alignment_current_source_sha256",
                "source_alignment_wheel_member_sha256",
                "source_alignment_sdist_member_sha256",
                "source_alignment_sha256s_match",
                "source_alignment_required_symbols_nonempty_unique_strings",
                "source_alignment_required_symbols_include_strict_contract",
                "source_alignment_required_symbol_count",
                "source_alignment_current_source_contains_required_symbols",
                "source_alignment_wheel_member_contains_required_symbols",
                "source_alignment_sdist_member_contains_required_symbols",
                "source_alignment_source_sha256s_match_claimed",
                "source_alignment_verified",
            )
        }
    )
    default_blockers = [
        "artifact_sha256s",
        "artifact_urls",
        "manifest_contract",
        "package_index_url",
        "platform_index_publication_claimed",
        "publication_claimed",
        "published_artifact_count",
        "release_version",
        "signature_count",
        "signature_sha256s",
        "signature_urls",
        "signed_release_artifacts_published",
        "source_alignment",
    ]
    if evidence.get("available") is not True:
        readiness_blockers = list(default_blockers)
    else:
        readiness_blockers = sorted(
            {
                failed_check_to_blocker[check]
                for check in evidence.get("failed_checks", [])
                if check in failed_check_to_blocker
            }
        )
    readiness_checks = {
        "manifest_contract": "manifest_contract" not in readiness_blockers,
        "release_version": "release_version" not in readiness_blockers,
        "source_alignment": "source_alignment" not in readiness_blockers,
        "signed_release_artifacts_published": (
            "signed_release_artifacts_published" not in readiness_blockers
        ),
        "publication_claimed": "publication_claimed" not in readiness_blockers,
        "platform_index_publication_claimed": (
            "platform_index_publication_claimed" not in readiness_blockers
        ),
        "published_artifact_count": (
            "published_artifact_count" not in readiness_blockers
        ),
        "signature_count": "signature_count" not in readiness_blockers,
        "package_index_url": "package_index_url" not in readiness_blockers,
        "artifact_urls": "artifact_urls" not in readiness_blockers,
        "artifact_sha256s": "artifact_sha256s" not in readiness_blockers,
        "signature_urls": "signature_urls" not in readiness_blockers,
        "signature_sha256s": "signature_sha256s" not in readiness_blockers,
    }
    readiness_ready = evidence.get("certified") is True and not readiness_blockers
    blocker_summary = _readiness_blocker_summary(readiness_blockers)
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "signed_release_publication_readiness_report",
        "claim_scope": "signed_release_publication_readiness",
        "source_method": "iroll signed-release-publication-readiness",
        "required_artifact": "signed_release_publication_manifest",
        "readiness_all_ready": readiness_ready,
        "readiness_check_count": len(readiness_checks),
        "readiness_passed_check_count": sum(
            1 for passed in readiness_checks.values() if passed
        ),
        "readiness_failed_check_count": len(readiness_blockers),
        "readiness_checks": readiness_checks,
        "readiness_blockers": readiness_blockers,
        "readiness_blocker_count": len(readiness_blockers),
        **blocker_summary,
        "readiness_blocker_signature": ",".join(readiness_blockers),
        "release_manifest_available": evidence.get("available") is True,
        "release_manifest_certified": evidence.get("certified") is True,
        "release_manifest_evidence": evidence,
        "release_gate_passed": release_gate.get("passed") is True,
        "release_gate_blocker_count": int(
            release_gate.get("blocker_count", 0) or 0
        ),
        "retained_evidence_count": len(retained_evidence),
        "retained_evidence": retained_evidence,
        "retained_signed_release_artifacts_published_count": retained_signed_count,
        "retained_publication_claimed_count": retained_publication_count,
        "retained_platform_index_publication_claimed_count": retained_platform_count,
        "retained_unsigned_ci_release_manifest_count": sum(
            1
            for row in retained_evidence
            if row.get("source_method") == "rust_wheel_retained_metadata_manifest"
        ),
        "completion_claimed": False,
        "notes": [
            "readiness distinguishes unsigned CI artifact retention from signed release publication",
            "a certified signed publication manifest is still required before final completion",
        ],
    }


def full_homfly_pt_evaluation_readiness_report(
    full_homfly_pt_evaluation_certification_pack: Mapping[str, Any] | None = None,
) -> dict:
    """Report readiness for the full HOMFLY-PT certification pack."""

    evidence = _full_homfly_pt_evaluation_certification_pack_evidence(
        full_homfly_pt_evaluation_certification_pack
    )
    audit = cross_workstream_validation_pack_audit(
        full_homfly_pt_evaluation_certification_pack=(
            full_homfly_pt_evaluation_certification_pack
        )
    )
    gate_checks = {
        row.get("gate"): row for row in audit.get("final_completion_gate_checks", [])
    }
    gate = gate_checks.get("full_homfly_pt_evaluation", {})
    retained_evidence = list(gate.get("retained_evidence", []))
    failed_check_to_blocker = {
        "full_homfly_pt_evaluation_certified": "full_homfly_pt_evaluation_certified",
        "arbitrary_signed_pd_coverage_certified": (
            "arbitrary_signed_pd_coverage_certified"
        ),
        "external_table_normalization_certified": (
            "external_table_normalization_certified"
        ),
        "skein_relation_certified": "skein_relation_certified",
        "registered_fixture_regression_certified": (
            "registered_fixture_regression_certified"
        ),
        "counterexample_count_zero": "counterexample_count_zero",
        "certification_report_url_http": "certification_report_url",
        "external_table_source_urls_available": "external_table_source_urls",
        "external_table_source_urls_http": "external_table_source_urls",
    }
    default_blockers = [
        "arbitrary_signed_pd_coverage_certified",
        "certification_report_url",
        "counterexample_count_zero",
        "external_table_normalization_certified",
        "external_table_source_urls",
        "registered_fixture_regression_certified",
        "skein_relation_certified",
    ]
    if evidence.get("available") is not True:
        readiness_blockers = list(default_blockers)
    else:
        readiness_blockers = sorted(
            {
                failed_check_to_blocker[check]
                for check in evidence.get("failed_checks", [])
                if check in failed_check_to_blocker
                and failed_check_to_blocker[check] != "full_homfly_pt_evaluation_certified"
            }
        )
    readiness_checks = {name: name not in readiness_blockers for name in default_blockers}
    readiness_ready = evidence.get("certified") is True and not readiness_blockers
    blocker_summary = _readiness_blocker_summary(readiness_blockers)
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "full_homfly_pt_evaluation_readiness_report",
        "claim_scope": "full_homfly_pt_evaluation_readiness",
        "source_method": "iroll full-homfly-pt-evaluation-readiness",
        "required_artifact": "full_homfly_pt_evaluation_certification_pack",
        "readiness_all_ready": readiness_ready,
        "readiness_check_count": len(readiness_checks),
        "readiness_passed_check_count": sum(
            1 for passed in readiness_checks.values() if passed
        ),
        "readiness_failed_check_count": len(readiness_blockers),
        "readiness_checks": readiness_checks,
        "readiness_blockers": readiness_blockers,
        "readiness_blocker_count": len(readiness_blockers),
        **blocker_summary,
        "readiness_blocker_signature": ",".join(readiness_blockers),
        "certification_pack_available": evidence.get("available") is True,
        "certification_pack_certified": evidence.get("certified") is True,
        "certification_pack_evidence": evidence,
        "certification_gate_passed": gate.get("passed") is True,
        "certification_gate_blocker_count": int(gate.get("blocker_count", 0) or 0),
        "retained_evidence_count": len(retained_evidence),
        "retained_evidence": retained_evidence,
        "retained_repository_test_count": sum(
            1 for row in retained_evidence if row.get("evidence_kind") == "repository_test"
        ),
        "retained_registered_fixture_scope_count": sum(
            1
            for row in retained_evidence
            if row.get("source_method") == "homfly_fixture_acceptance_report"
        ),
        "retained_bounded_scope_count": sum(
            1
            for row in retained_evidence
            if row.get("source_method") == "homfly_small_diagram_coverage_report"
        ),
        "completion_claimed": False,
        "notes": [
            "readiness distinguishes bounded HOMFLY evidence from full arbitrary signed-PD certification",
            "a certified full HOMFLY-PT evaluation pack is still required before final completion",
        ],
    }


def full_multivariable_alexander_normalization_readiness_report(
    full_multivariable_alexander_normalization_certification_pack: (
        Mapping[str, Any] | None
    ) = None,
) -> dict:
    """Report readiness for the full multi-variable Alexander certification pack."""

    evidence = _full_multivariable_alexander_normalization_certification_pack_evidence(
        full_multivariable_alexander_normalization_certification_pack
    )
    audit = cross_workstream_validation_pack_audit(
        full_multivariable_alexander_normalization_certification_pack=(
            full_multivariable_alexander_normalization_certification_pack
        )
    )
    gate_checks = {
        row.get("gate"): row for row in audit.get("final_completion_gate_checks", [])
    }
    gate = gate_checks.get("full_multivariable_alexander_normalization", {})
    retained_evidence = list(gate.get("retained_evidence", []))
    failed_check_to_blocker = {
        "full_multivariable_alexander_normalization_certified": (
            "full_multivariable_alexander_normalization_certified"
        ),
        "signed_pd_wirtinger_fox_certified": "signed_pd_wirtinger_fox_certified",
        "admissible_minor_normalization_certified": (
            "admissible_minor_normalization_certified"
        ),
        "all_admissible_minors_consistent": "all_admissible_minors_consistent",
        "external_table_normalization_certified": (
            "external_table_normalization_certified"
        ),
        "counterexample_count_zero": "counterexample_count_zero",
        "certification_report_url_http": "certification_report_url",
        "external_table_source_urls_available": "external_table_source_urls",
        "external_table_source_urls_http": "external_table_source_urls",
    }
    default_blockers = [
        "admissible_minor_normalization_certified",
        "all_admissible_minors_consistent",
        "certification_report_url",
        "counterexample_count_zero",
        "external_table_normalization_certified",
        "external_table_source_urls",
        "signed_pd_wirtinger_fox_certified",
    ]
    if evidence.get("available") is not True:
        readiness_blockers = list(default_blockers)
    else:
        readiness_blockers = sorted(
            {
                failed_check_to_blocker[check]
                for check in evidence.get("failed_checks", [])
                if check in failed_check_to_blocker
                and failed_check_to_blocker[check]
                != "full_multivariable_alexander_normalization_certified"
            }
        )
    readiness_checks = {name: name not in readiness_blockers for name in default_blockers}
    readiness_ready = evidence.get("certified") is True and not readiness_blockers
    blocker_summary = _readiness_blocker_summary(readiness_blockers)
    return {
        "artifact_schema_version": 1,
        "artifact_kind": (
            "full_multivariable_alexander_normalization_readiness_report"
        ),
        "claim_scope": "full_multivariable_alexander_normalization_readiness",
        "source_method": (
            "iroll full-multivariable-alexander-normalization-readiness"
        ),
        "required_artifact": (
            "full_multivariable_alexander_normalization_certification_pack"
        ),
        "readiness_all_ready": readiness_ready,
        "readiness_check_count": len(readiness_checks),
        "readiness_passed_check_count": sum(
            1 for passed in readiness_checks.values() if passed
        ),
        "readiness_failed_check_count": len(readiness_blockers),
        "readiness_checks": readiness_checks,
        "readiness_blockers": readiness_blockers,
        "readiness_blocker_count": len(readiness_blockers),
        **blocker_summary,
        "readiness_blocker_signature": ",".join(readiness_blockers),
        "certification_pack_available": evidence.get("available") is True,
        "certification_pack_certified": evidence.get("certified") is True,
        "certification_pack_evidence": evidence,
        "certification_gate_passed": gate.get("passed") is True,
        "certification_gate_blocker_count": int(gate.get("blocker_count", 0) or 0),
        "retained_evidence_count": len(retained_evidence),
        "retained_evidence": retained_evidence,
        "retained_repository_test_count": sum(
            1 for row in retained_evidence if row.get("evidence_kind") == "repository_test"
        ),
        "retained_registered_fixture_scope_count": sum(
            1
            for row in retained_evidence
            if row.get("source_method")
            == "multivariable_alexander_fixture_acceptance_report"
        ),
        "retained_bounded_scope_count": sum(
            1
            for row in retained_evidence
            if row.get("source_method")
            == "multivariable_alexander_signed_pd_coverage_report"
        ),
        "completion_claimed": False,
        "notes": [
            "readiness distinguishes bounded Alexander evidence from full signed-PD normalization certification",
            "a certified full multi-variable Alexander normalization pack is still required before final completion",
        ],
    }


def _completion_evidence_artifact_filenames(artifact_type: str) -> list[str]:
    filenames = {
        "verified_signed_crossing_assignment": [
            "verified_signed_crossing_assignment.L5a1.json",
            "verified_signed_crossing_assignment.L6a4.json",
        ],
        "production_imgui_renderer_framebuffer_pack": [
            "production_imgui_renderer_framebuffer_pack.json"
        ],
        "signed_release_publication_manifest": [
            "signed_release_publication_manifest.json"
        ],
        "full_homfly_pt_evaluation_certification_pack": [
            "full_homfly_pt_evaluation_certification_pack.json"
        ],
        "full_multivariable_alexander_normalization_certification_pack": [
            "full_multivariable_alexander_normalization_certification_pack.json"
        ],
        "release_grade_high_point_performance_pack": [
            "release_grade_high_point_performance_pack.json"
        ],
        "broad_noisy_curve_robustness_certification_pack": [
            "broad_noisy_curve_robustness_certification_pack.json"
        ],
    }
    return list(filenames.get(artifact_type, []))


def _expected_completion_evidence_filenames() -> list[str]:
    requirements = [
        "broad_noisy_curve_robustness_certification_pack.json",
        "full_homfly_pt_evaluation_certification_pack.json",
        "full_multivariable_alexander_normalization_certification_pack.json",
        "production_imgui_renderer_framebuffer_pack.json",
        "release_grade_high_point_performance_pack.json",
        "signed_release_publication_manifest.json",
        "verified_signed_crossing_assignment.L5a1.json",
        "verified_signed_crossing_assignment.L6a4.json",
    ]
    return requirements


def _cross_workstream_completion_evidence_bundle_evidence(
    bundle: Mapping[str, Any] | None,
) -> dict:
    required_artifact_keys = [
        "verified_signed_crossing_assignments",
        "production_imgui_renderer_framebuffer_pack",
        "signed_release_publication_manifest",
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "broad_noisy_curve_robustness_certification_pack",
        "release_grade_high_point_performance_pack",
    ]
    required_signed_assignment_notations = ["L5a1", "L6a4"]
    expected_evidence_filenames = _expected_completion_evidence_filenames()
    expected_evidence_filename_signature = "|".join(expected_evidence_filenames)
    if not isinstance(bundle, Mapping):
        bundle_contract_coverage = (
            completion_evidence_artifact_preflight_contract_coverage(
                [],
                claim_scope="completion_evidence_bundle_artifact_preflight_contract_coverage",
                required_signed_assignment_notations=(
                    required_signed_assignment_notations
                ),
                present_signed_assignment_notations=[],
            )
        )
        return {
            "available": False,
            "certified": False,
            "payload": {},
            "missing_reason": "completion evidence bundle not provided",
            "bundle_evidence_failed_check_count": 1,
            "bundle_evidence_failed_checks": ["completion_evidence_bundle_available"],
            "bundle_evidence_failed_check_signature": (
                "completion_evidence_bundle_available"
            ),
            "required_bundle_keys": required_artifact_keys,
            "missing_bundle_key_count": len(required_artifact_keys),
            "missing_bundle_keys": required_artifact_keys,
            "artifact_preflight_row_count": 0,
            "artifact_preflight_passed_count": 0,
            "artifact_preflight_failed_count": 0,
            "artifact_preflight_rows": [],
            "artifact_preflight_failed_rows": [],
            "completion_evidence_artifact_instance_row_count": 0,
            "completion_evidence_artifact_instance_rows": [],
            "completion_evidence_artifact_filenames": [],
            "completion_evidence_artifact_filename_signature": "",
            "expected_evidence_filename_count": len(expected_evidence_filenames),
            "expected_evidence_filenames": expected_evidence_filenames,
            "expected_evidence_filename_signature": (
                expected_evidence_filename_signature
            ),
            "completion_evidence_artifact_filenames_match_expected": False,
            "completion_evidence_artifact_filename_signature_matches_expected": (
                False
            ),
            "completion_evidence_artifact_instance_row_count_matches_expected": (
                False
            ),
            "expected_artifact_preflight_row_count": (
                len(required_signed_assignment_notations)
                + len(required_artifact_keys)
                - 1
            ),
            "all_bundle_artifacts_certified": False,
            "bundle_contract_coverage": bundle_contract_coverage,
            "bundle_contract_coverage_complete": False,
            "verified_signed_crossing_assignment_count": 0,
            "required_signed_assignment_notations": (
                required_signed_assignment_notations
            ),
            "present_signed_assignment_notations": [],
            "missing_signed_assignment_notation_count": len(
                required_signed_assignment_notations
            ),
            "missing_signed_assignment_notations": (
                required_signed_assignment_notations
            ),
            "artifact_key_count": 0,
        }
    assignments = bundle.get("verified_signed_crossing_assignments")
    assignment_count = (
        len(assignments)
        if isinstance(assignments, Sequence) and not isinstance(assignments, (str, bytes))
        else 0
    )
    assignment_sequence = (
        assignments
        if isinstance(assignments, Sequence) and not isinstance(assignments, (str, bytes))
        else []
    )
    present_signed_assignment_notations = sorted(
        {
            str(assignment.get("notation"))
            for assignment in assignment_sequence
            if isinstance(assignment, Mapping)
            and assignment.get("notation") in required_signed_assignment_notations
        }
    )
    missing_signed_assignment_notations = [
        notation
        for notation in required_signed_assignment_notations
        if notation not in present_signed_assignment_notations
    ]
    checks = {
        "artifact_schema_version": bundle.get("artifact_schema_version") == 1,
        "artifact_kind": (
            bundle.get("artifact_kind")
            == "cross_workstream_completion_evidence_bundle"
        ),
        "claim_scope": (
            bundle.get("claim_scope")
            == "cross_workstream_final_completion_evidence"
        ),
        "verified_signed_crossing_assignments": assignment_count > 0,
        "verified_signed_crossing_assignment_required_notations": (
            not missing_signed_assignment_notations
        ),
        "bundle_completion_claimed_false": (
            bundle.get("completion_claimed") is False
        ),
        "bundle_certified_by_audit_false": (
            bundle.get("bundle_certified_by_audit") is False
        ),
    }
    for key in required_artifact_keys[1:]:
        checks[key] = isinstance(bundle.get(key), Mapping)
    artifact_preflight_rows = []
    if assignment_sequence:
        for index, assignment in enumerate(assignment_sequence):
            if isinstance(assignment, Mapping):
                audit = completion_evidence_artifact_audit(
                    assignment,
                    artifact_type="verified_signed_crossing_assignment",
                )
                artifact_kind = audit.get("audited_artifact_kind")
            else:
                audit = completion_evidence_artifact_audit(
                    {},
                    artifact_type="verified_signed_crossing_assignment",
                )
                artifact_kind = None
            artifact_preflight_rows.append(
                {
                    "bundle_key": "verified_signed_crossing_assignments",
                    "artifact_type": "verified_signed_crossing_assignment",
                    "completion_evidence_artifact_filenames": (
                        _completion_evidence_artifact_filenames(
                            "verified_signed_crossing_assignment"
                        )
                    ),
                    "artifact_index": index,
                    "artifact_kind": artifact_kind,
                    "artifact_certified": audit["artifact_certified"],
                    "failed_check_count": audit["failed_check_count"],
                    "failed_checks": audit["failed_checks"],
                    "artifact_field_coverage_complete": audit[
                        "artifact_field_coverage_complete"
                    ],
                    "missing_artifact_field_count": audit[
                        "missing_artifact_field_count"
                    ],
                    "missing_artifact_fields": audit["missing_artifact_fields"],
                }
            )
    for key in required_artifact_keys[1:]:
        artifact = bundle.get(key)
        if not isinstance(artifact, Mapping):
            continue
        audit = completion_evidence_artifact_audit(artifact, artifact_type=key)
        artifact_preflight_rows.append(
            {
                "bundle_key": key,
                "artifact_type": key,
                "completion_evidence_artifact_filenames": (
                    _completion_evidence_artifact_filenames(key)
                ),
                "artifact_index": None,
                "artifact_kind": audit.get("audited_artifact_kind"),
                "artifact_certified": audit["artifact_certified"],
                "failed_check_count": audit["failed_check_count"],
                "failed_checks": audit["failed_checks"],
                "artifact_field_coverage_complete": audit[
                    "artifact_field_coverage_complete"
                ],
                "missing_artifact_field_count": audit[
                    "missing_artifact_field_count"
                ],
                "missing_artifact_fields": audit["missing_artifact_fields"],
            }
        )
    artifact_preflight_failed_rows = [
        row for row in artifact_preflight_rows if not row["artifact_certified"]
    ]
    artifact_instance_rows = (
        list(bundle.get("completion_evidence_artifact_instance_rows"))
        if isinstance(bundle.get("completion_evidence_artifact_instance_rows"), list)
        else []
    )
    artifact_filenames = (
        list(bundle.get("completion_evidence_artifact_filenames"))
        if isinstance(bundle.get("completion_evidence_artifact_filenames"), list)
        else []
    )
    artifact_filename_signature = (
        str(bundle.get("completion_evidence_artifact_filename_signature"))
        if bundle.get("completion_evidence_artifact_filename_signature") is not None
        else "|".join(str(filename) for filename in artifact_filenames)
    )
    artifact_preflight_field_coverage_failed_rows = [
        row
        for row in artifact_preflight_rows
        if row["artifact_field_coverage_complete"] is not True
    ]
    missing_artifact_fields_by_bundle_key: dict[str, list[dict]] = {}
    for row in artifact_preflight_field_coverage_failed_rows:
        bundle_key = str(row["bundle_key"])
        missing_artifact_fields_by_bundle_key.setdefault(bundle_key, []).append(
            {
                "artifact_type": row["artifact_type"],
                "artifact_index": row.get("artifact_index"),
                "missing_artifact_fields": list(row["missing_artifact_fields"]),
            }
        )
    expected_artifact_preflight_row_count = (
        assignment_count + len(required_artifact_keys) - 1
    )
    expected_evidence_filename_count_matches_artifact_preflight_row_count = (
        len(expected_evidence_filenames) == expected_artifact_preflight_row_count
    )
    artifact_preflight_field_coverage_complete = (
        len(artifact_preflight_rows) == expected_artifact_preflight_row_count
        and not artifact_preflight_field_coverage_failed_rows
    )
    all_bundle_artifacts_certified = (
        len(artifact_preflight_rows) == expected_artifact_preflight_row_count
        and not artifact_preflight_failed_rows
    )
    bundle_contract_coverage = (
        completion_evidence_artifact_preflight_contract_coverage(
            artifact_preflight_rows,
            claim_scope="completion_evidence_bundle_artifact_preflight_contract_coverage",
            required_signed_assignment_notations=required_signed_assignment_notations,
            present_signed_assignment_notations=present_signed_assignment_notations,
        )
    )
    checks["all_bundle_artifacts_certified"] = all_bundle_artifacts_certified
    checks["bundle_contract_coverage_complete"] = bundle_contract_coverage[
        "coverage_complete"
    ]
    checks["completion_evidence_artifact_filenames_match_expected"] = (
        artifact_filenames == expected_evidence_filenames
    )
    checks["completion_evidence_artifact_filename_signature_matches_expected"] = (
        artifact_filename_signature == expected_evidence_filename_signature
    )
    checks["completion_evidence_artifact_instance_row_count_matches_expected"] = (
        len(artifact_instance_rows) == len(expected_evidence_filenames)
    )
    invalid_bundle_fields = [
        name
        for name in (
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
        )
        if not checks[name]
    ]
    invalid_bundle_non_claim_fields = [
        field
        for field, check_name in (
            ("completion_claimed", "bundle_completion_claimed_false"),
            ("bundle_certified_by_audit", "bundle_certified_by_audit_false"),
        )
        if not checks[check_name]
    ]
    missing_bundle_keys = [
        key
        for key in required_artifact_keys
        if (
            assignment_count == 0
            if key == "verified_signed_crossing_assignments"
            else not isinstance(bundle.get(key), Mapping)
        )
    ]
    failed_checks = [name for name, passed in checks.items() if not passed]
    failed_check_signature = "|".join(failed_checks)
    payload = bundle if not failed_checks else {}
    return {
        "available": True,
        "certified": not failed_checks,
        "payload": payload,
        "evidence_id": "cross_workstream_completion_evidence_bundle",
        "evidence_kind": "completion_evidence_bundle",
        "artifact_kind": bundle.get("artifact_kind"),
        "source_method": "cross_workstream_completion_evidence_bundle",
        "claim_scope": bundle.get("claim_scope"),
        "required_check_count": len(checks),
        "passed_check_count": len(checks) - len(failed_checks),
        "failed_check_count": len(failed_checks),
        "failed_checks": failed_checks,
        "bundle_evidence_failed_check_count": len(failed_checks),
        "bundle_evidence_failed_checks": failed_checks,
        "bundle_evidence_failed_check_signature": failed_check_signature,
        "required_bundle_keys": required_artifact_keys,
        "missing_bundle_key_count": len(missing_bundle_keys),
        "missing_bundle_keys": missing_bundle_keys,
        "invalid_bundle_field_count": len(invalid_bundle_fields),
        "invalid_bundle_fields": invalid_bundle_fields,
        "invalid_bundle_non_claim_field_count": len(invalid_bundle_non_claim_fields),
        "invalid_bundle_non_claim_fields": invalid_bundle_non_claim_fields,
        "bundle_completion_claimed": bundle.get("completion_claimed"),
        "bundle_certified_by_audit": bundle.get("bundle_certified_by_audit"),
        "artifact_preflight_row_count": len(artifact_preflight_rows),
        "artifact_preflight_passed_count": (
            len(artifact_preflight_rows) - len(artifact_preflight_failed_rows)
        ),
        "artifact_preflight_failed_count": len(artifact_preflight_failed_rows),
        "artifact_preflight_rows": artifact_preflight_rows,
        "artifact_preflight_failed_rows": artifact_preflight_failed_rows,
        "completion_evidence_artifact_instance_row_count": len(
            artifact_instance_rows
        ),
        "completion_evidence_artifact_instance_rows": artifact_instance_rows,
        "completion_evidence_artifact_filenames": artifact_filenames,
        "completion_evidence_artifact_filename_signature": (
            artifact_filename_signature
        ),
        "expected_evidence_filename_count": len(expected_evidence_filenames),
        "expected_evidence_filenames": expected_evidence_filenames,
        "expected_evidence_filename_signature": (
            expected_evidence_filename_signature
        ),
        "completion_evidence_artifact_filenames_match_expected": (
            artifact_filenames == expected_evidence_filenames
        ),
        "completion_evidence_artifact_filename_signature_matches_expected": (
            artifact_filename_signature == expected_evidence_filename_signature
        ),
        "completion_evidence_artifact_instance_row_count_matches_expected": (
            len(artifact_instance_rows) == len(expected_evidence_filenames)
        ),
        "artifact_preflight_field_coverage_failed_count": (
            len(artifact_preflight_field_coverage_failed_rows)
        ),
        "artifact_preflight_field_coverage_failed_rows": (
            artifact_preflight_field_coverage_failed_rows
        ),
        "artifact_preflight_field_coverage_complete": (
            artifact_preflight_field_coverage_complete
        ),
        "missing_artifact_fields_by_bundle_key": (
            missing_artifact_fields_by_bundle_key
        ),
        "expected_artifact_preflight_row_count": (
            expected_artifact_preflight_row_count
        ),
        "expected_bundle_preflight_row_count_source": (
            "present_bundle_assignment_count_plus_single_artifacts"
        ),
        "expected_evidence_filename_count_matches_artifact_preflight_row_count": (
            expected_evidence_filename_count_matches_artifact_preflight_row_count
        ),
        "all_bundle_artifacts_certified": all_bundle_artifacts_certified,
        "bundle_contract_coverage": bundle_contract_coverage,
        "bundle_contract_coverage_complete": bundle_contract_coverage[
            "coverage_complete"
        ],
        "verified_signed_crossing_assignment_count": assignment_count,
        "required_signed_assignment_notations": (
            required_signed_assignment_notations
        ),
        "present_signed_assignment_notations": (
            present_signed_assignment_notations
        ),
        "missing_signed_assignment_notation_count": (
            len(missing_signed_assignment_notations)
        ),
        "missing_signed_assignment_notations": missing_signed_assignment_notations,
        "artifact_key_count": sum(
            1
            for key in required_artifact_keys[1:]
            if isinstance(bundle.get(key), Mapping)
        ),
        "completion_claimed": not failed_checks,
    }


def completion_evidence_artifact_preflight_contract_coverage(
    artifact_preflight_rows: Sequence[Mapping[str, Any]],
    *,
    claim_scope: str,
    required_signed_assignment_notations: Sequence[str],
    present_signed_assignment_notations: Sequence[str],
) -> dict:
    expected_single_artifact_types = [
        "broad_noisy_curve_robustness_certification_pack",
        "full_homfly_pt_evaluation_certification_pack",
        "full_multivariable_alexander_normalization_certification_pack",
        "production_imgui_renderer_framebuffer_pack",
        "release_grade_high_point_performance_pack",
        "signed_release_publication_manifest",
    ]
    expected_repeatable_artifact_types = ["verified_signed_crossing_assignment"]
    expected_artifact_types = sorted(
        expected_single_artifact_types + expected_repeatable_artifact_types
    )
    preflight_artifact_types = sorted(
        {
            str(row["artifact_type"])
            for row in artifact_preflight_rows
            if row.get("artifact_type")
        }
    )
    preflight_artifact_type_counts = {
        artifact_type: sum(
            1
            for row in artifact_preflight_rows
            if row.get("artifact_type") == artifact_type
        )
        for artifact_type in preflight_artifact_types
    }
    missing_artifact_types = [
        artifact_type
        for artifact_type in expected_artifact_types
        if artifact_type not in preflight_artifact_types
    ]
    unexpected_artifact_types = [
        artifact_type
        for artifact_type in preflight_artifact_types
        if artifact_type not in expected_artifact_types
    ]
    missing_single_artifact_types = [
        artifact_type
        for artifact_type in expected_single_artifact_types
        if preflight_artifact_type_counts.get(artifact_type, 0) != 1
    ]
    repeated_single_artifact_types = [
        artifact_type
        for artifact_type in expected_single_artifact_types
        if preflight_artifact_type_counts.get(artifact_type, 0) > 1
    ]
    signed_assignment_count = preflight_artifact_type_counts.get(
        "verified_signed_crossing_assignment",
        0,
    )
    required_signed_assignment_count = len(required_signed_assignment_notations)
    signed_assignment_count_matches_required = (
        signed_assignment_count == required_signed_assignment_count
    )
    missing_signed_assignment_notations = [
        notation
        for notation in required_signed_assignment_notations
        if notation not in present_signed_assignment_notations
    ]
    signed_assignment_notation_coverage_complete = (
        not missing_signed_assignment_notations
    )
    expected_artifact_type_coverage_complete = (
        not missing_artifact_types and not unexpected_artifact_types
    )
    single_artifact_type_coverage_complete = (
        not missing_single_artifact_types and not repeated_single_artifact_types
    )
    coverage_complete = (
        expected_artifact_type_coverage_complete
        and single_artifact_type_coverage_complete
        and signed_assignment_count_matches_required
        and signed_assignment_notation_coverage_complete
    )
    return {
        "claim_scope": claim_scope,
        "expected_artifact_types": expected_artifact_types,
        "expected_artifact_type_count": len(expected_artifact_types),
        "expected_single_artifact_types": expected_single_artifact_types,
        "expected_single_artifact_type_count": len(expected_single_artifact_types),
        "expected_repeatable_artifact_types": expected_repeatable_artifact_types,
        "expected_repeatable_artifact_type_count": len(
            expected_repeatable_artifact_types
        ),
        "preflight_artifact_types": preflight_artifact_types,
        "preflight_artifact_type_count": len(preflight_artifact_types),
        "preflight_artifact_type_counts": preflight_artifact_type_counts,
        "preflight_artifact_row_count": len(artifact_preflight_rows),
        "missing_artifact_types": missing_artifact_types,
        "missing_artifact_type_count": len(missing_artifact_types),
        "unexpected_artifact_types": unexpected_artifact_types,
        "unexpected_artifact_type_count": len(unexpected_artifact_types),
        "missing_single_artifact_types": missing_single_artifact_types,
        "missing_single_artifact_type_count": len(missing_single_artifact_types),
        "repeated_single_artifact_types": repeated_single_artifact_types,
        "repeated_single_artifact_type_count": len(repeated_single_artifact_types),
        "signed_assignment_preflight_count": signed_assignment_count,
        "required_signed_assignment_count": required_signed_assignment_count,
        "signed_assignment_count_matches_required": (
            signed_assignment_count_matches_required
        ),
        "required_signed_assignment_notations": list(
            required_signed_assignment_notations
        ),
        "present_signed_assignment_notations": list(
            present_signed_assignment_notations
        ),
        "missing_signed_assignment_notations": missing_signed_assignment_notations,
        "signed_assignment_notation_coverage_complete": (
            signed_assignment_notation_coverage_complete
        ),
        "expected_artifact_type_coverage_complete": (
            expected_artifact_type_coverage_complete
        ),
        "single_artifact_type_coverage_complete": (
            single_artifact_type_coverage_complete
        ),
        "coverage_complete": coverage_complete,
        "matched": coverage_complete,
    }


def _production_imgui_renderer_framebuffer_pack_evidence(
    pack: Mapping[str, Any] | None,
) -> dict:
    if not isinstance(pack, Mapping):
        return {
            "available": False,
            "certified": False,
            "missing_reason": "production framebuffer pack not provided",
        }
    url_witness_rows = [
        _final_evidence_url_witness(
            pack.get("screenshot_url"),
            field="screenshot_url",
        )
    ]
    digest_witness_rows = [
        _final_evidence_digest_witness(
            pack.get("screenshot_sha256"),
            field="screenshot_sha256",
            paired_url_field="screenshot_url",
            paired_url=pack.get("screenshot_url"),
        )
    ]
    checks = {
        "artifact_schema_version": pack.get("artifact_schema_version") == 1,
        "artifact_kind": (
            pack.get("artifact_kind")
            == "imgui_production_renderer_framebuffer_pack"
        ),
        "claim_scope": (
            pack.get("claim_scope")
            == "production_imgui_renderer_framebuffer_verification"
        ),
        "passed": pack.get("passed") is True,
        "render_frame_count_positive": _is_positive_int(
            pack.get("render_frame_count")
        ),
        "framebuffer_touched": _is_positive_int(pack.get("framebuffer_touched")),
        "framebuffer_touched_unit_flag": (
            _strict_int(pack.get("framebuffer_touched")) == 1
        ),
        "estimated_nonzero_pixels": _is_positive_int(
            pack.get("estimated_nonzero_pixels")
        ),
        "estimated_nonzero_pixels_covers_framebuffer_touched": (
            _estimated_nonzero_pixels_covers_framebuffer_touched(pack)
        ),
        "estimated_nonzero_pixels_within_framebuffer_area": (
            _estimated_nonzero_pixels_within_framebuffer_area(pack)
        ),
        "real_graphics_backend_framebuffer_verified": (
            pack.get("real_graphics_backend_framebuffer_verified") is True
        ),
        "screenshot_verified": pack.get("screenshot_verified") is True,
        "template_placeholder_not_true": pack.get("template_placeholder") is not True,
        "graphics_backend_name_available": bool(pack.get("graphics_backend_name")),
        "graphics_backend_name_not_test_or_stub": (
            _production_graphics_backend_name(pack.get("graphics_backend_name"))
        ),
        "framebuffer_width_positive": _is_positive_int(
            pack.get("framebuffer_width")
        ),
        "framebuffer_height_positive": _is_positive_int(
            pack.get("framebuffer_height")
        ),
        "screenshot_url_http": _is_final_evidence_http_url(
            pack.get("screenshot_url")
        ),
        "screenshot_sha256_available": _is_sha256_hex(
            pack.get("screenshot_sha256")
        ),
    }
    failed_checks = [name for name, passed in checks.items() if not passed]
    return {
        "available": True,
        "certified": not failed_checks,
        "evidence_id": "production_imgui_renderer_framebuffer_pack",
        "evidence_kind": "host_provided_artifact",
        "artifact_kind": pack.get("artifact_kind"),
        "source_method": "imgui_production_renderer_framebuffer_pack",
        "claim_scope": pack.get("claim_scope"),
        "required_check_count": len(checks),
        "passed_check_count": len(checks) - len(failed_checks),
        "failed_check_count": len(failed_checks),
        "failed_checks": failed_checks,
        "render_frame_count": _strict_int_or_zero(pack.get("render_frame_count")),
        "framebuffer_touched": _strict_int_or_zero(pack.get("framebuffer_touched")),
        "estimated_nonzero_pixels": _strict_int_or_zero(
            pack.get("estimated_nonzero_pixels")
        ),
        "graphics_backend_name": pack.get("graphics_backend_name"),
        "framebuffer_width": _strict_int_or_zero(pack.get("framebuffer_width")),
        "framebuffer_height": _strict_int_or_zero(pack.get("framebuffer_height")),
        "screenshot_url": pack.get("screenshot_url"),
        "screenshot_sha256": str(pack.get("screenshot_sha256") or ""),
        "real_graphics_backend_framebuffer_verified": pack.get(
            "real_graphics_backend_framebuffer_verified"
        )
        is True,
        "screenshot_verified": pack.get("screenshot_verified") is True,
        **_final_evidence_url_witness_summary(url_witness_rows),
        **_final_evidence_digest_witness_summary(digest_witness_rows),
        "completion_claimed": not failed_checks,
    }


def _full_homfly_pt_evaluation_certification_pack_evidence(
    pack: Mapping[str, Any] | None,
) -> dict:
    if not isinstance(pack, Mapping):
        return {
            "available": False,
            "certified": False,
            "missing_reason": "full HOMFLY-PT certification pack not provided",
        }
    from iroll.topology.homfly_certification import (
        canonical_json_sha256,
        full_homfly_pinned_sources,
        full_homfly_pt_evaluation_certification_report_audit,
        serialized_certification_report_bytes,
        serialized_certification_report_sha256,
    )

    embedded_report = pack.get("certification_report")
    embedded_report_available = isinstance(embedded_report, Mapping)
    embedded_report_audit = (
        full_homfly_pt_evaluation_certification_report_audit(embedded_report)
        if embedded_report_available
        else None
    )
    embedded_report_canonical_sha256 = (
        canonical_json_sha256(embedded_report)
        if embedded_report_available
        else ""
    )
    embedded_report_raw_sha256 = (
        serialized_certification_report_sha256(embedded_report)
        if embedded_report_available
        else ""
    )
    embedded_report_raw_byte_count = (
        len(serialized_certification_report_bytes(embedded_report))
        if embedded_report_available
        else 0
    )
    pinned_sources = full_homfly_pinned_sources()
    pinned_source_urls = [
        str(pinned_sources[role]["url"])
        for role in ("definition", "4_1", "L5a1", "L6a4")
    ]
    pinned_source_sha256s = [
        str(pinned_sources[role]["sha256"])
        for role in ("definition", "4_1", "L5a1", "L6a4")
    ]
    raw_published_witness = pack.get("published_report_witness")
    published_witness = (
        raw_published_witness
        if isinstance(raw_published_witness, Mapping)
        else {}
    )
    certification_report_url = pack.get("certification_report_url")
    certification_report_sha256 = pack.get("certification_report_sha256")
    published_report_witness_verified = all(
        (
            published_witness.get("title")
            == "published full HOMFLY-PT evaluation certification report",
            published_witness.get("revision_id") is None,
            published_witness.get("url") == certification_report_url,
            published_witness.get("expected_sha256")
            == certification_report_sha256,
            published_witness.get("actual_sha256")
            == certification_report_sha256,
            certification_report_sha256 == embedded_report_raw_sha256,
            pack.get("certification_report_raw_sha256")
            == embedded_report_raw_sha256,
            published_witness.get("fetched") is True,
            published_witness.get("sha256_verified") is True,
            published_witness.get("byte_count")
            == embedded_report_raw_byte_count,
            published_witness.get("error") is None,
            pack.get("published_report_json_matches_embedded") is True,
            pack.get("published_report_canonical_sha256")
            == embedded_report_canonical_sha256,
        )
    )
    external_table_source_urls = _string_sequence(
        pack.get("external_table_source_urls")
    )
    external_table_source_sha256s = _sha256_sequence(
        pack.get("external_table_source_sha256s")
    )
    url_witness_rows = [
        _final_evidence_url_witness(
            pack.get("certification_report_url"),
            field="certification_report_url",
        ),
        *[
            _final_evidence_url_witness(
                url,
                field="external_table_source_urls",
            )
            for url in external_table_source_urls
        ],
    ]
    digest_witness_rows = [
        _final_evidence_digest_witness(
            pack.get("certification_report_sha256"),
            field="certification_report_sha256",
            paired_url_field="certification_report_url",
            paired_url=pack.get("certification_report_url"),
        ),
        *_final_evidence_digest_witness_rows(
            external_table_source_sha256s,
            field="external_table_source_sha256s",
            paired_url_field="external_table_source_urls",
            paired_urls=external_table_source_urls,
        ),
    ]
    checks = {
        "artifact_schema_version": pack.get("artifact_schema_version") == 1,
        "artifact_kind": (
            pack.get("artifact_kind")
            == "full_homfly_pt_evaluation_certification_pack"
        ),
        "claim_scope": pack.get("claim_scope") == "full_homfly_pt_evaluation",
        "full_homfly_pt_evaluation_certified": (
            pack.get("full_homfly_pt_evaluation_certified") is True
        ),
        "arbitrary_signed_pd_coverage_certified": (
            pack.get("arbitrary_signed_pd_coverage_certified") is True
        ),
        "external_table_normalization_certified": (
            pack.get("external_table_normalization_certified") is True
        ),
        "skein_relation_certified": pack.get("skein_relation_certified") is True,
        "registered_fixture_regression_certified": (
            pack.get("registered_fixture_regression_certified") is True
        ),
        "counterexample_count_zero": _is_zero_int(pack.get("counterexample_count")),
        "embedded_certification_report_available": embedded_report_available,
        "embedded_certification_report_replay_certified": bool(
            embedded_report_audit is not None
            and embedded_report_audit.get("certified") is True
        ),
        "embedded_certification_report_canonical_sha256_matches": bool(
            embedded_report_available
            and pack.get("certification_report_canonical_sha256")
            == embedded_report_canonical_sha256
        ),
        "embedded_certification_report_raw_sha256_matches": bool(
            embedded_report_available
            and pack.get("certification_report_sha256")
            == embedded_report_raw_sha256
            and pack.get("certification_report_raw_sha256")
            == embedded_report_raw_sha256
        ),
        "published_certification_report_witness_verified": (
            published_report_witness_verified
        ),
        "pinned_external_table_sources_exact": (
            pack.get("external_table_source_urls") == pinned_source_urls
            and pack.get("external_table_source_sha256s")
            == pinned_source_sha256s
        ),
        "embedded_report_implementation_source_sha256_matches_pack": bool(
            embedded_report_available
            and pack.get("certification_report_implementation_source_sha256")
            == embedded_report.get("implementation_source_sha256")
            and embedded_report_audit is not None
            and embedded_report.get("implementation_source_sha256")
            == embedded_report_audit.get("implementation_source_sha256")
        ),
        "embedded_report_implementation_bundle_sha256_matches_pack": bool(
            embedded_report_available
            and pack.get("certification_report_implementation_bundle_sha256")
            == embedded_report.get("implementation_bundle_sha256")
            and embedded_report_audit is not None
            and embedded_report.get("implementation_bundle_sha256")
            == embedded_report_audit.get("implementation_bundle_sha256")
        ),
        "embedded_report_summary_counts_match_pack": bool(
            embedded_report_available
            and pack.get("certification_report_artifact_kind")
            == embedded_report.get("artifact_kind")
            and pack.get("certification_report_method")
            == embedded_report.get("method")
            and pack.get("certification_report_algorithm_scope")
            == embedded_report.get("algorithm_scope")
            and pack.get("certification_report_case_count")
            == embedded_report.get("case_count")
            and pack.get("certification_report_total_state_count")
            == embedded_report.get("total_state_count")
            and pack.get("certification_report_total_transition_count")
            == embedded_report.get("total_transition_count")
            and pack.get("certification_report_total_terminal_count")
            == embedded_report.get("total_terminal_count")
        ),
        "embedded_report_claims_match_pack": bool(
            embedded_report_available
            and published_report_witness_verified
            and pack.get("full_homfly_pt_evaluation_certified")
            is (embedded_report.get("certified") is True)
            and pack.get("arbitrary_signed_pd_coverage_certified")
            is (
                embedded_report.get("arbitrary_signed_pd_coverage_certified")
                is True
            )
            and pack.get("external_table_normalization_certified")
            is (
                embedded_report.get("external_table_normalization_certified")
                is True
            )
            and pack.get("skein_relation_certified")
            is (embedded_report.get("skein_relation_certified") is True)
            and pack.get("registered_fixture_regression_certified")
            is (
                embedded_report.get("registered_fixture_regression_certified")
                is True
            )
            and pack.get("counterexample_count")
            == embedded_report.get("counterexample_count")
        ),
        "producer_replay_audit_matches_embedded_report": bool(
            embedded_report_audit is not None
            and pack.get("certification_report_replay_audit")
            == embedded_report_audit
        ),
        "producer_checks_all_true": bool(
            isinstance(pack.get("producer_checks"), Mapping)
            and pack.get("producer_checks")
            and all(value is True for value in pack["producer_checks"].values())
            and pack.get("producer_check_count")
            == len(pack["producer_checks"])
            and pack.get("producer_failed_check_count") == 0
            and pack.get("producer_failed_checks") == []
        ),
        "certification_report_url_http": _is_final_evidence_http_url(
            pack.get("certification_report_url")
        ),
        "certification_report_url_not_external_table_source_urls": (
            not isinstance(pack.get("certification_report_url"), str)
            or pack.get("certification_report_url")
            not in external_table_source_urls
        ),
        "certification_report_sha256_available": _is_sha256_hex(
            pack.get("certification_report_sha256")
        ) and bool(
            embedded_report_available
            and pack.get("certification_report_sha256")
            == embedded_report_raw_sha256
            and pack.get("certification_report_raw_sha256")
            == embedded_report_raw_sha256
            and published_report_witness_verified
        ),
        "certification_report_sha256_not_external_table_source_sha256s": (
            not isinstance(pack.get("certification_report_sha256"), str)
            or pack.get("certification_report_sha256")
            not in external_table_source_sha256s
        ),
        "external_table_source_urls_available": bool(external_table_source_urls),
        "external_table_source_urls_items_nonempty_strings": (
            _all_nonempty_strings(pack.get("external_table_source_urls"))
        ),
        "external_table_source_urls_http": all(
            _is_final_evidence_http_url(url) for url in external_table_source_urls
        ),
        "external_table_source_urls_unique": _all_unique_strings(
            external_table_source_urls
        ),
        "external_table_source_url_filenames_unique": _url_path_filenames_unique(
            external_table_source_urls
        ),
        "external_table_source_sha256s_available": bool(
            external_table_source_sha256s
        ),
        "external_table_source_sha256s_items_nonempty_strings": (
            _all_nonempty_strings(pack.get("external_table_source_sha256s"))
        ),
        "external_table_source_sha256_count_matches_source_url_count": (
            len(external_table_source_sha256s) == len(external_table_source_urls)
        ),
        "external_table_source_sha256s_hex": all(
            _is_sha256_hex(digest) for digest in external_table_source_sha256s
        ),
        "external_table_source_sha256s_unique": _all_unique_strings(
            external_table_source_sha256s
        ),
        "external_table_source_witness_pairs_unique": (
            _external_table_source_witness_pairs_unique(
                external_table_source_urls, external_table_source_sha256s
            )
        ),
        "template_placeholder_not_true": pack.get("template_placeholder") is not True,
    }
    failed_checks = [name for name, passed in checks.items() if not passed]
    return {
        "available": True,
        "certified": not failed_checks,
        "evidence_id": "full_homfly_pt_evaluation_certification_pack",
        "evidence_kind": "certification_pack",
        "artifact_kind": pack.get("artifact_kind"),
        "source_method": "full_homfly_pt_evaluation_certification_pack",
        "claim_scope": pack.get("claim_scope"),
        "required_check_count": len(checks),
        "passed_check_count": len(checks) - len(failed_checks),
        "failed_check_count": len(failed_checks),
        "failed_checks": failed_checks,
        "arbitrary_signed_pd_coverage_certified": pack.get(
            "arbitrary_signed_pd_coverage_certified"
        )
        is True,
        "external_table_normalization_certified": pack.get(
            "external_table_normalization_certified"
        )
        is True,
        "skein_relation_certified": pack.get("skein_relation_certified") is True,
        "registered_fixture_regression_certified": pack.get(
            "registered_fixture_regression_certified"
        )
        is True,
        "counterexample_count": _strict_int_or_zero(pack.get("counterexample_count")),
        "certification_report_url": pack.get("certification_report_url"),
        "certification_report_sha256": str(
            pack.get("certification_report_sha256") or ""
        ),
        "external_table_source_urls": external_table_source_urls,
        "external_table_source_url_count": len(external_table_source_urls),
        "external_table_source_sha256s": external_table_source_sha256s,
        "external_table_source_sha256_count": len(external_table_source_sha256s),
        "external_table_source_witness_pair_signature": (
            _external_table_source_witness_pair_signature(
                external_table_source_urls, external_table_source_sha256s
            )
        ),
        "embedded_certification_report_available": embedded_report_available,
        "embedded_certification_report_canonical_sha256": (
            embedded_report_canonical_sha256
        ),
        "embedded_certification_report_raw_sha256": embedded_report_raw_sha256,
        "embedded_certification_report_raw_byte_count": (
            embedded_report_raw_byte_count
        ),
        "embedded_certification_report_audit": embedded_report_audit,
        "published_certification_report_witness_verified": (
            published_report_witness_verified
        ),
        **_final_evidence_url_witness_summary(url_witness_rows),
        **_final_evidence_digest_witness_summary(digest_witness_rows),
        "completion_claimed": not failed_checks,
    }


def _full_multivariable_alexander_normalization_certification_pack_evidence(
    pack: Mapping[str, Any] | None,
) -> dict:
    if not isinstance(pack, Mapping):
        return {
            "available": False,
            "certified": False,
            "missing_reason": (
                "full multi-variable Alexander normalization certification pack "
                "not provided"
            ),
        }
    embedded_report = pack.get("certification_report")
    embedded_report_available = isinstance(embedded_report, Mapping)
    embedded_report_audit: dict[str, Any] | None = None
    embedded_report_sha256 = ""
    embedded_report_raw_sha256 = ""
    published_report_witness_verified = False
    pinned_page_sources_match = False
    if embedded_report_available:
        from iroll.topology.alexander_certification import (
            canonical_json_sha256,
            full_alexander_pinned_sources,
            full_multivariable_alexander_normalization_certification_report_audit,
            serialized_certification_report_sha256,
        )

        embedded_report_audit = (
            full_multivariable_alexander_normalization_certification_report_audit(
                embedded_report
            )
        )
        embedded_report_sha256 = canonical_json_sha256(embedded_report)
        embedded_report_raw_sha256 = serialized_certification_report_sha256(
            embedded_report
        )
        certification_report_url = pack.get("certification_report_url")
        if _is_final_evidence_http_url(certification_report_url):
            raw_published_witness = pack.get(
                "certification_report_published_witness"
            )
            published_witness = (
                raw_published_witness
                if isinstance(raw_published_witness, Mapping)
                else {}
            )
            published_report_witness_verified = all(
                (
                    published_witness.get("title")
                    == "iroll full multivariable Alexander certification report",
                    published_witness.get("revision_id") == 0,
                    published_witness.get("url") == certification_report_url,
                    published_witness.get("expected_sha256")
                    == embedded_report_raw_sha256,
                    published_witness.get("actual_sha256")
                    == embedded_report_raw_sha256,
                    published_witness.get("fetched") is True,
                    published_witness.get("sha256_verified") is True,
                    isinstance(published_witness.get("byte_count"), int)
                    and not isinstance(published_witness.get("byte_count"), bool)
                    and published_witness.get("byte_count") > 0,
                    published_witness.get("error") is None,
                    pack.get("certification_report_published_json_matches") is True,
                    pack.get("certification_report_published_canonical_sha256")
                    == embedded_report_sha256,
                )
            )
        pinned_sources = full_alexander_pinned_sources()
        pinned_page_urls = [
            str(pinned_sources[notation]["page"]["url"])
            for notation in ("L5a1", "L6a4")
        ]
        pinned_page_sha256s = [
            str(pinned_sources[notation]["page"]["sha256"])
            for notation in ("L5a1", "L6a4")
        ]
        raw_page_witnesses = pack.get("external_table_source_witnesses")
        page_witnesses = (
            raw_page_witnesses if isinstance(raw_page_witnesses, list) else []
        )
        page_witnesses_match = len(page_witnesses) == 2 and all(
            isinstance(witness, Mapping)
            and witness.get("notation") == notation
            and witness.get("title") == pinned_sources[notation]["page"]["title"]
            and witness.get("revision_id")
            == pinned_sources[notation]["page"]["revision_id"]
            and witness.get("url") == pinned_sources[notation]["page"]["url"]
            and witness.get("expected_sha256")
            == pinned_sources[notation]["page"]["sha256"]
            and witness.get("actual_sha256")
            == pinned_sources[notation]["page"]["sha256"]
            and witness.get("fetched") is True
            and witness.get("sha256_verified") is True
            for notation, witness in zip(("L5a1", "L6a4"), page_witnesses)
        )
        pinned_page_sources_match = (
            pack.get("external_table_source_urls") == pinned_page_urls
            and pack.get("external_table_source_sha256s") == pinned_page_sha256s
            and page_witnesses_match
        )

    external_table_source_urls = _string_sequence(
        pack.get("external_table_source_urls")
    )
    external_table_source_sha256s = _sha256_sequence(
        pack.get("external_table_source_sha256s")
    )
    url_witness_rows = [
        _final_evidence_url_witness(
            pack.get("certification_report_url"),
            field="certification_report_url",
        ),
        *[
            _final_evidence_url_witness(
                url,
                field="external_table_source_urls",
            )
            for url in external_table_source_urls
        ],
    ]
    digest_witness_rows = [
        _final_evidence_digest_witness(
            pack.get("certification_report_sha256"),
            field="certification_report_sha256",
            paired_url_field="certification_report_url",
            paired_url=pack.get("certification_report_url"),
        ),
        *_final_evidence_digest_witness_rows(
            external_table_source_sha256s,
            field="external_table_source_sha256s",
            paired_url_field="external_table_source_urls",
            paired_urls=external_table_source_urls,
        ),
    ]
    checks = {
        "artifact_schema_version": pack.get("artifact_schema_version") == 1,
        "artifact_kind": (
            pack.get("artifact_kind")
            == "full_multivariable_alexander_normalization_certification_pack"
        ),
        "claim_scope": (
            pack.get("claim_scope")
            == "full_multivariable_alexander_normalization"
        ),
        "full_multivariable_alexander_normalization_certified": (
            pack.get("full_multivariable_alexander_normalization_certified") is True
        ),
        "signed_pd_wirtinger_fox_certified": (
            pack.get("signed_pd_wirtinger_fox_certified") is True
        ),
        "admissible_minor_normalization_certified": (
            pack.get("admissible_minor_normalization_certified") is True
        ),
        "all_admissible_minors_consistent": (
            pack.get("all_admissible_minors_consistent") is True
        ),
        "external_table_normalization_certified": (
            pack.get("external_table_normalization_certified") is True
        ),
        "counterexample_count_zero": _is_zero_int(pack.get("counterexample_count")),
        "embedded_certification_report_available": embedded_report_available,
        "published_certification_report_witness_verified": (
            published_report_witness_verified
        ),
        "external_table_page_sources_match_pinned_revisions": (
            pinned_page_sources_match
        ),
        "certification_report_url_http": _is_final_evidence_http_url(
            pack.get("certification_report_url")
        ),
        "certification_report_url_not_external_table_source_urls": (
            not isinstance(pack.get("certification_report_url"), str)
            or pack.get("certification_report_url")
            not in external_table_source_urls
        ),
        "certification_report_sha256_available": (
            _is_sha256_hex(pack.get("certification_report_sha256"))
            and (
                not embedded_report_available
                or pack.get("certification_report_sha256")
                == embedded_report_raw_sha256
            )
        ),
        "certification_report_sha256_not_external_table_source_sha256s": (
            not isinstance(pack.get("certification_report_sha256"), str)
            or pack.get("certification_report_sha256")
            not in external_table_source_sha256s
        ),
        "external_table_source_urls_available": bool(external_table_source_urls),
        "external_table_source_urls_items_nonempty_strings": (
            _all_nonempty_strings(pack.get("external_table_source_urls"))
        ),
        "external_table_source_urls_http": all(
            _is_final_evidence_http_url(url) for url in external_table_source_urls
        ),
        "external_table_source_urls_unique": _all_unique_strings(
            external_table_source_urls
        ),
        "external_table_source_url_filenames_unique": _url_path_filenames_unique(
            external_table_source_urls
        ),
        "external_table_source_sha256s_available": bool(
            external_table_source_sha256s
        ),
        "external_table_source_sha256s_items_nonempty_strings": (
            _all_nonempty_strings(pack.get("external_table_source_sha256s"))
        ),
        "external_table_source_sha256_count_matches_source_url_count": (
            len(external_table_source_sha256s) == len(external_table_source_urls)
        ),
        "external_table_source_sha256s_hex": all(
            _is_sha256_hex(digest) for digest in external_table_source_sha256s
        ),
        "external_table_source_sha256s_unique": _all_unique_strings(
            external_table_source_sha256s
        ),
        "external_table_source_witness_pairs_unique": (
            _external_table_source_witness_pairs_unique(
                external_table_source_urls, external_table_source_sha256s
            )
        ),
        "template_placeholder_not_true": pack.get("template_placeholder") is not True,
    }
    if embedded_report_available:
        assert embedded_report_audit is not None
        checks.update(
            {
                "embedded_certification_report_replay_certified": (
                    embedded_report_audit.get("certified") is True
                ),
                "embedded_certification_report_canonical_sha256_matches": (
                    pack.get("certification_report_canonical_sha256")
                    == embedded_report_sha256
                ),
                "embedded_certification_report_raw_sha256_matches": (
                    pack.get("certification_report_raw_sha256")
                    == embedded_report_raw_sha256
                ),
                "embedded_certification_report_claims_match_pack": all(
                    (
                        pack.get("full_multivariable_alexander_normalization_certified")
                        is bool(
                            embedded_report.get("certified") is True
                            and published_report_witness_verified
                        ),
                        pack.get("signed_pd_wirtinger_fox_certified")
                        is bool(
                            embedded_report.get("signed_pd_wirtinger_fox_certified")
                            is True
                            and published_report_witness_verified
                        ),
                        pack.get("admissible_minor_normalization_certified")
                        is bool(
                            embedded_report.get(
                                "admissible_minor_normalization_certified"
                            )
                            is True
                            and published_report_witness_verified
                        ),
                        pack.get("all_admissible_minors_consistent")
                        is bool(
                            embedded_report.get("all_admissible_minors_consistent")
                            is True
                            and published_report_witness_verified
                        ),
                        pack.get("external_table_normalization_certified")
                        is bool(
                            embedded_report.get(
                                "external_table_normalization_certified"
                            )
                            is True
                            and published_report_witness_verified
                        ),
                        pack.get("counterexample_count")
                        == embedded_report.get("counterexample_count"),
                    )
                ),
            }
        )
    failed_checks = [name for name, passed in checks.items() if not passed]
    return {
        "available": True,
        "certified": not failed_checks,
        "evidence_id": (
            "full_multivariable_alexander_normalization_certification_pack"
        ),
        "evidence_kind": "certification_pack",
        "artifact_kind": pack.get("artifact_kind"),
        "source_method": (
            "full_multivariable_alexander_normalization_certification_pack"
        ),
        "claim_scope": pack.get("claim_scope"),
        "required_check_count": len(checks),
        "passed_check_count": len(checks) - len(failed_checks),
        "failed_check_count": len(failed_checks),
        "failed_checks": failed_checks,
        "signed_pd_wirtinger_fox_certified": pack.get(
            "signed_pd_wirtinger_fox_certified"
        )
        is True,
        "admissible_minor_normalization_certified": pack.get(
            "admissible_minor_normalization_certified"
        )
        is True,
        "all_admissible_minors_consistent": pack.get(
            "all_admissible_minors_consistent"
        )
        is True,
        "external_table_normalization_certified": pack.get(
            "external_table_normalization_certified"
        )
        is True,
        "counterexample_count": _strict_int_or_zero(pack.get("counterexample_count")),
        "certification_report_url": pack.get("certification_report_url"),
        "certification_report_sha256": str(
            pack.get("certification_report_sha256") or ""
        ),
        "external_table_source_urls": external_table_source_urls,
        "external_table_source_url_count": len(external_table_source_urls),
        "external_table_source_sha256s": external_table_source_sha256s,
        "external_table_source_sha256_count": len(external_table_source_sha256s),
        "external_table_source_witness_pair_signature": (
            _external_table_source_witness_pair_signature(
                external_table_source_urls, external_table_source_sha256s
            )
        ),
        "embedded_certification_report_available": embedded_report_available,
        "embedded_certification_report_sha256": embedded_report_sha256,
        "embedded_certification_report_raw_sha256": embedded_report_raw_sha256,
        "published_certification_report_witness_verified": (
            published_report_witness_verified
        ),
        "embedded_certification_report_audit": embedded_report_audit,
        **_final_evidence_url_witness_summary(url_witness_rows),
        **_final_evidence_digest_witness_summary(digest_witness_rows),
        "completion_claimed": not failed_checks,
    }


def _verified_signed_crossing_assignment_evidence_by_notation(
    assignments: Sequence[Mapping[str, Any]] | None,
) -> dict[str, dict]:
    result: dict[str, dict] = {}
    if assignments is None:
        return result
    for assignment in assignments:
        if not isinstance(assignment, Mapping):
            continue
        notation = str(assignment.get("notation") or "")
        if not notation:
            continue
        result[notation] = _verified_signed_crossing_assignment_evidence(
            assignment
        )
    return result


def _verified_signed_crossing_assignment_evidence(
    assignment: Mapping[str, Any],
) -> dict:
    notation = str(assignment.get("notation") or "")
    signs = assignment.get("signs")
    role_orders = assignment.get("role_orders")
    invariant_table_source_urls = _string_sequence(
        assignment.get("invariant_table_source_urls")
    )
    invariant_table_source_sha256s = _sha256_sequence(
        assignment.get("invariant_table_source_sha256s")
    )
    url_witness_rows = [
        _final_evidence_url_witness(
            assignment.get("source_url"),
            field="source_url",
        ),
        *[
            _final_evidence_url_witness(
                url,
                field="invariant_table_source_urls",
            )
            for url in invariant_table_source_urls
        ],
    ]
    candidate_replay_sha256 = str(assignment.get("candidate_replay_sha256") or "")
    digest_witness_rows = [
        _final_evidence_digest_witness(
            assignment.get("candidate_replay_sha256"),
            field="candidate_replay_sha256",
        ),
        *_final_evidence_digest_witness_rows(
            invariant_table_source_sha256s,
            field="invariant_table_source_sha256s",
            paired_url_field="invariant_table_source_urls",
            paired_urls=invariant_table_source_urls,
        ),
    ]
    signs_count = len(signs) if isinstance(signs, Sequence) and not isinstance(signs, str) else 0
    role_order_count = (
        len(role_orders)
        if isinstance(role_orders, Sequence) and not isinstance(role_orders, str)
        else 0
    )
    signs_valid = (
        isinstance(signs, Sequence)
        and not isinstance(signs, (str, bytes))
        and all(_strict_int(sign) in {-1, 1} for sign in signs)
    )
    role_orders_valid = (
        isinstance(role_orders, Sequence)
        and not isinstance(role_orders, (str, bytes))
        and all(
            isinstance(role_order, Sequence)
            and not isinstance(role_order, (str, bytes))
            and all(_strict_int(role) is not None for role in role_order)
            and sorted(_strict_int(role) for role in role_order) == [0, 1, 2, 3]
            for role_order in role_orders
        )
    )
    expected_crossing_count_by_notation = {"L5a1": 5, "L6a4": 6}
    expected_crossing_count = expected_crossing_count_by_notation.get(notation)
    checks = {
        "artifact_schema_version": assignment.get("artifact_schema_version") == 1,
        "artifact_kind": (
            assignment.get("artifact_kind") == "verified_signed_crossing_assignment"
        ),
        "claim_scope": (
            assignment.get("claim_scope")
            == "verified_signed_crossing_assignment"
        ),
        "notation": notation in {"L5a1", "L6a4"},
        "source_url": bool(assignment.get("source_url")),
        "source_url_http": _is_final_evidence_http_url(
            assignment.get("source_url")
        ),
        "source_url_matches_notation": _url_mentions_notation(
            assignment.get("source_url"), notation
        ),
        "source_url_not_invariant_table_source_urls": (
            not isinstance(assignment.get("source_url"), str)
            or assignment.get("source_url") not in invariant_table_source_urls
        ),
        "crossing_count_positive": _is_positive_int(
            assignment.get("crossing_count")
        ),
        "crossing_count_matches_notation": (
            expected_crossing_count is not None
            and _strict_int(assignment.get("crossing_count"))
            == expected_crossing_count
        ),
        "signs_match_crossing_count": signs_count
        == _strict_int_or_zero(assignment.get("crossing_count")),
        "signs_are_plus_or_minus_one": signs_valid,
        "role_orders_match_crossing_count": role_order_count
        == _strict_int_or_zero(assignment.get("crossing_count")),
        "role_orders_are_four_role_permutations": role_orders_valid,
        "source_gauss_code_match": assignment.get("source_gauss_code_match") is True,
        "source_candidate_replay_valid": (
            assignment.get("source_candidate_replay_valid") is True
        ),
        "candidate_replay_sha256_available": _is_sha256_hex(
            candidate_replay_sha256
        ),
        "candidate_replay_sha256_not_invariant_table_source_sha256s": (
            not isinstance(assignment.get("candidate_replay_sha256"), str)
            or assignment.get("candidate_replay_sha256")
            not in invariant_table_source_sha256s
        ),
        "unique_assignment_certified": (
            assignment.get("unique_assignment_certified") is True
        ),
        "invariant_table_values_verified": (
            assignment.get("invariant_table_values_verified") is True
        ),
        "invariant_table_source_urls_available": bool(
            invariant_table_source_urls
        ),
        "invariant_table_source_urls_items_nonempty_strings": (
            _all_nonempty_strings(assignment.get("invariant_table_source_urls"))
        ),
        "invariant_table_source_urls_http": all(
            _is_final_evidence_http_url(url)
            for url in invariant_table_source_urls
        ),
        "invariant_table_source_urls_unique": _all_unique_strings(
            invariant_table_source_urls
        ),
        "invariant_table_source_sha256s_available": bool(
            invariant_table_source_sha256s
        ),
        "invariant_table_source_sha256s_items_nonempty_strings": (
            _all_nonempty_strings(assignment.get("invariant_table_source_sha256s"))
        ),
        "invariant_table_source_sha256_count_matches_source_url_count": (
            len(invariant_table_source_sha256s) == len(invariant_table_source_urls)
        ),
        "invariant_table_source_sha256s_hex": all(
            _is_sha256_hex(digest) for digest in invariant_table_source_sha256s
        ),
        "invariant_table_source_sha256s_unique": _all_unique_strings(
            invariant_table_source_sha256s
        ),
        "invariant_table_source_witness_pairs_unique": (
            _url_sha256_witness_pairs_unique(
                invariant_table_source_urls, invariant_table_source_sha256s
            )
        ),
        "orientation_validation_issue_count_zero": _is_zero_int(
            assignment.get("orientation_validation_issue_count")
        ),
        "template_placeholder_not_true": assignment.get("template_placeholder")
        is not True,
    }
    failed_checks = [name for name, passed in checks.items() if not passed]
    return {
        "available": True,
        "certified": not failed_checks,
        "evidence_id": "verified_signed_crossing_assignment",
        "evidence_kind": "signed_fixture_assignment_pack",
        "artifact_kind": assignment.get("artifact_kind"),
        "source_method": "verified_signed_crossing_assignment",
        "claim_scope": assignment.get("claim_scope"),
        "notation": notation,
        "source_url": assignment.get("source_url"),
        "required_check_count": len(checks),
        "passed_check_count": len(checks) - len(failed_checks),
        "failed_check_count": len(failed_checks),
        "failed_checks": failed_checks,
        "crossing_count": _strict_int_or_zero(assignment.get("crossing_count")),
        "sign_count": signs_count,
        "role_order_count": role_order_count,
        "source_gauss_code_match": assignment.get("source_gauss_code_match") is True,
        "source_candidate_replay_valid": (
            assignment.get("source_candidate_replay_valid") is True
        ),
        "candidate_replay_sha256": candidate_replay_sha256,
        "unique_assignment_certified": (
            assignment.get("unique_assignment_certified") is True
        ),
        "invariant_table_values_verified": (
            assignment.get("invariant_table_values_verified") is True
        ),
        "invariant_table_source_urls": invariant_table_source_urls,
        "invariant_table_source_url_count": len(invariant_table_source_urls),
        "invariant_table_source_sha256s": invariant_table_source_sha256s,
        "invariant_table_source_sha256_count": len(
            invariant_table_source_sha256s
        ),
        "invariant_table_source_witness_pair_signature": (
            _url_sha256_witness_pair_signature(
                invariant_table_source_urls, invariant_table_source_sha256s
            )
        ),
        **_final_evidence_url_witness_summary(url_witness_rows),
        **_final_evidence_digest_witness_summary(digest_witness_rows),
        "completion_claimed": not failed_checks,
    }


def verified_signed_crossing_assignment_audit(
    assignment: Mapping[str, Any],
) -> dict:
    """Audit one retained verified signed-crossing assignment artifact."""

    evidence = (
        _verified_signed_crossing_assignment_evidence(assignment)
        if isinstance(assignment, Mapping)
        else {
            "available": False,
            "certified": False,
            "failed_checks": ["assignment_payload_not_object"],
            "required_check_count": 1,
            "passed_check_count": 0,
            "failed_check_count": 1,
            "completion_claimed": False,
        }
    )
    return {
        "artifact_schema_version": 1,
        "artifact_kind": "verified_signed_crossing_assignment_audit",
        "claim_scope": "verified_signed_crossing_assignment_preflight",
        "source_method": "iroll verified-signed-crossing-assignment-audit",
        "assignment_available": evidence.get("available") is True,
        "assignment_certified": evidence.get("certified") is True,
        "required_check_count": evidence.get("required_check_count", 0),
        "passed_check_count": evidence.get("passed_check_count", 0),
        "failed_check_count": evidence.get("failed_check_count", 0),
        "failed_checks": list(evidence.get("failed_checks", [])),
        "assignment_evidence": evidence,
        "completion_claimed": evidence.get("certified") is True,
        "notes": [
            "preflight uses the same signed-assignment checks as the final validation-pack audit",
            "a certified preflight artifact is still input evidence, not a final completion certificate",
        ],
    }


def completion_evidence_artifact_audit(
    artifact: Mapping[str, Any],
    *,
    artifact_type: str | None = None,
) -> dict:
    """Preflight one retained artifact used by the completion-evidence bundle."""

    artifact_kind = (
        str(artifact.get("artifact_kind") or "")
        if isinstance(artifact, Mapping)
        else ""
    )
    inferred_types = {
        "verified_signed_crossing_assignment": (
            "verified_signed_crossing_assignment"
        ),
        "imgui_production_renderer_framebuffer_pack": (
            "production_imgui_renderer_framebuffer_pack"
        ),
        "signed_release_publication_manifest": (
            "signed_release_publication_manifest"
        ),
        "full_homfly_pt_evaluation_certification_pack": (
            "full_homfly_pt_evaluation_certification_pack"
        ),
        "full_multivariable_alexander_normalization_certification_pack": (
            "full_multivariable_alexander_normalization_certification_pack"
        ),
        "release_grade_high_point_performance_pack": (
            "release_grade_high_point_performance_pack"
        ),
        "broad_noisy_curve_robustness_certification_pack": (
            "broad_noisy_curve_robustness_certification_pack"
        ),
    }
    resolved_type = artifact_type or inferred_types.get(artifact_kind)
    evidence_builders = {
        "verified_signed_crossing_assignment": (
            _verified_signed_crossing_assignment_evidence
        ),
        "production_imgui_renderer_framebuffer_pack": (
            _production_imgui_renderer_framebuffer_pack_evidence
        ),
        "signed_release_publication_manifest": (
            _signed_release_publication_manifest_evidence
        ),
        "full_homfly_pt_evaluation_certification_pack": (
            _full_homfly_pt_evaluation_certification_pack_evidence
        ),
        "full_multivariable_alexander_normalization_certification_pack": (
            _full_multivariable_alexander_normalization_certification_pack_evidence
        ),
        "release_grade_high_point_performance_pack": (
            _release_grade_high_point_performance_pack_evidence
        ),
        "broad_noisy_curve_robustness_certification_pack": (
            _broad_noisy_curve_robustness_certification_pack_evidence
        ),
    }
    builder = evidence_builders.get(str(resolved_type or ""))
    required_artifact_fields = _completion_evidence_required_artifact_fields(
        str(resolved_type or "")
    )
    missing_artifact_fields = _completion_evidence_missing_artifact_fields(
        artifact,
        required_artifact_fields,
    )
    if not isinstance(artifact, Mapping):
        evidence = {
            "available": False,
            "certified": False,
            "artifact_kind": None,
            "failed_checks": ["artifact_payload_not_object"],
            "required_check_count": 1,
            "passed_check_count": 0,
            "failed_check_count": 1,
            "completion_claimed": False,
        }
    elif builder is None:
        evidence = {
            "available": True,
            "certified": False,
            "artifact_kind": artifact_kind or None,
            "failed_checks": ["unsupported_completion_evidence_artifact_type"],
            "required_check_count": 1,
            "passed_check_count": 0,
            "failed_check_count": 1,
            "completion_claimed": False,
        }
    else:
        evidence = builder(artifact)

    return {
        "artifact_schema_version": 1,
        "artifact_kind": "completion_evidence_artifact_audit",
        "claim_scope": "completion_evidence_artifact_preflight",
        "source_method": "iroll completion-evidence-artifact-audit",
        "audited_artifact_type": resolved_type,
        "audited_artifact_kind": artifact_kind or evidence.get("artifact_kind"),
        "artifact_available": evidence.get("available") is True,
        "artifact_certified": evidence.get("certified") is True,
        "required_check_count": evidence.get("required_check_count", 0),
        "passed_check_count": evidence.get("passed_check_count", 0),
        "failed_check_count": evidence.get("failed_check_count", 0),
        "failed_checks": list(evidence.get("failed_checks", [])),
        "required_artifact_field_count": len(required_artifact_fields),
        "required_artifact_fields": required_artifact_fields,
        "missing_artifact_field_count": len(missing_artifact_fields),
        "missing_artifact_fields": missing_artifact_fields,
        "artifact_field_coverage_complete": (
            bool(required_artifact_fields) and not missing_artifact_fields
        ),
        "artifact_evidence": evidence,
        "completion_claimed": evidence.get("certified") is True,
        "notes": [
            "preflight uses the same artifact checks as the final validation-pack audit",
            "a certified preflight artifact is still input evidence, not a final completion certificate",
        ],
    }


def _completion_evidence_required_artifact_fields(artifact_type: str) -> list[str]:
    required_fields_by_type = {
        "verified_signed_crossing_assignment": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "notation",
            "source_url",
            "crossing_count",
            "signs",
            "role_orders",
            "source_gauss_code_match",
            "source_candidate_replay_valid",
            "candidate_replay_sha256",
            "unique_assignment_certified",
            "invariant_table_values_verified",
            "invariant_table_source_urls",
            "invariant_table_source_sha256s",
            "orientation_validation_issue_count",
        ],
        "production_imgui_renderer_framebuffer_pack": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "passed",
            "render_frame_count",
            "framebuffer_touched",
            "estimated_nonzero_pixels",
            "real_graphics_backend_framebuffer_verified",
            "screenshot_verified",
            "graphics_backend_name",
            "framebuffer_width",
            "framebuffer_height",
            "screenshot_url",
            "screenshot_sha256",
        ],
        "signed_release_publication_manifest": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "release_version",
            "source_alignment",
            "signed_release_artifacts_published",
            "publication_claimed",
            "platform_index_publication_claimed",
            "published_artifact_count",
            "signature_count",
            "package_index_url",
            "artifact_urls",
            "artifact_sha256s",
            "signature_urls",
            "signature_sha256s",
        ],
        "full_homfly_pt_evaluation_certification_pack": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "full_homfly_pt_evaluation_certified",
            "arbitrary_signed_pd_coverage_certified",
            "external_table_normalization_certified",
            "skein_relation_certified",
            "registered_fixture_regression_certified",
            "counterexample_count",
            "certification_report_url",
            "certification_report_sha256",
            "certification_report_raw_sha256",
            "certification_report_canonical_sha256",
            "certification_report",
            "published_report_witness",
            "published_report_canonical_sha256",
            "published_report_json_matches_embedded",
            "certification_report_replay_audit",
            "certification_report_implementation_source_sha256",
            "certification_report_implementation_bundle_sha256",
            "external_table_source_urls",
            "external_table_source_sha256s",
        ],
        "full_multivariable_alexander_normalization_certification_pack": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "full_multivariable_alexander_normalization_certified",
            "signed_pd_wirtinger_fox_certified",
            "admissible_minor_normalization_certified",
            "all_admissible_minors_consistent",
            "external_table_normalization_certified",
            "counterexample_count",
            "certification_report_url",
            "certification_report_sha256",
            "external_table_source_urls",
            "external_table_source_sha256s",
        ],
        "release_grade_high_point_performance_pack": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "source_method",
            "artifact_name",
            "raw_filename",
            "raw_sha256",
            "analysis_filename",
            "analysis_sha256",
            "host_filename",
            "host_sha256",
            "point_sizes",
            "backends",
            "repeat",
            "warmup",
            "speedup_threshold",
            "minimum_repeat_for_release_claim",
            "release_grade_speedup_claimed",
            "completion_claimed",
        ],
        "broad_noisy_curve_robustness_certification_pack": [
            "artifact_schema_version",
            "artifact_kind",
            "claim_scope",
            "source_method",
            "artifact_name",
            "raw_filename",
            "raw_sha256",
            "analysis_filename",
            "analysis_sha256",
            "host_filename",
            "host_sha256",
            "representative_curve_family_count",
            "representative_curve_families",
            "report_backends",
            "completion_claimed",
        ],
    }
    return list(required_fields_by_type.get(artifact_type, []))


def _completion_evidence_missing_artifact_fields(
    artifact: Mapping[str, Any],
    required_fields: Sequence[str],
) -> list[str]:
    if not isinstance(artifact, Mapping):
        return list(required_fields)
    requirements = [
        field
        for field in required_fields
        if not _completion_evidence_field_present(artifact.get(field))
    ]
    return requirements


def _completion_evidence_field_present(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value)
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return bool(value)
    return True


def _signed_release_publication_manifest_evidence(
    manifest: Mapping[str, Any] | None,
) -> dict:
    if not isinstance(manifest, Mapping):
        return {
            "available": False,
            "certified": False,
            "missing_reason": "signed release publication manifest not provided",
        }
    artifact_urls = _string_sequence(manifest.get("artifact_urls"))
    signature_urls = _string_sequence(manifest.get("signature_urls"))
    artifact_sha256s = _sha256_sequence(manifest.get("artifact_sha256s"))
    signature_sha256s = _sha256_sequence(manifest.get("signature_sha256s"))
    release_version = manifest.get("release_version")
    source_alignment = manifest.get("source_alignment")
    if not isinstance(source_alignment, Mapping):
        source_alignment = {}
    current_source_sha256 = source_alignment.get("current_source_sha256")
    wheel_member_sha256 = source_alignment.get("wheel_member_sha256")
    sdist_member_sha256 = source_alignment.get("sdist_member_sha256")
    required_symbols = _string_sequence(source_alignment.get("required_symbols"))
    required_symbol_count = _strict_int_or_zero(
        source_alignment.get("required_symbol_count")
    )
    artifact_filenames = [_url_path_filename(url) for url in artifact_urls]
    wheel_filenames = [
        filename for filename in artifact_filenames if filename.lower().endswith(".whl")
    ]
    sdist_filenames = [
        filename
        for filename in artifact_filenames
        if filename.lower().endswith(".tar.gz")
    ]
    published_artifact_count = _strict_int_or_zero(
        manifest.get("published_artifact_count")
    )
    signature_count = _strict_int_or_zero(manifest.get("signature_count"))
    url_witness_rows = [
        _final_evidence_url_witness(
            manifest.get("package_index_url"),
            field="package_index_url",
        ),
        *[
            _final_evidence_url_witness(url, field="artifact_urls")
            for url in artifact_urls
        ],
        *[
            _final_evidence_url_witness(url, field="signature_urls")
            for url in signature_urls
        ],
    ]
    digest_witness_rows = [
        *_final_evidence_digest_witness_rows(
            artifact_sha256s,
            field="artifact_sha256s",
            paired_url_field="artifact_urls",
            paired_urls=artifact_urls,
        ),
        *_final_evidence_digest_witness_rows(
            signature_sha256s,
            field="signature_sha256s",
            paired_url_field="signature_urls",
            paired_urls=signature_urls,
        ),
    ]
    checks = {
        "artifact_schema_version": manifest.get("artifact_schema_version") == 1,
        "artifact_kind": (
            manifest.get("artifact_kind") == "signed_release_publication_manifest"
        ),
        "claim_scope": (
            manifest.get("claim_scope") == "signed_release_publication"
        ),
        "release_version_available": _is_release_version(release_version),
        "artifact_set_is_one_wheel_and_one_sdist": (
            len(artifact_filenames) == 2
            and len(wheel_filenames) == 1
            and len(sdist_filenames) == 1
        ),
        "artifact_filenames_match_release_version": (
            _release_artifact_filenames_match_version(
                artifact_filenames,
                release_version,
            )
        ),
        "source_alignment_object": isinstance(
            manifest.get("source_alignment"), Mapping
        ),
        "source_alignment_current_source_path": (
            source_alignment.get("current_source_path")
            == _SIGNED_RELEASE_SOURCE_PATH
        ),
        "source_alignment_wheel_member_path": (
            source_alignment.get("wheel_member_path")
            == _SIGNED_RELEASE_WHEEL_MEMBER_PATH
        ),
        "source_alignment_sdist_member_suffix": (
            source_alignment.get("sdist_member_suffix")
            == _SIGNED_RELEASE_SDIST_MEMBER_SUFFIX
        ),
        "source_alignment_current_source_sha256": _is_sha256_hex(
            current_source_sha256
        ),
        "source_alignment_wheel_member_sha256": _is_sha256_hex(
            wheel_member_sha256
        ),
        "source_alignment_sdist_member_sha256": _is_sha256_hex(
            sdist_member_sha256
        ),
        "source_alignment_sha256s_match": (
            _is_sha256_hex(current_source_sha256)
            and current_source_sha256 == wheel_member_sha256
            and current_source_sha256 == sdist_member_sha256
        ),
        "source_alignment_required_symbols_nonempty_unique_strings": (
            _all_nonempty_strings(source_alignment.get("required_symbols"))
            and _all_unique_strings(required_symbols)
        ),
        "source_alignment_required_symbols_include_strict_contract": (
            _SIGNED_RELEASE_REQUIRED_SOURCE_SYMBOLS.issubset(required_symbols)
        ),
        "source_alignment_required_symbol_count": (
            required_symbol_count == len(required_symbols)
            and required_symbol_count >= len(
                _SIGNED_RELEASE_REQUIRED_SOURCE_SYMBOLS
            )
        ),
        "source_alignment_current_source_contains_required_symbols": (
            source_alignment.get("current_source_contains_required_symbols")
            is True
        ),
        "source_alignment_wheel_member_contains_required_symbols": (
            source_alignment.get("wheel_member_contains_required_symbols")
            is True
        ),
        "source_alignment_sdist_member_contains_required_symbols": (
            source_alignment.get("sdist_member_contains_required_symbols")
            is True
        ),
        "source_alignment_source_sha256s_match_claimed": (
            source_alignment.get("source_sha256s_match") is True
        ),
        "source_alignment_verified": (
            source_alignment.get("source_alignment_verified") is True
        ),
        "signed_release_artifacts_published": (
            manifest.get("signed_release_artifacts_published") is True
        ),
        "publication_claimed": manifest.get("publication_claimed") is True,
        "platform_index_publication_claimed": (
            manifest.get("platform_index_publication_claimed") is True
        ),
        "published_artifact_count": (
            published_artifact_count > 0
        ),
        "signature_count": signature_count > 0,
        "signature_count_matches_published_artifact_count": (
            signature_count == published_artifact_count
        ),
        "package_index_url_available": bool(manifest.get("package_index_url")),
        "package_index_url_http": _is_final_evidence_http_url(
            manifest.get("package_index_url")
        ),
        "package_index_url_not_artifact_or_signature_url": (
            not isinstance(manifest.get("package_index_url"), str)
            or manifest.get("package_index_url")
            not in artifact_urls + signature_urls
        ),
        "artifact_urls_available": bool(artifact_urls),
        "artifact_urls_items_nonempty_strings": _all_nonempty_strings(
            manifest.get("artifact_urls")
        ),
        "artifact_url_count_matches_published_artifact_count": (
            len(artifact_urls) == published_artifact_count
        ),
        "artifact_urls_http": all(
            _is_final_evidence_http_url(url) for url in artifact_urls
        ),
        "artifact_urls_unique": _all_unique_strings(artifact_urls),
        "artifact_url_filenames_unique": _url_path_filenames_unique(artifact_urls),
        "artifact_sha256s_available": bool(artifact_sha256s),
        "artifact_sha256s_items_nonempty_strings": _all_nonempty_strings(
            manifest.get("artifact_sha256s")
        ),
        "artifact_sha256_count_matches_published_artifact_count": (
            len(artifact_sha256s) == published_artifact_count
        ),
        "artifact_sha256_count_matches_artifact_url_count": (
            len(artifact_sha256s) == len(artifact_urls)
        ),
        "artifact_sha256s_hex": all(
            _is_sha256_hex(digest) for digest in artifact_sha256s
        ),
        "artifact_sha256s_unique": _all_unique_strings(artifact_sha256s),
        "artifact_url_sha256_pairs_unique": (
            _url_sha256_witness_pairs_unique(artifact_urls, artifact_sha256s)
        ),
        "signature_urls_available": bool(signature_urls),
        "signature_urls_items_nonempty_strings": _all_nonempty_strings(
            manifest.get("signature_urls")
        ),
        "signature_url_count_matches_signature_count": (
            len(signature_urls) == signature_count
        ),
        "signature_urls_http": all(
            _is_final_evidence_http_url(url) for url in signature_urls
        ),
        "signature_urls_unique": _all_unique_strings(signature_urls),
        "signature_url_filenames_unique": _url_path_filenames_unique(signature_urls),
        "signature_url_filenames_have_signature_extension": (
            _signature_url_filenames_have_signature_extension(signature_urls)
        ),
        "artifact_urls_disjoint_from_signature_urls": (
            set(artifact_urls).isdisjoint(signature_urls)
        ),
        "signature_urls_match_artifact_url_filenames": (
            _signature_urls_match_artifact_url_filenames(
                artifact_urls,
                signature_urls,
            )
        ),
        "signature_sha256s_available": bool(signature_sha256s),
        "signature_sha256s_items_nonempty_strings": _all_nonempty_strings(
            manifest.get("signature_sha256s")
        ),
        "signature_sha256_count_matches_signature_count": (
            len(signature_sha256s) == signature_count
        ),
        "signature_sha256_count_matches_signature_url_count": (
            len(signature_sha256s) == len(signature_urls)
        ),
        "signature_sha256s_hex": all(
            _is_sha256_hex(digest) for digest in signature_sha256s
        ),
        "signature_sha256s_unique": _all_unique_strings(signature_sha256s),
        "signature_url_sha256_pairs_unique": (
            _url_sha256_witness_pairs_unique(signature_urls, signature_sha256s)
        ),
        "artifact_sha256s_disjoint_from_signature_sha256s": (
            set(artifact_sha256s).isdisjoint(signature_sha256s)
        ),
        "template_placeholder_not_true": (
            manifest.get("template_placeholder") is not True
        ),
    }
    failed_checks = [name for name, passed in checks.items() if not passed]
    return {
        "available": True,
        "certified": not failed_checks,
        "evidence_id": "signed_release_publication_manifest",
        "evidence_kind": "publication_manifest",
        "artifact_kind": manifest.get("artifact_kind"),
        "source_method": "signed_release_publication_manifest",
        "claim_scope": manifest.get("claim_scope"),
        "required_check_count": len(checks),
        "passed_check_count": len(checks) - len(failed_checks),
        "failed_check_count": len(failed_checks),
        "failed_checks": failed_checks,
        "published_artifact_count": published_artifact_count,
        "signature_count": signature_count,
        "package_index_url": manifest.get("package_index_url"),
        "release_version": release_version,
        "source_alignment": dict(source_alignment),
        "source_alignment_required_symbol_count": required_symbol_count,
        "source_alignment_required_symbols": required_symbols,
        "source_alignment_sha256": current_source_sha256,
        "artifact_urls": artifact_urls,
        "artifact_url_count": len(artifact_urls),
        "artifact_sha256s": artifact_sha256s,
        "artifact_sha256_count": len(artifact_sha256s),
        "artifact_url_sha256_pair_signature": _url_sha256_witness_pair_signature(
            artifact_urls, artifact_sha256s
        ),
        "signature_urls": signature_urls,
        "signature_url_count": len(signature_urls),
        "signature_sha256s": signature_sha256s,
        "signature_sha256_count": len(signature_sha256s),
        "signature_url_sha256_pair_signature": _url_sha256_witness_pair_signature(
            signature_urls, signature_sha256s
        ),
        "signed_release_artifacts_published": (
            manifest.get("signed_release_artifacts_published") is True
        ),
        "publication_claimed": manifest.get("publication_claimed") is True,
        "platform_index_publication_claimed": (
            manifest.get("platform_index_publication_claimed") is True
        ),
        **_final_evidence_url_witness_summary(url_witness_rows),
        **_final_evidence_digest_witness_summary(digest_witness_rows),
        "completion_claimed": not failed_checks,
    }


def _string_sequence(value: Any) -> list[str]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return []
    return [str(item) for item in value if isinstance(item, str) and item]


def _all_unique_strings(values: Sequence[str]) -> bool:
    return len(set(values)) == len(values)


def _all_nonempty_strings(value: Any) -> bool:
    return (
        isinstance(value, Sequence)
        and not isinstance(value, (str, bytes))
        and bool(value)
        and all(isinstance(item, str) and bool(item) for item in value)
    )


def _url_sha256_witness_pairs(
    urls: Sequence[str], sha256s: Sequence[str]
) -> list[str]:
    if len(urls) != len(sha256s):
        return []
    return [
        f"{url}#{digest}"
        for url, digest in zip(urls, sha256s)
        if isinstance(url, str) and url and isinstance(digest, str) and digest
    ]


def _url_sha256_witness_pairs_unique(
    urls: Sequence[str], sha256s: Sequence[str]
) -> bool:
    pairs = _url_sha256_witness_pairs(urls, sha256s)
    return bool(pairs) and len(pairs) == len(urls) and len(set(pairs)) == len(pairs)


def _url_sha256_witness_pair_signature(
    urls: Sequence[str], sha256s: Sequence[str]
) -> str:
    return "|".join(_url_sha256_witness_pairs(urls, sha256s))


def _external_table_source_witness_pairs(
    urls: Sequence[str], sha256s: Sequence[str]
) -> list[str]:
    return _url_sha256_witness_pairs(urls, sha256s)


def _external_table_source_witness_pairs_unique(
    urls: Sequence[str], sha256s: Sequence[str]
) -> bool:
    return _url_sha256_witness_pairs_unique(urls, sha256s)


def _external_table_source_witness_pair_signature(
    urls: Sequence[str], sha256s: Sequence[str]
) -> str:
    return _url_sha256_witness_pair_signature(urls, sha256s)


def _estimated_nonzero_pixels_within_framebuffer_area(
    pack: Mapping[str, Any],
) -> bool:
    nonzero_pixels = _strict_int(pack.get("estimated_nonzero_pixels"))
    framebuffer_width = _strict_int(pack.get("framebuffer_width"))
    framebuffer_height = _strict_int(pack.get("framebuffer_height"))
    if (
        nonzero_pixels is None
        or framebuffer_width is None
        or framebuffer_height is None
        or framebuffer_width <= 0
        or framebuffer_height <= 0
    ):
        return False
    return nonzero_pixels <= framebuffer_width * framebuffer_height


def _estimated_nonzero_pixels_covers_framebuffer_touched(
    pack: Mapping[str, Any],
) -> bool:
    framebuffer_touched = _strict_int(pack.get("framebuffer_touched"))
    nonzero_pixels = _strict_int(pack.get("estimated_nonzero_pixels"))
    if framebuffer_touched != 1 or nonzero_pixels is None:
        return True
    return nonzero_pixels >= framebuffer_touched


def _production_graphics_backend_name(name: Any) -> bool:
    if not isinstance(name, str) or not name.strip():
        return False
    lowered = name.strip().lower()
    blocked_terms = ("stub", "test", "mock", "dummy", "fake")
    return not any(term in lowered for term in blocked_terms)


def _strict_int(value: Any) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    return value


def _is_positive_int(value: Any) -> bool:
    numeric_value = _strict_int(value)
    return numeric_value is not None and numeric_value > 0


def _is_zero_int(value: Any) -> bool:
    numeric_value = _strict_int(value)
    return numeric_value == 0


def _strict_int_or_zero(value: Any) -> int:
    numeric_value = _strict_int(value)
    return numeric_value if numeric_value is not None else 0


def _is_sha256_hex(value: Any) -> bool:
    if not isinstance(value, str) or len(value) != 64:
        return False
    return all(char in "0123456789abcdefABCDEF" for char in value)


def _is_release_version(value: Any) -> bool:
    if not isinstance(value, str) or not value or value != value.strip():
        return False
    return all(char.isalnum() or char in ".!+_-" for char in value)


def _release_artifact_filenames_match_version(
    filenames: Sequence[str],
    release_version: Any,
) -> bool:
    if not _is_release_version(release_version) or len(filenames) != 2:
        return False
    wheel_filenames = [
        filename for filename in filenames if filename.lower().endswith(".whl")
    ]
    sdist_filenames = [
        filename for filename in filenames if filename.lower().endswith(".tar.gz")
    ]
    if len(wheel_filenames) != 1 or len(sdist_filenames) != 1:
        return False
    wheel_parts = wheel_filenames[0][:-4].split("-")
    if len(wheel_parts) < 5 or wheel_parts[1] != release_version:
        return False
    return sdist_filenames[0][:-7].endswith(f"-{release_version}")


def _url_path_filename(value: str) -> str:
    return PurePosixPath(urlparse(value).path).name


def _url_path_filenames_unique(urls: Sequence[str]) -> bool:
    filenames = [_url_path_filename(url) for url in urls]
    return bool(filenames) and all(filenames) and len(set(filenames)) == len(filenames)


def _signature_url_filenames_have_signature_extension(
    signature_urls: Sequence[str],
) -> bool:
    filenames = [_url_path_filename(url) for url in signature_urls]
    signature_suffixes = (".sig", ".asc", ".minisig")
    return bool(filenames) and all(
        filename.lower().endswith(signature_suffixes) for filename in filenames
    )


def _url_mentions_notation(url: Any, notation: str) -> bool:
    if not isinstance(url, str) or not notation:
        return False
    lowered_notation = notation.lower()
    return lowered_notation in url.lower() or lowered_notation in urlparse(url).path.lower()


def _signature_urls_match_artifact_url_filenames(
    artifact_urls: Sequence[str],
    signature_urls: Sequence[str],
) -> bool:
    if len(artifact_urls) != len(signature_urls):
        return False
    for artifact_url, signature_url in zip(artifact_urls, signature_urls):
        artifact_filename = _url_path_filename(artifact_url)
        signature_filename = _url_path_filename(signature_url)
        if not artifact_filename or not signature_filename:
            return False
        if not signature_filename.startswith(f"{artifact_filename}."):
            return False
    return True


def _sha256_sequence(value: Any) -> list[str]:
    return [item for item in _string_sequence(value) if item]


def _final_evidence_digest_witness(
    value: Any,
    *,
    field: str,
    index: int | None = None,
    paired_url_field: str | None = None,
    paired_url: Any = None,
) -> dict[str, Any]:
    digest_available = isinstance(value, str) and bool(value)
    sha256_hex_64 = _is_sha256_hex(value)
    if not digest_available:
        reason = "digest_missing"
    elif not sha256_hex_64:
        reason = "digest_not_sha256_hex_64"
    else:
        reason = "valid"
    return {
        "field": field,
        "index": index,
        "digest": value if isinstance(value, str) else None,
        "digest_available": digest_available,
        "sha256_hex_64": sha256_hex_64,
        "paired_url_field": paired_url_field,
        "paired_url": paired_url if isinstance(paired_url, str) else None,
        "valid_final_evidence_digest": sha256_hex_64,
        "failure_reason": reason,
    }


def _final_evidence_digest_witness_rows(
    values: Sequence[str],
    *,
    field: str,
    paired_url_field: str | None = None,
    paired_urls: Sequence[str] | None = None,
) -> list[dict[str, Any]]:
    paired_url_values = list(paired_urls or [])
    row_count = max(len(values), len(paired_url_values), 1)
    return [
        _final_evidence_digest_witness(
            values[index] if index < len(values) else None,
            field=field,
            index=index,
            paired_url_field=paired_url_field,
            paired_url=(
                paired_url_values[index]
                if index < len(paired_url_values)
                else None
            ),
        )
        for index in range(row_count)
    ]


def _final_evidence_digest_witness_summary(
    rows: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    invalid_rows = [
        row for row in rows if row.get("valid_final_evidence_digest") is not True
    ]
    return {
        "final_evidence_digest_witness_count": len(rows),
        "final_evidence_digest_witness_valid_count": (
            len(rows) - len(invalid_rows)
        ),
        "final_evidence_digest_witness_invalid_count": len(invalid_rows),
        "final_evidence_digest_witness_invalid_fields": sorted(
            {
                str(row.get("field"))
                for row in invalid_rows
                if row.get("field")
            }
        ),
        "final_evidence_digest_witness_invalid_reasons": sorted(
            {
                str(row.get("failure_reason"))
                for row in invalid_rows
                if row.get("failure_reason")
            }
        ),
        "final_evidence_digest_witnesses": [dict(row) for row in rows],
    }


def _is_http_url(value: Any) -> bool:
    if not isinstance(value, str) or not value:
        return False
    parsed = urlparse(value)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def _is_final_evidence_http_url(value: Any) -> bool:
    if not _is_http_url(value):
        return False
    parsed = urlparse(value)
    host = (parsed.hostname or "").lower().rstrip(".")
    placeholder_hosts = {
        "example.com",
        "example.net",
        "example.org",
        "localhost",
    }
    placeholder_suffixes = (
        ".example",
        ".invalid",
        ".localhost",
        ".test",
    )
    if host in placeholder_hosts or any(
        host.endswith(suffix) for suffix in placeholder_suffixes
    ):
        return False
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        return True
    return not (
        address.is_loopback
        or address.is_private
        or address.is_link_local
        or address.is_multicast
        or address.is_reserved
        or address.is_unspecified
    )


def _final_evidence_url_witness(value: Any, *, field: str) -> dict[str, Any]:
    parsed = urlparse(value) if isinstance(value, str) else None
    scheme = parsed.scheme.lower() if parsed is not None else None
    host = (parsed.hostname or "").lower().rstrip(".") if parsed is not None else None
    placeholder_hosts = {
        "example.com",
        "example.net",
        "example.org",
        "localhost",
    }
    placeholder_suffixes = (
        ".example",
        ".invalid",
        ".localhost",
        ".test",
    )
    placeholder_host = bool(
        host
        and (
            host in placeholder_hosts
            or any(host.endswith(suffix) for suffix in placeholder_suffixes)
        )
    )
    ip_address_kind = None
    local_or_reserved_ip_host = False
    if host:
        try:
            address = ipaddress.ip_address(host)
        except ValueError:
            address = None
        if address is not None:
            ip_address_kind = address.version
            local_or_reserved_ip_host = (
                address.is_loopback
                or address.is_private
                or address.is_link_local
                or address.is_multicast
                or address.is_reserved
                or address.is_unspecified
            )
    url_available = isinstance(value, str) and bool(value)
    http_or_https = (
        url_available
        and parsed is not None
        and scheme in {"http", "https"}
        and bool(host)
    )
    valid = bool(
        http_or_https and not placeholder_host and not local_or_reserved_ip_host
    )
    if not url_available:
        reason = "url_missing"
    elif not http_or_https:
        reason = "url_not_http_or_https"
    elif placeholder_host:
        reason = "placeholder_host"
    elif local_or_reserved_ip_host:
        reason = "local_or_reserved_ip_host"
    else:
        reason = "valid"
    return {
        "field": field,
        "url": value if isinstance(value, str) else None,
        "scheme": scheme,
        "host": host,
        "url_available": url_available,
        "http_or_https": bool(http_or_https),
        "placeholder_host": placeholder_host,
        "local_or_reserved_ip_host": local_or_reserved_ip_host,
        "ip_address_kind": ip_address_kind,
        "valid_final_evidence_url": valid,
        "failure_reason": reason,
    }


def _final_evidence_url_witness_summary(
    rows: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    invalid_rows = [
        row for row in rows if row.get("valid_final_evidence_url") is not True
    ]
    return {
        "final_evidence_url_witness_count": len(rows),
        "final_evidence_url_witness_valid_count": len(rows) - len(invalid_rows),
        "final_evidence_url_witness_invalid_count": len(invalid_rows),
        "final_evidence_url_witness_invalid_fields": sorted(
            {
                str(row.get("field"))
                for row in invalid_rows
                if row.get("field")
            }
        ),
        "final_evidence_url_witness_invalid_reasons": sorted(
            {
                str(row.get("failure_reason"))
                for row in invalid_rows
                if row.get("failure_reason")
            }
        ),
        "final_evidence_url_witnesses": [dict(row) for row in rows],
    }


def _cross_workstream_non_diagram_requirements(
    *,
    production_imgui_renderer_framebuffer_pack_evidence: Mapping[str, Any]
    | None = None,
    broad_noisy_curve_robustness_certification_pack_evidence: Mapping[
        str, Any
    ]
    | None = None,
    release_grade_high_point_performance_pack_evidence: Mapping[str, Any]
    | None = None,
) -> list[dict]:
    builtin_evidence = _cross_workstream_builtin_non_diagram_evidence()
    production_evidence = (
        production_imgui_renderer_framebuffer_pack_evidence
        if isinstance(production_imgui_renderer_framebuffer_pack_evidence, Mapping)
        else {"certified": False}
    )
    production_certified = production_evidence.get("certified") is True
    noisy_evidence = (
        broad_noisy_curve_robustness_certification_pack_evidence
        if isinstance(
            broad_noisy_curve_robustness_certification_pack_evidence,
            Mapping,
        )
        else {"certified": False, "failed_checks": ["pack_not_provided"]}
    )
    noisy_certified = noisy_evidence.get("certified") is True
    noisy_local_profiles = [
        {
            "evidence_id": "noisy_sampled_closed_curve_geometry_report_regression",
            "evidence_kind": "repository_test",
            "test": (
                "tests/test_geometry.py::"
                "test_noisy_sampled_closed_curve_keeps_finite_geometry_report"
            ),
            "claim_scope": "deterministic_noisy_curve_geometry_report_regression",
            "completion_claimed": False,
        },
        {
            "evidence_id": "noisy_sampled_curve_family_matrix_regression",
            "evidence_kind": "repository_test",
            "test": (
                "tests/test_geometry.py::"
                "test_noisy_sampled_curve_family_matrix_keeps_finite_reports"
            ),
            "claim_scope": "deterministic_noisy_curve_family_matrix_regression",
            "completion_claimed": False,
        },
    ]
    high_point_evidence = (
        release_grade_high_point_performance_pack_evidence
        if isinstance(release_grade_high_point_performance_pack_evidence, Mapping)
        else {"certified": False, "failed_checks": ["pack_not_provided"]}
    )
    high_point_certified = high_point_evidence.get("certified") is True
    high_point_local_profile = {
        "evidence_id": "numpy_benchmark_matrix_local_profiling",
        "evidence_kind": "ci_retained_artifact",
        "artifact_name": "iroll-numpy-benchmark-matrix-py${{ matrix.python-version }}",
        "artifact_files": [
            "numpy-benchmark-matrix.json",
            "numpy-benchmark-matrix-imgui-analysis.json",
            "numpy-benchmark-matrix-imgui-host.json",
        ],
        "source_method": "iroll_core_benchmark_matrix",
        "claim_scope": "local_backend_benchmark_matrix_profiling_evidence",
        "release_grade_speedup_claimed": False,
        "completion_claimed": False,
    }
    native_imgui_requirement = {
        "requirement": "native ImGui screenshot/framebuffer fixtures",
        "status": "available" if production_certified else "partial",
        "required_evidence": (
            "real graphics-backend screenshot/framebuffer verification from "
            "a production Dear ImGui host renderer"
        ),
        "current_evidence": (
            "production Dear ImGui renderer framebuffer pack is certified"
            if production_certified
            else (
                "repository test-stub framebuffer estimate artifact and retained "
                "dynamic-loader smoke evidence"
            )
        ),
        "missing_artifact": (
            None if production_certified else "production_imgui_renderer_framebuffer_pack"
        ),
        "completion_claimed": production_certified,
        "evidence": (
            "production Dear ImGui renderer screenshot/framebuffer pack is certified"
            if production_certified
            else (
                "repository test-stub framebuffer estimate artifact exists; real "
                "graphics-backend screenshot verification remains open"
            )
        ),
    }
    if production_certified:
        native_imgui_requirement.update(
            {
                "certification_artifact": (
                    "production_imgui_renderer_framebuffer_pack"
                ),
                "certification_evidence": [dict(production_evidence)],
            }
        )
    else:
        native_imgui_requirement["retained_evidence"] = [
            {
                "evidence_id": "imgui_test_stub_framebuffer_smoke_retained_pack",
                "evidence_kind": "ci_retained_artifact",
                "artifact_name": "iroll-imgui-test-stub-framebuffer-smoke-${{ matrix.os }}",
                "artifact_files": [
                    "iroll-imgui-test-stub-framebuffer-smoke.json",
                    "iroll-imgui-test-stub-framebuffer-smoke-imgui-analysis.json",
                    "iroll-imgui-test-stub-framebuffer-smoke-imgui-host.json",
                ],
                "source_method": "imgui_test_stub_framebuffer_smoke",
                "artifact_kind": "imgui_test_stub_framebuffer_smoke",
                "claim_scope": "repository_imgui_test_stub_draw_list_framebuffer_estimate",
                "real_graphics_backend_framebuffer_verified": False,
                "screenshot_verified": False,
                "completion_claimed": False,
            },
            {
                "evidence_id": "imgui_real_kernel_loader_smoke_retained_pack",
                "evidence_kind": "ci_retained_artifact",
                "artifact_name": "iroll-imgui-real-kernel-loader-smoke-${{ matrix.os }}",
                "artifact_files": [
                    "iroll-imgui-real-kernel-loader-smoke.json",
                    "iroll-imgui-real-kernel-loader-smoke-imgui-analysis.json",
                    "iroll-imgui-real-kernel-loader-smoke-imgui-host.json",
                ],
                "source_method": "imgui_real_kernel_loader_smoke",
                "artifact_kind": "imgui_real_kernel_loader_smoke",
                "claim_scope": "runtime_loader_real_rust_dynamic_library_contract",
                "real_graphics_backend_framebuffer_verified": False,
                "screenshot_verified": False,
                "completion_claimed": False,
            },
        ]
    requirements = [
        {
            "requirement": "mirror pairs",
            "status": (
                "available"
                if builtin_evidence["mirror_pairs"]["matched"]
                else "partial"
            ),
            "evidence": (
                "runtime HOMFLY mirror comparisons for 3_1 and 4_1 match the "
                "documented polynomial transform"
            ),
            "runtime_validation": builtin_evidence["mirror_pairs"],
        },
        {
            "requirement": "split links",
            "status": (
                "available"
                if builtin_evidence["split_links"]["matched"]
                else "partial"
            ),
            "evidence": (
                "runtime registry audit confirms the L0a1 zero-crossing "
                "two-component split-union fixture"
            ),
            "runtime_validation": builtin_evidence["split_links"],
        },
        {
            "requirement": "noisy sampled curves",
            "status": "available" if noisy_certified else "partial",
            "certification_artifact": "broad_noisy_curve_robustness_certification_pack",
            "required_evidence": (
                "independently retained raw noisy-curve reports, derived ImGui "
                "analysis, and host geometry JSON files with matching SHA-256 "
                "values and successful deterministic six-family recomputation"
            ),
            "current_evidence": (
                "broad noisy-curve raw/analysis/host pack passed byte, SHA-256, "
                "six-family recomputation, and curve-report/ImGui projection checks"
                if noisy_certified
                else (
                    "repository regression coverage exists, but the required "
                    "external broad noisy-curve pack is missing or failed checks: "
                    + ", ".join(
                        str(check)
                        for check in noisy_evidence.get("failed_checks", [])
                    )
                )
            ),
            "missing_artifact": (
                None
                if noisy_certified
                else "broad_noisy_curve_robustness_certification_pack"
            ),
            "evidence": (
                "broad deterministic noisy sampled-curve robustness is backed "
                "by a byte-verified raw/analysis/host retained artifact trio"
                if noisy_certified
                else (
                    "local deterministic geometry tests are retained as "
                    "non-claim evidence until the strict external pack is supplied"
                )
            ),
            "completion_claimed": noisy_certified,
            **(
                {
                    "certification_evidence": [
                        *noisy_local_profiles,
                        dict(noisy_evidence),
                    ]
                }
                if noisy_certified
                else {"retained_evidence": noisy_local_profiles}
            ),
        },
        {
            "requirement": "high-point-count performance curves",
            "status": "available" if high_point_certified else "partial",
            "certification_artifact": "release_grade_high_point_performance_pack",
            "required_evidence": (
                "independently retained raw benchmark, ImGui analysis, and ImGui "
                "host JSON files with matching SHA-256 values, consistent derived "
                "fields, and a true release-grade speedup claim"
            ),
            "current_evidence": (
                "release-grade high-point performance pack and all three external "
                "JSON files passed SHA-256, cross-layer consistency, and claim checks"
                if high_point_certified
                else (
                    "release-grade high-point performance evidence is missing or "
                    "failed checks: "
                    + ", ".join(
                        str(check)
                        for check in high_point_evidence.get("failed_checks", [])
                    )
                )
            ),
            "missing_artifact": (
                None
                if high_point_certified
                else "release_grade_high_point_performance_pack"
            ),
            "completion_claimed": high_point_certified,
            "evidence": (
                "release-grade high-point performance certification is backed by "
                "a byte-verified raw/analysis/host retained artifact trio"
                if high_point_certified
                else (
                    "local NumPy profiling is retained as non-claim comparison "
                    "evidence, but no certified external high-point artifact trio "
                    "was supplied"
                )
            ),
            **(
                {
                    "certification_evidence": [
                        high_point_local_profile,
                        dict(high_point_evidence),
                    ]
                }
                if high_point_certified
                else {"retained_evidence": [high_point_local_profile]}
            ),
        },
        {
            "requirement": "UI sample reports with geometry",
            "status": (
                "available"
                if builtin_evidence["ui_geometry_sample"]["matched"]
                else "partial"
            ),
            "evidence": (
                "runtime curve analysis and ImGui geometry projection are schema-"
                "valid and host-loadable; committed sample parity remains covered"
            ),
            "runtime_validation": builtin_evidence["ui_geometry_sample"],
        },
        native_imgui_requirement,
    ]
    metadata_by_requirement: dict[str, dict[str, Any]] = {
        "mirror pairs": {
            "construction_or_source": (
                "runtime registered 3_1 and 4_1 signed-PD HOMFLY mirror "
                "comparisons"
            ),
            "expected_invariant": (
                "each observed mirror polynomial equals the documented HOMFLY "
                "mirror transform"
            ),
            "convention_and_normalization": (
                "P_mirror(a,z)=P(a^-1,-z) under the registered iroll HOMFLY "
                "normalization"
            ),
            "numeric_tolerance": {
                "applicable": False,
                "comparison": "exact Laurent-polynomial equality",
            },
            "known_limitations": (
                "runtime completion evidence covers the registered 3_1 and 4_1 "
                "mirror fixtures, not every arbitrary diagram"
            ),
            "source_url_applicable": False,
            "source_url": None,
        },
        "split links": {
            "construction_or_source": (
                "registered in-repository L0a1 zero-crossing split-union fixture"
            ),
            "expected_invariant": (
                "two components, zero crossings, and a valid signed-PD free-circle "
                "representation"
            ),
            "convention_and_normalization": (
                "iroll PD free-circle convention with component_count=2"
            ),
            "numeric_tolerance": {
                "applicable": False,
                "comparison": "exact discrete fixture metadata",
            },
            "known_limitations": (
                "this fixture proves the registered split-union terminal case, "
                "not a general geometric split-link detector"
            ),
            "source_url_applicable": False,
            "source_url": None,
        },
        "noisy sampled curves": {
            "construction_or_source": (
                "deterministic synthetic six-family noisy closed-curve producer"
            ),
            "expected_invariant": (
                "finite schema-valid curve reports and exactly matching ImGui "
                "geometry projections for every retained family"
            ),
            "convention_and_normalization": (
                "arc-length resampling, NumPy analysis, fixed projection direction, "
                "and canonical JSON SHA-256 binding"
            ),
            "numeric_tolerance": {
                "applicable": True,
                "comparison": (
                    "finite-number checks plus deterministic exact JSON replay"
                ),
            },
            "known_limitations": (
                "synthetic deterministic noise families do not claim coverage of "
                "all acquisition hardware or arbitrary stochastic processes"
            ),
            "source_url_applicable": False,
            "source_url": None,
        },
        "high-point-count performance curves": {
            "construction_or_source": (
                "retained repeated 128-point NumPy/Rust benchmark matrix bound to "
                "the loaded Rust release binary SHA-256"
            ),
            "expected_invariant": (
                "all eight workload/backend rows complete and at least one Rust "
                "median speedup meets the 1.25x release threshold"
            ),
            "convention_and_normalization": (
                "median of three timed samples after one warmup; NumPy is the "
                "baseline; only a release-profile Rust binary may claim speedup"
            ),
            "numeric_tolerance": {
                "applicable": True,
                "median_recomputation_rel_tol": 1e-12,
                "median_recomputation_abs_tol": 1e-15,
                "speedup_threshold": 1.25,
            },
            "known_limitations": (
                "the retained result is a machine/workload-specific CPU witness "
                "and is not a hosted GPU or all-platform acceleration claim"
            ),
            "source_url_applicable": False,
            "source_url": None,
        },
        "UI sample reports with geometry": {
            "construction_or_source": (
                "runtime 24-point closed-circle curve report plus committed sample "
                "payload parity coverage"
            ),
            "expected_invariant": (
                "schema-valid report projects to one closed 24-point ImGui geometry "
                "component without scientific recomputation"
            ),
            "convention_and_normalization": (
                "fixed +Z projection direction and imgui_geometry_payload_from_report"
            ),
            "numeric_tolerance": {
                "applicable": False,
                "comparison": "exact geometry count and deterministic JSON equality",
            },
            "known_limitations": (
                "the synthetic sample validates the host payload boundary rather "
                "than production renderer styling or user interaction"
            ),
            "source_url_applicable": False,
            "source_url": None,
        },
        "native ImGui screenshot/framebuffer fixtures": {
            "construction_or_source": (
                "production Dear ImGui imgui_impl_dx11 Direct3D 11 hardware "
                "framebuffer readback and WIC PNG witness"
            ),
            "expected_invariant": (
                "a rendered frame touches the real framebuffer and its public "
                "screenshot bytes match the declared SHA-256"
            ),
            "convention_and_normalization": (
                "RGBA framebuffer dimensions/nonzero-pixel accounting with exact "
                "PNG byte hash verification"
            ),
            "numeric_tolerance": {
                "applicable": False,
                "comparison": "exact integer bounds and cryptographic byte equality",
            },
            "known_limitations": (
                "the retained production witness is Windows Direct3D 11 specific; "
                "other renderer backends remain separate integration work"
            ),
            "source_url_applicable": True,
            "source_url": (
                production_evidence.get("screenshot_url")
                if production_certified
                else None
            ),
        },
    }
    for row in requirements:
        metadata = metadata_by_requirement[row["requirement"]]
        source_url = metadata["source_url"]
        source_url_check = (
            isinstance(source_url, str)
            and urlparse(source_url).scheme in {"http", "https"}
            and bool(urlparse(source_url).netloc)
        )
        metadata_checks = {
            "construction_or_source_available": bool(
                metadata["construction_or_source"]
            ),
            "expected_invariant_available": bool(metadata["expected_invariant"]),
            "convention_and_normalization_available": bool(
                metadata["convention_and_normalization"]
            ),
            "numeric_tolerance_documented": (
                isinstance(metadata["numeric_tolerance"], Mapping)
                and bool(metadata["numeric_tolerance"])
            ),
            "known_limitations_available": bool(metadata["known_limitations"]),
            "source_url_available_when_applicable": (
                not metadata["source_url_applicable"]
                or isinstance(source_url, str)
                and bool(source_url)
            ),
            "source_url_http_or_https_when_applicable": (
                not metadata["source_url_applicable"] or source_url_check
            ),
        }
        metadata_blockers = [
            name for name, passed in metadata_checks.items() if not passed
        ]
        row["fixture_metadata"] = metadata
        row["metadata_checks"] = metadata_checks
        row["metadata_complete"] = not metadata_blockers
        row["metadata_blockers"] = metadata_blockers
        if metadata_blockers and row["status"] == "available":
            row["status"] = "partial"
    return requirements


@lru_cache(maxsize=1)
def _cross_workstream_builtin_non_diagram_evidence() -> dict[str, Any]:
    """Execute the three repository-owned non-diagram checks fail-closed."""

    mirror_checks: dict[str, bool] = {}
    mirror_rows: list[dict[str, Any]] = []
    mirror_error: str | None = None
    try:
        from iroll.topology.homfly import homfly_mirror_fixture_comparison

        for notation in ("3_1", "4_1"):
            comparison = homfly_mirror_fixture_comparison(notation)
            row = {
                "notation": notation,
                "method": comparison.get("method"),
                "skipped": comparison.get("skipped"),
                "matched": comparison.get("matched"),
                "mirror_transform_convention": comparison.get(
                    "mirror_transform_convention"
                ),
                "original_homfly": comparison.get("original_homfly"),
                "mirrored_homfly": comparison.get("mirrored_homfly"),
                "expected_mirror_homfly": comparison.get(
                    "expected_mirror_homfly"
                ),
            }
            mirror_rows.append(row)
            mirror_checks[f"{notation}_comparison_available"] = (
                row["method"] == "homfly_mirror_fixture_comparison"
                and row["skipped"] is False
            )
            mirror_checks[f"{notation}_polynomial_transform_matched"] = (
                row["matched"] is True
                and row["mirrored_homfly"] == row["expected_mirror_homfly"]
            )
    except Exception as exc:  # pragma: no cover - defensive audit boundary
        mirror_error = f"{type(exc).__name__}: {exc}"
        mirror_checks["runtime_computation_completed"] = False
    else:
        mirror_checks["runtime_computation_completed"] = True

    split_checks: dict[str, bool] = {}
    split_row: dict[str, Any] = {}
    split_error: str | None = None
    try:
        fixture = get_diagram_fixture("L0a1")
        diagram = fixture.diagram()
        split_row = {
            "notation": fixture.notation,
            "kind": fixture.kind,
            "component_count": fixture.component_count,
            "crossing_count": diagram.crossing_count,
            "diagram_component_count": diagram.component_count,
            "source": fixture.source,
            "source_url": fixture.source_url,
            "source_url_applicable": fixture.source != "iroll",
        }
        split_checks = {
            "registered_notation": fixture.notation == "L0a1",
            "link_kind": fixture.kind == "link",
            "two_components": (
                fixture.component_count == 2 and diagram.component_count == 2
            ),
            "zero_crossings": diagram.crossing_count == 0,
            "signed_pd_available": fixture.has_signed_pd,
            "source_attribution_documented": (
                bool(fixture.source)
                and (
                    bool(fixture.source_url)
                    or fixture.source == "iroll"
                )
            ),
            "runtime_computation_completed": True,
        }
    except Exception as exc:  # pragma: no cover - defensive audit boundary
        split_error = f"{type(exc).__name__}: {exc}"
        split_checks = {"runtime_computation_completed": False}

    ui_checks: dict[str, bool] = {}
    ui_row: dict[str, Any] = {}
    ui_error: str | None = None
    try:
        import numpy as np

        from iroll.core.curve import Polyline3D
        from iroll.reports import (
            imgui_geometry_payload_from_report,
            validate_report,
        )
        from iroll.topology.analyze import analyze_curve

        theta = np.linspace(0.0, 2.0 * np.pi, 25, dtype=float)[:-1]
        curve = Polyline3D(
            np.column_stack(
                (np.cos(theta), np.sin(theta), np.zeros_like(theta))
            ),
            closed=True,
            name="cross_workstream_ui_geometry_sample",
            metadata={"fixture": "cross_workstream_ui_geometry_sample"},
        )
        curve_report = analyze_curve(
            curve,
            direction=[0.0, 0.0, 1.0],
            backend="numpy",
        )
        geometry = imgui_geometry_payload_from_report(curve_report)
        validation_issues = validate_report(curve_report)
        ui_row = {
            "curve_report_version": curve_report.get("version"),
            "requested_backend": curve_report.get("runtime", {}).get(
                "requested_backend"
            ),
            "geometry_method": geometry.get("method"),
            "geometry_point_count": geometry.get("geometry_point_count"),
            "component_point_counts": geometry.get("component_point_counts"),
            "component_closed": geometry.get("component_closed"),
            "validation_issue_count": len(validation_issues),
        }
        ui_checks = {
            "curve_report_schema_valid": not validation_issues,
            "numpy_backend_used": ui_row["requested_backend"] == "numpy",
            "imgui_geometry_projection_available": (
                ui_row["geometry_method"]
                == "imgui_geometry_payload_from_report"
            ),
            "geometry_point_count_matches": (
                ui_row["geometry_point_count"] == 24
                and ui_row["component_point_counts"] == [24]
            ),
            "closed_component_preserved": ui_row["component_closed"] == [1],
            "projection_deterministic": (
                imgui_geometry_payload_from_report(curve_report) == geometry
            ),
            "runtime_computation_completed": True,
        }
    except Exception as exc:  # pragma: no cover - defensive audit boundary
        ui_error = f"{type(exc).__name__}: {exc}"
        ui_checks = {"runtime_computation_completed": False}

    def summary(
        checks: Mapping[str, bool],
        *,
        rows: Any,
        error: str | None,
        claim_scope: str,
    ) -> dict[str, Any]:
        failed = [name for name, passed in checks.items() if not passed]
        return {
            "method": "cross_workstream_builtin_non_diagram_runtime_audit",
            "claim_scope": claim_scope,
            "checks": dict(checks),
            "required_check_count": len(checks),
            "passed_check_count": len(checks) - len(failed),
            "failed_check_count": len(failed),
            "failed_checks": failed,
            "matched": not failed,
            "rows": rows,
            "error": error,
        }

    return {
        "mirror_pairs": summary(
            mirror_checks,
            rows=mirror_rows,
            error=mirror_error,
            claim_scope="registered_homfly_mirror_pair_runtime_validation",
        ),
        "split_links": summary(
            split_checks,
            rows=[split_row] if split_row else [],
            error=split_error,
            claim_scope="registered_split_link_fixture_runtime_validation",
        ),
        "ui_geometry_sample": summary(
            ui_checks,
            rows=[ui_row] if ui_row else [],
            error=ui_error,
            claim_scope="imgui_geometry_sample_runtime_validation",
        ),
    }
