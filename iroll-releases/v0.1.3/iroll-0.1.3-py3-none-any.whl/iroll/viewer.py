"""Static HTML report viewer helpers."""

from __future__ import annotations

import html
from pathlib import Path
from typing import Any

from iroll.io.report import dump_report


def render_report_html(report: dict[str, Any], *, title: str = "iroll report") -> str:
    payload = dump_report(report)
    escaped_payload = html.escape(payload)
    escaped_title = html.escape(title)
    kind = _report_kind(report)
    summary = _summary_lines(report)
    summary_html = "\n".join(
        f"<li><strong>{html.escape(key)}</strong>: {html.escape(value)}</li>"
        for key, value in summary
    )
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escaped_title}</title>
  <style>
    body {{ font-family: system-ui, sans-serif; margin: 2rem; color: #1f2937; }}
    main {{ max-width: 960px; margin: 0 auto; }}
    h1 {{ font-size: 1.8rem; }}
    .kind {{ color: #4b5563; }}
    pre {{ background: #f3f4f6; padding: 1rem; overflow: auto; border-radius: 6px; }}
    li {{ margin: 0.35rem 0; }}
  </style>
</head>
<body>
  <main>
    <h1>{escaped_title}</h1>
    <p class="kind">Report kind: {html.escape(kind)}</p>
    <ul>
      {summary_html}
    </ul>
    <pre id="report-json">{escaped_payload}</pre>
  </main>
</body>
</html>
"""


def write_report_html(
    report: dict[str, Any],
    path: str | Path,
    *,
    title: str = "iroll report",
) -> Path:
    output_path = Path(path)
    output_path.write_text(render_report_html(report, title=title), encoding="utf-8")
    return output_path


def _report_kind(report: dict[str, Any]) -> str:
    input_section = report.get("input", {})
    topology = report.get("topology", {})
    if "component_count" in input_section:
        return "link"
    if "twist" in topology:
        return "ribbon"
    return "curve"


def _summary_lines(report: dict[str, Any]) -> list[tuple[str, str]]:
    topology = report.get("topology", {})
    input_section = report.get("input", {})
    lines = [
        ("version", str(report.get("version"))),
        ("name", str(input_section.get("name"))),
    ]
    if "classification" in topology and isinstance(topology["classification"], dict):
        classification = topology["classification"]
        if "knot_type" in classification:
            lines.append(("knot_type", str(classification["knot_type"])))
        if "link_type" in classification:
            lines.append(("link_type", str(classification["link_type"])))
    if "link_type" in topology:
        lines.append(("link_type", str(topology["link_type"])))
    for key in ["writhe", "twist", "linking_estimate", "crossing_count"]:
        if key in topology:
            lines.append((key, str(topology[key])))
    return lines
