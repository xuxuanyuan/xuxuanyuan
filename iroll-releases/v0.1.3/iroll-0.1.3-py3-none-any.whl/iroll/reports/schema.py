"""Lightweight schema checks for JSON analysis reports."""

from __future__ import annotations

from dataclasses import dataclass
import json
import math
from typing import Any, Literal, Mapping

ReportKind = Literal["curve", "link", "ribbon"]


@dataclass(frozen=True)
class ReportSchemaIssue:
    path: str
    message: str

    def to_dict(self) -> dict[str, str]:
        return {
            "path": self.path,
            "message": self.message,
        }


def infer_report_kind(report: Mapping[str, Any]) -> ReportKind | None:
    input_section = report.get("input")
    topology = report.get("topology")
    if not isinstance(input_section, Mapping):
        return None
    if "components" in report or "component_count" in input_section:
        return "link"
    if "centerline" in report or (
        isinstance(topology, Mapping) and "twist" in topology
    ):
        return "ribbon"
    if "closed" in input_section and "point_count" in input_section:
        return "curve"
    return None


def validate_report(
    report: Mapping[str, Any],
    *,
    kind: ReportKind | None = None,
) -> list[ReportSchemaIssue]:
    issues: list[ReportSchemaIssue] = []
    _check_json_serializable(report, issues)
    _require_mapping(report, "$", issues)

    for key in ["input", "topology", "warnings", "runtime", "version"]:
        _require_key(report, "$", key, issues)

    _require_mapping(report.get("input"), "$.input", issues)
    _require_mapping(report.get("topology"), "$.topology", issues)
    _require_list(report.get("warnings"), "$.warnings", issues)
    _require_mapping(report.get("runtime"), "$.runtime", issues)
    _require_type(report.get("version"), "$.version", str, issues)

    inferred_kind = kind or infer_report_kind(report)
    if inferred_kind is None:
        issues.append(
            ReportSchemaIssue(
                "$",
                "could not infer report kind from input/topology fields",
            )
        )
        return issues

    if inferred_kind == "curve":
        _validate_curve_report(report, issues)
    elif inferred_kind == "link":
        _validate_link_report(report, issues)
    elif inferred_kind == "ribbon":
        _validate_ribbon_report(report, issues)
    return issues


def assert_valid_report(
    report: Mapping[str, Any],
    *,
    kind: ReportKind | None = None,
) -> None:
    issues = validate_report(report, kind=kind)
    if issues:
        detail = "; ".join(f"{issue.path}: {issue.message}" for issue in issues)
        raise ValueError(f"invalid iroll report: {detail}")


def _validate_curve_report(
    report: Mapping[str, Any],
    issues: list[ReportSchemaIssue],
) -> None:
    input_section = report.get("input")
    topology = report.get("topology")
    if not isinstance(input_section, Mapping) or not isinstance(topology, Mapping):
        return

    _require_type(input_section.get("closed"), "$.input.closed", bool, issues)
    _require_int(input_section.get("point_count"), "$.input.point_count", issues)
    _require_number(topology.get("writhe"), "$.topology.writhe", issues)
    _require_int(topology.get("crossing_count"), "$.topology.crossing_count", issues)
    _require_list(topology.get("crossings"), "$.topology.crossings", issues)
    _require_mapping(topology.get("classification"), "$.topology.classification", issues)

    classification = topology.get("classification")
    if isinstance(classification, Mapping):
        for key in ["knot_type", "method", "confidence"]:
            _require_key(classification, "$.topology.classification", key, issues)

    diagram = topology.get("diagram")
    if diagram is not None:
        _require_mapping(diagram, "$.topology.diagram", issues)
        if isinstance(diagram, Mapping):
            for key in ["crossing_count", "arc_count"]:
                _require_int(diagram.get(key), f"$.topology.diagram.{key}", issues)
            for key in ["arc_relations", "gauss_code", "pd_code"]:
                _require_list(diagram.get(key), f"$.topology.diagram.{key}", issues)


def _validate_link_report(
    report: Mapping[str, Any],
    issues: list[ReportSchemaIssue],
) -> None:
    input_section = report.get("input")
    topology = report.get("topology")
    if not isinstance(input_section, Mapping) or not isinstance(topology, Mapping):
        return

    _require_int(input_section.get("component_count"), "$.input.component_count", issues)
    _require_list(report.get("components"), "$.components", issues)
    _require_int(topology.get("crossing_count"), "$.topology.crossing_count", issues)
    _require_list(topology.get("crossings"), "$.topology.crossings", issues)
    _require_mapping(topology.get("classification"), "$.topology.classification", issues)
    _require_list(topology.get("component_reports"), "$.topology.component_reports", issues)
    _require_type(topology.get("link_type"), "$.topology.link_type", str, issues)

    matrix = topology.get("linking_matrix")
    if matrix is not None:
        _require_list(matrix, "$.topology.linking_matrix", issues)

    classification = topology.get("classification")
    if isinstance(classification, Mapping):
        for key in ["link_type", "method", "confidence", "component_count"]:
            _require_key(classification, "$.topology.classification", key, issues)


def _validate_ribbon_report(
    report: Mapping[str, Any],
    issues: list[ReportSchemaIssue],
) -> None:
    input_section = report.get("input")
    topology = report.get("topology")
    if not isinstance(input_section, Mapping) or not isinstance(topology, Mapping):
        return

    _require_type(input_section.get("closed"), "$.input.closed", bool, issues)
    _require_int(input_section.get("point_count"), "$.input.point_count", issues)
    _require_mapping(report.get("centerline"), "$.centerline", issues)
    for key in ["writhe", "twist", "linking_estimate"]:
        _require_number(topology.get(key), f"$.topology.{key}", issues)
    _require_type(topology.get("twist_method"), "$.topology.twist_method", str, issues)


def _check_json_serializable(
    report: Mapping[str, Any],
    issues: list[ReportSchemaIssue],
) -> None:
    try:
        json.dumps(report, allow_nan=False)
    except (TypeError, ValueError) as exc:
        issues.append(ReportSchemaIssue("$", f"report is not strict JSON serializable: {exc}"))


def _require_key(
    value: Mapping[str, Any],
    path: str,
    key: str,
    issues: list[ReportSchemaIssue],
) -> None:
    if key not in value:
        issues.append(ReportSchemaIssue(f"{path}.{key}", "missing required field"))


def _require_mapping(
    value: Any,
    path: str,
    issues: list[ReportSchemaIssue],
) -> None:
    if not isinstance(value, Mapping):
        issues.append(ReportSchemaIssue(path, "expected object"))


def _require_list(
    value: Any,
    path: str,
    issues: list[ReportSchemaIssue],
) -> None:
    if not isinstance(value, list):
        issues.append(ReportSchemaIssue(path, "expected list"))


def _require_type(
    value: Any,
    path: str,
    expected: type,
    issues: list[ReportSchemaIssue],
) -> None:
    if not isinstance(value, expected):
        issues.append(ReportSchemaIssue(path, f"expected {expected.__name__}"))


def _require_int(
    value: Any,
    path: str,
    issues: list[ReportSchemaIssue],
) -> None:
    if isinstance(value, bool) or not isinstance(value, int):
        issues.append(ReportSchemaIssue(path, "expected int"))


def _require_number(
    value: Any,
    path: str,
    issues: list[ReportSchemaIssue],
) -> None:
    if isinstance(value, bool) or not isinstance(value, int | float):
        issues.append(ReportSchemaIssue(path, "expected finite number"))
        return
    if not math.isfinite(float(value)):
        issues.append(ReportSchemaIssue(path, "expected finite number"))
