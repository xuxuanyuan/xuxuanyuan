﻿"""Helpers for Dear ImGui-facing report payloads."""

from __future__ import annotations

import math
from typing import Any, Iterable, Iterator, Mapping, Sequence


_CHECK_COUNT_PAIRS = (
    ("comparison_checked_count", "comparison_matched_count"),
    ("mirror_checked_count", "mirror_matched_count"),
    ("skein_checked_count", "skein_matched_count"),
    ("minor_divisibility_audit_checked_count", "minor_divisibility_audit_matched_count"),
    ("scanned_gcd_audit_checked_count", "scanned_gcd_audit_matched_count"),
)

_CERTIFICATION_KEYS = (
    "full_table_normalization_certified",
    "full_admissible_minor_normalization_certified",
    "full_invariant_certified",
    "certified",
)

_BLOCKER_SUMMARY_FIELDS = (
    ("certification_blocker_count", "certification_blockers"),
    ("homfly_completion_blocker_count", "homfly_completion_blockers"),
    (
        "admissible_minor_normalization_blocker_count",
        "admissible_minor_normalization_blockers",
    ),
    ("full_alexander_completion_blocker_count", "full_alexander_completion_blockers"),
)

_BLOCKER_SUMMARY_KEYS = tuple(
    count_key for count_key, _ in _BLOCKER_SUMMARY_FIELDS
)

_HOMFLY_BLOCKER_DETAIL_FIELDS = (
    ("certification_blocker_detail_count", "certification_blocker_details"),
    ("homfly_completion_blocker_detail_count", "homfly_completion_blocker_details"),
)

_HOMFLY_BLOCKER_DETAIL_KEYS = tuple(
    count_key for count_key, _ in _HOMFLY_BLOCKER_DETAIL_FIELDS
)

_HOMFLY_FRONTIER_WITNESS_SUMMARY_KEYS = (
    "frontier_witness_summary_count",
    "frontier_witness_summary_truncated",
    "frontier_witness_summary_reason_count",
    "frontier_witness_summary_recursive_path_prefix_count",
    "frontier_witness_summary_source_kind_count",
    "frontier_witness_summary_branch_count",
    "frontier_witness_summary_min_depth",
    "frontier_witness_summary_max_depth",
    "frontier_witness_summary_min_branch_depth",
    "frontier_witness_summary_max_branch_depth",
    "frontier_witness_summary_pressure_total_frontier_count",
    "frontier_witness_summary_pressure_visible_witness_count",
    "frontier_witness_summary_pressure_missing_frontier_count",
    "frontier_witness_summary_pressure_all_frontiers_have_visible_witness",
    "frontier_witness_summary_pressure_reason_count",
)

_HOMFLY_COMPLETION_PROVENANCE_KEYS = (
    "homfly_completion_blocker_provenance_matched",
    "homfly_completion_blocker_provenance_non_claim_matched",
    "homfly_completion_blocker_provenance_gate_pressure_matched",
    "homfly_completion_blocker_provenance_frontier_pressure_matched",
    "homfly_completion_blocker_provenance_frontier_witness_matched",
    "homfly_completion_blocker_provenance_terminal_audit_matched",
    "homfly_completion_blocker_provenance_source_field_count",
)

_HOMFLY_REDUCTION_CONTRIBUTION_KEYS = (
    "homfly_reduction_contribution_count",
    "homfly_reduction_contribution_witness_count",
    "homfly_reduction_contribution_witness_limit",
    "homfly_reduction_contribution_witness_truncated_count",
    "homfly_reduction_contribution_parsed_count",
    "homfly_reduction_contribution_unparsed_count",
    "homfly_reduction_contribution_consistency_matched_count",
    "homfly_reduction_contribution_consistency_mismatch_count",
)

_ALEXANDER_WITNESS_EVIDENCE_KEYS = (
    "failed_division_witness_count",
    "quotient_gcd_uncertainty_present",
    "quotient_polynomial_witness_count",
    "quotient_polynomial_witness_truncated",
    "normalization_class_witness_count",
)

_ALEXANDER_BLOCKER_WITNESS_SUMMARY_KEY = (
    "bounded_admissible_minor_normalization_blocker_witness_summary"
)

_ALEXANDER_BLOCKER_WITNESS_SUMMARY_KEYS = (
    "admissible_minor_normalization_blocker_reason_count",
    "admissible_minor_normalization_blocker_witness_available_count",
    "admissible_minor_normalization_blocker_missing_witness_reason_count",
    "admissible_minor_normalization_blocker_witness_source_count",
    "admissible_minor_normalization_blocker_witness_source_available_count",
    "admissible_minor_normalization_blocker_witness_source_missing_count",
)

_ALEXANDER_GATE_SUMMARY_KEY = (
    "bounded_admissible_minor_normalization_gate_summary"
)

_ALEXANDER_GATE_SUMMARY_KEYS = (
    "admissible_minor_normalization_gate_count",
    "admissible_minor_normalization_gate_passed_count",
    "admissible_minor_normalization_gate_failed_count",
    "admissible_minor_normalization_gate_summary_consistent",
    "admissible_minor_normalization_failed_gate_blocker_count",
)

_ALEXANDER_GATE_PROVENANCE_KEYS = (
    "admissible_minor_normalization_failed_gate_blocker_provenance_consistent",
    "admissible_minor_normalization_failed_gate_blocker_provenance_row_count",
    "admissible_minor_normalization_failed_gate_blocker_provenance_gate_count",
    "admissible_minor_normalization_failed_gate_blocker_provenance_attribution_count",
    "admissible_minor_normalization_failed_gate_blocker_provenance_reason_count",
    "admissible_minor_normalization_failed_gate_blocker_provenance_source_available_count",
    "admissible_minor_normalization_failed_gate_blocker_provenance_source_missing_count",
    "admissible_minor_normalization_failed_gate_blocker_provenance_missing_source_count",
    "admissible_minor_normalization_failed_gate_blocker_provenance_inconsistent_source_count",
)

_COMPACT_HOST_EVIDENCE_KEYS = (
    _HOMFLY_BLOCKER_DETAIL_KEYS
    + _HOMFLY_FRONTIER_WITNESS_SUMMARY_KEYS
    + _HOMFLY_COMPLETION_PROVENANCE_KEYS
    + _HOMFLY_REDUCTION_CONTRIBUTION_KEYS
    + _ALEXANDER_WITNESS_EVIDENCE_KEYS
    + (
        "wirtinger_fox_relation_shape_invalid_count",
        "wirtinger_fox_relation_shape_witness_count",
        "wirtinger_fox_relation_shape_count_consistency_matched_count",
        "wirtinger_fox_generator_component_coverage_complete_count",
        "wirtinger_fox_generator_component_count_row_count",
        "wirtinger_fox_generator_component_count_total",
        "wirtinger_fox_generator_component_count_consistency_matched_count",
    )
    + _ALEXANDER_BLOCKER_WITNESS_SUMMARY_KEYS
    + _ALEXANDER_GATE_SUMMARY_KEYS
    + _ALEXANDER_GATE_PROVENANCE_KEYS
)

_HOMFLY_MATURITY_PATH_COUNT_FIELD_BY_PATH = {
    "zero_crossing_unlink_terminal": (
        "bounded_homfly_maturity_path_zero_crossing_unlink_count"
    ),
    "recursive_switching_to_descending_frontier_exhausted": (
        "bounded_homfly_maturity_path_recursive_frontier_exhausted_count"
    ),
    "source_table_diagnostic_only": (
        "bounded_homfly_maturity_path_source_table_diagnostic_count"
    ),
    "not_certified": "bounded_homfly_maturity_path_not_certified_count",
}

_HOMFLY_MATURITY_PATH_CERTIFIED_VALUES = {
    "zero_crossing_unlink_terminal",
    "recursive_switching_to_descending_frontier_exhausted",
}

_HOMFLY_MATURITY_PATH_COUNT_KEYS = (
    "bounded_homfly_maturity_path_certified_count",
    "bounded_homfly_maturity_path_distinct_count",
    "bounded_homfly_maturity_path_zero_crossing_unlink_count",
    "bounded_homfly_maturity_path_recursive_frontier_exhausted_count",
    "bounded_homfly_maturity_path_source_table_diagnostic_count",
    "bounded_homfly_maturity_path_not_certified_count",
)

_HOMFLY_CASE_EVIDENCE_CONSISTENCY_COUNT_KEYS = (
    "homfly_case_evidence_consistency_available_count",
    "homfly_case_evidence_consistency_matched_count",
    "homfly_case_evidence_consistency_mismatch_count",
    "homfly_case_evidence_consistency_case_count",
    "homfly_case_evidence_consistency_checked_case_count",
    "homfly_case_evidence_consistency_missing_evidence_count",
    "homfly_case_evidence_maturity_path_counts_matched_count",
    "homfly_case_evidence_maturity_path_distinct_count_matched_count",
    "homfly_case_evidence_maturity_path_certified_count_matched_count",
)

_VALIDATION_PACK_AUDIT_COUNT_KEYS = (
    "validation_pack_audit_available_count",
    "required_diagram_fixture_count",
    "registered_required_diagram_fixture_count",
    "missing_required_diagram_fixture_count",
    "metadata_blocker_count",
    "unsigned_required_fixture_count",
    "non_diagram_requirement_count",
    "open_non_diagram_requirement_count",
    "final_completion_required_check_count",
    "final_completion_required_check_passed_count",
    "final_completion_required_check_failed_count",
    "final_completion_required_check_mismatched_count",
    "final_completion_required_check_final_ready_matched_count",
    "final_completion_required_check_all_matched_count",
    "final_completion_required_check_consistency_matched_count",
    "final_completion_required_diagram_fixture_metadata_consistency_required_count",
    "final_completion_required_diagram_fixture_metadata_consistency_registered_count",
    "final_completion_required_diagram_fixture_metadata_consistency_missing_count",
    "final_completion_required_diagram_fixture_metadata_consistency_metadata_complete_count",
    "final_completion_required_diagram_fixture_metadata_consistency_metadata_incomplete_count",
    "final_completion_required_diagram_fixture_metadata_consistency_metadata_blocker_count",
    "final_completion_required_diagram_fixture_metadata_consistency_gate_passed_count",
    "final_completion_required_diagram_fixture_metadata_consistency_gate_blocker_count",
    "final_completion_required_diagram_fixture_metadata_consistency_mismatched_count",
    "final_completion_required_diagram_fixture_metadata_consistency_matched_count",
    "validation_pack_fixture_source_url_fixture_row_count",
    "validation_pack_fixture_source_url_row_count",
    "validation_pack_fixture_source_url_external_row_count",
    "validation_pack_fixture_source_url_required_count",
    "validation_pack_fixture_source_url_http_or_https_count",
    "validation_pack_fixture_source_url_requirement_satisfied_count",
    "validation_pack_fixture_source_url_scheme_entry_count",
    "validation_pack_fixture_source_url_domain_entry_count",
    "validation_pack_fixture_source_url_scheme_count_total",
    "validation_pack_fixture_source_url_domain_count_total",
    "validation_pack_fixture_source_url_scheme_count_matched_count",
    "validation_pack_fixture_source_url_domain_count_matched_count",
    "validation_pack_fixture_source_url_http_or_https_count_matched_count",
    "validation_pack_fixture_source_url_requirement_satisfied_count_matched_count",
    "validation_pack_fixture_source_url_shape_matched_count",
    "validation_pack_fixture_known_limitations_fixture_row_count",
    "validation_pack_fixture_known_limitations_available_count",
    "validation_pack_fixture_known_limitations_unavailable_count",
    "validation_pack_fixture_known_limitations_note_count_total",
    "validation_pack_fixture_known_limitations_requirement_satisfied_count",
    "validation_pack_fixture_known_limitations_requirement_satisfied_count_matched_count",
    "validation_pack_fixture_known_limitations_unavailable_count_matched_count",
    "validation_pack_fixture_known_limitations_matched_count",
    "final_completion_signed_fixture_consistency_blocker_count",
    "final_completion_signed_fixture_consistency_final_blocker_count",
    "final_completion_signed_fixture_consistency_mismatched_count",
    "final_completion_signed_fixture_consistency_source_url_present_count",
    "final_completion_signed_fixture_consistency_unsigned_non_claim_count",
    "final_completion_signed_fixture_consistency_source_table_metadata_count",
    "final_completion_signed_fixture_consistency_missing_artifact_matched_count",
    "final_completion_signed_fixture_consistency_evidence_fields_matched_count",
    "final_completion_signed_fixture_consistency_source_candidate_evidence_available_count",
    "final_completion_signed_fixture_consistency_source_candidate_not_unique_count",
    "final_completion_signed_fixture_consistency_source_candidate_replay_all_valid_count",
    "final_completion_signed_fixture_consistency_source_candidate_matching_candidate_count_total",
    "final_completion_signed_fixture_consistency_source_candidate_unique_sign_pattern_count_total",
    "final_completion_signed_fixture_consistency_matched_count",
    "final_completion_non_diagram_requirement_consistency_requirement_count",
    "final_completion_non_diagram_requirement_consistency_open_count",
    "final_completion_non_diagram_requirement_consistency_blocker_count",
    "final_completion_non_diagram_requirement_consistency_mismatched_count",
    "final_completion_non_diagram_requirement_consistency_retained_evidence_count",
    "final_completion_non_diagram_requirement_consistency_retained_evidence_id_count",
    "final_completion_non_diagram_requirement_consistency_retained_evidence_reference_top_level_matched_count",
    "final_completion_non_diagram_requirement_consistency_retained_evidence_id_top_level_matched_count",
    "final_completion_non_diagram_requirement_consistency_missing_artifact_matched_count",
    "final_completion_non_diagram_requirement_consistency_evidence_fields_matched_count",
    "final_completion_non_diagram_requirement_consistency_retained_evidence_matched_count",
    "final_completion_non_diagram_requirement_consistency_retained_evidence_ids_matched_count",
    "final_completion_non_diagram_requirement_consistency_completion_claim_false_count",
    "final_completion_non_diagram_requirement_consistency_matched_count",
    "final_completion_gate_count",
    "final_completion_passed_gate_count",
    "final_completion_failed_gate_count",
    "final_completion_blocker_count",
    "final_completion_blocker_code_count",
    "final_completion_blocker_completion_evidence_artifact_filename_reference_count",
    "final_completion_blocker_completion_evidence_artifact_filename_unique_count",
    "final_completion_failed_gate_completion_evidence_artifact_filename_reference_count",
    "final_completion_failed_gate_completion_evidence_artifact_filename_unique_count",
    "final_completion_blocker_code_consistency_code_count",
    "final_completion_blocker_code_consistency_code_total",
    "final_completion_blocker_code_consistency_total_matched_count",
    "final_completion_blocker_code_consistency_unique_matched_count",
    "final_completion_blocker_code_consistency_signature_matched_count",
    "final_completion_blocker_code_consistency_all_have_code_count",
    "final_completion_blocker_code_consistency_matched_count",
    "final_completion_blocker_code_summary_detail_consistency_row_count",
    "final_completion_blocker_code_summary_detail_consistency_code_count",
    "final_completion_blocker_code_summary_detail_consistency_blocker_count",
    "final_completion_blocker_code_summary_detail_consistency_kind_reference_count",
    "final_completion_blocker_code_summary_detail_consistency_label_reference_count",
    "final_completion_blocker_code_summary_detail_consistency_missing_artifact_reference_count",
    "final_completion_blocker_code_summary_detail_consistency_unique_missing_artifact_count",
    "final_completion_blocker_code_summary_detail_consistency_blocker_count_matched_count",
    "final_completion_blocker_code_summary_detail_consistency_kinds_matched_count",
    "final_completion_blocker_code_summary_detail_consistency_labels_matched_count",
    "final_completion_blocker_code_summary_detail_consistency_missing_artifacts_matched_count",
    "final_completion_blocker_code_summary_detail_consistency_mismatched_count",
    "final_completion_blocker_code_summary_detail_consistency_matched_count",
    "final_completion_blocker_kind_summary_row_count",
    "final_completion_blocker_kind_summary_blocker_count",
    "final_completion_blocker_kind_signed_fixture_count",
    "final_completion_blocker_kind_non_diagram_requirement_count",
    "final_completion_blocker_kind_completion_gate_count",
    "final_completion_blocker_kind_consistency_blocker_count",
    "final_completion_blocker_kind_consistency_kind_count",
    "final_completion_blocker_kind_consistency_kind_total",
    "final_completion_blocker_kind_consistency_total_matched_count",
    "final_completion_blocker_kind_consistency_unique_matched_count",
    "final_completion_blocker_kind_all_have_kind_count",
    "final_completion_blocker_kind_summary_count_matched_count",
    "final_completion_blocker_kind_consistency_matched_count",
    "final_completion_blocker_kind_summary_detail_consistency_row_count",
    "final_completion_blocker_kind_summary_detail_consistency_kind_count",
    "final_completion_blocker_kind_summary_detail_consistency_blocker_count",
    "final_completion_blocker_kind_summary_detail_consistency_code_reference_count",
    "final_completion_blocker_kind_summary_detail_consistency_missing_artifact_reference_count",
    "final_completion_blocker_kind_summary_detail_consistency_unique_missing_artifact_count",
    "final_completion_blocker_kind_summary_detail_consistency_blocker_count_matched_count",
    "final_completion_blocker_kind_summary_detail_consistency_codes_matched_count",
    "final_completion_blocker_kind_summary_detail_consistency_missing_artifacts_matched_count",
    "final_completion_blocker_kind_summary_detail_consistency_mismatched_count",
    "final_completion_blocker_kind_summary_detail_consistency_matched_count",
    "final_completion_open_gate_blocker_summary_detail_consistency_gate_count",
    "final_completion_open_gate_blocker_summary_detail_consistency_blocker_count",
    "final_completion_open_gate_blocker_summary_detail_consistency_code_reference_count",
    "final_completion_open_gate_blocker_summary_detail_consistency_missing_artifact_reference_count",
    "final_completion_open_gate_blocker_summary_detail_consistency_unique_missing_artifact_count",
    "final_completion_open_gate_blocker_summary_detail_consistency_retained_evidence_reference_count",
    "final_completion_open_gate_blocker_summary_detail_consistency_blocker_count_matched_count",
    "final_completion_open_gate_blocker_summary_detail_consistency_codes_matched_count",
    "final_completion_open_gate_blocker_summary_detail_consistency_missing_artifacts_matched_count",
    "final_completion_open_gate_blocker_summary_detail_consistency_retained_evidence_matched_count",
    "final_completion_open_gate_blocker_summary_detail_consistency_mismatched_count",
    "final_completion_open_gate_blocker_summary_detail_consistency_matched_count",
    "retained_evidence_count",
    "retained_evidence_id_count",
    "retained_evidence_completion_claimed_count",
    "retained_evidence_release_grade_speedup_claimed_count",
    "retained_evidence_real_graphics_backend_framebuffer_verified_count",
    "retained_evidence_screenshot_verified_count",
    "retained_evidence_all_non_claimed_count",
    "retained_evidence_non_claim_consistency_entry_count",
    "retained_evidence_non_claim_consistency_evidence_id_count",
    "retained_evidence_non_claim_consistency_completion_claimed_count",
    "retained_evidence_non_claim_consistency_release_grade_speedup_claimed_count",
    "retained_evidence_non_claim_consistency_real_backend_claimed_count",
    "retained_evidence_non_claim_consistency_screenshot_verified_count",
    "retained_evidence_non_claim_consistency_all_non_claimed_count",
    "retained_evidence_non_claim_consistency_entry_top_level_matched_count",
    "retained_evidence_non_claim_consistency_id_top_level_matched_count",
    "retained_evidence_non_claim_consistency_completion_top_level_matched_count",
    "retained_evidence_non_claim_consistency_release_speedup_top_level_matched_count",
    "retained_evidence_non_claim_consistency_real_backend_top_level_matched_count",
    "retained_evidence_non_claim_consistency_screenshot_top_level_matched_count",
    "retained_evidence_non_claim_consistency_matched_count",
    "retained_evidence_artifact_file_consistency_entry_count",
    "retained_evidence_artifact_file_consistency_artifact_evidence_count",
    "retained_evidence_artifact_file_consistency_non_artifact_evidence_count",
    "retained_evidence_artifact_file_consistency_file_reference_count",
    "retained_evidence_artifact_file_consistency_unique_file_count",
    "retained_evidence_artifact_file_consistency_raw_file_count",
    "retained_evidence_artifact_file_consistency_analysis_file_count",
    "retained_evidence_artifact_file_consistency_host_file_count",
    "retained_evidence_artifact_file_consistency_complete_raw_analysis_host_group_count",
    "retained_evidence_artifact_file_consistency_incomplete_group_count",
    "retained_evidence_artifact_file_consistency_reference_count_matched_count",
    "retained_evidence_artifact_file_consistency_file_type_counts_matched_count",
    "retained_evidence_artifact_file_consistency_all_groups_complete_count",
    "retained_evidence_artifact_file_consistency_all_files_unique_count",
    "retained_evidence_artifact_file_consistency_matched_count",
    "final_completion_blocker_evidence_linked_blocker_count",
    "final_completion_blocker_evidence_unlinked_blocker_count",
    "final_completion_blocker_evidence_reference_count",
    "final_completion_blocker_evidence_reference_count_matched_count",
    "final_completion_blocker_evidence_id_count_matched_count",
    "final_completion_blocker_evidence_non_claim_matched_count",
    "final_completion_blocker_evidence_link_consistency_matched_count",
    "final_completion_blocker_evidence_machine_audit_fields_present_count",
    "final_completion_blocker_evidence_label_present_count",
    "final_completion_blocker_evidence_code_present_count",
    "final_completion_blocker_evidence_missing_artifact_present_count",
    "final_completion_blocker_evidence_required_evidence_present_count",
    "final_completion_blocker_evidence_current_evidence_present_count",
    "final_completion_blocker_evidence_link_kind_summary_detail_consistency_row_count",
    "final_completion_blocker_evidence_link_kind_summary_detail_consistency_blocker_count",
    "final_completion_blocker_evidence_link_kind_summary_detail_consistency_linked_count",
    "final_completion_blocker_evidence_link_kind_summary_detail_consistency_unlinked_count",
    "final_completion_blocker_evidence_link_kind_summary_detail_consistency_reference_count",
    "final_completion_blocker_evidence_link_kind_summary_detail_consistency_id_count",
    "final_completion_blocker_evidence_link_kind_summary_detail_consistency_non_claimed_link_count",
    "final_completion_blocker_evidence_link_kind_summary_detail_consistency_blocker_count_matched_count",
    "final_completion_blocker_evidence_link_kind_summary_detail_consistency_linked_count_matched_count",
    "final_completion_blocker_evidence_link_kind_summary_detail_consistency_unlinked_count_matched_count",
    "final_completion_blocker_evidence_link_kind_summary_detail_consistency_reference_count_matched_count",
    "final_completion_blocker_evidence_link_kind_summary_detail_consistency_ids_matched_count",
    "final_completion_blocker_evidence_link_kind_summary_detail_consistency_non_claim_matched_count",
    "final_completion_blocker_evidence_link_kind_summary_detail_consistency_mismatched_count",
    "final_completion_blocker_evidence_link_kind_summary_detail_consistency_matched_count",
    "final_completion_gate_blocker_consistency_checked_gate_count",
    "final_completion_gate_blocker_consistency_mismatched_gate_count",
    "final_completion_gate_blocker_count_matched_gate_count",
    "final_completion_gate_blocker_codes_matched_gate_count",
    "final_completion_gate_blocker_consistency_matched_count",
    "final_completion_non_claim_gate_count",
    "final_completion_non_claim_gate_top_level_false_count",
    "final_completion_non_claim_gate_check_failed_count",
    "final_completion_non_claim_gate_blocker_count",
    "final_completion_non_claim_gate_code_matched_count",
    "final_completion_non_claim_gate_missing_artifact_matched_count",
    "final_completion_non_claim_gate_matched_gate_count",
    "final_completion_non_claim_gate_all_false_count",
    "final_completion_non_claim_gate_all_blockers_present_count",
    "final_completion_non_claim_gate_consistency_matched_count",
    "final_completion_non_claim_gate_consistency_field_count",
    "final_completion_non_claim_gate_consistency_false_count",
    "final_completion_non_claim_gate_consistency_gate_count",
    "final_completion_non_claim_gate_consistency_blocker_count",
    "final_completion_non_claim_gate_consistency_missing_artifact_count",
    "final_completion_non_claim_gate_consistency_mismatched_count",
    "final_completion_completion_gate_evidence_consistency_gate_count",
    "final_completion_completion_gate_evidence_consistency_gate_check_count",
    "final_completion_completion_gate_evidence_consistency_blocker_count",
    "final_completion_completion_gate_evidence_consistency_failed_gate_count",
    "final_completion_completion_gate_evidence_consistency_top_level_false_count",
    "final_completion_completion_gate_evidence_consistency_code_matched_count",
    "final_completion_completion_gate_evidence_consistency_required_evidence_matched_count",
    "final_completion_completion_gate_evidence_consistency_current_evidence_matched_count",
    "final_completion_completion_gate_evidence_consistency_missing_artifact_matched_count",
    "final_completion_completion_gate_evidence_consistency_missing_artifact_id_matched_count",
    "final_completion_completion_gate_evidence_consistency_retained_evidence_count",
    "final_completion_completion_gate_evidence_consistency_retained_evidence_id_count",
    "final_completion_completion_gate_evidence_consistency_retained_evidence_ids_matched_count",
    "final_completion_completion_gate_evidence_consistency_mismatched_count",
    "final_completion_completion_gate_evidence_consistency_matched_count",
    "final_completion_missing_artifact_reference_count",
    "final_completion_missing_artifact_unique_count",
    "final_completion_missing_artifact_summary_row_count",
    "final_completion_missing_artifact_reference_count_matched_count",
    "final_completion_missing_artifact_summary_row_count_matched_count",
    "final_completion_missing_artifact_summary_consistency_matched_count",
    "final_completion_missing_artifact_summary_detail_consistency_row_count",
    "final_completion_missing_artifact_summary_detail_consistency_unique_count",
    "final_completion_missing_artifact_summary_detail_consistency_blocker_count",
    "final_completion_missing_artifact_summary_detail_consistency_code_reference_count",
    "final_completion_missing_artifact_summary_detail_consistency_label_reference_count",
    "final_completion_missing_artifact_summary_detail_consistency_blocker_count_matched_count",
    "final_completion_missing_artifact_summary_detail_consistency_codes_matched_count",
    "final_completion_missing_artifact_summary_detail_consistency_labels_matched_count",
    "final_completion_missing_artifact_summary_detail_consistency_mismatched_count",
    "final_completion_missing_artifact_summary_detail_consistency_matched_count",
    "final_completion_blocker_evidence_field_summary_row_count",
    "final_completion_blocker_evidence_field_missing_artifact_present_count",
    "final_completion_blocker_evidence_field_required_evidence_present_count",
    "final_completion_blocker_evidence_field_current_evidence_present_count",
    "final_completion_blocker_evidence_field_all_present_count",
    "final_completion_blocker_evidence_field_consistency_matched_count",
    "final_completion_blocker_evidence_field_summary_detail_consistency_row_count",
    "final_completion_blocker_evidence_field_summary_detail_consistency_blocker_count",
    "final_completion_blocker_evidence_field_summary_detail_consistency_missing_count",
    "final_completion_blocker_evidence_field_summary_detail_consistency_required_count",
    "final_completion_blocker_evidence_field_summary_detail_consistency_current_count",
    "final_completion_blocker_evidence_field_summary_detail_consistency_all_present_count",
    "final_completion_blocker_evidence_field_summary_detail_consistency_blocker_count_matched_count",
    "final_completion_blocker_evidence_field_summary_detail_consistency_missing_matched_count",
    "final_completion_blocker_evidence_field_summary_detail_consistency_required_matched_count",
    "final_completion_blocker_evidence_field_summary_detail_consistency_current_matched_count",
    "final_completion_blocker_evidence_field_summary_detail_consistency_all_present_matched_count",
    "final_completion_blocker_evidence_field_summary_detail_consistency_mismatched_count",
    "final_completion_blocker_evidence_field_summary_detail_consistency_matched_count",
    "required_diagram_fixture_metadata_complete_count",
    "signed_diagram_fixture_registration_complete_count",
    "final_completion_ready_count",
    "full_homfly_pt_evaluation_certified_count",
    "full_multivariable_alexander_normalization_certified_count",
    "production_imgui_renderer_verified_count",
    "release_artifacts_published_count",
)

_ALEXANDER_MATURITY_PATH_COUNT_FIELD_BY_PATH = {
    "zero_crossing_unlink_terminal": (
        "bounded_alexander_maturity_path_zero_crossing_unlink_count"
    ),
    "exact_scanned_gcd": "bounded_alexander_maturity_path_exact_scanned_gcd_count",
    "laurent_unit_normalization_consensus": (
        "bounded_alexander_maturity_path_laurent_unit_normalization_consensus_count"
    ),
    "general_gcd_without_unit_normalization_consensus": (
        "bounded_alexander_maturity_path_general_gcd_without_unit_normalization_consensus_count"
    ),
    "source_table_diagnostic_only": (
        "bounded_alexander_maturity_path_source_table_diagnostic_count"
    ),
    "not_certified": "bounded_alexander_maturity_path_not_certified_count",
}

_ALEXANDER_MATURITY_PATH_CERTIFIED_VALUES = {
    "zero_crossing_unlink_terminal",
    "exact_scanned_gcd",
    "laurent_unit_normalization_consensus",
    "general_gcd_without_unit_normalization_consensus",
}

_ALEXANDER_MATURITY_PATH_COUNT_KEYS = (
    "bounded_alexander_maturity_path_certified_count",
    "bounded_alexander_maturity_path_distinct_count",
    "bounded_alexander_maturity_path_zero_crossing_unlink_count",
    "bounded_alexander_maturity_path_exact_scanned_gcd_count",
    "bounded_alexander_maturity_path_laurent_unit_normalization_consensus_count",
    (
        "bounded_alexander_maturity_path_"
        "general_gcd_without_unit_normalization_consensus_count"
    ),
    "bounded_alexander_maturity_path_source_table_diagnostic_count",
    "bounded_alexander_maturity_path_not_certified_count",
)

_ANALYSIS_CERTIFICATION_EVIDENCE_KEYS = (
    "input_certification_recursion_node_count",
    "input_certification_terminal_reduction_count",
    "input_certification_frontier_count",
    "input_certification_frontier_reason_count",
    "input_certification_truncated_count",
    "input_certification_zero_crossing_count",
    "input_certification_iterative_attempt_count",
    "input_certification_iterative_solved_count",
    "input_certification_iterative_max_solved_depth",
    "input_certification_terminal_contribution_audit_applicable_count",
    "input_certification_terminal_contribution_matched_count",
    "input_certification_terminal_contribution_failed_count",
    *_HOMFLY_MATURITY_PATH_COUNT_KEYS,
    *_HOMFLY_CASE_EVIDENCE_CONSISTENCY_COUNT_KEYS,
    *_ALEXANDER_MATURITY_PATH_COUNT_KEYS,
    "bounded_scanned_gcd_checked_nonzero_minor_count",
    "bounded_scanned_gcd_failed_nonzero_minor_count",
    "bounded_scanned_gcd_scanned_minor_count",
    "bounded_scanned_gcd_division_record_count",
    "bounded_scanned_gcd_expected_minor_combination_count",
    "bounded_scanned_gcd_nonzero_minor_count",
    "bounded_scanned_gcd_zero_minor_count",
    "bounded_scanned_gcd_unit_minor_count",
    "bounded_scanned_gcd_unique_nonzero_polynomial_count",
    "bounded_scanned_gcd_all_rows_have_nonzero_minor_count",
    "bounded_scanned_gcd_all_columns_have_nonzero_minor_count",
    "bounded_scanned_gcd_complete_scan_count",
    "bounded_scanned_gcd_nonzero_minor_coverage_complete_count",
    "bounded_scanned_gcd_truncated_count",
    "bounded_scanned_gcd_quotient_gcd_certified_count",
    "bounded_scanned_gcd_complete_certified_count",
    "bounded_scanned_gcd_improved_candidate_count",
    "registered_knot_admissible_normalization_applicable_count",
    "registered_knot_admissible_normalization_certified_count",
    "registered_knot_admissible_normalization_uncertified_count",
    "admissible_minor_normalization_checked_nonzero_minor_count",
    "admissible_minor_normalization_failed_nonzero_minor_count",
    "admissible_minor_normalization_all_equivalent_count",
    "admissible_minor_normalization_bounded_certified_count",
    "admissible_minor_normalization_complete_scan_count",
    "admissible_minor_normalization_nonzero_minor_coverage_complete_count",
    "admissible_minor_normalization_truncated_count",
    "admissible_minor_normalization_class_count",
    "admissible_minor_normalization_largest_class_minor_count",
    "admissible_minor_normalization_representative_class_minor_count",
    "admissible_minor_normalization_nonrepresentative_class_count",
    "source_table_alexander_numerator_checked_count",
    "source_table_alexander_numerator_source_seen_count",
    "source_table_alexander_numerator_complete_match_count",
    "source_table_alexander_numerator_returned_match_count",
    "source_table_alexander_numerator_incomplete_or_unstable_count",
    "source_table_alexander_numerator_candidate_unique_value_count",
    "source_table_alexander_numerator_computed_candidate_count",
    "source_table_alexander_numerator_skipped_candidate_count",
    "source_table_alexander_numerator_missing_candidate_count",
    "source_table_alexander_numerator_link_normalization_checked_count",
    "source_table_alexander_numerator_link_normalization_ready_count",
    "source_table_alexander_numerator_link_normalization_blocked_count",
    "source_table_alexander_numerator_link_normalization_blocker_count",
    "source_table_alexander_skipped_common_gcd_attempt_candidate_count",
    "source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count",
    "source_table_alexander_skipped_common_gcd_attempt_method_count",
    "source_table_alexander_skipped_common_gcd_attempt_limit_variant_count",
    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count",
    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_min",
    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_max",
    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_divides_all_candidate_count_min",
    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_divides_all_candidate_count_max",
    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_min",
    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max",
    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed_count",
    "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count",
    "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count",
    "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min",
    "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max",
    "source_table_alexander_source_divisibility_checked_candidate_count",
    "source_table_alexander_source_divisibility_source_divides_all_candidate_count",
    "source_table_alexander_source_divisibility_source_division_failed_candidate_count",
    "source_table_alexander_source_divisibility_status_variant_count",
    "source_table_alexander_source_divisibility_failed_candidate_witness_count",
    "source_table_alexander_source_divisibility_failed_candidate_witness_truncated",
    "wirtinger_fox_relation_count",
    "wirtinger_fox_generator_count",
    "wirtinger_fox_scanned_minor_count",
    "wirtinger_fox_invalid_minor_reference_count",
    "wirtinger_fox_invalid_normalization_count",
    "wirtinger_fox_complete_scan_count",
    "wirtinger_fox_truncated_count",
    "wirtinger_fox_relation_shape_invalid_count",
    "wirtinger_fox_relation_shape_witness_count",
    "wirtinger_fox_relation_shape_count_consistency_matched_count",
    "wirtinger_fox_generator_component_coverage_complete_count",
    "wirtinger_fox_generator_component_count_row_count",
    "wirtinger_fox_generator_component_count_total",
    "wirtinger_fox_generator_component_count_consistency_matched_count",
)

_ALEXANDER_MATURITY_PATH_SUMMARY_CONSISTENCY_COUNT_KEYS = (
    "bounded_alexander_maturity_path_summary_consistency_available_count",
    "bounded_alexander_maturity_path_summary_consistency_matched_count",
    "bounded_alexander_maturity_path_summary_consistency_mismatch_count",
    "bounded_alexander_maturity_path_summary_consistency_record_count",
    "bounded_alexander_maturity_path_summary_consistency_path_count_total",
    "bounded_alexander_maturity_path_summary_consistency_reported_path_count_total",
    "bounded_alexander_maturity_path_summary_consistency_path_count_row_count",
    "bounded_alexander_maturity_path_summary_consistency_certified_count",
    "bounded_alexander_maturity_path_summary_consistency_certified_path_count",
)

_ANALYSIS_ROLE_ORDER_SIGNATURE_KEYS = (
    "role_order_signature_strict_candidate_count",
    "role_order_signature_all_strict_candidates_evaluated_count",
    "role_order_signature_evaluated_candidate_count",
    "role_order_signature_skipped_candidate_count",
    "role_order_signature_group_count",
    "role_order_signature_homfly_group_count",
    "role_order_signature_alexander_group_count",
    "role_order_signature_homfly_certified_candidate_count",
    "role_order_signature_homfly_frontier_count",
    "role_order_signature_homfly_frontier_reason_count",
    "role_order_signature_homfly_truncated_candidate_count",
    "role_order_signature_alexander_bounded_scanned_gcd_certified_candidate_count",
    "role_order_signature_alexander_complete_scanned_gcd_certified_candidate_count",
    "role_order_signature_alexander_quotient_gcd_certified_candidate_count",
    "role_order_signature_alexander_failed_nonzero_minor_count",
    "role_order_signature_alexander_truncated_candidate_count",
)

_ANALYSIS_SOURCE_TABLE_AUDIT_KEYS = (
    "source_table_audit_comparison_count",
    "source_table_audit_source_match_resolution_status_count",
    "source_table_audit_matched_invariant_count",
    "source_table_audit_mismatched_invariant_count",
    "source_table_audit_uncomputed_invariant_count",
    "source_table_audit_unstable_invariant_count",
    "source_table_audit_candidate_count",
    "source_table_audit_unique_sign_pattern_count",
    "source_table_audit_computed_source_compatible_candidate_count",
    "source_table_audit_computed_source_compatible_unique_sign_pattern_count",
    "source_table_audit_complete_source_compatible_candidate_count",
    "source_table_audit_complete_source_compatible_unique_sign_pattern_count",
    "source_table_audit_top_candidate_count",
    "source_table_audit_top_unique_sign_pattern_count",
    "source_table_audit_max_matched_source_value_count",
    "source_table_audit_max_matched_candidate_total_count",
    "source_table_audit_max_matched_candidate_total_unique_sign_pattern_count",
    "source_table_audit_max_matched_candidate_count",
    "source_table_audit_max_matched_unique_sign_pattern_count",
    "source_table_audit_homfly_source_variant_count",
    "source_table_audit_homfly_source_variant_seen_count",
    "source_table_audit_homfly_source_variant_miss_count",
    "source_table_audit_homfly_source_unit_normalized_variant_count",
    "source_table_audit_homfly_source_unit_normalized_variant_seen_count",
    "source_table_audit_homfly_source_unit_normalized_variant_miss_count",
    "source_table_audit_homfly_candidate_unique_value_count",
    "source_table_audit_homfly_candidate_unit_normalized_value_count",
    "source_table_audit_homfly_variant_miss_witness_count",
    "source_table_audit_homfly_variant_miss_witness_limit",
    "source_table_audit_homfly_variant_miss_witness_truncated",
    "source_table_audit_candidate_convergence_partial_certified_count",
    "source_table_audit_candidate_convergence_full_certified_count",
    "source_table_audit_candidate_convergence_certified_invariant_count",
    "source_table_audit_candidate_convergence_uncertified_invariant_count",
    "source_table_audit_candidate_convergence_source_value_seen_count",
    "source_table_audit_candidate_convergence_source_value_seen_but_uncertified_count",
    "source_table_audit_registration_ready_count",
    "source_table_audit_registration_blocked_count",
    "source_table_audit_registration_blocker_count",
    "source_table_audit_registration_blocker_code_count",
    "source_table_audit_registration_summary_consistency_available_count",
    "source_table_audit_registration_summary_consistency_matched_count",
    "source_table_audit_registration_summary_consistency_mismatch_count",
)

_ANALYSIS_SOURCE_CANDIDATE_REPLAY_SUMMARY_KEYS = (
    "source_candidate_replay_summary_checked_candidate_count",
    "source_candidate_replay_summary_valid_replay_count",
    "source_candidate_replay_summary_invalid_replay_count",
    "source_candidate_replay_summary_missing_replay_count",
    "source_candidate_replay_summary_invalid_claim_scope_count",
    "source_candidate_replay_summary_source_notation_mismatch_count",
    "source_candidate_replay_summary_sign_mismatch_count",
    "source_candidate_replay_summary_role_order_mismatch_count",
    "source_candidate_replay_summary_pairwise_linking_mismatch_count",
    "source_candidate_replay_summary_orientation_issue_count",
    "source_candidate_replay_summary_missing_diagram_or_orientation_count",
    "source_candidate_replay_summary_all_valid_count",
)

_ANALYSIS_BENCHMARK_MATRIX_KEYS = (
    "benchmark_matrix_expected_row_count",
    "benchmark_matrix_row_count",
    "benchmark_matrix_completed_row_count",
    "benchmark_matrix_skipped_row_count",
    "benchmark_matrix_failed_row_count",
    "benchmark_matrix_backend_count",
    "benchmark_matrix_workload_count",
    "benchmark_speedup_candidate_count",
    "benchmark_speedup_threshold_candidate_count",
    "benchmark_speedup_completed_comparison_count",
    "benchmark_speedup_missing_baseline_count",
    "benchmark_speedup_release_grade_claimed_count",
    "benchmark_cuda_gpu_requested_row_count",
    "benchmark_cuda_gpu_completed_row_count",
    "benchmark_cuda_gpu_skipped_row_count",
    "benchmark_cuda_gpu_failed_row_count",
    "benchmark_cuda_gpu_threshold_candidate_count",
    "benchmark_cuda_gpu_blocking_reason_count",
    "benchmark_cuda_gpu_runtime_observed_count",
    "benchmark_cuda_gpu_hosted_cuda_ci_claimed_count",
    "benchmark_cuda_gpu_parity_claimed_count",
    "benchmark_cuda_gpu_release_grade_speedup_claimed_count",
)

_ANALYSIS_GPU_SMOKE_KEYS = (
    "gpu_smoke_parity_result_count",
    "gpu_smoke_unavailable_boundary_count",
    "gpu_smoke_parity_failure_count",
    "gpu_smoke_required_capability_count",
    "gpu_smoke_required_capability_name_count",
    "gpu_smoke_parity_check_count",
    "gpu_smoke_passed_check_count",
    "gpu_smoke_failed_check_count",
    "gpu_smoke_failed_check_name_count",
    "gpu_smoke_blocking_reason_count",
    "gpu_smoke_backend_available_count",
    "gpu_smoke_runtime_observed_count",
    "gpu_smoke_gate_passed_count",
    "gpu_smoke_release_gate_gpu_backend_unavailable_blocker_count",
    "gpu_smoke_release_gate_cuda_runtime_not_observed_blocker_count",
    "gpu_smoke_release_gate_required_checks_incomplete_blocker_count",
    "gpu_smoke_release_gate_required_checks_failed_blocker_count",
    "gpu_smoke_release_gate_forced_unavailable_blocker_count",
    "gpu_smoke_release_gate_simulated_parity_failure_blocker_count",
    "gpu_smoke_dispatch_parity_claimed_count",
    "gpu_smoke_no_cuda_boundary_count",
    "gpu_smoke_simulated_parity_failure_count",
    "gpu_smoke_cuda_parity_claimed_count",
    "gpu_smoke_release_grade_speedup_claimed_count",
)

_ANALYSIS_IMGUI_FRAMEBUFFER_SMOKE_KEYS = (
    "imgui_framebuffer_smoke_artifact_count",
    "imgui_framebuffer_smoke_passed_count",
    "imgui_framebuffer_smoke_real_backend_verified_count",
    "imgui_framebuffer_smoke_screenshot_verified_count",
    "imgui_framebuffer_smoke_framebuffer_touched_count",
    "imgui_framebuffer_smoke_estimated_nonzero_pixel_count",
    "imgui_framebuffer_smoke_render_frame_count",
    "imgui_framebuffer_smoke_geometry_nonempty_count",
    "imgui_framebuffer_smoke_geometry_canvas_count",
    "imgui_framebuffer_smoke_geometry_filled_rect_count",
    "imgui_framebuffer_smoke_geometry_rect_count",
    "imgui_framebuffer_smoke_geometry_polyline_count",
    "imgui_framebuffer_smoke_geometry_marker_count",
    "imgui_framebuffer_smoke_rect_filled_count",
    "imgui_framebuffer_smoke_rect_count",
    "imgui_framebuffer_smoke_polyline_count",
    "imgui_framebuffer_smoke_circle_filled_count",
    "imgui_framebuffer_smoke_text_count",
)

_ANALYSIS_IMGUI_SOURCE_OPEN_REQUEST_SMOKE_KEYS = (
    "imgui_source_open_request_smoke_artifact_count",
    "imgui_source_open_request_smoke_passed_count",
    "imgui_source_open_request_smoke_opened_by_real_host_count",
    "imgui_source_open_request_smoke_scheme_allowed_count",
    "imgui_source_open_request_smoke_request_consumed_count",
    "imgui_source_open_request_smoke_request_cleared_count",
    "imgui_source_open_request_smoke_final_pending_count",
    "imgui_source_open_request_smoke_source_url_length_total",
    "imgui_source_open_request_smoke_selected_source_url_length_total",
    "imgui_source_open_request_smoke_requested_source_url_length_total",
)

_ANALYSIS_VALIDATE_TABLE_SOURCE_METADATA_KEYS = (
    "validate_table_source_metadata_artifact_count",
    "validate_table_source_metadata_valid_count",
    "validate_table_source_metadata_issue_count",
    "validate_table_source_metadata_record_count",
    "validate_table_source_metadata_provenance_review_ready_count",
    "validate_table_source_metadata_provenance_blocker_count",
    "validate_table_source_metadata_summary_consistency_matched_count",
    "validate_table_source_metadata_blocker_summary_consistency_matched_count",
    "validate_table_source_metadata_source_count",
    "validate_table_source_metadata_source_value_label_count",
    "validate_table_source_metadata_source_value_row_count_total",
    "validate_table_source_metadata_source_url_count",
    "validate_table_source_metadata_source_url_scheme_count",
    "validate_table_source_metadata_source_url_domain_count",
    "validate_table_source_metadata_valid_source_url_count",
    "validate_table_source_metadata_invalid_source_url_count",
    "validate_table_source_metadata_source_url_missing_scheme_count",
    "validate_table_source_metadata_source_url_missing_domain_count",
    "validate_table_source_metadata_source_url_issue_code_total",
    "validate_table_source_metadata_missing_source_count",
    "validate_table_source_metadata_missing_source_url_count",
    "validate_table_source_metadata_source_url_without_source_count",
    "validate_table_source_metadata_all_records_have_source_count",
    "validate_table_source_metadata_all_source_records_have_source_url_count",
    "validate_table_source_metadata_all_source_urls_have_source_count",
    "validate_table_source_metadata_all_source_urls_are_http_or_https_count",
    "validate_table_source_metadata_source_completeness_row_count",
    "validate_table_source_metadata_source_completeness_row_count_matched_count",
    "validate_table_source_metadata_source_completeness_source_count_matched_count",
    "validate_table_source_metadata_source_completeness_source_url_count_matched_count",
    "validate_table_source_metadata_source_completeness_invalid_url_count_matched_count",
    "validate_table_source_metadata_known_limitations_count",
    "validate_table_source_metadata_convention_metadata_without_name_count",
    "validate_table_source_metadata_convention_mismatch_count",
    "validate_table_source_metadata_all_conventions_match_expected_count",
    "validate_table_source_metadata_table_correctness_certified_count",
    "validate_table_source_metadata_external_source_verified_count",
)

_ANALYSIS_IMGUI_SIGNED_PD_SNAPSHOT_KEYS = (
    "imgui_signed_pd_snapshot_artifact_count",
    "imgui_signed_pd_snapshot_valid_count",
    "imgui_signed_pd_snapshot_validation_available_count",
    "imgui_signed_pd_snapshot_component_count_matches_count",
    "imgui_signed_pd_snapshot_revision_present_count",
    "imgui_signed_pd_snapshot_crossing_count_total",
    "imgui_signed_pd_snapshot_component_count_total",
    "imgui_signed_pd_snapshot_validation_component_count_total",
    "imgui_signed_pd_snapshot_edge_label_slot_count_total",
    "imgui_signed_pd_snapshot_unique_edge_label_count_total",
    "imgui_signed_pd_snapshot_nonpositive_edge_label_count_total",
    "imgui_signed_pd_snapshot_unexpected_occurrence_label_count_total",
    "imgui_signed_pd_snapshot_invalid_flow_label_count_total",
    "imgui_signed_pd_snapshot_explicit_role_order_count_total",
    "imgui_signed_pd_snapshot_invalid_role_order_count_total",
    "imgui_signed_pd_snapshot_oriented_component_count_total",
)

_ANALYSIS_IMGUI_SIGNED_PD_RECOMPUTE_SCHEDULER_SMOKE_KEYS = (
    "imgui_signed_pd_recompute_scheduler_smoke_artifact_count",
    "imgui_signed_pd_recompute_scheduler_smoke_passed_count",
    "imgui_signed_pd_recompute_scheduler_smoke_first_revision_reloaded_count",
    "imgui_signed_pd_recompute_scheduler_smoke_stale_recompute_rejected_count",
    "imgui_signed_pd_recompute_scheduler_smoke_stale_results_rejected_count",
    "imgui_signed_pd_recompute_scheduler_smoke_stale_error_revision_mismatch_count",
    "imgui_signed_pd_recompute_scheduler_smoke_current_revision_reloaded_count",
    "imgui_signed_pd_recompute_scheduler_smoke_current_revision_rows_reloaded_count",
    "imgui_signed_pd_recompute_scheduler_smoke_requested_snapshot_cleared_count",
    "imgui_signed_pd_recompute_scheduler_smoke_host_queue_drained_count",
    "imgui_signed_pd_recompute_scheduler_smoke_abi_matched_count",
    "imgui_signed_pd_recompute_scheduler_smoke_handoff_complete_count",
    "imgui_signed_pd_recompute_scheduler_smoke_snapshot_hash_present_count",
    "imgui_signed_pd_recompute_scheduler_smoke_final_status_fresh_count",
    "imgui_signed_pd_recompute_scheduler_smoke_first_result_count_total",
    "imgui_signed_pd_recompute_scheduler_smoke_stale_result_count_total",
    "imgui_signed_pd_recompute_scheduler_smoke_current_result_count_total",
    "imgui_signed_pd_recompute_scheduler_smoke_final_invariant_status_count_total",
    "imgui_signed_pd_recompute_scheduler_smoke_snapshot_json_length_total",
    "imgui_signed_pd_recompute_scheduler_smoke_cli_handoff_metadata_count",
)

_ANALYSIS_IMGUI_SIGNED_PD_THREAD_POOL_RECOMPUTE_SCHEDULER_SMOKE_KEYS = (
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact_count",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_passed_count",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_recompute_rejected_count",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_result_rejected_count",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_revision_reloaded_count",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_requested_snapshot_cleared_count",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_progress_completed_count",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_progress_inactive_after_completion_count",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_abi_matched_count",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_handoff_complete_count",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_snapshot_hash_present_count",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_final_status_fresh_count",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_request_lifecycle_complete_count",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_request_lifecycle_complete_count",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_thread_pool_worker_count_matched_count",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_loaded_revision_current_count",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_worker_count_total",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_result_count_total",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_result_count_total",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_final_invariant_status_count_total",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_snapshot_json_length_total",
    "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_cli_handoff_metadata_count",
)

_ANALYSIS_IMGUI_REAL_KERNEL_LOADER_SMOKE_KEYS = (
    "imgui_real_kernel_loader_smoke_artifact_count",
    "imgui_real_kernel_loader_smoke_passed_count",
    "imgui_real_kernel_loader_smoke_abi_matched_count",
    "imgui_real_kernel_loader_smoke_dynamic_library_loaded_count",
    "imgui_real_kernel_loader_smoke_api_attached_count",
    "imgui_real_kernel_loader_smoke_kernel_api_connected_count",
    "imgui_real_kernel_loader_smoke_rust_kernel_available_count",
    "imgui_real_kernel_loader_smoke_callback_thread_pool_completed_count",
    "imgui_real_kernel_loader_smoke_worker_touches_imgui_context_count",
    "imgui_real_kernel_loader_smoke_required_metadata_fields_present_count",
    "imgui_real_kernel_loader_smoke_readiness_provenance_present_count",
    "imgui_real_kernel_loader_smoke_python_file_recompute_boundary_count",
    "imgui_real_kernel_loader_smoke_native_result_handles_complete_count",
    "imgui_real_kernel_loader_smoke_complete_result_handle_abi_count",
    "imgui_real_kernel_loader_smoke_release_grade_result_handles_count",
    "imgui_real_kernel_loader_smoke_native_homfly_cpp_computation_claimed_count",
    "imgui_real_kernel_loader_smoke_native_alexander_cpp_computation_claimed_count",
    "imgui_real_kernel_loader_smoke_production_scheduler_completion_claimed_count",
    "imgui_real_kernel_loader_smoke_signed_release_artifacts_published_count",
    "imgui_real_kernel_loader_smoke_non_claim_false_count",
    "imgui_real_kernel_loader_smoke_backend_report_byte_count_total",
    "imgui_real_kernel_loader_smoke_invariant_handles_report_byte_count_total",
    "imgui_real_kernel_loader_smoke_last_kernel_result_length_total",
    "imgui_real_kernel_loader_smoke_distance_progress_total",
    "imgui_real_kernel_loader_smoke_intersection_progress_total",
    "imgui_real_kernel_loader_smoke_distance_callback_count_total",
    "imgui_real_kernel_loader_smoke_intersection_callback_count_total",
    "imgui_real_kernel_loader_smoke_required_metadata_field_count_total",
)

_ANALYSIS_IMGUI_WINDOWS_RETAINED_ARTIFACTS_MANIFEST_KEYS = (
    "imgui_windows_retained_artifacts_manifest_artifact_count",
    "imgui_windows_retained_artifacts_manifest_abi_matched_count",
    "imgui_windows_retained_artifacts_manifest_evidence_group_count_total",
    "imgui_windows_retained_artifacts_manifest_reported_evidence_group_count_total",
    "imgui_windows_retained_artifacts_manifest_retained_json_file_count_total",
    "imgui_windows_retained_artifacts_manifest_retained_json_file_reference_count_total",
    "imgui_windows_retained_artifacts_manifest_unique_retained_json_file_count_total",
    "imgui_windows_retained_artifacts_manifest_shared_retained_json_file_count_total",
    "imgui_windows_retained_artifacts_manifest_retained_json_file_count_matched_count",
    "imgui_windows_retained_artifacts_manifest_raw_analysis_host_group_count_total",
    "imgui_windows_retained_artifacts_manifest_invariant_status_host_group_count_total",
    "imgui_windows_retained_artifacts_manifest_smoke_executed_no_retained_json_count_total",
    "imgui_windows_retained_artifacts_manifest_complete_raw_analysis_host_group_count_total",
    "imgui_windows_retained_artifacts_manifest_non_claim_false_count",
    "imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total",
    "imgui_windows_retained_artifacts_manifest_production_renderer_verified_count",
    "imgui_windows_retained_artifacts_manifest_production_scheduler_completion_claimed_count",
    "imgui_windows_retained_artifacts_manifest_native_homfly_cpp_computation_claimed_count",
    "imgui_windows_retained_artifacts_manifest_native_alexander_cpp_computation_claimed_count",
    "imgui_windows_retained_artifacts_manifest_signed_release_artifacts_published_count",
)

_ANALYSIS_RUST_WHEEL_RETAINED_MANIFEST_KEYS = (
    "rust_wheel_retained_manifest_artifact_count",
    "rust_wheel_retained_manifest_abi_matched_count",
    "rust_wheel_retained_manifest_wheel_count_total",
    "rust_wheel_retained_manifest_wheel_file_count_total",
    "rust_wheel_retained_manifest_wheel_count_matched_count",
    "rust_wheel_retained_manifest_unsigned_ci_artifact_count",
    "rust_wheel_retained_manifest_non_claim_false_count",
    "rust_wheel_retained_manifest_non_claim_evidence_index_entry_count_total",
    "rust_wheel_retained_manifest_signed_release_artifacts_published_count",
    "rust_wheel_retained_manifest_publication_claimed_count",
    "rust_wheel_retained_manifest_platform_index_publication_claimed_count",
    "rust_wheel_retained_manifest_release_grade_speedup_claimed_count",
    "rust_wheel_retained_manifest_native_homfly_cpp_computation_claimed_count",
    "rust_wheel_retained_manifest_native_alexander_cpp_computation_claimed_count",
)

_INVARIANT_STATUS_ADMISSIBLE_MINOR_KEYS = (
    "bounded_scanned_gcd_expected_minor_combination_count",
    "bounded_scanned_gcd_nonzero_minor_count",
    "bounded_scanned_gcd_zero_minor_count",
    "bounded_scanned_gcd_unit_minor_count",
    "bounded_scanned_gcd_unique_nonzero_polynomial_count",
    "bounded_scanned_gcd_all_rows_have_nonzero_minor_count",
    "bounded_scanned_gcd_all_columns_have_nonzero_minor_count",
    "bounded_scanned_gcd_complete_scan_count",
    "bounded_scanned_gcd_nonzero_minor_coverage_complete_count",
)

_INVARIANT_STATUS_SOURCE_TABLE_AUDIT_KEYS = _ANALYSIS_SOURCE_TABLE_AUDIT_KEYS

_ALEXANDER_COMMON_GCD_EVIDENCE_KEYS = (
    "alexander_common_gcd_attempt_evidence_count",
    "alexander_common_gcd_proof_evidence_count",
    "alexander_common_gcd_input_polynomial_count",
    "alexander_common_gcd_unique_input_polynomial_count",
    "alexander_common_gcd_candidate_term_count",
    "alexander_common_gcd_divisible_input_count",
    "alexander_common_gcd_failed_input_count",
    "alexander_common_gcd_quotient_count",
    "alexander_common_gcd_unique_quotient_count",
    "alexander_common_gcd_quotient_unit_count",
    "alexander_common_gcd_support_signature_variant_count",
    "alexander_common_gcd_direct_divisor_candidate_count",
    "alexander_common_gcd_direct_divisor_failed_candidate_count",
    "alexander_common_gcd_direct_divisor_all_candidates_failed_count",
)

_ADMISSIBLE_MINOR_NORMALIZATION_KEYS = (
    "admissible_minor_normalization_checked_nonzero_minor_count",
    "admissible_minor_normalization_failed_nonzero_minor_count",
    "admissible_minor_normalization_all_equivalent_count",
    "admissible_minor_normalization_bounded_certified_count",
    "admissible_minor_normalization_complete_scan_count",
    "admissible_minor_normalization_nonzero_minor_coverage_complete_count",
    "admissible_minor_normalization_truncated_count",
    "admissible_minor_normalization_class_count",
    "admissible_minor_normalization_largest_class_minor_count",
    "admissible_minor_normalization_representative_class_minor_count",
    "admissible_minor_normalization_nonrepresentative_class_count",
)

_SOURCE_TABLE_ALEXANDER_NUMERATOR_KEYS = (
    "source_table_alexander_numerator_checked_count",
    "source_table_alexander_numerator_source_seen_count",
    "source_table_alexander_numerator_complete_match_count",
    "source_table_alexander_numerator_returned_match_count",
    "source_table_alexander_numerator_incomplete_or_unstable_count",
    "source_table_alexander_numerator_candidate_unique_value_count",
    "source_table_alexander_numerator_computed_candidate_count",
    "source_table_alexander_numerator_skipped_candidate_count",
    "source_table_alexander_numerator_missing_candidate_count",
    "source_table_alexander_numerator_link_normalization_checked_count",
    "source_table_alexander_numerator_link_normalization_ready_count",
    "source_table_alexander_numerator_link_normalization_blocked_count",
    "source_table_alexander_numerator_link_normalization_blocker_count",
    "source_table_alexander_skipped_common_gcd_attempt_candidate_count",
    "source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count",
    "source_table_alexander_skipped_common_gcd_attempt_method_count",
    "source_table_alexander_skipped_common_gcd_attempt_limit_variant_count",
    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count",
    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_min",
    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_max",
    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_divides_all_candidate_count_min",
    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_divides_all_candidate_count_max",
    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_min",
    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max",
    "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed_count",
    "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count",
    "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count",
    "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min",
    "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max",
    "source_table_alexander_source_divisibility_checked_candidate_count",
    "source_table_alexander_source_divisibility_source_divides_all_candidate_count",
    "source_table_alexander_source_divisibility_source_division_failed_candidate_count",
    "source_table_alexander_source_divisibility_status_variant_count",
    "source_table_alexander_source_divisibility_failed_candidate_witness_count",
    "source_table_alexander_source_divisibility_failed_candidate_witness_truncated",
)

_SOURCE_TABLE_ALEXANDER_NUMERATOR_REPORT_FIELDS = {
    "source_table_multivariable_alexander_numerator_checked_count": (
        "source_table_alexander_numerator_checked_count"
    ),
    "source_table_multivariable_alexander_numerator_source_seen_count": (
        "source_table_alexander_numerator_source_seen_count"
    ),
    "source_table_multivariable_alexander_numerator_complete_match_count": (
        "source_table_alexander_numerator_complete_match_count"
    ),
    "source_table_multivariable_alexander_numerator_returned_match_count": (
        "source_table_alexander_numerator_returned_match_count"
    ),
    "source_table_multivariable_alexander_numerator_incomplete_or_unstable_count": (
        "source_table_alexander_numerator_incomplete_or_unstable_count"
    ),
    "source_table_multivariable_alexander_numerator_candidate_unique_value_count": (
        "source_table_alexander_numerator_candidate_unique_value_count"
    ),
    "source_table_multivariable_alexander_numerator_computed_candidate_count": (
        "source_table_alexander_numerator_computed_candidate_count"
    ),
    "source_table_multivariable_alexander_numerator_skipped_candidate_count": (
        "source_table_alexander_numerator_skipped_candidate_count"
    ),
    "source_table_multivariable_alexander_numerator_missing_candidate_count": (
        "source_table_alexander_numerator_missing_candidate_count"
    ),
    "source_table_alexander_numerator_link_normalization_checked_count": (
        "source_table_alexander_numerator_link_normalization_checked_count"
    ),
    "source_table_alexander_numerator_link_normalization_ready_count": (
        "source_table_alexander_numerator_link_normalization_ready_count"
    ),
    "source_table_alexander_numerator_link_normalization_blocked_count": (
        "source_table_alexander_numerator_link_normalization_blocked_count"
    ),
    "source_table_alexander_numerator_link_normalization_blocker_count": (
        "source_table_alexander_numerator_link_normalization_blocker_count"
    ),
}

_ANALYSIS_GENERATED_COVERAGE_KEYS = (
    "generated_case_count",
    "generated_non_fixture_case_count",
    "generated_source_notation_count",
    "generated_branch_depth",
    "generated_max_branch_depth",
    "generated_unique_diagram_count",
    "generated_unique_oriented_diagram_count",
    "generated_frontier_case_count",
    "generated_zero_crossing_unlink_case_count",
    "generated_polynomial_variant_diagram_count",
    "generated_oriented_polynomial_conflict_count",
    "generated_unique_evaluation_count",
    "generated_reused_evaluation_count",
    "generated_fixture_normalization_metadata_count",
    "generated_fixture_normalization_expected_source_count",
    "generated_fixture_normalization_source_url_count",
    "generated_fixture_normalization_full_table_certified_count",
    "generated_fixture_normalization_arbitrary_diagram_certified_count",
)

_GENERATED_SOURCE_SUMMARY_CONSISTENCY_FIELDS = (
    (
        "generated_source_summary_consistency_matched",
        "matched",
    ),
    (
        "generated_source_summary_count_totals_matched",
        "count_totals_matched",
    ),
    (
        "generated_source_summary_distribution_totals_matched",
        "distribution_totals_matched",
    ),
    (
        "generated_source_summary_frontier_reason_counts_matched",
        "frontier_reason_counts_matched",
    ),
    (
        "generated_source_summary_source_notation_count_matches_fixture_count",
        "source_notation_count_matches_fixture_count",
    ),
)


_ROLE_ORDER_SIGNATURE_RESOLUTION_STATUS_CODES = {
    "": 0,
    "no_strict_candidates": 1,
    "not_evaluated": 2,
    "evaluated_candidates_same_signature": 3,
    "all_strict_candidates_same_signature": 4,
    "partially_distinguishes_candidates": 5,
    "distinguishes_strict_candidates": 6,
}


def _role_order_signature_resolution_status_code(status: str) -> int:
    return _ROLE_ORDER_SIGNATURE_RESOLUTION_STATUS_CODES.get(status, 0)


_SOURCE_TABLE_HOMFLY_VARIANT_RESOLUTION_STATUS_CODES = {
    "": 0,
    "no_source_value": 1,
    "not_computed": 2,
    "source_value_seen": 3,
    "source_variant_seen": 4,
    "source_value_unit_normalized_seen": 5,
    "source_variant_unit_normalized_seen": 6,
    "source_variants_missed": 7,
}


def _source_table_homfly_variant_resolution_status_code(status: str) -> int:
    return _SOURCE_TABLE_HOMFLY_VARIANT_RESOLUTION_STATUS_CODES.get(status, 0)


_SOURCE_TABLE_SOURCE_MATCH_RESOLUTION_STATUS_CODES = {
    "": 0,
    "no_source_value": 1,
    "not_computed": 2,
    "complete_source_match": 3,
    "returned_source_match_incomplete": 4,
    "source_seen_with_incomplete_candidates": 5,
    "source_seen_unstable": 6,
    "candidate_values_missing_or_skipped": 7,
    "source_missed_with_candidates": 8,
}


def _source_table_source_match_resolution_status_code(status: str) -> int:
    return _SOURCE_TABLE_SOURCE_MATCH_RESOLUTION_STATUS_CODES.get(status, 0)


def geometry_components_from_report(report: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Return normalized renderable 3D components from an analysis report."""

    components, _ = _geometry_components_and_notes(report)
    return components


def projected_crossings_from_report(report: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Return `IrollProjectedCrossing`-compatible records from a report."""

    topology = report.get("topology")
    if not isinstance(topology, Mapping):
        return []
    rows = topology.get("crossings")
    if not isinstance(rows, list):
        return []
    crossings = []
    for row in rows:
        if not isinstance(row, Mapping):
            continue
        crossing = _projected_crossing_from_mapping(row)
        if crossing is not None:
            crossings.append(crossing)
    return crossings


def contact_overlays_from_report(report: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Return `IrollContactOverlay`-compatible records from a report."""

    topology = report.get("topology")
    if not isinstance(topology, Mapping):
        return []
    contacts = topology.get("contacts")
    if isinstance(contacts, Mapping):
        rows = contacts.get("contacts")
    else:
        rows = contacts
    if not isinstance(rows, list):
        return []
    overlays = []
    for row in rows:
        if not isinstance(row, Mapping):
            continue
        overlay = _contact_overlay_from_mapping(row)
        if overlay is not None:
            overlays.append(overlay)
    return overlays


def imgui_geometry_payload_from_report(report: Mapping[str, Any]) -> dict[str, Any]:
    """Flatten report geometry and overlays for the C++/Dear ImGui panel.

    The returned dictionary is still JSON, but the array fields map directly to
    `IrollImGui_LoadComponents3D`, `IrollImGui_LoadProjectedCrossings`, and
    `IrollImGui_LoadContacts`.
    """

    components, component_notes = _geometry_components_and_notes(report)
    projected_crossings = projected_crossings_from_report(report)
    contacts = contact_overlays_from_report(report)
    flat_points = [
        coordinate
        for component in components
        for point in component["points"]
        for coordinate in point
    ]
    colors = [
        component["color"]
        for component in components
        if component.get("color") is not None
    ]
    component_colors = colors if components and len(colors) == len(components) else None
    notes = [
        "flat_points/component_point_counts/component_closed map to IrollImGui_LoadComponents3D",
        "projected_crossings map to IrollProjectedCrossing and IrollImGui_LoadProjectedCrossings",
        "contacts map to IrollContactOverlay and IrollImGui_LoadContacts",
        "payload is display/load metadata; topology values remain authoritative in the source report",
        *component_notes,
    ]
    payload = {
        "method": "imgui_geometry_payload_from_report",
        "source_kind": _report_kind_label(report),
        "report_name": _report_name(report),
        "components": components,
        "component_count": len(components),
        "geometry_point_count": sum(component["point_count"] for component in components),
        "flat_points": flat_points,
        "component_point_counts": [
            component["point_count"] for component in components
        ],
        "component_closed": [1 if component["closed"] else 0 for component in components],
        "component_colors": component_colors,
        "projected_crossings": projected_crossings,
        "projected_crossing_count": len(projected_crossings),
        "contacts": contacts,
        "contact_count": len(contacts),
        "skipped": len(components) == 0,
        "notes": notes,
    }
    classification_summary = _classification_summary_from_report(report)
    if classification_summary is not None:
        payload["classification_summary"] = classification_summary
        payload["notes"] = [
            *payload["notes"],
            "classification_summary is copied from the source report for host display only",
        ]
    return payload


def imgui_link_classification_summary_payload_from_report(
    report: Mapping[str, Any],
) -> dict[str, Any]:
    """Return an `IrollLinkClassificationSummary`-shaped payload for a report."""

    summary = _classification_summary_from_report(report)
    payload: dict[str, Any] = {
        "method": "imgui_link_classification_summary_payload_from_report",
        "has_link_classification_summary": summary is not None,
        "link_classification_summary": None,
        "notes": [
            "payload fields map to IrollLinkClassificationSummary for host loading",
        ],
    }
    if summary is None:
        payload["notes"].append(
            "source report did not expose pairwise-zero classification ambiguity"
        )
        return payload

    payload["link_classification_summary"] = {
        "method": str(summary.get("method", "")),
        "source_method": str(summary.get("source_method", "")),
        "link_type": str(summary.get("link_type", "")),
        "confidence": str(summary.get("confidence", "")),
        "component_count": int(summary.get("component_count", 0) or 0),
        "candidate_count": int(summary.get("candidate_count", 0) or 0),
        "nontrivial_candidate_count": int(
            summary.get("nontrivial_candidate_count", 0) or 0
        ),
        "nontrivial_link_types": _classification_summary_text(
            summary.get("nontrivial_link_types")
        ),
        "nontrivial_notations": _classification_summary_text(
            summary.get("nontrivial_notations")
        ),
        "source_table_invariant_audit_available_count": int(
            summary.get("source_table_invariant_audit_available_count", 0) or 0
        ),
        "source_table_invariant_audit_summary_count": int(
            summary.get("source_table_invariant_audit_summary_count", 0) or 0
        ),
        "source_table_nontrivial_candidate_count": int(
            summary.get("source_table_nontrivial_candidate_count", 0) or 0
        ),
        "source_table_nontrivial_candidate_notations": _classification_summary_text(
            summary.get("source_table_nontrivial_candidate_notations")
        ),
        "source_table_distinguishing_evidence_available": bool(
            summary.get("source_table_distinguishing_evidence_available", False)
        ),
        "stronger_invariants_required": bool(
            summary.get("stronger_invariants_required", False)
        ),
        "source_table_registration_ready_count": int(
            summary.get("source_table_registration_ready_count", 0) or 0
        ),
        "source_table_registration_blocked_count": int(
            summary.get("source_table_registration_blocked_count", 0) or 0
        ),
        "source_table_registration_blocker_count": int(
            summary.get("source_table_registration_blocker_count", 0) or 0
        ),
        "source_table_registration_blocker_codes": _classification_summary_text(
            summary.get("source_table_registration_blocker_codes")
        ),
        "source_table_registration_blocker_code_count": int(
            summary.get("source_table_registration_blocker_code_count", 0) or 0
        ),
        "source_table_registration_blocker_count_signature": str(
            summary.get("source_table_registration_blocker_count_signature", "") or ""
        ),
        "source_table_matched_invariant_count": int(
            summary.get("source_table_matched_invariant_count", 0) or 0
        ),
        "source_table_uncomputed_invariant_count": int(
            summary.get("source_table_uncomputed_invariant_count", 0) or 0
        ),
        "source_table_mismatched_invariant_count": int(
            summary.get("source_table_mismatched_invariant_count", 0) or 0
        ),
        "source_table_unstable_invariant_count": int(
            summary.get("source_table_unstable_invariant_count", 0) or 0
        ),
        "source_table_source_match_resolution_statuses": (
            _classification_summary_text(
                summary.get("source_table_source_match_resolution_statuses")
            )
        ),
        "source_table_source_match_resolution_status_count": (
            int(summary.get("source_table_source_match_resolution_status_count", 0) or 0)
            if summary.get("source_table_source_match_resolution_status_count")
            is not None
            else _classification_summary_item_count(
                summary.get("source_table_source_match_resolution_statuses")
            )
        ),
        "source_table_homfly_variant_resolution_statuses": (
            _classification_summary_text(
                summary.get("source_table_homfly_variant_resolution_statuses")
            )
        ),
        "source_table_audit_notations": _classification_summary_text(
            summary.get("source_table_audit_notations")
        ),
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count": int(
            summary.get(
                "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count",
                0,
            )
            or 0
        ),
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count": int(
            summary.get(
                "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count",
                0,
            )
            or 0
        ),
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min": int(
            summary.get(
                "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min",
                0,
            )
            or 0
        ),
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max": int(
            summary.get(
                "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max",
                0,
            )
            or 0
        ),
        "notes": _classification_summary_notes_text(summary.get("notes")),
    }
    payload["notes"].append(
        "link_classification_summary is display metadata, not a classification proof"
    )
    return payload


def analysis_summary_from_acceptance_report(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    """Return an `IrollAnalysisSummary`-compatible dictionary.

    The C++/Dear ImGui panel accepts a flat C ABI payload, while mathematical
    acceptance reports are nested. This helper preserves the conservative
    boundary by exposing only display-safe summary fields.
    """

    if _is_gpu_smoke_artifact(report):
        return _analysis_summary_with_source_signed_pd_revision(
            _analysis_summary_from_gpu_smoke_artifact(report, name=name),
            report,
        )
    if _is_imgui_framebuffer_smoke_artifact(report):
        return _analysis_summary_from_imgui_framebuffer_smoke_artifact(
            report,
            name=name,
        )
    if _is_imgui_source_open_request_smoke_artifact(report):
        return _analysis_summary_from_imgui_source_open_request_smoke_artifact(
            report,
            name=name,
        )
    if _is_validate_table_source_metadata_report(report):
        return _analysis_summary_from_validate_table_source_metadata_report(
            report,
            name=name,
        )
    if _is_imgui_signed_pd_snapshot_artifact(report):
        return _analysis_summary_with_source_signed_pd_revision(
            _analysis_summary_from_imgui_signed_pd_snapshot_artifact(
                report,
                name=name,
            ),
            report,
        )
    if _is_imgui_signed_pd_recompute_scheduler_smoke_artifact(report):
        return _analysis_summary_from_imgui_signed_pd_recompute_scheduler_smoke_artifact(
            report,
            name=name,
        )
    if _is_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact(report):
        return _analysis_summary_from_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact(
            report,
            name=name,
        )
    if _is_imgui_real_kernel_loader_smoke_artifact(report):
        return _analysis_summary_from_imgui_real_kernel_loader_smoke_artifact(
            report,
            name=name,
        )
    if _is_imgui_windows_retained_artifacts_manifest(report):
        return _analysis_summary_from_imgui_windows_retained_artifacts_manifest(
            report,
            name=name,
        )
    if _is_rust_wheel_retained_manifest(report):
        return _analysis_summary_from_rust_wheel_retained_manifest(
            report,
            name=name,
        )

    method = str(report.get("method", "acceptance_report"))
    if method == "homfly_terminal_reduction_audit":
        return _analysis_summary_with_source_signed_pd_revision(
            _analysis_summary_from_homfly_terminal_reduction_audit(
                report,
                name=name,
            ),
            report,
        )
    if method == "homfly_input_certification_evidence":
        return _analysis_summary_with_source_signed_pd_revision(
            _analysis_summary_from_homfly_input_certification_evidence(
                report,
                name=name,
            ),
            report,
        )
    if method == "homfly_skein_identity_audit":
        return _analysis_summary_with_source_signed_pd_revision(
            _analysis_summary_from_homfly_skein_identity_audit(
                report,
                name=name,
            ),
            report,
        )
    if method == "multivariable_alexander_improve_scanned_gcd_result":
        return _analysis_summary_with_source_signed_pd_revision(
            _analysis_summary_from_alexander_improved_result(report, name=name),
            report,
        )
    if method == "multivariable_alexander_minor_divisibility_audit":
        return _analysis_summary_with_source_signed_pd_revision(
            _analysis_summary_from_alexander_minor_divisibility_audit(
                report,
                name=name,
            ),
            report,
        )
    if method == "multivariable_alexander_admissible_minor_normalization_audit":
        return _analysis_summary_with_source_signed_pd_revision(
            _analysis_summary_from_alexander_admissible_minor_normalization_audit(
                report,
                name=name,
            ),
            report,
        )
    if method == "multivariable_alexander_scanned_gcd_audit":
        return _analysis_summary_with_source_signed_pd_revision(
            _analysis_summary_from_alexander_scanned_gcd_audit(report, name=name),
            report,
        )
    if method == "multivariable_alexander_wirtinger_fox_audit":
        return _analysis_summary_with_source_signed_pd_revision(
            _analysis_summary_from_alexander_wirtinger_fox_audit(report, name=name),
            report,
        )
    if method == "multivariable_alexander_input_certification_evidence":
        return _analysis_summary_with_source_signed_pd_revision(
            _analysis_summary_from_alexander_input_certification_evidence(
                report,
                name=name,
            ),
            report,
        )
    if method == "iroll_core_benchmark_matrix":
        return _analysis_summary_with_source_signed_pd_revision(
            _analysis_summary_from_core_benchmark_matrix(report, name=name),
            report,
        )
    if method == "cross_workstream_validation_pack_audit":
        return _analysis_summary_from_cross_workstream_validation_pack_audit(
            report,
            name=name,
        )

    required, passed, failed = _acceptance_check_counts(report)
    (
        certification_scope,
        certification_applicable,
        certification_certified,
        certification_uncertified,
    ) = _acceptance_certification_counts(report)
    evidence_counts = _acceptance_certification_evidence_counts(report)
    notes = _notes_text(report)
    incomplete = report.get("incomplete_notations")
    if isinstance(incomplete, list) and incomplete:
        suffix = "incomplete: " + ", ".join(str(item) for item in incomplete)
        notes = f"{notes}; {suffix}" if notes else suffix
    if method == "signed_pd_role_order_candidates_report":
        notes = _append_role_order_candidate_notes(report, notes)
    if method == "diagram_fixture_source_table_invariant_audit":
        notes = _append_source_table_audit_notes(report, notes)
    if method == "diagram_fixture_source_invariant_candidate_diagnostics":
        notes = _append_source_candidate_replay_summary_note(report, notes)
    if method == "homfly_small_diagram_coverage_report":
        notes = _append_homfly_small_coverage_notes(report, notes)
        notes = _append_homfly_case_evidence_consistency_note(report, notes)
    if method == "multivariable_alexander_signed_pd_coverage_report":
        notes = _append_alexander_signed_pd_coverage_notes(report, notes)
    if method == "multivariable_alexander_fixture_acceptance_report":
        notes = _append_source_table_alexander_acceptance_note(report, notes)
        notes = _append_source_table_registration_acceptance_note(report, notes)
    if method == "homfly_fixture_acceptance_report":
        notes = _append_source_table_registration_acceptance_note(report, notes)
    notes = _append_bounded_homfly_maturity_path_note(report, notes)
    notes = _append_bounded_alexander_maturity_path_note(report, notes)
    notes = _append_alexander_maturity_path_summary_consistency_note(report, notes)
    notes = _append_common_gcd_attempt_note(report, notes)
    notes = _append_homfly_frontier_witness_summary_notes(report, notes)
    notes = _append_homfly_blocker_detail_notes(report, notes)
    notes = _append_alexander_witness_notes(report, notes)

    return _analysis_summary_with_source_signed_pd_revision({
        "name": name or _display_name(method),
        "source_method": method,
        "claim_scope": _analysis_claim_scope(report),
        "accepted": _analysis_summary_accepted(report),
        "certified": any(report.get(key) is True for key in _CERTIFICATION_KEYS),
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": failed,
        "certification_scope": certification_scope,
        "certification_applicable_count": certification_applicable,
        "certification_certified_count": certification_certified,
        "certification_uncertified_count": certification_uncertified,
        **evidence_counts,
        **_compact_host_evidence_counts(report),
        **(
            _blocker_summary_counts(report)
            if _has_nonzero_blocker_summary_input(report)
            else {}
        ),
        **_generated_coverage_counts(report),
        **_homfly_case_evidence_consistency_fields(report),
        **_generated_source_summary_consistency_fields(report),
        **_alexander_maturity_path_summary_consistency_fields(report),
        **_role_order_signature_counts(report),
        **_role_order_signature_resolution_fields(report),
        **_source_table_audit_counts(report),
        **_source_table_audit_registration_blocker_fields(report),
        **_source_table_audit_registration_summary_consistency_fields(report),
        **_source_table_homfly_variant_resolution_fields(report),
        **_source_table_audit_source_match_resolution_fields(report),
        **_source_table_alexander_source_divisibility_witness_fields(report),
        **_source_candidate_replay_summary_fields(report),
        "notes": notes,
    }, report)


def _analysis_summary_from_cross_workstream_validation_pack_audit(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    metadata_complete = bool(
        report.get("required_diagram_fixture_metadata_complete", False)
    )
    signed_complete = bool(
        report.get("signed_diagram_fixture_registration_complete", False)
    )
    non_diagram_closed = (
        (_optional_count(report.get("open_non_diagram_requirement_count")) or 0)
        == 0
    )
    passed = sum((metadata_complete, signed_complete, non_diagram_closed))
    required = 3
    counts = _validation_pack_audit_count_fields(report)
    notes = _append_validation_pack_audit_note(report, _notes_text(report))
    return {
        "name": name or _display_name(str(report.get("method", ""))),
        "source_method": str(report.get("method", "")),
        "claim_scope": _analysis_claim_scope(report),
        "accepted": bool(report.get("final_completion_ready", False)),
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": required - passed,
        "certification_scope": str(report.get("claim_scope", "")),
        "certification_applicable_count": 0,
        "certification_certified_count": 0,
        "certification_uncertified_count": 0,
        "required_diagram_fixture_metadata_complete": metadata_complete,
        "signed_diagram_fixture_registration_complete": signed_complete,
        "final_completion_ready": bool(report.get("final_completion_ready", False)),
        "full_homfly_pt_evaluation_certified": bool(
            report.get("full_homfly_pt_evaluation_certified", False)
        ),
        "full_multivariable_alexander_normalization_certified": bool(
            report.get(
                "full_multivariable_alexander_normalization_certified",
                False,
            )
        ),
        "production_imgui_renderer_verified": bool(
            report.get("production_imgui_renderer_verified", False)
        ),
        "release_artifacts_published": bool(
            report.get("release_artifacts_published", False)
        ),
        **counts,
        **_role_order_signature_counts(report),
        **_source_table_audit_counts(report),
        "notes": notes,
    }


def _analysis_summary_from_alexander_scanned_gcd_audit(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    skipped = bool(report.get("skipped", False))
    exact = bool(report.get("candidate_is_exact_scanned_gcd", False))
    complete = bool(report.get("complete_scanned_gcd_certified", False))
    quotient = bool(report.get("quotient_gcd_certified", False))
    checked = _optional_count(report.get("checked_nonzero_minor_count")) or 0
    failed_nonzero = _optional_count(report.get("failed_nonzero_minor_count")) or 0
    improved = report.get("improved_candidate_polynomial")

    division_ok = not skipped and failed_nonzero == 0
    check_results = (not skipped, division_ok, exact)
    required = len(check_results)
    passed = sum(1 for item in check_results if item)
    failed = required - passed

    evidence_counts = {
        key: 0
        for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS
    }
    evidence_counts["bounded_scanned_gcd_checked_nonzero_minor_count"] = checked
    evidence_counts["bounded_scanned_gcd_failed_nonzero_minor_count"] = failed_nonzero
    evidence_counts["bounded_scanned_gcd_scanned_minor_count"] = (
        _optional_count(report.get("scanned_minor_count")) or 0
    )
    evidence_counts["bounded_scanned_gcd_division_record_count"] = (
        _optional_count(report.get("division_record_count")) or 0
    )
    evidence_counts["bounded_scanned_gcd_complete_scan_count"] = (
        1
        if report.get("complete_combination_scan") is True or complete
        else 0
    )
    evidence_counts["bounded_scanned_gcd_nonzero_minor_coverage_complete_count"] = (
        1
        if report.get("nonzero_minor_coverage_complete") is True or complete
        else 0
    )
    evidence_counts["bounded_scanned_gcd_truncated_count"] = (
        1 if report.get("truncated") is True else 0
    )
    evidence_counts["bounded_scanned_gcd_quotient_gcd_certified_count"] = (
        1 if quotient else 0
    )
    evidence_counts["bounded_scanned_gcd_complete_certified_count"] = (
        1 if complete else 0
    )
    promoted = bool(report.get("scanned_gcd_promoted_candidate", False)) or bool(
        report.get("scanned_gcd_improvement_evidence")
    )
    evidence_counts["bounded_scanned_gcd_improved_candidate_count"] = (
        1 if improved or promoted else 0
    )
    evidence_counts.update(_bounded_scanned_gcd_admissible_minor_counts(report))
    evidence_counts.update(_compact_host_evidence_counts(report))

    notes = _append_note(
        _notes_text(report),
        (
            f"exact_scanned_gcd={exact}; "
            f"complete_scanned_gcd_certified={complete}; "
            f"quotient_gcd_certified={quotient}; "
            f"checked_nonzero_minors={checked}; "
            f"failed_nonzero_minors={failed_nonzero}"
        ),
    )
    if improved:
        notes = _append_note(notes, f"improved_candidate={improved}")
    promotion = report.get("scanned_gcd_improvement_evidence")
    if isinstance(promotion, Mapping):
        promoted = promotion.get("improved_candidate_polynomial") or report.get(
            "multivariable_alexander_polynomial"
        )
        notes = _append_note(notes, f"promoted_candidate={promoted}")
    quotient_method = report.get("quotient_gcd_method")
    quotient_polynomial = report.get("quotient_gcd_polynomial")
    if quotient_method or quotient_polynomial:
        quotient_text = str(quotient_polynomial or "unknown")
        if quotient_method:
            quotient_text += f" via {quotient_method}"
        notes = _append_note(notes, f"quotient_gcd={quotient_text}")
    notes = _append_alexander_witness_notes(report, notes)
    notes = _append_note(
        notes,
        (
            "full_admissible_minor_normalization_certified=False; "
            "full_invariant_certified=False"
        ),
    )
    notes = _append_admissible_minor_scan_note(report, notes)

    certified = 1 if exact and not skipped else 0
    return {
        "name": name or "multi-variable Alexander scanned gcd audit",
        "source_method": "multivariable_alexander_scanned_gcd_audit",
        "claim_scope": str(
            report.get("claim_scope", "bounded_scanned_fox_minor_exact_gcd")
        ),
        "accepted": exact and not skipped,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": failed,
        "certification_scope": str(
            report.get("claim_scope", "bounded_scanned_fox_minor_exact_gcd")
        ),
        "certification_applicable_count": 0 if skipped else 1,
        "certification_certified_count": certified,
        "certification_uncertified_count": 0 if skipped else 1 - certified,
        **evidence_counts,
        **_blocker_summary_counts(report),
        **_role_order_signature_counts(report),
        **_source_table_audit_counts(report),
        **_source_table_homfly_variant_resolution_fields(report),
        **_source_table_audit_source_match_resolution_fields(report),
        "notes": notes,
    }


def _analysis_summary_from_alexander_minor_divisibility_audit(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    skipped = bool(report.get("skipped", False))
    all_divisible = bool(report.get("all_nonzero_minors_divisible", False))
    checked = _optional_count(report.get("checked_nonzero_minor_count")) or 0
    failed_nonzero = _optional_count(report.get("failed_nonzero_minor_count")) or 0
    division_record_count = _optional_count(report.get("division_record_count"))
    division_records = report.get("division_records")
    if division_record_count is None and isinstance(division_records, list):
        division_record_count = len(division_records)

    summary = report.get("admissible_minor_summary")
    summary_mapping = summary if isinstance(summary, Mapping) else {}
    complete = bool(
        report.get("complete_combination_scan", False)
        or summary_mapping.get("complete_combination_scan", False)
    )
    nonzero_coverage_complete = bool(
        report.get("nonzero_minor_coverage_complete", False)
        or summary_mapping.get("nonzero_minor_coverage_complete", False)
    )
    scanned_minor_count = _optional_count(report.get("scanned_minor_count"))
    if scanned_minor_count is None:
        scanned_minor_count = _optional_count(summary_mapping.get("scanned_minor_count"))
    if scanned_minor_count is None:
        scanned_minor_count = checked

    accepted = not skipped and all_divisible and failed_nonzero == 0
    check_results = (
        not skipped,
        all_divisible,
        failed_nonzero == 0,
    )
    required = len(check_results)
    passed = sum(1 for item in check_results if item)
    failed = required - passed

    evidence_counts = {
        key: 0
        for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS
    }
    evidence_counts["bounded_scanned_gcd_checked_nonzero_minor_count"] = checked
    evidence_counts["bounded_scanned_gcd_failed_nonzero_minor_count"] = failed_nonzero
    evidence_counts["bounded_scanned_gcd_scanned_minor_count"] = scanned_minor_count
    evidence_counts["bounded_scanned_gcd_division_record_count"] = (
        division_record_count or 0
    )
    evidence_counts["bounded_scanned_gcd_complete_scan_count"] = 1 if complete else 0
    evidence_counts["bounded_scanned_gcd_nonzero_minor_coverage_complete_count"] = (
        1 if nonzero_coverage_complete else 0
    )
    evidence_counts["bounded_scanned_gcd_truncated_count"] = (
        1 if report.get("truncated") is True else 0
    )
    evidence_counts.update(_bounded_scanned_gcd_admissible_minor_counts(report))
    evidence_counts.update(_compact_host_evidence_counts(report))

    notes = _append_note(
        _notes_text(report),
        (
            f"all_nonzero_minors_divisible={all_divisible}; "
            f"checked_nonzero_minors={checked}; "
            f"failed_nonzero_minors={failed_nonzero}; "
            f"complete_combination_scan={complete}; "
            f"truncated={bool(report.get('truncated', False))}"
        ),
    )
    notes = _append_alexander_witness_notes(report, notes)
    notes = _append_note(
        notes,
        (
            "full_admissible_minor_normalization_certified=False; "
            "full_invariant_certified=False"
        ),
    )
    notes = _append_admissible_minor_scan_note(report, notes)
    claim_scope = str(
        report.get("claim_scope", "bounded_scanned_fox_minor_divisibility")
    )

    return {
        "name": name or "multi-variable Alexander minor divisibility audit",
        "source_method": "multivariable_alexander_minor_divisibility_audit",
        "claim_scope": claim_scope,
        "accepted": accepted,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": failed,
        "certification_scope": claim_scope,
        "certification_applicable_count": 0 if skipped else 1,
        "certification_certified_count": 1 if accepted else 0,
        "certification_uncertified_count": 0 if skipped or accepted else 1,
        **evidence_counts,
        **_blocker_summary_counts(report),
        **_role_order_signature_counts(report),
        **_source_table_audit_counts(report),
        **_source_table_homfly_variant_resolution_fields(report),
        **_source_table_audit_source_match_resolution_fields(report),
        "notes": notes,
    }


def _analysis_summary_from_homfly_terminal_reduction_audit(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    skipped = bool(report.get("skipped", False))
    matched = bool(report.get("matched_result", False)) and not skipped
    failed_reductions = (
        _optional_count(report.get("failed_terminal_reduction_count")) or 0
    )
    terminal_reductions = _optional_count(report.get("terminal_reduction_count")) or 0
    memoized_reductions = _optional_count(report.get("memoized_reduction_count")) or 0
    contribution_count = (
        _optional_count(report.get("reduction_contribution_count")) or 0
    )
    frontier_count = _optional_count(report.get("frontier_count")) or 0
    truncated = bool(report.get("truncated", False))

    check_results = (
        not skipped,
        not skipped and failed_reductions == 0,
        matched,
    )
    required = len(check_results)
    passed = sum(1 for item in check_results if item)
    failed = required - passed

    evidence_counts = {
        key: 0
        for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS
    }
    evidence_counts["input_certification_terminal_reduction_count"] = (
        terminal_reductions
    )
    evidence_counts["input_certification_frontier_count"] = frontier_count
    evidence_counts["input_certification_truncated_count"] = 1 if truncated else 0
    evidence_counts[
        "input_certification_terminal_contribution_audit_applicable_count"
    ] = 0 if skipped else 1
    evidence_counts[
        "input_certification_terminal_contribution_matched_count"
    ] = 1 if matched else 0
    evidence_counts[
        "input_certification_terminal_contribution_failed_count"
    ] = 0 if skipped or matched else 1
    evidence_counts.update(_compact_host_evidence_counts(report))

    notes = _append_note(
        _notes_text(report),
        (
            f"terminal_contribution_sum={report.get('terminal_contribution_sum')}; "
            f"homfly_polynomial={report.get('homfly_polynomial')}; "
            f"terminal_reductions={terminal_reductions}; "
            f"memoized_reductions={memoized_reductions}; "
            f"reduction_contributions={contribution_count}; "
            f"failed_terminal_reductions={failed_reductions}; "
            f"frontier={frontier_count}; truncated={truncated}"
        ),
    )
    notes = _append_homfly_reduction_contribution_witness_notes(report, notes)
    notes = _append_homfly_frontier_witness_summary_notes(report, notes)
    notes = _append_note(
        notes,
        (
            "full_table_normalization_certified=False; "
            "arbitrary_diagram_coverage_certified=False"
        ),
    )
    claim_scope = str(
        report.get(
            "claim_scope",
            "exact_sum_of_recorded_terminal_and_memoized_reduction_contributions",
        )
    )

    return {
        "name": name or "HOMFLY terminal reduction audit",
        "source_method": "homfly_terminal_reduction_audit",
        "claim_scope": claim_scope,
        "accepted": matched,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": failed,
        "certification_scope": claim_scope,
        "certification_applicable_count": 0 if skipped else 1,
        "certification_certified_count": 1 if matched else 0,
        "certification_uncertified_count": 0 if skipped or matched else 1,
        **evidence_counts,
        **_blocker_summary_counts(report),
        **_role_order_signature_counts(report),
        **_source_table_audit_counts(report),
        **_source_table_homfly_variant_resolution_fields(report),
        **_source_table_audit_source_match_resolution_fields(report),
        "notes": notes,
    }


def _analysis_summary_from_alexander_input_certification_evidence(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    skipped = bool(report.get("skipped", False))
    bounded = bool(report.get("bounded_scanned_gcd_certified", False))
    complete = bool(report.get("complete_scanned_gcd_certified", False))
    quotient = bool(report.get("quotient_gcd_certified", False))
    failed_nonzero = _optional_count(report.get("failed_nonzero_minor_count")) or 0
    wirtinger_available = any(
        report.get(key)
        for key in (
            "wirtinger_fox_input_chain_consistent",
            "wirtinger_presentation_valid",
            "fox_jacobian_valid",
            "fox_square_minor_scan_valid",
        )
    ) or any(
        (_optional_count(report.get(key)) or 0) > 0
        for key in (
            "wirtinger_relation_count",
            "wirtinger_generator_count",
            "fox_jacobian_row_count",
            "fox_jacobian_column_count",
        )
    )
    wirtinger_consistent = bool(
        report.get("wirtinger_fox_input_chain_consistent", False)
    )
    check_results = [
        not skipped,
        bounded,
        failed_nonzero == 0,
    ]
    if wirtinger_available:
        check_results.append(wirtinger_consistent)
    required = len(check_results)
    passed = sum(1 for item in check_results if item)
    failed = required - passed
    accepted = (
        not skipped
        and bounded
        and failed_nonzero == 0
        and (wirtinger_consistent if wirtinger_available else True)
    )

    evidence_counts = {
        key: 0
        for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS
    }
    evidence_counts["bounded_scanned_gcd_checked_nonzero_minor_count"] = (
        _optional_count(report.get("checked_nonzero_minor_count")) or 0
    )
    evidence_counts["bounded_scanned_gcd_failed_nonzero_minor_count"] = failed_nonzero
    evidence_counts["bounded_scanned_gcd_scanned_minor_count"] = (
        _optional_count(report.get("scanned_minor_count")) or 0
    )
    evidence_counts["bounded_scanned_gcd_division_record_count"] = (
        _optional_count(report.get("division_record_count")) or 0
    )
    evidence_counts["bounded_scanned_gcd_complete_scan_count"] = (
        1 if report.get("complete_combination_scan") is True else 0
    )
    evidence_counts["bounded_scanned_gcd_nonzero_minor_coverage_complete_count"] = (
        1 if report.get("nonzero_minor_coverage_complete") is True else 0
    )
    evidence_counts["bounded_scanned_gcd_truncated_count"] = (
        1 if report.get("truncated") is True else 0
    )
    evidence_counts["bounded_scanned_gcd_quotient_gcd_certified_count"] = (
        1 if quotient else 0
    )
    evidence_counts["bounded_scanned_gcd_complete_certified_count"] = (
        1 if complete else 0
    )
    promoted = bool(report.get("scanned_gcd_promoted_candidate", False)) or bool(
        report.get("scanned_gcd_improvement_evidence")
    )
    evidence_counts["bounded_scanned_gcd_improved_candidate_count"] = (
        1 if report.get("improved_candidate_polynomial") or promoted else 0
    )
    evidence_counts.update(_bounded_scanned_gcd_admissible_minor_counts(report))
    evidence_counts.update(_admissible_minor_normalization_counts(report))
    evidence_counts.update(_bounded_alexander_maturity_path_count_fields(report))
    evidence_counts.update(_compact_host_evidence_counts(report))
    evidence_counts["wirtinger_fox_relation_count"] = (
        _optional_count(report.get("wirtinger_relation_count")) or 0
    )
    evidence_counts["wirtinger_fox_generator_count"] = (
        _optional_count(report.get("wirtinger_generator_count")) or 0
    )
    evidence_counts["wirtinger_fox_scanned_minor_count"] = (
        _optional_count(report.get("scanned_minor_count")) or 0
    )
    evidence_counts["wirtinger_fox_invalid_minor_reference_count"] = (
        _optional_count(report.get("fox_square_minor_invalid_reference_count")) or 0
    )
    evidence_counts["wirtinger_fox_invalid_normalization_count"] = (
        _optional_count(report.get("fox_square_minor_invalid_normalization_count"))
        or 0
    )
    evidence_counts["wirtinger_fox_complete_scan_count"] = (
        1 if report.get("complete_combination_scan") is True else 0
    )
    evidence_counts["wirtinger_fox_truncated_count"] = (
        1 if report.get("truncated") is True else 0
    )
    evidence_counts.update(_compact_host_evidence_counts(report))

    notes = _append_note(
        _notes_text(report),
        (
            f"bounded_scanned_gcd_certified={bounded}; "
            f"complete_scanned_gcd_certified={complete}; "
            f"quotient_gcd_certified={quotient}; "
            f"failed_nonzero_minors={failed_nonzero}; "
            f"wirtinger_fox_input_chain_consistent={wirtinger_consistent}"
        ),
    )
    quotient_polynomial = report.get("quotient_gcd_polynomial")
    quotient_method = report.get("quotient_gcd_method")
    if quotient_polynomial or quotient_method:
        quotient_text = str(quotient_polynomial or "unknown")
        if quotient_method:
            quotient_text += f" via {quotient_method}"
        notes = _append_note(notes, f"quotient_gcd={quotient_text}")
    improved = report.get("improved_candidate_polynomial")
    promotion = report.get("scanned_gcd_improvement_evidence")
    if improved:
        notes = _append_note(notes, f"improved_candidate={improved}")
    if isinstance(promotion, Mapping):
        promoted = promotion.get("improved_candidate_polynomial") or report.get(
            "multivariable_alexander_polynomial"
        )
        notes = _append_note(notes, f"promoted_candidate={promoted}")
    notes = _append_bounded_alexander_maturity_path_note(report, notes)
    notes = _append_alexander_maturity_path_summary_consistency_note(report, notes)
    notes = _append_admissible_minor_normalization_note(report, notes)
    notes = _append_alexander_blocker_notes(report, notes)
    notes = _append_alexander_wirtinger_relation_shape_notes(report, notes)
    notes = _append_alexander_witness_notes(report, notes)
    notes = _append_note(
        notes,
        (
            "full_admissible_minor_normalization_certified=False; "
            "full_invariant_certified=False"
        ),
    )
    notes = _append_admissible_minor_scan_note(report, notes)
    claim_scope = str(
        report.get(
            "claim_scope",
            "exact_scanned_fox_minor_gcd_for_one_signed_pd_input",
        )
    )

    return {
        "name": name or "multi-variable Alexander input certification evidence",
        "source_method": "multivariable_alexander_input_certification_evidence",
        "claim_scope": claim_scope,
        "accepted": accepted,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": failed,
        "certification_scope": claim_scope,
        "certification_applicable_count": 0 if skipped else 1,
        "certification_certified_count": 1 if accepted else 0,
        "certification_uncertified_count": 0 if skipped or accepted else 1,
        **evidence_counts,
        **_blocker_summary_counts(report),
        **_role_order_signature_counts(report),
        **_source_table_audit_counts(report),
        **_source_table_homfly_variant_resolution_fields(report),
        **_source_table_audit_source_match_resolution_fields(report),
        "notes": notes,
    }


def _analysis_summary_from_alexander_admissible_minor_normalization_audit(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    skipped = bool(report.get("skipped", False))
    all_equivalent = bool(
        report.get("all_nonzero_minors_laurent_unit_equivalent", False)
    )
    bounded_certified = bool(
        report.get("bounded_admissible_minor_normalization_certified", False)
    )
    checked = _optional_count(report.get("checked_nonzero_minor_count")) or 0
    failed_nonzero = _optional_count(report.get("failed_nonzero_minor_count")) or 0
    complete = bool(report.get("complete_combination_scan", False))
    nonzero_coverage_complete = bool(
        report.get("nonzero_minor_coverage_complete", False)
    )
    truncated = bool(report.get("truncated", False))
    normalization_class_rows = report.get("normalization_class_counts")
    class_count = _optional_count(report.get("normalization_class_count"))
    if class_count is None and isinstance(normalization_class_rows, list):
        class_count = len(normalization_class_rows)
    if class_count is None:
        class_count = 0
    largest_class = _optional_count(
        report.get("admissible_minor_normalization_largest_class_minor_count")
    )
    if largest_class is None:
        largest_class = _optional_count(
            report.get("largest_normalization_class_minor_count")
        )
    if largest_class is None and isinstance(normalization_class_rows, list):
        row_counts = [
            _optional_count(row.get("minor_count"))
            for row in normalization_class_rows
            if isinstance(row, Mapping)
        ]
        largest_class = max(
            (count for count in row_counts if count is not None),
            default=0,
        )
    if largest_class is None:
        largest_class = 0
    mismatch_witness_count = _optional_count(
        report.get("normalization_mismatch_witness_count")
    )
    mismatch_witness_limit = _optional_count(
        report.get("normalization_mismatch_witness_limit")
    )
    mismatch_witness_truncated = report.get("normalization_mismatch_witness_truncated")
    representative_witness = report.get("normalization_representative_witness")
    representative_minor = None
    if isinstance(representative_witness, Mapping):
        representative_minor = _optional_count(
            representative_witness.get("minor_index")
        )
    witness_parts = []
    if mismatch_witness_count is not None:
        if mismatch_witness_limit is not None:
            witness_parts.append(
                f"mismatch_witnesses={mismatch_witness_count}/{mismatch_witness_limit}"
            )
        else:
            witness_parts.append(f"mismatch_witnesses={mismatch_witness_count}")
    if isinstance(mismatch_witness_truncated, bool):
        witness_parts.append(
            f"mismatch_witness_truncated={mismatch_witness_truncated}"
        )
    if representative_minor is not None:
        witness_parts.append(f"representative_minor={representative_minor}")
    witness_note = "; ".join(witness_parts)
    if witness_note:
        witness_note += "; "

    check_results = (not skipped, all_equivalent, bounded_certified)
    required = len(check_results)
    passed = sum(1 for item in check_results if item)
    failed = required - passed

    evidence_counts = {
        key: 0
        for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS
    }
    evidence_counts["bounded_scanned_gcd_checked_nonzero_minor_count"] = checked
    evidence_counts["bounded_scanned_gcd_failed_nonzero_minor_count"] = failed_nonzero
    evidence_counts["bounded_scanned_gcd_scanned_minor_count"] = (
        _optional_count(report.get("scanned_minor_count")) or 0
    )
    evidence_counts["bounded_scanned_gcd_complete_scan_count"] = 1 if complete else 0
    evidence_counts["bounded_scanned_gcd_nonzero_minor_coverage_complete_count"] = (
        1 if nonzero_coverage_complete else 0
    )
    evidence_counts["bounded_scanned_gcd_truncated_count"] = 1 if truncated else 0
    evidence_counts["bounded_scanned_gcd_complete_certified_count"] = (
        1 if bounded_certified else 0
    )
    evidence_counts.update(_bounded_scanned_gcd_admissible_minor_counts(report))
    evidence_counts.update(_admissible_minor_normalization_counts(report))
    evidence_counts.update(_compact_host_evidence_counts(report))

    representative = report.get("normalized_representative_polynomial")
    notes = _append_note(
        _notes_text(report),
        (
            "admissible_minor_normalization="
            f"representative={representative or 'none'}; "
            f"all_nonzero_laurent_unit_equivalent={all_equivalent}; "
            f"bounded_certified={bounded_certified}; "
            f"checked_nonzero_minors={checked}; "
            f"failed_nonzero_minors={failed_nonzero}; "
            f"normalization_classes={class_count}; "
            f"largest_class_minors={largest_class}; "
            f"{witness_note}"
            f"complete_combination_scan={complete}; "
            f"nonzero_coverage_complete={nonzero_coverage_complete}; "
            f"truncated={truncated}"
        ),
    )
    notes = _append_alexander_wirtinger_relation_shape_notes(report, notes)
    notes = _append_alexander_witness_notes(report, notes)
    notes = _append_note(
        notes,
        (
            "full_admissible_minor_normalization_certified=False; "
            "full_invariant_certified=False"
        ),
    )
    notes = _append_alexander_blocker_notes(report, notes)
    notes = _append_admissible_minor_scan_note(report, notes)

    return {
        "name": name or "multi-variable Alexander admissible-minor normalization",
        "source_method": "multivariable_alexander_admissible_minor_normalization_audit",
        "claim_scope": str(
            report.get(
                "claim_scope",
                "bounded_scanned_fox_admissible_minor_laurent_unit_normalization",
            )
        ),
        "accepted": bounded_certified and not skipped,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": failed,
        "certification_scope": str(
            report.get(
                "claim_scope",
                "bounded_scanned_fox_admissible_minor_laurent_unit_normalization",
            )
        ),
        "certification_applicable_count": 0 if skipped else 1,
        "certification_certified_count": (
            1 if bounded_certified and not skipped else 0
        ),
        "certification_uncertified_count": (
            0 if skipped or bounded_certified else 1
        ),
        **evidence_counts,
        **_blocker_summary_counts(report),
        **_role_order_signature_counts(report),
        **_source_table_audit_counts(report),
        **_source_table_homfly_variant_resolution_fields(report),
        **_source_table_audit_source_match_resolution_fields(report),
        "notes": notes,
    }


def _analysis_summary_from_homfly_input_certification_evidence(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    skipped = bool(report.get("skipped", False))
    certified_for_input = bool(report.get("certified_for_input", False))
    frontier_exhausted = bool(report.get("frontier_exhausted", False))
    terminal_applicable = report.get("terminal_contribution_audit_skipped") is False
    terminal_matched = bool(report.get("terminal_contribution_matches_result", False))

    check_results = [
        not skipped,
        certified_for_input,
        frontier_exhausted,
    ]
    if terminal_applicable:
        check_results.append(terminal_matched)
    required = len(check_results)
    passed = sum(1 for item in check_results if item)
    failed = required - passed
    accepted = not skipped and certified_for_input and frontier_exhausted and (
        terminal_matched if terminal_applicable else True
    )

    iterative_solved_depth = report.get("iterative_solved_depth")
    evidence_counts = {
        key: 0
        for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS
    }
    evidence_counts["input_certification_recursion_node_count"] = (
        _optional_count(report.get("recursion_nodes")) or 0
    )
    evidence_counts["input_certification_terminal_reduction_count"] = (
        _optional_count(report.get("terminal_reduction_count")) or 0
    )
    evidence_counts["input_certification_frontier_count"] = (
        _optional_count(report.get("frontier_count")) or 0
    )
    evidence_counts["input_certification_frontier_reason_count"] = (
        _optional_count(report.get("frontier_reason_count")) or 0
    )
    evidence_counts["input_certification_truncated_count"] = (
        1 if report.get("truncated") is True else 0
    )
    evidence_counts["input_certification_zero_crossing_count"] = (
        1 if report.get("zero_crossing_certified") is True else 0
    )
    evidence_counts["input_certification_iterative_attempt_count"] = (
        _optional_count(report.get("iterative_attempt_count")) or 0
    )
    evidence_counts["input_certification_iterative_solved_count"] = (
        1 if iterative_solved_depth is not None else 0
    )
    evidence_counts["input_certification_iterative_max_solved_depth"] = (
        _optional_count(iterative_solved_depth) or 0
    )
    evidence_counts[
        "input_certification_terminal_contribution_audit_applicable_count"
    ] = 1 if terminal_applicable else 0
    evidence_counts[
        "input_certification_terminal_contribution_matched_count"
    ] = 1 if terminal_matched else 0
    evidence_counts[
        "input_certification_terminal_contribution_failed_count"
    ] = 1 if terminal_applicable and not terminal_matched else 0
    evidence_counts.update(_bounded_homfly_maturity_path_count_fields(report))
    evidence_counts.update(_compact_host_evidence_counts(report))

    notes = _append_note(
        _notes_text(report),
        (
            f"certified_for_input={certified_for_input}; "
            f"frontier_exhausted={frontier_exhausted}; "
            f"zero_crossing_certified={report.get('zero_crossing_certified') is True}; "
            f"frontier={report.get('frontier_count')}; "
            f"frontier_reasons={report.get('frontier_reason_count')}; "
            f"truncated={report.get('truncated') is True}; "
            f"terminal_contribution_skipped={not terminal_applicable}; "
            f"terminal_contribution_matched={terminal_matched}"
        ),
    )
    notes = _append_bounded_homfly_maturity_path_note(report, notes)
    notes = _append_homfly_reduction_contribution_witness_notes(report, notes)
    notes = _append_homfly_frontier_witness_summary_notes(report, notes)
    notes = _append_blocker_summary_note(
        report,
        notes,
        blockers_key="certification_blockers",
        count_key="certification_blocker_count",
        first_key="first_certification_blocker",
    )
    notes = _append_blocker_summary_note(
        report,
        notes,
        blockers_key="homfly_completion_blockers",
        count_key="homfly_completion_blocker_count",
        first_key="first_homfly_completion_blocker",
    )
    notes = _append_homfly_blocker_detail_notes(report, notes)
    notes = _append_note(
        notes,
        (
            "full_table_normalization_certified=False; "
            "arbitrary_diagram_coverage_certified=False"
        ),
    )
    claim_scope = str(
        report.get(
            "claim_scope",
            "recursive_frontier_exhaustion_for_one_signed_pd_input",
        )
    )

    return {
        "name": name or "HOMFLY input certification evidence",
        "source_method": "homfly_input_certification_evidence",
        "claim_scope": claim_scope,
        "accepted": accepted,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": failed,
        "certification_scope": claim_scope,
        "certification_applicable_count": 0 if skipped else 1,
        "certification_certified_count": 1 if accepted else 0,
        "certification_uncertified_count": 0 if skipped or accepted else 1,
        **evidence_counts,
        **_blocker_summary_counts(report),
        **_role_order_signature_counts(report),
        **_source_table_audit_counts(report),
        **_source_table_homfly_variant_resolution_fields(report),
        **_source_table_audit_source_match_resolution_fields(report),
        "notes": notes,
    }


def _analysis_summary_from_homfly_skein_identity_audit(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    crossing_count = _optional_count(report.get("crossing_count")) or 0
    checked = _optional_count(report.get("checked_crossing_count")) or 0
    crossing_audits = report.get("crossing_audits")
    audit_rows = crossing_audits if isinstance(crossing_audits, list) else []
    matched_crossings = sum(
        1
        for row in audit_rows
        if isinstance(row, Mapping)
        and row.get("matched") is True
        and row.get("skipped") is not True
    )
    if not audit_rows and crossing_count == 0 and report.get("matched") is True:
        matched_crossings = 0
    skipped_crossings = sum(
        1
        for row in audit_rows
        if isinstance(row, Mapping) and row.get("skipped") is True
    )
    truncated_crossings = sum(
        1
        for row in audit_rows
        if isinstance(row, Mapping) and row.get("truncated") is True
    )
    if not audit_rows and report.get("truncated") is True:
        truncated_crossings = 1
    frontier_count = _homfly_skein_branch_frontier_count(audit_rows)

    required = crossing_count
    passed = min(matched_crossings, required)
    failed = max(0, required - passed)
    matched = bool(report.get("matched", False))
    skipped = bool(report.get("skipped", False))
    truncated = bool(report.get("truncated", False))
    accepted = matched and not skipped and not truncated

    evidence_counts = {
        key: 0
        for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS
    }
    evidence_counts["input_certification_frontier_count"] = frontier_count
    evidence_counts["input_certification_truncated_count"] = truncated_crossings
    evidence_counts.update(_compact_host_evidence_counts(report))

    notes = _append_note(
        _notes_text(report),
        (
            f"skein_checked={checked}; "
            f"skein_matched={matched_crossings}; "
            f"skein_skipped={skipped_crossings}; "
            f"branch_frontier={frontier_count}; "
            f"truncated_crossings={truncated_crossings}"
        ),
    )
    notes = _append_homfly_frontier_witness_summary_notes(report, notes)
    notes = _append_note(
        notes,
        (
            "full_table_normalization_certified=False; "
            "arbitrary_diagram_coverage_certified=False"
        ),
    )
    claim_scope = str(
        report.get(
            "claim_scope",
            "local_homfly_skein_identity_for_signed_pd_input",
        )
    )

    return {
        "name": name or "HOMFLY skein identity audit",
        "source_method": "homfly_skein_identity_audit",
        "claim_scope": claim_scope,
        "accepted": accepted,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": failed,
        "certification_scope": claim_scope,
        "certification_applicable_count": required,
        "certification_certified_count": passed,
        "certification_uncertified_count": failed,
        **evidence_counts,
        **_blocker_summary_counts(report),
        **_role_order_signature_counts(report),
        **_source_table_audit_counts(report),
        **_source_table_homfly_variant_resolution_fields(report),
        **_source_table_audit_source_match_resolution_fields(report),
        "notes": notes,
    }


def _homfly_skein_branch_frontier_count(audit_rows: Iterable[Any]) -> int:
    frontier_count = 0
    for row in audit_rows:
        if not isinstance(row, Mapping):
            continue
        branches = row.get("branches")
        if not isinstance(branches, Mapping):
            continue
        for branch in branches.values():
            if not isinstance(branch, Mapping):
                continue
            frontier_count += _optional_count(branch.get("frontier_count")) or 0
    return frontier_count


def _analysis_summary_from_alexander_wirtinger_fox_audit(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    skipped = bool(report.get("skipped", False))
    presentation = bool(report.get("presentation_valid", False))
    jacobian = bool(report.get("fox_jacobian_valid", False))
    minors = bool(report.get("fox_square_minor_scan_valid", False))
    consistent = bool(report.get("input_chain_consistent", False)) and not skipped
    check_results = (presentation, jacobian, minors)
    required = len(check_results)
    passed = sum(1 for item in check_results if item)
    if skipped:
        passed = 0
    failed = required - passed

    evidence_counts = {
        key: 0
        for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS
    }
    evidence_counts["wirtinger_fox_relation_count"] = (
        _optional_count(report.get("relation_count")) or 0
    )
    evidence_counts["wirtinger_fox_generator_count"] = (
        _optional_count(report.get("generator_count")) or 0
    )
    evidence_counts["wirtinger_fox_scanned_minor_count"] = (
        _optional_count(report.get("scanned_minor_count")) or 0
    )
    evidence_counts["wirtinger_fox_invalid_minor_reference_count"] = (
        _optional_count(report.get("invalid_minor_reference_count")) or 0
    )
    evidence_counts["wirtinger_fox_invalid_normalization_count"] = (
        _optional_count(report.get("invalid_normalization_count")) or 0
    )
    evidence_counts["wirtinger_fox_complete_scan_count"] = (
        1 if report.get("complete_combination_scan") is True else 0
    )
    evidence_counts["wirtinger_fox_truncated_count"] = (
        1 if report.get("truncated") is True else 0
    )
    evidence_counts.update(_compact_host_evidence_counts(report))

    notes = _append_note(
        _notes_text(report),
        (
            f"presentation_valid={presentation}; "
            f"fox_jacobian_valid={jacobian}; "
            f"fox_square_minor_scan_valid={minors}; "
            f"input_chain_consistent={consistent}"
        ),
    )
    notes = _append_alexander_wirtinger_relation_shape_notes(report, notes)
    notes = _append_alexander_witness_notes(report, notes)
    notes = _append_note(
        notes,
        (
            "full_admissible_minor_normalization_certified=False; "
            "full_invariant_certified=False"
        ),
    )

    certified = 1 if consistent else 0
    return {
        "name": name or "multi-variable Alexander Wirtinger/Fox audit",
        "source_method": "multivariable_alexander_wirtinger_fox_audit",
        "claim_scope": str(
            report.get(
                "claim_scope",
                "input_wirtinger_presentation_and_fox_matrix_consistency",
            )
        ),
        "accepted": consistent,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": failed,
        "certification_scope": str(
            report.get(
                "claim_scope",
                "input_wirtinger_presentation_and_fox_matrix_consistency",
            )
        ),
        "certification_applicable_count": 0 if skipped else 1,
        "certification_certified_count": certified,
        "certification_uncertified_count": 0 if skipped else 1 - certified,
        **evidence_counts,
        **_blocker_summary_counts(report),
        **_role_order_signature_counts(report),
        **_source_table_audit_counts(report),
        **_source_table_homfly_variant_resolution_fields(report),
        **_source_table_audit_source_match_resolution_fields(report),
        "notes": notes,
    }


def _analysis_summary_from_alexander_improved_result(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    result = report.get("result")
    result_mapping = result if isinstance(result, Mapping) else {}
    source_audit = report.get("source_audit")
    source_audit_mapping = source_audit if isinstance(source_audit, Mapping) else {}
    improved_audit = report.get("improved_audit")
    audit = improved_audit if isinstance(improved_audit, Mapping) else {}

    source_polynomial = report.get("source_polynomial")
    improved_candidate = report.get("improved_candidate_polynomial") or (
        source_audit_mapping.get("improved_candidate_polynomial")
    )
    result_polynomial = result_mapping.get("multivariable_alexander_polynomial")
    exact = bool(audit.get("candidate_is_exact_scanned_gcd", False))
    complete = bool(audit.get("complete_scanned_gcd_certified", False))
    quotient = bool(audit.get("quotient_gcd_certified", False))
    accepted = bool(report.get("accepted", False))
    skipped = bool(report.get("skipped", False))

    check_results = (
        bool(improved_candidate),
        exact,
        complete,
        quotient,
    )
    required = len(check_results)
    passed = sum(1 for item in check_results if item)
    if skipped or not accepted:
        passed = min(passed, required - 1)
    failed = required - passed

    evidence_counts = {
        key: 0
        for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS
    }
    evidence_counts["bounded_scanned_gcd_checked_nonzero_minor_count"] = (
        _optional_count(audit.get("checked_nonzero_minor_count")) or 0
    )
    evidence_counts["bounded_scanned_gcd_failed_nonzero_minor_count"] = (
        _optional_count(audit.get("failed_nonzero_minor_count")) or 0
    )
    evidence_counts["bounded_scanned_gcd_scanned_minor_count"] = (
        _optional_count(audit.get("scanned_minor_count")) or 0
    )
    evidence_counts["bounded_scanned_gcd_division_record_count"] = (
        _optional_count(audit.get("division_record_count")) or 0
    )
    evidence_counts["bounded_scanned_gcd_complete_scan_count"] = (
        1
        if audit.get("complete_combination_scan") is True or complete
        else 0
    )
    evidence_counts["bounded_scanned_gcd_nonzero_minor_coverage_complete_count"] = (
        1
        if audit.get("nonzero_minor_coverage_complete") is True or complete
        else 0
    )
    evidence_counts["bounded_scanned_gcd_truncated_count"] = (
        1 if audit.get("truncated") is True else 0
    )
    evidence_counts["bounded_scanned_gcd_quotient_gcd_certified_count"] = (
        1 if quotient else 0
    )
    evidence_counts["bounded_scanned_gcd_complete_certified_count"] = (
        1 if complete else 0
    )
    evidence_counts["bounded_scanned_gcd_improved_candidate_count"] = (
        1 if improved_candidate else 0
    )
    evidence_counts.update(_bounded_scanned_gcd_admissible_minor_counts(audit))
    evidence_counts.update(_compact_host_evidence_counts(report))

    notes = _append_note(
        _notes_text(report),
        (
            f"accepted={accepted}; skipped={skipped}; "
            f"exact_scanned_gcd={exact}; "
            f"complete_scanned_gcd_certified={complete}; "
            f"quotient_gcd_certified={quotient}"
        ),
    )
    if source_polynomial:
        notes = _append_note(notes, f"source_polynomial={source_polynomial}")
    if improved_candidate:
        notes = _append_note(notes, f"improved_candidate={improved_candidate}")
    if result_polynomial:
        notes = _append_note(notes, f"result_polynomial={result_polynomial}")
    quotient_method = audit.get("quotient_gcd_method")
    quotient_polynomial = audit.get("quotient_gcd_polynomial")
    if quotient_method or quotient_polynomial:
        quotient_text = str(quotient_polynomial or "unknown")
        if quotient_method:
            quotient_text += f" via {quotient_method}"
        notes = _append_note(notes, f"quotient_gcd={quotient_text}")
    notes = _append_alexander_witness_notes(report, notes)
    notes = _append_note(
        notes,
        (
            "full_admissible_minor_normalization_certified=False; "
            "full_invariant_certified=False"
        ),
    )
    notes = _append_admissible_minor_scan_note(audit, notes)

    certification_certified = 1 if accepted and not skipped and passed == required else 0
    return {
        "name": name or "multi-variable Alexander improved scanned gcd",
        "source_method": "multivariable_alexander_improve_scanned_gcd_result",
        "claim_scope": "bounded_scanned_fox_minor_improved_candidate",
        "accepted": accepted,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": failed,
        "certification_scope": "bounded_scanned_fox_minor_improved_candidate",
        "certification_applicable_count": 1,
        "certification_certified_count": certification_certified,
        "certification_uncertified_count": 1 - certification_certified,
        **evidence_counts,
        **_blocker_summary_counts(report),
        **_role_order_signature_counts(report),
        **_source_table_audit_counts(report),
        **_source_table_homfly_variant_resolution_fields(report),
        **_source_table_audit_source_match_resolution_fields(report),
        "notes": notes,
    }


def _is_gpu_smoke_artifact(report: Mapping[str, Any]) -> bool:
    artifact_kind = report.get("artifact_kind")
    return (
        report.get("artifact_schema_version") == 1
        and isinstance(artifact_kind, str)
        and artifact_kind.startswith("gpu_smoke_")
    )


def _is_imgui_framebuffer_smoke_artifact(report: Mapping[str, Any]) -> bool:
    return (
        report.get("artifact_schema_version") == 1
        and report.get("artifact_kind")
        in {
            "imgui_test_stub_framebuffer_smoke",
            "imgui_production_renderer_framebuffer_pack",
        }
    )


def _is_imgui_source_open_request_smoke_artifact(
    report: Mapping[str, Any],
) -> bool:
    return (
        report.get("artifact_schema_version") == 1
        and report.get("artifact_kind") == "imgui_source_open_request_smoke"
    )


def _is_validate_table_source_metadata_report(report: Mapping[str, Any]) -> bool:
    summary = report.get("source_metadata_summary")
    return (
        isinstance(summary, Mapping)
        and summary.get("claim_scope") == "table_source_metadata_scan"
    )


def _is_imgui_signed_pd_snapshot_artifact(
    report: Mapping[str, Any],
) -> bool:
    return report.get("method") == "imgui_signed_pd_snapshot"


def _is_imgui_signed_pd_recompute_scheduler_smoke_artifact(
    report: Mapping[str, Any],
) -> bool:
    return (
        report.get("artifact_schema_version") == 1
        and report.get("artifact_kind")
        == "imgui_signed_pd_recompute_scheduler_smoke"
    )


def _is_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact(
    report: Mapping[str, Any],
) -> bool:
    return (
        report.get("artifact_schema_version") == 1
        and report.get("artifact_kind")
        == "imgui_signed_pd_thread_pool_recompute_scheduler_smoke"
    )


def _is_imgui_windows_retained_artifacts_manifest(
    report: Mapping[str, Any],
) -> bool:
    return (
        report.get("artifact_schema_version") == 1
        and report.get("artifact_kind")
        == "imgui_windows_retained_artifacts_manifest"
    )


def _is_imgui_real_kernel_loader_smoke_artifact(
    report: Mapping[str, Any],
) -> bool:
    return (
        report.get("artifact_schema_version") == 1
        and report.get("artifact_kind") == "imgui_real_kernel_loader_smoke"
    )


def _is_rust_wheel_retained_manifest(
    report: Mapping[str, Any],
) -> bool:
    return (
        report.get("artifact_schema_version") == 1
        and report.get("artifact_kind") == "rust_wheel_retained_metadata_manifest"
    )


def _analysis_summary_from_imgui_framebuffer_smoke_artifact(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    counts = _imgui_framebuffer_smoke_analysis_counts(report)
    artifact_kind = str(report.get("artifact_kind") or "")
    production_artifact = artifact_kind == "imgui_production_renderer_framebuffer_pack"
    check_results = [
        counts["imgui_framebuffer_smoke_passed_count"] == 1,
        counts["imgui_framebuffer_smoke_framebuffer_touched_count"] == 1,
        counts["imgui_framebuffer_smoke_estimated_nonzero_pixel_count"] > 0,
    ]
    if production_artifact:
        check_results.extend(
            [
                counts["imgui_framebuffer_smoke_real_backend_verified_count"] == 1,
                counts["imgui_framebuffer_smoke_screenshot_verified_count"] == 1,
            ]
        )
    required = len(check_results)
    passed = sum(check_results)
    certified = production_artifact and passed == required
    certification_scope = (
        "production_imgui_renderer_framebuffer_verification"
        if production_artifact
        else ""
    )
    return {
        "name": name or _display_name(artifact_kind),
        "source_method": artifact_kind,
        "claim_scope": str(report.get("claim_scope") or ""),
        "accepted": passed == required,
        "certified": certified,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": required - passed,
        "certification_scope": certification_scope,
        "certification_applicable_count": 1 if production_artifact else 0,
        "certification_certified_count": 1 if certified else 0,
        "certification_uncertified_count": (
            1 if production_artifact and not certified else 0
        ),
        **{key: 0 for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS},
        **{key: 0 for key in _COMPACT_HOST_EVIDENCE_KEYS},
        **{key: 0 for key in _ANALYSIS_ROLE_ORDER_SIGNATURE_KEYS},
        **{key: 0 for key in _ANALYSIS_SOURCE_TABLE_AUDIT_KEYS},
        **counts,
        "imgui_framebuffer_smoke_passed": (
            counts["imgui_framebuffer_smoke_passed_count"] == 1
        ),
        "imgui_framebuffer_smoke_real_backend_verified": (
            counts["imgui_framebuffer_smoke_real_backend_verified_count"] == 1
        ),
        "imgui_framebuffer_smoke_screenshot_verified": (
            counts["imgui_framebuffer_smoke_screenshot_verified_count"] == 1
        ),
        "imgui_framebuffer_smoke_framebuffer_touched": (
            counts["imgui_framebuffer_smoke_framebuffer_touched_count"] == 1
        ),
        "notes": _imgui_framebuffer_smoke_analysis_notes(report, counts),
    }


def _imgui_framebuffer_smoke_analysis_counts(
    report: Mapping[str, Any],
) -> dict[str, int]:
    return {
        "imgui_framebuffer_smoke_artifact_count": 1,
        "imgui_framebuffer_smoke_passed_count": _count_true(report.get("passed")),
        "imgui_framebuffer_smoke_real_backend_verified_count": _count_true(
            report.get("real_graphics_backend_framebuffer_verified")
        ),
        "imgui_framebuffer_smoke_screenshot_verified_count": _count_true(
            report.get("screenshot_verified")
        ),
        "imgui_framebuffer_smoke_framebuffer_touched_count": _count_true(
            (_optional_count(report.get("framebuffer_touched")) or 0) > 0
        ),
        "imgui_framebuffer_smoke_estimated_nonzero_pixel_count": (
            _optional_count(report.get("estimated_nonzero_pixels")) or 0
        ),
        "imgui_framebuffer_smoke_render_frame_count": (
            _optional_count(report.get("render_frame_count")) or 0
        ),
        "imgui_framebuffer_smoke_geometry_nonempty_count": _count_true(
            report.get("last_render_geometry_nonempty")
        ),
        "imgui_framebuffer_smoke_geometry_canvas_count": (
            _optional_count(report.get("last_render_geometry_canvas_count")) or 0
        ),
        "imgui_framebuffer_smoke_geometry_filled_rect_count": (
            _optional_count(report.get("last_render_geometry_filled_rect_count"))
            or 0
        ),
        "imgui_framebuffer_smoke_geometry_rect_count": (
            _optional_count(report.get("last_render_geometry_rect_count")) or 0
        ),
        "imgui_framebuffer_smoke_geometry_polyline_count": (
            _optional_count(report.get("last_render_geometry_polyline_count")) or 0
        ),
        "imgui_framebuffer_smoke_geometry_marker_count": (
            _optional_count(report.get("last_render_geometry_marker_count")) or 0
        ),
        "imgui_framebuffer_smoke_rect_filled_count": (
            _optional_count(report.get("rect_filled_count")) or 0
        ),
        "imgui_framebuffer_smoke_rect_count": (
            _optional_count(report.get("rect_count")) or 0
        ),
        "imgui_framebuffer_smoke_polyline_count": (
            _optional_count(report.get("polyline_count")) or 0
        ),
        "imgui_framebuffer_smoke_circle_filled_count": (
            _optional_count(report.get("circle_filled_count")) or 0
        ),
        "imgui_framebuffer_smoke_text_count": (
            _optional_count(report.get("text_count")) or 0
        ),
    }


def _imgui_framebuffer_smoke_analysis_notes(
    report: Mapping[str, Any],
    counts: Mapping[str, int],
) -> str:
    artifact_kind = str(report.get("artifact_kind") or "")
    production_artifact = artifact_kind == "imgui_production_renderer_framebuffer_pack"
    notes = _append_note(
        _notes_text(report),
        (
            "imgui_framebuffer_smoke="
            f"artifact_kind={_note_field_value(report.get('artifact_kind'))}; "
            f"claim_scope={_note_field_value(report.get('claim_scope'))}; "
            f"repository_test_stub={str(not production_artifact).lower()}; "
            "draw_list_framebuffer_estimate="
            f"{str(not production_artifact).lower()}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "imgui_framebuffer_smoke_counts="
            f"render_frames={counts['imgui_framebuffer_smoke_render_frame_count']}; "
            "estimated_nonzero_pixels="
            f"{counts['imgui_framebuffer_smoke_estimated_nonzero_pixel_count']}; "
            f"text={counts['imgui_framebuffer_smoke_text_count']}; "
            f"polylines={counts['imgui_framebuffer_smoke_polyline_count']}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "imgui_framebuffer_smoke_claims="
            "real_graphics_backend_framebuffer_verified="
            f"{_note_bool_from_count(counts['imgui_framebuffer_smoke_real_backend_verified_count'])}; "
            "screenshot_verified="
            f"{_note_bool_from_count(counts['imgui_framebuffer_smoke_screenshot_verified_count'])}; "
            "production_renderer_verified="
            f"{str(production_artifact and counts['imgui_framebuffer_smoke_real_backend_verified_count'] == 1 and counts['imgui_framebuffer_smoke_screenshot_verified_count'] == 1).lower()}"
        ),
    )
    if production_artifact:
        return _append_note(
            notes,
            "production renderer screenshot/framebuffer verification artifact",
        )
    return _append_note(
        notes,
        "repository test-stub framebuffer estimate only; not production renderer screenshot/framebuffer evidence",
    )


def _analysis_summary_from_imgui_source_open_request_smoke_artifact(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    counts = _imgui_source_open_request_smoke_analysis_counts(report)
    source_url = str(report.get("source_url") or "")
    consumed_source_url = str(report.get("consumed_source_url") or "")
    required = 4
    passed = sum(
        (
            counts["imgui_source_open_request_smoke_passed_count"] == 1,
            counts["imgui_source_open_request_smoke_scheme_allowed_count"] == 1,
            counts["imgui_source_open_request_smoke_request_consumed_count"] == 1,
            counts["imgui_source_open_request_smoke_request_cleared_count"] == 1,
        )
    )
    return {
        "name": name or _display_name("imgui_source_open_request_smoke"),
        "source_method": "imgui_source_open_request_smoke",
        "claim_scope": str(report.get("claim_scope") or ""),
        "accepted": passed == required,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": required - passed,
        "certification_scope": "",
        "certification_applicable_count": 0,
        "certification_certified_count": 0,
        "certification_uncertified_count": 0,
        **{key: 0 for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS},
        **{key: 0 for key in _COMPACT_HOST_EVIDENCE_KEYS},
        **{key: 0 for key in _ANALYSIS_ROLE_ORDER_SIGNATURE_KEYS},
        **{key: 0 for key in _ANALYSIS_SOURCE_TABLE_AUDIT_KEYS},
        **counts,
        "imgui_source_open_request_smoke_passed": (
            counts["imgui_source_open_request_smoke_passed_count"] == 1
        ),
        "imgui_source_open_request_smoke_opened_by_real_host": (
            counts["imgui_source_open_request_smoke_opened_by_real_host_count"] == 1
        ),
        "imgui_source_open_request_smoke_scheme_allowed": (
            counts["imgui_source_open_request_smoke_scheme_allowed_count"] == 1
        ),
        "imgui_source_open_request_smoke_request_consumed": (
            counts["imgui_source_open_request_smoke_request_consumed_count"] == 1
        ),
        "imgui_source_open_request_smoke_request_cleared": (
            counts["imgui_source_open_request_smoke_request_cleared_count"] == 1
        ),
        "imgui_source_open_request_smoke_final_pending": (
            counts["imgui_source_open_request_smoke_final_pending_count"] == 1
        ),
        "imgui_source_open_request_smoke_host_action": str(
            report.get("host_action") or ""
        ),
        "imgui_source_open_request_smoke_selected_fixture_name": str(
            report.get("selected_fixture_name") or ""
        ),
        "imgui_source_open_request_smoke_selected_fixture_source": str(
            report.get("selected_fixture_source") or ""
        ),
        "imgui_source_open_request_smoke_source_url": source_url,
        "imgui_source_open_request_smoke_consumed_source_url": consumed_source_url,
        "imgui_source_open_request_smoke_consumed_source_url_matched": (
            bool(source_url) and consumed_source_url == source_url
        ),
        "notes": _imgui_source_open_request_smoke_analysis_notes(report, counts),
    }


def _imgui_source_open_request_smoke_analysis_counts(
    report: Mapping[str, Any],
) -> dict[str, int]:
    return {
        "imgui_source_open_request_smoke_artifact_count": 1,
        "imgui_source_open_request_smoke_passed_count": _count_true(
            report.get("passed")
        ),
        "imgui_source_open_request_smoke_opened_by_real_host_count": _count_true(
            report.get("opened_by_real_host")
        ),
        "imgui_source_open_request_smoke_scheme_allowed_count": _count_true(
            report.get("scheme_allowed")
        ),
        "imgui_source_open_request_smoke_request_consumed_count": _count_true(
            report.get("request_consumed_by_smoke")
        ),
        "imgui_source_open_request_smoke_request_cleared_count": _count_true(
            report.get("request_cleared_after_consumption")
        ),
        "imgui_source_open_request_smoke_final_pending_count": _count_true(
            report.get("final_request_pending")
        ),
        "imgui_source_open_request_smoke_source_url_length_total": (
            len(str(report.get("source_url") or ""))
        ),
        "imgui_source_open_request_smoke_selected_source_url_length_total": (
            _optional_count(report.get("selected_fixture_source_url_length")) or 0
        ),
        "imgui_source_open_request_smoke_requested_source_url_length_total": (
            _optional_count(report.get("requested_fixture_source_url_length")) or 0
        ),
    }


def _imgui_source_open_request_smoke_analysis_notes(
    report: Mapping[str, Any],
    counts: Mapping[str, int],
) -> str:
    notes = _append_note(
        _notes_text(report),
        (
            "imgui_source_open_request_smoke="
            f"artifact_kind={_note_field_value(report.get('artifact_kind'))}; "
            f"claim_scope={_note_field_value(report.get('claim_scope'))}; "
            f"host_action={_note_field_value(report.get('host_action'))}; "
            f"source={_note_field_value(report.get('selected_fixture_source'))}; "
            f"fixture={_note_field_value(report.get('selected_fixture_name'))}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "imgui_source_open_request_smoke_counts="
            "source_url_length="
            f"{counts['imgui_source_open_request_smoke_source_url_length_total']}; "
            "selected_source_url_length="
            f"{counts['imgui_source_open_request_smoke_selected_source_url_length_total']}; "
            "requested_source_url_length="
            f"{counts['imgui_source_open_request_smoke_requested_source_url_length_total']}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "imgui_source_open_request_smoke_claims="
            "opened_by_real_host="
            f"{_note_bool_from_count(counts['imgui_source_open_request_smoke_opened_by_real_host_count'])}; "
            "scheme_allowed="
            f"{_note_bool_from_count(counts['imgui_source_open_request_smoke_scheme_allowed_count'])}; "
            "request_consumed_by_smoke="
            f"{_note_bool_from_count(counts['imgui_source_open_request_smoke_request_consumed_count'])}; "
            "request_cleared_after_consumption="
            f"{_note_bool_from_count(counts['imgui_source_open_request_smoke_request_cleared_count'])}; "
            "final_request_pending="
            f"{_note_bool_from_count(counts['imgui_source_open_request_smoke_final_pending_count'])}"
        ),
    )
    return _append_note(
        notes,
        "host-polled source-opening request contract only; not production platform URL-opening evidence",
    )


def _analysis_summary_from_validate_table_source_metadata_report(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    counts = _validate_table_source_metadata_analysis_counts(report)
    required = 4
    passed = sum(
        (
            counts["validate_table_source_metadata_valid_count"] == 1,
            counts[
                "validate_table_source_metadata_provenance_review_ready_count"
            ]
            == 1,
            counts[
                "validate_table_source_metadata_summary_consistency_matched_count"
            ]
            == 1,
            counts[
                "validate_table_source_metadata_blocker_summary_consistency_matched_count"
            ]
            == 1,
        )
    )
    return {
        "name": name or _display_name("validate_table_source_metadata_report"),
        "source_method": "validate_table_source_metadata_report",
        "claim_scope": "table_source_metadata_scan",
        "accepted": passed == required,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": required - passed,
        "certification_scope": "table_source_metadata_scan",
        "certification_applicable_count": 0,
        "certification_certified_count": 0,
        "certification_uncertified_count": 0,
        **{key: 0 for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS},
        **{key: 0 for key in _COMPACT_HOST_EVIDENCE_KEYS},
        **{key: 0 for key in _ANALYSIS_ROLE_ORDER_SIGNATURE_KEYS},
        **{key: 0 for key in _ANALYSIS_SOURCE_TABLE_AUDIT_KEYS},
        **counts,
        "validate_table_source_metadata_provenance_review_ready": (
            counts[
                "validate_table_source_metadata_provenance_review_ready_count"
            ]
            == 1
        ),
        "validate_table_source_metadata_summary_consistency_matched": (
            counts[
                "validate_table_source_metadata_summary_consistency_matched_count"
            ]
            == 1
        ),
        "validate_table_source_metadata_blocker_summary_consistency_matched": (
            counts[
                "validate_table_source_metadata_blocker_summary_consistency_matched_count"
            ]
            == 1
        ),
        "validate_table_source_metadata_all_conventions_match_expected": (
            counts[
                "validate_table_source_metadata_all_conventions_match_expected_count"
            ]
            == 1
        ),
        "validate_table_source_metadata_table_correctness_certified": (
            counts[
                "validate_table_source_metadata_table_correctness_certified_count"
            ]
            == 1
        ),
        "validate_table_source_metadata_external_source_verified": (
            counts["validate_table_source_metadata_external_source_verified_count"]
            == 1
        ),
        "notes": _validate_table_source_metadata_analysis_notes(report, counts),
    }


def _validate_table_source_metadata_analysis_counts(
    report: Mapping[str, Any],
) -> dict[str, int]:
    summary = report.get("source_metadata_summary")
    summary_mapping = summary if isinstance(summary, Mapping) else {}
    summary_consistency = summary_mapping.get("summary_consistency")
    summary_consistency_mapping = (
        summary_consistency if isinstance(summary_consistency, Mapping) else {}
    )
    blocker_consistency = summary_mapping.get("provenance_blocker_summary_consistency")
    blocker_consistency_mapping = (
        blocker_consistency if isinstance(blocker_consistency, Mapping) else {}
    )
    source_value_counts = _mapping_or_empty(summary_mapping.get("source_value_counts"))
    source_value_rows = _mapping_or_empty(summary_mapping.get("source_value_rows"))
    source_url_scheme_counts = _mapping_or_empty(
        summary_mapping.get("source_url_scheme_counts")
    )
    source_url_domain_counts = _mapping_or_empty(
        summary_mapping.get("source_url_domain_counts")
    )
    issues = report.get("issues")
    issue_count = len(issues) if isinstance(issues, list) else 0
    return {
        "validate_table_source_metadata_artifact_count": 1,
        "validate_table_source_metadata_valid_count": _count_true(
            report.get("valid")
        ),
        "validate_table_source_metadata_issue_count": issue_count,
        "validate_table_source_metadata_record_count": (
            _optional_count(report.get("record_count")) or 0
        ),
        "validate_table_source_metadata_provenance_review_ready_count": _count_true(
            summary_mapping.get("provenance_review_ready")
        ),
        "validate_table_source_metadata_provenance_blocker_count": (
            _optional_count(summary_mapping.get("provenance_blocker_count")) or 0
        ),
        "validate_table_source_metadata_summary_consistency_matched_count": _count_true(
            summary_consistency_mapping.get("matched")
        ),
        "validate_table_source_metadata_blocker_summary_consistency_matched_count": _count_true(
            blocker_consistency_mapping.get("matched")
        ),
        "validate_table_source_metadata_source_count": (
            _optional_count(summary_mapping.get("source_count")) or 0
        ),
        "validate_table_source_metadata_source_value_label_count": len(
            source_value_counts
        ),
        "validate_table_source_metadata_source_value_row_count_total": (
            _mapping_sequence_value_count_total(source_value_rows)
        ),
        "validate_table_source_metadata_source_url_count": (
            _optional_count(summary_mapping.get("source_url_count")) or 0
        ),
        "validate_table_source_metadata_source_url_scheme_count": len(
            source_url_scheme_counts
        ),
        "validate_table_source_metadata_source_url_domain_count": len(
            source_url_domain_counts
        ),
        "validate_table_source_metadata_valid_source_url_count": (
            _optional_count(summary_mapping.get("valid_source_url_count")) or 0
        ),
        "validate_table_source_metadata_invalid_source_url_count": (
            _optional_count(summary_mapping.get("invalid_source_url_count")) or 0
        ),
        "validate_table_source_metadata_source_url_missing_scheme_count": (
            _optional_count(summary_mapping.get("source_url_missing_scheme_count"))
            or 0
        ),
        "validate_table_source_metadata_source_url_missing_domain_count": (
            _optional_count(summary_mapping.get("source_url_missing_domain_count"))
            or 0
        ),
        "validate_table_source_metadata_source_url_issue_code_total": (
            _optional_count(summary_consistency_mapping.get("source_url_issue_code_total"))
            or 0
        ),
        "validate_table_source_metadata_missing_source_count": (
            _optional_count(summary_mapping.get("missing_source_count")) or 0
        ),
        "validate_table_source_metadata_missing_source_url_count": (
            _optional_count(summary_mapping.get("missing_source_url_count")) or 0
        ),
        "validate_table_source_metadata_source_url_without_source_count": (
            _optional_count(summary_mapping.get("source_url_without_source_count")) or 0
        ),
        "validate_table_source_metadata_all_records_have_source_count": _count_true(
            summary_mapping.get("all_records_have_source")
        ),
        "validate_table_source_metadata_all_source_records_have_source_url_count": _count_true(
            summary_mapping.get("all_source_records_have_source_url")
        ),
        "validate_table_source_metadata_all_source_urls_have_source_count": _count_true(
            summary_mapping.get("all_source_urls_have_source")
        ),
        "validate_table_source_metadata_all_source_urls_are_http_or_https_count": _count_true(
            summary_mapping.get("all_source_urls_are_http_or_https")
        ),
        "validate_table_source_metadata_source_completeness_row_count": (
            _optional_count(
                summary_consistency_mapping.get("source_completeness_row_count")
            )
            or 0
        ),
        "validate_table_source_metadata_source_completeness_row_count_matched_count": _count_true(
            summary_consistency_mapping.get(
                "source_completeness_row_count_matched"
            )
        ),
        "validate_table_source_metadata_source_completeness_source_count_matched_count": _count_true(
            summary_consistency_mapping.get(
                "source_completeness_source_count_matched"
            )
        ),
        "validate_table_source_metadata_source_completeness_source_url_count_matched_count": _count_true(
            summary_consistency_mapping.get(
                "source_completeness_source_url_count_matched"
            )
        ),
        "validate_table_source_metadata_source_completeness_invalid_url_count_matched_count": _count_true(
            summary_consistency_mapping.get(
                "source_completeness_invalid_url_count_matched"
            )
        ),
        "validate_table_source_metadata_known_limitations_count": (
            _optional_count(summary_mapping.get("known_limitations_count")) or 0
        ),
        "validate_table_source_metadata_convention_metadata_without_name_count": (
            _optional_count(
                summary_mapping.get("convention_metadata_without_name_count")
            )
            or 0
        ),
        "validate_table_source_metadata_convention_mismatch_count": (
            _optional_count(summary_mapping.get("convention_mismatch_count")) or 0
        ),
        "validate_table_source_metadata_all_conventions_match_expected_count": (
            _count_true(summary_mapping.get("all_conventions_match_expected"))
        ),
        "validate_table_source_metadata_table_correctness_certified_count": _count_true(
            summary_mapping.get("table_correctness_certified")
        ),
        "validate_table_source_metadata_external_source_verified_count": _count_true(
            summary_mapping.get("external_source_verified")
        ),
    }


def _validate_table_source_metadata_analysis_notes(
    report: Mapping[str, Any],
    counts: Mapping[str, int],
) -> str:
    summary = report.get("source_metadata_summary")
    summary_mapping = summary if isinstance(summary, Mapping) else {}
    source_value_rows = _mapping_or_empty(summary_mapping.get("source_value_rows"))
    source_url_scheme_counts = _mapping_or_empty(
        summary_mapping.get("source_url_scheme_counts")
    )
    source_url_scheme_rows = _mapping_or_empty(
        summary_mapping.get("source_url_scheme_rows")
    )
    source_url_domain_counts = _mapping_or_empty(
        summary_mapping.get("source_url_domain_counts")
    )
    source_url_domain_rows = _mapping_or_empty(
        summary_mapping.get("source_url_domain_rows")
    )
    source_url_issue_code_counts = _mapping_or_empty(
        summary_mapping.get("source_url_issue_code_counts")
    )
    source_url_issue_code_rows = _mapping_or_empty(
        summary_mapping.get("source_url_issue_code_rows")
    )
    issues = report.get("issues")
    issue_rows = issues if isinstance(issues, Sequence) else []
    provenance_blocker_codes = summary_mapping.get("provenance_blocker_codes")
    missing_source_rows = summary_mapping.get("missing_source_rows")
    missing_source_url_rows = summary_mapping.get("missing_source_url_rows")
    source_url_without_source_rows = summary_mapping.get(
        "source_url_without_source_rows"
    )
    convention_mismatch_rows = summary_mapping.get("convention_mismatch_rows")
    known_limitations_rows = summary_mapping.get("known_limitations_rows")
    convention_metadata_without_name_rows = summary_mapping.get(
        "convention_metadata_without_name_rows"
    )
    notes = _append_note(
        _notes_text(report),
        (
            "validate_table_source_metadata="
            f"record_count={counts['validate_table_source_metadata_record_count']}; "
            f"valid={_note_bool_from_count(counts['validate_table_source_metadata_valid_count'])}; "
            "provenance_review_ready="
            f"{_note_bool_from_count(counts['validate_table_source_metadata_provenance_review_ready_count'])}; "
            f"blockers={counts['validate_table_source_metadata_provenance_blocker_count']}; "
            f"issues={counts['validate_table_source_metadata_issue_count']}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "validate_table_source_metadata_sources="
            f"sources={counts['validate_table_source_metadata_source_count']}; "
            "source_labels="
            f"{counts['validate_table_source_metadata_source_value_label_count']}; "
            "source_label_rows="
            f"{counts['validate_table_source_metadata_source_value_row_count_total']}; "
            f"source_urls={counts['validate_table_source_metadata_source_url_count']}; "
            "source_url_schemes="
            f"{counts['validate_table_source_metadata_source_url_scheme_count']}; "
            "source_url_domains="
            f"{counts['validate_table_source_metadata_source_url_domain_count']}; "
            "valid_source_urls="
            f"{counts['validate_table_source_metadata_valid_source_url_count']}; "
            "invalid_source_urls="
            f"{counts['validate_table_source_metadata_invalid_source_url_count']}; "
            "convention_metadata_without_name="
            f"{counts['validate_table_source_metadata_convention_metadata_without_name_count']}; "
            "convention_mismatches="
            f"{counts['validate_table_source_metadata_convention_mismatch_count']}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "validate_table_source_metadata_source_completeness="
            f"rows={counts['validate_table_source_metadata_source_completeness_row_count']}; "
            "row_count_matched="
            f"{_note_bool_from_count(counts['validate_table_source_metadata_source_completeness_row_count_matched_count'])}; "
            "source_count_matched="
            f"{_note_bool_from_count(counts['validate_table_source_metadata_source_completeness_source_count_matched_count'])}; "
            "source_url_count_matched="
            f"{_note_bool_from_count(counts['validate_table_source_metadata_source_completeness_source_url_count_matched_count'])}; "
            "invalid_url_count_matched="
            f"{_note_bool_from_count(counts['validate_table_source_metadata_source_completeness_invalid_url_count_matched_count'])}"
        ),
    )
    source_value_signature = _mapping_sequence_note_signature(source_value_rows)
    if source_value_signature:
        notes = _append_note(
            notes,
            "validate_table_source_metadata_source_value_rows="
            f"{source_value_signature}",
        )
    scheme_count_signature = _mapping_count_note_signature(source_url_scheme_counts)
    if scheme_count_signature:
        notes = _append_note(
            notes,
            "validate_table_source_metadata_source_url_schemes="
            f"{scheme_count_signature}",
        )
    scheme_row_signature = _mapping_sequence_note_signature(source_url_scheme_rows)
    if scheme_row_signature:
        notes = _append_note(
            notes,
            "validate_table_source_metadata_source_url_scheme_rows="
            f"{scheme_row_signature}",
        )
    domain_count_signature = _mapping_count_note_signature(source_url_domain_counts)
    if domain_count_signature:
        notes = _append_note(
            notes,
            "validate_table_source_metadata_source_url_domains="
            f"{domain_count_signature}",
        )
    domain_row_signature = _mapping_sequence_note_signature(source_url_domain_rows)
    if domain_row_signature:
        notes = _append_note(
            notes,
            "validate_table_source_metadata_source_url_domain_rows="
            f"{domain_row_signature}",
        )
    issue_code_signature = _mapping_count_note_signature(source_url_issue_code_counts)
    if issue_code_signature:
        notes = _append_note(
            notes,
            "validate_table_source_metadata_source_url_issue_codes="
            f"{issue_code_signature}",
        )
    issue_code_row_signature = _mapping_sequence_note_signature(
        source_url_issue_code_rows
    )
    if issue_code_row_signature:
        notes = _append_note(
            notes,
            "validate_table_source_metadata_source_url_issue_code_rows="
            f"{issue_code_row_signature}",
        )
    issue_path_signature = _sequence_note_signature(
        [
            issue.get("path")
            for issue in issue_rows
            if isinstance(issue, Mapping) and issue.get("path")
        ]
    )
    if issue_path_signature != "none":
        notes = _append_note(
            notes,
            "validate_table_source_metadata_issue_paths="
            f"{issue_path_signature}",
        )
    issue_message_signature = _sequence_note_signature(
        [
            issue.get("message")
            for issue in issue_rows
            if isinstance(issue, Mapping) and issue.get("message")
        ]
    )
    if issue_message_signature != "none":
        notes = _append_note(
            notes,
            "validate_table_source_metadata_issue_messages="
            f"{issue_message_signature}",
        )
    if isinstance(provenance_blocker_codes, Sequence) and not isinstance(
        provenance_blocker_codes,
        (str, bytes),
    ):
        notes = _append_note(
            notes,
            "validate_table_source_metadata_provenance_blocker_codes="
            + ",".join(
                _note_field_value(code) for code in provenance_blocker_codes
            ),
        )
    if isinstance(missing_source_rows, Sequence) and not isinstance(
        missing_source_rows,
        (str, bytes),
    ):
        notes = _append_note(
            notes,
            "validate_table_source_metadata_missing_source_rows="
            + _sequence_note_signature(missing_source_rows),
        )
    if isinstance(missing_source_url_rows, Sequence) and not isinstance(
        missing_source_url_rows,
        (str, bytes),
    ):
        notes = _append_note(
            notes,
            "validate_table_source_metadata_missing_source_url_rows="
            + _sequence_note_signature(missing_source_url_rows),
        )
    if isinstance(source_url_without_source_rows, Sequence) and not isinstance(
        source_url_without_source_rows,
        (str, bytes),
    ):
        notes = _append_note(
            notes,
            "validate_table_source_metadata_source_url_without_source_rows="
            + _sequence_note_signature(source_url_without_source_rows),
        )
    if isinstance(convention_mismatch_rows, Sequence) and not isinstance(
        convention_mismatch_rows,
        (str, bytes),
    ):
        notes = _append_note(
            notes,
            "validate_table_source_metadata_convention_mismatch_rows="
            + _sequence_note_signature(convention_mismatch_rows),
        )
    if isinstance(known_limitations_rows, Sequence) and not isinstance(
        known_limitations_rows,
        (str, bytes),
    ):
        notes = _append_note(
            notes,
            "validate_table_source_metadata_known_limitations_rows="
            + _sequence_note_signature(known_limitations_rows),
        )
    if isinstance(
        convention_metadata_without_name_rows,
        Sequence,
    ) and not isinstance(convention_metadata_without_name_rows, (str, bytes)):
        notes = _append_note(
            notes,
            "validate_table_source_metadata_convention_metadata_without_name_rows="
            + _sequence_note_signature(convention_metadata_without_name_rows),
        )
    notes = _append_note(
        notes,
        (
            "validate_table_source_metadata_claims="
            "table_correctness_certified="
            f"{_note_bool_from_count(counts['validate_table_source_metadata_table_correctness_certified_count'])}; "
            "external_source_verified="
            f"{_note_bool_from_count(counts['validate_table_source_metadata_external_source_verified_count'])}; "
            "expected_convention="
            f"{_note_field_value(summary_mapping.get('expected_convention'))}"
        ),
    )
    return _append_note(
        notes,
        "validate-table source metadata is import/reviewer evidence only; not external table correctness or invariant normalization evidence",
    )


def _analysis_summary_from_imgui_signed_pd_snapshot_artifact(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    counts = _imgui_signed_pd_snapshot_analysis_counts(report)
    required = 6
    passed = sum(
        (
            counts["imgui_signed_pd_snapshot_valid_count"] == 1,
            counts["imgui_signed_pd_snapshot_validation_available_count"] == 1,
            counts["imgui_signed_pd_snapshot_component_count_matches_count"] == 1,
            counts["imgui_signed_pd_snapshot_revision_present_count"] == 1,
            counts["imgui_signed_pd_snapshot_invalid_role_order_count_total"] == 0,
            counts["imgui_signed_pd_snapshot_invalid_flow_label_count_total"] == 0,
        )
    )
    return {
        "name": name or _display_name("imgui_signed_pd_snapshot"),
        "source_method": "imgui_signed_pd_snapshot",
        "claim_scope": "host_exported_imgui_signed_pd_snapshot_shape",
        "accepted": passed == required,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": required - passed,
        "certification_scope": "",
        "certification_applicable_count": 0,
        "certification_certified_count": 0,
        "certification_uncertified_count": 0,
        **{key: 0 for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS},
        **{key: 0 for key in _COMPACT_HOST_EVIDENCE_KEYS},
        **{key: 0 for key in _ANALYSIS_ROLE_ORDER_SIGNATURE_KEYS},
        **{key: 0 for key in _ANALYSIS_SOURCE_TABLE_AUDIT_KEYS},
        **counts,
        "imgui_signed_pd_snapshot_valid": (
            counts["imgui_signed_pd_snapshot_valid_count"] == 1
        ),
        "imgui_signed_pd_snapshot_validation_available": (
            counts["imgui_signed_pd_snapshot_validation_available_count"] == 1
        ),
        "imgui_signed_pd_snapshot_component_count_matches": (
            counts["imgui_signed_pd_snapshot_component_count_matches_count"] == 1
        ),
        "imgui_signed_pd_snapshot_revision_present": (
            counts["imgui_signed_pd_snapshot_revision_present_count"] == 1
        ),
        "notes": _imgui_signed_pd_snapshot_analysis_notes(report, counts),
    }


def _imgui_signed_pd_snapshot_analysis_counts(
    report: Mapping[str, Any],
) -> dict[str, int]:
    validation = _mapping_or_empty(report.get("validation"))
    crossing_count = (
        _optional_count(validation.get("crossing_count"))
        or _sequence_count(report.get("crossings"))
    )
    return {
        "imgui_signed_pd_snapshot_artifact_count": 1,
        "imgui_signed_pd_snapshot_valid_count": _count_true(report.get("valid")),
        "imgui_signed_pd_snapshot_validation_available_count": _count_true(
            bool(validation)
        ),
        "imgui_signed_pd_snapshot_component_count_matches_count": _count_true(
            validation.get("component_count_matches")
        ),
        "imgui_signed_pd_snapshot_revision_present_count": _count_true(
            _optional_count(report.get("signed_pd_revision")) is not None
        ),
        "imgui_signed_pd_snapshot_crossing_count_total": crossing_count,
        "imgui_signed_pd_snapshot_component_count_total": (
            _optional_count(report.get("component_count")) or 0
        ),
        "imgui_signed_pd_snapshot_validation_component_count_total": (
            _optional_count(validation.get("component_count")) or 0
        ),
        "imgui_signed_pd_snapshot_edge_label_slot_count_total": (
            _optional_count(validation.get("edge_label_slot_count")) or 0
        ),
        "imgui_signed_pd_snapshot_unique_edge_label_count_total": (
            _optional_count(validation.get("unique_edge_label_count")) or 0
        ),
        "imgui_signed_pd_snapshot_nonpositive_edge_label_count_total": (
            _optional_count(validation.get("nonpositive_edge_label_count")) or 0
        ),
        "imgui_signed_pd_snapshot_unexpected_occurrence_label_count_total": (
            _optional_count(validation.get("labels_with_unexpected_occurrence_count"))
            or 0
        ),
        "imgui_signed_pd_snapshot_invalid_flow_label_count_total": (
            _optional_count(validation.get("labels_with_invalid_flow_count")) or 0
        ),
        "imgui_signed_pd_snapshot_explicit_role_order_count_total": (
            _optional_count(validation.get("explicit_role_order_count")) or 0
        ),
        "imgui_signed_pd_snapshot_invalid_role_order_count_total": (
            _optional_count(validation.get("invalid_role_order_count")) or 0
        ),
        "imgui_signed_pd_snapshot_oriented_component_count_total": (
            _optional_count(validation.get("oriented_component_count")) or 0
        ),
    }


def _imgui_signed_pd_snapshot_analysis_notes(
    report: Mapping[str, Any],
    counts: Mapping[str, int],
) -> str:
    notes = _append_note(
        _notes_text(report),
        (
            "imgui_signed_pd_snapshot="
            f"component_count={counts['imgui_signed_pd_snapshot_component_count_total']}; "
            f"crossings={counts['imgui_signed_pd_snapshot_crossing_count_total']}; "
            "unique_edge_labels="
            f"{counts['imgui_signed_pd_snapshot_unique_edge_label_count_total']}; "
            "explicit_role_orders="
            f"{counts['imgui_signed_pd_snapshot_explicit_role_order_count_total']}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "imgui_signed_pd_snapshot_validation="
            "valid="
            f"{_note_bool_from_count(counts['imgui_signed_pd_snapshot_valid_count'])}; "
            "component_count_matches="
            f"{_note_bool_from_count(counts['imgui_signed_pd_snapshot_component_count_matches_count'])}; "
            "invalid_role_order_count="
            f"{counts['imgui_signed_pd_snapshot_invalid_role_order_count_total']}; "
            "labels_with_invalid_flow_count="
            f"{counts['imgui_signed_pd_snapshot_invalid_flow_label_count_total']}"
        ),
    )
    return _append_note(
        notes,
        "host-exported ImGui signed-PD JSON shape evidence only; not invariant computation evidence",
    )


def _analysis_summary_from_imgui_signed_pd_recompute_scheduler_smoke_artifact(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    counts = _imgui_signed_pd_recompute_scheduler_smoke_analysis_counts(report)
    required = 11
    passed = sum(
        (
            counts["imgui_signed_pd_recompute_scheduler_smoke_passed_count"] == 1,
            str(report.get("claim_scope") or "")
            == "host_owned_signed_pd_recompute_scheduler_contract",
            counts["imgui_signed_pd_recompute_scheduler_smoke_abi_matched_count"] == 1,
            counts[
                "imgui_signed_pd_recompute_scheduler_smoke_handoff_complete_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_recompute_scheduler_smoke_first_revision_reloaded_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_recompute_scheduler_smoke_stale_recompute_rejected_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_recompute_scheduler_smoke_current_revision_reloaded_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_recompute_scheduler_smoke_snapshot_hash_present_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_recompute_scheduler_smoke_requested_snapshot_cleared_count"
            ]
            == 1,
            counts["imgui_signed_pd_recompute_scheduler_smoke_host_queue_drained_count"]
            == 1,
            counts["imgui_signed_pd_recompute_scheduler_smoke_final_status_fresh_count"]
            == 1,
        )
    )
    return {
        "name": name
        or _display_name("imgui_signed_pd_recompute_scheduler_smoke"),
        "source_method": "imgui_signed_pd_recompute_scheduler_smoke",
        "claim_scope": str(report.get("claim_scope") or ""),
        "accepted": passed == required,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": required - passed,
        "certification_scope": "",
        "certification_applicable_count": 0,
        "certification_certified_count": 0,
        "certification_uncertified_count": 0,
        **{key: 0 for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS},
        **{key: 0 for key in _COMPACT_HOST_EVIDENCE_KEYS},
        **{key: 0 for key in _ANALYSIS_ROLE_ORDER_SIGNATURE_KEYS},
        **{key: 0 for key in _ANALYSIS_SOURCE_TABLE_AUDIT_KEYS},
        **counts,
        "imgui_signed_pd_recompute_scheduler_smoke_passed": (
            counts["imgui_signed_pd_recompute_scheduler_smoke_passed_count"] == 1
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_first_revision_reloaded": (
            counts[
                "imgui_signed_pd_recompute_scheduler_smoke_first_revision_reloaded_count"
            ]
            == 1
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_stale_recompute_rejected": (
            counts[
                "imgui_signed_pd_recompute_scheduler_smoke_stale_recompute_rejected_count"
            ]
            == 1
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_current_revision_reloaded": (
            counts[
                "imgui_signed_pd_recompute_scheduler_smoke_current_revision_reloaded_count"
            ]
            == 1
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_current_revision_rows_reloaded": (
            counts[
                "imgui_signed_pd_recompute_scheduler_smoke_current_revision_rows_reloaded_count"
            ]
            == 1
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_requested_snapshot_cleared": (
            counts[
                "imgui_signed_pd_recompute_scheduler_smoke_requested_snapshot_cleared_count"
            ]
            == 1
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_host_queue_drained": (
            counts["imgui_signed_pd_recompute_scheduler_smoke_host_queue_drained_count"]
            == 1
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_final_status_fresh": (
            counts["imgui_signed_pd_recompute_scheduler_smoke_final_status_fresh_count"]
            == 1
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_first_scope": str(
            report.get("first_scope") or ""
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_stale_scope": str(
            report.get("stale_scope") or ""
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_current_scope": str(
            report.get("current_scope") or ""
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_handoff_input_format": str(
            report.get("handoff_input_format") or ""
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_handoff_result_transport": str(
            report.get("handoff_result_transport") or ""
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_host_reload_payload": str(
            report.get("host_reload_payload") or ""
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_first_revision": (
            _optional_count(report.get("first_revision")) or 0
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_second_revision": (
            _optional_count(report.get("second_revision")) or 0
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_current_request_revision": (
            _optional_count(report.get("current_request_revision")) or 0
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_final_invariant_status_signed_pd_revision": (
            _optional_count(report.get("final_invariant_status_signed_pd_revision"))
            or 0
        ),
        "notes": _imgui_signed_pd_recompute_scheduler_smoke_analysis_notes(
            report,
            counts,
        ),
    }


def _imgui_signed_pd_recompute_scheduler_smoke_analysis_counts(
    report: Mapping[str, Any],
) -> dict[str, int]:
    snapshot_length_total = sum(
        _optional_count(report.get(key)) or 0
        for key in (
            "first_request_snapshot_json_length",
            "stale_request_snapshot_json_length",
            "current_request_snapshot_json_length",
        )
    )
    cli_handoff_metadata_count = sum(
        1
        for key in (
            "handoff_input_format",
            "handoff_result_transport",
            "homfly_cli_command",
            "alexander_cli_command",
            "host_reload_payload",
        )
        if report.get(key)
    )
    handoff_complete = (
        report.get("handoff_input_format") == "imgui_signed_pd_json"
        and report.get("handoff_result_transport") == "json_file"
        and report.get("homfly_cli_command") == "iroll homfly-pd"
        and report.get("alexander_cli_command") == "iroll multivariable-alexander-pd"
        and report.get("host_reload_payload")
        == "imgui-signed-pd-invariant-status-payload"
    )
    snapshot_hash_present = all(
        (_optional_count(report.get(key)) or 0) > 0
        for key in (
            "first_request_snapshot_fnv1a64",
            "stale_request_snapshot_fnv1a64",
            "current_request_snapshot_fnv1a64",
        )
    )
    final_status_stale = report.get("final_signed_pd_invariant_status_stale")
    final_request_stale = report.get("final_requested_recompute_stale")
    final_status_fresh = (
        final_status_stale in (False, 0)
        and final_request_stale in (False, 0)
        and report.get("requested_snapshot_json_cleared") is True
        and report.get("host_queue_drained") is True
    )
    return {
        "imgui_signed_pd_recompute_scheduler_smoke_artifact_count": 1,
        "imgui_signed_pd_recompute_scheduler_smoke_passed_count": _count_true(
            report.get("passed")
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_first_revision_reloaded_count": _count_true(
            report.get("first_revision_reloaded")
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_stale_recompute_rejected_count": _count_true(
            report.get("stale_recompute_rejected")
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_stale_results_rejected_count": _count_true(
            report.get("stale_results_rejected")
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_stale_error_revision_mismatch_count": _count_true(
            report.get("stale_error_mentions_revision_mismatch")
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_current_revision_reloaded_count": _count_true(
            report.get("current_revision_reloaded")
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_current_revision_rows_reloaded_count": _count_true(
            report.get("current_revision_rows_reloaded")
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_requested_snapshot_cleared_count": _count_true(
            report.get("requested_snapshot_json_cleared")
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_host_queue_drained_count": _count_true(
            report.get("host_queue_drained")
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_abi_matched_count": _count_true(
            report.get("imgui_abi_version") == 117
            and report.get("rust_c_abi_version") == 19
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_handoff_complete_count": _count_true(
            handoff_complete
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_snapshot_hash_present_count": _count_true(
            snapshot_hash_present
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_final_status_fresh_count": _count_true(
            final_status_fresh
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_first_result_count_total": (
            _optional_count(report.get("first_result_count")) or 0
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_stale_result_count_total": (
            _optional_count(report.get("stale_result_count")) or 0
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_current_result_count_total": (
            _optional_count(report.get("current_result_count")) or 0
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_final_invariant_status_count_total": (
            _optional_count(report.get("final_invariant_status_count")) or 0
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_snapshot_json_length_total": (
            snapshot_length_total
        ),
        "imgui_signed_pd_recompute_scheduler_smoke_cli_handoff_metadata_count": (
            cli_handoff_metadata_count
        ),
    }


def _imgui_signed_pd_recompute_scheduler_smoke_analysis_notes(
    report: Mapping[str, Any],
    counts: Mapping[str, int],
) -> str:
    notes = _append_note(
        _notes_text(report),
        (
            "imgui_signed_pd_recompute_scheduler_smoke="
            f"artifact_kind={_note_field_value(report.get('artifact_kind'))}; "
            f"claim_scope={_note_field_value(report.get('claim_scope'))}; "
            f"first_scope={_note_field_value(report.get('first_scope'))}; "
            f"stale_scope={_note_field_value(report.get('stale_scope'))}; "
            f"current_scope={_note_field_value(report.get('current_scope'))}; "
            "host_owned_mock_queue=true"
        ),
    )
    notes = _append_note(
        notes,
        (
            "imgui_signed_pd_recompute_scheduler_smoke_handoff="
            f"input_format={_note_field_value(report.get('handoff_input_format'))}; "
            "handoff_input_format="
            f"{_note_field_value(report.get('handoff_input_format'))}; "
            "handoff_result_transport="
            f"{_note_field_value(report.get('handoff_result_transport'))}; "
            "host_reload_payload="
            f"{_note_field_value(report.get('host_reload_payload'))}; "
            "file_handoff_metadata_only=true"
        ),
    )
    notes = _append_note(
        notes,
        (
            "imgui_signed_pd_recompute_scheduler_smoke_counts="
            "first_results="
            f"{counts['imgui_signed_pd_recompute_scheduler_smoke_first_result_count_total']}; "
            "stale_results="
            f"{counts['imgui_signed_pd_recompute_scheduler_smoke_stale_result_count_total']}; "
            "current_results="
            f"{counts['imgui_signed_pd_recompute_scheduler_smoke_current_result_count_total']}; "
            "final_invariant_statuses="
            f"{counts['imgui_signed_pd_recompute_scheduler_smoke_final_invariant_status_count_total']}; "
            "snapshot_json_length_total="
            f"{counts['imgui_signed_pd_recompute_scheduler_smoke_snapshot_json_length_total']}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "imgui_signed_pd_recompute_scheduler_smoke_claims="
            "first_revision_reloaded="
            f"{_note_bool_from_count(counts['imgui_signed_pd_recompute_scheduler_smoke_first_revision_reloaded_count'])}; "
            "stale_recompute_rejected="
            f"{_note_bool_from_count(counts['imgui_signed_pd_recompute_scheduler_smoke_stale_recompute_rejected_count'])}; "
            "current_revision_reloaded="
            f"{_note_bool_from_count(counts['imgui_signed_pd_recompute_scheduler_smoke_current_revision_reloaded_count'])}; "
            "requested_snapshot_json_cleared="
            f"{_note_bool_from_count(counts['imgui_signed_pd_recompute_scheduler_smoke_requested_snapshot_cleared_count'])}; "
            "host_queue_drained="
            f"{_note_bool_from_count(counts['imgui_signed_pd_recompute_scheduler_smoke_host_queue_drained_count'])}; "
            "final_status_fresh="
            f"{_note_bool_from_count(counts['imgui_signed_pd_recompute_scheduler_smoke_final_status_fresh_count'])}; "
            "native_homfly_cpp_computation_claimed=false; "
            "native_alexander_cpp_computation_claimed=false; "
            "production_scheduler_completion_claimed=false"
        ),
    )
    return _append_note(
        notes,
        "host-owned signed-PD recompute scheduler contract only; not native HOMFLY/Alexander C++ computation evidence",
    )


def _analysis_summary_from_imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    counts = _imgui_signed_pd_thread_pool_recompute_scheduler_smoke_analysis_counts(
        report
    )
    required = 16
    passed = sum(
        (
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_passed_count"
            ]
            == 1,
            str(report.get("claim_scope") or "")
            == "host_owned_thread_pool_signed_pd_recompute_scheduler_contract",
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_abi_matched_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_handoff_complete_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_recompute_rejected_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_result_rejected_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_revision_reloaded_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_snapshot_hash_present_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_requested_snapshot_cleared_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_progress_completed_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_progress_inactive_after_completion_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_final_status_fresh_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_request_lifecycle_complete_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_request_lifecycle_complete_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_thread_pool_worker_count_matched_count"
            ]
            == 1,
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_loaded_revision_current_count"
            ]
            == 1,
        )
    )
    return {
        "name": name
        or _display_name("imgui_signed_pd_thread_pool_recompute_scheduler_smoke"),
        "source_method": "imgui_signed_pd_thread_pool_recompute_scheduler_smoke",
        "claim_scope": str(report.get("claim_scope") or ""),
        "accepted": passed == required,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": required - passed,
        "certification_scope": "",
        "certification_applicable_count": 0,
        "certification_certified_count": 0,
        "certification_uncertified_count": 0,
        **{key: 0 for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS},
        **{key: 0 for key in _COMPACT_HOST_EVIDENCE_KEYS},
        **{key: 0 for key in _ANALYSIS_ROLE_ORDER_SIGNATURE_KEYS},
        **{key: 0 for key in _ANALYSIS_SOURCE_TABLE_AUDIT_KEYS},
        **counts,
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_passed": (
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_passed_count"
            ]
            == 1
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_recompute_rejected": (
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_recompute_rejected_count"
            ]
            == 1
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_revision_reloaded": (
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_revision_reloaded_count"
            ]
            == 1
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_requested_snapshot_cleared": (
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_requested_snapshot_cleared_count"
            ]
            == 1
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_progress_completed": (
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_progress_completed_count"
            ]
            == 1
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_progress_inactive_after_completion": (
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_progress_inactive_after_completion_count"
            ]
            == 1
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_final_status_fresh": (
            counts[
                "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_final_status_fresh_count"
            ]
            == 1
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_scope": str(
            report.get("stale_scope") or ""
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_scope": str(
            report.get("current_scope") or ""
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_request_scope": str(
            report.get("current_request_scope") or ""
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_handoff_input_format": str(
            report.get("handoff_input_format") or ""
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_handoff_result_transport": str(
            report.get("handoff_result_transport") or ""
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_host_reload_payload": str(
            report.get("host_reload_payload") or ""
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_first_revision": (
            _optional_count(report.get("first_revision")) or 0
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_second_revision": (
            _optional_count(report.get("second_revision")) or 0
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_loaded_revision": (
            _optional_count(report.get("current_loaded_revision")) or 0
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_request_revision": (
            _optional_count(report.get("current_request_revision")) or 0
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_final_invariant_status_signed_pd_revision": (
            _optional_count(report.get("final_invariant_status_signed_pd_revision"))
            or 0
        ),
        "notes": _imgui_signed_pd_thread_pool_recompute_scheduler_smoke_analysis_notes(
            report,
            counts,
        ),
    }


def _imgui_signed_pd_thread_pool_recompute_scheduler_smoke_analysis_counts(
    report: Mapping[str, Any],
) -> dict[str, int]:
    snapshot_length_total = sum(
        _optional_count(report.get(key)) or 0
        for key in (
            "stale_request_snapshot_json_length",
            "current_request_snapshot_json_length",
        )
    )
    cli_handoff_metadata_count = sum(
        1
        for key in (
            "handoff_input_format",
            "handoff_result_transport",
            "homfly_cli_command",
            "alexander_cli_command",
            "host_reload_payload",
        )
        if report.get(key)
    )
    handoff_complete = (
        report.get("handoff_input_format") == "imgui_signed_pd_json"
        and report.get("handoff_result_transport") == "json_file"
        and report.get("homfly_cli_command") == "iroll homfly-pd"
        and report.get("alexander_cli_command") == "iroll multivariable-alexander-pd"
        and report.get("host_reload_payload")
        == "imgui-signed-pd-invariant-status-payload"
    )
    snapshot_hash_present = all(
        (_optional_count(report.get(key)) or 0) > 0
        for key in (
            "stale_request_snapshot_fnv1a64",
            "current_request_snapshot_fnv1a64",
        )
    )
    final_status_stale = report.get("final_signed_pd_invariant_status_stale")
    final_request_stale = report.get("final_requested_recompute_stale")
    final_status_fresh = (
        report.get("current_loaded_revision") == report.get("second_revision")
        and report.get("final_invariant_status_count")
        == report.get("current_result_count")
        and final_status_stale in (False, 0)
        and (_optional_count(report.get("final_requested_recompute_revision")) or 0)
        == 0
        and final_request_stale in (False, 0)
        and report.get("requested_snapshot_json_cleared") is True
    )
    stale_lifecycle_complete = (
        report.get("stale_request_queued") is True
        and report.get("stale_request_started") is True
        and report.get("stale_request_completed") is True
    )
    current_lifecycle_complete = (
        report.get("current_request_queued") is True
        and report.get("current_request_started") is True
        and report.get("current_request_completed") is True
    )
    return {
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_artifact_count": 1,
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_passed_count": _count_true(
            report.get("passed")
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_recompute_rejected_count": _count_true(
            report.get("stale_recompute_rejected")
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_result_rejected_count": _count_true(
            report.get("stale_result_rejected")
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_revision_reloaded_count": _count_true(
            report.get("current_revision_reloaded")
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_requested_snapshot_cleared_count": _count_true(
            report.get("requested_snapshot_json_cleared")
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_progress_completed_count": _count_true(
            report.get("progress_completed")
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_progress_inactive_after_completion_count": _count_true(
            report.get("progress_active_after_completion") is False
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_abi_matched_count": _count_true(
            report.get("imgui_abi_version") == 117
            and report.get("rust_c_abi_version") == 19
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_handoff_complete_count": _count_true(
            handoff_complete
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_snapshot_hash_present_count": _count_true(
            snapshot_hash_present
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_final_status_fresh_count": _count_true(
            final_status_fresh
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_request_lifecycle_complete_count": _count_true(
            stale_lifecycle_complete
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_request_lifecycle_complete_count": _count_true(
            current_lifecycle_complete
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_thread_pool_worker_count_matched_count": _count_true(
            report.get("thread_pool_worker_count") == 2
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_loaded_revision_current_count": _count_true(
            report.get("current_loaded_revision") == report.get("second_revision")
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_worker_count_total": (
            _optional_count(report.get("thread_pool_worker_count")) or 0
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_result_count_total": (
            _optional_count(report.get("stale_result_count")) or 0
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_result_count_total": (
            _optional_count(report.get("current_result_count")) or 0
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_final_invariant_status_count_total": (
            _optional_count(report.get("final_invariant_status_count")) or 0
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_snapshot_json_length_total": (
            snapshot_length_total
        ),
        "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_cli_handoff_metadata_count": (
            cli_handoff_metadata_count
        ),
    }


def _imgui_signed_pd_thread_pool_recompute_scheduler_smoke_analysis_notes(
    report: Mapping[str, Any],
    counts: Mapping[str, int],
) -> str:
    notes = _append_note(
        _notes_text(report),
        (
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke="
            f"artifact_kind={_note_field_value(report.get('artifact_kind'))}; "
            f"claim_scope={_note_field_value(report.get('claim_scope'))}; "
            f"stale_scope={_note_field_value(report.get('stale_scope'))}; "
            f"current_scope={_note_field_value(report.get('current_scope'))}; "
            "host_owned_thread_pool=true"
        ),
    )
    notes = _append_note(
        notes,
        (
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_handoff="
            "handoff_input_format="
            f"{_note_field_value(report.get('handoff_input_format'))}; "
            "handoff_result_transport="
            f"{_note_field_value(report.get('handoff_result_transport'))}; "
            "host_reload_payload="
            f"{_note_field_value(report.get('host_reload_payload'))}; "
            "file_handoff_metadata_only=true"
        ),
    )
    notes = _append_note(
        notes,
        (
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_counts="
            "thread_pool_worker_count="
            f"{counts['imgui_signed_pd_thread_pool_recompute_scheduler_smoke_worker_count_total']}; "
            "stale_results="
            f"{counts['imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_result_count_total']}; "
            "current_results="
            f"{counts['imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_result_count_total']}; "
            "final_invariant_statuses="
            f"{counts['imgui_signed_pd_thread_pool_recompute_scheduler_smoke_final_invariant_status_count_total']}; "
            "snapshot_json_length_total="
            f"{counts['imgui_signed_pd_thread_pool_recompute_scheduler_smoke_snapshot_json_length_total']}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "imgui_signed_pd_thread_pool_recompute_scheduler_smoke_claims="
            "stale_recompute_rejected="
            f"{_note_bool_from_count(counts['imgui_signed_pd_thread_pool_recompute_scheduler_smoke_stale_recompute_rejected_count'])}; "
            "current_revision_reloaded="
            f"{_note_bool_from_count(counts['imgui_signed_pd_thread_pool_recompute_scheduler_smoke_current_revision_reloaded_count'])}; "
            "requested_snapshot_json_cleared="
            f"{_note_bool_from_count(counts['imgui_signed_pd_thread_pool_recompute_scheduler_smoke_requested_snapshot_cleared_count'])}; "
            "progress_completed="
            f"{_note_bool_from_count(counts['imgui_signed_pd_thread_pool_recompute_scheduler_smoke_progress_completed_count'])}; "
            "progress_active_after_completion=false; "
            "final_status_fresh="
            f"{_note_bool_from_count(counts['imgui_signed_pd_thread_pool_recompute_scheduler_smoke_final_status_fresh_count'])}; "
            "native_homfly_cpp_computation_claimed=false; "
            "native_alexander_cpp_computation_claimed=false; "
            "production_scheduler_completion_claimed=false"
        ),
    )
    return _append_note(
        notes,
        "host-owned thread-pool signed-PD recompute scheduler contract only; not native HOMFLY/Alexander C++ computation evidence",
    )


def _analysis_summary_from_imgui_real_kernel_loader_smoke_artifact(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    counts = _imgui_real_kernel_loader_smoke_analysis_counts(report)
    required = 11
    passed = sum(
        (
            str(report.get("claim_scope") or "")
            == "runtime_loader_real_rust_dynamic_library_contract",
            counts["imgui_real_kernel_loader_smoke_passed_count"] == 1,
            counts["imgui_real_kernel_loader_smoke_abi_matched_count"] == 1,
            counts["imgui_real_kernel_loader_smoke_dynamic_library_loaded_count"]
            == 1,
            counts["imgui_real_kernel_loader_smoke_api_attached_count"] == 1,
            counts["imgui_real_kernel_loader_smoke_kernel_api_connected_count"]
            == 1,
            counts["imgui_real_kernel_loader_smoke_rust_kernel_available_count"]
            == 1,
            counts[
                "imgui_real_kernel_loader_smoke_callback_thread_pool_completed_count"
            ]
            == 1,
            counts[
                "imgui_real_kernel_loader_smoke_required_metadata_fields_present_count"
            ]
            == 1,
            counts[
                "imgui_real_kernel_loader_smoke_readiness_provenance_present_count"
            ]
            == 1,
            counts["imgui_real_kernel_loader_smoke_non_claim_false_count"] == 5,
        )
    )
    return {
        "name": name or _display_name("imgui_real_kernel_loader_smoke"),
        "source_method": "imgui_real_kernel_loader_smoke",
        "claim_scope": str(report.get("claim_scope") or ""),
        "accepted": passed == required,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": required - passed,
        "certification_scope": "",
        "certification_applicable_count": 0,
        "certification_certified_count": 0,
        "certification_uncertified_count": 0,
        **{key: 0 for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS},
        **{key: 0 for key in _COMPACT_HOST_EVIDENCE_KEYS},
        **{key: 0 for key in _ANALYSIS_ROLE_ORDER_SIGNATURE_KEYS},
        **{key: 0 for key in _ANALYSIS_SOURCE_TABLE_AUDIT_KEYS},
        **counts,
        "imgui_real_kernel_loader_smoke_passed": (
            counts["imgui_real_kernel_loader_smoke_passed_count"] == 1
        ),
        "imgui_real_kernel_loader_smoke_dynamic_library_loaded": (
            counts[
                "imgui_real_kernel_loader_smoke_dynamic_library_loaded_count"
            ]
            == 1
        ),
        "imgui_real_kernel_loader_smoke_callback_thread_pool_completed": (
            counts[
                "imgui_real_kernel_loader_smoke_callback_thread_pool_completed_count"
            ]
            == 1
        ),
        "imgui_real_kernel_loader_smoke_non_claims_preserved": (
            counts["imgui_real_kernel_loader_smoke_non_claim_false_count"] == 5
        ),
        "imgui_real_kernel_loader_smoke_metadata_schema_version": (
            _optional_count(report.get("metadata_schema_version")) or 0
        ),
        "imgui_real_kernel_loader_smoke_metadata_contract_version": str(
            report.get("metadata_contract_version") or ""
        ),
        "imgui_real_kernel_loader_smoke_required_metadata_fields_present": (
            counts[
                "imgui_real_kernel_loader_smoke_required_metadata_fields_present_count"
            ]
            == 1
        ),
        "imgui_real_kernel_loader_smoke_readiness_provenance_present": (
            counts[
                "imgui_real_kernel_loader_smoke_readiness_provenance_present_count"
            ]
            == 1
        ),
        "imgui_real_kernel_loader_smoke_ready_for_native_result_handles": bool(
            report.get("ready_for_native_result_handles")
        ),
        "imgui_real_kernel_loader_smoke_readiness_blocked_by_required_gates": bool(
            report.get("readiness_blocked_by_required_gates")
        ),
        "imgui_real_kernel_loader_smoke_python_file_recompute_boundary": bool(
            report.get("python_file_recompute_boundary")
        ),
        "notes": _imgui_real_kernel_loader_smoke_analysis_notes(report, counts),
    }


def _imgui_real_kernel_loader_smoke_analysis_counts(
    report: Mapping[str, Any],
) -> dict[str, int]:
    non_claim_fields = (
        "native_result_handles_complete",
        "complete_result_handle_abi",
        "release_grade_result_handles",
        "native_homfly_cpp_computation_claimed",
        "native_alexander_cpp_computation_claimed",
    )
    return {
        "imgui_real_kernel_loader_smoke_artifact_count": 1,
        "imgui_real_kernel_loader_smoke_passed_count": _count_true(
            report.get("passed")
        ),
        "imgui_real_kernel_loader_smoke_abi_matched_count": _count_true(
            report.get("imgui_abi_version") == 117
            and report.get("rust_c_abi_version") == 19
            and report.get("kernel_loader_abi_version") == 6
        ),
        "imgui_real_kernel_loader_smoke_dynamic_library_loaded_count": _count_true(
            report.get("dynamic_library_loaded")
        ),
        "imgui_real_kernel_loader_smoke_api_attached_count": _count_true(
            report.get("api_attached_to_panel")
        ),
        "imgui_real_kernel_loader_smoke_kernel_api_connected_count": _count_true(
            report.get("kernel_api_connected")
        ),
        "imgui_real_kernel_loader_smoke_rust_kernel_available_count": _count_true(
            report.get("rust_kernel_available")
        ),
        "imgui_real_kernel_loader_smoke_callback_thread_pool_completed_count": _count_true(
            report.get("callback_thread_pool_completed")
        ),
        "imgui_real_kernel_loader_smoke_worker_touches_imgui_context_count": _count_true(
            report.get("worker_touches_imgui_context")
        ),
        "imgui_real_kernel_loader_smoke_required_metadata_fields_present_count": _count_true(
            report.get("required_metadata_fields_present")
        ),
        "imgui_real_kernel_loader_smoke_readiness_provenance_present_count": _count_true(
            report.get("readiness_provenance_present")
        ),
        "imgui_real_kernel_loader_smoke_python_file_recompute_boundary_count": _count_true(
            report.get("python_file_recompute_boundary")
        ),
        "imgui_real_kernel_loader_smoke_native_result_handles_complete_count": _count_true(
            report.get("native_result_handles_complete")
        ),
        "imgui_real_kernel_loader_smoke_complete_result_handle_abi_count": _count_true(
            report.get("complete_result_handle_abi")
        ),
        "imgui_real_kernel_loader_smoke_release_grade_result_handles_count": _count_true(
            report.get("release_grade_result_handles")
        ),
        "imgui_real_kernel_loader_smoke_native_homfly_cpp_computation_claimed_count": _count_true(
            report.get("native_homfly_cpp_computation_claimed")
        ),
        "imgui_real_kernel_loader_smoke_native_alexander_cpp_computation_claimed_count": _count_true(
            report.get("native_alexander_cpp_computation_claimed")
        ),
        "imgui_real_kernel_loader_smoke_production_scheduler_completion_claimed_count": _count_true(
            report.get("production_scheduler_completion_claimed")
        ),
        "imgui_real_kernel_loader_smoke_signed_release_artifacts_published_count": _count_true(
            report.get("signed_release_artifacts_published")
        ),
        "imgui_real_kernel_loader_smoke_non_claim_false_count": sum(
            _count_true(report.get(field) is False) for field in non_claim_fields
        ),
        "imgui_real_kernel_loader_smoke_backend_report_byte_count_total": (
            _optional_count(report.get("backend_report_bytes")) or 0
        ),
        "imgui_real_kernel_loader_smoke_invariant_handles_report_byte_count_total": (
            _optional_count(report.get("invariant_result_handles_report_bytes"))
            or 0
        ),
        "imgui_real_kernel_loader_smoke_last_kernel_result_length_total": (
            _optional_count(report.get("last_kernel_result_length")) or 0
        ),
        "imgui_real_kernel_loader_smoke_distance_progress_total": (
            _optional_count(report.get("distance_progress_total")) or 0
        ),
        "imgui_real_kernel_loader_smoke_intersection_progress_total": (
            _optional_count(report.get("intersection_progress_total")) or 0
        ),
        "imgui_real_kernel_loader_smoke_distance_callback_count_total": (
            _optional_count(report.get("distance_callback_count")) or 0
        ),
        "imgui_real_kernel_loader_smoke_intersection_callback_count_total": (
            _optional_count(report.get("intersection_callback_count")) or 0
        ),
        "imgui_real_kernel_loader_smoke_required_metadata_field_count_total": (
            _optional_count(report.get("required_metadata_field_count")) or 0
        ),
    }


def _imgui_real_kernel_loader_smoke_analysis_notes(
    report: Mapping[str, Any],
    counts: Mapping[str, int],
) -> str:
    notes = _append_note(
        _notes_text(report),
        (
            "imgui_real_kernel_loader_smoke="
            f"artifact_kind={_note_field_value(report.get('artifact_kind'))}; "
            f"claim_scope={_note_field_value(report.get('claim_scope'))}; "
            "dynamic_library_loaded="
            f"{_note_bool_from_count(counts['imgui_real_kernel_loader_smoke_dynamic_library_loaded_count'])}; "
            "api_attached_to_panel="
            f"{_note_bool_from_count(counts['imgui_real_kernel_loader_smoke_api_attached_count'])}; "
            "kernel_api_connected="
            f"{_note_bool_from_count(counts['imgui_real_kernel_loader_smoke_kernel_api_connected_count'])}; "
            "rust_kernel_available="
            f"{_note_bool_from_count(counts['imgui_real_kernel_loader_smoke_rust_kernel_available_count'])}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "imgui_real_kernel_loader_smoke_callbacks="
            "thread_pool_completed="
            f"{_note_bool_from_count(counts['imgui_real_kernel_loader_smoke_callback_thread_pool_completed_count'])}; "
            "worker_touches_imgui_context="
            f"{_note_bool_from_count(counts['imgui_real_kernel_loader_smoke_worker_touches_imgui_context_count'])}; "
            "distance_progress="
            f"{counts['imgui_real_kernel_loader_smoke_distance_progress_total']}; "
            "intersection_progress="
            f"{counts['imgui_real_kernel_loader_smoke_intersection_progress_total']}; "
            "distance_callback_count="
            f"{counts['imgui_real_kernel_loader_smoke_distance_callback_count_total']}; "
            "intersection_callback_count="
            f"{counts['imgui_real_kernel_loader_smoke_intersection_callback_count_total']}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "imgui_real_kernel_loader_smoke_metadata="
            "backend_report_bytes="
            f"{counts['imgui_real_kernel_loader_smoke_backend_report_byte_count_total']}; "
            "invariant_result_handles_report_bytes="
            f"{counts['imgui_real_kernel_loader_smoke_invariant_handles_report_byte_count_total']}; "
            "required_metadata_field_count="
            f"{counts['imgui_real_kernel_loader_smoke_required_metadata_field_count_total']}; "
            "required_metadata_fields_present="
            f"{_note_bool_from_count(counts['imgui_real_kernel_loader_smoke_required_metadata_fields_present_count'])}; "
            "readiness_provenance_present="
            f"{_note_bool_from_count(counts['imgui_real_kernel_loader_smoke_readiness_provenance_present_count'])}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "imgui_real_kernel_loader_smoke_claims="
            "native_result_handles_complete="
            f"{_note_bool_from_count(counts['imgui_real_kernel_loader_smoke_native_result_handles_complete_count'])}; "
            "complete_result_handle_abi="
            f"{_note_bool_from_count(counts['imgui_real_kernel_loader_smoke_complete_result_handle_abi_count'])}; "
            "release_grade_result_handles="
            f"{_note_bool_from_count(counts['imgui_real_kernel_loader_smoke_release_grade_result_handles_count'])}; "
            "native_homfly_cpp_computation_claimed="
            f"{_note_bool_from_count(counts['imgui_real_kernel_loader_smoke_native_homfly_cpp_computation_claimed_count'])}; "
            "native_alexander_cpp_computation_claimed="
            f"{_note_bool_from_count(counts['imgui_real_kernel_loader_smoke_native_alexander_cpp_computation_claimed_count'])}"
        ),
    )
    return _append_note(
        notes,
        "runtime-loaded real Rust dynamic-library evidence only; not native HOMFLY/Alexander C++ computation or release completion evidence",
    )


def _analysis_summary_from_imgui_windows_retained_artifacts_manifest(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    counts = _imgui_windows_retained_artifacts_manifest_analysis_counts(report)
    required = 9
    passed = sum(
        (
            str(report.get("claim_scope") or "")
            == "windows_dear_imgui_retained_artifact_manifest",
            counts[
                "imgui_windows_retained_artifacts_manifest_abi_matched_count"
            ]
            == 1,
            counts[
                "imgui_windows_retained_artifacts_manifest_evidence_group_count_total"
            ]
            == counts[
                "imgui_windows_retained_artifacts_manifest_reported_evidence_group_count_total"
            ],
            counts[
                "imgui_windows_retained_artifacts_manifest_retained_json_file_count_matched_count"
            ]
            == 1,
            counts[
                "imgui_windows_retained_artifacts_manifest_retained_json_file_reference_count_total"
            ]
            >= counts[
                "imgui_windows_retained_artifacts_manifest_unique_retained_json_file_count_total"
            ]
            and counts[
                "imgui_windows_retained_artifacts_manifest_shared_retained_json_file_count_total"
            ]
            == (
                counts[
                    "imgui_windows_retained_artifacts_manifest_retained_json_file_reference_count_total"
                ]
                - counts[
                    "imgui_windows_retained_artifacts_manifest_unique_retained_json_file_count_total"
                ]
            ),
            counts[
                "imgui_windows_retained_artifacts_manifest_raw_analysis_host_group_count_total"
            ]
            == counts[
                "imgui_windows_retained_artifacts_manifest_complete_raw_analysis_host_group_count_total"
            ],
            counts[
                "imgui_windows_retained_artifacts_manifest_invariant_status_host_group_count_total"
            ]
            == (_optional_count(report.get("invariant_status_host_group_count")) or 0),
            counts[
                "imgui_windows_retained_artifacts_manifest_smoke_executed_no_retained_json_count_total"
            ]
            == (
                _optional_count(report.get("smoke_executed_no_retained_json_count"))
                or 0
            ),
            counts[
                "imgui_windows_retained_artifacts_manifest_non_claim_false_count"
            ]
            == 5,
        )
    )
    return {
        "name": name
        or _display_name("imgui_windows_retained_artifacts_manifest"),
        "source_method": "imgui_windows_retained_artifacts_manifest",
        "claim_scope": str(report.get("claim_scope") or ""),
        "accepted": passed == required,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": required - passed,
        "certification_scope": "",
        "certification_applicable_count": 0,
        "certification_certified_count": 0,
        "certification_uncertified_count": 0,
        **{key: 0 for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS},
        **{key: 0 for key in _COMPACT_HOST_EVIDENCE_KEYS},
        **{key: 0 for key in _ANALYSIS_ROLE_ORDER_SIGNATURE_KEYS},
        **{key: 0 for key in _ANALYSIS_SOURCE_TABLE_AUDIT_KEYS},
        **counts,
        "imgui_windows_retained_artifacts_manifest_abi_matched": (
            counts[
                "imgui_windows_retained_artifacts_manifest_abi_matched_count"
            ]
            == 1
        ),
        "imgui_windows_retained_artifacts_manifest_non_claims_preserved": (
            counts[
                "imgui_windows_retained_artifacts_manifest_non_claim_false_count"
            ]
            == 5
        ),
        "notes": _imgui_windows_retained_artifacts_manifest_analysis_notes(
            report,
            counts,
        ),
    }


def _imgui_windows_retained_artifacts_manifest_analysis_counts(
    report: Mapping[str, Any],
) -> dict[str, int]:
    evidence_groups = report.get("evidence_groups")
    if not isinstance(evidence_groups, Sequence) or isinstance(
        evidence_groups,
        (str, bytes),
    ):
        evidence_groups = ()
    group_mappings = [
        group for group in evidence_groups if isinstance(group, Mapping)
    ]
    classification_counts = {
        "complete_raw_analysis_host": 0,
        "invariant_status_host_only": 0,
        "smoke_executed_no_retained_json": 0,
    }
    for group in group_mappings:
        classification = str(group.get("classification") or "")
        if classification in classification_counts:
            classification_counts[classification] += 1
    retained_file_fields = (
        "raw_files",
        "analysis_files",
        "host_files",
        "invariant_status_files",
    )
    retained_json_file_references = [
        str(file_name)
        for group in group_mappings
        for field in retained_file_fields
        for file_name in (
            group.get(field)
            if isinstance(group.get(field), Sequence)
            and not isinstance(group.get(field), (str, bytes))
            else ()
        )
        if str(file_name).endswith(".json")
    ]
    unique_retained_json_files = set(retained_json_file_references)
    retained_json_file_reference_counts: dict[str, int] = {}
    for file_name in retained_json_file_references:
        retained_json_file_reference_counts[file_name] = (
            retained_json_file_reference_counts.get(file_name, 0) + 1
        )
    shared_retained_json_file_count = sum(
        1 for count in retained_json_file_reference_counts.values() if count > 1
    )
    retained_json_file_count = (
        _optional_count(report.get("retained_json_file_count")) or 0
    )
    non_claim_flags = (
        "production_renderer_verified",
        "production_scheduler_completion_claimed",
        "native_homfly_cpp_computation_claimed",
        "native_alexander_cpp_computation_claimed",
        "signed_release_artifacts_published",
    )
    non_claim_evidence_index = report.get("non_claim_evidence_index")
    non_claim_evidence_entry_count = (
        len(
            [
                entry
                for entry in non_claim_evidence_index
                if isinstance(entry, Mapping)
            ]
        )
        if isinstance(non_claim_evidence_index, Sequence)
        and not isinstance(non_claim_evidence_index, (str, bytes))
        else 0
    )
    return {
        "imgui_windows_retained_artifacts_manifest_artifact_count": 1,
        "imgui_windows_retained_artifacts_manifest_abi_matched_count": _count_true(
            report.get("imgui_abi_version") == 117
            and report.get("rust_c_abi_version") == 19
        ),
        "imgui_windows_retained_artifacts_manifest_evidence_group_count_total": len(
            group_mappings
        ),
        "imgui_windows_retained_artifacts_manifest_reported_evidence_group_count_total": (
            _optional_count(report.get("evidence_group_count")) or 0
        ),
        "imgui_windows_retained_artifacts_manifest_retained_json_file_count_total": (
            retained_json_file_count
        ),
        "imgui_windows_retained_artifacts_manifest_retained_json_file_reference_count_total": (
            len(retained_json_file_references)
        ),
        "imgui_windows_retained_artifacts_manifest_unique_retained_json_file_count_total": (
            len(unique_retained_json_files)
        ),
        "imgui_windows_retained_artifacts_manifest_shared_retained_json_file_count_total": (
            shared_retained_json_file_count
        ),
        "imgui_windows_retained_artifacts_manifest_retained_json_file_count_matched_count": _count_true(
            retained_json_file_count == len(unique_retained_json_files)
        ),
        "imgui_windows_retained_artifacts_manifest_raw_analysis_host_group_count_total": (
            _optional_count(report.get("raw_analysis_host_group_count")) or 0
        ),
        "imgui_windows_retained_artifacts_manifest_invariant_status_host_group_count_total": (
            classification_counts["invariant_status_host_only"]
        ),
        "imgui_windows_retained_artifacts_manifest_smoke_executed_no_retained_json_count_total": (
            classification_counts["smoke_executed_no_retained_json"]
        ),
        "imgui_windows_retained_artifacts_manifest_complete_raw_analysis_host_group_count_total": (
            classification_counts["complete_raw_analysis_host"]
        ),
        "imgui_windows_retained_artifacts_manifest_non_claim_false_count": sum(
            1 for key in non_claim_flags if report.get(key) is False
        ),
        "imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total": (
            non_claim_evidence_entry_count
        ),
        "imgui_windows_retained_artifacts_manifest_production_renderer_verified_count": _count_true(
            report.get("production_renderer_verified")
        ),
        "imgui_windows_retained_artifacts_manifest_production_scheduler_completion_claimed_count": _count_true(
            report.get("production_scheduler_completion_claimed")
        ),
        "imgui_windows_retained_artifacts_manifest_native_homfly_cpp_computation_claimed_count": _count_true(
            report.get("native_homfly_cpp_computation_claimed")
        ),
        "imgui_windows_retained_artifacts_manifest_native_alexander_cpp_computation_claimed_count": _count_true(
            report.get("native_alexander_cpp_computation_claimed")
        ),
        "imgui_windows_retained_artifacts_manifest_signed_release_artifacts_published_count": _count_true(
            report.get("signed_release_artifacts_published")
        ),
    }


def _imgui_windows_retained_artifacts_manifest_analysis_notes(
    report: Mapping[str, Any],
    counts: Mapping[str, int],
) -> str:
    shared_retained_json_files = _imgui_windows_retained_artifacts_manifest_shared_files(
        report
    )
    notes = _append_note(
        _notes_text(report),
        (
            "imgui_windows_retained_artifacts_manifest="
            "retained_json_files="
            f"{counts['imgui_windows_retained_artifacts_manifest_retained_json_file_count_total']}; "
            "retained_json_file_references="
            f"{counts['imgui_windows_retained_artifacts_manifest_retained_json_file_reference_count_total']}; "
            "unique_retained_json_files="
            f"{counts['imgui_windows_retained_artifacts_manifest_unique_retained_json_file_count_total']}; "
            "shared_retained_json_files="
            f"{counts['imgui_windows_retained_artifacts_manifest_shared_retained_json_file_count_total']}; "
            "retained_json_file_count_matched="
            f"{_note_bool_from_count(counts['imgui_windows_retained_artifacts_manifest_retained_json_file_count_matched_count'])}; "
            f"groups={counts['imgui_windows_retained_artifacts_manifest_evidence_group_count_total']}; "
            "complete_raw_analysis_host_groups="
            f"{counts['imgui_windows_retained_artifacts_manifest_complete_raw_analysis_host_group_count_total']}; "
            "invariant_status_host_groups="
            f"{counts['imgui_windows_retained_artifacts_manifest_invariant_status_host_group_count_total']}; "
            "smoke_executed_no_retained_json_groups="
            f"{counts['imgui_windows_retained_artifacts_manifest_smoke_executed_no_retained_json_count_total']}"
        ),
    )
    if shared_retained_json_files:
        notes = _append_note(
            notes,
            "imgui_windows_retained_artifacts_manifest_shared_files="
            + ",".join(shared_retained_json_files),
        )
    notes = _append_note(
        notes,
        (
            "imgui_windows_retained_artifacts_manifest_claims="
            "production_renderer_verified="
            f"{_note_bool_from_count(counts['imgui_windows_retained_artifacts_manifest_production_renderer_verified_count'])}; "
            "production_scheduler_completion_claimed="
            f"{_note_bool_from_count(counts['imgui_windows_retained_artifacts_manifest_production_scheduler_completion_claimed_count'])}; "
            "native_homfly_cpp_computation_claimed="
            f"{_note_bool_from_count(counts['imgui_windows_retained_artifacts_manifest_native_homfly_cpp_computation_claimed_count'])}; "
            "native_alexander_cpp_computation_claimed="
            f"{_note_bool_from_count(counts['imgui_windows_retained_artifacts_manifest_native_alexander_cpp_computation_claimed_count'])}; "
            "signed_release_artifacts_published="
            f"{_note_bool_from_count(counts['imgui_windows_retained_artifacts_manifest_signed_release_artifacts_published_count'])}"
        ),
    )
    notes = _append_note(
        notes,
        "non_claim_evidence_index_entries="
        f"{counts['imgui_windows_retained_artifacts_manifest_non_claim_evidence_index_entry_count_total']}",
    )
    return _append_note(
        notes,
        "Windows Dear ImGui retained-artifact manifest evidence only; not release completion evidence",
    )


def _imgui_windows_retained_artifacts_manifest_shared_files(
    report: Mapping[str, Any],
) -> list[str]:
    evidence_groups = report.get("evidence_groups")
    if not isinstance(evidence_groups, Sequence) or isinstance(
        evidence_groups,
        (str, bytes),
    ):
        return []
    retained_file_fields = (
        "raw_files",
        "analysis_files",
        "host_files",
        "invariant_status_files",
    )
    reference_counts: dict[str, int] = {}
    for group in evidence_groups:
        if not isinstance(group, Mapping):
            continue
        for field in retained_file_fields:
            file_names = group.get(field)
            if not isinstance(file_names, Sequence) or isinstance(
                file_names,
                (str, bytes),
            ):
                continue
            for file_name in file_names:
                file_name_text = str(file_name)
                if not file_name_text.endswith(".json"):
                    continue
                reference_counts[file_name_text] = (
                    reference_counts.get(file_name_text, 0) + 1
                )
    return sorted(
        file_name for file_name, count in reference_counts.items() if count > 1
    )


def _analysis_summary_from_rust_wheel_retained_manifest(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    counts = _rust_wheel_retained_manifest_analysis_counts(report)
    required = 6
    passed = sum(
        (
            str(report.get("claim_scope") or "")
            == "unsigned_ci_rust_wheel_artifact_index",
            counts["rust_wheel_retained_manifest_abi_matched_count"] == 1,
            counts["rust_wheel_retained_manifest_wheel_count_total"] >= 1,
            counts["rust_wheel_retained_manifest_wheel_count_matched_count"] == 1,
            counts["rust_wheel_retained_manifest_unsigned_ci_artifact_count"] == 1,
            counts["rust_wheel_retained_manifest_non_claim_false_count"] == 6,
        )
    )
    return {
        "name": name or _display_name("rust_wheel_retained_manifest"),
        "source_method": "rust_wheel_retained_metadata_manifest",
        "claim_scope": str(report.get("claim_scope") or ""),
        "accepted": passed == required,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": required - passed,
        "certification_scope": "",
        "certification_applicable_count": 0,
        "certification_certified_count": 0,
        "certification_uncertified_count": 0,
        **{key: 0 for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS},
        **{key: 0 for key in _COMPACT_HOST_EVIDENCE_KEYS},
        **{key: 0 for key in _ANALYSIS_ROLE_ORDER_SIGNATURE_KEYS},
        **{key: 0 for key in _ANALYSIS_SOURCE_TABLE_AUDIT_KEYS},
        **counts,
        "rust_wheel_retained_manifest_abi_matched": (
            counts["rust_wheel_retained_manifest_abi_matched_count"] == 1
        ),
        "rust_wheel_retained_manifest_wheel_count_matched": (
            counts["rust_wheel_retained_manifest_wheel_count_matched_count"] == 1
        ),
        "rust_wheel_retained_manifest_non_claims_preserved": (
            counts["rust_wheel_retained_manifest_non_claim_false_count"] == 6
        ),
        "notes": _rust_wheel_retained_manifest_analysis_notes(report, counts),
    }


def _rust_wheel_retained_manifest_analysis_counts(
    report: Mapping[str, Any],
) -> dict[str, int]:
    wheel_count = _optional_count(report.get("wheel_count")) or 0
    wheel_files = report.get("wheel_files")
    wheel_file_count = _sequence_count(wheel_files)
    non_claim_flags = (
        "signed_release_artifacts_published",
        "publication_claimed",
        "platform_index_publication_claimed",
        "release_grade_speedup_claimed",
        "native_homfly_cpp_computation_claimed",
        "native_alexander_cpp_computation_claimed",
    )
    non_claim_evidence_index = report.get("non_claim_evidence_index")
    non_claim_evidence_entry_count = (
        len(
            [
                entry
                for entry in non_claim_evidence_index
                if isinstance(entry, Mapping)
            ]
        )
        if isinstance(non_claim_evidence_index, Sequence)
        and not isinstance(non_claim_evidence_index, (str, bytes))
        else 0
    )
    return {
        "rust_wheel_retained_manifest_artifact_count": 1,
        "rust_wheel_retained_manifest_abi_matched_count": _count_true(
            report.get("rust_c_abi_version") == 19
        ),
        "rust_wheel_retained_manifest_wheel_count_total": wheel_count,
        "rust_wheel_retained_manifest_wheel_file_count_total": wheel_file_count,
        "rust_wheel_retained_manifest_wheel_count_matched_count": _count_true(
            wheel_count == wheel_file_count
        ),
        "rust_wheel_retained_manifest_unsigned_ci_artifact_count": _count_true(
            report.get("unsigned_ci_artifact")
        ),
        "rust_wheel_retained_manifest_non_claim_false_count": sum(
            1 for key in non_claim_flags if report.get(key) is False
        ),
        "rust_wheel_retained_manifest_non_claim_evidence_index_entry_count_total": (
            non_claim_evidence_entry_count
        ),
        "rust_wheel_retained_manifest_signed_release_artifacts_published_count": _count_true(
            report.get("signed_release_artifacts_published")
        ),
        "rust_wheel_retained_manifest_publication_claimed_count": _count_true(
            report.get("publication_claimed")
        ),
        "rust_wheel_retained_manifest_platform_index_publication_claimed_count": _count_true(
            report.get("platform_index_publication_claimed")
        ),
        "rust_wheel_retained_manifest_release_grade_speedup_claimed_count": _count_true(
            report.get("release_grade_speedup_claimed")
        ),
        "rust_wheel_retained_manifest_native_homfly_cpp_computation_claimed_count": _count_true(
            report.get("native_homfly_cpp_computation_claimed")
        ),
        "rust_wheel_retained_manifest_native_alexander_cpp_computation_claimed_count": _count_true(
            report.get("native_alexander_cpp_computation_claimed")
        ),
    }


def _rust_wheel_retained_manifest_analysis_notes(
    report: Mapping[str, Any],
    counts: Mapping[str, int],
) -> str:
    consistency = report.get("release_non_claim_consistency")
    if isinstance(consistency, Mapping):
        non_claim_flag_count = _optional_count(consistency.get("flag_count")) or 0
        non_claim_false_count = _optional_count(consistency.get("false_count")) or 0
        non_claim_all_false = bool(consistency.get("all_false", False))
    else:
        non_claim_flag_count = 6
        non_claim_false_count = counts[
            "rust_wheel_retained_manifest_non_claim_false_count"
        ]
        non_claim_all_false = non_claim_false_count == non_claim_flag_count
    notes = _append_note(
        _notes_text(report),
        (
            "rust_wheel_retained_manifest="
            f"wheel_count={counts['rust_wheel_retained_manifest_wheel_count_total']}; "
            "wheel_file_count="
            f"{counts['rust_wheel_retained_manifest_wheel_file_count_total']}; "
            "wheel_count_matched="
            f"{_note_bool_from_count(counts['rust_wheel_retained_manifest_wheel_count_matched_count'])}; "
            "rust_c_abi_matched="
            f"{_note_bool_from_count(counts['rust_wheel_retained_manifest_abi_matched_count'])}; "
            "unsigned_ci_artifact="
            f"{_note_bool_from_count(counts['rust_wheel_retained_manifest_unsigned_ci_artifact_count'])}; "
            "wheel_artifact_name="
            f"{_note_field_value(report.get('wheel_artifact_name'))}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "rust_wheel_retained_manifest_claims="
            "signed_release_artifacts_published="
            f"{_note_bool_from_count(counts['rust_wheel_retained_manifest_signed_release_artifacts_published_count'])}; "
            "publication_claimed="
            f"{_note_bool_from_count(counts['rust_wheel_retained_manifest_publication_claimed_count'])}; "
            "platform_index_publication_claimed="
            f"{_note_bool_from_count(counts['rust_wheel_retained_manifest_platform_index_publication_claimed_count'])}; "
            "release_grade_speedup_claimed="
            f"{_note_bool_from_count(counts['rust_wheel_retained_manifest_release_grade_speedup_claimed_count'])}; "
            "native_homfly_cpp_computation_claimed="
            f"{_note_bool_from_count(counts['rust_wheel_retained_manifest_native_homfly_cpp_computation_claimed_count'])}; "
            "native_alexander_cpp_computation_claimed="
            f"{_note_bool_from_count(counts['rust_wheel_retained_manifest_native_alexander_cpp_computation_claimed_count'])}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "release_non_claim_consistency="
            f"flags={non_claim_flag_count}; "
            f"false={non_claim_false_count}; "
            f"all_false={_note_field_value(non_claim_all_false)}"
        ),
    )
    notes = _append_note(
        notes,
        "non_claim_evidence_index_entries="
        f"{counts['rust_wheel_retained_manifest_non_claim_evidence_index_entry_count_total']}",
    )
    return _append_note(
        notes,
        "unsigned Rust wheel CI artifact index only; not signed release publication, platform index publication, release-grade speedup, or native HOMFLY/Alexander computation evidence",
    )


def _analysis_summary_from_gpu_smoke_artifact(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    artifact_kind = str(report.get("artifact_kind") or "gpu_smoke_artifact")
    gate = _mapping_or_empty(report.get("gpu_release_gate"))
    metadata = _mapping_or_empty(report.get("environment_metadata"))
    witness = _mapping_or_empty(report.get("environment_witness"))
    runtime = _mapping_or_empty(witness.get("runtime"))
    simulation = _mapping_or_empty(witness.get("simulation"))
    evidence = _mapping_or_empty(report.get("evidence"))

    counts = _gpu_smoke_analysis_counts(
        report,
        artifact_kind=artifact_kind,
        gate=gate,
        metadata=metadata,
        runtime=runtime,
        simulation=simulation,
        evidence=evidence,
    )
    parity_checks = counts["gpu_smoke_parity_check_count"]
    failed = counts["gpu_smoke_failed_check_count"]
    passed = counts["gpu_smoke_passed_check_count"]
    required_capability_names = _gpu_smoke_required_capability_names(report)
    failed_check_names = _gpu_smoke_failed_check_names(report)
    no_cuda_boundary = counts["gpu_smoke_no_cuda_boundary_count"] == 1
    gate_passed = counts["gpu_smoke_gate_passed_count"] == 1
    accepted = (
        no_cuda_boundary
        if artifact_kind == "gpu_smoke_unavailable_boundary"
        else gate_passed and failed == 0 and parity_checks > 0
    )
    if artifact_kind == "gpu_smoke_parity_failure":
        accepted = False

    return {
        "name": name or _display_name(artifact_kind),
        "source_method": artifact_kind,
        "claim_scope": str(report.get("claim_scope") or ""),
        "accepted": accepted,
        "certified": False,
        "required_check_count": parity_checks,
        "passed_check_count": passed,
        "failed_check_count": failed,
        "certification_scope": "",
        "certification_applicable_count": 0,
        "certification_certified_count": 0,
        "certification_uncertified_count": 0,
        **{key: 0 for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS},
        **{key: 0 for key in _COMPACT_HOST_EVIDENCE_KEYS},
        **{key: 0 for key in _ANALYSIS_ROLE_ORDER_SIGNATURE_KEYS},
        **{key: 0 for key in _ANALYSIS_SOURCE_TABLE_AUDIT_KEYS},
        **counts,
        "gpu_smoke_backend_available": (
            counts["gpu_smoke_backend_available_count"] == 1
        ),
        "gpu_smoke_cuda_runtime_observed": (
            counts["gpu_smoke_runtime_observed_count"] == 1
        ),
        "gpu_smoke_gate_passed": gate_passed,
        "gpu_smoke_dispatch_parity_claimed": (
            counts["gpu_smoke_dispatch_parity_claimed_count"] == 1
        ),
        "gpu_smoke_no_cuda_boundary": no_cuda_boundary,
        "gpu_smoke_simulated_parity_failure": (
            counts["gpu_smoke_simulated_parity_failure_count"] == 1
        ),
        "gpu_smoke_cuda_parity_claimed": (
            counts["gpu_smoke_cuda_parity_claimed_count"] == 1
        ),
        "gpu_smoke_release_grade_speedup_claimed": (
            counts["gpu_smoke_release_grade_speedup_claimed_count"] == 1
        ),
        "gpu_smoke_required_capability_names": "|".join(
            required_capability_names
        ),
        "gpu_smoke_failed_check_names": "|".join(failed_check_names),
        "notes": _gpu_smoke_analysis_notes(
            report,
            artifact_kind=artifact_kind,
            counts=counts,
            gate=gate,
            required_capability_names=required_capability_names,
            failed_check_names=failed_check_names,
        ),
    }


def _gpu_smoke_required_capability_names(report: Mapping[str, Any]) -> list[str]:
    capabilities = report.get("required_capabilities")
    if not isinstance(capabilities, Sequence) or isinstance(
        capabilities,
        (str, bytes, bytearray),
    ):
        return []
    return [str(item) for item in capabilities]


def _gpu_smoke_failed_check_names(report: Mapping[str, Any]) -> list[str]:
    check_results = report.get("check_results")
    if not isinstance(check_results, Sequence) or isinstance(
        check_results,
        (str, bytes, bytearray),
    ):
        return []
    failed_names: list[str] = []
    for index, check in enumerate(check_results):
        if not isinstance(check, Mapping):
            continue
        if check.get("matched") is not False:
            continue
        failed_names.append(str(check.get("name") or f"check_{index}"))
    return failed_names


def _gpu_smoke_analysis_counts(
    report: Mapping[str, Any],
    *,
    artifact_kind: str,
    gate: Mapping[str, Any],
    metadata: Mapping[str, Any],
    runtime: Mapping[str, Any],
    simulation: Mapping[str, Any],
    evidence: Mapping[str, Any],
) -> dict[str, int]:
    required_capabilities = (
        _optional_count(report.get("required_capability_count"))
        or _sequence_count(report.get("required_capabilities"))
    )
    required_capability_name_count = len(
        _gpu_smoke_required_capability_names(report)
    )
    parity_checks = (
        _optional_count(report.get("parity_check_count"))
        or _sequence_count(report.get("check_results"))
    )
    passed = _optional_count(report.get("passed_check_count")) or 0
    failed = _optional_count(report.get("failed_check_count"))
    if failed is None:
        failed = max(0, parity_checks - passed)
    failed_check_name_count = len(_gpu_smoke_failed_check_names(report))

    backend_available = _optional_bool(metadata.get("gpu_backend_available"))
    if backend_available is None:
        backend_available = _optional_bool(gate.get("gpu_backend_available"))
    runtime_observed = _optional_bool(runtime.get("cuda_runtime_observed"))
    if runtime_observed is None:
        runtime_observed = _optional_bool(gate.get("cuda_runtime_observed"))
    blocking_reasons = gate.get("blocking_reasons")
    blocking_reason_values = (
        [str(reason) for reason in blocking_reasons]
        if isinstance(blocking_reasons, Sequence)
        and not isinstance(blocking_reasons, (str, bytes))
        else []
    )
    blocking_reason_counts = {
        reason: blocking_reason_values.count(reason)
        for reason in set(blocking_reason_values)
    }

    return {
        "gpu_smoke_parity_result_count": _count_true(
            artifact_kind == "gpu_smoke_parity_result"
        ),
        "gpu_smoke_unavailable_boundary_count": _count_true(
            artifact_kind == "gpu_smoke_unavailable_boundary"
        ),
        "gpu_smoke_parity_failure_count": _count_true(
            artifact_kind == "gpu_smoke_parity_failure"
        ),
        "gpu_smoke_required_capability_count": required_capabilities,
        "gpu_smoke_required_capability_name_count": required_capability_name_count,
        "gpu_smoke_parity_check_count": parity_checks,
        "gpu_smoke_passed_check_count": passed,
        "gpu_smoke_failed_check_count": failed,
        "gpu_smoke_failed_check_name_count": failed_check_name_count,
        "gpu_smoke_blocking_reason_count": (
            _optional_count(gate.get("blocking_reason_count"))
            or _sequence_count(gate.get("blocking_reasons"))
        ),
        "gpu_smoke_backend_available_count": _count_true(backend_available),
        "gpu_smoke_runtime_observed_count": _count_true(runtime_observed),
        "gpu_smoke_gate_passed_count": _count_true(gate.get("gate_passed")),
        "gpu_smoke_release_gate_gpu_backend_unavailable_blocker_count": (
            blocking_reason_counts.get("gpu_backend_unavailable", 0)
        ),
        "gpu_smoke_release_gate_cuda_runtime_not_observed_blocker_count": (
            blocking_reason_counts.get("cuda_runtime_not_observed", 0)
        ),
        "gpu_smoke_release_gate_required_checks_incomplete_blocker_count": (
            blocking_reason_counts.get("required_checks_incomplete", 0)
        ),
        "gpu_smoke_release_gate_required_checks_failed_blocker_count": (
            blocking_reason_counts.get("required_checks_failed", 0)
            + blocking_reason_counts.get("gpu_dispatch_parity_smoke_failed", 0)
        ),
        "gpu_smoke_release_gate_forced_unavailable_blocker_count": (
            blocking_reason_counts.get("forced_unavailable", 0)
        ),
        "gpu_smoke_release_gate_simulated_parity_failure_blocker_count": (
            blocking_reason_counts.get("simulated_parity_failure", 0)
        ),
        "gpu_smoke_dispatch_parity_claimed_count": _count_true(
            report.get("gpu_dispatch_parity_smoke_claimed")
        ),
        "gpu_smoke_no_cuda_boundary_count": _count_true(
            evidence.get("no_cuda_boundary")
        ),
        "gpu_smoke_simulated_parity_failure_count": _count_true(
            simulation.get("simulated_parity_failure")
        ),
        "gpu_smoke_cuda_parity_claimed_count": _count_true(
            report.get("cuda_parity_claimed")
        ),
        "gpu_smoke_release_grade_speedup_claimed_count": _count_true(
            report.get("release_grade_speedup_claimed")
        ),
    }


def _gpu_smoke_analysis_notes(
    report: Mapping[str, Any],
    *,
    artifact_kind: str,
    counts: Mapping[str, int],
    gate: Mapping[str, Any],
    required_capability_names: Sequence[str],
    failed_check_names: Sequence[str],
) -> str:
    notes = _append_note(
        str(report.get("note") or ""),
        (
            "gpu_smoke_artifact="
            f"kind={artifact_kind}; "
            f"execution_path={_note_field_value(report.get('execution_path'))}; "
            f"claim_scope={_note_field_value(report.get('claim_scope'))}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "gpu_smoke_checks="
            f"required_capabilities={counts['gpu_smoke_required_capability_count']}; "
            f"parity_checks={counts['gpu_smoke_parity_check_count']}; "
            f"passed={counts['gpu_smoke_passed_check_count']}; "
            f"failed={counts['gpu_smoke_failed_check_count']}"
        ),
    )
    if required_capability_names:
        notes = _append_note(
            notes,
            "gpu_smoke_required_capabilities="
            f"{'|'.join(required_capability_names)}",
        )
    if failed_check_names:
        notes = _append_note(
            notes,
            f"gpu_smoke_failed_check_names={'|'.join(failed_check_names)}",
        )
    blocking_reasons = gate.get("blocking_reasons")
    if isinstance(blocking_reasons, Sequence) and not isinstance(
        blocking_reasons,
        (str, bytes),
    ):
        blocking_text = ",".join(str(item) for item in blocking_reasons)
    else:
        blocking_text = ""
    notes = _append_note(
        notes,
        (
            "gpu_release_gate="
            f"gate_passed={_note_field_value(gate.get('gate_passed'))}; "
            f"blocking_reasons={counts['gpu_smoke_blocking_reason_count']}; "
            f"backend_available={_note_field_value(gate.get('gpu_backend_available'))}; "
            "cuda_runtime_observed="
            f"{_note_field_value(gate.get('cuda_runtime_observed'))}"
        ),
    )
    if blocking_text:
        notes = _append_note(notes, f"gpu_release_gate_blockers={blocking_text}")
    blocker_code_counts = {
        "gpu_backend_unavailable": counts[
            "gpu_smoke_release_gate_gpu_backend_unavailable_blocker_count"
        ],
        "cuda_runtime_not_observed": counts[
            "gpu_smoke_release_gate_cuda_runtime_not_observed_blocker_count"
        ],
        "required_checks_incomplete": counts[
            "gpu_smoke_release_gate_required_checks_incomplete_blocker_count"
        ],
        "required_checks_failed": counts[
            "gpu_smoke_release_gate_required_checks_failed_blocker_count"
        ],
        "forced_unavailable": counts[
            "gpu_smoke_release_gate_forced_unavailable_blocker_count"
        ],
        "simulated_parity_failure": counts[
            "gpu_smoke_release_gate_simulated_parity_failure_blocker_count"
        ],
    }
    blocker_code_signature = _mapping_count_note_signature(
        {
            key: value
            for key, value in blocker_code_counts.items()
            if value
        }
    )
    if blocker_code_signature:
        notes = _append_note(
            notes,
            f"gpu_release_gate_blocker_codes={blocker_code_signature}",
        )
    notes = _append_note(
        notes,
        (
            "gpu_smoke_claims="
            "gpu_dispatch_parity_smoke_claimed="
            f"{_note_bool_from_count(counts['gpu_smoke_dispatch_parity_claimed_count'])}; "
            "cuda_parity_claimed="
            f"{_note_bool_from_count(counts['gpu_smoke_cuda_parity_claimed_count'])}; "
            "release_grade_speedup_claimed="
            f"{_note_bool_from_count(counts['gpu_smoke_release_grade_speedup_claimed_count'])}"
        ),
    )
    return _append_note(
        notes,
        "GPU smoke analysis row is host-visible artifact evidence, not CUDA parity evidence or release-grade speedup evidence",
    )


def _note_bool_from_count(count: int) -> str:
    return "true" if count > 0 else "false"


def _analysis_summary_from_core_benchmark_matrix(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    matrix_summary = _mapping_or_empty(report.get("matrix_summary"))
    speedup_evidence = _mapping_or_empty(report.get("speedup_evidence"))
    release_gate = _mapping_or_empty(speedup_evidence.get("release_gate"))
    gpu_evidence = _mapping_or_empty(report.get("cuda_gpu_benchmark_evidence"))

    counts = _benchmark_matrix_analysis_counts(
        report,
        matrix_summary=matrix_summary,
        speedup_evidence=speedup_evidence,
        release_gate=release_gate,
        gpu_evidence=gpu_evidence,
    )
    required = max(1, counts["benchmark_matrix_expected_row_count"])
    failed = min(counts["benchmark_matrix_failed_row_count"], required)
    passed = max(0, required - failed)
    notes = _benchmark_matrix_analysis_notes(
        report,
        counts=counts,
        speedup_evidence=speedup_evidence,
        release_gate=release_gate,
        gpu_evidence=gpu_evidence,
    )
    return {
        "name": name or _display_name("iroll_core_benchmark_matrix"),
        "source_method": "iroll_core_benchmark_matrix",
        "claim_scope": "local_backend_benchmark_matrix_profiling_evidence",
        "accepted": counts["benchmark_matrix_row_count"] > 0 and failed == 0,
        "certified": False,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": failed,
        "certification_scope": "",
        "certification_applicable_count": 0,
        "certification_certified_count": 0,
        "certification_uncertified_count": 0,
        **{key: 0 for key in _ANALYSIS_ROLE_ORDER_SIGNATURE_KEYS},
        **{key: 0 for key in _ANALYSIS_SOURCE_TABLE_AUDIT_KEYS},
        **counts,
        "benchmark_matrix_all_requested_rows_completed": bool(
            matrix_summary.get("all_requested_rows_completed", False)
        ),
        "benchmark_matrix_has_failures": bool(
            matrix_summary.get("has_failures", failed > 0)
        ),
        "benchmark_speedup_release_grade_claimed": bool(
            speedup_evidence.get("release_grade_speedup_claimed", False)
        ),
        "benchmark_speedup_repeat_satisfied": bool(
            release_gate.get("repeat_satisfied", False)
        ),
        "benchmark_cuda_gpu_backend_requested": bool(
            gpu_evidence.get("gpu_backend_requested", False)
        ),
        "benchmark_cuda_gpu_backend_available": bool(
            gpu_evidence.get("gpu_backend_available", False)
        ),
        "benchmark_cuda_gpu_cuda_runtime_observed": bool(
            gpu_evidence.get("cuda_runtime_observed", False)
        ),
        "benchmark_cuda_gpu_generic_speedup_gate_claimed_for_gpu": bool(
            gpu_evidence.get("generic_speedup_gate_claimed_for_gpu", False)
        ),
        "benchmark_cuda_gpu_local_speedup_threshold_met": bool(
            gpu_evidence.get("local_gpu_speedup_threshold_met", False)
        ),
        "benchmark_cuda_gpu_hosted_cuda_ci_claimed": bool(
            gpu_evidence.get("hosted_cuda_ci_claimed", False)
        ),
        "benchmark_cuda_gpu_parity_claimed": bool(
            gpu_evidence.get("cuda_parity_claimed", False)
        ),
        "benchmark_cuda_gpu_release_grade_speedup_claimed": bool(
            gpu_evidence.get("release_grade_gpu_speedup_claimed", False)
        ),
        "notes": notes,
    }


def imgui_analysis_payload_from_acceptance_reports(
    reports: Iterable[Mapping[str, Any]],
) -> dict[str, Any]:
    """Flatten acceptance reports for host-loaded ImGui analysis summaries."""

    report_list = list(reports)
    summaries = [
        analysis_summary_from_acceptance_report(report)
        for report in report_list
    ]
    accepted_summaries = sum(1 for summary in summaries if summary["accepted"])
    certified_summaries = sum(1 for summary in summaries if summary["certified"])
    uncertified_summaries = sum(
        1
        for summary in summaries
        if summary["accepted"] and not summary["certified"]
    )
    failed_summaries = sum(
        1 for summary in summaries if summary["failed_check_count"] > 0
    )
    required = sum(summary["required_check_count"] for summary in summaries)
    passed = sum(summary["passed_check_count"] for summary in summaries)
    failed = sum(summary["failed_check_count"] for summary in summaries)
    certification_applicable = sum(
        summary["certification_applicable_count"] for summary in summaries
    )
    certification_certified = sum(
        summary["certification_certified_count"] for summary in summaries
    )
    certification_uncertified = sum(
        summary["certification_uncertified_count"] for summary in summaries
    )
    evidence_totals = {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in summaries
        )
        for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS
        + _COMPACT_HOST_EVIDENCE_KEYS
    }
    _set_payload_maturity_path_distinct_counts(evidence_totals, prefix="analysis")
    role_order_signature_totals = {
        f"analysis_{key}": sum(summary[key] for summary in summaries)
        for key in _ANALYSIS_ROLE_ORDER_SIGNATURE_KEYS
    }
    source_table_audit_totals = {
        f"analysis_{key}": sum(summary[key] for summary in summaries)
        for key in _ANALYSIS_SOURCE_TABLE_AUDIT_KEYS
    }
    source_candidate_replay_summary_totals = {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in summaries
        )
        for key in _ANALYSIS_SOURCE_CANDIDATE_REPLAY_SUMMARY_KEYS
    }
    benchmark_matrix_totals = {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in summaries
        )
        for key in _ANALYSIS_BENCHMARK_MATRIX_KEYS
    }
    gpu_smoke_totals = {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in summaries
        )
        for key in _ANALYSIS_GPU_SMOKE_KEYS
    }
    imgui_framebuffer_smoke_totals = {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in summaries
        )
        for key in _ANALYSIS_IMGUI_FRAMEBUFFER_SMOKE_KEYS
    }
    imgui_source_open_request_smoke_totals = {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in summaries
        )
        for key in _ANALYSIS_IMGUI_SOURCE_OPEN_REQUEST_SMOKE_KEYS
    }
    validate_table_source_metadata_totals = {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in summaries
        )
        for key in _ANALYSIS_VALIDATE_TABLE_SOURCE_METADATA_KEYS
    }
    imgui_signed_pd_snapshot_totals = {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in summaries
        )
        for key in _ANALYSIS_IMGUI_SIGNED_PD_SNAPSHOT_KEYS
    }
    imgui_signed_pd_recompute_scheduler_smoke_totals = {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in summaries
        )
        for key in _ANALYSIS_IMGUI_SIGNED_PD_RECOMPUTE_SCHEDULER_SMOKE_KEYS
    }
    imgui_signed_pd_thread_pool_recompute_scheduler_smoke_totals = {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in summaries
        )
        for key in _ANALYSIS_IMGUI_SIGNED_PD_THREAD_POOL_RECOMPUTE_SCHEDULER_SMOKE_KEYS
    }
    imgui_real_kernel_loader_smoke_totals = {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in summaries
        )
        for key in _ANALYSIS_IMGUI_REAL_KERNEL_LOADER_SMOKE_KEYS
    }
    imgui_windows_retained_artifacts_manifest_totals = {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in summaries
        )
        for key in _ANALYSIS_IMGUI_WINDOWS_RETAINED_ARTIFACTS_MANIFEST_KEYS
    }
    rust_wheel_retained_manifest_totals = {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in summaries
        )
        for key in _ANALYSIS_RUST_WHEEL_RETAINED_MANIFEST_KEYS
    }
    blocker_summary_totals = _analysis_blocker_summary_totals(summaries)
    generated_coverage_totals = _analysis_generated_coverage_totals(summaries)
    generated_source_summary_consistency_totals = (
        _analysis_generated_source_summary_consistency_totals(summaries)
    )
    homfly_case_evidence_consistency_totals = (
        _analysis_homfly_case_evidence_consistency_totals(summaries)
    )
    validation_pack_audit_totals = _analysis_validation_pack_audit_totals(summaries)
    alexander_maturity_path_summary_consistency_totals = (
        _analysis_alexander_maturity_path_summary_consistency_totals(summaries)
    )
    payload = {
        "method": "imgui_analysis_payload_from_acceptance_reports",
        "analysis_summaries": summaries,
        "analysis_summary_count": len(summaries),
        "analysis_accepted_summary_count": accepted_summaries,
        "analysis_rejected_summary_count": len(summaries) - accepted_summaries,
        "analysis_certified_summary_count": certified_summaries,
        "analysis_uncertified_summary_count": uncertified_summaries,
        "analysis_failed_summary_count": failed_summaries,
        "analysis_required_check_count": required,
        "analysis_passed_check_count": passed,
        "analysis_failed_check_count": failed,
        "analysis_certification_applicable_count": certification_applicable,
        "analysis_certification_certified_count": certification_certified,
        "analysis_certification_uncertified_count": certification_uncertified,
        **evidence_totals,
        **role_order_signature_totals,
        **source_table_audit_totals,
        **source_candidate_replay_summary_totals,
        **benchmark_matrix_totals,
        **gpu_smoke_totals,
        **imgui_framebuffer_smoke_totals,
        **imgui_source_open_request_smoke_totals,
        **validate_table_source_metadata_totals,
        **imgui_signed_pd_snapshot_totals,
        **imgui_signed_pd_recompute_scheduler_smoke_totals,
        **imgui_signed_pd_thread_pool_recompute_scheduler_smoke_totals,
        **imgui_real_kernel_loader_smoke_totals,
        **imgui_windows_retained_artifacts_manifest_totals,
        **rust_wheel_retained_manifest_totals,
        **blocker_summary_totals,
        **generated_coverage_totals,
        **homfly_case_evidence_consistency_totals,
        **validation_pack_audit_totals,
        **generated_source_summary_consistency_totals,
        **alexander_maturity_path_summary_consistency_totals,
        "notes": [
            "payload is designed for C++/Dear ImGui display and host-side C ABI loading",
            "nested mathematical reports remain the authoritative computation evidence",
        ],
    }
    common_revision = _common_source_signed_pd_revision(report_list)
    if common_revision is not None:
        payload["source_signed_pd_revision"] = common_revision
    return payload


def fixture_comparisons_from_acceptance_report(
    report: Mapping[str, Any],
) -> list[dict[str, Any]]:
    """Return `IrollFixtureComparison`-compatible fixture rows.

    Acceptance reports keep rich nested comparison, mirror, skein, and minor
    audit payloads. The ImGui fixture-comparison panel only needs the
    expected-vs-observed row plus conservative evidence counts and notes.
    """

    invariant_name = _invariant_display_name(str(report.get("method", "")))
    rows = report.get("fixtures", [])
    if not isinstance(rows, list):
        return []
    return [
        fixture_comparison_from_acceptance_row(
            row,
            invariant_name=invariant_name,
        )
        for row in rows
        if isinstance(row, Mapping)
    ]


def fixture_comparison_from_acceptance_row(
    row: Mapping[str, Any],
    *,
    invariant_name: str,
) -> dict[str, Any]:
    """Flatten one acceptance-report fixture row for Dear ImGui loading."""

    comparison = row.get("comparison")
    comparison_mapping: Mapping[str, Any] = (
        comparison if isinstance(comparison, Mapping) else {}
    )
    expected = _row_expected_value(row, comparison_mapping, invariant_name)
    observed = _row_observed_value(comparison_mapping, invariant_name)
    required, passed, failed = _fixture_row_check_counts(row)
    return {
        "fixture_name": str(row.get("notation") or row.get("name") or ""),
        "invariant_name": invariant_name,
        "source": _fixture_row_source(row, comparison_mapping),
        "source_url": _fixture_row_source_url(row, comparison_mapping),
        "expected": expected,
        "observed": observed,
        "matched": bool(comparison_mapping.get("matched", row.get("comparison_matched", False))),
        "certified_for_input": bool(
            comparison_mapping.get(
                "certified_for_input",
                row.get("certified_for_input", False),
            )
        ),
        "full_table_normalization_certified": bool(
            comparison_mapping.get(
                "full_table_normalization_certified",
                row.get("full_table_normalization_certified", False),
            )
        ),
        "bounded_scanned_gcd_certified": bool(
            row.get("bounded_scanned_gcd_certified", False)
        ),
        "full_invariant_certified": bool(
            row.get("full_invariant_certified", False)
        ),
        "skipped": bool(comparison_mapping.get("skipped", expected == "")),
        "notes": _fixture_row_notes(row, comparison_mapping),
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": failed,
    }


def imgui_fixture_comparison_payload_from_acceptance_reports(
    reports: Iterable[Mapping[str, Any]],
) -> dict[str, Any]:
    """Flatten acceptance reports for host-loaded ImGui fixture rows."""

    comparisons: list[dict[str, Any]] = []
    for report in reports:
        comparisons.extend(fixture_comparisons_from_acceptance_report(report))
    required = sum(comparison["required_check_count"] for comparison in comparisons)
    passed = sum(comparison["passed_check_count"] for comparison in comparisons)
    failed = sum(comparison["failed_check_count"] for comparison in comparisons)
    return {
        "method": "imgui_fixture_comparison_payload_from_acceptance_reports",
        "fixture_comparisons": comparisons,
        "fixture_comparison_count": len(comparisons),
        "fixture_required_check_count": required,
        "fixture_passed_check_count": passed,
        "fixture_failed_check_count": failed,
        "notes": [
            "payload is designed for C++/Dear ImGui IrollFixtureComparison loading",
            "nested acceptance reports remain the authoritative computation evidence",
        ],
    }


def invariant_status_from_acceptance_report(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    """Return an `IrollInvariantStatus`-compatible report-level row."""

    required, passed, failed = _acceptance_check_counts(report)
    accepted = bool(report.get("accepted", False))
    notes = _notes_text(report)
    claim_scope = report.get("claim_scope")
    if claim_scope:
        notes = _append_note(notes, f"claim_scope: {claim_scope}")
    incomplete = report.get("incomplete_notations")
    if isinstance(incomplete, list) and incomplete:
        notes = _append_note(
            notes,
            "incomplete: " + ", ".join(str(item) for item in incomplete),
        )
    if report.get("method") == "diagram_fixture_source_table_invariant_audit":
        notes = _append_source_table_audit_notes(report, notes)
    if report.get("method") == "multivariable_alexander_fixture_acceptance_report":
        notes = _append_admissible_minor_scan_note(report, notes)
        notes = _append_source_table_alexander_acceptance_note(report, notes)
        notes = _append_source_table_registration_acceptance_note(report, notes)
    if report.get("method") == "homfly_fixture_acceptance_report":
        notes = _append_source_table_registration_acceptance_note(report, notes)
    notes = _append_bounded_homfly_maturity_path_note(report, notes)
    notes = _append_bounded_alexander_maturity_path_note(report, notes)
    notes = _append_alexander_maturity_path_summary_consistency_note(report, notes)
    notes = _append_homfly_case_evidence_consistency_note(report, notes)
    notes = _append_homfly_frontier_witness_summary_notes(report, notes)
    notes = _append_homfly_blocker_detail_notes(report, notes)
    notes = _append_alexander_witness_notes(report, notes)

    return {
        "name": name or _invariant_display_name(str(report.get("method", ""))),
        "value": _invariant_status_value(
            accepted=accepted,
            required=required,
            passed=passed,
            failed=failed,
        ),
        "skipped": _invariant_status_skipped(report, accepted=accepted, passed=passed),
        "notes": notes,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": failed,
        **_invariant_status_admissible_minor_fields(report),
        **_admissible_minor_normalization_counts(report),
        **_alexander_common_gcd_evidence_counts(report),
        **_bounded_homfly_maturity_path_count_fields(report),
        **_bounded_alexander_maturity_path_count_fields(report),
        **_alexander_maturity_path_summary_consistency_fields(report),
        **_homfly_case_evidence_consistency_fields(report),
        **_compact_host_evidence_counts(report),
        **(
            _blocker_summary_counts(report)
            if _has_nonzero_blocker_summary_input(report)
            else {}
        ),
        **_source_table_audit_counts(report),
        **_source_table_audit_registration_blocker_fields(report),
        **_source_table_audit_registration_summary_consistency_fields(report),
        **_source_table_homfly_variant_resolution_fields(report),
        **_source_table_audit_source_match_resolution_fields(report),
        **_source_table_alexander_numerator_counts(report),
        **_source_table_alexander_skipped_common_gcd_attempt_counts(report),
        **_source_table_alexander_source_divisibility_counts(report),
    }


def invariant_status_from_invariant_result_handle_report(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    """Return a skipped status row for a native unsupported-handle report."""

    invariant = str(report.get("invariant", "")).lower()
    if invariant == "homfly":
        invariant_name = "HOMFLY-PT native result handle"
    elif invariant == "alexander":
        invariant_name = "multi-variable Alexander native result handle"
    elif invariant:
        invariant_name = f"{invariant} native result handle"
    else:
        invariant_name = "native invariant result handle"

    notes = _notes_text(report)
    notes = _append_note(
        notes,
        (
            "invariant_result_handle_report: "
            f"handle_kind={_note_field_value(report.get('handle_kind'))}; "
            f"status={_note_field_value(report.get('status'))}; "
            f"status_code={_note_field_value(report.get('status_code'))}; "
            "blocking_status_code="
            f"{_note_field_value(report.get('blocking_status_code'))}; "
            f"blocking_gate={_note_field_value(report.get('blocking_gate'))}; "
            f"gate_status={_note_field_value(report.get('gate_status'))}; "
            "native_compute_handle_available="
            f"{_note_field_value(report.get('native_compute_handle_available'))}; "
            "native_computation_claimed="
            f"{_note_field_value(report.get('native_computation_claimed'))}; "
            f"result_available={_note_field_value(report.get('result_available'))}; "
            f"homfly_report_json={_note_field_value(report.get('homfly_report_json'))}; "
            "alexander_report_json="
            f"{_note_field_value(report.get('alexander_report_json'))}; "
            "python_file_recompute_boundary="
            f"{_note_field_value(report.get('python_file_recompute_boundary'))}; "
            f"current_boundary={_note_field_value(report.get('current_boundary'))}; "
            f"host_action={_note_field_value(report.get('host_action'))}; "
            f"claim_scope={_note_field_value(report.get('claim_scope'))}; "
            "complete_result_handle_abi="
            f"{_note_field_value(report.get('complete_result_handle_abi'))}; "
            "release_grade_result_handles="
            f"{_note_field_value(report.get('release_grade_result_handles'))}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "result_handle_transport: "
            f"abi_version={_note_field_value(report.get('abi_version'))}; "
            f"result_handle_abi={_note_field_value(report.get('result_handle_abi'))}; "
            "report_transport_abi="
            f"{_note_field_value(report.get('report_transport_abi'))}; "
            f"handle_create_symbol={_note_field_value(report.get('handle_create_symbol'))}; "
            f"handle_report_symbol={_note_field_value(report.get('handle_report_symbol'))}; "
            f"handle_free_symbol={_note_field_value(report.get('handle_free_symbol'))}; "
            "owned_string_free_symbol="
            f"{_note_field_value(report.get('owned_string_free_symbol'))}"
        ),
    )

    return {
        "name": name or invariant_name,
        "value": "skipped",
        "skipped": True,
        "notes": notes,
        "required_check_count": 0,
        "passed_check_count": 0,
        "failed_check_count": 0,
    }


def invariant_status_from_report(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    """Return an `IrollInvariantStatus` row from an acceptance or signed-PD report."""

    method = str(report.get("method", ""))
    if method == "invariant_result_handle_report":
        return invariant_status_from_invariant_result_handle_report(
            report,
            name=name,
        )
    if method in {
        "homfly_input_certification_evidence",
        "homfly_skein_identity_audit",
        "homfly_terminal_reduction_audit",
    }:
        return invariant_status_from_homfly_audit_report(report, name=name)
    if method in {"homfly_pd_report", "multivariable_alexander_pd_report"}:
        return invariant_status_from_pd_report(report, name=name)
    if method == "multivariable_alexander_improve_scanned_gcd_result":
        return invariant_status_from_alexander_improved_result(report, name=name)
    if method in {
        "multivariable_alexander_input_certification_evidence",
        "multivariable_alexander_admissible_minor_normalization_audit",
        "multivariable_alexander_minor_divisibility_audit",
        "multivariable_alexander_scanned_gcd_audit",
        "multivariable_alexander_wirtinger_fox_audit",
    }:
        return invariant_status_from_alexander_audit_report(report, name=name)
    return invariant_status_from_acceptance_report(report, name=name)


def invariant_status_from_pd_report(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    """Flatten one arbitrary signed-PD invariant report for Dear ImGui loading."""

    method = str(report.get("method", ""))
    admissible_source: Mapping[str, Any] | None = None
    blocker_source: Mapping[str, Any] | None = None
    if method == "homfly_pd_report":
        invariant_name = "HOMFLY-PT"
        value = report.get("homfly_polynomial")
        certified = bool(report.get("certified_for_input", False))
        passed = 1 if value and certified and not report.get("skipped", False) else 0
        notes = _append_note(_notes_text(report), f"certified_for_input={certified}")
        evidence = report.get("input_certification_evidence")
        if isinstance(evidence, Mapping):
            blocker_source = evidence
            frontier = _optional_count(evidence.get("frontier_count")) or 0
            truncated = bool(evidence.get("truncated", False))
            notes = _append_note(notes, f"frontier={frontier}; truncated={truncated}")
            notes = _append_homfly_frontier_witness_summary_notes(evidence, notes)
            frontier_exhausted = evidence.get("frontier_exhausted")
            if isinstance(frontier_exhausted, bool):
                notes = _append_note(
                    notes,
                    f"frontier_exhausted={frontier_exhausted}",
                )
            notes = _append_bounded_homfly_maturity_path_note(evidence, notes)
            run_cap_note = _homfly_run_cap_note(evidence)
            if run_cap_note is not None:
                notes = _append_note(notes, run_cap_note)
            terminal_skipped = evidence.get("terminal_contribution_audit_skipped")
            terminal_matched = evidence.get("terminal_contribution_matches_result")
            if isinstance(terminal_skipped, bool):
                terminal_note = f"terminal_contribution_skipped={terminal_skipped}"
                if isinstance(terminal_matched, bool):
                    terminal_note += f"; terminal_contribution_matched={terminal_matched}"
                notes = _append_note(notes, terminal_note)
            notes = _append_blocker_summary_note(
                evidence,
                notes,
                blockers_key="certification_blockers",
                count_key="certification_blocker_count",
                first_key="first_certification_blocker",
            )
            notes = _append_blocker_summary_note(
                evidence,
                notes,
                blockers_key="homfly_completion_blockers",
                count_key="homfly_completion_blocker_count",
                first_key="first_homfly_completion_blocker",
            )
            notes = _append_homfly_blocker_detail_notes(evidence, notes)
            frontier_reasons = evidence.get("frontier_reasons")
            if isinstance(frontier_reasons, list):
                reasons = [str(reason) for reason in frontier_reasons if str(reason)]
                if reasons:
                    notes = _append_note(
                        notes,
                        "frontier_reasons=" + ", ".join(reasons),
                    )
    elif method == "multivariable_alexander_pd_report":
        invariant_name = "multi-variable Alexander"
        value = report.get("multivariable_alexander_polynomial")
        passed = 1 if value and not report.get("skipped", False) else 0
        full_certified = bool(report.get("full_invariant_certified", False))
        notes = _append_note(_notes_text(report), f"full_invariant_certified={full_certified}")
        if report.get("zero_crossing_unlink_certified") is True:
            notes = _append_note(notes, "zero_crossing_unlink_certified=True")
        candidates = report.get("candidate_polynomials")
        if isinstance(candidates, list) and candidates:
            notes = _append_note(
                notes,
                "candidates: " + ", ".join(str(item) for item in candidates),
            )
        evidence = report.get("input_certification_evidence")
        if isinstance(evidence, Mapping):
            admissible_source = evidence
            blocker_source = evidence
            bounded = bool(evidence.get("bounded_scanned_gcd_certified", False))
            complete = bool(evidence.get("complete_scanned_gcd_certified", False))
            quotient = bool(evidence.get("quotient_gcd_certified", False))
            checked = _optional_count(evidence.get("checked_nonzero_minor_count")) or 0
            failed = _optional_count(evidence.get("failed_nonzero_minor_count")) or 0
            truncated = bool(evidence.get("truncated", False))
            notes = _append_note(
                notes,
                (
                    f"bounded_scanned_gcd_certified={bounded}; "
                    f"complete_scanned_gcd_certified={complete}; "
                    f"quotient_gcd_certified={quotient}; "
                    f"checked_nonzero_minors={checked}; "
                    f"failed_nonzero_minors={failed}; "
                    f"truncated={truncated}"
                ),
            )
            quotient_method = evidence.get("quotient_gcd_method")
            quotient_polynomial = evidence.get("quotient_gcd_polynomial")
            if quotient_method or quotient_polynomial:
                quotient_text = str(quotient_polynomial or "unknown")
                if quotient_method:
                    quotient_text += f" via {quotient_method}"
                notes = _append_note(notes, f"quotient_gcd={quotient_text}")
            improved = evidence.get("improved_candidate_polynomial")
            if improved:
                notes = _append_note(notes, f"improved_candidate={improved}")
            notes = _append_admissible_minor_normalization_note(evidence, notes)
            notes = _append_alexander_blocker_notes(evidence, notes)
            notes = _append_alexander_witness_notes(evidence, notes)
            notes = _append_admissible_minor_scan_note(evidence, notes)
            notes = _append_bounded_alexander_maturity_path_note(evidence, notes)
        notes = _append_common_gcd_attempt_note(report, notes)
    else:
        invariant_name = method.replace("_", " ") or "invariant"
        value = None
        passed = 0
        notes = _notes_text(report)

    required = 1
    failed = required - passed
    claim_scope = report.get("claim_scope")
    if claim_scope:
        notes = _append_note(notes, f"claim_scope: {claim_scope}")
    notes = _append_signed_pd_role_order_note(report, notes)
    notes = _append_signed_pd_auto_role_order_note(report, notes)
    notes = _append_source_candidate_replay_note(report, notes)
    skipped = bool(report.get("skipped", False)) or value in {None, ""}
    return {
        "name": name or invariant_name,
        "value": str(value) if value not in {None, ""} else "skipped",
        "skipped": skipped,
        "notes": notes,
        "required_check_count": required,
        "passed_check_count": passed,
        "failed_check_count": failed,
        **_invariant_status_admissible_minor_fields(admissible_source),
        **_admissible_minor_normalization_counts(admissible_source),
        **_alexander_common_gcd_evidence_counts(report),
        **_bounded_homfly_maturity_path_count_fields(blocker_source or report),
        **_bounded_alexander_maturity_path_count_fields(admissible_source or report),
        **_compact_host_evidence_counts(blocker_source or report),
        **_signed_pd_role_order_status_fields(report),
        **_signed_pd_auto_role_order_status_fields(report),
        **_source_candidate_replay_status_fields(report),
        **(
            _blocker_summary_counts(blocker_source)
            if _has_blocker_summary_input(blocker_source)
            else {}
        ),
        **_invariant_status_source_table_registration_fields(None),
        **_source_table_audit_source_match_resolution_fields(None),
        **_source_table_alexander_numerator_counts(None),
    }


def _append_source_candidate_replay_note(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    fields = _source_candidate_replay_status_fields(report)
    if not fields["source_candidate_replay_present"]:
        return notes
    parts = [
        f"claim_scope={fields['source_candidate_replay_claim_scope']}",
        f"source_notation={fields['source_candidate_replay_source_notation']}",
    ]
    if fields["source_candidate_replay_source"]:
        parts.append(f"source={fields['source_candidate_replay_source']}")
    if fields["source_candidate_replay_source_url"]:
        parts.append(f"source_url={fields['source_candidate_replay_source_url']}")
    if fields["source_candidate_replay_pairwise_linking"]:
        parts.append(
            f"pairwise_linking={fields['source_candidate_replay_pairwise_linking']}"
        )
    parts.append(f"sign_count={fields['source_candidate_replay_sign_count']}")
    parts.append(
        f"role_order_count={fields['source_candidate_replay_role_order_count']}"
    )
    parts.append(
        "orientation_issue_count="
        f"{fields['source_candidate_replay_orientation_issue_count']}"
    )
    return _append_note(notes, "source_candidate_replay=" + "; ".join(parts))


def _append_signed_pd_role_order_note(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    fields = _signed_pd_role_order_status_fields(report)
    if not fields["signed_pd_role_order_metadata_present"]:
        return notes
    return _append_note(
        notes,
        (
            "signed_pd_role_order_provenance="
            f"role_orders={fields['signed_pd_role_order_count']}; "
            f"explicit={fields['signed_pd_role_order_explicit_count']}"
        ),
    )


def _append_signed_pd_auto_role_order_note(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    fields = _signed_pd_auto_role_order_status_fields(report)
    if not fields["signed_pd_auto_role_order_present"]:
        return notes
    parts = [
        f"status={fields['signed_pd_auto_role_order_status']}",
        f"applied={fields['signed_pd_auto_role_order_applied']}",
        f"candidates={fields['signed_pd_auto_role_order_candidate_count']}",
        f"strict={fields['signed_pd_auto_role_order_strict_candidate_count']}",
    ]
    unique_role_order = fields[
        "signed_pd_auto_role_order_unique_strict_global_role_order"
    ]
    if unique_role_order:
        parts.append(f"unique_role_order={unique_role_order}")
    return _append_note(notes, "signed_pd_auto_role_order=" + "; ".join(parts))


def _signed_pd_role_order_status_fields(
    report: Mapping[str, Any],
) -> dict[str, int | bool]:
    input_payload = report.get("input")
    empty = {
        "signed_pd_role_order_metadata_present": False,
        "signed_pd_role_order_count": 0,
        "signed_pd_role_order_explicit_count": 0,
    }
    if not isinstance(input_payload, Mapping):
        return empty
    role_orders = input_payload.get("per_crossing_role_orders")
    explicit_values = input_payload.get("per_crossing_role_order_explicit")
    role_order_count = _sequence_count(role_orders)
    explicit_count = _optional_count(
        input_payload.get("per_crossing_role_order_explicit_count")
    )
    if explicit_count is None and isinstance(explicit_values, Sequence) and not isinstance(
        explicit_values,
        (str, bytes, bytearray),
    ):
        explicit_count = sum(1 for value in explicit_values if value is True)
    explicit_count = explicit_count or 0
    metadata_present = role_order_count > 0 or isinstance(
        explicit_values,
        Sequence,
    ) and not isinstance(explicit_values, (str, bytes, bytearray))
    return {
        "signed_pd_role_order_metadata_present": metadata_present,
        "signed_pd_role_order_count": role_order_count,
        "signed_pd_role_order_explicit_count": explicit_count,
    }


def _signed_pd_auto_role_order_status_fields(
    report: Mapping[str, Any],
) -> dict[str, int | str | bool]:
    input_payload = report.get("input")
    empty = {
        "signed_pd_auto_role_order_present": False,
        "signed_pd_auto_role_order_requested": False,
        "signed_pd_auto_role_order_applied": False,
        "signed_pd_auto_role_order_status": "",
        "signed_pd_auto_role_order_candidate_count": 0,
        "signed_pd_auto_role_order_strict_candidate_count": 0,
        "signed_pd_auto_role_order_unique_strict_global_role_order": "",
    }
    if not isinstance(input_payload, Mapping):
        return empty
    auto_role_order = input_payload.get("auto_role_order")
    if not isinstance(auto_role_order, Mapping):
        return empty
    requested = auto_role_order.get("requested") is True
    status = str(auto_role_order.get("status") or "")
    applied = auto_role_order.get("applied") is True
    candidate_count = _optional_count(auto_role_order.get("candidate_count")) or 0
    strict_count = _optional_count(
        auto_role_order.get("strict_candidate_count")
    ) or 0
    unique_role_order = auto_role_order.get("unique_strict_global_role_order")
    unique_text = ""
    if isinstance(unique_role_order, Sequence) and not isinstance(
        unique_role_order,
        (str, bytes, bytearray),
    ):
        unique_text = ",".join(str(item) for item in unique_role_order)
    elif unique_role_order not in (None, ""):
        unique_text = str(unique_role_order)
    if not applied:
        unique_text = ""
    if not requested and not applied and status in {"", "not_requested"}:
        return empty
    return {
        "signed_pd_auto_role_order_present": True,
        "signed_pd_auto_role_order_requested": requested,
        "signed_pd_auto_role_order_applied": applied,
        "signed_pd_auto_role_order_status": status,
        "signed_pd_auto_role_order_candidate_count": candidate_count,
        "signed_pd_auto_role_order_strict_candidate_count": strict_count,
        "signed_pd_auto_role_order_unique_strict_global_role_order": unique_text,
    }


def _source_candidate_replay_status_fields(
    report: Mapping[str, Any],
) -> dict[str, int | str | bool]:
    input_payload = report.get("input")
    empty = {
        "source_candidate_replay_present": False,
        "source_candidate_replay_claim_scope": "",
        "source_candidate_replay_source_notation": "",
        "source_candidate_replay_source": "",
        "source_candidate_replay_source_url": "",
        "source_candidate_replay_pairwise_linking": "",
        "source_candidate_replay_sign_count": 0,
        "source_candidate_replay_role_order_count": 0,
        "source_candidate_replay_orientation_issue_count": 0,
    }
    if not isinstance(input_payload, Mapping):
        return empty
    replay = input_payload.get("source_candidate_replay")
    if not isinstance(replay, Mapping) or replay.get("present") is not True:
        return empty
    pairwise = replay.get("pairwise_linking")
    pairwise_text = ""
    if isinstance(pairwise, Sequence) and not isinstance(
        pairwise,
        (str, bytes, bytearray),
    ):
        pairwise_text = ",".join(str(item) for item in pairwise)
    return {
        **empty,
        "source_candidate_replay_present": True,
        "source_candidate_replay_claim_scope": str(replay.get("claim_scope") or ""),
        "source_candidate_replay_source_notation": str(
            replay.get("source_notation") or ""
        ),
        "source_candidate_replay_source": str(replay.get("source") or ""),
        "source_candidate_replay_source_url": str(replay.get("source_url") or ""),
        "source_candidate_replay_pairwise_linking": pairwise_text,
        "source_candidate_replay_sign_count": _sequence_count(replay.get("signs")),
        "source_candidate_replay_role_order_count": _sequence_count(
            replay.get("role_orders")
        ),
        "source_candidate_replay_orientation_issue_count": _sequence_count(
            replay.get("orientation_validation_issues")
        ),
    }


def invariant_status_from_alexander_improved_result(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    """Flatten an improved bounded scanned-gcd result for Dear ImGui loading."""

    result = report.get("result")
    result_mapping = result if isinstance(result, Mapping) else {}
    value = result_mapping.get("multivariable_alexander_polynomial")
    accepted = bool(report.get("accepted", False))
    skipped = bool(report.get("skipped", False)) or value in {None, ""}
    passed = 1 if value and accepted and not skipped else 0
    notes = _append_note(_notes_text(report), f"accepted={accepted}")
    source_polynomial = report.get("source_polynomial")
    if source_polynomial:
        notes = _append_note(notes, f"source_polynomial={source_polynomial}")
    improved = report.get("improved_candidate_polynomial")
    if improved:
        notes = _append_note(notes, f"improved_candidate={improved}")

    improved_audit = report.get("improved_audit")
    admissible_source: Mapping[str, Any] | None = None
    if isinstance(improved_audit, Mapping):
        admissible_source = improved_audit
        exact = bool(improved_audit.get("candidate_is_exact_scanned_gcd", False))
        complete = bool(improved_audit.get("complete_scanned_gcd_certified", False))
        quotient = bool(improved_audit.get("quotient_gcd_certified", False))
        checked = _optional_count(improved_audit.get("checked_nonzero_minor_count")) or 0
        failed = _optional_count(improved_audit.get("failed_nonzero_minor_count")) or 0
        notes = _append_note(
            notes,
            (
                f"exact_scanned_gcd={exact}; "
                f"complete_scanned_gcd_certified={complete}; "
                f"quotient_gcd_certified={quotient}; "
                f"checked_nonzero_minors={checked}; "
                f"failed_nonzero_minors={failed}"
            ),
        )
        quotient_method = improved_audit.get("quotient_gcd_method")
        quotient_polynomial = improved_audit.get("quotient_gcd_polynomial")
        if quotient_method or quotient_polynomial:
            quotient_text = str(quotient_polynomial or "unknown")
            if quotient_method:
                quotient_text += f" via {quotient_method}"
            notes = _append_note(notes, f"quotient_gcd={quotient_text}")
        notes = _append_admissible_minor_scan_note(improved_audit, notes)
    notes = _append_alexander_witness_notes(report, notes)

    gcd_counts = _alexander_common_gcd_evidence_counts(report)
    source_audit = report.get("source_audit")
    for nested in (source_audit, improved_audit):
        if not isinstance(nested, Mapping):
            continue
        for key, count_value in _alexander_common_gcd_evidence_counts(nested).items():
            gcd_counts[key] += count_value

    return {
        "name": name or "multi-variable Alexander improved scanned gcd",
        "value": str(value) if value not in {None, ""} else "skipped",
        "skipped": skipped,
        "notes": notes,
        "required_check_count": 1,
        "passed_check_count": passed,
        "failed_check_count": 1 - passed,
        **_invariant_status_admissible_minor_fields(admissible_source),
        **_admissible_minor_normalization_counts(admissible_source),
        **gcd_counts,
        **_compact_host_evidence_counts(report),
        **(
            _blocker_summary_counts(report)
            if _has_blocker_summary_input(report)
            else {}
        ),
        **_invariant_status_source_table_registration_fields(None),
        **_source_table_audit_source_match_resolution_fields(None),
        **_source_table_alexander_numerator_counts(None),
    }


def invariant_status_from_homfly_audit_report(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    """Flatten a direct HOMFLY audit/evidence report for status reloads."""

    method = str(report.get("method", ""))
    skipped = bool(report.get("skipped", False))
    notes = _notes_text(report)
    value = report.get("homfly_polynomial")

    if method == "homfly_input_certification_evidence":
        invariant_name = "HOMFLY-PT input evidence"
        certified = bool(report.get("certified_for_input", False))
        frontier_exhausted = bool(report.get("frontier_exhausted", False))
        frontier_count = _optional_count(report.get("frontier_count")) or 0
        frontier_reason_count = _optional_count(report.get("frontier_reason_count")) or 0
        truncated = bool(report.get("truncated", False))
        terminal_applicable = report.get("terminal_contribution_audit_skipped") is False
        terminal_matched = bool(
            report.get("terminal_contribution_matches_result", False)
        )
        accepted = (
            not skipped
            and certified
            and frontier_exhausted
            and (terminal_matched if terminal_applicable else True)
        )
        notes = _append_note(
            notes,
            (
                f"certified_for_input={certified}; "
                f"frontier_exhausted={frontier_exhausted}; "
                f"frontier={frontier_count}; "
                f"frontier_reasons={frontier_reason_count}; "
                f"truncated={truncated}; "
                f"terminal_contribution_skipped={not terminal_applicable}; "
            f"terminal_contribution_matched={terminal_matched}"
            ),
        )
        notes = _append_bounded_homfly_maturity_path_note(report, notes)
        notes = _append_homfly_reduction_contribution_witness_notes(report, notes)
        notes = _append_blocker_summary_note(
            report,
            notes,
            blockers_key="certification_blockers",
            count_key="certification_blocker_count",
            first_key="first_certification_blocker",
        )
        notes = _append_blocker_summary_note(
            report,
            notes,
            blockers_key="homfly_completion_blockers",
            count_key="homfly_completion_blocker_count",
            first_key="first_homfly_completion_blocker",
        )
        notes = _append_homfly_blocker_detail_notes(report, notes)
        run_cap_note = _homfly_run_cap_note(report)
        if run_cap_note is not None:
            notes = _append_note(notes, run_cap_note)
        frontier_reasons = report.get("frontier_reasons")
        if isinstance(frontier_reasons, list):
            reasons = [str(reason) for reason in frontier_reasons if str(reason)]
            if reasons:
                notes = _append_note(
                    notes,
                    "frontier_reasons=" + ", ".join(reasons),
                )
    elif method == "homfly_terminal_reduction_audit":
        invariant_name = "HOMFLY-PT terminal reduction"
        matched = bool(report.get("matched_result", False)) and not skipped
        terminal_reductions = _optional_count(report.get("terminal_reduction_count")) or 0
        failed_reductions = (
            _optional_count(report.get("failed_terminal_reduction_count")) or 0
        )
        frontier_count = _optional_count(report.get("frontier_count")) or 0
        truncated = bool(report.get("truncated", False))
        accepted = matched and failed_reductions == 0
        notes = _append_note(
            notes,
            (
                f"matched_result={matched}; "
                f"terminal_reductions={terminal_reductions}; "
                f"failed_terminal_reductions={failed_reductions}; "
                f"frontier={frontier_count}; "
                f"truncated={truncated}"
            ),
        )
        terminal_sum = report.get("terminal_contribution_sum")
        if terminal_sum is not None:
            notes = _append_note(notes, f"terminal_contribution_sum={terminal_sum}")
        notes = _append_homfly_reduction_contribution_witness_notes(report, notes)
    else:
        invariant_name = "HOMFLY-PT skein identity"
        matched = bool(report.get("matched", False)) and not skipped
        checked = _optional_count(report.get("checked_crossing_count")) or 0
        crossing_count = _optional_count(report.get("crossing_count")) or 0
        frontier_count = _homfly_skein_branch_frontier_count(report)
        truncated = bool(report.get("truncated", False))
        accepted = matched
        value = "matched" if matched else "failed"
        notes = _append_note(
            notes,
            (
                f"matched={matched}; "
                f"checked_crossings={checked}; "
                f"crossing_count={crossing_count}; "
                f"branch_frontier={frontier_count}; "
                f"truncated={truncated}"
            ),
        )

    notes = _append_homfly_frontier_witness_summary_notes(report, notes)
    notes = _append_note(
        notes,
        (
            "full_table_normalization_certified=False; "
            "arbitrary_diagram_coverage_certified=False"
        ),
    )
    claim_scope = report.get("claim_scope")
    if claim_scope:
        notes = _append_note(notes, f"claim_scope: {claim_scope}")
    if value in {None, ""}:
        value = "skipped" if skipped else ("passed" if accepted else "failed")
    passed = 1 if accepted else 0
    return {
        "name": name or invariant_name,
        "value": str(value),
        "skipped": skipped,
        "notes": notes,
        "required_check_count": 1,
        "passed_check_count": passed,
        "failed_check_count": 1 - passed,
        **_invariant_status_admissible_minor_fields(None),
        **_admissible_minor_normalization_counts(None),
        **_bounded_homfly_maturity_path_count_fields(report),
        **_compact_host_evidence_counts(report),
        **_blocker_summary_counts(report),
        **_invariant_status_source_table_registration_fields(None),
        **_source_table_audit_source_match_resolution_fields(None),
        **_source_table_alexander_numerator_counts(None),
    }


def invariant_status_from_alexander_audit_report(
    report: Mapping[str, Any],
    *,
    name: str | None = None,
) -> dict[str, Any]:
    """Flatten a direct Alexander audit/evidence report for status reloads."""

    method = str(report.get("method", ""))
    skipped = bool(report.get("skipped", False))
    notes = _notes_text(report)
    value = report.get("multivariable_alexander_polynomial")

    if method == "multivariable_alexander_minor_divisibility_audit":
        invariant_name = "multi-variable Alexander minor divisibility"
        all_divisible = bool(report.get("all_nonzero_minors_divisible", False))
        checked = _optional_count(report.get("checked_nonzero_minor_count")) or 0
        failed = _optional_count(report.get("failed_nonzero_minor_count")) or 0
        complete = bool(report.get("complete_combination_scan", False))
        truncated = bool(report.get("truncated", False))
        accepted = not skipped and all_divisible and failed == 0
        notes = _append_note(
            notes,
            (
                f"all_nonzero_minors_divisible={all_divisible}; "
                f"checked_nonzero_minors={checked}; "
                f"failed_nonzero_minors={failed}; "
                f"complete_combination_scan={complete}; "
                f"truncated={truncated}"
            ),
        )
    elif method == "multivariable_alexander_admissible_minor_normalization_audit":
        invariant_name = "multi-variable Alexander admissible-minor normalization"
        all_equivalent = bool(
            report.get("all_nonzero_minors_laurent_unit_equivalent", False)
        )
        bounded_certified = bool(
            report.get("bounded_admissible_minor_normalization_certified", False)
        )
        checked = _optional_count(report.get("checked_nonzero_minor_count")) or 0
        failed = _optional_count(report.get("failed_nonzero_minor_count")) or 0
        complete = bool(report.get("complete_combination_scan", False))
        nonzero_coverage_complete = bool(
            report.get("nonzero_minor_coverage_complete", False)
        )
        truncated = bool(report.get("truncated", False))
        representative = report.get("normalized_representative_polynomial")
        accepted = not skipped and bounded_certified
        value = representative or ("skipped" if skipped else "not certified")
        notes = _append_note(
            notes,
            (
                "admissible_minor_normalization="
                f"representative={representative or 'none'}; "
                f"all_nonzero_laurent_unit_equivalent={all_equivalent}; "
                f"bounded_certified={bounded_certified}; "
                f"checked_nonzero_minors={checked}; "
                f"failed_nonzero_minors={failed}; "
                f"complete_combination_scan={complete}; "
                f"nonzero_coverage_complete={nonzero_coverage_complete}; "
                f"truncated={truncated}"
            ),
        )
    elif method == "multivariable_alexander_scanned_gcd_audit":
        invariant_name = "multi-variable Alexander scanned gcd"
        exact = bool(report.get("candidate_is_exact_scanned_gcd", False))
        complete = bool(report.get("complete_scanned_gcd_certified", False))
        quotient = bool(report.get("quotient_gcd_certified", False))
        checked = _optional_count(report.get("checked_nonzero_minor_count")) or 0
        failed = _optional_count(report.get("failed_nonzero_minor_count")) or 0
        accepted = not skipped and exact
        notes = _append_note(
            notes,
            (
                f"exact_scanned_gcd={exact}; "
                f"complete_scanned_gcd_certified={complete}; "
                f"quotient_gcd_certified={quotient}; "
                f"checked_nonzero_minors={checked}; "
                f"failed_nonzero_minors={failed}"
            ),
        )
        quotient_method = report.get("quotient_gcd_method")
        quotient_polynomial = report.get("quotient_gcd_polynomial")
        if quotient_method or quotient_polynomial:
            quotient_text = str(quotient_polynomial or "unknown")
            if quotient_method:
                quotient_text += f" via {quotient_method}"
            notes = _append_note(notes, f"quotient_gcd={quotient_text}")
        improved = report.get("improved_candidate_polynomial")
        if improved:
            notes = _append_note(notes, f"improved_candidate={improved}")
    elif method == "multivariable_alexander_input_certification_evidence":
        invariant_name = "multi-variable Alexander input evidence"
        bounded = bool(report.get("bounded_scanned_gcd_certified", False))
        complete = bool(report.get("complete_scanned_gcd_certified", False))
        quotient = bool(report.get("quotient_gcd_certified", False))
        failed = _optional_count(report.get("failed_nonzero_minor_count")) or 0
        wirtinger_available = any(
            report.get(key)
            for key in (
                "wirtinger_fox_input_chain_consistent",
                "wirtinger_presentation_valid",
                "fox_jacobian_valid",
                "fox_square_minor_scan_valid",
            )
        )
        wirtinger_consistent = bool(
            report.get("wirtinger_fox_input_chain_consistent", False)
        )
        accepted = (
            not skipped
            and bounded
            and failed == 0
            and (wirtinger_consistent if wirtinger_available else True)
        )
        notes = _append_note(
            notes,
            (
                f"bounded_scanned_gcd_certified={bounded}; "
                f"complete_scanned_gcd_certified={complete}; "
                f"quotient_gcd_certified={quotient}; "
                f"failed_nonzero_minors={failed}; "
                f"wirtinger_fox_input_chain_consistent={wirtinger_consistent}"
            ),
        )
        quotient_method = report.get("quotient_gcd_method")
        quotient_polynomial = report.get("quotient_gcd_polynomial")
        if quotient_method or quotient_polynomial:
            quotient_text = str(quotient_polynomial or "unknown")
            if quotient_method:
                quotient_text += f" via {quotient_method}"
            notes = _append_note(notes, f"quotient_gcd={quotient_text}")
        notes = _append_admissible_minor_normalization_note(report, notes)
        notes = _append_alexander_blocker_notes(report, notes)
    else:
        invariant_name = "multi-variable Alexander Wirtinger/Fox"
        presentation_valid = bool(report.get("presentation_valid", False))
        jacobian_valid = bool(report.get("fox_jacobian_valid", False))
        scan_valid = bool(report.get("fox_square_minor_scan_valid", False))
        consistent = bool(report.get("input_chain_consistent", False))
        relation_count = _optional_count(report.get("relation_count")) or 0
        generator_count = _optional_count(report.get("generator_count")) or 0
        scanned_minor_count = _optional_count(report.get("scanned_minor_count")) or 0
        accepted = (
            not skipped
            and presentation_valid
            and jacobian_valid
            and scan_valid
            and consistent
        )
        value = "consistent" if accepted else "inconsistent"
        notes = _append_note(
            notes,
            (
                f"presentation_valid={presentation_valid}; "
                f"fox_jacobian_valid={jacobian_valid}; "
                f"fox_square_minor_scan_valid={scan_valid}; "
                f"input_chain_consistent={consistent}; "
                f"relations={relation_count}; "
                f"generators={generator_count}; "
                f"scanned_minors={scanned_minor_count}"
            ),
        )

    notes = _append_admissible_minor_scan_note(report, notes)
    notes = _append_common_gcd_attempt_note(report, notes)
    notes = _append_alexander_wirtinger_relation_shape_notes(report, notes)
    notes = _append_alexander_witness_notes(report, notes)
    notes = _append_bounded_alexander_maturity_path_note(report, notes)
    notes = _append_alexander_maturity_path_summary_consistency_note(report, notes)
    notes = _append_note(notes, "full_invariant_certified=False")
    claim_scope = report.get("claim_scope")
    if claim_scope:
        notes = _append_note(notes, f"claim_scope: {claim_scope}")
    if value in {None, ""}:
        value = "skipped" if skipped else ("passed" if accepted else "failed")
    passed = 1 if accepted else 0
    return {
        "name": name or invariant_name,
        "value": str(value),
        "skipped": skipped,
        "notes": notes,
        "required_check_count": 1,
        "passed_check_count": passed,
        "failed_check_count": 1 - passed,
        **_invariant_status_admissible_minor_fields(report),
        **_admissible_minor_normalization_counts(report),
        **_alexander_common_gcd_evidence_counts(report),
        **_bounded_alexander_maturity_path_count_fields(report),
        **_alexander_maturity_path_summary_consistency_fields(report),
        **_compact_host_evidence_counts(report),
        **_blocker_summary_counts(report),
        **_invariant_status_source_table_registration_fields(None),
        **_source_table_audit_source_match_resolution_fields(None),
        **_source_table_alexander_numerator_counts(None),
    }


def _invariant_status_payload_evidence_counts(
    statuses: Iterable[Mapping[str, Any]],
) -> dict[str, int]:
    rows = list(statuses)
    counts = {
        f"invariant_{key}": 0
        for key in (
            _INVARIANT_STATUS_ADMISSIBLE_MINOR_KEYS
            + _ADMISSIBLE_MINOR_NORMALIZATION_KEYS
            + _ALEXANDER_COMMON_GCD_EVIDENCE_KEYS
            + _HOMFLY_MATURITY_PATH_COUNT_KEYS
            + _ALEXANDER_MATURITY_PATH_COUNT_KEYS
            + _ALEXANDER_MATURITY_PATH_SUMMARY_CONSISTENCY_COUNT_KEYS
            + _HOMFLY_CASE_EVIDENCE_CONSISTENCY_COUNT_KEYS
            + _COMPACT_HOST_EVIDENCE_KEYS
            + _INVARIANT_STATUS_SOURCE_TABLE_AUDIT_KEYS
            + _SOURCE_TABLE_ALEXANDER_NUMERATOR_KEYS
        )
    }
    for status in rows:
        for key in (
            _INVARIANT_STATUS_ADMISSIBLE_MINOR_KEYS
            + _ADMISSIBLE_MINOR_NORMALIZATION_KEYS
            + _ALEXANDER_COMMON_GCD_EVIDENCE_KEYS
            + _HOMFLY_MATURITY_PATH_COUNT_KEYS
            + _ALEXANDER_MATURITY_PATH_COUNT_KEYS
            + _ALEXANDER_MATURITY_PATH_SUMMARY_CONSISTENCY_COUNT_KEYS
            + _HOMFLY_CASE_EVIDENCE_CONSISTENCY_COUNT_KEYS
            + _COMPACT_HOST_EVIDENCE_KEYS
            + _INVARIANT_STATUS_SOURCE_TABLE_AUDIT_KEYS
            + _SOURCE_TABLE_ALEXANDER_NUMERATOR_KEYS
        ):
            counts[f"invariant_{key}"] += _optional_count(status.get(key)) or 0
    if any(_has_blocker_summary_input(status) for status in rows):
        for key in _BLOCKER_SUMMARY_KEYS:
            counts[f"invariant_{key}"] = sum(
                _optional_count(status.get(key)) or 0
                for status in rows
            )
    _set_payload_maturity_path_distinct_counts(counts, prefix="invariant")
    return counts


def _invariant_status_payload_source_candidate_replay_fields(
    statuses: Iterable[Mapping[str, Any]],
) -> dict[str, int | str]:
    rows = list(statuses)
    replay_rows = [
        row for row in rows if row.get("source_candidate_replay_present") is True
    ]
    source_notations = sorted(
        {
            str(row.get("source_candidate_replay_source_notation"))
            for row in replay_rows
            if row.get("source_candidate_replay_source_notation") not in (None, "")
        }
    )
    claim_scopes = sorted(
        {
            str(row.get("source_candidate_replay_claim_scope"))
            for row in replay_rows
            if row.get("source_candidate_replay_claim_scope") not in (None, "")
        }
    )
    return {
        "invariant_source_candidate_replay_count": len(replay_rows),
        "invariant_source_candidate_replay_source_notation_count": len(
            source_notations
        ),
        "invariant_source_candidate_replay_source_notations": ",".join(
            source_notations
        ),
        "invariant_source_candidate_replay_claim_scope_count": len(claim_scopes),
        "invariant_source_candidate_replay_claim_scopes": ",".join(claim_scopes),
        "invariant_source_candidate_replay_sign_count": sum(
            _optional_count(row.get("source_candidate_replay_sign_count")) or 0
            for row in replay_rows
        ),
        "invariant_source_candidate_replay_role_order_count": sum(
            _optional_count(row.get("source_candidate_replay_role_order_count")) or 0
            for row in replay_rows
        ),
        "invariant_source_candidate_replay_orientation_issue_count": sum(
            _optional_count(
                row.get("source_candidate_replay_orientation_issue_count")
            )
            or 0
            for row in replay_rows
        ),
    }


def _invariant_status_payload_signed_pd_role_order_fields(
    statuses: Iterable[Mapping[str, Any]],
) -> dict[str, int]:
    rows = list(statuses)
    metadata_rows = [
        row for row in rows if row.get("signed_pd_role_order_metadata_present") is True
    ]
    return {
        "invariant_signed_pd_role_order_metadata_count": len(metadata_rows),
        "invariant_signed_pd_role_order_count": sum(
            _optional_count(row.get("signed_pd_role_order_count")) or 0
            for row in metadata_rows
        ),
        "invariant_signed_pd_role_order_explicit_count": sum(
            _optional_count(row.get("signed_pd_role_order_explicit_count")) or 0
            for row in metadata_rows
        ),
    }


def _invariant_status_payload_signed_pd_auto_role_order_fields(
    statuses: Iterable[Mapping[str, Any]],
) -> dict[str, int]:
    rows = list(statuses)
    auto_rows = [
        row for row in rows if row.get("signed_pd_auto_role_order_present") is True
    ]
    return {
        "invariant_signed_pd_auto_role_order_present_count": len(auto_rows),
        "invariant_signed_pd_auto_role_order_requested_count": sum(
            1
            for row in auto_rows
            if row.get("signed_pd_auto_role_order_requested") is True
        ),
        "invariant_signed_pd_auto_role_order_applied_count": sum(
            1
            for row in auto_rows
            if row.get("signed_pd_auto_role_order_applied") is True
        ),
        "invariant_signed_pd_auto_role_order_not_needed_count": sum(
            1
            for row in auto_rows
            if row.get("signed_pd_auto_role_order_status") == "not_needed"
        ),
        "invariant_signed_pd_auto_role_order_unique_applied_count": sum(
            1
            for row in auto_rows
            if row.get("signed_pd_auto_role_order_status") == "unique_applied"
        ),
        "invariant_signed_pd_auto_role_order_ambiguous_count": sum(
            1
            for row in auto_rows
            if row.get("signed_pd_auto_role_order_status") == "ambiguous"
        ),
        "invariant_signed_pd_auto_role_order_no_strict_candidate_count": sum(
            1
            for row in auto_rows
            if row.get("signed_pd_auto_role_order_status") == "no_strict_candidate"
        ),
        "invariant_signed_pd_auto_role_order_candidate_count": sum(
            _optional_count(row.get("signed_pd_auto_role_order_candidate_count")) or 0
            for row in auto_rows
        ),
        "invariant_signed_pd_auto_role_order_strict_candidate_count": sum(
            _optional_count(
                row.get("signed_pd_auto_role_order_strict_candidate_count")
            )
            or 0
            for row in auto_rows
        ),
    }


def imgui_invariant_status_payload_from_reports(
    reports: Iterable[Mapping[str, Any]],
    *,
    signed_pd_revision: int | None = None,
) -> dict[str, Any]:
    """Flatten mixed acceptance and signed-PD reports for host-loaded ImGui rows."""

    report_list = list(reports)
    statuses = [invariant_status_from_report(report) for report in report_list]
    required = sum(status["required_check_count"] for status in statuses)
    passed = sum(status["passed_check_count"] for status in statuses)
    failed = sum(status["failed_check_count"] for status in statuses)
    payload = {
        "method": "imgui_invariant_status_payload_from_reports",
        "invariant_statuses": statuses,
        "invariant_status_count": len(statuses),
        "invariant_required_check_count": required,
        "invariant_passed_check_count": passed,
        "invariant_failed_check_count": failed,
        **_invariant_status_payload_evidence_counts(statuses),
        **_invariant_status_payload_signed_pd_role_order_fields(statuses),
        **_invariant_status_payload_signed_pd_auto_role_order_fields(statuses),
        **_invariant_status_payload_source_candidate_replay_fields(statuses),
        "notes": [
            "payload is designed for C++/Dear ImGui IrollInvariantStatus loading",
            "source reports remain the authoritative computation evidence",
        ],
    }
    if signed_pd_revision is not None:
        payload["signed_pd_revision"] = signed_pd_revision
    else:
        common_revision = _common_source_signed_pd_revision(report_list)
        if common_revision is not None:
            payload["signed_pd_revision"] = common_revision
    return payload


def _common_source_signed_pd_revision(
    reports: Iterable[Mapping[str, Any]],
) -> int | None:
    revisions: set[int] = set()
    for report in reports:
        revisions.update(_source_signed_pd_revisions(report))
    if len(revisions) == 1:
        return next(iter(revisions))
    return None


def imgui_invariant_status_payload_from_acceptance_reports(
    reports: Iterable[Mapping[str, Any]],
) -> dict[str, Any]:
    """Flatten acceptance reports for host-loaded ImGui invariant statuses."""

    statuses = [
        invariant_status_from_acceptance_report(report)
        for report in reports
    ]
    required = sum(status["required_check_count"] for status in statuses)
    passed = sum(status["passed_check_count"] for status in statuses)
    failed = sum(status["failed_check_count"] for status in statuses)
    return {
        "method": "imgui_invariant_status_payload_from_acceptance_reports",
        "invariant_statuses": statuses,
        "invariant_status_count": len(statuses),
        "invariant_required_check_count": required,
        "invariant_passed_check_count": passed,
        "invariant_failed_check_count": failed,
        **_invariant_status_payload_evidence_counts(statuses),
        **_invariant_status_payload_source_candidate_replay_fields(statuses),
        "notes": [
            "payload is designed for C++/Dear ImGui IrollInvariantStatus loading",
            "nested acceptance reports remain the authoritative computation evidence",
        ],
    }


def signed_pd_payloads_from_acceptance_report(
    report: Mapping[str, Any],
) -> list[dict[str, Any]]:
    """Return host-selectable signed-PD diagrams from fixture rows."""

    rows = report.get("fixtures", [])
    if not isinstance(rows, list):
        return []
    payloads = []
    for row in rows:
        if not isinstance(row, Mapping):
            continue
        payload = signed_pd_payload_from_acceptance_row(row)
        if payload is not None:
            payloads.append(payload)
    return payloads


def signed_pd_payload_from_acceptance_row(
    row: Mapping[str, Any],
) -> dict[str, Any] | None:
    """Flatten one fixture's signed PD for `IrollImGui_LoadSignedPlanarDiagram`."""

    fixture = _fixture_payload_from_row(row)
    if fixture is None:
        return None
    pd_code = fixture.get("pd_code")
    signs = fixture.get("signs")
    if not isinstance(pd_code, list) or not isinstance(signs, list):
        return None
    if len(pd_code) != len(signs):
        return None

    orientation_role_orders = fixture.get("orientation_role_orders")
    role_orders: list[list[int]] = []
    role_orders_explicit: list[bool] = []
    if isinstance(orientation_role_orders, list) and len(orientation_role_orders) == len(pd_code):
        for order in orientation_role_orders:
            if not isinstance(order, list) or len(order) != 4:
                return None
            role_order = [int(position) for position in order]
            if sorted(role_order) != [0, 1, 2, 3]:
                return None
            role_orders.append(role_order)
            role_orders_explicit.append(True)
    else:
        role_orders = [[0, 1, 2, 3] for _ in pd_code]
        role_orders_explicit = [False for _ in pd_code]

    crossings = []
    for pd_crossing, sign, role_order, role_order_explicit in zip(
        pd_code,
        signs,
        role_orders,
        role_orders_explicit,
    ):
        if (
            not isinstance(pd_crossing, list)
            or len(pd_crossing) != 4
            or sign not in (-1, 1)
        ):
            return None
        crossings.append(
            {
                "sign": int(sign),
                "edge_labels": [int(edge) for edge in pd_crossing],
                "role_order": role_order,
                "role_order_explicit": role_order_explicit,
            }
        )

    component_count = _optional_count(fixture.get("component_count")) or 0
    notes = _fixture_row_notes(row, {})
    convention_notes = fixture.get("convention_notes")
    if isinstance(convention_notes, list) and convention_notes:
        notes = _append_note(
            notes,
            "convention: " + "; ".join(str(note) for note in convention_notes),
        )
    orientation_role_orders = fixture.get("orientation_role_orders")
    if orientation_role_orders:
        notes = _append_note(notes, "explicit orientation role orders are registered")

    return {
        "fixture_name": str(fixture.get("notation") or row.get("notation") or ""),
        "name": str(fixture.get("name") or row.get("name") or ""),
        "component_count": component_count,
        "crossings": crossings,
        "crossing_count": len(crossings),
        "notes": notes,
    }


def imgui_signed_pd_payload_from_acceptance_reports(
    reports: Iterable[Mapping[str, Any]],
) -> dict[str, Any]:
    """Collect signed-PD fixture diagrams for the native ImGui signed-PD panel."""

    diagrams: list[dict[str, Any]] = []
    skipped: list[str] = []
    for report in reports:
        rows = report.get("fixtures", [])
        if not isinstance(rows, list):
            continue
        for row in rows:
            if not isinstance(row, Mapping):
                continue
            payload = signed_pd_payload_from_acceptance_row(row)
            if payload is None:
                notation = row.get("notation")
                if notation is not None:
                    skipped.append(str(notation))
                continue
            diagrams.append(payload)
    return {
        "method": "imgui_signed_pd_payload_from_acceptance_reports",
        "signed_pd_diagrams": diagrams,
        "signed_pd_diagram_count": len(diagrams),
        "signed_pd_crossing_count": sum(
            diagram["crossing_count"] for diagram in diagrams
        ),
        "skipped_fixture_count": len(skipped),
        "skipped_fixtures": skipped,
        "notes": [
            "payload is designed for host selection followed by IrollImGui_LoadSignedPlanarDiagram",
            "the C++ panel still displays one signed-PD diagram at a time",
        ],
    }


def kernel_backend_statuses_from_backend_report(
    report: Mapping[str, Any],
) -> list[dict[str, Any]]:
    """Return `IrollKernelBackendStatus`-compatible backend rows."""

    backends = report.get("backends")
    if not isinstance(backends, Mapping):
        return []
    kernel_capabilities = report.get("kernel_capabilities")
    capability_names = (
        [str(name) for name in kernel_capabilities]
        if isinstance(kernel_capabilities, list)
        else []
    )
    auto_backend = str(report.get("auto_backend", ""))
    statuses = []
    for name in ("numpy", "rust", "gpu"):
        entry = backends.get(name)
        if isinstance(entry, Mapping):
            statuses.append(
                kernel_backend_status_from_backend_entry(
                    name,
                    entry,
                    capability_names=capability_names,
                    selected_by_auto=name == auto_backend,
                )
            )
    for name, entry in backends.items():
        if name in {"numpy", "rust", "gpu"} or not isinstance(entry, Mapping):
            continue
        statuses.append(
            kernel_backend_status_from_backend_entry(
                str(name),
                entry,
                capability_names=capability_names,
                selected_by_auto=str(name) == auto_backend,
            )
        )
    return statuses


def kernel_backend_status_from_backend_entry(
    name: str,
    entry: Mapping[str, Any],
    *,
    capability_names: Iterable[str] = (),
    selected_by_auto: bool = False,
) -> dict[str, Any]:
    """Flatten one backend-report row for Dear ImGui loading."""

    capabilities = entry.get("capabilities")
    capability_map: Mapping[str, Any] = (
        capabilities if isinstance(capabilities, Mapping) else {}
    )
    expected_names = list(capability_names) or [
        str(key) for key in capability_map.keys()
    ]
    available_capabilities = [
        name for name in expected_names if capability_map.get(name) is True
    ]
    missing_capabilities = entry.get("missing_capabilities")
    missing = (
        [str(name) for name in missing_capabilities]
        if isinstance(missing_capabilities, list)
        else [
            name
            for name in expected_names
            if capability_map.get(name) is not True
        ]
    )
    notes = _backend_status_notes(entry)
    owned_string_contract = _backend_owned_string_contract_fields(entry)
    invariant_result_handles = _backend_invariant_result_handle_readiness_fields(
        entry
    )
    return {
        "name": name,
        "display_name": _backend_display_name(name),
        "available": bool(entry.get("available", False)),
        "selected": bool(entry.get("selected_by_auto", selected_by_auto))
        or selected_by_auto,
        "explicit_only": bool(entry.get("explicit_only", False)),
        "capabilities": _backend_capability_text(
            available=available_capabilities,
            missing=missing,
            expected_count=len(expected_names),
        ),
        **owned_string_contract,
        **invariant_result_handles,
        "notes": notes,
    }


def imgui_kernel_backend_status_payload_from_backend_report(
    report: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Flatten backend diagnostics for host-loaded ImGui backend statuses."""

    if report is None:
        from iroll.kernels import backend_report

        report = backend_report()
    statuses = kernel_backend_statuses_from_backend_report(report)
    return {
        "method": "imgui_kernel_backend_status_payload_from_backend_report",
        "kernel_backend_statuses": statuses,
        "kernel_backend_status_count": len(statuses),
        "kernel_backend_invariant_result_handles_native_result_handles_complete_count": sum(
            int(
                status[
                    "invariant_result_handles_native_result_handles_complete"
                ]
            )
            for status in statuses
        ),
        "kernel_backend_invariant_result_handles_complete_result_handle_abi_count": sum(
            int(
                status[
                    "invariant_result_handles_complete_result_handle_abi"
                ]
            )
            for status in statuses
        ),
        "kernel_backend_invariant_result_handles_release_grade_result_handles_count": sum(
            int(
                status[
                    "invariant_result_handles_release_grade_result_handles"
                ]
            )
            for status in statuses
        ),
        "kernel_backend_invariant_result_handles_readiness_provenance_present_count": sum(
            int(
                status[
                    "invariant_result_handles_readiness_provenance_present"
                ]
            )
            for status in statuses
        ),
        "kernel_backend_invariant_result_handles_ready_for_native_result_handles_count": sum(
            int(
                status[
                    "invariant_result_handles_ready_for_native_result_handles"
                ]
            )
            for status in statuses
        ),
        "kernel_backend_invariant_result_handles_readiness_blocked_by_required_gates_count": sum(
            int(
                status[
                    "invariant_result_handles_readiness_blocked_by_required_gates"
                ]
            )
            for status in statuses
        ),
        "kernel_backend_invariant_result_handles_readiness_provenance_note_length_max": max(
            (
                int(
                    status[
                        "invariant_result_handles_readiness_provenance_note_length"
                    ]
                )
                for status in statuses
            ),
            default=0,
        ),
        "auto_backend": str(report.get("auto_backend", "")),
        "kernel_capabilities": list(report.get("kernel_capabilities", []))
        if isinstance(report.get("kernel_capabilities"), list)
        else [],
        "notes": _notes_text(report),
    }


def imgui_host_payload_from_acceptance_reports(
    reports: Iterable[Mapping[str, Any]],
    *,
    geometry_report: Mapping[str, Any] | None = None,
    backend_diagnostics: Mapping[str, Any] | None = None,
    analysis_reports: Iterable[Mapping[str, Any]] | None = None,
    invariant_reports: Iterable[Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    """Build the combined file-oriented payload consumed by C++/Dear ImGui hosts.

    ``analysis_reports`` lets callers add report-level evidence summaries that do
    not have fixture rows or signed-PD diagrams, while keeping the fixture and
    signed-PD sections tied to acceptance reports only. ``invariant_reports``
    lets callers append direct HOMFLY/Alexander status reports to the invariant
    section without changing the acceptance-based fixture sections.
    """

    acceptance_reports = list(reports)
    analysis_report_list = (
        list(analysis_reports)
        if analysis_reports is not None
        else acceptance_reports
    )
    invariant_report_list = (
        list(invariant_reports)
        if invariant_reports is not None
        else acceptance_reports
    )
    geometry_payload = (
        imgui_geometry_payload_from_report(geometry_report)
        if geometry_report is not None
        else None
    )
    link_classification_payload = (
        imgui_link_classification_summary_payload_from_report(geometry_report)
        if geometry_report is not None
        else None
    )
    analysis_payload = imgui_analysis_payload_from_acceptance_reports(
        analysis_report_list
    )
    invariant_payload = (
        imgui_invariant_status_payload_from_reports(invariant_report_list)
        if invariant_reports is not None
        else imgui_invariant_status_payload_from_acceptance_reports(
            acceptance_reports
        )
    )
    payload = {
        "method": "imgui_host_payload",
        "geometry": geometry_payload,
        "analysis": analysis_payload,
        "invariants": invariant_payload,
        "fixture_comparisons": (
            imgui_fixture_comparison_payload_from_acceptance_reports(
                acceptance_reports
            )
        ),
        "signed_pd": imgui_signed_pd_payload_from_acceptance_reports(
            acceptance_reports
        ),
        "kernel_backends": imgui_kernel_backend_status_payload_from_backend_report(
            backend_diagnostics
        ),
        **_host_blocker_summary_aggregate_fields(
            analysis_payload,
            invariant_payload,
        ),
        "notes": [
            "bundle combines host-loadable Dear ImGui JSON payloads",
            "nested mathematical acceptance reports remain authoritative and are not embedded by default",
        ],
    }
    if (
        isinstance(link_classification_payload, Mapping)
        and link_classification_payload.get("has_link_classification_summary") is True
    ):
        payload["link_classification"] = link_classification_payload
    return payload


def _host_blocker_summary_aggregate_fields(
    analysis_payload: Mapping[str, Any],
    invariant_payload: Mapping[str, Any],
) -> dict[str, int]:
    fields: dict[str, int] = {}
    for prefix, section in (
        ("analysis", analysis_payload),
        ("invariant", invariant_payload),
    ):
        for key in _BLOCKER_SUMMARY_KEYS + _COMPACT_HOST_EVIDENCE_KEYS:
            aggregate_key = f"{prefix}_{key}"
            if aggregate_key in section:
                fields[aggregate_key] = (
                    _optional_count(section.get(aggregate_key)) or 0
                )
    return fields


def _analysis_claim_scope(report: Mapping[str, Any]) -> str:
    claim_scope = report.get("claim_scope")
    if claim_scope is not None:
        return str(claim_scope)
    if report.get("method") == "signed_pd_role_order_candidates_report":
        return "strict_global_signed_pd_role_order_candidate_diagnostic"
    if report.get("method") == "diagram_fixture_source_table_invariant_audit":
        return "source_table_invariant_candidate_convergence"
    return ""


def _analysis_summary_accepted(report: Mapping[str, Any]) -> bool:
    if report.get("method") == "signed_pd_role_order_candidates_report":
        return report.get("status") == "unique"
    if report.get("method") == "diagram_fixture_source_table_invariant_audit":
        required, passed, failed = _source_table_audit_check_counts(report)
        return required > 0 and passed == required and failed == 0
    return bool(report.get("accepted", False))


def _role_order_signature_counts(report: Mapping[str, Any]) -> dict[str, int]:
    counts = {key: 0 for key in _ANALYSIS_ROLE_ORDER_SIGNATURE_KEYS}
    if report.get("method") != "signed_pd_role_order_candidates_report":
        return counts
    signatures = report.get("invariant_signatures")
    if not isinstance(signatures, Mapping) or signatures.get("requested") is not True:
        return counts

    strict_count = (
        _optional_count(signatures.get("strict_candidate_count"))
        or _optional_count(report.get("strict_candidate_count"))
        or 0
    )
    counts["role_order_signature_strict_candidate_count"] = strict_count

    field_map = {
        "role_order_signature_evaluated_candidate_count": "evaluated_candidate_count",
        "role_order_signature_skipped_candidate_count": "skipped_candidate_count",
        "role_order_signature_group_count": "combined_signature_count",
        "role_order_signature_homfly_group_count": "homfly_signature_count",
        "role_order_signature_alexander_group_count": "alexander_signature_count",
        "role_order_signature_homfly_certified_candidate_count": (
            "homfly_certified_candidate_count"
        ),
        "role_order_signature_homfly_frontier_count": "homfly_frontier_count",
        "role_order_signature_homfly_frontier_reason_count": (
            "homfly_frontier_reason_count"
        ),
        "role_order_signature_homfly_truncated_candidate_count": (
            "homfly_truncated_candidate_count"
        ),
        "role_order_signature_alexander_bounded_scanned_gcd_certified_candidate_count": (
            "alexander_bounded_scanned_gcd_certified_candidate_count"
        ),
        "role_order_signature_alexander_complete_scanned_gcd_certified_candidate_count": (
            "alexander_complete_scanned_gcd_certified_candidate_count"
        ),
        "role_order_signature_alexander_quotient_gcd_certified_candidate_count": (
            "alexander_quotient_gcd_certified_candidate_count"
        ),
        "role_order_signature_alexander_failed_nonzero_minor_count": (
            "alexander_failed_nonzero_minor_count"
        ),
        "role_order_signature_alexander_truncated_candidate_count": (
            "alexander_truncated_candidate_count"
        ),
    }
    for output_key, source_key in field_map.items():
        counts[output_key] = _optional_count(signatures.get(source_key)) or 0
    return counts


def _role_order_signature_resolution_status_from_counts(
    *,
    strict_candidate_count: int,
    evaluated_candidate_count: int,
    combined_signature_count: int,
) -> str:
    if strict_candidate_count == 0:
        return "no_strict_candidates"
    if evaluated_candidate_count == 0:
        return "not_evaluated"
    all_evaluated = evaluated_candidate_count >= strict_candidate_count
    if combined_signature_count <= 1:
        if all_evaluated:
            return "all_strict_candidates_same_signature"
        return "evaluated_candidates_same_signature"
    if all_evaluated:
        return "distinguishes_strict_candidates"
    return "partially_distinguishes_candidates"


def _role_order_signature_resolution_fields(
    report: Mapping[str, Any],
) -> dict[str, Any]:
    fields: dict[str, Any] = {
        "role_order_signature_strict_candidate_count": 0,
        "role_order_signature_resolution_status": "",
        "role_order_signature_resolution_status_code": 0,
        "role_order_signature_all_strict_candidates_evaluated": False,
    }
    if report.get("method") != "signed_pd_role_order_candidates_report":
        return fields
    signatures = report.get("invariant_signatures")
    if not isinstance(signatures, Mapping) or signatures.get("requested") is not True:
        return fields

    strict_count = (
        _optional_count(signatures.get("strict_candidate_count"))
        or _optional_count(report.get("strict_candidate_count"))
        or 0
    )
    evaluated = _optional_count(signatures.get("evaluated_candidate_count")) or 0
    groups = _optional_count(signatures.get("combined_signature_count")) or 0
    status = signatures.get("signature_resolution_status")
    if not isinstance(status, str) or not status:
        status = _role_order_signature_resolution_status_from_counts(
            strict_candidate_count=strict_count,
            evaluated_candidate_count=evaluated,
            combined_signature_count=groups,
        )
    all_evaluated = signatures.get("all_strict_candidates_evaluated")
    if not isinstance(all_evaluated, bool):
        all_evaluated = strict_count > 0 and evaluated >= strict_count
    fields["role_order_signature_strict_candidate_count"] = strict_count
    fields["role_order_signature_resolution_status"] = status
    fields["role_order_signature_resolution_status_code"] = (
        _role_order_signature_resolution_status_code(status)
    )
    fields["role_order_signature_all_strict_candidates_evaluated"] = all_evaluated
    return fields


def _source_table_homfly_variant_resolution_status(
    comparison: Mapping[str, Any],
) -> str:
    if comparison.get("source_value_present") is not True:
        return "no_source_value"
    computed = _optional_count(comparison.get("computed_candidate_count")) or 0
    if computed <= 0:
        return "not_computed"
    if comparison.get("source_value_seen") is True:
        return "source_value_seen"
    variant_seen_count = (
        _optional_count(comparison.get("source_value_seen_variant_count")) or 0
    )
    if variant_seen_count > 0:
        return "source_variant_seen"
    if comparison.get("source_value_seen_after_unit_normalization") is True:
        return "source_value_unit_normalized_seen"
    unit_variant_seen_count = (
        _optional_count(
            comparison.get("source_value_seen_unit_normalized_variant_count")
        )
        or 0
    )
    if unit_variant_seen_count > 0:
        return "source_variant_unit_normalized_seen"
    return "source_variants_missed"


def _source_table_homfly_variant_resolution_status_from_comparison(
    comparison: Mapping[str, Any],
) -> str:
    raw_status = comparison.get("source_value_variant_resolution_status")
    if isinstance(raw_status, str) and raw_status:
        return raw_status
    return _source_table_homfly_variant_resolution_status(comparison)


def _source_table_source_match_resolution_status(
    comparison: Mapping[str, Any],
) -> str:
    if comparison.get("source_value_present") is not True:
        return "no_source_value"
    computed = _optional_count(comparison.get("computed_candidate_count")) or 0
    if computed <= 0:
        return "not_computed"
    source_seen = comparison.get("source_value_seen") is True
    if comparison.get("complete_candidate_source_match") is True:
        return "complete_source_match"
    if comparison.get("returned_candidate_source_match") is True:
        return "returned_source_match_incomplete"
    missing = _optional_count(comparison.get("missing_candidate_count")) or 0
    skipped = _optional_count(comparison.get("skipped_candidate_count")) or 0
    if source_seen and (missing > 0 or skipped > 0):
        return "source_seen_with_incomplete_candidates"
    if source_seen:
        return "source_seen_unstable"
    if missing > 0 or skipped > 0:
        return "candidate_values_missing_or_skipped"
    return "source_missed_with_candidates"


def _source_table_source_match_resolution_status_from_comparison(
    comparison: Mapping[str, Any],
) -> str:
    raw_status = comparison.get("source_match_resolution_status")
    if isinstance(raw_status, str) and raw_status:
        return raw_status
    return _source_table_source_match_resolution_status(comparison)


def _source_table_homfly_variant_resolution_fields(
    report: Mapping[str, Any],
) -> dict[str, int | str]:
    fields: dict[str, int | str] = {
        "source_table_audit_homfly_variant_resolution_status": "",
        "source_table_audit_homfly_variant_resolution_status_code": 0,
    }
    if report.get("method") != "diagram_fixture_source_table_invariant_audit":
        return fields
    comparisons = report.get("comparisons")
    if not isinstance(comparisons, Mapping):
        return fields
    homfly = comparisons.get("homfly")
    if not isinstance(homfly, Mapping):
        return fields
    status = _source_table_homfly_variant_resolution_status_from_comparison(homfly)
    fields["source_table_audit_homfly_variant_resolution_status"] = status
    fields["source_table_audit_homfly_variant_resolution_status_code"] = (
        _source_table_homfly_variant_resolution_status_code(status)
    )
    return fields


def _source_table_audit_source_match_resolution_fields(
    report: Mapping[str, Any] | None,
) -> dict[str, int | str]:
    statuses = _source_table_audit_source_match_status_rows(report)
    return {
        "source_table_audit_source_match_resolution_statuses": ",".join(statuses),
        "source_table_audit_source_match_resolution_status_count": len(statuses),
    }


def _source_candidate_replay_summary_fields(
    report: Mapping[str, Any],
) -> dict[str, int]:
    fields = {
        key: 0 for key in _ANALYSIS_SOURCE_CANDIDATE_REPLAY_SUMMARY_KEYS
    }
    summary = report.get("signed_pd_replay_summary")
    if not isinstance(summary, Mapping):
        return fields
    checked = _optional_count(summary.get("checked_candidate_count")) or 0
    valid = _optional_count(summary.get("valid_replay_count")) or 0
    fields["source_candidate_replay_summary_checked_candidate_count"] = checked
    fields["source_candidate_replay_summary_valid_replay_count"] = valid
    fields["source_candidate_replay_summary_invalid_replay_count"] = max(
        0,
        checked - valid,
    )
    fields["source_candidate_replay_summary_missing_replay_count"] = (
        _optional_count(summary.get("missing_replay_count")) or 0
    )
    fields["source_candidate_replay_summary_invalid_claim_scope_count"] = (
        _optional_count(summary.get("invalid_claim_scope_count")) or 0
    )
    fields["source_candidate_replay_summary_source_notation_mismatch_count"] = (
        _optional_count(summary.get("source_notation_mismatch_count")) or 0
    )
    fields["source_candidate_replay_summary_sign_mismatch_count"] = (
        _optional_count(summary.get("sign_mismatch_count")) or 0
    )
    fields["source_candidate_replay_summary_role_order_mismatch_count"] = (
        _optional_count(summary.get("role_order_mismatch_count")) or 0
    )
    fields["source_candidate_replay_summary_pairwise_linking_mismatch_count"] = (
        _optional_count(summary.get("pairwise_linking_mismatch_count")) or 0
    )
    fields["source_candidate_replay_summary_orientation_issue_count"] = (
        _optional_count(summary.get("orientation_issue_count")) or 0
    )
    fields[
        "source_candidate_replay_summary_missing_diagram_or_orientation_count"
    ] = _optional_count(summary.get("missing_diagram_or_orientation_count")) or 0
    if summary.get("all_returned_candidates_have_valid_replay") is True:
        fields["source_candidate_replay_summary_all_valid_count"] = 1
    return fields


def _append_source_candidate_replay_summary_note(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    summary = report.get("signed_pd_replay_summary")
    if not isinstance(summary, Mapping):
        return notes
    fields = _source_candidate_replay_summary_fields(report)
    return _append_note(
        notes,
        (
            "source_candidate_replay_summary="
            f"checked={fields['source_candidate_replay_summary_checked_candidate_count']}; "
            f"valid={fields['source_candidate_replay_summary_valid_replay_count']}; "
            f"invalid={fields['source_candidate_replay_summary_invalid_replay_count']}; "
            f"orientation_issues={fields['source_candidate_replay_summary_orientation_issue_count']}; "
            f"all_valid={summary.get('all_returned_candidates_have_valid_replay') is True}"
        ),
    )


def _source_table_audit_counts(report: Mapping[str, Any]) -> dict[str, int]:
    counts = {key: 0 for key in _ANALYSIS_SOURCE_TABLE_AUDIT_KEYS}
    method = report.get("method")
    if method in {
        "homfly_fixture_acceptance_report",
        "multivariable_alexander_fixture_acceptance_report",
    }:
        counts["source_table_audit_registration_ready_count"] = (
            _optional_count(report.get("source_table_registration_ready_count")) or 0
        )
        counts["source_table_audit_registration_blocked_count"] = (
            _optional_count(report.get("source_table_registration_blocked_count")) or 0
        )
        counts["source_table_audit_registration_blocker_count"] = (
            _optional_count(report.get("source_table_registration_blocker_count")) or 0
        )
        return counts
    if method != "diagram_fixture_source_table_invariant_audit":
        return counts

    comparisons = report.get("comparisons")
    if isinstance(comparisons, Mapping):
        counts["source_table_audit_comparison_count"] = len(comparisons)
        for name, comparison in comparisons.items():
            if not isinstance(comparison, Mapping):
                continue
            if comparison.get("source_value_present") is not True:
                continue
            if str(name) == "homfly":
                computed = _optional_count(comparison.get("computed_candidate_count")) or 0
                if computed > 0:
                    variant_count = (
                        _optional_count(comparison.get("source_value_variant_count"))
                        or 0
                    )
                    variant_seen_count = (
                        _optional_count(
                            comparison.get("source_value_seen_variant_count")
                        )
                        or 0
                    )
                    counts["source_table_audit_homfly_source_variant_count"] = (
                        variant_count
                    )
                    counts[
                        "source_table_audit_homfly_source_variant_seen_count"
                    ] = variant_seen_count
                    counts[
                        "source_table_audit_homfly_source_variant_miss_count"
                    ] = max(0, variant_count - variant_seen_count)
                    unit_variant_count = (
                        _optional_count(
                            comparison.get(
                                "source_value_unit_normalized_variant_count"
                            )
                        )
                        or 0
                    )
                    unit_variant_seen_count = (
                        _optional_count(
                            comparison.get(
                                "source_value_seen_unit_normalized_variant_count"
                            )
                        )
                        or 0
                    )
                    counts[
                        "source_table_audit_homfly_source_unit_normalized_variant_count"
                    ] = unit_variant_count
                    counts[
                        "source_table_audit_homfly_source_unit_normalized_variant_seen_count"
                    ] = unit_variant_seen_count
                    counts[
                        "source_table_audit_homfly_source_unit_normalized_variant_miss_count"
                    ] = max(0, unit_variant_count - unit_variant_seen_count)
                    counts[
                        "source_table_audit_homfly_candidate_unique_value_count"
                    ] = (
                        _optional_count(
                            comparison.get("candidate_unique_value_count")
                        )
                        or 0
                    )
                    counts[
                        "source_table_audit_homfly_candidate_unit_normalized_value_count"
                    ] = (
                        _optional_count(
                            comparison.get("candidate_unit_normalized_value_count")
                        )
                        or 0
                    )
                    variant_miss_summary = comparison.get(
                        "source_value_variant_miss_witness_summary"
                    )
                    if isinstance(variant_miss_summary, Mapping):
                        counts[
                            "source_table_audit_homfly_variant_miss_witness_count"
                        ] = (
                            _optional_count(
                                variant_miss_summary.get(
                                    "variant_miss_witness_count"
                                )
                            )
                            or 0
                        )
                        counts[
                            "source_table_audit_homfly_variant_miss_witness_limit"
                        ] = (
                            _optional_count(
                                variant_miss_summary.get(
                                    "variant_miss_witness_limit"
                                )
                            )
                            or 0
                        )
                        counts[
                            "source_table_audit_homfly_variant_miss_witness_truncated"
                        ] = (
                            1
                            if variant_miss_summary.get(
                                "variant_miss_witness_truncated",
                                False,
                            )
                            else 0
                        )
            if comparison.get("complete_candidate_source_match") is True:
                continue
            computed = _optional_count(comparison.get("computed_candidate_count")) or 0
            missing = _optional_count(comparison.get("missing_candidate_count")) or 0
            skipped = _optional_count(comparison.get("skipped_candidate_count")) or 0
            if computed == 0 or missing > 0 or skipped > 0:
                counts["source_table_audit_uncomputed_invariant_count"] += 1
            elif comparison.get("source_value_seen") is False:
                counts["source_table_audit_mismatched_invariant_count"] += 1
            else:
                counts["source_table_audit_unstable_invariant_count"] += 1

    matched = report.get("matched_source_table_invariants")
    if isinstance(matched, list):
        counts["source_table_audit_matched_invariant_count"] = len(matched)
    else:
        counts["source_table_audit_matched_invariant_count"] = (
            _optional_count(report.get("matched_source_table_invariant_count")) or 0
        )
    for count_field, list_field, report_count_field in [
        (
            "source_table_audit_uncomputed_invariant_count",
            "uncomputed_source_table_invariants",
            "uncomputed_source_table_invariant_count",
        ),
        (
            "source_table_audit_mismatched_invariant_count",
            "mismatched_source_table_invariants",
            "mismatched_source_table_invariant_count",
        ),
        (
            "source_table_audit_unstable_invariant_count",
            "unstable_source_table_invariants",
            "unstable_source_table_invariant_count",
        ),
    ]:
        invariant_names = report.get(list_field)
        if isinstance(invariant_names, list):
            counts[count_field] = len(invariant_names)
            continue
        invariant_count = _optional_count(report.get(report_count_field))
        if invariant_count is not None:
            counts[count_field] = invariant_count

    top_level_candidate_field_map = {
        "source_table_audit_candidate_count": "source_table_candidate_count",
        "source_table_audit_unique_sign_pattern_count": (
            "source_table_candidate_unique_sign_pattern_count"
        ),
        "source_table_audit_computed_source_compatible_candidate_count": (
            "source_table_computed_source_compatible_candidate_count"
        ),
        "source_table_audit_computed_source_compatible_unique_sign_pattern_count": (
            "source_table_computed_source_compatible_unique_sign_pattern_count"
        ),
        "source_table_audit_complete_source_compatible_candidate_count": (
            "source_table_complete_source_compatible_candidate_count"
        ),
        "source_table_audit_complete_source_compatible_unique_sign_pattern_count": (
            "source_table_complete_source_compatible_unique_sign_pattern_count"
        ),
        "source_table_audit_top_candidate_count": "source_table_top_candidate_count",
        "source_table_audit_top_unique_sign_pattern_count": (
            "source_table_top_candidate_unique_sign_pattern_count"
        ),
        "source_table_audit_max_matched_source_value_count": (
            "source_table_max_matched_source_value_count"
        ),
        "source_table_audit_max_matched_candidate_total_count": (
            "source_table_max_matched_candidate_total_count"
        ),
        "source_table_audit_max_matched_candidate_total_unique_sign_pattern_count": (
            "source_table_max_matched_candidate_total_unique_sign_pattern_count"
        ),
        "source_table_audit_max_matched_candidate_count": (
            "source_table_max_matched_candidate_count"
        ),
        "source_table_audit_max_matched_unique_sign_pattern_count": (
            "source_table_max_matched_candidate_unique_sign_pattern_count"
        ),
        "source_table_audit_homfly_candidate_unique_value_count": (
            "source_table_homfly_candidate_unique_value_count"
        ),
        "source_table_audit_homfly_candidate_unit_normalized_value_count": (
            "source_table_homfly_candidate_unit_normalized_value_count"
        ),
    }
    populated_candidate_count_fields = set()
    for output_key, source_key in top_level_candidate_field_map.items():
        value = _optional_count(report.get(source_key))
        if value is not None:
            counts[output_key] = value
            populated_candidate_count_fields.add(output_key)

    convergence_summary = report.get("source_table_candidate_convergence_summary")
    partial_certified = report.get(
        "source_table_candidate_convergence_partial_certified"
    )
    if not isinstance(partial_certified, bool) and isinstance(
        convergence_summary,
        Mapping,
    ):
        partial_certified = convergence_summary.get(
            "partial_source_table_convergence_certified"
        )
    full_certified = report.get("source_table_candidate_convergence_full_certified")
    if not isinstance(full_certified, bool) and isinstance(
        convergence_summary,
        Mapping,
    ):
        full_certified = convergence_summary.get(
            "full_source_table_convergence_certified"
        )
    counts["source_table_audit_candidate_convergence_partial_certified_count"] = (
        1 if partial_certified is True else 0
    )
    counts["source_table_audit_candidate_convergence_full_certified_count"] = (
        1 if full_certified is True else 0
    )
    certified_count = _optional_count(
        report.get("source_table_candidate_convergence_certified_invariant_count")
    )
    uncertified_count = _optional_count(
        report.get("source_table_candidate_convergence_uncertified_invariant_count")
    )
    source_seen_count = _optional_count(
        report.get("source_table_candidate_convergence_source_value_seen_invariant_count")
    )
    source_seen_uncertified_count = _optional_count(
        report.get(
            "source_table_candidate_convergence_source_value_seen_but_uncertified_invariant_count"
        )
    )
    if isinstance(convergence_summary, Mapping):
        if certified_count is None:
            certified_count = _optional_count(
                convergence_summary.get("certified_invariant_count")
            )
        if uncertified_count is None:
            uncertified_count = _optional_count(
                convergence_summary.get("uncertified_invariant_count")
            )
        if source_seen_count is None:
            source_seen_count = _optional_count(
                convergence_summary.get("source_value_seen_invariant_count")
            )
        if source_seen_uncertified_count is None:
            source_seen_uncertified_count = _optional_count(
                convergence_summary.get(
                    "source_value_seen_but_uncertified_invariant_count"
                )
            )
    counts["source_table_audit_candidate_convergence_certified_invariant_count"] = (
        certified_count or 0
    )
    counts["source_table_audit_candidate_convergence_uncertified_invariant_count"] = (
        uncertified_count or 0
    )
    counts["source_table_audit_candidate_convergence_source_value_seen_count"] = (
        source_seen_count or 0
    )
    counts[
        "source_table_audit_candidate_convergence_source_value_seen_but_uncertified_count"
    ] = source_seen_uncertified_count or 0

    summary = report.get("candidate_source_table_match_summary")
    if isinstance(summary, Mapping):
        summary_field_map = {
            "source_table_audit_candidate_count": "candidate_count",
            "source_table_audit_unique_sign_pattern_count": (
                "candidate_unique_sign_pattern_count"
            ),
            "source_table_audit_computed_source_compatible_candidate_count": (
                "computed_source_compatible_candidate_count"
            ),
            "source_table_audit_computed_source_compatible_unique_sign_pattern_count": (
                "computed_source_compatible_unique_sign_pattern_count"
            ),
            "source_table_audit_complete_source_compatible_candidate_count": (
                "complete_source_compatible_candidate_count"
            ),
            "source_table_audit_complete_source_compatible_unique_sign_pattern_count": (
                "complete_source_compatible_unique_sign_pattern_count"
            ),
            "source_table_audit_top_candidate_count": "top_candidate_count",
            "source_table_audit_top_unique_sign_pattern_count": (
                "top_candidate_unique_sign_pattern_count"
            ),
            "source_table_audit_max_matched_source_value_count": (
                "max_matched_source_value_count"
            ),
            "source_table_audit_max_matched_candidate_total_count": (
                "max_matched_candidate_total_count"
            ),
            "source_table_audit_max_matched_candidate_total_unique_sign_pattern_count": (
                "max_matched_candidate_total_unique_sign_pattern_count"
            ),
            "source_table_audit_max_matched_candidate_count": (
                "max_matched_candidate_count"
            ),
            "source_table_audit_max_matched_unique_sign_pattern_count": (
                "max_matched_candidate_unique_sign_pattern_count"
            ),
        }
        for output_key, source_key in summary_field_map.items():
            if output_key in populated_candidate_count_fields:
                continue
            counts[output_key] = _optional_count(summary.get(source_key)) or 0
    blockers = _source_table_audit_registration_blockers(report)
    ready_value = report.get("source_table_registration_ready")
    ready = ready_value if isinstance(ready_value, bool) else len(blockers) == 0
    counts["source_table_audit_registration_ready_count"] = 1 if ready else 0
    counts["source_table_audit_registration_blocked_count"] = 0 if ready else 1
    blocker_count = _optional_count(report.get("source_table_registration_blocker_count"))
    counts["source_table_audit_registration_blocker_count"] = (
        blocker_count if blocker_count is not None else len(blockers)
    )
    return counts


def _source_table_audit_registration_summary_consistency(
    report: Mapping[str, Any],
) -> Mapping[str, Any] | None:
    consistency = report.get("source_table_registration_summary_consistency")
    return consistency if isinstance(consistency, Mapping) else None


def _source_table_audit_registration_summary_consistency_fields(
    report: Mapping[str, Any] | None,
) -> dict[str, int | str]:
    consistency = (
        _source_table_audit_registration_summary_consistency(report)
        if report is not None
        else None
    )
    if consistency is None:
        return {
            "source_table_audit_registration_summary_consistency_available_count": 0,
            "source_table_audit_registration_summary_consistency_matched_count": 0,
            "source_table_audit_registration_summary_consistency_mismatch_count": 0,
            "source_table_audit_registration_summary_consistency_status": "",
            "source_table_audit_registration_summary_consistency_first_mismatch": "",
        }
    matched = consistency.get("matched")
    mismatch_count = _optional_count(consistency.get("mismatch_count")) or 0
    if matched is True:
        status = "matched"
    elif matched is False:
        status = "mismatched"
    else:
        status = "unknown"
    first_mismatch = consistency.get("first_mismatch")
    first_mismatch_text = ""
    if isinstance(first_mismatch, Mapping):
        kind = str(first_mismatch.get("kind") or "")
        field = str(first_mismatch.get("field") or "")
        if kind or field:
            first_mismatch_text = (
                f"{kind}:{field}" if kind and field else kind or field
            )
    return {
        "source_table_audit_registration_summary_consistency_available_count": 1,
        "source_table_audit_registration_summary_consistency_matched_count": (
            1 if matched is True else 0
        ),
        "source_table_audit_registration_summary_consistency_mismatch_count": (
            mismatch_count
        ),
        "source_table_audit_registration_summary_consistency_status": status,
        "source_table_audit_registration_summary_consistency_first_mismatch": (
            first_mismatch_text
        ),
    }


def _append_role_order_candidate_notes(report: Mapping[str, Any], notes: str) -> str:
    status = str(report.get("status", ""))
    candidate_count = _optional_count(report.get("candidate_count")) or 0
    strict_count = _optional_count(report.get("strict_candidate_count")) or 0
    note = (
        f"role-order status={status}; candidates={candidate_count}; "
        f"strict={strict_count}"
    )
    signatures = report.get("invariant_signatures")
    if isinstance(signatures, Mapping) and signatures.get("requested") is True:
        evaluated = _optional_count(signatures.get("evaluated_candidate_count")) or 0
        skipped = _optional_count(signatures.get("skipped_candidate_count")) or 0
        groups = _optional_count(signatures.get("combined_signature_count")) or 0
        homfly_groups = _optional_count(signatures.get("homfly_signature_count")) or 0
        alexander_groups = _optional_count(signatures.get("alexander_signature_count")) or 0
        homfly_certified = (
            _optional_count(signatures.get("homfly_certified_candidate_count")) or 0
        )
        homfly_frontier = _optional_count(signatures.get("homfly_frontier_count")) or 0
        homfly_frontier_reasons = (
            _optional_count(signatures.get("homfly_frontier_reason_count")) or 0
        )
        alexander_gcd_certified = (
            _optional_count(
                signatures.get(
                    "alexander_bounded_scanned_gcd_certified_candidate_count"
                )
            )
            or 0
        )
        alexander_quotient_certified = (
            _optional_count(
                signatures.get("alexander_quotient_gcd_certified_candidate_count")
            )
            or 0
        )
        alexander_complete_certified = (
            _optional_count(
                signatures.get(
                    "alexander_complete_scanned_gcd_certified_candidate_count"
                )
            )
            or 0
        )
        alexander_failed_minors = (
            _optional_count(signatures.get("alexander_failed_nonzero_minor_count")) or 0
        )
        resolution = str(signatures.get("signature_resolution_status") or "")
        if not resolution:
            strict_count = (
                _optional_count(signatures.get("strict_candidate_count"))
                or _optional_count(report.get("strict_candidate_count"))
                or 0
            )
            resolution = _role_order_signature_resolution_status_from_counts(
                strict_candidate_count=strict_count,
                evaluated_candidate_count=evaluated,
                combined_signature_count=groups,
            )
        all_strict_evaluated = signatures.get("all_strict_candidates_evaluated")
        if isinstance(all_strict_evaluated, bool):
            all_strict_evaluated_text = str(all_strict_evaluated).lower()
        else:
            strict_count = _optional_count(report.get("strict_candidate_count")) or 0
            all_strict_evaluated_text = str(strict_count > 0 and skipped == 0).lower()
        note += (
            f"; signature_evaluated={evaluated}; signature_skipped={skipped}; "
            f"signature_resolution={resolution}; "
            f"signature_all_strict_evaluated={all_strict_evaluated_text}; "
            f"signature_groups={groups}; homfly_groups={homfly_groups}; "
            f"alexander_groups={alexander_groups}; "
            f"homfly_certified={homfly_certified}; "
            f"homfly_frontier={homfly_frontier}; "
            f"homfly_frontier_reasons={homfly_frontier_reasons}; "
            f"alexander_gcd_certified={alexander_gcd_certified}; "
            f"alexander_complete_gcd_certified={alexander_complete_certified}; "
            f"alexander_quotient_certified={alexander_quotient_certified}; "
            f"alexander_failed_nonzero_minors={alexander_failed_minors}"
        )
    return _append_note(notes, note)



def _generated_coverage_counts(report: Mapping[str, Any]) -> dict[str, int]:
    counts = {key: 0 for key in _ANALYSIS_GENERATED_COVERAGE_KEYS}
    method = report.get("method")
    if method not in {
        "homfly_small_diagram_coverage_report",
        "multivariable_alexander_signed_pd_coverage_report",
    }:
        return counts

    counts["generated_case_count"] = _optional_count(report.get("case_count")) or 0
    counts["generated_non_fixture_case_count"] = (
        _optional_count(report.get("non_fixture_case_count")) or 0
    )
    counts["generated_source_notation_count"] = _source_notation_summary_count(
        report
    )
    counts["generated_branch_depth"] = _optional_count(report.get("branch_depth")) or 0
    counts["generated_max_branch_depth"] = (
        _optional_count(report.get("max_generated_branch_depth")) or 0
    )
    counts["generated_unique_diagram_count"] = (
        _optional_count(report.get("unique_diagram_count")) or 0
    )
    counts["generated_unique_oriented_diagram_count"] = (
        _optional_count(report.get("unique_oriented_diagram_count")) or 0
    )
    if method == "homfly_small_diagram_coverage_report":
        counts["generated_frontier_case_count"] = (
            _optional_count(report.get("frontier_case_count")) or 0
        )
        metadata = report.get("fixture_normalization_metadata")
        metadata_mapping = metadata if isinstance(metadata, Mapping) else {}
        counts["generated_fixture_normalization_metadata_count"] = (
            _optional_count(metadata_mapping.get("metadata_row_count")) or 0
        )
        counts["generated_fixture_normalization_expected_source_count"] = (
            _optional_count(metadata_mapping.get("expected_homfly_source_count"))
            or 0
        )
        counts["generated_fixture_normalization_source_url_count"] = (
            _optional_count(metadata_mapping.get("source_url_count")) or 0
        )
        counts["generated_fixture_normalization_full_table_certified_count"] = (
            _optional_count(
                metadata_mapping.get("full_table_normalization_certified_count")
            )
            or 0
        )
        counts[
            "generated_fixture_normalization_arbitrary_diagram_certified_count"
        ] = (
            _optional_count(
                metadata_mapping.get("arbitrary_diagram_coverage_certified_count")
            )
            or 0
        )
    counts["generated_zero_crossing_unlink_case_count"] = (
        _optional_count(report.get("zero_crossing_unlink_certified_case_count")) or 0
    )
    counts["generated_polynomial_variant_diagram_count"] = (
        _optional_count(report.get("polynomial_variant_diagram_count")) or 0
    )
    counts["generated_oriented_polynomial_conflict_count"] = (
        _optional_count(report.get("oriented_polynomial_conflict_count")) or 0
    )
    counts["generated_unique_evaluation_count"] = (
        _optional_count(report.get("unique_evaluation_count"))
        or _optional_count(report.get("nonzero_unique_evaluation_count"))
        or 0
    )
    counts["generated_reused_evaluation_count"] = (
        _optional_count(report.get("reused_evaluation_count"))
        or _optional_count(report.get("nonzero_reused_evaluation_count"))
        or 0
    )
    return counts


def _generated_source_summary_consistency_fields(
    report: Mapping[str, Any],
) -> dict[str, bool | None]:
    if report.get("method") not in {
        "homfly_small_diagram_coverage_report",
        "multivariable_alexander_signed_pd_coverage_report",
    }:
        return {}

    fields = {
        summary_key: None
        for summary_key, _ in _GENERATED_SOURCE_SUMMARY_CONSISTENCY_FIELDS
    }
    consistency = report.get("source_notation_summary_consistency")
    if not isinstance(consistency, Mapping):
        return fields

    for summary_key, consistency_key in _GENERATED_SOURCE_SUMMARY_CONSISTENCY_FIELDS:
        fields[summary_key] = _optional_bool(consistency.get(consistency_key))
    return fields


def _homfly_case_evidence_consistency_fields(
    report: Mapping[str, Any],
) -> dict[str, int]:
    fields = {
        key: 0
        for key in _HOMFLY_CASE_EVIDENCE_CONSISTENCY_COUNT_KEYS
    }
    if report.get("method") != "homfly_small_diagram_coverage_report":
        return fields

    consistency = report.get("case_evidence_consistency")
    if not isinstance(consistency, Mapping):
        return fields

    fields["homfly_case_evidence_consistency_available_count"] = 1
    matched = _optional_bool(consistency.get("matched"))
    if matched is True:
        fields["homfly_case_evidence_consistency_matched_count"] = 1
    elif matched is False:
        fields["homfly_case_evidence_consistency_mismatch_count"] = 1

    for source_key, field_key in (
        ("case_count", "homfly_case_evidence_consistency_case_count"),
        ("checked_case_count", "homfly_case_evidence_consistency_checked_case_count"),
        (
            "missing_evidence_count",
            "homfly_case_evidence_consistency_missing_evidence_count",
        ),
    ):
        fields[field_key] = _optional_count(consistency.get(source_key)) or 0

    for source_key, field_key in (
        (
            "bounded_homfly_maturity_path_counts_matched",
            "homfly_case_evidence_maturity_path_counts_matched_count",
        ),
        (
            "bounded_homfly_maturity_path_distinct_count_matched",
            "homfly_case_evidence_maturity_path_distinct_count_matched_count",
        ),
        (
            "bounded_homfly_maturity_path_certified_count_matched",
            "homfly_case_evidence_maturity_path_certified_count_matched_count",
        ),
    ):
        fields[field_key] = 1 if consistency.get(source_key) is True else 0
    return fields


def _analysis_homfly_case_evidence_consistency_totals(
    summaries: Iterable[Mapping[str, Any]],
) -> dict[str, int]:
    return {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in summaries
        )
        for key in _HOMFLY_CASE_EVIDENCE_CONSISTENCY_COUNT_KEYS
    }


def _validation_pack_audit_count_fields(
    report: Mapping[str, Any],
) -> dict[str, int]:
    fields = {
        key: 0
        for key in _VALIDATION_PACK_AUDIT_COUNT_KEYS
    }
    if report.get("method") != "cross_workstream_validation_pack_audit":
        return fields

    fields["validation_pack_audit_available_count"] = 1
    for key in (
        "required_diagram_fixture_count",
        "registered_required_diagram_fixture_count",
        "missing_required_diagram_fixture_count",
        "metadata_blocker_count",
        "unsigned_required_fixture_count",
        "non_diagram_requirement_count",
        "open_non_diagram_requirement_count",
        "final_completion_gate_count",
        "final_completion_passed_gate_count",
        "final_completion_failed_gate_count",
        "final_completion_blocker_count",
        "final_completion_blocker_code_count",
        "retained_evidence_count",
        "retained_evidence_id_count",
        "retained_evidence_completion_claimed_count",
        "retained_evidence_release_grade_speedup_claimed_count",
        "retained_evidence_real_graphics_backend_framebuffer_verified_count",
        "retained_evidence_screenshot_verified_count",
    ):
        fields[key] = _optional_count(report.get(key)) or 0

    bool_count_fields = (
        (
            "required_diagram_fixture_metadata_complete",
            "required_diagram_fixture_metadata_complete_count",
        ),
        (
            "signed_diagram_fixture_registration_complete",
            "signed_diagram_fixture_registration_complete_count",
        ),
        ("final_completion_ready", "final_completion_ready_count"),
        (
            "full_homfly_pt_evaluation_certified",
            "full_homfly_pt_evaluation_certified_count",
        ),
        (
            "full_multivariable_alexander_normalization_certified",
            "full_multivariable_alexander_normalization_certified_count",
        ),
        (
            "production_imgui_renderer_verified",
            "production_imgui_renderer_verified_count",
        ),
        ("release_artifacts_published", "release_artifacts_published_count"),
        (
            "retained_evidence_all_non_claimed",
            "retained_evidence_all_non_claimed_count",
        ),
    )
    for source_key, field_key in bool_count_fields:
        fields[field_key] = 1 if report.get(source_key) is True else 0
    blocker_target_ref_count, blocker_target_unique_count = (
        _completion_evidence_artifact_filename_counts(
            report.get("final_completion_blockers")
        )
    )
    fields[
        "final_completion_blocker_completion_evidence_artifact_filename_reference_count"
    ] = blocker_target_ref_count
    fields[
        "final_completion_blocker_completion_evidence_artifact_filename_unique_count"
    ] = blocker_target_unique_count
    failed_gate_target_ref_count, failed_gate_target_unique_count = (
        _completion_evidence_artifact_filename_counts(
            [
                row
                for row in _iter_mappings(
                    report.get("final_completion_gate_checks")
                )
                if row.get("passed") is False
            ]
        )
    )
    fields[
        "final_completion_failed_gate_completion_evidence_artifact_filename_reference_count"
    ] = failed_gate_target_ref_count
    fields[
        "final_completion_failed_gate_completion_evidence_artifact_filename_unique_count"
    ] = failed_gate_target_unique_count
    retained_non_claim_consistency = _mapping_or_empty(
        report.get("retained_evidence_non_claim_consistency")
    )
    fields["retained_evidence_non_claim_consistency_entry_count"] = (
        _optional_count(retained_non_claim_consistency.get("entry_count")) or 0
    )
    fields["retained_evidence_non_claim_consistency_evidence_id_count"] = (
        _optional_count(retained_non_claim_consistency.get("evidence_id_count"))
        or 0
    )
    fields[
        "retained_evidence_non_claim_consistency_completion_claimed_count"
    ] = (
        _optional_count(
            retained_non_claim_consistency.get("completion_claimed_count")
        )
        or 0
    )
    fields[
        "retained_evidence_non_claim_consistency_release_grade_speedup_claimed_count"
    ] = (
        _optional_count(
            retained_non_claim_consistency.get(
                "release_grade_speedup_claimed_count"
            )
        )
        or 0
    )
    fields[
        "retained_evidence_non_claim_consistency_real_backend_claimed_count"
    ] = (
        _optional_count(
            retained_non_claim_consistency.get(
                "real_graphics_backend_framebuffer_verified_count"
            )
        )
        or 0
    )
    fields[
        "retained_evidence_non_claim_consistency_screenshot_verified_count"
    ] = (
        _optional_count(
            retained_non_claim_consistency.get("screenshot_verified_count")
        )
        or 0
    )
    fields[
        "retained_evidence_non_claim_consistency_all_non_claimed_count"
    ] = 1 if retained_non_claim_consistency.get("all_non_claimed") is True else 0
    fields[
        "retained_evidence_non_claim_consistency_entry_top_level_matched_count"
    ] = (
        1
        if retained_non_claim_consistency.get("entry_count_matches_top_level")
        is True
        else 0
    )
    fields[
        "retained_evidence_non_claim_consistency_id_top_level_matched_count"
    ] = (
        1
        if retained_non_claim_consistency.get("evidence_id_count_matches_top_level")
        is True
        else 0
    )
    fields[
        "retained_evidence_non_claim_consistency_completion_top_level_matched_count"
    ] = (
        1
        if retained_non_claim_consistency.get(
            "completion_claimed_count_matches_top_level"
        )
        is True
        else 0
    )
    fields[
        "retained_evidence_non_claim_consistency_release_speedup_top_level_matched_count"
    ] = (
        1
        if retained_non_claim_consistency.get(
            "release_grade_speedup_claimed_count_matches_top_level"
        )
        is True
        else 0
    )
    fields[
        "retained_evidence_non_claim_consistency_real_backend_top_level_matched_count"
    ] = (
        1
        if retained_non_claim_consistency.get(
            "real_graphics_backend_framebuffer_verified_count_matches_top_level"
        )
        is True
        else 0
    )
    fields[
        "retained_evidence_non_claim_consistency_screenshot_top_level_matched_count"
    ] = (
        1
        if retained_non_claim_consistency.get(
            "screenshot_verified_count_matches_top_level"
        )
        is True
        else 0
    )
    fields[
        "retained_evidence_non_claim_consistency_matched_count"
    ] = 1 if retained_non_claim_consistency.get("matched") is True else 0
    retained_artifact_file_consistency = _mapping_or_empty(
        report.get("retained_evidence_artifact_file_consistency")
    )
    fields["retained_evidence_artifact_file_consistency_entry_count"] = (
        _optional_count(retained_artifact_file_consistency.get("entry_count"))
        or 0
    )
    fields[
        "retained_evidence_artifact_file_consistency_artifact_evidence_count"
    ] = (
        _optional_count(
            retained_artifact_file_consistency.get("artifact_evidence_count")
        )
        or 0
    )
    fields[
        "retained_evidence_artifact_file_consistency_non_artifact_evidence_count"
    ] = (
        _optional_count(
            retained_artifact_file_consistency.get("non_artifact_evidence_count")
        )
        or 0
    )
    fields["retained_evidence_artifact_file_consistency_file_reference_count"] = (
        _optional_count(
            retained_artifact_file_consistency.get("artifact_file_reference_count")
        )
        or 0
    )
    fields["retained_evidence_artifact_file_consistency_unique_file_count"] = (
        _optional_count(
            retained_artifact_file_consistency.get("unique_artifact_file_count")
        )
        or 0
    )
    fields["retained_evidence_artifact_file_consistency_raw_file_count"] = (
        _optional_count(retained_artifact_file_consistency.get("raw_file_count"))
        or 0
    )
    fields["retained_evidence_artifact_file_consistency_analysis_file_count"] = (
        _optional_count(
            retained_artifact_file_consistency.get("analysis_file_count")
        )
        or 0
    )
    fields["retained_evidence_artifact_file_consistency_host_file_count"] = (
        _optional_count(retained_artifact_file_consistency.get("host_file_count"))
        or 0
    )
    fields[
        "retained_evidence_artifact_file_consistency_complete_raw_analysis_host_group_count"
    ] = (
        _optional_count(
            retained_artifact_file_consistency.get(
                "complete_raw_analysis_host_group_count"
            )
        )
        or 0
    )
    fields["retained_evidence_artifact_file_consistency_incomplete_group_count"] = (
        _optional_count(
            retained_artifact_file_consistency.get("incomplete_artifact_group_count")
        )
        or 0
    )
    fields[
        "retained_evidence_artifact_file_consistency_reference_count_matched_count"
    ] = (
        1
        if retained_artifact_file_consistency.get(
            "artifact_file_reference_count_matches_groups"
        )
        is True
        else 0
    )
    fields[
        "retained_evidence_artifact_file_consistency_file_type_counts_matched_count"
    ] = (
        1
        if retained_artifact_file_consistency.get(
            "raw_analysis_host_file_counts_matched"
        )
        is True
        else 0
    )
    fields[
        "retained_evidence_artifact_file_consistency_all_groups_complete_count"
    ] = (
        1
        if retained_artifact_file_consistency.get(
            "all_artifact_evidence_groups_complete"
        )
        is True
        else 0
    )
    fields["retained_evidence_artifact_file_consistency_all_files_unique_count"] = (
        1
        if retained_artifact_file_consistency.get("all_artifact_files_unique")
        is True
        else 0
    )
    fields["retained_evidence_artifact_file_consistency_matched_count"] = (
        1 if retained_artifact_file_consistency.get("matched") is True else 0
    )
    required_check_consistency = _mapping_or_empty(
        report.get("final_completion_required_check_consistency")
    )
    fields["final_completion_required_check_count"] = (
        _optional_count(required_check_consistency.get("required_check_count")) or 0
    )
    fields["final_completion_required_check_passed_count"] = (
        _optional_count(
            required_check_consistency.get("passed_required_check_count")
        )
        or 0
    )
    fields["final_completion_required_check_failed_count"] = (
        _optional_count(
            required_check_consistency.get("failed_required_check_count")
        )
        or 0
    )
    fields["final_completion_required_check_mismatched_count"] = (
        _optional_count(
            required_check_consistency.get("mismatched_required_check_count")
        )
        or 0
    )
    fields["final_completion_required_check_final_ready_matched_count"] = (
        1
        if required_check_consistency.get(
            "final_completion_ready_matches_required_checks"
        )
        is True
        else 0
    )
    fields["final_completion_required_check_all_matched_count"] = (
        1
        if required_check_consistency.get("all_required_checks_matched") is True
        else 0
    )
    fields["final_completion_required_check_consistency_matched_count"] = (
        1 if required_check_consistency.get("matched") is True else 0
    )
    required_fixture_metadata_consistency = _mapping_or_empty(
        report.get(
            "final_completion_required_diagram_fixture_metadata_consistency"
        )
    )
    fields[
        "final_completion_required_diagram_fixture_metadata_consistency_required_count"
    ] = (
        _optional_count(
            required_fixture_metadata_consistency.get("required_fixture_count")
        )
        or 0
    )
    fields[
        "final_completion_required_diagram_fixture_metadata_consistency_registered_count"
    ] = (
        _optional_count(
            required_fixture_metadata_consistency.get("registered_fixture_count")
        )
        or 0
    )
    fields[
        "final_completion_required_diagram_fixture_metadata_consistency_missing_count"
    ] = (
        _optional_count(
            required_fixture_metadata_consistency.get("missing_fixture_count")
        )
        or 0
    )
    fields[
        "final_completion_required_diagram_fixture_metadata_consistency_metadata_complete_count"
    ] = (
        _optional_count(
            required_fixture_metadata_consistency.get(
                "metadata_complete_fixture_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_required_diagram_fixture_metadata_consistency_metadata_incomplete_count"
    ] = (
        _optional_count(
            required_fixture_metadata_consistency.get(
                "metadata_incomplete_fixture_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_required_diagram_fixture_metadata_consistency_metadata_blocker_count"
    ] = (
        _optional_count(
            required_fixture_metadata_consistency.get("metadata_blocker_count")
        )
        or 0
    )
    fields[
        "final_completion_required_diagram_fixture_metadata_consistency_gate_passed_count"
    ] = (
        1
        if required_fixture_metadata_consistency.get("gate_passed") is True
        else 0
    )
    fields[
        "final_completion_required_diagram_fixture_metadata_consistency_gate_blocker_count"
    ] = (
        _optional_count(
            required_fixture_metadata_consistency.get("gate_blocker_count")
        )
        or 0
    )
    fields[
        "final_completion_required_diagram_fixture_metadata_consistency_mismatched_count"
    ] = (
        _optional_count(
            required_fixture_metadata_consistency.get("mismatched_fixture_count")
        )
        or 0
    )
    fields[
        "final_completion_required_diagram_fixture_metadata_consistency_matched_count"
    ] = (
        1 if required_fixture_metadata_consistency.get("matched") is True else 0
    )
    fixture_source_url_shape = _mapping_or_empty(
        report.get("fixture_source_url_shape_summary")
    )
    fields["validation_pack_fixture_source_url_fixture_row_count"] = (
        _optional_count(fixture_source_url_shape.get("fixture_row_count")) or 0
    )
    fields["validation_pack_fixture_source_url_row_count"] = (
        _optional_count(fixture_source_url_shape.get("source_url_row_count")) or 0
    )
    fields["validation_pack_fixture_source_url_external_row_count"] = (
        _optional_count(
            fixture_source_url_shape.get("external_source_url_row_count")
        )
        or 0
    )
    fields["validation_pack_fixture_source_url_required_count"] = (
        _optional_count(fixture_source_url_shape.get("source_url_required_count"))
        or 0
    )
    fields["validation_pack_fixture_source_url_http_or_https_count"] = (
        _optional_count(
            fixture_source_url_shape.get("source_url_http_or_https_count")
        )
        or 0
    )
    fields["validation_pack_fixture_source_url_requirement_satisfied_count"] = (
        _optional_count(
            fixture_source_url_shape.get(
                "source_url_requirement_satisfied_count"
            )
        )
        or 0
    )
    source_url_scheme_counts = _mapping_or_empty(
        fixture_source_url_shape.get("source_url_scheme_counts")
    )
    source_url_domain_counts = _mapping_or_empty(
        fixture_source_url_shape.get("source_url_domain_counts")
    )
    fields["validation_pack_fixture_source_url_scheme_entry_count"] = len(
        source_url_scheme_counts
    )
    fields["validation_pack_fixture_source_url_domain_entry_count"] = len(
        source_url_domain_counts
    )
    fields["validation_pack_fixture_source_url_scheme_count_total"] = (
        _optional_count(
            fixture_source_url_shape.get("source_url_scheme_count_total")
        )
        or 0
    )
    fields["validation_pack_fixture_source_url_domain_count_total"] = (
        _optional_count(
            fixture_source_url_shape.get("source_url_domain_count_total")
        )
        or 0
    )
    fields["validation_pack_fixture_source_url_scheme_count_matched_count"] = (
        1
        if fixture_source_url_shape.get("source_url_scheme_count_matched") is True
        else 0
    )
    fields["validation_pack_fixture_source_url_domain_count_matched_count"] = (
        1
        if fixture_source_url_shape.get("source_url_domain_count_matched") is True
        else 0
    )
    fields[
        "validation_pack_fixture_source_url_http_or_https_count_matched_count"
    ] = (
        1
        if fixture_source_url_shape.get(
            "source_url_http_or_https_count_matched"
        )
        is True
        else 0
    )
    fields[
        "validation_pack_fixture_source_url_requirement_satisfied_count_matched_count"
    ] = (
        1
        if fixture_source_url_shape.get(
            "source_url_requirement_satisfied_count_matched"
        )
        is True
        else 0
    )
    fields["validation_pack_fixture_source_url_shape_matched_count"] = (
        1 if fixture_source_url_shape.get("matched") is True else 0
    )
    fixture_known_limitations = _mapping_or_empty(
        report.get("fixture_known_limitations_summary")
    )
    fields["validation_pack_fixture_known_limitations_fixture_row_count"] = (
        _optional_count(fixture_known_limitations.get("fixture_row_count")) or 0
    )
    fields["validation_pack_fixture_known_limitations_available_count"] = (
        _optional_count(
            fixture_known_limitations.get("known_limitations_available_count")
        )
        or 0
    )
    fields["validation_pack_fixture_known_limitations_unavailable_count"] = (
        _optional_count(
            fixture_known_limitations.get("known_limitations_unavailable_count")
        )
        or 0
    )
    fields["validation_pack_fixture_known_limitations_note_count_total"] = (
        _optional_count(
            fixture_known_limitations.get("known_limitations_note_count_total")
        )
        or 0
    )
    fields[
        "validation_pack_fixture_known_limitations_requirement_satisfied_count"
    ] = (
        _optional_count(
            fixture_known_limitations.get(
                "known_limitations_requirement_satisfied_count"
            )
        )
        or 0
    )
    fields[
        "validation_pack_fixture_known_limitations_requirement_satisfied_count_matched_count"
    ] = (
        1
        if fixture_known_limitations.get(
            "known_limitations_requirement_satisfied_count_matched"
        )
        is True
        else 0
    )
    fields[
        "validation_pack_fixture_known_limitations_unavailable_count_matched_count"
    ] = (
        1
        if fixture_known_limitations.get(
            "known_limitations_unavailable_count_matched"
        )
        is True
        else 0
    )
    fields["validation_pack_fixture_known_limitations_matched_count"] = (
        1 if fixture_known_limitations.get("matched") is True else 0
    )
    signed_fixture_consistency = _mapping_or_empty(
        report.get("final_completion_signed_fixture_consistency")
    )
    fields["final_completion_signed_fixture_consistency_blocker_count"] = (
        _optional_count(
            signed_fixture_consistency.get("signed_fixture_blocker_count")
        )
        or 0
    )
    fields["final_completion_signed_fixture_consistency_final_blocker_count"] = (
        _optional_count(signed_fixture_consistency.get("final_blocker_count"))
        or 0
    )
    fields["final_completion_signed_fixture_consistency_mismatched_count"] = (
        _optional_count(signed_fixture_consistency.get("mismatched_fixture_count"))
        or 0
    )
    fields[
        "final_completion_signed_fixture_consistency_source_url_present_count"
    ] = (
        _optional_count(signed_fixture_consistency.get("source_url_present_count"))
        or 0
    )
    fields[
        "final_completion_signed_fixture_consistency_unsigned_non_claim_count"
    ] = (
        _optional_count(
            signed_fixture_consistency.get("unsigned_non_claim_preserved_count")
        )
        or 0
    )
    fields[
        "final_completion_signed_fixture_consistency_source_table_metadata_count"
    ] = (
        _optional_count(
            signed_fixture_consistency.get("source_table_metadata_available_count")
        )
        or 0
    )
    fields[
        "final_completion_signed_fixture_consistency_missing_artifact_matched_count"
    ] = (
        _optional_count(
            signed_fixture_consistency.get("missing_artifact_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_signed_fixture_consistency_evidence_fields_matched_count"
    ] = (
        _optional_count(
            signed_fixture_consistency.get("evidence_fields_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_signed_fixture_consistency_source_candidate_evidence_available_count"
    ] = (
        _optional_count(
            signed_fixture_consistency.get(
                "source_candidate_evidence_available_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_signed_fixture_consistency_source_candidate_not_unique_count"
    ] = (
        _optional_count(
            signed_fixture_consistency.get("source_candidate_not_unique_count")
        )
        or 0
    )
    fields[
        "final_completion_signed_fixture_consistency_source_candidate_replay_all_valid_count"
    ] = (
        _optional_count(
            signed_fixture_consistency.get(
                "source_candidate_replay_all_valid_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_signed_fixture_consistency_source_candidate_matching_candidate_count_total"
    ] = (
        _optional_count(
            signed_fixture_consistency.get(
                "source_candidate_matching_candidate_count_total"
            )
        )
        or 0
    )
    fields[
        "final_completion_signed_fixture_consistency_source_candidate_unique_sign_pattern_count_total"
    ] = (
        _optional_count(
            signed_fixture_consistency.get(
                "source_candidate_unique_sign_pattern_count_total"
            )
        )
        or 0
    )
    fields["final_completion_signed_fixture_consistency_matched_count"] = (
        1 if signed_fixture_consistency.get("matched") is True else 0
    )
    non_diagram_consistency = _mapping_or_empty(
        report.get("final_completion_non_diagram_requirement_consistency")
    )
    fields[
        "final_completion_non_diagram_requirement_consistency_requirement_count"
    ] = _optional_count(non_diagram_consistency.get("requirement_count")) or 0
    fields[
        "final_completion_non_diagram_requirement_consistency_open_count"
    ] = _optional_count(non_diagram_consistency.get("open_requirement_count")) or 0
    fields[
        "final_completion_non_diagram_requirement_consistency_blocker_count"
    ] = _optional_count(non_diagram_consistency.get("blocker_count")) or 0
    fields[
        "final_completion_non_diagram_requirement_consistency_mismatched_count"
    ] = (
        _optional_count(non_diagram_consistency.get("mismatched_requirement_count"))
        or 0
    )
    fields[
        "final_completion_non_diagram_requirement_consistency_retained_evidence_count"
    ] = (
        _optional_count(
            non_diagram_consistency.get("retained_evidence_reference_count")
        )
        or 0
    )
    fields[
        "final_completion_non_diagram_requirement_consistency_retained_evidence_id_count"
    ] = _optional_count(non_diagram_consistency.get("retained_evidence_id_count")) or 0
    fields[
        "final_completion_non_diagram_requirement_consistency_retained_evidence_reference_top_level_matched_count"
    ] = (
        1
        if non_diagram_consistency.get(
            "retained_evidence_reference_count_matches_top_level"
        )
        is True
        else 0
    )
    fields[
        "final_completion_non_diagram_requirement_consistency_retained_evidence_id_top_level_matched_count"
    ] = (
        1
        if non_diagram_consistency.get("retained_evidence_id_count_matches_top_level")
        is True
        else 0
    )
    fields[
        "final_completion_non_diagram_requirement_consistency_missing_artifact_matched_count"
    ] = (
        _optional_count(non_diagram_consistency.get("missing_artifact_matched_count"))
        or 0
    )
    fields[
        "final_completion_non_diagram_requirement_consistency_evidence_fields_matched_count"
    ] = (
        _optional_count(non_diagram_consistency.get("evidence_fields_matched_count"))
        or 0
    )
    fields[
        "final_completion_non_diagram_requirement_consistency_retained_evidence_matched_count"
    ] = (
        _optional_count(
            non_diagram_consistency.get("retained_evidence_count_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_non_diagram_requirement_consistency_retained_evidence_ids_matched_count"
    ] = (
        _optional_count(
            non_diagram_consistency.get("retained_evidence_ids_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_non_diagram_requirement_consistency_completion_claim_false_count"
    ] = (
        _optional_count(non_diagram_consistency.get("completion_claimed_false_count"))
        or 0
    )
    fields[
        "final_completion_non_diagram_requirement_consistency_matched_count"
    ] = 1 if non_diagram_consistency.get("matched") is True else 0
    code_consistency = _mapping_or_empty(
        report.get("final_completion_blocker_code_consistency")
    )
    fields["final_completion_blocker_code_consistency_code_count"] = (
        _optional_count(code_consistency.get("code_count")) or 0
    )
    fields["final_completion_blocker_code_consistency_code_total"] = (
        _optional_count(code_consistency.get("code_count_total")) or 0
    )
    fields["final_completion_blocker_code_consistency_total_matched_count"] = (
        1
        if code_consistency.get("code_count_total_matches_blocker_count")
        is True
        else 0
    )
    fields["final_completion_blocker_code_consistency_unique_matched_count"] = (
        1
        if code_consistency.get("unique_code_count_matches_top_level") is True
        else 0
    )
    fields["final_completion_blocker_code_consistency_signature_matched_count"] = (
        1 if code_consistency.get("signature_matches_counts") is True else 0
    )
    fields["final_completion_blocker_code_consistency_all_have_code_count"] = (
        1 if code_consistency.get("all_blockers_have_code") is True else 0
    )
    fields["final_completion_blocker_code_consistency_matched_count"] = (
        1 if code_consistency.get("matched") is True else 0
    )
    code_detail_consistency = _mapping_or_empty(
        report.get("final_completion_blocker_code_summary_detail_consistency")
    )
    fields[
        "final_completion_blocker_code_summary_detail_consistency_row_count"
    ] = _optional_count(code_detail_consistency.get("summary_row_count")) or 0
    fields[
        "final_completion_blocker_code_summary_detail_consistency_code_count"
    ] = _optional_count(code_detail_consistency.get("code_count")) or 0
    fields[
        "final_completion_blocker_code_summary_detail_consistency_blocker_count"
    ] = _optional_count(code_detail_consistency.get("blocker_count")) or 0
    fields[
        "final_completion_blocker_code_summary_detail_consistency_kind_reference_count"
    ] = (
        _optional_count(code_detail_consistency.get("blocker_kind_reference_count"))
        or 0
    )
    fields[
        "final_completion_blocker_code_summary_detail_consistency_label_reference_count"
    ] = (
        _optional_count(code_detail_consistency.get("blocker_label_reference_count"))
        or 0
    )
    fields[
        "final_completion_blocker_code_summary_detail_consistency_missing_artifact_reference_count"
    ] = (
        _optional_count(
            code_detail_consistency.get("missing_artifact_reference_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_code_summary_detail_consistency_unique_missing_artifact_count"
    ] = (
        _optional_count(code_detail_consistency.get("unique_missing_artifact_count"))
        or 0
    )
    fields[
        "final_completion_blocker_code_summary_detail_consistency_blocker_count_matched_count"
    ] = (
        _optional_count(code_detail_consistency.get("blocker_count_matched_count"))
        or 0
    )
    fields[
        "final_completion_blocker_code_summary_detail_consistency_kinds_matched_count"
    ] = (
        _optional_count(code_detail_consistency.get("blocker_kinds_matched_count"))
        or 0
    )
    fields[
        "final_completion_blocker_code_summary_detail_consistency_labels_matched_count"
    ] = (
        _optional_count(code_detail_consistency.get("blocker_labels_matched_count"))
        or 0
    )
    fields[
        "final_completion_blocker_code_summary_detail_consistency_missing_artifacts_matched_count"
    ] = (
        _optional_count(code_detail_consistency.get("missing_artifacts_matched_count"))
        or 0
    )
    fields[
        "final_completion_blocker_code_summary_detail_consistency_mismatched_count"
    ] = (
        _optional_count(code_detail_consistency.get("mismatched_summary_row_count"))
        or 0
    )
    fields[
        "final_completion_blocker_code_summary_detail_consistency_matched_count"
    ] = 1 if code_detail_consistency.get("matched") is True else 0
    kind_consistency = _mapping_or_empty(
        report.get("final_completion_blocker_kind_consistency")
    )
    fields["final_completion_blocker_kind_summary_row_count"] = (
        _optional_count(kind_consistency.get("summary_row_count")) or 0
    )
    fields["final_completion_blocker_kind_summary_blocker_count"] = (
        _optional_count(kind_consistency.get("summary_blocker_count")) or 0
    )
    fields["final_completion_blocker_kind_signed_fixture_count"] = (
        _optional_count(kind_consistency.get("signed_fixture_blocker_count")) or 0
    )
    fields["final_completion_blocker_kind_non_diagram_requirement_count"] = (
        _optional_count(
            kind_consistency.get("non_diagram_requirement_blocker_count")
        )
        or 0
    )
    fields["final_completion_blocker_kind_completion_gate_count"] = (
        _optional_count(kind_consistency.get("completion_gate_blocker_count"))
        or 0
    )
    fields["final_completion_blocker_kind_consistency_blocker_count"] = (
        _optional_count(kind_consistency.get("blocker_count")) or 0
    )
    fields["final_completion_blocker_kind_consistency_kind_count"] = (
        _optional_count(kind_consistency.get("kind_count")) or 0
    )
    fields["final_completion_blocker_kind_consistency_kind_total"] = (
        _optional_count(kind_consistency.get("kind_count_total")) or 0
    )
    fields["final_completion_blocker_kind_consistency_total_matched_count"] = (
        1
        if kind_consistency.get("kind_count_total_matches_blocker_count")
        is True
        else 0
    )
    fields["final_completion_blocker_kind_consistency_unique_matched_count"] = (
        1
        if kind_consistency.get("unique_kind_count_matches_summary") is True
        else 0
    )
    fields["final_completion_blocker_kind_all_have_kind_count"] = (
        1 if kind_consistency.get("all_blockers_have_kind") is True else 0
    )
    fields["final_completion_blocker_kind_summary_count_matched_count"] = (
        1
        if kind_consistency.get("summary_blocker_count_matches_top_level")
        is True
        else 0
    )
    fields["final_completion_blocker_kind_consistency_matched_count"] = (
        1 if kind_consistency.get("matched") is True else 0
    )
    kind_detail_consistency = _mapping_or_empty(
        report.get("final_completion_blocker_kind_summary_detail_consistency")
    )
    fields[
        "final_completion_blocker_kind_summary_detail_consistency_row_count"
    ] = (
        _optional_count(kind_detail_consistency.get("summary_row_count")) or 0
    )
    fields[
        "final_completion_blocker_kind_summary_detail_consistency_kind_count"
    ] = _optional_count(kind_detail_consistency.get("kind_count")) or 0
    fields[
        "final_completion_blocker_kind_summary_detail_consistency_blocker_count"
    ] = _optional_count(kind_detail_consistency.get("blocker_count")) or 0
    fields[
        "final_completion_blocker_kind_summary_detail_consistency_code_reference_count"
    ] = (
        _optional_count(
            kind_detail_consistency.get("blocker_code_reference_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_kind_summary_detail_consistency_missing_artifact_reference_count"
    ] = (
        _optional_count(
            kind_detail_consistency.get("missing_artifact_reference_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_kind_summary_detail_consistency_unique_missing_artifact_count"
    ] = (
        _optional_count(
            kind_detail_consistency.get("unique_missing_artifact_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_kind_summary_detail_consistency_blocker_count_matched_count"
    ] = (
        _optional_count(
            kind_detail_consistency.get("blocker_count_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_kind_summary_detail_consistency_codes_matched_count"
    ] = (
        _optional_count(
            kind_detail_consistency.get("blocker_codes_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_kind_summary_detail_consistency_missing_artifacts_matched_count"
    ] = (
        _optional_count(
            kind_detail_consistency.get("missing_artifacts_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_kind_summary_detail_consistency_mismatched_count"
    ] = (
        _optional_count(
            kind_detail_consistency.get("mismatched_summary_row_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_kind_summary_detail_consistency_matched_count"
    ] = 1 if kind_detail_consistency.get("matched") is True else 0
    gate_summary_detail_consistency = _mapping_or_empty(
        report.get("final_completion_open_gate_blocker_summary_detail_consistency")
    )
    fields[
        "final_completion_open_gate_blocker_summary_detail_consistency_gate_count"
    ] = (
        _optional_count(gate_summary_detail_consistency.get("summary_gate_count"))
        or 0
    )
    fields[
        "final_completion_open_gate_blocker_summary_detail_consistency_blocker_count"
    ] = _optional_count(gate_summary_detail_consistency.get("blocker_count")) or 0
    fields[
        "final_completion_open_gate_blocker_summary_detail_consistency_code_reference_count"
    ] = (
        _optional_count(
            gate_summary_detail_consistency.get("blocker_code_reference_count")
        )
        or 0
    )
    fields[
        "final_completion_open_gate_blocker_summary_detail_consistency_missing_artifact_reference_count"
    ] = (
        _optional_count(
            gate_summary_detail_consistency.get("missing_artifact_reference_count")
        )
        or 0
    )
    fields[
        "final_completion_open_gate_blocker_summary_detail_consistency_unique_missing_artifact_count"
    ] = (
        _optional_count(
            gate_summary_detail_consistency.get("unique_missing_artifact_count")
        )
        or 0
    )
    fields[
        "final_completion_open_gate_blocker_summary_detail_consistency_retained_evidence_reference_count"
    ] = (
        _optional_count(
            gate_summary_detail_consistency.get("retained_evidence_reference_count")
        )
        or 0
    )
    fields[
        "final_completion_open_gate_blocker_summary_detail_consistency_blocker_count_matched_count"
    ] = (
        _optional_count(
            gate_summary_detail_consistency.get("blocker_count_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_open_gate_blocker_summary_detail_consistency_codes_matched_count"
    ] = (
        _optional_count(
            gate_summary_detail_consistency.get("blocker_codes_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_open_gate_blocker_summary_detail_consistency_missing_artifacts_matched_count"
    ] = (
        _optional_count(
            gate_summary_detail_consistency.get("missing_artifacts_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_open_gate_blocker_summary_detail_consistency_retained_evidence_matched_count"
    ] = (
        _optional_count(
            gate_summary_detail_consistency.get(
                "retained_evidence_count_matched_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_open_gate_blocker_summary_detail_consistency_mismatched_count"
    ] = (
        _optional_count(
            gate_summary_detail_consistency.get("mismatched_summary_row_count")
        )
        or 0
    )
    fields[
        "final_completion_open_gate_blocker_summary_detail_consistency_matched_count"
    ] = 1 if gate_summary_detail_consistency.get("matched") is True else 0
    link_consistency = _mapping_or_empty(
        report.get("final_completion_blocker_evidence_link_consistency")
    )
    fields["final_completion_blocker_evidence_linked_blocker_count"] = (
        _optional_count(link_consistency.get("linked_blocker_count")) or 0
    )
    fields["final_completion_blocker_evidence_unlinked_blocker_count"] = (
        _optional_count(link_consistency.get("unlinked_blocker_count")) or 0
    )
    fields["final_completion_blocker_evidence_reference_count"] = (
        _optional_count(link_consistency.get("retained_evidence_reference_count"))
        or 0
    )
    fields["final_completion_blocker_evidence_reference_count_matched_count"] = (
        1
        if link_consistency.get(
            "retained_evidence_reference_count_matches_top_level"
        )
        is True
        else 0
    )
    fields["final_completion_blocker_evidence_id_count_matched_count"] = (
        1
        if link_consistency.get("retained_evidence_id_count_matches_top_level")
        is True
        else 0
    )
    fields["final_completion_blocker_evidence_non_claim_matched_count"] = (
        1
        if link_consistency.get(
            "retained_evidence_non_claim_consistency_matches_top_level"
        )
        is True
        else 0
    )
    fields["final_completion_blocker_evidence_link_consistency_matched_count"] = (
        1 if link_consistency.get("matched") is True else 0
    )
    fields["final_completion_blocker_evidence_machine_audit_fields_present_count"] = (
        1
        if link_consistency.get("all_blockers_have_machine_audit_fields")
        is True
        else 0
    )
    fields["final_completion_blocker_evidence_label_present_count"] = (
        _optional_count(link_consistency.get("blocker_label_present_count")) or 0
    )
    fields["final_completion_blocker_evidence_code_present_count"] = (
        _optional_count(link_consistency.get("blocker_code_present_count")) or 0
    )
    fields["final_completion_blocker_evidence_missing_artifact_present_count"] = (
        _optional_count(link_consistency.get("missing_artifact_present_count"))
        or 0
    )
    fields["final_completion_blocker_evidence_required_evidence_present_count"] = (
        _optional_count(link_consistency.get("required_evidence_present_count"))
        or 0
    )
    fields["final_completion_blocker_evidence_current_evidence_present_count"] = (
        _optional_count(link_consistency.get("current_evidence_present_count"))
        or 0
    )
    link_kind_detail_consistency = _mapping_or_empty(
        report.get(
            "final_completion_blocker_evidence_link_kind_summary_detail_consistency"
        )
    )
    fields[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency_row_count"
    ] = _optional_count(link_kind_detail_consistency.get("summary_row_count")) or 0
    fields[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency_blocker_count"
    ] = _optional_count(link_kind_detail_consistency.get("blocker_count")) or 0
    fields[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency_linked_count"
    ] = _optional_count(link_kind_detail_consistency.get("linked_blocker_count")) or 0
    fields[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency_unlinked_count"
    ] = _optional_count(link_kind_detail_consistency.get("unlinked_blocker_count")) or 0
    fields[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency_reference_count"
    ] = (
        _optional_count(
            link_kind_detail_consistency.get("retained_evidence_reference_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency_id_count"
    ] = _optional_count(link_kind_detail_consistency.get("retained_evidence_id_count")) or 0
    fields[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency_non_claimed_link_count"
    ] = (
        _optional_count(
            link_kind_detail_consistency.get("retained_evidence_non_claimed_link_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency_blocker_count_matched_count"
    ] = (
        _optional_count(link_kind_detail_consistency.get("blocker_count_matched_count"))
        or 0
    )
    fields[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency_linked_count_matched_count"
    ] = (
        _optional_count(
            link_kind_detail_consistency.get("linked_blocker_count_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency_unlinked_count_matched_count"
    ] = (
        _optional_count(
            link_kind_detail_consistency.get("unlinked_blocker_count_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency_reference_count_matched_count"
    ] = (
        _optional_count(
            link_kind_detail_consistency.get(
                "retained_evidence_reference_count_matched_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency_ids_matched_count"
    ] = (
        _optional_count(
            link_kind_detail_consistency.get("retained_evidence_ids_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency_non_claim_matched_count"
    ] = (
        _optional_count(
            link_kind_detail_consistency.get(
                "retained_evidence_non_claim_counts_matched_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency_mismatched_count"
    ] = (
        _optional_count(link_kind_detail_consistency.get("mismatched_summary_row_count"))
        or 0
    )
    fields[
        "final_completion_blocker_evidence_link_kind_summary_detail_consistency_matched_count"
    ] = 1 if link_kind_detail_consistency.get("matched") is True else 0
    gate_blocker_consistency = _mapping_or_empty(
        report.get("final_completion_gate_blocker_consistency")
    )
    fields["final_completion_gate_blocker_consistency_checked_gate_count"] = (
        _optional_count(gate_blocker_consistency.get("checked_gate_count")) or 0
    )
    fields["final_completion_gate_blocker_consistency_mismatched_gate_count"] = (
        _optional_count(gate_blocker_consistency.get("mismatched_gate_count")) or 0
    )
    fields["final_completion_gate_blocker_count_matched_gate_count"] = (
        _optional_count(
            gate_blocker_consistency.get("blocker_count_matched_gate_count")
        )
        or 0
    )
    fields["final_completion_gate_blocker_codes_matched_gate_count"] = (
        _optional_count(
            gate_blocker_consistency.get("blocker_codes_matched_gate_count")
        )
        or 0
    )
    fields["final_completion_gate_blocker_consistency_matched_count"] = (
        1 if gate_blocker_consistency.get("matched") is True else 0
    )
    non_claim_gate_consistency = _mapping_or_empty(
        report.get("final_completion_non_claim_gate_consistency")
    )
    fields["final_completion_non_claim_gate_count"] = (
        _optional_count(non_claim_gate_consistency.get("non_claim_gate_count")) or 0
    )
    fields["final_completion_non_claim_gate_top_level_false_count"] = (
        _optional_count(non_claim_gate_consistency.get("top_level_false_count"))
        or 0
    )
    fields["final_completion_non_claim_gate_check_failed_count"] = (
        _optional_count(non_claim_gate_consistency.get("gate_check_failed_count"))
        or 0
    )
    fields["final_completion_non_claim_gate_blocker_count"] = (
        _optional_count(
            non_claim_gate_consistency.get("completion_gate_blocker_count")
        )
        or 0
    )
    fields["final_completion_non_claim_gate_code_matched_count"] = (
        _optional_count(non_claim_gate_consistency.get("blocker_code_matched_count"))
        or 0
    )
    fields["final_completion_non_claim_gate_missing_artifact_matched_count"] = (
        _optional_count(
            non_claim_gate_consistency.get("missing_artifact_matched_count")
        )
        or 0
    )
    fields["final_completion_non_claim_gate_matched_gate_count"] = (
        _optional_count(non_claim_gate_consistency.get("matched_gate_count")) or 0
    )
    fields["final_completion_non_claim_gate_all_false_count"] = (
        1
        if non_claim_gate_consistency.get("all_top_level_values_false") is True
        else 0
    )
    fields["final_completion_non_claim_gate_all_blockers_present_count"] = (
        1
        if non_claim_gate_consistency.get("all_completion_gate_blockers_present")
        is True
        else 0
    )
    fields["final_completion_non_claim_gate_consistency_matched_count"] = (
        1 if non_claim_gate_consistency.get("matched") is True else 0
    )
    fields["final_completion_non_claim_gate_consistency_field_count"] = (
        _optional_count(non_claim_gate_consistency.get("non_claim_field_count")) or 0
    )
    fields["final_completion_non_claim_gate_consistency_false_count"] = (
        _optional_count(
            non_claim_gate_consistency.get("false_non_claim_field_count")
        )
        or 0
    )
    fields["final_completion_non_claim_gate_consistency_gate_count"] = (
        _optional_count(non_claim_gate_consistency.get("completion_gate_check_count"))
        or 0
    )
    fields["final_completion_non_claim_gate_consistency_blocker_count"] = (
        _optional_count(
            non_claim_gate_consistency.get("completion_gate_blocker_count")
        )
        or 0
    )
    fields[
        "final_completion_non_claim_gate_consistency_missing_artifact_count"
    ] = (
        _optional_count(
            non_claim_gate_consistency.get("missing_artifact_reference_count")
        )
        or 0
    )
    fields["final_completion_non_claim_gate_consistency_mismatched_count"] = (
        _optional_count(
            non_claim_gate_consistency.get("mismatched_non_claim_field_count")
        )
        or 0
    )
    completion_gate_evidence_consistency = _mapping_or_empty(
        report.get("final_completion_completion_gate_evidence_consistency")
    )
    fields["final_completion_completion_gate_evidence_consistency_gate_count"] = (
        _optional_count(completion_gate_evidence_consistency.get("gate_count")) or 0
    )
    fields[
        "final_completion_completion_gate_evidence_consistency_gate_check_count"
    ] = (
        _optional_count(
            completion_gate_evidence_consistency.get("gate_check_count")
        )
        or 0
    )
    fields[
        "final_completion_completion_gate_evidence_consistency_blocker_count"
    ] = (
        _optional_count(
            completion_gate_evidence_consistency.get(
                "completion_gate_blocker_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_completion_gate_evidence_consistency_failed_gate_count"
    ] = (
        _optional_count(completion_gate_evidence_consistency.get("failed_gate_count"))
        or 0
    )
    fields[
        "final_completion_completion_gate_evidence_consistency_top_level_false_count"
    ] = (
        _optional_count(
            completion_gate_evidence_consistency.get("top_level_false_count")
        )
        or 0
    )
    fields[
        "final_completion_completion_gate_evidence_consistency_code_matched_count"
    ] = (
        _optional_count(
            completion_gate_evidence_consistency.get("blocker_code_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_completion_gate_evidence_consistency_required_evidence_matched_count"
    ] = (
        _optional_count(
            completion_gate_evidence_consistency.get(
                "required_evidence_matched_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_completion_gate_evidence_consistency_current_evidence_matched_count"
    ] = (
        _optional_count(
            completion_gate_evidence_consistency.get(
                "current_evidence_matched_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_completion_gate_evidence_consistency_missing_artifact_matched_count"
    ] = (
        _optional_count(
            completion_gate_evidence_consistency.get(
                "missing_artifact_matched_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_completion_gate_evidence_consistency_missing_artifact_id_matched_count"
    ] = (
        _optional_count(
            completion_gate_evidence_consistency.get(
                "missing_artifact_id_matched_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_completion_gate_evidence_consistency_retained_evidence_count"
    ] = (
        _optional_count(
            completion_gate_evidence_consistency.get(
                "retained_evidence_reference_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_completion_gate_evidence_consistency_retained_evidence_id_count"
    ] = (
        _optional_count(
            completion_gate_evidence_consistency.get(
                "retained_evidence_id_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_completion_gate_evidence_consistency_retained_evidence_ids_matched_count"
    ] = (
        _optional_count(
            completion_gate_evidence_consistency.get(
                "retained_evidence_ids_matched_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_completion_gate_evidence_consistency_mismatched_count"
    ] = (
        _optional_count(
            completion_gate_evidence_consistency.get("mismatched_gate_count")
        )
        or 0
    )
    fields[
        "final_completion_completion_gate_evidence_consistency_matched_count"
    ] = 1 if completion_gate_evidence_consistency.get("matched") is True else 0
    missing_artifact_consistency = _mapping_or_empty(
        report.get("final_completion_missing_artifact_summary_consistency")
    )
    fields["final_completion_missing_artifact_reference_count"] = (
        _optional_count(missing_artifact_consistency.get("reference_count")) or 0
    )
    fields["final_completion_missing_artifact_unique_count"] = (
        _optional_count(
            missing_artifact_consistency.get("unique_missing_artifact_count")
        )
        or 0
    )
    fields["final_completion_missing_artifact_summary_row_count"] = (
        _optional_count(missing_artifact_consistency.get("summary_row_count")) or 0
    )
    fields["final_completion_missing_artifact_reference_count_matched_count"] = (
        1
        if missing_artifact_consistency.get("references_match_blocker_count")
        is True
        else 0
    )
    fields["final_completion_missing_artifact_summary_row_count_matched_count"] = (
        1
        if missing_artifact_consistency.get(
            "summary_row_count_matches_unique_missing_artifacts"
        )
        is True
        else 0
    )
    fields["final_completion_missing_artifact_summary_consistency_matched_count"] = (
        1 if missing_artifact_consistency.get("matched") is True else 0
    )
    missing_artifact_detail_consistency = _mapping_or_empty(
        report.get("final_completion_missing_artifact_summary_detail_consistency")
    )
    fields[
        "final_completion_missing_artifact_summary_detail_consistency_row_count"
    ] = (
        _optional_count(
            missing_artifact_detail_consistency.get("summary_row_count")
        )
        or 0
    )
    fields[
        "final_completion_missing_artifact_summary_detail_consistency_unique_count"
    ] = (
        _optional_count(
            missing_artifact_detail_consistency.get("unique_missing_artifact_count")
        )
        or 0
    )
    fields[
        "final_completion_missing_artifact_summary_detail_consistency_blocker_count"
    ] = (
        _optional_count(missing_artifact_detail_consistency.get("blocker_count"))
        or 0
    )
    fields[
        "final_completion_missing_artifact_summary_detail_consistency_code_reference_count"
    ] = (
        _optional_count(
            missing_artifact_detail_consistency.get("blocker_code_reference_count")
        )
        or 0
    )
    fields[
        "final_completion_missing_artifact_summary_detail_consistency_label_reference_count"
    ] = (
        _optional_count(
            missing_artifact_detail_consistency.get("blocker_label_reference_count")
        )
        or 0
    )
    fields[
        "final_completion_missing_artifact_summary_detail_consistency_blocker_count_matched_count"
    ] = (
        _optional_count(
            missing_artifact_detail_consistency.get(
                "blocker_count_matched_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_missing_artifact_summary_detail_consistency_codes_matched_count"
    ] = (
        _optional_count(
            missing_artifact_detail_consistency.get("blocker_codes_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_missing_artifact_summary_detail_consistency_labels_matched_count"
    ] = (
        _optional_count(
            missing_artifact_detail_consistency.get("blocker_labels_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_missing_artifact_summary_detail_consistency_mismatched_count"
    ] = (
        _optional_count(
            missing_artifact_detail_consistency.get("mismatched_summary_row_count")
        )
        or 0
    )
    fields[
        "final_completion_missing_artifact_summary_detail_consistency_matched_count"
    ] = 1 if missing_artifact_detail_consistency.get("matched") is True else 0
    evidence_field_consistency = _mapping_or_empty(
        report.get("final_completion_blocker_evidence_field_consistency")
    )
    fields["final_completion_blocker_evidence_field_summary_row_count"] = (
        _optional_count(evidence_field_consistency.get("summary_row_count")) or 0
    )
    fields[
        "final_completion_blocker_evidence_field_missing_artifact_present_count"
    ] = (
        _optional_count(
            evidence_field_consistency.get("missing_artifact_present_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_field_required_evidence_present_count"
    ] = (
        _optional_count(
            evidence_field_consistency.get("required_evidence_present_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_field_current_evidence_present_count"
    ] = (
        _optional_count(
            evidence_field_consistency.get("current_evidence_present_count")
        )
        or 0
    )
    fields["final_completion_blocker_evidence_field_all_present_count"] = (
        _optional_count(
            evidence_field_consistency.get("all_evidence_fields_present_count")
        )
        or 0
    )
    fields["final_completion_blocker_evidence_field_consistency_matched_count"] = (
        1 if evidence_field_consistency.get("matched") is True else 0
    )
    evidence_field_detail_consistency = _mapping_or_empty(
        report.get(
            "final_completion_blocker_evidence_field_summary_detail_consistency"
        )
    )
    fields[
        "final_completion_blocker_evidence_field_summary_detail_consistency_row_count"
    ] = (
        _optional_count(evidence_field_detail_consistency.get("summary_row_count"))
        or 0
    )
    fields[
        "final_completion_blocker_evidence_field_summary_detail_consistency_blocker_count"
    ] = (
        _optional_count(evidence_field_detail_consistency.get("blocker_count"))
        or 0
    )
    fields[
        "final_completion_blocker_evidence_field_summary_detail_consistency_missing_count"
    ] = (
        _optional_count(
            evidence_field_detail_consistency.get(
                "missing_artifact_present_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_field_summary_detail_consistency_required_count"
    ] = (
        _optional_count(
            evidence_field_detail_consistency.get(
                "required_evidence_present_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_field_summary_detail_consistency_current_count"
    ] = (
        _optional_count(
            evidence_field_detail_consistency.get(
                "current_evidence_present_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_field_summary_detail_consistency_all_present_count"
    ] = (
        _optional_count(
            evidence_field_detail_consistency.get(
                "all_evidence_fields_present_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_field_summary_detail_consistency_blocker_count_matched_count"
    ] = (
        _optional_count(
            evidence_field_detail_consistency.get("blocker_count_matched_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_field_summary_detail_consistency_missing_matched_count"
    ] = (
        _optional_count(
            evidence_field_detail_consistency.get(
                "missing_artifact_present_count_matched_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_field_summary_detail_consistency_required_matched_count"
    ] = (
        _optional_count(
            evidence_field_detail_consistency.get(
                "required_evidence_present_count_matched_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_field_summary_detail_consistency_current_matched_count"
    ] = (
        _optional_count(
            evidence_field_detail_consistency.get(
                "current_evidence_present_count_matched_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_field_summary_detail_consistency_all_present_matched_count"
    ] = (
        _optional_count(
            evidence_field_detail_consistency.get(
                "all_evidence_fields_present_count_matched_count"
            )
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_field_summary_detail_consistency_mismatched_count"
    ] = (
        _optional_count(
            evidence_field_detail_consistency.get("mismatched_summary_row_count")
        )
        or 0
    )
    fields[
        "final_completion_blocker_evidence_field_summary_detail_consistency_matched_count"
    ] = 1 if evidence_field_detail_consistency.get("matched") is True else 0
    return fields


def _analysis_validation_pack_audit_totals(
    summaries: Iterable[Mapping[str, Any]],
) -> dict[str, int]:
    return {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in summaries
        )
        for key in _VALIDATION_PACK_AUDIT_COUNT_KEYS
    }


def _append_validation_pack_audit_note(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    if report.get("method") != "cross_workstream_validation_pack_audit":
        return notes
    fixture_count = _optional_count(report.get("required_diagram_fixture_count")) or 0
    registered_count = (
        _optional_count(report.get("registered_required_diagram_fixture_count")) or 0
    )
    unsigned_count = _optional_count(report.get("unsigned_required_fixture_count")) or 0
    open_non_diagram = (
        _optional_count(report.get("open_non_diagram_requirement_count")) or 0
    )
    final_blockers = _optional_count(report.get("final_completion_blocker_count")) or 0
    final_blocker_signature = str(report.get("final_completion_blocker_signature") or "")
    final_ready = bool(report.get("final_completion_ready", False))
    fixture_source_url_shape = _mapping_or_empty(
        report.get("fixture_source_url_shape_summary")
    )
    fixture_source_url_rows = (
        _optional_count(fixture_source_url_shape.get("source_url_row_count")) or 0
    )
    fixture_source_url_required = (
        _optional_count(fixture_source_url_shape.get("source_url_required_count"))
        or 0
    )
    fixture_source_url_http = (
        _optional_count(
            fixture_source_url_shape.get("source_url_http_or_https_count")
        )
        or 0
    )
    fixture_source_url_satisfied = (
        _optional_count(
            fixture_source_url_shape.get(
                "source_url_requirement_satisfied_count"
            )
        )
        or 0
    )
    fixture_source_url_scheme_total = (
        _optional_count(
            fixture_source_url_shape.get("source_url_scheme_count_total")
        )
        or 0
    )
    fixture_source_url_domain_total = (
        _optional_count(
            fixture_source_url_shape.get("source_url_domain_count_total")
        )
        or 0
    )
    fixture_source_url_matched = bool(
        fixture_source_url_shape.get("matched", False)
    )
    fixture_known_limitations = _mapping_or_empty(
        report.get("fixture_known_limitations_summary")
    )
    fixture_known_limitations_rows = (
        _optional_count(fixture_known_limitations.get("fixture_row_count")) or 0
    )
    fixture_known_limitations_available = (
        _optional_count(
            fixture_known_limitations.get("known_limitations_available_count")
        )
        or 0
    )
    fixture_known_limitations_unavailable = (
        _optional_count(
            fixture_known_limitations.get("known_limitations_unavailable_count")
        )
        or 0
    )
    fixture_known_limitations_note_count = (
        _optional_count(
            fixture_known_limitations.get("known_limitations_note_count_total")
        )
        or 0
    )
    fixture_known_limitations_satisfied = (
        _optional_count(
            fixture_known_limitations.get(
                "known_limitations_requirement_satisfied_count"
            )
        )
        or 0
    )
    fixture_known_limitations_matched = bool(
        fixture_known_limitations.get("matched", False)
    )
    retained_evidence_count = _optional_count(report.get("retained_evidence_count")) or 0
    retained_evidence_id_count = (
        _optional_count(report.get("retained_evidence_id_count")) or 0
    )
    retained_evidence_all_non_claimed = bool(
        report.get("retained_evidence_all_non_claimed", False)
    )
    retained_evidence_claimed_count = (
        _optional_count(report.get("retained_evidence_completion_claimed_count")) or 0
    )
    retained_non_claim_consistency = _mapping_or_empty(
        report.get("retained_evidence_non_claim_consistency")
    )
    retained_non_claim_entry_count = (
        _optional_count(retained_non_claim_consistency.get("entry_count")) or 0
    )
    retained_non_claim_id_count = (
        _optional_count(retained_non_claim_consistency.get("evidence_id_count")) or 0
    )
    retained_non_claim_completion_count = (
        _optional_count(
            retained_non_claim_consistency.get("completion_claimed_count")
        )
        or 0
    )
    retained_non_claim_release_count = (
        _optional_count(
            retained_non_claim_consistency.get(
                "release_grade_speedup_claimed_count"
            )
        )
        or 0
    )
    retained_non_claim_real_backend_count = (
        _optional_count(
            retained_non_claim_consistency.get(
                "real_graphics_backend_framebuffer_verified_count"
            )
        )
        or 0
    )
    retained_non_claim_screenshot_count = (
        _optional_count(
            retained_non_claim_consistency.get("screenshot_verified_count")
        )
        or 0
    )
    retained_non_claim_matched = bool(
        retained_non_claim_consistency.get("matched", False)
    )
    retained_artifact_file_consistency = _mapping_or_empty(
        report.get("retained_evidence_artifact_file_consistency")
    )
    retained_artifact_entry_count = (
        _optional_count(retained_artifact_file_consistency.get("entry_count"))
        or 0
    )
    retained_artifact_evidence_count = (
        _optional_count(
            retained_artifact_file_consistency.get("artifact_evidence_count")
        )
        or 0
    )
    retained_non_artifact_evidence_count = (
        _optional_count(
            retained_artifact_file_consistency.get("non_artifact_evidence_count")
        )
        or 0
    )
    retained_artifact_file_ref_count = (
        _optional_count(
            retained_artifact_file_consistency.get("artifact_file_reference_count")
        )
        or 0
    )
    retained_artifact_unique_file_count = (
        _optional_count(
            retained_artifact_file_consistency.get("unique_artifact_file_count")
        )
        or 0
    )
    retained_artifact_raw_file_count = (
        _optional_count(retained_artifact_file_consistency.get("raw_file_count"))
        or 0
    )
    retained_artifact_analysis_file_count = (
        _optional_count(
            retained_artifact_file_consistency.get("analysis_file_count")
        )
        or 0
    )
    retained_artifact_host_file_count = (
        _optional_count(retained_artifact_file_consistency.get("host_file_count"))
        or 0
    )
    retained_artifact_complete_group_count = (
        _optional_count(
            retained_artifact_file_consistency.get(
                "complete_raw_analysis_host_group_count"
            )
        )
        or 0
    )
    retained_artifact_incomplete_group_count = (
        _optional_count(
            retained_artifact_file_consistency.get("incomplete_artifact_group_count")
        )
        or 0
    )
    retained_artifact_refs_matched = bool(
        retained_artifact_file_consistency.get(
            "artifact_file_reference_count_matches_groups",
            False,
        )
    )
    retained_artifact_file_types_matched = bool(
        retained_artifact_file_consistency.get(
            "raw_analysis_host_file_counts_matched",
            False,
        )
    )
    retained_artifact_groups_complete = bool(
        retained_artifact_file_consistency.get(
            "all_artifact_evidence_groups_complete",
            False,
        )
    )
    retained_artifact_files_unique = bool(
        retained_artifact_file_consistency.get("all_artifact_files_unique", False)
    )
    retained_artifact_file_matched = bool(
        retained_artifact_file_consistency.get("matched", False)
    )
    required_check_consistency = _mapping_or_empty(
        report.get("final_completion_required_check_consistency")
    )
    required_check_count = (
        _optional_count(required_check_consistency.get("required_check_count")) or 0
    )
    required_check_passed_count = (
        _optional_count(
            required_check_consistency.get("passed_required_check_count")
        )
        or 0
    )
    required_check_failed_count = (
        _optional_count(
            required_check_consistency.get("failed_required_check_count")
        )
        or 0
    )
    required_check_mismatched_count = (
        _optional_count(
            required_check_consistency.get("mismatched_required_check_count")
        )
        or 0
    )
    required_check_final_ready_matched = bool(
        required_check_consistency.get(
            "final_completion_ready_matches_required_checks",
            False,
        )
    )
    required_check_all_matched = bool(
        required_check_consistency.get("all_required_checks_matched", False)
    )
    required_check_matched = bool(required_check_consistency.get("matched", False))
    required_fixture_metadata_consistency = _mapping_or_empty(
        report.get(
            "final_completion_required_diagram_fixture_metadata_consistency"
        )
    )
    required_fixture_metadata_required_count = (
        _optional_count(
            required_fixture_metadata_consistency.get("required_fixture_count")
        )
        or 0
    )
    required_fixture_metadata_registered_count = (
        _optional_count(
            required_fixture_metadata_consistency.get("registered_fixture_count")
        )
        or 0
    )
    required_fixture_metadata_missing_count = (
        _optional_count(
            required_fixture_metadata_consistency.get("missing_fixture_count")
        )
        or 0
    )
    required_fixture_metadata_complete_count = (
        _optional_count(
            required_fixture_metadata_consistency.get(
                "metadata_complete_fixture_count"
            )
        )
        or 0
    )
    required_fixture_metadata_incomplete_count = (
        _optional_count(
            required_fixture_metadata_consistency.get(
                "metadata_incomplete_fixture_count"
            )
        )
        or 0
    )
    required_fixture_metadata_blocker_count = (
        _optional_count(
            required_fixture_metadata_consistency.get("metadata_blocker_count")
        )
        or 0
    )
    required_fixture_metadata_gate_passed = bool(
        required_fixture_metadata_consistency.get("gate_passed", False)
    )
    required_fixture_metadata_matched = bool(
        required_fixture_metadata_consistency.get("matched", False)
    )
    signed_fixture_consistency = _mapping_or_empty(
        report.get("final_completion_signed_fixture_consistency")
    )
    signed_fixture_blocker_count = (
        _optional_count(signed_fixture_consistency.get("signed_fixture_blocker_count"))
        or 0
    )
    signed_fixture_final_blocker_count = (
        _optional_count(signed_fixture_consistency.get("final_blocker_count")) or 0
    )
    signed_fixture_source_url_count = (
        _optional_count(signed_fixture_consistency.get("source_url_present_count"))
        or 0
    )
    signed_fixture_unsigned_count = (
        _optional_count(
            signed_fixture_consistency.get("unsigned_non_claim_preserved_count")
        )
        or 0
    )
    signed_fixture_source_table_count = (
        _optional_count(
            signed_fixture_consistency.get("source_table_metadata_available_count")
        )
        or 0
    )
    signed_fixture_source_candidate_evidence_count = (
        _optional_count(
            signed_fixture_consistency.get(
                "source_candidate_evidence_available_count"
            )
        )
        or 0
    )
    signed_fixture_source_candidate_not_unique_count = (
        _optional_count(
            signed_fixture_consistency.get("source_candidate_not_unique_count")
        )
        or 0
    )
    signed_fixture_source_candidate_replay_valid_count = (
        _optional_count(
            signed_fixture_consistency.get(
                "source_candidate_replay_all_valid_count"
            )
        )
        or 0
    )
    signed_fixture_source_candidate_matching_total = (
        _optional_count(
            signed_fixture_consistency.get(
                "source_candidate_matching_candidate_count_total"
            )
        )
        or 0
    )
    signed_fixture_source_candidate_unique_sign_total = (
        _optional_count(
            signed_fixture_consistency.get(
                "source_candidate_unique_sign_pattern_count_total"
            )
        )
        or 0
    )
    signed_fixture_mismatched_count = (
        _optional_count(signed_fixture_consistency.get("mismatched_fixture_count"))
        or 0
    )
    signed_fixture_matched = bool(signed_fixture_consistency.get("matched", False))
    non_diagram_consistency = _mapping_or_empty(
        report.get("final_completion_non_diagram_requirement_consistency")
    )
    non_diagram_requirement_count = (
        _optional_count(non_diagram_consistency.get("requirement_count")) or 0
    )
    non_diagram_open_count = (
        _optional_count(non_diagram_consistency.get("open_requirement_count")) or 0
    )
    non_diagram_blocker_count = (
        _optional_count(non_diagram_consistency.get("blocker_count")) or 0
    )
    non_diagram_retained_count = (
        _optional_count(
            non_diagram_consistency.get("retained_evidence_reference_count")
        )
        or 0
    )
    non_diagram_retained_id_count = (
        _optional_count(non_diagram_consistency.get("retained_evidence_id_count"))
        or 0
    )
    non_diagram_retained_refs_top_level_matched = bool(
        non_diagram_consistency.get(
            "retained_evidence_reference_count_matches_top_level",
            False,
        )
    )
    non_diagram_retained_ids_top_level_matched = bool(
        non_diagram_consistency.get(
            "retained_evidence_id_count_matches_top_level",
            False,
        )
    )
    non_diagram_mismatched_count = (
        _optional_count(
            non_diagram_consistency.get("mismatched_requirement_count")
        )
        or 0
    )
    non_diagram_missing_matched_count = (
        _optional_count(non_diagram_consistency.get("missing_artifact_matched_count"))
        or 0
    )
    non_diagram_evidence_matched_count = (
        _optional_count(non_diagram_consistency.get("evidence_fields_matched_count"))
        or 0
    )
    non_diagram_matched = bool(non_diagram_consistency.get("matched", False))
    code_consistency = _mapping_or_empty(
        report.get("final_completion_blocker_code_consistency")
    )
    code_consistency_code_count = (
        _optional_count(code_consistency.get("code_count")) or 0
    )
    code_consistency_code_total = (
        _optional_count(code_consistency.get("code_count_total")) or 0
    )
    code_consistency_total_matched = bool(
        code_consistency.get("code_count_total_matches_blocker_count", False)
    )
    code_consistency_unique_matched = bool(
        code_consistency.get("unique_code_count_matches_top_level", False)
    )
    code_consistency_signature_matched = bool(
        code_consistency.get("signature_matches_counts", False)
    )
    code_consistency_all_have_code = bool(
        code_consistency.get("all_blockers_have_code", False)
    )
    code_consistency_matched = bool(code_consistency.get("matched", False))
    code_detail_consistency = _mapping_or_empty(
        report.get("final_completion_blocker_code_summary_detail_consistency")
    )
    blocker_code_detail_rows = (
        _optional_count(code_detail_consistency.get("summary_row_count")) or 0
    )
    blocker_code_detail_codes = (
        _optional_count(code_detail_consistency.get("code_count")) or 0
    )
    blocker_code_detail_blockers = (
        _optional_count(code_detail_consistency.get("blocker_count")) or 0
    )
    blocker_code_detail_kind_refs = (
        _optional_count(code_detail_consistency.get("blocker_kind_reference_count"))
        or 0
    )
    blocker_code_detail_label_refs = (
        _optional_count(code_detail_consistency.get("blocker_label_reference_count"))
        or 0
    )
    blocker_code_detail_missing_refs = (
        _optional_count(code_detail_consistency.get("missing_artifact_reference_count"))
        or 0
    )
    blocker_code_detail_unique_missing = (
        _optional_count(code_detail_consistency.get("unique_missing_artifact_count"))
        or 0
    )
    blocker_code_detail_count_matched = (
        _optional_count(code_detail_consistency.get("blocker_count_matched_count"))
        or 0
    )
    blocker_code_detail_kinds_matched = (
        _optional_count(code_detail_consistency.get("blocker_kinds_matched_count"))
        or 0
    )
    blocker_code_detail_labels_matched = (
        _optional_count(code_detail_consistency.get("blocker_labels_matched_count"))
        or 0
    )
    blocker_code_detail_missing_matched = (
        _optional_count(code_detail_consistency.get("missing_artifacts_matched_count"))
        or 0
    )
    blocker_code_detail_mismatched = (
        _optional_count(code_detail_consistency.get("mismatched_summary_row_count"))
        or 0
    )
    blocker_code_detail_matched = bool(code_detail_consistency.get("matched", False))
    kind_consistency = _mapping_or_empty(
        report.get("final_completion_blocker_kind_consistency")
    )
    blocker_kind_summary_rows = (
        _optional_count(kind_consistency.get("summary_row_count")) or 0
    )
    blocker_kind_count = _optional_count(kind_consistency.get("kind_count")) or 0
    blocker_kind_summary_blockers = (
        _optional_count(kind_consistency.get("kind_count_total")) or 0
    )
    blocker_kind_signed_count = (
        _optional_count(kind_consistency.get("signed_fixture_blocker_count"))
        or 0
    )
    blocker_kind_non_diagram_count = (
        _optional_count(
            kind_consistency.get("non_diagram_requirement_blocker_count")
        )
        or 0
    )
    blocker_kind_completion_count = (
        _optional_count(kind_consistency.get("completion_gate_blocker_count"))
        or 0
    )
    blocker_kind_count_matched = bool(
        kind_consistency.get("kind_count_total_matches_blocker_count", False)
    )
    blocker_kind_unique_matched = bool(
        kind_consistency.get("unique_kind_count_matches_summary", False)
    )
    blocker_kind_all_have_kind = bool(
        kind_consistency.get("all_blockers_have_kind", False)
    )
    blocker_kind_matched = bool(kind_consistency.get("matched", False))
    kind_detail_consistency = _mapping_or_empty(
        report.get("final_completion_blocker_kind_summary_detail_consistency")
    )
    blocker_kind_detail_rows = (
        _optional_count(kind_detail_consistency.get("summary_row_count")) or 0
    )
    blocker_kind_detail_kinds = (
        _optional_count(kind_detail_consistency.get("kind_count")) or 0
    )
    blocker_kind_detail_blockers = (
        _optional_count(kind_detail_consistency.get("blocker_count")) or 0
    )
    blocker_kind_detail_code_refs = (
        _optional_count(kind_detail_consistency.get("blocker_code_reference_count"))
        or 0
    )
    blocker_kind_detail_missing_refs = (
        _optional_count(
            kind_detail_consistency.get("missing_artifact_reference_count")
        )
        or 0
    )
    blocker_kind_detail_unique_missing = (
        _optional_count(kind_detail_consistency.get("unique_missing_artifact_count"))
        or 0
    )
    blocker_kind_detail_count_matched = (
        _optional_count(kind_detail_consistency.get("blocker_count_matched_count"))
        or 0
    )
    blocker_kind_detail_codes_matched = (
        _optional_count(kind_detail_consistency.get("blocker_codes_matched_count"))
        or 0
    )
    blocker_kind_detail_missing_matched = (
        _optional_count(
            kind_detail_consistency.get("missing_artifacts_matched_count")
        )
        or 0
    )
    blocker_kind_detail_mismatched = (
        _optional_count(kind_detail_consistency.get("mismatched_summary_row_count"))
        or 0
    )
    blocker_kind_detail_matched = bool(
        kind_detail_consistency.get("matched", False)
    )
    gate_summary_consistency = _mapping_or_empty(
        report.get("final_completion_open_gate_blocker_summary_consistency")
    )
    gate_summary_failed_count = (
        _optional_count(gate_summary_consistency.get("failed_gate_count")) or 0
    )
    gate_summary_gate_count = (
        _optional_count(gate_summary_consistency.get("summary_gate_count")) or 0
    )
    gate_summary_blocker_count = (
        _optional_count(gate_summary_consistency.get("blocker_count")) or 0
    )
    gate_summary_summary_blocker_count = (
        _optional_count(gate_summary_consistency.get("summary_blocker_count")) or 0
    )
    gate_summary_gate_sets_matched = bool(
        gate_summary_consistency.get("gate_sets_matched", False)
    )
    gate_summary_blocker_count_matched = bool(
        gate_summary_consistency.get("blocker_count_matched", False)
    )
    gate_summary_all_have_gate = bool(
        gate_summary_consistency.get("all_blockers_have_gate", False)
    )
    gate_summary_detail_consistency = _mapping_or_empty(
        report.get("final_completion_open_gate_blocker_summary_detail_consistency")
    )
    gate_summary_detail_gates = (
        _optional_count(gate_summary_detail_consistency.get("summary_gate_count"))
        or 0
    )
    gate_summary_detail_blockers = (
        _optional_count(gate_summary_detail_consistency.get("blocker_count")) or 0
    )
    gate_summary_detail_code_refs = (
        _optional_count(
            gate_summary_detail_consistency.get("blocker_code_reference_count")
        )
        or 0
    )
    gate_summary_detail_missing_refs = (
        _optional_count(
            gate_summary_detail_consistency.get("missing_artifact_reference_count")
        )
        or 0
    )
    gate_summary_detail_unique_missing = (
        _optional_count(
            gate_summary_detail_consistency.get("unique_missing_artifact_count")
        )
        or 0
    )
    gate_summary_detail_retained_refs = (
        _optional_count(
            gate_summary_detail_consistency.get("retained_evidence_reference_count")
        )
        or 0
    )
    gate_summary_detail_count_matched = (
        _optional_count(
            gate_summary_detail_consistency.get("blocker_count_matched_count")
        )
        or 0
    )
    gate_summary_detail_codes_matched = (
        _optional_count(
            gate_summary_detail_consistency.get("blocker_codes_matched_count")
        )
        or 0
    )
    gate_summary_detail_missing_matched = (
        _optional_count(
            gate_summary_detail_consistency.get("missing_artifacts_matched_count")
        )
        or 0
    )
    gate_summary_detail_retained_matched = (
        _optional_count(
            gate_summary_detail_consistency.get(
                "retained_evidence_count_matched_count"
            )
        )
        or 0
    )
    gate_summary_detail_mismatched = (
        _optional_count(
            gate_summary_detail_consistency.get("mismatched_summary_row_count")
        )
        or 0
    )
    gate_summary_detail_matched = bool(
        gate_summary_detail_consistency.get("matched", False)
    )
    blocker_evidence_link_consistency = _mapping_or_empty(
        report.get("final_completion_blocker_evidence_link_consistency")
    )
    linked_blocker_count = (
        _optional_count(
            blocker_evidence_link_consistency.get("linked_blocker_count")
        )
        or 0
    )
    unlinked_blocker_count = (
        _optional_count(
            blocker_evidence_link_consistency.get("unlinked_blocker_count")
        )
        or 0
    )
    evidence_reference_count = (
        _optional_count(
            blocker_evidence_link_consistency.get(
                "retained_evidence_reference_count"
            )
        )
        or 0
    )
    evidence_reference_matched = bool(
        blocker_evidence_link_consistency.get(
            "retained_evidence_reference_count_matches_top_level",
            False,
        )
    )
    evidence_ids_matched = bool(
        blocker_evidence_link_consistency.get(
            "retained_evidence_id_count_matches_top_level",
            False,
        )
    )
    evidence_non_claim_matched = bool(
        blocker_evidence_link_consistency.get(
            "retained_evidence_non_claim_consistency_matches_top_level",
            False,
        )
    )
    blocker_evidence_label_present_count = (
        _optional_count(
            blocker_evidence_link_consistency.get("blocker_label_present_count")
        )
        or 0
    )
    blocker_evidence_code_present_count = (
        _optional_count(
            blocker_evidence_link_consistency.get("blocker_code_present_count")
        )
        or 0
    )
    blocker_evidence_missing_present_count = (
        _optional_count(
            blocker_evidence_link_consistency.get("missing_artifact_present_count")
        )
        or 0
    )
    blocker_evidence_required_present_count = (
        _optional_count(
            blocker_evidence_link_consistency.get("required_evidence_present_count")
        )
        or 0
    )
    blocker_evidence_current_present_count = (
        _optional_count(
            blocker_evidence_link_consistency.get("current_evidence_present_count")
        )
        or 0
    )
    evidence_link_matched = bool(
        blocker_evidence_link_consistency.get("matched", False)
    )
    blocker_evidence_link_kind_detail_consistency = _mapping_or_empty(
        report.get(
            "final_completion_blocker_evidence_link_kind_summary_detail_consistency"
        )
    )
    link_kind_detail_row_count = (
        _optional_count(
            blocker_evidence_link_kind_detail_consistency.get("summary_row_count")
        )
        or 0
    )
    link_kind_detail_blocker_count = (
        _optional_count(
            blocker_evidence_link_kind_detail_consistency.get("blocker_count")
        )
        or 0
    )
    link_kind_detail_linked_count = (
        _optional_count(
            blocker_evidence_link_kind_detail_consistency.get("linked_blocker_count")
        )
        or 0
    )
    link_kind_detail_unlinked_count = (
        _optional_count(
            blocker_evidence_link_kind_detail_consistency.get("unlinked_blocker_count")
        )
        or 0
    )
    link_kind_detail_reference_count = (
        _optional_count(
            blocker_evidence_link_kind_detail_consistency.get(
                "retained_evidence_reference_count"
            )
        )
        or 0
    )
    link_kind_detail_id_count = (
        _optional_count(
            blocker_evidence_link_kind_detail_consistency.get(
                "retained_evidence_id_count"
            )
        )
        or 0
    )
    link_kind_detail_non_claimed_count = (
        _optional_count(
            blocker_evidence_link_kind_detail_consistency.get(
                "retained_evidence_non_claimed_link_count"
            )
        )
        or 0
    )
    link_kind_detail_blocker_matched_count = (
        _optional_count(
            blocker_evidence_link_kind_detail_consistency.get(
                "blocker_count_matched_count"
            )
        )
        or 0
    )
    link_kind_detail_linked_matched_count = (
        _optional_count(
            blocker_evidence_link_kind_detail_consistency.get(
                "linked_blocker_count_matched_count"
            )
        )
        or 0
    )
    link_kind_detail_unlinked_matched_count = (
        _optional_count(
            blocker_evidence_link_kind_detail_consistency.get(
                "unlinked_blocker_count_matched_count"
            )
        )
        or 0
    )
    link_kind_detail_reference_matched_count = (
        _optional_count(
            blocker_evidence_link_kind_detail_consistency.get(
                "retained_evidence_reference_count_matched_count"
            )
        )
        or 0
    )
    link_kind_detail_ids_matched_count = (
        _optional_count(
            blocker_evidence_link_kind_detail_consistency.get(
                "retained_evidence_ids_matched_count"
            )
        )
        or 0
    )
    link_kind_detail_non_claim_matched_count = (
        _optional_count(
            blocker_evidence_link_kind_detail_consistency.get(
                "retained_evidence_non_claim_counts_matched_count"
            )
        )
        or 0
    )
    link_kind_detail_mismatched_count = (
        _optional_count(
            blocker_evidence_link_kind_detail_consistency.get(
                "mismatched_summary_row_count"
            )
        )
        or 0
    )
    link_kind_detail_matched = bool(
        blocker_evidence_link_kind_detail_consistency.get("matched", False)
    )
    gate_blocker_consistency = _mapping_or_empty(
        report.get("final_completion_gate_blocker_consistency")
    )
    gate_blocker_checked_count = (
        _optional_count(gate_blocker_consistency.get("checked_gate_count")) or 0
    )
    gate_blocker_mismatched_count = (
        _optional_count(gate_blocker_consistency.get("mismatched_gate_count")) or 0
    )
    gate_blocker_count_matched_count = (
        _optional_count(
            gate_blocker_consistency.get("blocker_count_matched_gate_count")
        )
        or 0
    )
    gate_blocker_codes_matched_count = (
        _optional_count(
            gate_blocker_consistency.get("blocker_codes_matched_gate_count")
        )
        or 0
    )
    gate_blocker_matched = bool(gate_blocker_consistency.get("matched", False))
    non_claim_gate_consistency = _mapping_or_empty(
        report.get("final_completion_non_claim_gate_consistency")
    )
    non_claim_gate_count = (
        _optional_count(non_claim_gate_consistency.get("non_claim_field_count")) or 0
    )
    non_claim_top_level_false_count = (
        _optional_count(
            non_claim_gate_consistency.get("false_non_claim_field_count")
        )
        or 0
    )
    non_claim_gate_failed_count = (
        _optional_count(non_claim_gate_consistency.get("completion_gate_check_count"))
        or 0
    )
    non_claim_blocker_count = (
        _optional_count(
            non_claim_gate_consistency.get("completion_gate_blocker_count")
        )
        or 0
    )
    non_claim_code_matched_count = (
        _optional_count(non_claim_gate_consistency.get("blocker_code_matched_count"))
        or 0
    )
    non_claim_missing_artifact_matched_count = (
        _optional_count(
            non_claim_gate_consistency.get("missing_artifact_reference_count")
        )
        or 0
    )
    non_claim_gate_matched = bool(non_claim_gate_consistency.get("matched", False))
    completion_gate_evidence_consistency = _mapping_or_empty(
        report.get("final_completion_completion_gate_evidence_consistency")
    )
    completion_gate_evidence_gate_count = (
        _optional_count(completion_gate_evidence_consistency.get("gate_count")) or 0
    )
    completion_gate_evidence_gate_check_count = (
        _optional_count(
            completion_gate_evidence_consistency.get("gate_check_count")
        )
        or 0
    )
    completion_gate_evidence_blocker_count = (
        _optional_count(
            completion_gate_evidence_consistency.get(
                "completion_gate_blocker_count"
            )
        )
        or 0
    )
    completion_gate_evidence_failed_count = (
        _optional_count(completion_gate_evidence_consistency.get("failed_gate_count"))
        or 0
    )
    completion_gate_evidence_false_count = (
        _optional_count(
            completion_gate_evidence_consistency.get("top_level_false_count")
        )
        or 0
    )
    completion_gate_evidence_code_count = (
        _optional_count(
            completion_gate_evidence_consistency.get("blocker_code_matched_count")
        )
        or 0
    )
    completion_gate_evidence_required_count = (
        _optional_count(
            completion_gate_evidence_consistency.get(
                "required_evidence_matched_count"
            )
        )
        or 0
    )
    completion_gate_evidence_current_count = (
        _optional_count(
            completion_gate_evidence_consistency.get(
                "current_evidence_matched_count"
            )
        )
        or 0
    )
    completion_gate_evidence_missing_count = (
        _optional_count(
            completion_gate_evidence_consistency.get(
                "missing_artifact_matched_count"
            )
        )
        or 0
    )
    completion_gate_evidence_missing_id_count = (
        _optional_count(
            completion_gate_evidence_consistency.get(
                "missing_artifact_id_matched_count"
            )
        )
        or 0
    )
    completion_gate_evidence_retained_count = (
        _optional_count(
            completion_gate_evidence_consistency.get(
                "retained_evidence_reference_count"
            )
        )
        or 0
    )
    completion_gate_evidence_retained_id_count = (
        _optional_count(
            completion_gate_evidence_consistency.get("retained_evidence_id_count")
        )
        or 0
    )
    completion_gate_evidence_retained_matched_count = (
        _optional_count(
            completion_gate_evidence_consistency.get(
                "retained_evidence_ids_matched_count"
            )
        )
        or 0
    )
    completion_gate_evidence_mismatched_count = (
        _optional_count(
            completion_gate_evidence_consistency.get("mismatched_gate_count")
        )
        or 0
    )
    completion_gate_evidence_matched = bool(
        completion_gate_evidence_consistency.get("matched", False)
    )
    missing_artifact_consistency = _mapping_or_empty(
        report.get("final_completion_missing_artifact_summary_consistency")
    )
    missing_artifact_reference_count = (
        _optional_count(missing_artifact_consistency.get("reference_count")) or 0
    )
    missing_artifact_unique_count = (
        _optional_count(
            missing_artifact_consistency.get("unique_missing_artifact_count")
        )
        or 0
    )
    missing_artifact_summary_row_count = (
        _optional_count(missing_artifact_consistency.get("summary_row_count")) or 0
    )
    missing_artifact_references_matched = bool(
        missing_artifact_consistency.get("references_match_blocker_count", False)
    )
    missing_artifact_rows_matched = bool(
        missing_artifact_consistency.get(
            "summary_row_count_matches_unique_missing_artifacts",
            False,
        )
    )
    missing_artifact_summary_matched = bool(
        missing_artifact_consistency.get("matched", False)
    )
    missing_artifact_detail_consistency = _mapping_or_empty(
        report.get("final_completion_missing_artifact_summary_detail_consistency")
    )
    missing_artifact_detail_row_count = (
        _optional_count(missing_artifact_detail_consistency.get("summary_row_count"))
        or 0
    )
    missing_artifact_detail_unique_count = (
        _optional_count(
            missing_artifact_detail_consistency.get("unique_missing_artifact_count")
        )
        or 0
    )
    missing_artifact_detail_blocker_count = (
        _optional_count(missing_artifact_detail_consistency.get("blocker_count"))
        or 0
    )
    missing_artifact_detail_code_count = (
        _optional_count(
            missing_artifact_detail_consistency.get("blocker_code_reference_count")
        )
        or 0
    )
    missing_artifact_detail_label_count = (
        _optional_count(
            missing_artifact_detail_consistency.get("blocker_label_reference_count")
        )
        or 0
    )
    missing_artifact_detail_count_matched_count = (
        _optional_count(
            missing_artifact_detail_consistency.get(
                "blocker_count_matched_count"
            )
        )
        or 0
    )
    missing_artifact_detail_codes_matched_count = (
        _optional_count(
            missing_artifact_detail_consistency.get("blocker_codes_matched_count")
        )
        or 0
    )
    missing_artifact_detail_labels_matched_count = (
        _optional_count(
            missing_artifact_detail_consistency.get("blocker_labels_matched_count")
        )
        or 0
    )
    missing_artifact_detail_mismatched_count = (
        _optional_count(
            missing_artifact_detail_consistency.get("mismatched_summary_row_count")
        )
        or 0
    )
    missing_artifact_detail_matched = bool(
        missing_artifact_detail_consistency.get("matched", False)
    )
    evidence_field_consistency = _mapping_or_empty(
        report.get("final_completion_blocker_evidence_field_consistency")
    )
    evidence_field_summary_rows = (
        _optional_count(evidence_field_consistency.get("summary_row_count")) or 0
    )
    evidence_field_missing_count = (
        _optional_count(
            evidence_field_consistency.get("missing_artifact_present_count")
        )
        or 0
    )
    evidence_field_required_count = (
        _optional_count(
            evidence_field_consistency.get("required_evidence_present_count")
        )
        or 0
    )
    evidence_field_current_count = (
        _optional_count(
            evidence_field_consistency.get("current_evidence_present_count")
        )
        or 0
    )
    evidence_field_all_count = (
        _optional_count(
            evidence_field_consistency.get("all_evidence_fields_present_count")
        )
        or 0
    )
    evidence_field_matched = bool(evidence_field_consistency.get("matched", False))
    evidence_field_detail_consistency = _mapping_or_empty(
        report.get(
            "final_completion_blocker_evidence_field_summary_detail_consistency"
        )
    )
    evidence_field_detail_row_count = (
        _optional_count(evidence_field_detail_consistency.get("summary_row_count"))
        or 0
    )
    evidence_field_detail_blocker_count = (
        _optional_count(evidence_field_detail_consistency.get("blocker_count")) or 0
    )
    evidence_field_detail_missing_count = (
        _optional_count(
            evidence_field_detail_consistency.get(
                "missing_artifact_present_count"
            )
        )
        or 0
    )
    evidence_field_detail_required_count = (
        _optional_count(
            evidence_field_detail_consistency.get(
                "required_evidence_present_count"
            )
        )
        or 0
    )
    evidence_field_detail_current_count = (
        _optional_count(
            evidence_field_detail_consistency.get(
                "current_evidence_present_count"
            )
        )
        or 0
    )
    evidence_field_detail_all_count = (
        _optional_count(
            evidence_field_detail_consistency.get(
                "all_evidence_fields_present_count"
            )
        )
        or 0
    )
    evidence_field_detail_blocker_matched_count = (
        _optional_count(
            evidence_field_detail_consistency.get("blocker_count_matched_count")
        )
        or 0
    )
    evidence_field_detail_missing_matched_count = (
        _optional_count(
            evidence_field_detail_consistency.get(
                "missing_artifact_present_count_matched_count"
            )
        )
        or 0
    )
    evidence_field_detail_required_matched_count = (
        _optional_count(
            evidence_field_detail_consistency.get(
                "required_evidence_present_count_matched_count"
            )
        )
        or 0
    )
    evidence_field_detail_current_matched_count = (
        _optional_count(
            evidence_field_detail_consistency.get(
                "current_evidence_present_count_matched_count"
            )
        )
        or 0
    )
    evidence_field_detail_all_matched_count = (
        _optional_count(
            evidence_field_detail_consistency.get(
                "all_evidence_fields_present_count_matched_count"
            )
        )
        or 0
    )
    evidence_field_detail_mismatched_count = (
        _optional_count(
            evidence_field_detail_consistency.get("mismatched_summary_row_count")
        )
        or 0
    )
    evidence_field_detail_matched = bool(
        evidence_field_detail_consistency.get("matched", False)
    )
    missing_artifacts = sorted(
        {
            str(blocker.get("missing_artifact"))
            for blocker in report.get("final_completion_blockers", [])
            if isinstance(blocker, Mapping) and blocker.get("missing_artifact")
        }
    )
    open_evidence = []
    retained_evidence = []
    completion_evidence_targets = []
    retained_evidence_kind_counts: dict[str, int] = {}
    for blocker in report.get("final_completion_blockers", []):
        if not isinstance(blocker, Mapping):
            continue
        label = (
            blocker.get("gate")
            or blocker.get("requirement")
            or blocker.get("notation")
            or blocker.get("code")
        )
        target_filenames = _completion_evidence_artifact_filename_values(blocker)
        if label and target_filenames:
            completion_evidence_targets.append(
                f"{label}{{files={','.join(target_filenames)}}}"
            )
        for evidence in blocker.get("retained_evidence", []):
            if not isinstance(evidence, Mapping):
                continue
            evidence_id = evidence.get("evidence_id")
            evidence_kind = evidence.get("evidence_kind")
            claim_scope = evidence.get("claim_scope")
            if not (label and evidence_id and evidence_kind and claim_scope):
                continue
            evidence_kind_text = str(evidence_kind)
            retained_evidence_kind_counts[evidence_kind_text] = (
                retained_evidence_kind_counts.get(evidence_kind_text, 0) + 1
            )
            retained_evidence.append(
                f"{label}{{"
                f"evidence_id={evidence_id}; "
                f"kind={evidence_kind}; "
                f"claim_scope={claim_scope}; "
                "completion_claimed="
                f"{_note_field_value(evidence.get('completion_claimed'))}"
                "}"
            )
        missing_artifact = blocker.get("missing_artifact")
        required_evidence = blocker.get("required_evidence")
        current_evidence = blocker.get("current_evidence")
        if not (
            label
            and missing_artifact
            and required_evidence
            and current_evidence
        ):
            continue
        open_evidence.append(
            f"{label}{{"
            f"missing_artifact={missing_artifact}; "
            f"required={required_evidence}; "
            f"current={current_evidence}"
            "}"
        )
    note = (
        "validation_pack="
        f"fixtures={registered_count}/{fixture_count}; "
        f"unsigned={unsigned_count}; "
        f"open_non_diagram={open_non_diagram}; "
        f"final_blockers={final_blockers}; "
        f"blocker_signature={final_blocker_signature}; "
        f"final_ready={final_ready}"
    )
    if missing_artifacts:
        note += "; missing_artifacts=" + ",".join(missing_artifacts)
    if open_evidence:
        note += "; open_evidence=" + "|".join(open_evidence)
    if completion_evidence_targets:
        note += (
            "; completion_evidence_targets="
            + "|".join(completion_evidence_targets)
        )
    if fixture_source_url_shape:
        note += (
            "; fixture_source_urls="
            f"rows={fixture_source_url_rows}; "
            f"required={fixture_source_url_required}; "
            f"http_or_https={fixture_source_url_http}; "
            f"requirement_satisfied={fixture_source_url_satisfied}; "
            f"schemes={fixture_source_url_scheme_total}; "
            f"domains={fixture_source_url_domain_total}; "
            f"matched={_note_field_value(fixture_source_url_matched)}"
        )
    if fixture_known_limitations:
        note += (
            "; fixture_known_limitations="
            f"rows={fixture_known_limitations_rows}; "
            f"available={fixture_known_limitations_available}; "
            f"unavailable={fixture_known_limitations_unavailable}; "
            f"notes={fixture_known_limitations_note_count}; "
            f"requirement_satisfied={fixture_known_limitations_satisfied}; "
            f"matched={_note_field_value(fixture_known_limitations_matched)}"
        )
    if retained_evidence:
        note += "; retained_evidence=" + "|".join(retained_evidence)
    if retained_evidence_kind_counts:
        note += (
            "; retained_evidence_kinds="
            + _mapping_count_note_signature(retained_evidence_kind_counts)
        )
    if retained_evidence_count:
        note += (
            "; retained_evidence_consistency="
            f"entries={retained_evidence_count}; "
            f"ids={retained_evidence_id_count}; "
            f"completion_claimed={retained_evidence_claimed_count}; "
            f"all_non_claimed={_note_field_value(retained_evidence_all_non_claimed)}"
        )
    if retained_non_claim_consistency:
        note += (
            "; retained_evidence_non_claim="
            f"entries={retained_non_claim_entry_count}; "
            f"ids={retained_non_claim_id_count}; "
            f"completion={retained_non_claim_completion_count}; "
            f"release_speedup={retained_non_claim_release_count}; "
            f"real_backend={retained_non_claim_real_backend_count}; "
            f"screenshot={retained_non_claim_screenshot_count}; "
            f"matched={_note_field_value(retained_non_claim_matched)}"
        )
    if retained_artifact_file_consistency:
        note += (
            "; retained_evidence_artifact_files="
            f"entries={retained_artifact_entry_count}; "
            f"artifact_entries={retained_artifact_evidence_count}; "
            f"non_artifact={retained_non_artifact_evidence_count}; "
            f"refs={retained_artifact_file_ref_count}; "
            f"unique={retained_artifact_unique_file_count}; "
            f"raw={retained_artifact_raw_file_count}; "
            f"analysis={retained_artifact_analysis_file_count}; "
            f"host={retained_artifact_host_file_count}; "
            f"complete_groups={retained_artifact_complete_group_count}; "
            f"incomplete_groups={retained_artifact_incomplete_group_count}; "
            f"refs_matched={_note_field_value(retained_artifact_refs_matched)}; "
            "file_types_matched="
            f"{_note_field_value(retained_artifact_file_types_matched)}; "
            f"groups_complete={_note_field_value(retained_artifact_groups_complete)}; "
            f"files_unique={_note_field_value(retained_artifact_files_unique)}; "
            f"matched={_note_field_value(retained_artifact_file_matched)}"
        )
    if required_check_consistency:
        note += (
            "; required_check_consistency="
            f"required={required_check_count}; "
            f"passed={required_check_passed_count}; "
            f"failed={required_check_failed_count}; "
            f"mismatched={required_check_mismatched_count}; "
            "final_ready_matched="
            f"{_note_field_value(required_check_final_ready_matched)}; "
            f"all_matched={_note_field_value(required_check_all_matched)}; "
            f"matched={_note_field_value(required_check_matched)}"
        )
    if required_fixture_metadata_consistency:
        note += (
            "; required_fixture_metadata_consistency="
            f"required={required_fixture_metadata_required_count}; "
            f"registered={required_fixture_metadata_registered_count}; "
            f"missing={required_fixture_metadata_missing_count}; "
            f"metadata_complete={required_fixture_metadata_complete_count}; "
            f"metadata_incomplete={required_fixture_metadata_incomplete_count}; "
            f"blockers={required_fixture_metadata_blocker_count}; "
            "gate_passed="
            f"{_note_field_value(required_fixture_metadata_gate_passed)}; "
            f"matched={_note_field_value(required_fixture_metadata_matched)}"
        )
    if signed_fixture_consistency:
        note += (
            "; signed_fixture_consistency="
            f"blockers={signed_fixture_blocker_count}; "
            f"final_blockers={signed_fixture_final_blocker_count}; "
            f"source_urls={signed_fixture_source_url_count}; "
            f"unsigned_non_claims={signed_fixture_unsigned_count}; "
            f"source_table_metadata={signed_fixture_source_table_count}; "
            "source_candidate_evidence="
            f"{signed_fixture_source_candidate_evidence_count}; "
            "source_candidates_not_unique="
            f"{signed_fixture_source_candidate_not_unique_count}; "
            "source_candidate_replays_valid="
            f"{signed_fixture_source_candidate_replay_valid_count}; "
            "source_candidate_matches="
            f"{signed_fixture_source_candidate_matching_total}; "
            "source_candidate_unique_signs="
            f"{signed_fixture_source_candidate_unique_sign_total}; "
            f"mismatched={signed_fixture_mismatched_count}; "
            f"matched={_note_field_value(signed_fixture_matched)}"
        )
    if non_diagram_consistency:
        note += (
            "; non_diagram_requirement_consistency="
            f"requirements={non_diagram_requirement_count}; "
            f"open={non_diagram_open_count}; "
            f"blockers={non_diagram_blocker_count}; "
            f"evidence_refs={non_diagram_retained_count}; "
            f"evidence_ids={non_diagram_retained_id_count}; "
            f"missing_artifacts_matched={non_diagram_missing_matched_count}; "
            f"evidence_fields_matched={non_diagram_evidence_matched_count}; "
            "refs_top_level_matched="
            f"{_note_field_value(non_diagram_retained_refs_top_level_matched)}; "
            "ids_top_level_matched="
            f"{_note_field_value(non_diagram_retained_ids_top_level_matched)}; "
            f"mismatched={non_diagram_mismatched_count}; "
            f"matched={_note_field_value(non_diagram_matched)}"
        )
    if code_consistency:
        note += (
            "; blocker_code_consistency="
            f"codes={code_consistency_code_count}; "
            f"total={code_consistency_code_total}; "
            f"total_matched={_note_field_value(code_consistency_total_matched)}; "
            f"unique_matched={_note_field_value(code_consistency_unique_matched)}; "
            "signature_matched="
            f"{_note_field_value(code_consistency_signature_matched)}; "
            f"all_have_code={_note_field_value(code_consistency_all_have_code)}; "
            f"matched={_note_field_value(code_consistency_matched)}"
        )
    if code_detail_consistency:
        note += (
            "; blocker_code_summary_detail="
            f"rows={blocker_code_detail_rows}; "
            f"codes={blocker_code_detail_codes}; "
            f"blockers={blocker_code_detail_blockers}; "
            f"kinds={blocker_code_detail_kind_refs}; "
            f"labels={blocker_code_detail_label_refs}; "
            f"missing_refs={blocker_code_detail_missing_refs}; "
            f"unique_missing={blocker_code_detail_unique_missing}; "
            f"count_matched={blocker_code_detail_count_matched}; "
            f"kinds_matched={blocker_code_detail_kinds_matched}; "
            f"labels_matched={blocker_code_detail_labels_matched}; "
            f"missing_artifacts_matched={blocker_code_detail_missing_matched}; "
            f"mismatched={blocker_code_detail_mismatched}; "
            f"matched={_note_field_value(blocker_code_detail_matched)}"
        )
    if kind_consistency:
        note += (
            "; blocker_kind_consistency="
            f"kinds={blocker_kind_count}; "
            f"total={blocker_kind_summary_blockers}; "
            f"signed={blocker_kind_signed_count}; "
            f"non_diagram={blocker_kind_non_diagram_count}; "
            f"completion={blocker_kind_completion_count}; "
            f"rows={blocker_kind_summary_rows}; "
            f"total_matched={_note_field_value(blocker_kind_count_matched)}; "
            f"unique_matched={_note_field_value(blocker_kind_unique_matched)}; "
            f"all_have_kind={_note_field_value(blocker_kind_all_have_kind)}; "
            f"matched={_note_field_value(blocker_kind_matched)}"
        )
    if kind_detail_consistency:
        note += (
            "; blocker_kind_summary_detail="
            f"rows={blocker_kind_detail_rows}; "
            f"kinds={blocker_kind_detail_kinds}; "
            f"blockers={blocker_kind_detail_blockers}; "
            f"codes={blocker_kind_detail_code_refs}; "
            f"missing_refs={blocker_kind_detail_missing_refs}; "
            f"unique_missing={blocker_kind_detail_unique_missing}; "
            f"count_matched={blocker_kind_detail_count_matched}; "
            f"codes_matched={blocker_kind_detail_codes_matched}; "
            "missing_artifacts_matched="
            f"{blocker_kind_detail_missing_matched}; "
            f"mismatched={blocker_kind_detail_mismatched}; "
            f"matched={_note_field_value(blocker_kind_detail_matched)}"
        )
    if gate_summary_consistency:
        note += (
            "; open_gate_blocker_summary="
            f"failed_gates={gate_summary_failed_count}; "
            f"summary_gates={gate_summary_gate_count}; "
            f"blockers={gate_summary_blocker_count}; "
            f"summary_blockers={gate_summary_summary_blocker_count}; "
            f"gate_sets_matched={_note_field_value(gate_summary_gate_sets_matched)}; "
            "blocker_count_matched="
            f"{_note_field_value(gate_summary_blocker_count_matched)}; "
            f"all_blockers_have_gate={_note_field_value(gate_summary_all_have_gate)}"
        )
    if gate_summary_detail_consistency:
        note += (
            "; open_gate_blocker_summary_detail="
            f"gates={gate_summary_detail_gates}; "
            f"blockers={gate_summary_detail_blockers}; "
            f"codes={gate_summary_detail_code_refs}; "
            f"missing_refs={gate_summary_detail_missing_refs}; "
            f"unique_missing={gate_summary_detail_unique_missing}; "
            f"retained={gate_summary_detail_retained_refs}; "
            f"count_matched={gate_summary_detail_count_matched}; "
            f"codes_matched={gate_summary_detail_codes_matched}; "
            "missing_artifacts_matched="
            f"{gate_summary_detail_missing_matched}; "
            f"retained_matched={gate_summary_detail_retained_matched}; "
            f"mismatched={gate_summary_detail_mismatched}; "
            f"matched={_note_field_value(gate_summary_detail_matched)}"
        )
    if blocker_evidence_link_consistency:
        note += (
            "; blocker_evidence_links="
            f"linked={linked_blocker_count}; "
            f"unlinked={unlinked_blocker_count}; "
            f"evidence_refs={evidence_reference_count}; "
            "refs_matched="
            f"{_note_field_value(evidence_reference_matched)}; "
            f"ids_matched={_note_field_value(evidence_ids_matched)}; "
            f"non_claim_matched={_note_field_value(evidence_non_claim_matched)}; "
            f"labels={blocker_evidence_label_present_count}; "
            f"codes={blocker_evidence_code_present_count}; "
            f"missing={blocker_evidence_missing_present_count}; "
            f"required={blocker_evidence_required_present_count}; "
            f"current={blocker_evidence_current_present_count}; "
            f"matched={_note_field_value(evidence_link_matched)}"
        )
    if blocker_evidence_link_kind_detail_consistency:
        note += (
            "; blocker_evidence_link_kind_detail="
            f"rows={link_kind_detail_row_count}; "
            f"blockers={link_kind_detail_blocker_count}; "
            f"linked={link_kind_detail_linked_count}; "
            f"unlinked={link_kind_detail_unlinked_count}; "
            f"refs={link_kind_detail_reference_count}; "
            f"ids={link_kind_detail_id_count}; "
            f"non_claimed_links={link_kind_detail_non_claimed_count}; "
            f"blocker_matched={link_kind_detail_blocker_matched_count}; "
            f"linked_matched={link_kind_detail_linked_matched_count}; "
            f"unlinked_matched={link_kind_detail_unlinked_matched_count}; "
            f"refs_matched={link_kind_detail_reference_matched_count}; "
            f"ids_matched={link_kind_detail_ids_matched_count}; "
            f"non_claim_matched={link_kind_detail_non_claim_matched_count}; "
            f"mismatched={link_kind_detail_mismatched_count}; "
            f"matched={_note_field_value(link_kind_detail_matched)}"
        )
    if gate_blocker_consistency:
        note += (
            "; gate_blocker_consistency="
            f"checked={gate_blocker_checked_count}; "
            f"count_matched={gate_blocker_count_matched_count}; "
            f"codes_matched={gate_blocker_codes_matched_count}; "
            f"mismatched={gate_blocker_mismatched_count}; "
            f"matched={_note_field_value(gate_blocker_matched)}"
        )
    if non_claim_gate_consistency:
        note += (
            "; non_claim_gate_consistency="
            f"fields={non_claim_gate_count}; "
            f"false={non_claim_top_level_false_count}; "
            f"gates={non_claim_gate_failed_count}; "
            f"blockers={non_claim_blocker_count}; "
            f"missing_artifacts={non_claim_missing_artifact_matched_count}; "
            f"codes_matched={non_claim_code_matched_count}; "
            "missing_artifacts_matched_count="
            f"{non_claim_missing_artifact_matched_count}; "
            f"matched={_note_field_value(non_claim_gate_matched)}"
        )
    if completion_gate_evidence_consistency:
        note += (
            "; completion_gate_evidence_consistency="
            f"gates={completion_gate_evidence_gate_count}; "
            f"gate_checks={completion_gate_evidence_gate_check_count}; "
            f"blockers={completion_gate_evidence_blocker_count}; "
            f"failed={completion_gate_evidence_failed_count}; "
            f"false={completion_gate_evidence_false_count}; "
            f"codes={completion_gate_evidence_code_count}; "
            f"required={completion_gate_evidence_required_count}; "
            f"current={completion_gate_evidence_current_count}; "
            f"missing_artifacts={completion_gate_evidence_missing_count}; "
            f"missing_artifact_ids={completion_gate_evidence_missing_id_count}; "
            f"retained_evidence={completion_gate_evidence_retained_count}; "
            f"retained_evidence_ids={completion_gate_evidence_retained_id_count}; "
            "retained_evidence_matched="
            f"{completion_gate_evidence_retained_matched_count}; "
            f"mismatched={completion_gate_evidence_mismatched_count}; "
            f"matched={_note_field_value(completion_gate_evidence_matched)}"
        )
    if missing_artifact_consistency:
        note += (
            "; missing_artifact_summary="
            f"refs={missing_artifact_reference_count}; "
            f"unique={missing_artifact_unique_count}; "
            f"rows={missing_artifact_summary_row_count}; "
            "refs_matched="
            f"{_note_field_value(missing_artifact_references_matched)}; "
            f"rows_matched={_note_field_value(missing_artifact_rows_matched)}; "
            f"matched={_note_field_value(missing_artifact_summary_matched)}"
        )
    if missing_artifact_detail_consistency:
        note += (
            "; missing_artifact_summary_detail="
            f"rows={missing_artifact_detail_row_count}; "
            f"unique={missing_artifact_detail_unique_count}; "
            f"blockers={missing_artifact_detail_blocker_count}; "
            f"codes={missing_artifact_detail_code_count}; "
            f"labels={missing_artifact_detail_label_count}; "
            f"count_matched={missing_artifact_detail_count_matched_count}; "
            f"codes_matched={missing_artifact_detail_codes_matched_count}; "
            f"labels_matched={missing_artifact_detail_labels_matched_count}; "
            f"mismatched={missing_artifact_detail_mismatched_count}; "
            f"matched={_note_field_value(missing_artifact_detail_matched)}"
        )
    if evidence_field_consistency:
        note += (
            "; blocker_evidence_fields="
            f"summary_rows={evidence_field_summary_rows}; "
            f"missing_artifact={evidence_field_missing_count}; "
            f"required={evidence_field_required_count}; "
            f"current={evidence_field_current_count}; "
            f"all_present={evidence_field_all_count}; "
            f"matched={_note_field_value(evidence_field_matched)}"
        )
    if evidence_field_detail_consistency:
        note += (
            "; blocker_evidence_field_summary_detail="
            f"rows={evidence_field_detail_row_count}; "
            f"blockers={evidence_field_detail_blocker_count}; "
            f"missing_artifact={evidence_field_detail_missing_count}; "
            f"required={evidence_field_detail_required_count}; "
            f"current={evidence_field_detail_current_count}; "
            f"all_present={evidence_field_detail_all_count}; "
            f"count_matched={evidence_field_detail_blocker_matched_count}; "
            f"missing_matched={evidence_field_detail_missing_matched_count}; "
            f"required_matched={evidence_field_detail_required_matched_count}; "
            f"current_matched={evidence_field_detail_current_matched_count}; "
            f"all_present_matched={evidence_field_detail_all_matched_count}; "
            f"mismatched={evidence_field_detail_mismatched_count}; "
            f"matched={_note_field_value(evidence_field_detail_matched)}"
        )
    return _append_note(notes, note)


def _homfly_case_evidence_consistency_note(report: Mapping[str, Any]) -> str:
    consistency = report.get("case_evidence_consistency")
    if not isinstance(consistency, Mapping):
        return ""
    matched = _optional_bool(consistency.get("matched"))
    case_count = _optional_count(consistency.get("case_count")) or 0
    checked = _optional_count(consistency.get("checked_case_count")) or 0
    missing = _optional_count(consistency.get("missing_evidence_count")) or 0
    maturity_counts = _optional_bool(
        consistency.get("bounded_homfly_maturity_path_counts_matched")
    )
    maturity_distinct = _optional_bool(
        consistency.get("bounded_homfly_maturity_path_distinct_count_matched")
    )
    maturity_certified = _optional_bool(
        consistency.get("bounded_homfly_maturity_path_certified_count_matched")
    )
    mismatch_count = _optional_count(consistency.get("mismatch_count")) or 0
    return (
        "homfly_case_evidence_consistency="
        f"matched={matched}; "
        f"checked={checked}/{case_count}; "
        f"missing={missing}; "
        f"maturity_path_counts_matched={maturity_counts}; "
        f"maturity_path_distinct_matched={maturity_distinct}; "
        f"maturity_path_certified_matched={maturity_certified}; "
        f"mismatch_count={mismatch_count}"
    )


def _append_homfly_case_evidence_consistency_note(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    note = _homfly_case_evidence_consistency_note(report)
    if not note:
        return notes
    return _append_note(notes, note)


def _alexander_maturity_path_summary_consistency_fields(
    report: Mapping[str, Any],
) -> dict[str, int]:
    fields = {
        key: 0
        for key in _ALEXANDER_MATURITY_PATH_SUMMARY_CONSISTENCY_COUNT_KEYS
    }
    consistency = report.get("bounded_alexander_maturity_path_summary_consistency")
    if not isinstance(consistency, Mapping):
        return fields

    fields[
        "bounded_alexander_maturity_path_summary_consistency_available_count"
    ] = 1
    matched = _optional_bool(consistency.get("matched"))
    if matched is True:
        fields[
            "bounded_alexander_maturity_path_summary_consistency_matched_count"
        ] = 1
    elif matched is False:
        fields[
            "bounded_alexander_maturity_path_summary_consistency_mismatch_count"
        ] = 1

    for source_key, field_key in (
        ("record_count", "bounded_alexander_maturity_path_summary_consistency_record_count"),
        ("path_count_total", "bounded_alexander_maturity_path_summary_consistency_path_count_total"),
        ("reported_path_count_total", "bounded_alexander_maturity_path_summary_consistency_reported_path_count_total"),
        ("path_count_row_count", "bounded_alexander_maturity_path_summary_consistency_path_count_row_count"),
        ("certified_count", "bounded_alexander_maturity_path_summary_consistency_certified_count"),
        ("certified_path_count", "bounded_alexander_maturity_path_summary_consistency_certified_path_count"),
    ):
        fields[field_key] = _optional_count(consistency.get(source_key)) or 0
    return fields


def _analysis_alexander_maturity_path_summary_consistency_totals(
    summaries: Iterable[Mapping[str, Any]],
) -> dict[str, int]:
    return {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in summaries
        )
        for key in _ALEXANDER_MATURITY_PATH_SUMMARY_CONSISTENCY_COUNT_KEYS
    }


def _alexander_maturity_path_summary_consistency_note(
    report: Mapping[str, Any],
) -> str:
    consistency = report.get("bounded_alexander_maturity_path_summary_consistency")
    if not isinstance(consistency, Mapping):
        return ""
    matched = _optional_bool(consistency.get("matched"))
    record_count = _optional_count(consistency.get("record_count")) or 0
    path_total = _optional_count(consistency.get("path_count_total")) or 0
    reported_total = (
        _optional_count(consistency.get("reported_path_count_total")) or 0
    )
    certified = _optional_count(consistency.get("certified_count")) or 0
    certified_paths = _optional_count(consistency.get("certified_path_count")) or 0
    path_rows = _optional_count(consistency.get("path_count_row_count")) or 0
    return (
        "bounded_alexander_maturity_path_summary_consistency="
        f"matched={matched}; "
        f"path_total={path_total}/{record_count}; "
        f"reported_path_total={reported_total}/{record_count}; "
        f"path_rows={path_rows}; "
        f"certified={certified}/{certified_paths}"
    )


def _append_alexander_maturity_path_summary_consistency_note(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    note = _alexander_maturity_path_summary_consistency_note(report)
    if not note:
        return notes
    return _append_note(notes, note)


def _source_notation_summary_count(report: Mapping[str, Any]) -> int:
    summary = report.get("source_notation_summary")
    if isinstance(summary, (list, tuple)):
        return sum(1 for row in summary if isinstance(row, Mapping))
    notations = report.get("source_notations")
    if isinstance(notations, (list, tuple)):
        return sum(1 for item in notations if item not in (None, ""))
    return 0


def _set_payload_maturity_path_distinct_counts(
    counts: dict[str, int],
    *,
    prefix: str,
) -> None:
    for base_key, bucket_fields in (
        (
            "bounded_homfly_maturity_path_distinct_count",
            set(_HOMFLY_MATURITY_PATH_COUNT_FIELD_BY_PATH.values()),
        ),
        (
            "bounded_alexander_maturity_path_distinct_count",
            set(_ALEXANDER_MATURITY_PATH_COUNT_FIELD_BY_PATH.values()),
        ),
    ):
        counts[f"{prefix}_{base_key}"] = sum(
            1
            for field in bucket_fields
            if (_optional_count(counts.get(f"{prefix}_{field}")) or 0) > 0
        )

def _bounded_homfly_maturity_path_count_fields(
    report: Mapping[str, Any],
) -> dict[str, int]:
    counts = {key: 0 for key in _HOMFLY_MATURITY_PATH_COUNT_KEYS}
    raw_counts = report.get("bounded_homfly_maturity_path_counts")
    if isinstance(raw_counts, (list, tuple)):
        distinct_paths: set[str] = set()
        certified_from_paths = 0
        for row in raw_counts:
            if not isinstance(row, Mapping):
                continue
            path_value = row.get("bounded_homfly_maturity_path")
            if path_value in (None, ""):
                continue
            path = str(path_value)
            count = (
                _optional_count(row.get("fixture_count"))
                or _optional_count(row.get("case_count"))
                or _optional_count(row.get("input_count"))
                or _optional_count(row.get("count"))
                or 0
            )
            if count <= 0:
                continue
            distinct_paths.add(path)
            field = _HOMFLY_MATURITY_PATH_COUNT_FIELD_BY_PATH.get(path)
            if field is not None:
                counts[field] += count
            if path in _HOMFLY_MATURITY_PATH_CERTIFIED_VALUES:
                certified_from_paths += count
        distinct = _optional_count(
            report.get("bounded_homfly_maturity_path_distinct_count")
        )
        certified = _optional_count(
            report.get("bounded_homfly_maturity_path_certified_count")
        )
        counts["bounded_homfly_maturity_path_distinct_count"] = (
            distinct if distinct is not None else len(distinct_paths)
        )
        counts["bounded_homfly_maturity_path_certified_count"] = (
            certified if certified is not None else certified_from_paths
        )
        return counts

    path_value = report.get("bounded_homfly_maturity_path")
    if path_value not in (None, ""):
        path = str(path_value)
        field = _HOMFLY_MATURITY_PATH_COUNT_FIELD_BY_PATH.get(path)
        if field is not None:
            counts[field] = 1
        counts["bounded_homfly_maturity_path_distinct_count"] = 1
        certified = report.get("bounded_homfly_maturity_path_certified")
        if isinstance(certified, bool):
            counts["bounded_homfly_maturity_path_certified_count"] = (
                1 if certified else 0
            )
        elif path in _HOMFLY_MATURITY_PATH_CERTIFIED_VALUES:
            counts["bounded_homfly_maturity_path_certified_count"] = 1
        return counts

    for key in (
        "bounded_homfly_maturity_path_certified_count",
        "bounded_homfly_maturity_path_distinct_count",
    ):
        value = _optional_count(report.get(key))
        if value is not None:
            counts[key] = value
    return counts


def _bounded_homfly_maturity_path_note(
    report: Mapping[str, Any],
) -> str | None:
    raw_counts = report.get("bounded_homfly_maturity_path_counts")
    if isinstance(raw_counts, (list, tuple)):
        entries: list[str] = []
        for row in raw_counts:
            if not isinstance(row, Mapping):
                continue
            path_value = row.get("bounded_homfly_maturity_path")
            if path_value in (None, ""):
                continue
            count = (
                _optional_count(row.get("fixture_count"))
                or _optional_count(row.get("case_count"))
                or _optional_count(row.get("input_count"))
                or _optional_count(row.get("count"))
                or 0
            )
            if count <= 0:
                continue
            entries.append(f"{path_value}:{count}")
        if entries:
            certified = _optional_count(
                report.get("bounded_homfly_maturity_path_certified_count")
            )
            distinct = _optional_count(
                report.get("bounded_homfly_maturity_path_distinct_count")
            )
            parts = ["bounded_homfly_maturity_paths=" + ",".join(entries)]
            if certified is not None:
                parts.append(f"bounded_homfly_maturity_certified={certified}")
            if distinct is not None:
                parts.append(f"bounded_homfly_maturity_distinct={distinct}")
            return "; ".join(parts)

    path_value = report.get("bounded_homfly_maturity_path")
    if path_value in (None, ""):
        return None
    path = str(path_value)
    certified = report.get("bounded_homfly_maturity_path_certified")
    if isinstance(certified, bool):
        return (
            f"bounded_homfly_maturity_path={path}; "
            f"bounded_homfly_maturity_certified={certified}"
        )
    return f"bounded_homfly_maturity_path={path}"


def _append_bounded_homfly_maturity_path_note(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    note = _bounded_homfly_maturity_path_note(report)
    if note is None:
        return notes
    return _append_note(notes, note)


def _bounded_alexander_maturity_path_count_rows(
    report: Mapping[str, Any],
) -> list[dict[str, int | str]]:
    raw_counts = report.get("bounded_alexander_maturity_path_counts")
    if isinstance(raw_counts, (list, tuple)):
        rows: list[dict[str, int | str]] = []
        for row in raw_counts:
            if not isinstance(row, Mapping):
                continue
            path_value = row.get("bounded_alexander_maturity_path")
            if path_value in (None, ""):
                continue
            count = (
                _optional_count(row.get("fixture_count"))
                or _optional_count(row.get("case_count"))
                or _optional_count(row.get("input_count"))
                or _optional_count(row.get("count"))
                or 0
            )
            if count <= 0:
                continue
            rows.append(
                {
                    "bounded_alexander_maturity_path": str(path_value),
                    "count": count,
                }
            )
        return rows

    cases = report.get("cases")
    if not isinstance(cases, (list, tuple)):
        return []
    counts: dict[str, int] = {}
    for case in cases:
        if not isinstance(case, Mapping):
            continue
        path_value = case.get("bounded_alexander_maturity_path")
        if path_value in (None, ""):
            continue
        path = str(path_value)
        counts[path] = counts.get(path, 0) + 1
    return [
        {"bounded_alexander_maturity_path": path, "count": counts[path]}
        for path in sorted(counts)
    ]


def _bounded_alexander_maturity_path_count_fields(
    report: Mapping[str, Any],
) -> dict[str, int]:
    counts = {key: 0 for key in _ALEXANDER_MATURITY_PATH_COUNT_KEYS}
    row_counts = _bounded_alexander_maturity_path_count_rows(report)
    if row_counts:
        distinct_paths: set[str] = set()
        certified_from_paths = 0
        for row in row_counts:
            path = str(row["bounded_alexander_maturity_path"])
            count = int(row["count"])
            distinct_paths.add(path)
            field = _ALEXANDER_MATURITY_PATH_COUNT_FIELD_BY_PATH.get(path)
            if field is not None:
                counts[field] += count
            if path in _ALEXANDER_MATURITY_PATH_CERTIFIED_VALUES:
                certified_from_paths += count
        distinct = _optional_count(
            report.get("bounded_alexander_maturity_path_distinct_count")
        )
        certified = _optional_count(
            report.get("bounded_alexander_maturity_path_certified_count")
        )
        counts["bounded_alexander_maturity_path_distinct_count"] = (
            distinct if distinct is not None else len(distinct_paths)
        )
        counts["bounded_alexander_maturity_path_certified_count"] = (
            certified if certified is not None else certified_from_paths
        )
        return counts

    path_value = report.get("bounded_alexander_maturity_path")
    if path_value not in (None, ""):
        path = str(path_value)
        field = _ALEXANDER_MATURITY_PATH_COUNT_FIELD_BY_PATH.get(path)
        if field is not None:
            counts[field] = 1
        counts["bounded_alexander_maturity_path_distinct_count"] = 1
        certified = report.get("bounded_alexander_maturity_path_certified")
        if isinstance(certified, bool):
            counts["bounded_alexander_maturity_path_certified_count"] = (
                1 if certified else 0
            )
        elif path in _ALEXANDER_MATURITY_PATH_CERTIFIED_VALUES:
            counts["bounded_alexander_maturity_path_certified_count"] = 1
        return counts

    for key in (
        "bounded_alexander_maturity_path_certified_count",
        "bounded_alexander_maturity_path_distinct_count",
    ):
        value = _optional_count(report.get(key))
        if value is not None:
            counts[key] = value
    return counts


def _bounded_alexander_maturity_path_note(
    report: Mapping[str, Any],
) -> str | None:
    rows = _bounded_alexander_maturity_path_count_rows(report)
    if rows:
        entries = [
            f"{row['bounded_alexander_maturity_path']}:{row['count']}"
            for row in rows
        ]
        certified = _optional_count(
            report.get("bounded_alexander_maturity_path_certified_count")
        )
        distinct = _optional_count(
            report.get("bounded_alexander_maturity_path_distinct_count")
        )
        parts = ["bounded_alexander_maturity_paths=" + ",".join(entries)]
        if certified is not None:
            parts.append(f"bounded_alexander_maturity_certified={certified}")
        if distinct is not None:
            parts.append(f"bounded_alexander_maturity_distinct={distinct}")
        return "; ".join(parts)

    path_value = report.get("bounded_alexander_maturity_path")
    if path_value in (None, ""):
        return None
    path = str(path_value)
    certified = report.get("bounded_alexander_maturity_path_certified")
    if isinstance(certified, bool):
        return (
            f"bounded_alexander_maturity_path={path}; "
            f"bounded_alexander_maturity_certified={certified}"
        )
    return f"bounded_alexander_maturity_path={path}"


def _append_bounded_alexander_maturity_path_note(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    note = _bounded_alexander_maturity_path_note(report)
    if note is None:
        return notes
    return _append_note(notes, note)


def _analysis_generated_coverage_totals(
    summaries: Iterable[Mapping[str, Any]],
) -> dict[str, int]:
    rows = list(summaries)
    totals = {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0 for summary in rows
        )
        for key in _ANALYSIS_GENERATED_COVERAGE_KEYS
        if key not in {"generated_branch_depth", "generated_max_branch_depth"}
    }
    totals["analysis_generated_max_branch_depth"] = max(
        (
            max(
                _optional_count(summary.get("generated_branch_depth")) or 0,
                _optional_count(summary.get("generated_max_branch_depth")) or 0,
            )
            for summary in rows
        ),
        default=0,
    )
    return totals


def _analysis_blocker_summary_totals(
    summaries: Iterable[Mapping[str, Any]],
) -> dict[str, int]:
    rows = list(summaries)
    if not any(_has_blocker_summary_input(summary) for summary in rows):
        return {}
    return {
        f"analysis_{key}": sum(
            _optional_count(summary.get(key)) or 0
            for summary in rows
        )
        for key in _BLOCKER_SUMMARY_KEYS
    }


def _analysis_generated_source_summary_consistency_totals(
    summaries: Iterable[Mapping[str, Any]],
) -> dict[str, bool | None]:
    rows = list(summaries)
    totals: dict[str, bool | None] = {}
    for summary_key, _ in _GENERATED_SOURCE_SUMMARY_CONSISTENCY_FIELDS:
        values = [
            summary.get(summary_key)
            for summary in rows
            if summary.get(summary_key) is not None
        ]
        totals[f"analysis_{summary_key}"] = (
            all(value is True for value in values) if values else None
        )
    return totals


def _append_source_table_audit_notes(report: Mapping[str, Any], notes: str) -> str:
    notation = str(report.get("notation", ""))
    source = str(report.get("source", ""))
    source_url = str(report.get("source_url", ""))
    matched = report.get("matched_source_table_invariants")
    if isinstance(matched, list):
        matched_text = ",".join(str(item) for item in matched) if matched else "none"
    else:
        matched_text = "none"
    required, passed, failed = _source_table_audit_check_counts(report)
    note = (
        f"source-table audit {notation}; source={source}; "
        f"matched={matched_text}; checks={passed}/{required}; failed={failed}"
    )
    detail_note = _source_table_audit_unmatched_note(report)
    if detail_note:
        note += f"; {detail_note}"
    source_match_note = _source_table_audit_source_match_note(report)
    if source_match_note:
        note += f"; {source_match_note}"
    alexander_skipped_attempt_note = (
        _source_table_alexander_skipped_common_gcd_attempt_note(report)
    )
    if alexander_skipped_attempt_note:
        note += f"; {alexander_skipped_attempt_note}"
    alexander_source_divisibility_note = (
        _source_table_alexander_source_divisibility_note(report)
    )
    if alexander_source_divisibility_note:
        note += f"; {alexander_source_divisibility_note}"
    homfly_variant_note = _source_table_audit_homfly_variant_note(report)
    if homfly_variant_note:
        note += f"; {homfly_variant_note}"
    convergence_note = _source_table_candidate_convergence_note(report)
    if convergence_note:
        note += f"; {convergence_note}"
    top_candidate_note = _source_table_audit_top_candidate_note(report)
    if top_candidate_note:
        note += f"; {top_candidate_note}"
    registration_blocker_note = _source_table_audit_registration_blocker_note(report)
    if registration_blocker_note:
        note += f"; {registration_blocker_note}"
    if source_url:
        note += f"; source_url={source_url}"
    return _append_note(notes, note)


def _append_homfly_small_coverage_notes(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    coverage_counts = {
        "generated_cases": _optional_count(report.get("case_count")),
        "non_fixture_cases": _optional_count(report.get("non_fixture_case_count")),
        "branch_depth": _optional_count(report.get("branch_depth")),
        "max_generated_branch_depth": _optional_count(
            report.get("max_generated_branch_depth")
        ),
        "unique_diagrams": _optional_count(report.get("unique_diagram_count")),
        "unique_oriented_diagrams": _optional_count(
            report.get("unique_oriented_diagram_count")
        ),
        "frontier_cases": _optional_count(report.get("frontier_case_count")),
        "unique_evaluations": _optional_count(report.get("unique_evaluation_count")),
        "reused_evaluations": _optional_count(report.get("reused_evaluation_count")),
    }
    if any(value is not None for value in coverage_counts.values()):
        notes = _append_note(
            notes,
            "; ".join(
                f"{key}={value or 0}"
                for key, value in coverage_counts.items()
            ),
        )
    branch_depth_counts = _coverage_count_note_value(
        report.get("branch_depth_counts"),
        "branch_depth",
    )
    if branch_depth_counts:
        notes = _append_note(notes, f"branch_depth_counts={branch_depth_counts}")
    frontier_reason_counts = _frontier_reason_count_note_value(
        report.get("frontier_reason_counts")
    )
    if frontier_reason_counts:
        notes = _append_note(
            notes,
            f"frontier_reason_counts={frontier_reason_counts}",
        )
    frontier_branch_depth_counts = _coverage_count_note_value(
        report.get("frontier_branch_depth_counts"),
        "branch_depth",
    )
    if frontier_branch_depth_counts:
        notes = _append_note(
            notes,
            f"frontier_branch_depth_counts={frontier_branch_depth_counts}",
        )
    truncated_branch_depth_counts = _coverage_count_note_value(
        report.get("truncated_branch_depth_counts"),
        "branch_depth",
    )
    if truncated_branch_depth_counts:
        notes = _append_note(
            notes,
            f"truncated_branch_depth_counts={truncated_branch_depth_counts}",
        )
    for note_key, field_name in (
        ("source_kind_counts", "source_kind"),
        ("frontier_source_kind_counts", "source_kind"),
        ("truncated_source_kind_counts", "source_kind"),
        ("branch_counts", "branch"),
        ("frontier_branch_counts", "branch"),
        ("truncated_branch_counts", "branch"),
    ):
        count_text = _coverage_string_count_note_value(
            report.get(note_key),
            field_name,
        )
        if count_text:
            notes = _append_note(notes, f"{note_key}={count_text}")
    notes = _append_source_notation_coverage_notes(
        report,
        notes,
        case_note_key="source_notation_certified_cases",
        passed_key="certified_case_count",
        extra_note_keys=(
            ("source_notation_unique_diagrams", "unique_diagram_count"),
            (
                "source_notation_unique_oriented_diagrams",
                "unique_oriented_diagram_count",
            ),
        ),
    )
    consistency_note = _homfly_source_notation_summary_consistency_note(report)
    if consistency_note:
        notes = _append_note(notes, consistency_note)
    normalization_note = _homfly_fixture_normalization_metadata_note(report)
    if normalization_note:
        notes = _append_note(notes, normalization_note)

    notes = _append_homfly_solved_depth_notes(report, notes)
    multiplicity = report.get("diagram_multiplicity_summary")
    multiplicity_mapping = multiplicity if isinstance(multiplicity, Mapping) else {}
    variant_count = _optional_count(report.get("polynomial_variant_diagram_count"))
    max_polynomial_count = _optional_count(
        report.get("max_homfly_polynomial_count_per_diagram")
    )
    conflict_count = _optional_count(report.get("oriented_polynomial_conflict_count"))
    max_oriented_polynomial_count = _optional_count(
        report.get("max_homfly_polynomial_count_per_oriented_diagram")
    )
    if variant_count is None:
        variant_count = _optional_count(
            multiplicity_mapping.get("polynomial_variant_diagram_count")
        )
    if max_polynomial_count is None:
        max_polynomial_count = _optional_count(
            multiplicity_mapping.get("max_homfly_polynomial_count_per_diagram")
        )
    if conflict_count is None:
        conflict_count = _optional_count(
            multiplicity_mapping.get("oriented_polynomial_conflict_count")
        )
    if max_oriented_polynomial_count is None:
        max_oriented_polynomial_count = _optional_count(
            multiplicity_mapping.get(
                "max_homfly_polynomial_count_per_oriented_diagram"
            )
        )
    if (
        variant_count is None
        and max_polynomial_count is None
        and conflict_count is None
        and max_oriented_polynomial_count is None
    ):
        return notes
    return _append_note(
        notes,
        (
            f"canonical_polynomial_variant_diagrams={variant_count or 0}; "
            f"max_homfly_polynomials_per_diagram={max_polynomial_count or 0}; "
            f"oriented_polynomial_conflicts={conflict_count or 0}; "
            f"max_homfly_polynomials_per_oriented_diagram="
            f"{max_oriented_polynomial_count or 0}"
        ),
    )


def _homfly_source_notation_summary_consistency_note(
    report: Mapping[str, Any],
) -> str:
    consistency = report.get("source_notation_summary_consistency")
    if not isinstance(consistency, Mapping):
        return ""
    parts: list[str] = []
    for key in (
        "matched",
        "count_totals_matched",
        "distribution_totals_matched",
        "frontier_reason_counts_matched",
        "source_notation_count_matches_fixture_count",
    ):
        value = consistency.get(key)
        if isinstance(value, bool):
            parts.append(f"{key}={value}")
    mismatch_count = _optional_count(consistency.get("mismatch_count"))
    if mismatch_count is not None:
        parts.append(f"mismatch_count={mismatch_count}")
    first_mismatch = consistency.get("first_mismatch")
    if isinstance(first_mismatch, Mapping):
        kind = first_mismatch.get("kind")
        field = first_mismatch.get("field")
        if kind not in (None, "") and field not in (None, ""):
            parts.append(f"first_mismatch={kind}:{field}")
        tags = first_mismatch.get("tags")
        if isinstance(tags, Sequence) and not isinstance(tags, (str, bytes)):
            tag_values = [str(tag) for tag in tags if str(tag)]
            if tag_values:
                parts.append("first_mismatch_tags=" + ",".join(tag_values))
    if not parts:
        return ""
    return "source_notation_summary_consistency=" + "; ".join(parts)


def _homfly_fixture_normalization_metadata_note(report: Mapping[str, Any]) -> str:
    metadata = report.get("fixture_normalization_metadata")
    if not isinstance(metadata, Mapping):
        return ""
    row_count = _optional_count(metadata.get("metadata_row_count")) or 0
    expected_source_count = (
        _optional_count(metadata.get("expected_homfly_source_count")) or 0
    )
    source_url_count = _optional_count(metadata.get("source_url_count")) or 0
    full_table_count = (
        _optional_count(metadata.get("full_table_normalization_certified_count"))
        or 0
    )
    arbitrary_count = (
        _optional_count(metadata.get("arbitrary_diagram_coverage_certified_count"))
        or 0
    )
    consistency = report.get("fixture_normalization_metadata_consistency")
    matched = (
        consistency.get("matched")
        if isinstance(consistency, Mapping)
        and isinstance(consistency.get("matched"), bool)
        else None
    )
    parts = [
        f"rows={row_count}",
        f"expected_sources={expected_source_count}",
        f"source_urls={source_url_count}",
        f"full_table_certified={full_table_count}",
        f"arbitrary_diagram_certified={arbitrary_count}",
    ]
    if matched is not None:
        parts.append(f"metadata_consistency_matched={matched}")
    if isinstance(consistency, Mapping):
        mismatch_count = _optional_count(consistency.get("mismatch_count"))
        if mismatch_count is not None:
            parts.append(f"metadata_mismatch_count={mismatch_count}")
        first_mismatch = consistency.get("first_mismatch")
        if isinstance(first_mismatch, Mapping):
            kind = first_mismatch.get("kind")
            field = first_mismatch.get("field")
            if kind not in (None, "") and field not in (None, ""):
                parts.append(f"metadata_first_mismatch={kind}:{field}")
            source_notation = first_mismatch.get("source_notation")
            if source_notation not in (None, ""):
                parts.append(
                    "metadata_first_mismatch_source="
                    f"{_note_field_value(source_notation)}"
                )
    return "fixture_normalization_metadata=" + "; ".join(parts)


def _append_homfly_solved_depth_notes(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    top_level_counts = _solved_depth_count_note_value(
        report.get("solved_depth_counts")
    )
    if top_level_counts:
        notes = _append_note(notes, f"solved_depth_counts={top_level_counts}")

    summary = report.get("source_notation_summary")
    if not isinstance(summary, (list, tuple)):
        return notes
    source_values: list[str] = []
    for row in summary:
        if not isinstance(row, Mapping):
            continue
        notation = row.get("source_notation")
        if notation in (None, ""):
            continue
        counts = _solved_depth_count_note_value(row.get("solved_depth_counts"))
        if counts:
            source_values.append(f"{notation}[{counts.replace(',', '|')}]")
    if source_values:
        notes = _append_note(
            notes,
            f"source_notation_solved_depth_counts={','.join(source_values)}",
        )
    return notes


def _solved_depth_count_note_value(value: object) -> str:
    return _coverage_count_note_value(value, "solved_depth")


def _coverage_string_count_note_value(value: object, key_field: str) -> str:
    if not isinstance(value, (list, tuple)):
        return ""
    pairs: list[str] = []
    for row in value:
        if not isinstance(row, Mapping):
            continue
        key_value = row.get(key_field)
        count = _optional_count(row.get("case_count"))
        if key_value in (None, "") or count is None:
            continue
        pairs.append(f"{key_value}:{count}")
    return ",".join(pairs)

def _coverage_count_note_value(value: object, count_key: str) -> str:
    if not isinstance(value, (list, tuple)):
        return ""
    pairs: list[str] = []
    for row in value:
        if not isinstance(row, Mapping):
            continue
        depth = _optional_count(row.get(count_key))
        count = _optional_count(row.get("case_count"))
        if depth is None or count is None:
            continue
        pairs.append(f"{depth}:{count}")
    return ",".join(pairs)


def _frontier_reason_count_note_value(value: object) -> str:
    if not isinstance(value, (list, tuple)):
        return ""
    pairs: list[str] = []
    for row in value:
        if not isinstance(row, Mapping):
            continue
        reason = row.get("frontier_reason")
        case_count = _optional_count(row.get("case_count"))
        frontier_count = _optional_count(row.get("frontier_count"))
        if reason in (None, "") or case_count is None or frontier_count is None:
            continue
        pairs.append(f"{reason}:{case_count}/{frontier_count}")
    return ",".join(pairs)


def _append_alexander_signed_pd_coverage_notes(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    coverage_counts = {
        "generated_cases": _optional_count(report.get("case_count")),
        "non_fixture_cases": _optional_count(report.get("non_fixture_case_count")),
        "branch_depth": _optional_count(report.get("branch_depth")),
        "max_generated_branch_depth": _optional_count(
            report.get("max_generated_branch_depth")
        ),
        "unique_diagrams": _optional_count(report.get("unique_diagram_count")),
        "unique_oriented_diagrams": _optional_count(
            report.get("unique_oriented_diagram_count")
        ),
        "nonzero_evaluated_cases": _optional_count(
            report.get("nonzero_evaluated_case_count")
        ),
        "nonzero_unique_evaluations": _optional_count(
            report.get("nonzero_unique_evaluation_count")
        ),
        "nonzero_reused_evaluations": _optional_count(
            report.get("nonzero_reused_evaluation_count")
        ),
        "zero_crossing_unlink_cases": _optional_count(
            report.get("zero_crossing_unlink_certified_case_count")
        ),
        "scanned_minors": _optional_count(report.get("scanned_minor_count")),
        "expected_minor_combinations": _optional_count(
            report.get("expected_combination_count")
        ),
        "nonzero_minors": _optional_count(report.get("nonzero_minor_count")),
        "zero_minors": _optional_count(report.get("zero_minor_count")),
        "unit_minors": _optional_count(report.get("unit_minor_count")),
        "unique_nonzero_minor_polynomials": _optional_count(
            report.get("unique_nonzero_polynomial_count")
        ),
        "all_rows_nonzero_minor_cases": _optional_count(
            report.get("all_rows_have_nonzero_minor_case_count")
        ),
        "all_columns_nonzero_minor_cases": _optional_count(
            report.get("all_columns_have_nonzero_minor_case_count")
        ),
        "failed_nonzero_minors": _optional_count(
            report.get("failed_nonzero_minor_count")
        ),
    }
    if any(value is not None for value in coverage_counts.values()):
        notes = _append_note(
            notes,
            "; ".join(
                f"{key}={value or 0}"
                for key, value in coverage_counts.items()
            ),
        )
    cache_evidence = report.get("nonzero_evaluation_cache_evidence")
    if isinstance(cache_evidence, Mapping):
        notes = _append_note(
            notes,
            (
                "nonzero_evaluation_cache="
                f"accounted={cache_evidence.get('nonzero_evaluation_accounting_complete') is True}; "
                f"reuse_observed={cache_evidence.get('nonzero_cache_reuse_observed') is True}; "
                f"accounted_cases={_optional_count(cache_evidence.get('accounted_case_count')) or 0}/"
                f"{_optional_count(cache_evidence.get('case_count')) or 0}"
            ),
        )
        notes = _append_note(
            notes,
            (
                "nonzero_evaluation_source_accounting="
                f"totals_match_report={cache_evidence.get('source_cache_totals_match_report') is True}; "
                f"case_accounting_complete={cache_evidence.get('source_case_accounting_complete') is True}; "
                f"evaluated_skips={_optional_count(cache_evidence.get('nonzero_evaluated_result_skipped_case_count')) or 0}; "
                f"unevaluated_skips={_optional_count(cache_evidence.get('unevaluated_skipped_case_count')) or 0}"
            ),
        )
    consistency_note = _alexander_source_notation_summary_consistency_note(report)
    if consistency_note:
        notes = _append_note(notes, consistency_note)
    return _append_source_notation_coverage_notes(
        report,
        notes,
        case_note_key="source_notation_accepted_cases",
        passed_key="accepted_case_count",
        extra_note_keys=(
            ("source_notation_scanned_minors", "scanned_minor_count"),
            (
                "source_notation_zero_crossing_unlinks",
                "zero_crossing_unlink_certified_case_count",
            ),
        ),
    )


def _alexander_source_notation_summary_consistency_note(
    report: Mapping[str, Any],
) -> str:
    consistency = report.get("source_notation_summary_consistency")
    if not isinstance(consistency, Mapping):
        return ""
    parts: list[str] = []
    for key in (
        "matched",
        "count_totals_matched",
        "source_notation_count_matches_fixture_count",
    ):
        value = consistency.get(key)
        if isinstance(value, bool):
            parts.append(f"{key}={value}")
    mismatch_count = _optional_count(consistency.get("mismatch_count"))
    if mismatch_count is not None:
        parts.append(f"mismatch_count={mismatch_count}")
    first_mismatch = consistency.get("first_mismatch")
    if isinstance(first_mismatch, Mapping):
        kind = first_mismatch.get("kind")
        field = first_mismatch.get("field")
        if kind not in (None, "") and field not in (None, ""):
            parts.append(f"first_mismatch={kind}:{field}")
        tags = first_mismatch.get("tags")
        if isinstance(tags, Sequence) and not isinstance(tags, (str, bytes)):
            tag_values = [str(tag) for tag in tags if str(tag)]
            if tag_values:
                parts.append("first_mismatch_tags=" + ",".join(tag_values))
    if not parts:
        return ""
    return "source_notation_summary_consistency=" + "; ".join(parts)


def _append_source_notation_coverage_notes(
    report: Mapping[str, Any],
    notes: str,
    *,
    case_note_key: str,
    passed_key: str,
    extra_note_keys: tuple[tuple[str, str], ...],
) -> str:
    summary = report.get("source_notation_summary")
    if not isinstance(summary, (list, tuple)):
        return notes
    rows = [row for row in summary if isinstance(row, Mapping)]
    case_values: list[str] = []
    for row in rows:
        notation = row.get("source_notation")
        case_count = _optional_count(row.get("case_count"))
        passed_count = _optional_count(row.get(passed_key))
        if notation in (None, "") or case_count is None:
            continue
        case_values.append(f"{notation}:{passed_count or 0}/{case_count}")
    if case_values:
        notes = _append_note(notes, f"{case_note_key}={','.join(case_values)}")

    for note_key, field in extra_note_keys:
        values: list[str] = []
        for row in rows:
            notation = row.get("source_notation")
            count = _optional_count(row.get(field))
            if notation in (None, "") or count is None:
                continue
            values.append(f"{notation}:{count}")
        if values:
            notes = _append_note(notes, f"{note_key}={','.join(values)}")
    return notes


def _source_table_audit_homfly_variant_note(report: Mapping[str, Any]) -> str:
    comparisons = report.get("comparisons")
    if not isinstance(comparisons, Mapping):
        return ""
    homfly = comparisons.get("homfly")
    if not isinstance(homfly, Mapping):
        return ""
    status = _source_table_homfly_variant_resolution_status_from_comparison(homfly)
    note_parts = [f"homfly_variant_status={status}"] if status else []
    computed = _optional_count(homfly.get("computed_candidate_count")) or 0
    if computed <= 0:
        return "; ".join(note_parts)
    variant_count = _optional_count(homfly.get("source_value_variant_count")) or 0
    if variant_count <= 0:
        return "; ".join(note_parts)
    seen_count = _optional_count(homfly.get("source_value_seen_variant_count")) or 0
    note = f"homfly_variants_seen={seen_count}/{variant_count}"
    unit_variant_count = (
        _optional_count(homfly.get("source_value_unit_normalized_variant_count")) or 0
    )
    if unit_variant_count > 0:
        unit_seen_count = (
            _optional_count(
                homfly.get("source_value_seen_unit_normalized_variant_count")
            )
            or 0
        )
        note += (
            f"; homfly_unit_normalized_variants_seen="
            f"{unit_seen_count}/{unit_variant_count}"
        )
    note_parts.append(note)
    variant_miss_summary = homfly.get("source_value_variant_miss_witness_summary")
    if isinstance(variant_miss_summary, Mapping):
        witness_count = (
            _optional_count(variant_miss_summary.get("variant_miss_witness_count"))
            or 0
        )
        witness_limit = (
            _optional_count(variant_miss_summary.get("variant_miss_witness_limit"))
            or 0
        )
        if witness_count > 0:
            note_parts.append(
                f"homfly_variant_miss_witnesses={witness_count}/{witness_limit}"
            )
            first_witness = variant_miss_summary.get("first_variant_miss_witness")
            if isinstance(first_witness, Mapping):
                variant_name = str(first_witness.get("variant_name") or "")
                if variant_name:
                    note_parts.append(f"first_homfly_variant_miss={variant_name}")
    return "; ".join(note_parts)


def _source_table_audit_source_match_note(report: Mapping[str, Any]) -> str:
    statuses = _source_table_audit_source_match_status_rows(report)
    if not statuses:
        return ""
    return "source_match_statuses=" + ",".join(statuses)


def _source_table_audit_source_match_status_rows(
    report: Mapping[str, Any] | None,
) -> list[str]:
    if not isinstance(report, Mapping):
        return []
    comparisons = report.get("comparisons")
    if not isinstance(comparisons, Mapping):
        return []
    statuses: list[str] = []
    for name, comparison in comparisons.items():
        if not isinstance(comparison, Mapping):
            continue
        if comparison.get("source_value_present") is not True:
            continue
        status = _source_table_source_match_resolution_status_from_comparison(
            comparison
        )
        if not status:
            continue
        statuses.append(f"{name}:{status}")
    return statuses


def _source_table_candidate_convergence_note(report: Mapping[str, Any]) -> str:
    summary = report.get("source_table_candidate_convergence_summary")
    if not isinstance(summary, Mapping):
        return ""
    source_seen_count = _optional_count(
        report.get("source_table_candidate_convergence_source_value_seen_invariant_count")
    )
    if source_seen_count is None:
        source_seen_count = _optional_count(
            summary.get("source_value_seen_invariant_count")
        )
    source_seen_uncertified_count = _optional_count(
        report.get(
            "source_table_candidate_convergence_source_value_seen_but_uncertified_invariant_count"
        )
    )
    if source_seen_uncertified_count is None:
        source_seen_uncertified_count = _optional_count(
            summary.get("source_value_seen_but_uncertified_invariant_count")
        )
    if source_seen_count is None and source_seen_uncertified_count is None:
        return ""
    return (
        f"source_seen={source_seen_count or 0}; "
        f"source_seen_uncertified={source_seen_uncertified_count or 0}"
    )


def _source_table_audit_top_candidate_note(report: Mapping[str, Any]) -> str:
    summary = report.get("candidate_source_table_match_summary")
    if not isinstance(summary, Mapping):
        return ""
    top_count = _optional_count(summary.get("top_candidate_count"))
    unique_sign_count = _optional_count(
        summary.get("top_candidate_unique_sign_pattern_count")
    )
    compatible_unique_sign_count = _optional_count(
        summary.get("computed_source_compatible_unique_sign_pattern_count")
    )
    complete_unique_sign_count = _optional_count(
        summary.get("complete_source_compatible_unique_sign_pattern_count")
    )
    max_matched_count = _optional_count(summary.get("max_matched_candidate_count"))
    max_matched_unique_sign_count = _optional_count(
        summary.get("max_matched_candidate_unique_sign_pattern_count")
    )
    max_matched_total_count = _optional_count(
        summary.get("max_matched_candidate_total_count")
    )
    max_matched_total_unique_sign_count = _optional_count(
        summary.get("max_matched_candidate_total_unique_sign_pattern_count")
    )
    if (
        top_count is None
        and unique_sign_count is None
        and compatible_unique_sign_count is None
        and complete_unique_sign_count is None
        and max_matched_count is None
        and max_matched_unique_sign_count is None
        and max_matched_total_count is None
        and max_matched_total_unique_sign_count is None
    ):
        return ""
    return (
        f"top_candidates={top_count or 0}; "
        f"top_unique_sign_patterns={unique_sign_count or 0}; "
        f"compatible_unique_sign_patterns={compatible_unique_sign_count or 0}; "
        f"complete_unique_sign_patterns={complete_unique_sign_count or 0}; "
        f"max_matched_candidates={max_matched_count or 0}; "
        f"max_matched_unique_sign_patterns={max_matched_unique_sign_count or 0}; "
        f"max_matched_total_candidates={max_matched_total_count or 0}; "
        f"max_matched_total_unique_sign_patterns={max_matched_total_unique_sign_count or 0}"
    )


def _source_table_audit_registration_blocker_note(report: Mapping[str, Any]) -> str:
    blockers = _source_table_audit_registration_blockers(report)
    ready_value = report.get("source_table_registration_ready")
    ready = ready_value if isinstance(ready_value, bool) else len(blockers) == 0
    blocker_text = ",".join(blockers) if blockers else "none"
    return (
        f"registration_ready={str(ready).lower()}; "
        f"registration_blockers={blocker_text}"
    )


def _source_table_audit_registration_blocker_fields(
    report: Mapping[str, Any],
) -> dict[str, int | str]:
    rows = _source_table_audit_registration_blocker_count_rows(report)
    blockers = [row["blocker"] for row in rows]
    return {
        "source_table_audit_registration_blockers": ",".join(blockers),
        "source_table_audit_registration_blocker_code_count": len(blockers),
        "source_table_audit_registration_blocker_count_signature": ",".join(
            f"{row['blocker']}:{row['count']}" for row in rows
        ),
    }


def _source_table_audit_registration_summary_consistency_note(
    report: Mapping[str, Any],
) -> str:
    fields = _source_table_audit_registration_summary_consistency_fields(report)
    if (
        fields[
            "source_table_audit_registration_summary_consistency_available_count"
        ]
        <= 0
    ):
        return ""
    note = (
        "registration_summary_consistency="
        f"{fields['source_table_audit_registration_summary_consistency_status']}; "
        "registration_summary_mismatches="
        f"{fields['source_table_audit_registration_summary_consistency_mismatch_count']}"
    )
    first_mismatch = fields[
        "source_table_audit_registration_summary_consistency_first_mismatch"
    ]
    if first_mismatch:
        note += f"; registration_summary_first_mismatch={first_mismatch}"
    return note


def _source_table_audit_registration_blocker_count_rows(
    report: Mapping[str, Any],
) -> list[dict[str, int | str]]:
    if report.get("method") not in {
        "diagram_fixture_source_table_invariant_audit",
        "homfly_fixture_acceptance_report",
        "multivariable_alexander_fixture_acceptance_report",
    } and not any(
        key in report
        for key in (
            "source_table_registration_blockers",
            "source_table_registration_blocker_counts",
            "source_table_registration_blocker_count",
        )
    ):
        return []
    counts: dict[str, int] = {}
    order: list[str] = []
    raw_counts = report.get("source_table_registration_blocker_counts")
    if isinstance(raw_counts, (list, tuple)):
        for row in raw_counts:
            if not isinstance(row, Mapping):
                continue
            blocker = row.get("blocker")
            if blocker in (None, ""):
                blocker = row.get("blocker_code")
            if blocker in (None, ""):
                blocker = row.get("code")
            if blocker in (None, ""):
                continue
            blocker_key = str(blocker)
            count = (
                _optional_count(row.get("fixture_count"))
                or _optional_count(row.get("count"))
                or _optional_count(row.get("blocker_count"))
                or 0
            )
            if blocker_key not in counts:
                order.append(blocker_key)
                counts[blocker_key] = 0
            counts[blocker_key] += count
    if not order:
        for blocker in _source_table_audit_registration_blockers(report):
            if blocker not in counts:
                order.append(blocker)
                counts[blocker] = 0
            counts[blocker] += 1
    return [
        {"blocker": blocker, "count": counts[blocker]}
        for blocker in order
    ]


def _append_source_table_registration_acceptance_note(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    checked = _optional_count(report.get("source_table_registration_checked_count"))
    if checked is None or checked <= 0:
        return notes
    ready = _optional_count(report.get("source_table_registration_ready_count")) or 0
    blocked = (
        _optional_count(report.get("source_table_registration_blocked_count")) or 0
    )
    blockers = (
        _optional_count(report.get("source_table_registration_blocker_count")) or 0
    )
    blocker_note = _source_table_audit_registration_blocker_note(report)
    consistency_note = _source_table_audit_registration_summary_consistency_note(
        report
    )
    extra = f"; {consistency_note}" if consistency_note else ""
    return _append_note(
        notes,
        (
            f"source_table_registration=checked={checked}; "
            f"ready={ready}; blocked={blocked}; blockers={blockers}; "
            f"{blocker_note}{extra}"
        ),
    )


def _source_table_audit_registration_blockers(report: Mapping[str, Any]) -> list[str]:
    raw_blockers = report.get("source_table_registration_blockers")
    if isinstance(raw_blockers, (list, tuple)):
        return [str(blocker) for blocker in raw_blockers if blocker not in (None, "")]

    blockers: list[str] = []
    if report.get("has_signed_pd") is False:
        blockers.append("fixture_signs_not_registered")
    if report.get("registered_fixture_invariant_claim") is not True:
        blockers.append("registered_fixture_invariant_claim_disabled")
    if report.get("complete_candidate_set") is False:
        blockers.append("candidate_set_incomplete")
    if _source_table_audit_invariant_gap_present(
        report,
        "uncomputed_source_table_invariants",
        "uncomputed_source_table_invariant_count",
    ):
        blockers.append("source_table_values_uncomputed")
    if _source_table_audit_invariant_gap_present(
        report,
        "mismatched_source_table_invariants",
        "mismatched_source_table_invariant_count",
    ):
        blockers.append("source_table_values_mismatched")
    if _source_table_audit_invariant_gap_present(
        report,
        "unstable_source_table_invariants",
        "unstable_source_table_invariant_count",
    ):
        blockers.append("source_table_values_unstable")

    complete_unique = _optional_count(
        report.get("source_table_complete_source_compatible_unique_sign_pattern_count")
    )
    if complete_unique is None:
        summary = report.get("candidate_source_table_match_summary")
        if isinstance(summary, Mapping):
            complete_unique = _optional_count(
                summary.get("complete_source_compatible_unique_sign_pattern_count")
            )
    if complete_unique is not None and complete_unique != 1:
        blockers.append("source_compatible_sign_pattern_not_unique")
    return blockers


def _source_table_audit_invariant_gap_present(
    report: Mapping[str, Any],
    list_field: str,
    count_field: str,
) -> bool:
    raw_list = report.get(list_field)
    if isinstance(raw_list, (list, tuple)):
        return len(raw_list) > 0
    count = _optional_count(report.get(count_field))
    return count is not None and count > 0


def _source_table_audit_unmatched_note(report: Mapping[str, Any]) -> str:
    comparisons = report.get("comparisons")
    if not isinstance(comparisons, Mapping):
        return ""
    mismatched: list[str] = []
    unstable: list[str] = []
    uncomputed: list[str] = []
    for name, comparison in comparisons.items():
        if not isinstance(comparison, Mapping):
            continue
        if comparison.get("source_value_present") is not True:
            continue
        if comparison.get("complete_candidate_source_match") is True:
            continue
        label = str(name)
        computed = _optional_count(comparison.get("computed_candidate_count")) or 0
        missing = _optional_count(comparison.get("missing_candidate_count")) or 0
        skipped = _optional_count(comparison.get("skipped_candidate_count")) or 0
        if computed == 0 or missing > 0 or skipped > 0:
            uncomputed.append(label)
        elif comparison.get("source_value_seen") is False:
            mismatched.append(label)
        else:
            unstable.append(label)

    parts = []
    if mismatched:
        parts.append("mismatched=" + ",".join(mismatched))
    if unstable:
        parts.append("unstable=" + ",".join(unstable))
    if uncomputed:
        parts.append("uncomputed=" + ",".join(uncomputed))
    return "; ".join(parts)


def _acceptance_check_counts(report: Mapping[str, Any]) -> tuple[int, int, int]:
    explicit = (
        _optional_count(report.get("required_check_count")),
        _optional_count(report.get("passed_check_count")),
        _optional_count(report.get("failed_check_count")),
    )
    if all(value is not None for value in explicit):
        required = int(explicit[0])
        passed = min(int(explicit[1]), required)
        failed = min(int(explicit[2]), required - passed)
        return required, passed, failed

    if report.get("method") == "homfly_small_diagram_coverage_report":
        required = _optional_count(report.get("case_count")) or 0
        passed = min(_optional_count(report.get("certified_case_count")) or 0, required)
        failed = _optional_count(report.get("uncertified_case_count"))
        if failed is None:
            failed = max(0, required - passed)
        return required, passed, max(0, min(failed, required - passed))

    if report.get("method") == "multivariable_alexander_signed_pd_coverage_report":
        required = _optional_count(report.get("case_count")) or 0
        passed = min(_optional_count(report.get("accepted_case_count")) or 0, required)
        failed = _optional_count(report.get("uncertified_case_count"))
        if failed is None:
            failed = max(0, required - passed)
        return required, passed, max(0, min(failed, required - passed))

    if report.get("method") == "signed_pd_role_order_candidates_report":
        required = _optional_count(report.get("strict_candidate_count")) or 0
        if required == 0:
            required = max(1, _optional_count(report.get("candidate_count")) or 0)
        passed = 1 if report.get("status") == "unique" else 0
        return required, min(passed, required), max(0, required - min(passed, required))

    if report.get("method") == "diagram_fixture_source_table_invariant_audit":
        return _source_table_audit_check_counts(report)

    required = 0
    passed = 0
    for checked_key, matched_key in _CHECK_COUNT_PAIRS:
        checked = _optional_count(report.get(checked_key))
        matched = _optional_count(report.get(matched_key))
        if checked is None or matched is None:
            continue
        required += checked
        passed += min(matched, checked)

    failed = max(0, required - passed)
    fixture_count = _optional_count(report.get("fixture_count"))
    accepted_count = _optional_count(report.get("accepted_count"))
    if fixture_count is not None and accepted_count is not None:
        row_gap = max(0, fixture_count - min(accepted_count, fixture_count))
        if row_gap > failed:
            required += row_gap - failed
            failed = row_gap

    if required == 0:
        required = 1
        passed = 1 if report.get("accepted") is True else 0
        failed = required - passed
    return required, min(passed, required), max(0, required - min(passed, required))


def _acceptance_certification_counts(
    report: Mapping[str, Any],
) -> tuple[str, int, int, int]:
    if report.get("method") == "homfly_small_diagram_coverage_report":
        return _bounded_certification_tuple(
            report.get("claim_scope", "generated_small_signed_pd_frontier_exhaustion"),
            _optional_count(report.get("case_count")),
            _optional_count(report.get("certified_case_count")),
            _optional_count(report.get("uncertified_case_count")),
        )

    if report.get("method") == "multivariable_alexander_signed_pd_coverage_report":
        return _bounded_certification_tuple(
            report.get(
                "claim_scope",
                "generated_small_signed_pd_wirtinger_fox_scanned_gcd_coverage",
            ),
            _optional_count(report.get("case_count")),
            _optional_count(report.get("accepted_case_count")),
            _optional_count(report.get("uncertified_case_count")),
        )

    if report.get("method") == "signed_pd_role_order_candidates_report":
        applicable = _optional_count(report.get("strict_candidate_count")) or 0
        if applicable == 0:
            applicable = max(1, _optional_count(report.get("candidate_count")) or 0)
        certified = 1 if report.get("status") == "unique" else 0
        return _bounded_certification_tuple(
            _analysis_claim_scope(report),
            applicable,
            certified,
            max(0, applicable - certified),
        )

    if report.get("method") == "diagram_fixture_source_table_invariant_audit":
        required, passed, failed = _source_table_audit_check_counts(report)
        return _bounded_certification_tuple(
            _analysis_claim_scope(report),
            required,
            passed,
            failed,
        )

    homfly_scope = report.get("input_certification_scope")
    if homfly_scope is not None:
        applicable = _optional_count(report.get("input_certification_applicable_count"))
        certified = _optional_count(report.get("certified_input_count"))
        uncertified = _optional_count(report.get("uncertified_input_count"))
        return _bounded_certification_tuple(
            homfly_scope,
            applicable,
            certified,
            uncertified,
        )

    alexander_scope = report.get("bounded_certification_scope")
    if alexander_scope is not None:
        applicable = _optional_count(
            report.get("bounded_scanned_gcd_certification_applicable_count")
        )
        certified = _optional_count(
            report.get("bounded_scanned_gcd_certified_count")
        )
        uncertified = _optional_count(
            report.get("bounded_scanned_gcd_uncertified_count")
        )
        return _bounded_certification_tuple(
            alexander_scope,
            applicable,
            certified,
            uncertified,
        )

    return "", 0, 0, 0


def _acceptance_certification_evidence_counts(
    report: Mapping[str, Any],
) -> dict[str, int]:
    counts = {
        key: _optional_count(report.get(key)) or 0
        for key in _ANALYSIS_CERTIFICATION_EVIDENCE_KEYS
    }
    if report.get("method") == "homfly_small_diagram_coverage_report":
        counts["input_certification_frontier_count"] = _optional_count(
            report.get("frontier_count")
        ) or 0
        counts["input_certification_frontier_reason_count"] = _optional_count(
            report.get("frontier_reason_count")
        ) or 0
        counts["input_certification_truncated_count"] = _optional_count(
            report.get("truncated_case_count")
        ) or 0
        counts["input_certification_iterative_attempt_count"] = _optional_count(
            report.get("attempt_count")
        ) or 0
        counts["input_certification_iterative_solved_count"] = _optional_count(
            report.get("certified_case_count")
        ) or 0
        counts["input_certification_iterative_max_solved_depth"] = _optional_count(
            report.get("max_solved_depth")
        ) or 0
    if report.get("method") == "multivariable_alexander_signed_pd_coverage_report":
        counts["input_certification_zero_crossing_count"] = _optional_count(
            report.get("zero_crossing_unlink_certified_case_count")
        ) or 0
        counts["bounded_scanned_gcd_checked_nonzero_minor_count"] = _optional_count(
            report.get("checked_nonzero_minor_count")
        ) or 0
        counts["bounded_scanned_gcd_failed_nonzero_minor_count"] = _optional_count(
            report.get("failed_nonzero_minor_count")
        ) or 0
        counts["bounded_scanned_gcd_scanned_minor_count"] = _optional_count(
            report.get("scanned_minor_count")
        ) or 0
        counts["bounded_scanned_gcd_expected_minor_combination_count"] = (
            _optional_count(report.get("expected_combination_count")) or 0
        )
        counts["bounded_scanned_gcd_nonzero_minor_count"] = (
            _optional_count(report.get("nonzero_minor_count")) or 0
        )
        counts["bounded_scanned_gcd_zero_minor_count"] = (
            _optional_count(report.get("zero_minor_count")) or 0
        )
        counts["bounded_scanned_gcd_unit_minor_count"] = (
            _optional_count(report.get("unit_minor_count")) or 0
        )
        counts["bounded_scanned_gcd_unique_nonzero_polynomial_count"] = (
            _optional_count(report.get("unique_nonzero_polynomial_count")) or 0
        )
        counts["bounded_scanned_gcd_all_rows_have_nonzero_minor_count"] = (
            _optional_count(report.get("all_rows_have_nonzero_minor_case_count"))
            or 0
        )
        counts["bounded_scanned_gcd_all_columns_have_nonzero_minor_count"] = (
            _optional_count(report.get("all_columns_have_nonzero_minor_case_count"))
            or 0
        )
        counts["bounded_scanned_gcd_complete_scan_count"] = _optional_count(
            report.get("complete_scan_case_count")
        ) or 0
        counts["bounded_scanned_gcd_nonzero_minor_coverage_complete_count"] = (
            _optional_count(report.get("nonzero_minor_coverage_complete_case_count"))
            or 0
        )
        counts["bounded_scanned_gcd_truncated_count"] = _optional_count(
            report.get("truncated_case_count")
        ) or 0
        counts["bounded_scanned_gcd_quotient_gcd_certified_count"] = (
            _optional_count(report.get("bounded_scanned_gcd_certified_case_count"))
            or 0
        )
        counts["bounded_scanned_gcd_complete_certified_count"] = (
            _optional_count(report.get("complete_scanned_gcd_certified_case_count"))
            or 0
        )
        counts["wirtinger_fox_scanned_minor_count"] = _optional_count(
            report.get("scanned_minor_count")
        ) or 0
        counts["wirtinger_fox_invalid_minor_reference_count"] = _optional_count(
            report.get("invalid_minor_reference_count")
        ) or 0
        counts["wirtinger_fox_invalid_normalization_count"] = _optional_count(
            report.get("invalid_normalization_count")
        ) or 0
        counts["wirtinger_fox_complete_scan_count"] = _optional_count(
            report.get("complete_scan_case_count")
        ) or 0
        counts["wirtinger_fox_truncated_count"] = _optional_count(
            report.get("truncated_case_count")
        ) or 0
    if report.get("method") == "multivariable_alexander_fixture_acceptance_report":
        counts.update(_source_table_alexander_numerator_counts(report))
    counts.update(_admissible_minor_normalization_counts(report))
    counts.update(_source_table_alexander_skipped_common_gcd_attempt_counts(report))
    counts.update(_source_table_alexander_source_divisibility_counts(report))
    counts.update(_bounded_homfly_maturity_path_count_fields(report))
    counts.update(_bounded_alexander_maturity_path_count_fields(report))
    counts.update(_compact_host_evidence_counts(report))
    return counts


def _source_table_audit_check_counts(report: Mapping[str, Any]) -> tuple[int, int, int]:
    comparisons = report.get("comparisons")
    if not isinstance(comparisons, Mapping):
        return 1, 0, 1
    required = 0
    passed = 0
    for comparison in comparisons.values():
        if not isinstance(comparison, Mapping):
            continue
        if comparison.get("source_value_present") is not True:
            continue
        required += 1
        if comparison.get("complete_candidate_source_match") is True:
            passed += 1
    if required == 0:
        return 1, 0, 1
    return required, passed, max(0, required - passed)


def _bounded_certification_tuple(
    scope: Any,
    applicable: int | None,
    certified: int | None,
    uncertified: int | None,
) -> tuple[str, int, int, int]:
    safe_applicable = applicable if applicable is not None else 0
    safe_certified = min(certified if certified is not None else 0, safe_applicable)
    if uncertified is None:
        safe_uncertified = safe_applicable - safe_certified
    else:
        safe_uncertified = min(uncertified, safe_applicable - safe_certified)
    return (
        str(scope),
        safe_applicable,
        safe_certified,
        max(0, safe_uncertified),
    )


def _fixture_row_check_counts(row: Mapping[str, Any]) -> tuple[int, int, int]:
    explicit = (
        _optional_count(row.get("required_check_count")),
        _optional_count(row.get("passed_check_count")),
        _optional_count(row.get("failed_check_count")),
    )
    if all(value is not None for value in explicit):
        required = int(explicit[0])
        passed = min(int(explicit[1]), required)
        failed = min(int(explicit[2]), required - passed)
        return required, passed, failed

    required = 1
    passed = 1 if row.get("comparison_matched") is True else 0
    audit_keys = (
        ("mirror_applicable", "mirror_matched"),
        ("skein_applicable", "skein_matched"),
        ("minor_divisibility_audit_applicable", "minor_divisibility_audit_matched"),
        ("scanned_gcd_audit_applicable", "scanned_gcd_audit_matched"),
    )
    for applicable_key, matched_key in audit_keys:
        if row.get(applicable_key) is True:
            required += 1
            if row.get(matched_key) is True:
                passed += 1
    if row.get("accepted") is False and required == passed:
        required += 1
    failed = max(0, required - passed)
    return required, min(passed, required), failed


def _optional_count(value: Any) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    return max(0, value)


def _optional_bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    return None


def _mapping_or_empty(value: Any) -> Mapping[str, Any]:
    if isinstance(value, Mapping):
        return value
    return {}


def _iter_mappings(value: Any) -> Iterator[Mapping[str, Any]]:
    if isinstance(value, (list, tuple)):
        for item in value:
            if isinstance(item, Mapping):
                yield item


def _completion_evidence_artifact_filename_values(
    row: Mapping[str, Any],
) -> list[str]:
    values = row.get("completion_evidence_artifact_filenames")
    if not isinstance(values, (list, tuple)):
        return []
    return [str(value) for value in values if value not in (None, "")]


def _completion_evidence_artifact_filename_counts(value: Any) -> tuple[int, int]:
    filenames: list[str] = []
    for row in _iter_mappings(value):
        filenames.extend(_completion_evidence_artifact_filename_values(row))
    return len(filenames), len(set(filenames))


def _mapping_sequence_value_count_total(value: Mapping[str, Any]) -> int:
    return sum(
        len(items)
        for items in value.values()
        if isinstance(items, Sequence) and not isinstance(items, (str, bytes))
    )


def _mapping_sequence_note_signature(value: Mapping[str, Any]) -> str:
    parts: list[str] = []
    for key in sorted(value, key=str):
        items = value[key]
        if not isinstance(items, Sequence) or isinstance(items, (str, bytes)):
            continue
        item_text = ",".join(_note_field_value(item) for item in items)
        parts.append(f"{_note_field_value(key)}:{item_text}")
    return "|".join(parts)


def _mapping_count_note_signature(value: Mapping[str, Any]) -> str:
    parts: list[str] = []
    for key in sorted(value, key=str):
        count = _optional_count(value[key])
        if count is None:
            continue
        parts.append(f"{_note_field_value(key)}:{count}")
    return "|".join(parts)


def _sequence_note_signature(value: Sequence[Any]) -> str:
    parts: list[str] = []
    for item in value:
        if isinstance(item, Mapping):
            item = item.get("row") or item.get("path") or item
        parts.append(_note_field_value(item))
    return ",".join(parts) if parts else "none"


def _sequence_count(value: Any) -> int:
    if isinstance(value, Sequence) and not isinstance(
        value,
        (str, bytes, bytearray),
    ):
        return len(value)
    return 0


def _count_true(value: Any) -> int:
    return 1 if value is True else 0


def _count_from_first(*values: Any) -> int:
    for value in values:
        count = _optional_count(value)
        if count is not None:
            return count
    return 0


def _benchmark_result_status_counts(report: Mapping[str, Any]) -> dict[str, int]:
    counts = {"completed": 0, "skipped": 0, "failed": 0}
    results = report.get("results")
    if not isinstance(results, Sequence) or isinstance(
        results,
        (str, bytes, bytearray),
    ):
        return counts
    for row in results:
        if not isinstance(row, Mapping):
            continue
        status = str(row.get("status", ""))
        if status in counts:
            counts[status] += 1
    return counts


def _benchmark_matrix_analysis_counts(
    report: Mapping[str, Any],
    *,
    matrix_summary: Mapping[str, Any],
    speedup_evidence: Mapping[str, Any],
    release_gate: Mapping[str, Any],
    gpu_evidence: Mapping[str, Any],
) -> dict[str, int]:
    status_counts = _benchmark_result_status_counts(report)
    row_count = _count_from_first(
        matrix_summary.get("row_count"),
        sum(status_counts.values()),
    )
    expected = _count_from_first(
        matrix_summary.get("expected_row_count"),
        row_count,
    )
    completed = _count_from_first(
        matrix_summary.get("completed_count"),
        report.get("completed_count"),
        status_counts["completed"],
    )
    skipped = _count_from_first(
        matrix_summary.get("skipped_count"),
        report.get("skipped_count"),
        status_counts["skipped"],
    )
    failed = _count_from_first(
        matrix_summary.get("failed_count"),
        report.get("failed_count"),
        status_counts["failed"],
    )
    return {
        "benchmark_matrix_expected_row_count": expected,
        "benchmark_matrix_row_count": row_count,
        "benchmark_matrix_completed_row_count": completed,
        "benchmark_matrix_skipped_row_count": skipped,
        "benchmark_matrix_failed_row_count": failed,
        "benchmark_matrix_backend_count": _sequence_count(report.get("backends")),
        "benchmark_matrix_workload_count": _sequence_count(report.get("workloads")),
        "benchmark_speedup_candidate_count": _count_from_first(
            speedup_evidence.get("candidate_speedup_count"),
        ),
        "benchmark_speedup_threshold_candidate_count": _count_from_first(
            release_gate.get("threshold_candidate_count"),
        ),
        "benchmark_speedup_completed_comparison_count": _count_from_first(
            release_gate.get("completed_comparison_count"),
        ),
        "benchmark_speedup_missing_baseline_count": _count_from_first(
            release_gate.get("missing_baseline_count"),
        ),
        "benchmark_speedup_release_grade_claimed_count": _count_true(
            speedup_evidence.get("release_grade_speedup_claimed")
        ),
        "benchmark_cuda_gpu_requested_row_count": _count_from_first(
            gpu_evidence.get("gpu_requested_row_count"),
        ),
        "benchmark_cuda_gpu_completed_row_count": _count_from_first(
            gpu_evidence.get("gpu_completed_row_count"),
        ),
        "benchmark_cuda_gpu_skipped_row_count": _count_from_first(
            gpu_evidence.get("gpu_skipped_row_count"),
        ),
        "benchmark_cuda_gpu_failed_row_count": _count_from_first(
            gpu_evidence.get("gpu_failed_row_count"),
        ),
        "benchmark_cuda_gpu_threshold_candidate_count": _count_from_first(
            gpu_evidence.get("gpu_threshold_candidate_count"),
        ),
        "benchmark_cuda_gpu_blocking_reason_count": _count_from_first(
            gpu_evidence.get("blocking_reason_count"),
            _sequence_count(gpu_evidence.get("blocking_reasons")),
        ),
        "benchmark_cuda_gpu_runtime_observed_count": _count_true(
            gpu_evidence.get("cuda_runtime_observed")
        ),
        "benchmark_cuda_gpu_hosted_cuda_ci_claimed_count": _count_true(
            gpu_evidence.get("hosted_cuda_ci_claimed")
        ),
        "benchmark_cuda_gpu_parity_claimed_count": _count_true(
            gpu_evidence.get("cuda_parity_claimed")
        ),
        "benchmark_cuda_gpu_release_grade_speedup_claimed_count": _count_true(
            gpu_evidence.get("release_grade_gpu_speedup_claimed")
        ),
    }


def _comma_join_sequence(value: Any) -> str:
    if not isinstance(value, Sequence) or isinstance(
        value,
        (str, bytes, bytearray),
    ):
        return ""
    return ",".join(str(item) for item in value)


def _benchmark_matrix_analysis_notes(
    report: Mapping[str, Any],
    *,
    counts: Mapping[str, int],
    speedup_evidence: Mapping[str, Any],
    release_gate: Mapping[str, Any],
    gpu_evidence: Mapping[str, Any],
) -> str:
    notes = _notes_text(report)
    notes = _append_note(
        notes,
        (
            "benchmark_matrix_rows="
            f"expected={counts['benchmark_matrix_expected_row_count']},"
            f"row_count={counts['benchmark_matrix_row_count']},"
            f"completed={counts['benchmark_matrix_completed_row_count']},"
            f"skipped={counts['benchmark_matrix_skipped_row_count']},"
            f"failed={counts['benchmark_matrix_failed_row_count']}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "benchmark_matrix_shape="
            f"backends={_comma_join_sequence(report.get('backends'))},"
            f"workloads={_comma_join_sequence(report.get('workloads'))},"
            f"repeat={_note_field_value(report.get('repeat'))},"
            f"warmup={_note_field_value(report.get('warmup'))}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "speedup_gate="
            "release_grade_speedup_claimed="
            f"{_note_field_value(speedup_evidence.get('release_grade_speedup_claimed'))},"
            f"repeat_satisfied={_note_field_value(release_gate.get('repeat_satisfied'))},"
            "threshold_candidate_count="
            f"{counts['benchmark_speedup_threshold_candidate_count']},"
            "blocking_reasons="
            f"{_comma_join_sequence(release_gate.get('blocking_reasons'))}"
        ),
    )
    notes = _append_note(
        notes,
        (
            "cuda_gpu_benchmark_witness="
            f"gate_scope={_note_field_value(gpu_evidence.get('gate_scope'))},"
            "requested_rows="
            f"{counts['benchmark_cuda_gpu_requested_row_count']},"
            "completed_rows="
            f"{counts['benchmark_cuda_gpu_completed_row_count']},"
            "cuda_runtime_observed="
            f"{_note_field_value(gpu_evidence.get('cuda_runtime_observed'))},"
            "hosted_cuda_ci_claimed="
            f"{_note_field_value(gpu_evidence.get('hosted_cuda_ci_claimed'))},"
            "cuda_parity_claimed="
            f"{_note_field_value(gpu_evidence.get('cuda_parity_claimed'))},"
            "release_grade_gpu_speedup_claimed="
            f"{_note_field_value(gpu_evidence.get('release_grade_gpu_speedup_claimed'))},"
            "blocking_reasons="
            f"{_comma_join_sequence(gpu_evidence.get('blocking_reasons'))}"
        ),
    )
    return _append_note(
        notes,
        "benchmark matrix analysis rows are host-visible profiling evidence, not CUDA parity evidence or release-grade acceleration claims",
    )


def _has_blocker_summary_input(report: Mapping[str, Any] | None) -> bool:
    if not isinstance(report, Mapping):
        return False
    return any(
        count_key in report or blockers_key in report
        for count_key, blockers_key in _BLOCKER_SUMMARY_FIELDS
    )


def _has_nonzero_blocker_summary_input(report: Mapping[str, Any] | None) -> bool:
    if not isinstance(report, Mapping):
        return False
    for count_key, blockers_key in _BLOCKER_SUMMARY_FIELDS:
        count = _optional_count(report.get(count_key))
        if count is not None and count > 0:
            return True
        blockers = report.get(blockers_key)
        if (
            isinstance(blockers, Sequence)
            and not isinstance(blockers, (str, bytes))
            and any(str(blocker) for blocker in blockers)
        ):
            return True
    return False


def _blocker_summary_counts(report: Mapping[str, Any] | None) -> dict[str, int]:
    counts = {key: 0 for key in _BLOCKER_SUMMARY_KEYS}
    if not isinstance(report, Mapping):
        return counts
    for count_key, blockers_key in _BLOCKER_SUMMARY_FIELDS:
        value = _optional_count(report.get(count_key))
        blockers = report.get(blockers_key)
        if (
            value is None
            and isinstance(blockers, Sequence)
            and not isinstance(blockers, (str, bytes))
        ):
            value = sum(1 for blocker in blockers if str(blocker))
        counts[count_key] = value or 0
    return counts


def _mapping_sequence(value: Any) -> list[Mapping[str, Any]]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return []
    return [row for row in value if isinstance(row, Mapping)]


def _string_sequence(value: Any) -> list[str]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return []
    return [str(row) for row in value if row not in (None, "")]


def _homfly_blocker_detail_count(
    report: Mapping[str, Any],
    *,
    count_key: str,
    details_key: str,
) -> int:
    count = _optional_count(report.get(count_key))
    if count is not None:
        return count
    rows = _mapping_sequence(report.get(details_key))
    return len(rows)


def _homfly_blocker_detail_counts(report: Mapping[str, Any] | None) -> dict[str, int]:
    counts = {key: 0 for key in _HOMFLY_BLOCKER_DETAIL_KEYS}
    if not isinstance(report, Mapping):
        return counts
    for count_key, details_key in _HOMFLY_BLOCKER_DETAIL_FIELDS:
        counts[count_key] = _homfly_blocker_detail_count(
            report,
            count_key=count_key,
            details_key=details_key,
        )
    return counts


def _first_homfly_blocker_detail(
    report: Mapping[str, Any],
    details_key: str,
) -> Mapping[str, Any] | None:
    rows = _mapping_sequence(report.get(details_key))
    return rows[0] if rows else None


def _append_homfly_blocker_detail_notes(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    for count_key, details_key in _HOMFLY_BLOCKER_DETAIL_FIELDS:
        if count_key not in report and details_key not in report:
            continue
        count = _homfly_blocker_detail_count(
            report,
            count_key=count_key,
            details_key=details_key,
        )
        prefix = details_key.removesuffix("s")
        note = f"{count_key}={count}"
        first = _first_homfly_blocker_detail(report, details_key)
        if first is not None:
            for key in ("code", "severity", "scope"):
                value = first.get(key)
                if value is not None:
                    note += f"; first_{prefix}_{key}={value}"
        notes = _append_note(notes, note)
    return _append_homfly_completion_provenance_notes(report, notes)


def _homfly_frontier_witness_summary_mapping(
    report: Mapping[str, Any] | None,
) -> Mapping[str, Any] | None:
    if not isinstance(report, Mapping):
        return None
    summary = report.get("frontier_witness_summary")
    return summary if isinstance(summary, Mapping) else None


def _homfly_frontier_witness_summary_reason_count(
    summary: Mapping[str, Any],
) -> int:
    return _homfly_frontier_witness_summary_compact_count(
        summary,
        explicit_key="reason_count",
        rows_key="reason_counts",
    )


def _homfly_frontier_witness_pressure_counts(
    summary: Mapping[str, Any],
) -> dict[str, int]:
    counts = {
        key: 0
        for key in (
            "frontier_witness_summary_pressure_total_frontier_count",
            "frontier_witness_summary_pressure_visible_witness_count",
            "frontier_witness_summary_pressure_missing_frontier_count",
            "frontier_witness_summary_pressure_all_frontiers_have_visible_witness",
            "frontier_witness_summary_pressure_reason_count",
        )
    }
    pressure = summary.get("run_cap_frontier_pressure")
    if not isinstance(pressure, Mapping):
        return counts

    counts["frontier_witness_summary_pressure_total_frontier_count"] = (
        _optional_count(pressure.get("frontier_count")) or 0
    )
    counts["frontier_witness_summary_pressure_visible_witness_count"] = (
        _optional_count(pressure.get("witness_count")) or 0
    )
    counts["frontier_witness_summary_pressure_missing_frontier_count"] = (
        _optional_count(pressure.get("unwitnessed_frontier_count")) or 0
    )
    counts[
        "frontier_witness_summary_pressure_all_frontiers_have_visible_witness"
    ] = 1 if pressure.get("all_frontier_witnessed") is True else 0
    counts["frontier_witness_summary_pressure_reason_count"] = (
        _homfly_frontier_witness_summary_compact_count(
            pressure,
            explicit_key="reason_count",
            rows_key="reason_counts",
        )
    )
    return counts


def _homfly_frontier_witness_summary_compact_count(
    summary: Mapping[str, Any],
    *,
    explicit_key: str,
    rows_key: str,
) -> int:
    explicit = _optional_count(summary.get(explicit_key))
    if explicit is not None:
        return explicit
    rows = summary.get(rows_key)
    if not isinstance(rows, Sequence) or isinstance(
        rows,
        (str, bytes),
    ):
        return 0
    return sum(1 for row in rows if isinstance(row, Mapping))


def _homfly_frontier_witness_summary_counts(
    report: Mapping[str, Any] | None,
) -> dict[str, int]:
    counts = {key: 0 for key in _HOMFLY_FRONTIER_WITNESS_SUMMARY_KEYS}
    summary = _homfly_frontier_witness_summary_mapping(report)
    if summary is None:
        return counts

    counts["frontier_witness_summary_count"] = (
        _optional_count(summary.get("witness_count")) or 0
    )
    counts["frontier_witness_summary_reason_count"] = (
        _homfly_frontier_witness_summary_reason_count(summary)
    )
    for summary_key, rows_key, count_key in (
        (
            "recursive_path_prefix_count",
            "recursive_path_prefix_counts",
            "frontier_witness_summary_recursive_path_prefix_count",
        ),
        (
            "source_kind_count",
            "source_kind_counts",
            "frontier_witness_summary_source_kind_count",
        ),
        (
            "branch_count",
            "branch_counts",
            "frontier_witness_summary_branch_count",
        ),
    ):
        counts[count_key] = _homfly_frontier_witness_summary_compact_count(
            summary,
            explicit_key=summary_key,
            rows_key=rows_key,
        )
    truncated = summary.get("witness_summary_truncated")
    if isinstance(truncated, bool):
        counts["frontier_witness_summary_truncated"] = 1 if truncated else 0
    else:
        counts["frontier_witness_summary_truncated"] = (
            _optional_count(truncated) or 0
        )
    for summary_key, count_key in (
        ("min_depth", "frontier_witness_summary_min_depth"),
        ("max_depth", "frontier_witness_summary_max_depth"),
        ("min_branch_depth", "frontier_witness_summary_min_branch_depth"),
        ("max_branch_depth", "frontier_witness_summary_max_branch_depth"),
    ):
        value = _optional_count(summary.get(summary_key))
        if value is not None:
            counts[count_key] = value
    counts.update(_homfly_frontier_witness_pressure_counts(summary))
    return counts


def _append_homfly_frontier_witness_summary_notes(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    summary = _homfly_frontier_witness_summary_mapping(report)
    if summary is None:
        return notes

    counts = _homfly_frontier_witness_summary_counts(report)
    parts = [
        f"witnesses={counts['frontier_witness_summary_count']}",
        f"reasons={counts['frontier_witness_summary_reason_count']}",
        (
            "recursive_path_prefix_count="
            f"{counts['frontier_witness_summary_recursive_path_prefix_count']}"
        ),
        f"source_kind_count={counts['frontier_witness_summary_source_kind_count']}",
        f"branch_count={counts['frontier_witness_summary_branch_count']}",
        (
            "truncated="
            f"{bool(counts['frontier_witness_summary_truncated'])}"
        ),
    ]
    min_depth = _optional_count(summary.get("min_depth"))
    max_depth = _optional_count(summary.get("max_depth"))
    if min_depth is not None or max_depth is not None:
        parts.append(
            "depth="
            f"{min_depth if min_depth is not None else 'none'}.."
            f"{max_depth if max_depth is not None else 'none'}"
        )
    min_branch_depth = _optional_count(summary.get("min_branch_depth"))
    max_branch_depth = _optional_count(summary.get("max_branch_depth"))
    if min_branch_depth is not None or max_branch_depth is not None:
        parts.append(
            "branch_depth="
            f"{min_branch_depth if min_branch_depth is not None else 'none'}.."
            f"{max_branch_depth if max_branch_depth is not None else 'none'}"
        )
    notes = _append_note(notes, "frontier_witness_summary=" + "; ".join(parts))

    pressure = summary.get("run_cap_frontier_pressure")
    if isinstance(pressure, Mapping):
        pressure_counts = _homfly_frontier_witness_pressure_counts(summary)
        notes = _append_note(
            notes,
            (
                "frontier_witness_pressure="
                "total_frontiers="
                f"{pressure_counts['frontier_witness_summary_pressure_total_frontier_count']}; "
                "visible_witnesses="
                f"{pressure_counts['frontier_witness_summary_pressure_visible_witness_count']}; "
                "missing_frontiers="
                f"{pressure_counts['frontier_witness_summary_pressure_missing_frontier_count']}; "
                "all_visible="
                f"{bool(pressure_counts['frontier_witness_summary_pressure_all_frontiers_have_visible_witness'])}; "
                "reasons="
                f"{pressure_counts['frontier_witness_summary_pressure_reason_count']}"
            ),
        )
    return notes


def _append_homfly_reduction_contribution_witness_notes(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    witness_fields = (
        "reduction_contribution_witness_count",
        "reduction_contribution_witness_limit",
        "reduction_contribution_witnesses_truncated",
        "reduction_contribution_witnesses",
        "first_reduction_contribution_witness",
        "parsed_reduction_contribution_count",
        "unparsed_reduction_contribution_count",
    )
    if not any(field in report for field in witness_fields):
        return notes

    witnesses = _mapping_sequence(report.get("reduction_contribution_witnesses"))
    witness_count = _optional_count(
        report.get("reduction_contribution_witness_count")
    )
    if witness_count is None:
        witness_count = len(witnesses)
    witness_limit = _optional_count(
        report.get("reduction_contribution_witness_limit")
    )
    parsed_count = _optional_count(
        report.get("parsed_reduction_contribution_count")
    )
    unparsed_count = _optional_count(
        report.get("unparsed_reduction_contribution_count")
    )
    if witness_limit is not None:
        witness_text = f"{witness_count}/{witness_limit}"
    else:
        witness_text = str(witness_count)
    parts = [
        f"witnesses={witness_text}",
        (
            "truncated="
            f"{bool(report.get('reduction_contribution_witnesses_truncated', False))}"
        ),
    ]
    if parsed_count is not None:
        parts.append(f"parsed={parsed_count}")
    if unparsed_count is not None:
        parts.append(f"unparsed={unparsed_count}")
    first = report.get("first_reduction_contribution_witness")
    if isinstance(first, Mapping):
        reduction_kind = first.get("reduction_kind")
        if reduction_kind not in (None, ""):
            parts.append(f"first_kind={reduction_kind}")
        index = _optional_count(first.get("index"))
        if index is not None:
            parts.append(f"first_index={index}")
    consistency = report.get("reduction_contribution_witness_consistency")
    if isinstance(consistency, Mapping):
        matched = consistency.get("matched")
        if matched in (True, False):
            parts.append(f"consistency_matched={matched}")
        mismatch_count = _optional_count(consistency.get("mismatch_count"))
        if mismatch_count is not None:
            parts.append(f"consistency_mismatch_count={mismatch_count}")
        first_mismatch = consistency.get("first_mismatch")
        if isinstance(first_mismatch, Mapping):
            mismatch_kind = first_mismatch.get("kind")
            mismatch_field = first_mismatch.get("field")
            if mismatch_kind not in (None, "") and mismatch_field not in (None, ""):
                parts.append(f"first_mismatch={mismatch_kind}:{mismatch_field}")
    return _append_note(
        notes,
        "homfly_reduction_contribution_witnesses=" + "; ".join(parts),
    )


def _homfly_reduction_contribution_sources(
    report: Mapping[str, Any] | None,
) -> list[Mapping[str, Any]]:
    if not isinstance(report, Mapping):
        return []
    sources: list[Mapping[str, Any]] = []
    pending: list[Mapping[str, Any]] = [report]
    seen: set[int] = set()
    while pending:
        source = pending.pop(0)
        source_id = id(source)
        if source_id in seen:
            continue
        seen.add(source_id)
        sources.append(source)
        for key in (
            "input_certification_evidence",
            "terminal_contribution_audit",
        ):
            nested = source.get(key)
            if isinstance(nested, Mapping):
                pending.append(nested)
    return sources


def _homfly_reduction_contribution_counts(
    report: Mapping[str, Any] | None,
) -> dict[str, int]:
    counts = {key: 0 for key in _HOMFLY_REDUCTION_CONTRIBUTION_KEYS}
    for source in _homfly_reduction_contribution_sources(report):
        contribution_count = _optional_count(
            source.get("reduction_contribution_count")
        )
        if contribution_count is not None:
            counts["homfly_reduction_contribution_count"] = max(
                counts["homfly_reduction_contribution_count"],
                contribution_count,
            )

        witnesses = _mapping_sequence(
            source.get("reduction_contribution_witnesses")
        )
        witness_count = _optional_count(
            source.get("reduction_contribution_witness_count")
        )
        if witness_count is None and witnesses:
            witness_count = len(witnesses)
        if witness_count is not None:
            counts["homfly_reduction_contribution_witness_count"] = max(
                counts["homfly_reduction_contribution_witness_count"],
                witness_count,
            )

        witness_limit = _optional_count(
            source.get("reduction_contribution_witness_limit")
        )
        if witness_limit is not None:
            counts["homfly_reduction_contribution_witness_limit"] = max(
                counts["homfly_reduction_contribution_witness_limit"],
                witness_limit,
            )

        if source.get("reduction_contribution_witnesses_truncated") is True:
            counts["homfly_reduction_contribution_witness_truncated_count"] = 1

        parsed = _optional_count(
            source.get("parsed_reduction_contribution_count")
        )
        if parsed is not None:
            counts["homfly_reduction_contribution_parsed_count"] = max(
                counts["homfly_reduction_contribution_parsed_count"],
                parsed,
            )
        unparsed = _optional_count(
            source.get("unparsed_reduction_contribution_count")
        )
        if unparsed is not None:
            counts["homfly_reduction_contribution_unparsed_count"] = max(
                counts["homfly_reduction_contribution_unparsed_count"],
                unparsed,
            )

        consistency = source.get("reduction_contribution_witness_consistency")
        if isinstance(consistency, Mapping):
            if consistency.get("matched") is True:
                counts[
                    "homfly_reduction_contribution_consistency_matched_count"
                ] = 1
            mismatch_count = _optional_count(consistency.get("mismatch_count"))
            if mismatch_count is not None:
                counts[
                    "homfly_reduction_contribution_consistency_mismatch_count"
                ] = max(
                    counts[
                        "homfly_reduction_contribution_consistency_mismatch_count"
                    ],
                    mismatch_count,
                )
    return counts


def _homfly_completion_provenance_sources(
    report: Mapping[str, Any] | None,
) -> list[Mapping[str, Any]]:
    if not isinstance(report, Mapping):
        return []
    sources: list[Mapping[str, Any]] = []
    pending: list[Mapping[str, Any]] = [report]
    seen: set[int] = set()
    while pending:
        source = pending.pop(0)
        source_id = id(source)
        if source_id in seen:
            continue
        seen.add(source_id)

        direct = source.get("completion_blocker_provenance")
        if isinstance(direct, Mapping):
            sources.append(direct)

        gate = source.get("arbitrary_diagram_completion_gate")
        if isinstance(gate, Mapping):
            gate_provenance = gate.get("completion_blocker_provenance")
            if isinstance(gate_provenance, Mapping):
                sources.append(gate_provenance)

        for detail in _mapping_sequence(
            source.get("homfly_completion_blocker_details")
        ):
            provenance = detail.get("provenance")
            if isinstance(provenance, Mapping):
                sources.append(provenance)

        for key in (
            "input_certification_evidence",
            "result",
            "source_audit",
        ):
            nested = source.get(key)
            if isinstance(nested, Mapping):
                pending.append(nested)
    return sources


def _first_homfly_completion_provenance(
    report: Mapping[str, Any] | None,
) -> Mapping[str, Any] | None:
    sources = _homfly_completion_provenance_sources(report)
    return sources[0] if sources else None


def _bool_compact(value: Any) -> int:
    return 1 if value is True else 0


def _homfly_completion_provenance_counts(
    report: Mapping[str, Any] | None,
) -> dict[str, int]:
    counts = {key: 0 for key in _HOMFLY_COMPLETION_PROVENANCE_KEYS}
    for provenance in _homfly_completion_provenance_sources(report):
        counts["homfly_completion_blocker_provenance_matched"] = max(
            counts["homfly_completion_blocker_provenance_matched"],
            _bool_compact(provenance.get("matched")),
        )
        counts["homfly_completion_blocker_provenance_non_claim_matched"] = max(
            counts["homfly_completion_blocker_provenance_non_claim_matched"],
            _bool_compact(provenance.get("non_claim_matched")),
        )
        counts["homfly_completion_blocker_provenance_gate_pressure_matched"] = max(
            counts["homfly_completion_blocker_provenance_gate_pressure_matched"],
            _bool_compact(provenance.get("gate_pressure_consistency_matched")),
        )
        counts[
            "homfly_completion_blocker_provenance_frontier_pressure_matched"
        ] = max(
            counts[
                "homfly_completion_blocker_provenance_frontier_pressure_matched"
            ],
            _bool_compact(provenance.get("frontier_pressure_counts_matched")),
        )
        counts[
            "homfly_completion_blocker_provenance_frontier_witness_matched"
        ] = max(
            counts[
                "homfly_completion_blocker_provenance_frontier_witness_matched"
            ],
            _bool_compact(provenance.get("frontier_witness_consistency_matched")),
        )
        counts[
            "homfly_completion_blocker_provenance_terminal_audit_matched"
        ] = max(
            counts[
                "homfly_completion_blocker_provenance_terminal_audit_matched"
            ],
            _bool_compact(provenance.get("terminal_audit_consistency_matched")),
        )
        source_field_count = _optional_count(provenance.get("source_field_count"))
        if source_field_count is None:
            source_fields = provenance.get("source_fields")
            source_field_count = (
                len(source_fields)
                if isinstance(source_fields, Sequence)
                and not isinstance(source_fields, (str, bytes))
                else 0
            )
        counts["homfly_completion_blocker_provenance_source_field_count"] = max(
            counts["homfly_completion_blocker_provenance_source_field_count"],
            source_field_count or 0,
        )
    return counts


def _append_homfly_completion_provenance_notes(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    provenance = _first_homfly_completion_provenance(report)
    if provenance is None:
        return notes
    counts = _homfly_completion_provenance_counts(report)
    parts = [
        (
            "matched="
            f"{bool(counts['homfly_completion_blocker_provenance_matched'])}"
        ),
        (
            "non_claim="
            f"{bool(counts['homfly_completion_blocker_provenance_non_claim_matched'])}"
        ),
        (
            "gate_pressure="
            f"{bool(counts['homfly_completion_blocker_provenance_gate_pressure_matched'])}"
        ),
        (
            "frontier_pressure="
            f"{bool(counts['homfly_completion_blocker_provenance_frontier_pressure_matched'])}"
        ),
        (
            "frontier_witness="
            f"{bool(counts['homfly_completion_blocker_provenance_frontier_witness_matched'])}"
        ),
        (
            "terminal_audit="
            f"{bool(counts['homfly_completion_blocker_provenance_terminal_audit_matched'])}"
        ),
        (
            "source_fields="
            f"{counts['homfly_completion_blocker_provenance_source_field_count']}"
        ),
    ]
    blocker = provenance.get("completion_blocker_code")
    if blocker not in (None, ""):
        parts.append(f"blocker={blocker}")
    return _append_note(
        notes,
        "homfly_completion_blocker_provenance=" + "; ".join(parts),
    )


def _alexander_witness_sources(
    report: Mapping[str, Any] | None,
) -> list[Mapping[str, Any]]:
    if not isinstance(report, Mapping):
        return []
    sources: list[Mapping[str, Any]] = []
    pending: list[Mapping[str, Any]] = [report]
    seen: set[int] = set()
    while pending:
        source = pending.pop(0)
        source_id = id(source)
        if source_id in seen:
            continue
        seen.add(source_id)
        sources.append(source)
        for key in (
            "input_certification_evidence",
            "result",
            "source_audit",
            "improved_audit",
        ):
            nested = source.get(key)
            if isinstance(nested, Mapping):
                pending.append(nested)
    return sources


def _alexander_blocker_witness_summary_sources(
    report: Mapping[str, Any] | None,
) -> list[Mapping[str, Any]]:
    if not isinstance(report, Mapping):
        return []
    sources: list[Mapping[str, Any]] = []
    pending: list[Mapping[str, Any]] = [report]
    seen: set[int] = set()
    while pending:
        source = pending.pop(0)
        source_id = id(source)
        if source_id in seen:
            continue
        seen.add(source_id)
        sources.append(source)
        for key in (
            "input_certification_evidence",
            "result",
            "source_audit",
            "improved_audit",
            "admissible_minor_normalization_evidence",
        ):
            nested = source.get(key)
            if isinstance(nested, Mapping):
                pending.append(nested)
    return sources


def _alexander_blocker_witness_summaries(
    report: Mapping[str, Any] | None,
) -> list[Mapping[str, Any]]:
    summaries: list[Mapping[str, Any]] = []
    for source in _alexander_blocker_witness_summary_sources(report):
        summary = source.get(_ALEXANDER_BLOCKER_WITNESS_SUMMARY_KEY)
        if isinstance(summary, Mapping):
            summaries.append(summary)
    return summaries


def _summary_sequence_count(value: Any) -> int:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return 0
    return sum(1 for item in value if item not in (None, ""))


def _alexander_blocker_witness_summary_reason_count(
    summary: Mapping[str, Any],
) -> int:
    return _optional_count(summary.get("reason_count")) or 0


def _alexander_blocker_witness_summary_missing_reason_count(
    summary: Mapping[str, Any],
) -> int:
    count = _optional_count(summary.get("missing_witness_reason_count"))
    if count is not None:
        return count
    return _summary_sequence_count(summary.get("missing_witness_reasons"))


def _summary_reason_count_total(value: Any) -> int | None:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return None
    total = 0
    found = False
    for row in value:
        if isinstance(row, Mapping):
            count = None
            for key in (
                "blocker_witness_source_count",
                "witness_source_count",
                "source_count",
                "witness_count",
                "count",
            ):
                count = _optional_count(row.get(key))
                if count is not None:
                    break
            if count is not None:
                total += count
                found = True
    return total if found else None


def _alexander_blocker_witness_source_entries(
    summary: Mapping[str, Any],
) -> list[Mapping[str, Any]]:
    sources = summary.get("blocker_witness_sources")
    if not isinstance(sources, Sequence) or isinstance(sources, (str, bytes)):
        return []
    return [source for source in sources if isinstance(source, Mapping)]


def _alexander_blocker_witness_summary_source_count(
    summary: Mapping[str, Any],
) -> int:
    count = _optional_count(summary.get("blocker_witness_source_count"))
    if count is not None:
        return count
    reason_total = _summary_reason_count_total(
        summary.get("blocker_witness_source_counts_by_reason")
    )
    if reason_total is not None:
        return reason_total
    return len(_alexander_blocker_witness_source_entries(summary))


def _alexander_blocker_witness_summary_source_available_count(
    summary: Mapping[str, Any],
) -> int:
    count = _optional_count(summary.get("blocker_witness_source_available_count"))
    if count is not None:
        return count
    reason_total = _summary_reason_count_total(
        summary.get("blocker_witness_source_available_counts_by_reason")
    )
    if reason_total is not None:
        return reason_total
    entries = _alexander_blocker_witness_source_entries(summary)
    if entries:
        return sum(
            1
            for source in entries
            if source.get("witness_available") is True
            or str(source.get("status", "")).lower() == "available"
        )
    return 0


def _alexander_blocker_witness_summary_source_missing_count(
    summary: Mapping[str, Any],
) -> int:
    count = _optional_count(summary.get("blocker_witness_source_missing_count"))
    if count is not None:
        return count
    reason_total = _summary_reason_count_total(
        summary.get("blocker_witness_source_missing_counts_by_reason")
    )
    if reason_total is not None:
        return reason_total
    entries = _alexander_blocker_witness_source_entries(summary)
    if entries:
        return sum(
            1
            for source in entries
            if source.get("witness_available") is False
            or str(source.get("status", "")).lower() == "missing"
        )
    return 0


def _alexander_blocker_witness_summary_counts(
    report: Mapping[str, Any] | None,
) -> dict[str, int]:
    counts = {key: 0 for key in _ALEXANDER_BLOCKER_WITNESS_SUMMARY_KEYS}
    for summary in _alexander_blocker_witness_summaries(report):
        counts["admissible_minor_normalization_blocker_reason_count"] = max(
            counts["admissible_minor_normalization_blocker_reason_count"],
            _alexander_blocker_witness_summary_reason_count(summary),
        )
        counts[
            "admissible_minor_normalization_blocker_witness_available_count"
        ] = max(
            counts[
                "admissible_minor_normalization_blocker_witness_available_count"
            ],
            _optional_count(summary.get("witness_available_count")) or 0,
        )
        counts[
            "admissible_minor_normalization_blocker_missing_witness_reason_count"
        ] = max(
            counts[
                "admissible_minor_normalization_blocker_missing_witness_reason_count"
            ],
            _alexander_blocker_witness_summary_missing_reason_count(summary),
        )
        counts[
            "admissible_minor_normalization_blocker_witness_source_count"
        ] = max(
            counts[
                "admissible_minor_normalization_blocker_witness_source_count"
            ],
            _alexander_blocker_witness_summary_source_count(summary),
        )
        counts[
            "admissible_minor_normalization_blocker_witness_source_available_count"
        ] = max(
            counts[
                "admissible_minor_normalization_blocker_witness_source_available_count"
            ],
            _alexander_blocker_witness_summary_source_available_count(summary),
        )
        counts[
            "admissible_minor_normalization_blocker_witness_source_missing_count"
        ] = max(
            counts[
                "admissible_minor_normalization_blocker_witness_source_missing_count"
            ],
            _alexander_blocker_witness_summary_source_missing_count(summary),
        )
    return counts


def _alexander_gate_summary_sources(
    report: Mapping[str, Any] | None,
) -> list[Mapping[str, Any]]:
    if not isinstance(report, Mapping):
        return []
    sources: list[Mapping[str, Any]] = []
    pending: list[Mapping[str, Any]] = [report]
    seen: set[int] = set()
    while pending:
        source = pending.pop(0)
        source_id = id(source)
        if source_id in seen:
            continue
        seen.add(source_id)
        sources.append(source)
        for key in (
            "input_certification_evidence",
            "result",
            "source_audit",
            "improved_audit",
            "admissible_minor_normalization_evidence",
        ):
            nested = source.get(key)
            if isinstance(nested, Mapping):
                pending.append(nested)
    return sources


def _first_alexander_gate_summary(
    report: Mapping[str, Any] | None,
) -> Mapping[str, Any] | None:
    for source in _alexander_gate_summary_sources(report):
        summary = source.get(_ALEXANDER_GATE_SUMMARY_KEY)
        if isinstance(summary, Mapping):
            return summary
    return None


def _alexander_gate_summary_count(
    summary: Mapping[str, Any],
    explicit_key: str,
    fallback_sequence_key: str,
) -> int:
    count = _optional_count(summary.get(explicit_key))
    if count is not None:
        return count
    if fallback_sequence_key == "gate_checks":
        return len(_mapping_sequence(summary.get(fallback_sequence_key)))
    return _summary_sequence_count(summary.get(fallback_sequence_key))


def _alexander_gate_summary_consistent(summary: Mapping[str, Any]) -> int:
    consistency = summary.get("summary_consistency")
    if isinstance(consistency, Mapping):
        return (
            1
            if consistency.get("gate_blocker_summary_consistent") is True
            else 0
        )
    return 1 if summary.get("gate_blocker_summary_consistent") is True else 0


def _alexander_gate_summary_counts(
    report: Mapping[str, Any] | None,
) -> dict[str, int]:
    counts = {key: 0 for key in _ALEXANDER_GATE_SUMMARY_KEYS}
    summary = _first_alexander_gate_summary(report)
    if summary is None:
        return counts

    counts["admissible_minor_normalization_gate_count"] = (
        _alexander_gate_summary_count(summary, "gate_count", "gate_checks")
    )
    counts["admissible_minor_normalization_gate_passed_count"] = (
        _alexander_gate_summary_count(
            summary,
            "passed_gate_count",
            "passed_gate_names",
        )
    )
    counts["admissible_minor_normalization_gate_failed_count"] = (
        _alexander_gate_summary_count(
            summary,
            "failed_gate_count",
            "failed_gate_names",
        )
    )
    counts["admissible_minor_normalization_gate_summary_consistent"] = (
        _alexander_gate_summary_consistent(summary)
    )
    counts["admissible_minor_normalization_failed_gate_blocker_count"] = (
        _alexander_gate_summary_count(
            summary,
            "failed_gate_blocker_count",
            "failed_gate_blockers",
        )
    )
    return counts


def _first_alexander_gate_provenance(
    report: Mapping[str, Any] | None,
) -> Mapping[str, Any] | None:
    summary = _first_alexander_gate_summary(report)
    if summary is None:
        return None
    candidate = summary.get("failed_gate_blocker_provenance_consistency")
    if isinstance(candidate, Mapping):
        return candidate
    for nested_key in ("gate_pressure_summary", "summary_consistency"):
        nested = summary.get(nested_key)
        if not isinstance(nested, Mapping):
            continue
        candidate = nested.get("failed_gate_blocker_provenance_consistency")
        if isinstance(candidate, Mapping):
            return candidate
    return None


def _mapping_count(value: Any) -> int:
    if isinstance(value, Mapping):
        return len(value)
    return 0


def _alexander_gate_provenance_counts(
    report: Mapping[str, Any] | None,
) -> dict[str, int]:
    counts = {key: 0 for key in _ALEXANDER_GATE_PROVENANCE_KEYS}
    provenance = _first_alexander_gate_provenance(report)
    if provenance is None:
        return counts

    counts[
        "admissible_minor_normalization_failed_gate_blocker_provenance_consistent"
    ] = _bool_compact(provenance.get("normalization_gate_provenance_consistent"))
    counts[
        "admissible_minor_normalization_failed_gate_blocker_provenance_row_count"
    ] = (
        _optional_count(provenance.get("failed_gate_blocker_provenance_row_count"))
        or len(
            _mapping_sequence(
                provenance.get("failed_gate_blocker_provenance_rows")
            )
        )
    )
    counts[
        "admissible_minor_normalization_failed_gate_blocker_provenance_gate_count"
    ] = (
        _optional_count(provenance.get("failed_gate_count"))
        or len(_string_sequence(provenance.get("failed_gate_names")))
    )
    counts[
        "admissible_minor_normalization_failed_gate_blocker_provenance_attribution_count"
    ] = (
        _optional_count(
            provenance.get("failed_gate_blocker_attribution_count")
        )
        or 0
    )
    counts[
        "admissible_minor_normalization_failed_gate_blocker_provenance_reason_count"
    ] = _mapping_count(
        provenance.get("failed_gate_blocker_provenance_row_reason_counts")
    )
    counts[
        "admissible_minor_normalization_failed_gate_blocker_provenance_source_available_count"
    ] = (
        _optional_count(
            provenance.get(
                "failed_gate_blocker_provenance_source_available_count"
            )
        )
        or 0
    )
    counts[
        "admissible_minor_normalization_failed_gate_blocker_provenance_source_missing_count"
    ] = (
        _optional_count(
            provenance.get(
                "failed_gate_blocker_provenance_source_missing_count"
            )
        )
        or 0
    )
    counts[
        "admissible_minor_normalization_failed_gate_blocker_provenance_missing_source_count"
    ] = len(
        _string_sequence(
            provenance.get(
                "failed_gate_blocker_provenance_missing_source_blockers"
            )
        )
    )
    counts[
        "admissible_minor_normalization_failed_gate_blocker_provenance_inconsistent_source_count"
    ] = len(
        _string_sequence(
            provenance.get(
                "failed_gate_blocker_provenance_inconsistent_source_blockers"
            )
        )
    )
    return counts


def _append_alexander_gate_summary_notes(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    summary = _first_alexander_gate_summary(report)
    if summary is None:
        return notes
    counts = _alexander_gate_summary_counts(report)
    notes = _append_note(
        notes,
        (
            "admissible_minor_normalization_gate_summary="
            f"gates={counts['admissible_minor_normalization_gate_count']}; "
            f"passed={counts['admissible_minor_normalization_gate_passed_count']}; "
            f"failed={counts['admissible_minor_normalization_gate_failed_count']}; "
            "consistent="
            f"{bool(counts['admissible_minor_normalization_gate_summary_consistent'])}; "
            "failed_gate_blockers="
            f"{counts['admissible_minor_normalization_failed_gate_blocker_count']}"
        ),
    )
    provenance = _first_alexander_gate_provenance(report)
    if provenance is None:
        return notes
    provenance_counts = _alexander_gate_provenance_counts(report)
    return _append_note(
        notes,
        (
            "admissible_minor_normalization_gate_provenance="
            "consistent="
            f"{bool(provenance_counts['admissible_minor_normalization_failed_gate_blocker_provenance_consistent'])}; "
            "rows="
            f"{provenance_counts['admissible_minor_normalization_failed_gate_blocker_provenance_row_count']}; "
            "gates="
            f"{provenance_counts['admissible_minor_normalization_failed_gate_blocker_provenance_gate_count']}; "
            "attributions="
            f"{provenance_counts['admissible_minor_normalization_failed_gate_blocker_provenance_attribution_count']}; "
            "reasons="
            f"{provenance_counts['admissible_minor_normalization_failed_gate_blocker_provenance_reason_count']}; "
            "source_available="
            f"{provenance_counts['admissible_minor_normalization_failed_gate_blocker_provenance_source_available_count']}; "
            "source_missing="
            f"{provenance_counts['admissible_minor_normalization_failed_gate_blocker_provenance_source_missing_count']}; "
            "missing_sources="
            f"{provenance_counts['admissible_minor_normalization_failed_gate_blocker_provenance_missing_source_count']}; "
            "inconsistent_sources="
            f"{provenance_counts['admissible_minor_normalization_failed_gate_blocker_provenance_inconsistent_source_count']}"
        ),
    )


def _first_alexander_blocker_witness_summary(
    report: Mapping[str, Any] | None,
) -> Mapping[str, Any] | None:
    summaries = _alexander_blocker_witness_summaries(report)
    return summaries[0] if summaries else None


def _first_missing_witness_reason(summary: Mapping[str, Any]) -> str:
    reasons = summary.get("missing_witness_reasons")
    if not isinstance(reasons, Sequence) or isinstance(reasons, (str, bytes)):
        return ""
    for reason in reasons:
        if isinstance(reason, Mapping):
            value = reason.get("reason", reason.get("code"))
            if value not in (None, ""):
                return str(value)
            continue
        if reason not in (None, ""):
            return str(reason)
    return ""


def _first_witness_source_part(
    source: Mapping[str, Any],
    *keys: str,
) -> str:
    for key in keys:
        value = source.get(key)
        if value not in (None, ""):
            return str(value)
    return ""


def _alexander_blocker_witness_summary_consistency_parts(
    summary: Mapping[str, Any],
) -> list[str]:
    consistency = summary.get("summary_consistency")
    if isinstance(consistency, bool):
        return [f"summary_consistency_matched={consistency}"]
    if not isinstance(consistency, Mapping):
        return []

    parts: list[str] = []
    status = consistency.get("status")
    if status not in (None, ""):
        parts.append(f"summary_consistency_status={status}")
    for key in (
        "matched",
        "reason_count_matched",
        "witness_available_count_matched",
        "missing_witness_reason_count_matched",
        "blocker_witness_source_count_matched",
        "blocker_witness_source_available_count_matched",
        "blocker_witness_source_missing_count_matched",
    ):
        value = consistency.get(key)
        if isinstance(value, bool):
            parts.append(f"summary_consistency_{key}={value}")
    return parts


def _append_alexander_blocker_witness_summary_notes(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    summary = _first_alexander_blocker_witness_summary(report)
    if summary is None:
        return notes

    counts = _alexander_blocker_witness_summary_counts(report)
    parts = [
        (
            "reason_count="
            f"{counts['admissible_minor_normalization_blocker_reason_count']}"
        ),
        (
            "witness_available_count="
            f"{counts['admissible_minor_normalization_blocker_witness_available_count']}"
        ),
        (
            "missing_witness_reason_count="
            f"{counts['admissible_minor_normalization_blocker_missing_witness_reason_count']}"
        ),
        (
            "witness_source_count="
            f"{counts['admissible_minor_normalization_blocker_witness_source_count']}"
        ),
        (
            "witness_source_available_count="
            f"{counts['admissible_minor_normalization_blocker_witness_source_available_count']}"
        ),
        (
            "witness_source_missing_count="
            f"{counts['admissible_minor_normalization_blocker_witness_source_missing_count']}"
        ),
    ]
    first_source = summary.get("first_witness_source")
    if isinstance(first_source, Mapping):
        source_kind = _first_witness_source_part(
            first_source,
            "source_kind",
            "kind",
            "source",
        )
        if source_kind:
            parts.append(
                "first_admissible_minor_normalization_blocker_witness_source_kind="
                f"{source_kind}"
            )
        source_status = _first_witness_source_part(
            first_source,
            "status",
            "source_status",
        )
        if source_status:
            parts.append(
                "first_admissible_minor_normalization_blocker_witness_source_status="
                f"{source_status}"
            )
    missing_reason = _first_missing_witness_reason(summary)
    if missing_reason:
        parts.append(f"missing_witness_reason={missing_reason}")
    parts.extend(_alexander_blocker_witness_summary_consistency_parts(summary))
    return _append_note(
        notes,
        "admissible_minor_normalization_blocker_witness_summary="
        + "; ".join(parts),
    )


def _detail_mappings(source: Mapping[str, Any], details_key: str) -> list[Mapping[str, Any]]:
    details = source.get(details_key)
    if not isinstance(details, Mapping):
        return []
    return [value for value in details.values() if isinstance(value, Mapping)]


def _failed_division_witness_count_from_mapping(mapping: Mapping[str, Any]) -> int:
    count = _optional_count(mapping.get("failed_division_witness_count"))
    if count is not None:
        return count
    witnesses = _mapping_sequence(mapping.get("failed_division_witnesses"))
    return len(witnesses)


def _normalization_class_witness_count_from_mapping(mapping: Mapping[str, Any]) -> int:
    count = _optional_count(mapping.get("normalization_class_witness_count"))
    if count is not None:
        return count
    witnesses = _mapping_sequence(mapping.get("normalization_class_witnesses"))
    return len(witnesses)


def _source_failed_division_witness_count(source: Mapping[str, Any]) -> int:
    count = _failed_division_witness_count_from_mapping(source)
    for detail in _detail_mappings(source, "certification_blocker_details"):
        count = max(count, _failed_division_witness_count_from_mapping(detail))
    return count


def _source_quotient_gcd_uncertainty_present(source: Mapping[str, Any]) -> int:
    if isinstance(source.get("quotient_gcd_uncertainty_evidence"), Mapping):
        return 1
    for detail in _detail_mappings(source, "certification_blocker_details"):
        if isinstance(detail.get("quotient_gcd_uncertainty_evidence"), Mapping):
            return 1
    return 0


def _quotient_gcd_uncertainty_evidence_mappings(
    source: Mapping[str, Any],
) -> list[Mapping[str, Any]]:
    evidence_entries: list[Mapping[str, Any]] = []
    evidence = source.get("quotient_gcd_uncertainty_evidence")
    if isinstance(evidence, Mapping):
        evidence_entries.append(evidence)
    for detail in _detail_mappings(source, "certification_blocker_details"):
        evidence = detail.get("quotient_gcd_uncertainty_evidence")
        if isinstance(evidence, Mapping):
            evidence_entries.append(evidence)
    return evidence_entries


def _quotient_polynomial_witness_count_from_mapping(
    mapping: Mapping[str, Any],
) -> int:
    count = _optional_count(mapping.get("quotient_polynomial_witness_count"))
    if count is not None:
        return count
    witnesses = _mapping_sequence(mapping.get("quotient_polynomial_witnesses"))
    return len(witnesses)


def _quotient_polynomial_witness_truncated_from_mapping(
    mapping: Mapping[str, Any],
) -> int:
    truncated = mapping.get("quotient_polynomial_witness_truncated")
    if isinstance(truncated, bool):
        return 1 if truncated else 0
    consistency = mapping.get("quotient_polynomial_witness_consistency")
    if isinstance(consistency, Mapping):
        truncated = consistency.get("witness_truncated")
        if isinstance(truncated, bool):
            return 1 if truncated else 0
    if (
        "quotient_polynomial_witness_count" in mapping
        and "quotient_polynomial_witnesses" in mapping
    ):
        return (
            1
            if _quotient_polynomial_witness_count_from_mapping(mapping)
            > len(_mapping_sequence(mapping.get("quotient_polynomial_witnesses")))
            else 0
        )
    return 0


def _source_quotient_polynomial_witness_count(source: Mapping[str, Any]) -> int:
    count = 0
    for evidence in _quotient_gcd_uncertainty_evidence_mappings(source):
        count = max(count, _quotient_polynomial_witness_count_from_mapping(evidence))
    return count


def _source_quotient_polynomial_witness_truncated(source: Mapping[str, Any]) -> int:
    truncated = 0
    for evidence in _quotient_gcd_uncertainty_evidence_mappings(source):
        truncated = max(
            truncated,
            _quotient_polynomial_witness_truncated_from_mapping(evidence),
        )
    return truncated


def _source_normalization_class_witness_count(source: Mapping[str, Any]) -> int:
    count = _normalization_class_witness_count_from_mapping(source)
    for details_key in (
        "admissible_minor_normalization_blocker_details",
        "full_alexander_completion_blocker_details",
    ):
        for detail in _detail_mappings(source, details_key):
            count = max(count, _normalization_class_witness_count_from_mapping(detail))
    return count


def _alexander_witness_evidence_counts(
    report: Mapping[str, Any] | None,
) -> dict[str, int]:
    counts = {key: 0 for key in _ALEXANDER_WITNESS_EVIDENCE_KEYS}
    for source in _alexander_witness_sources(report):
        counts["failed_division_witness_count"] = max(
            counts["failed_division_witness_count"],
            _source_failed_division_witness_count(source),
        )
        counts["quotient_gcd_uncertainty_present"] = max(
            counts["quotient_gcd_uncertainty_present"],
            _source_quotient_gcd_uncertainty_present(source),
        )
        counts["quotient_polynomial_witness_count"] = max(
            counts["quotient_polynomial_witness_count"],
            _source_quotient_polynomial_witness_count(source),
        )
        counts["quotient_polynomial_witness_truncated"] = max(
            counts["quotient_polynomial_witness_truncated"],
            _source_quotient_polynomial_witness_truncated(source),
        )
        counts["normalization_class_witness_count"] = max(
            counts["normalization_class_witness_count"],
            _source_normalization_class_witness_count(source),
        )
    return counts


def _compact_host_evidence_counts(report: Mapping[str, Any] | None) -> dict[str, int]:
    counts = {key: 0 for key in _COMPACT_HOST_EVIDENCE_KEYS}
    counts.update(_homfly_blocker_detail_counts(report))
    counts.update(_homfly_frontier_witness_summary_counts(report))
    counts.update(_homfly_completion_provenance_counts(report))
    counts.update(_homfly_reduction_contribution_counts(report))
    counts.update(_alexander_witness_evidence_counts(report))
    counts.update(_alexander_wirtinger_relation_shape_counts(report))
    counts.update(_alexander_blocker_witness_summary_counts(report))
    counts.update(_alexander_gate_summary_counts(report))
    counts.update(_alexander_gate_provenance_counts(report))
    return counts


def _alexander_wirtinger_relation_shape_counts(
    report: Mapping[str, Any] | None,
) -> dict[str, int]:
    counts = {
        "wirtinger_fox_relation_shape_invalid_count": 0,
        "wirtinger_fox_relation_shape_witness_count": 0,
        "wirtinger_fox_relation_shape_count_consistency_matched_count": 0,
        "wirtinger_fox_generator_component_coverage_complete_count": 0,
        "wirtinger_fox_generator_component_count_row_count": 0,
        "wirtinger_fox_generator_component_count_total": 0,
        "wirtinger_fox_generator_component_count_consistency_matched_count": 0,
    }
    if not isinstance(report, Mapping):
        return counts

    invalid_count = _optional_count(
        report.get("wirtinger_relation_shape_invalid_count")
    )
    witness_count = _optional_count(report.get("wirtinger_relation_shape_witness_count"))
    if witness_count is None:
        witness_count = len(_mapping_sequence(report.get("wirtinger_relation_shape_witnesses")))
    row_count = _optional_count(
        report.get("wirtinger_generator_component_count_row_count")
    )
    total = _optional_count(report.get("wirtinger_generator_component_count_total"))
    component_rows = _mapping_sequence(
        report.get("wirtinger_generator_component_counts")
    )
    if row_count is None and component_rows:
        row_count = len(component_rows)
    if total is None and component_rows:
        total = sum(
            _optional_count(row.get("generator_count")) or 0
            for row in component_rows
        )
    generator_count = _optional_count(
        report.get("wirtinger_generator_count", report.get("generator_count"))
    )

    invalid_count = invalid_count or 0
    witness_count = witness_count or 0
    row_count = row_count or 0
    total = total or 0
    relation_count_consistent = report.get(
        "wirtinger_relation_shape_count_consistent"
    )
    if relation_count_consistent is None:
        relation_count_consistent = invalid_count == witness_count
    component_count_consistent = report.get(
        "wirtinger_generator_component_count_consistent"
    )
    if component_count_consistent is None and generator_count is not None:
        component_count_consistent = total == generator_count

    counts["wirtinger_fox_relation_shape_invalid_count"] = invalid_count
    counts["wirtinger_fox_relation_shape_witness_count"] = witness_count
    counts["wirtinger_fox_relation_shape_count_consistency_matched_count"] = (
        1 if relation_count_consistent is True else 0
    )
    counts["wirtinger_fox_generator_component_coverage_complete_count"] = (
        1
        if report.get("wirtinger_generator_component_coverage_complete") is True
        else 0
    )
    counts["wirtinger_fox_generator_component_count_row_count"] = row_count
    counts["wirtinger_fox_generator_component_count_total"] = total
    counts["wirtinger_fox_generator_component_count_consistency_matched_count"] = (
        1 if component_count_consistent is True else 0
    )
    return counts


def _has_alexander_witness_evidence_input(report: Mapping[str, Any] | None) -> bool:
    for source in _alexander_witness_sources(report):
        if any(
            key in source
            for key in (
                "failed_division_witness_count",
                "failed_division_witnesses",
                "quotient_gcd_uncertainty_evidence",
                "quotient_polynomial_witness_count",
                "quotient_polynomial_witnesses",
                "normalization_class_witness_count",
                "normalization_class_witnesses",
            )
        ):
            return True
        for details_key in (
            "certification_blocker_details",
            "admissible_minor_normalization_blocker_details",
            "full_alexander_completion_blocker_details",
        ):
            for detail in _detail_mappings(source, details_key):
                if any(
                    key in detail
                    for key in (
                        "failed_division_witness_count",
                        "failed_division_witnesses",
                        "quotient_gcd_uncertainty_evidence",
                        "quotient_polynomial_witness_count",
                        "quotient_polynomial_witnesses",
                        "normalization_class_witness_count",
                        "normalization_class_witnesses",
                    )
                ):
                    return True
    return False


def _first_failed_division_witness(
    report: Mapping[str, Any] | None,
) -> Mapping[str, Any] | None:
    for source in _alexander_witness_sources(report):
        witnesses = _mapping_sequence(source.get("failed_division_witnesses"))
        if witnesses:
            return witnesses[0]
        for detail in _detail_mappings(source, "certification_blocker_details"):
            witnesses = _mapping_sequence(detail.get("failed_division_witnesses"))
            if witnesses:
                return witnesses[0]
    return None


def _first_normalization_class_witness(
    report: Mapping[str, Any] | None,
) -> Mapping[str, Any] | None:
    for source in _alexander_witness_sources(report):
        witnesses = _mapping_sequence(source.get("normalization_class_witnesses"))
        if witnesses:
            return witnesses[0]
        for details_key in (
            "admissible_minor_normalization_blocker_details",
            "full_alexander_completion_blocker_details",
        ):
            for detail in _detail_mappings(source, details_key):
                witnesses = _mapping_sequence(
                    detail.get("normalization_class_witnesses")
                )
                if witnesses:
                    return witnesses[0]
    return None


def _first_quotient_polynomial_witness(
    report: Mapping[str, Any] | None,
) -> Mapping[str, Any] | None:
    for source in _alexander_witness_sources(report):
        for evidence in _quotient_gcd_uncertainty_evidence_mappings(source):
            first = evidence.get("first_quotient_polynomial_witness")
            if isinstance(first, Mapping):
                return first
            witnesses = _mapping_sequence(
                evidence.get("quotient_polynomial_witnesses")
            )
            if witnesses:
                return witnesses[0]
    return None


def _fox_minor_validation_witness_value(
    source: Mapping[str, Any],
    *,
    prefixed_key: str,
    audit_key: str,
) -> Any:
    if prefixed_key in source:
        return source.get(prefixed_key)
    return source.get(audit_key)


def _first_fox_minor_validation_witness_fields(
    report: Mapping[str, Any] | None,
) -> dict[str, Any] | None:
    for source in _alexander_witness_sources(report):
        reference_witnesses = _mapping_sequence(
            _fox_minor_validation_witness_value(
                source,
                prefixed_key="fox_square_minor_invalid_reference_witnesses",
                audit_key="invalid_minor_reference_witnesses",
            )
        )
        normalization_witnesses = _mapping_sequence(
            _fox_minor_validation_witness_value(
                source,
                prefixed_key="fox_square_minor_invalid_normalization_witnesses",
                audit_key="invalid_normalization_witnesses",
            )
        )
        reference_count = _optional_count(
            _fox_minor_validation_witness_value(
                source,
                prefixed_key="fox_square_minor_invalid_reference_witness_count",
                audit_key="invalid_minor_reference_witness_count",
            )
        )
        normalization_count = _optional_count(
            _fox_minor_validation_witness_value(
                source,
                prefixed_key="fox_square_minor_invalid_normalization_witness_count",
                audit_key="invalid_normalization_witness_count",
            )
        )
        reference_limit = _optional_count(
            _fox_minor_validation_witness_value(
                source,
                prefixed_key="fox_square_minor_invalid_reference_witness_limit",
                audit_key="invalid_minor_reference_witness_limit",
            )
        )
        normalization_limit = _optional_count(
            _fox_minor_validation_witness_value(
                source,
                prefixed_key="fox_square_minor_invalid_normalization_witness_limit",
                audit_key="invalid_normalization_witness_limit",
            )
        )
        reference_truncated = bool(
            _fox_minor_validation_witness_value(
                source,
                prefixed_key="fox_square_minor_invalid_reference_witness_truncated",
                audit_key="invalid_minor_reference_witness_truncated",
            )
        )
        normalization_truncated = bool(
            _fox_minor_validation_witness_value(
                source,
                prefixed_key="fox_square_minor_invalid_normalization_witness_truncated",
                audit_key="invalid_normalization_witness_truncated",
            )
        )
        has_witness_shape = any(
            value is not None
            for value in (
                reference_count,
                normalization_count,
                reference_limit,
                normalization_limit,
            )
        ) or bool(reference_witnesses or normalization_witnesses)
        if not has_witness_shape:
            continue
        return {
            "reference_count": (
                reference_count
                if reference_count is not None
                else len(reference_witnesses)
            ),
            "normalization_count": (
                normalization_count
                if normalization_count is not None
                else len(normalization_witnesses)
            ),
            "reference_limit": reference_limit,
            "normalization_limit": normalization_limit,
            "reference_truncated": reference_truncated,
            "normalization_truncated": normalization_truncated,
            "first_reference_witness": (
                reference_witnesses[0] if reference_witnesses else None
            ),
            "first_normalization_witness": (
                normalization_witnesses[0] if normalization_witnesses else None
            ),
        }
    return None


def _append_alexander_fox_minor_validation_witness_notes(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    fields = _first_fox_minor_validation_witness_fields(report)
    if fields is None:
        return notes

    def _count_text(count: int, limit: int | None) -> str:
        return f"{count}/{limit}" if limit is not None else str(count)

    parts = [
        "reference="
        + _count_text(fields["reference_count"], fields["reference_limit"]),
        f"reference_truncated={fields['reference_truncated']}",
        "normalization="
        + _count_text(
            fields["normalization_count"],
            fields["normalization_limit"],
        ),
        f"normalization_truncated={fields['normalization_truncated']}",
    ]
    first_normalization = fields.get("first_normalization_witness")
    if isinstance(first_normalization, Mapping):
        minor_index = _optional_count(first_normalization.get("minor_index"))
        if minor_index is not None:
            parts.append(f"first_invalid_normalization_minor={minor_index}")
        issue_count = _optional_count(first_normalization.get("issue_count"))
        if issue_count is not None:
            parts.append(f"first_invalid_normalization_issue_count={issue_count}")
    first_reference = fields.get("first_reference_witness")
    if isinstance(first_reference, Mapping):
        minor_index = _optional_count(first_reference.get("minor_index"))
        if minor_index is not None:
            parts.append(f"first_invalid_reference_minor={minor_index}")
        issue_count = _optional_count(first_reference.get("issue_count"))
        if issue_count is not None:
            parts.append(f"first_invalid_reference_issue_count={issue_count}")
    return _append_note(
        notes,
        "fox_minor_invalid_witnesses=" + "; ".join(parts),
    )

def _append_alexander_witness_notes(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    notes = _append_alexander_fox_minor_validation_witness_notes(report, notes)
    notes = _append_alexander_blocker_witness_summary_notes(report, notes)
    notes = _append_alexander_gate_summary_notes(report, notes)
    if not _has_alexander_witness_evidence_input(report):
        return notes
    counts = _alexander_witness_evidence_counts(report)
    parts = [
        f"failed_division_witness_count={counts['failed_division_witness_count']}",
        (
            "quotient_gcd_uncertainty_present="
            f"{counts['quotient_gcd_uncertainty_present']}"
        ),
        (
            "quotient_polynomial_witness_count="
            f"{counts['quotient_polynomial_witness_count']}"
        ),
        (
            "quotient_polynomial_witness_truncated="
            f"{bool(counts['quotient_polynomial_witness_truncated'])}"
        ),
        (
            "normalization_class_witness_count="
            f"{counts['normalization_class_witness_count']}"
        ),
    ]
    failed_witness = _first_failed_division_witness(report)
    if failed_witness is not None:
        minor_index = _optional_count(failed_witness.get("minor_index"))
        if minor_index is not None:
            parts.append(f"first_failed_division_minor={minor_index}")
        reason = failed_witness.get("reason")
        if reason:
            parts.append(f"first_failed_division_reason={reason}")
    quotient_witness = _first_quotient_polynomial_witness(report)
    if quotient_witness is not None:
        quotient = quotient_witness.get("quotient_polynomial")
        if quotient not in (None, ""):
            parts.append(f"first_quotient_polynomial_witness={quotient}")
        quotient_index = _optional_count(quotient_witness.get("quotient_index"))
        if quotient_index is not None:
            parts.append(f"first_quotient_polynomial_witness_index={quotient_index}")
        quotient_terms = _optional_count(
            quotient_witness.get("quotient_term_count")
        )
        if quotient_terms is not None:
            parts.append(f"first_quotient_polynomial_witness_terms={quotient_terms}")
    class_witness = _first_normalization_class_witness(report)
    if class_witness is not None:
        normalized = class_witness.get("normalized_polynomial")
        if normalized:
            parts.append(f"first_normalization_class_witness={normalized}")
        minor_count = _optional_count(class_witness.get("minor_count"))
        if minor_count is not None:
            parts.append(f"first_normalization_class_minor_count={minor_count}")
    return _append_note(notes, "alexander_witness_evidence=" + "; ".join(parts))


def _append_alexander_wirtinger_relation_shape_notes(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    has_shape = any(
        key in report
        for key in (
            "wirtinger_relation_shape_valid",
            "wirtinger_relation_shape_invalid_count",
            "wirtinger_relation_shape_witness_count",
            "wirtinger_relation_shape_witnesses",
            "wirtinger_generator_component_coverage_complete",
            "wirtinger_generator_component_count_row_count",
            "wirtinger_generator_component_counts",
        )
    )
    if not has_shape:
        return notes
    counts = _alexander_wirtinger_relation_shape_counts(report)
    relation_shape_valid = bool(report.get("wirtinger_relation_shape_valid", False))
    component_coverage = bool(
        report.get("wirtinger_generator_component_coverage_complete", False)
    )
    notes = _append_note(
        notes,
        (
            "wirtinger_relation_shape="
            f"valid={relation_shape_valid}; "
            f"invalid={counts['wirtinger_fox_relation_shape_invalid_count']}; "
            f"witnesses={counts['wirtinger_fox_relation_shape_witness_count']}; "
            "count_consistent="
            f"{bool(counts['wirtinger_fox_relation_shape_count_consistency_matched_count'])}"
        ),
    )
    return _append_note(
        notes,
        (
            "wirtinger_generator_components="
            f"coverage_complete={component_coverage}; "
            f"rows={counts['wirtinger_fox_generator_component_count_row_count']}; "
            f"total_generators={counts['wirtinger_fox_generator_component_count_total']}; "
            "count_consistent="
            f"{bool(counts['wirtinger_fox_generator_component_count_consistency_matched_count'])}"
        ),
    )


def _source_signed_pd_revision(report: Mapping[str, Any]) -> int | None:
    revisions = _source_signed_pd_revisions(report)
    return revisions[0] if revisions else None


def _source_signed_pd_revisions(report: Mapping[str, Any]) -> tuple[int, ...]:
    revisions: list[int] = []
    for key in ("source_signed_pd_revision", "signed_pd_revision"):
        revision = _optional_count(report.get(key))
        if revision is not None:
            revisions.append(revision)
    input_report = report.get("input")
    if isinstance(input_report, Mapping):
        revision = _optional_count(input_report.get("signed_pd_revision"))
        if revision is not None:
            revisions.append(revision)
    return tuple(dict.fromkeys(revisions))


def _analysis_summary_with_source_signed_pd_revision(
    summary: dict[str, Any],
    report: Mapping[str, Any],
) -> dict[str, Any]:
    revision = _source_signed_pd_revision(report)
    summary["has_source_signed_pd_revision"] = revision is not None
    summary["source_signed_pd_revision"] = revision or 0
    if revision is not None:
        summary["notes"] = _append_note(
            str(summary.get("notes", "")),
            f"signed_pd_revision={revision}",
        )
    return summary


def _bounded_scanned_gcd_admissible_minor_counts(
    report: Mapping[str, Any],
) -> dict[str, int]:
    summary = report.get("admissible_minor_summary")
    summary_mapping = summary if isinstance(summary, Mapping) else {}
    aggregate_keys = {
        "expected_combination_count": (
            "bounded_scanned_gcd_expected_minor_combination_count"
        ),
        "nonzero_minor_count": "bounded_scanned_gcd_nonzero_minor_count",
        "zero_minor_count": "bounded_scanned_gcd_zero_minor_count",
        "unit_minor_count": "bounded_scanned_gcd_unit_minor_count",
        "unique_nonzero_polynomial_count": (
            "bounded_scanned_gcd_unique_nonzero_polynomial_count"
        ),
        "all_rows_have_nonzero_minor": (
            "bounded_scanned_gcd_all_rows_have_nonzero_minor_count"
        ),
        "all_columns_have_nonzero_minor": (
            "bounded_scanned_gcd_all_columns_have_nonzero_minor_count"
        ),
    }

    def count(name: str) -> int:
        value = _optional_count(report.get(name))
        if value is None:
            value = _optional_count(summary_mapping.get(name))
        if value is None:
            aggregate_key = aggregate_keys.get(name)
            if aggregate_key is not None:
                value = _optional_count(report.get(aggregate_key))
        if value is None and name == "unique_nonzero_polynomial_count":
            unique_polynomials = summary_mapping.get("unique_nonzero_polynomials")
            if isinstance(unique_polynomials, list):
                value = len(unique_polynomials)
        return value or 0

    def flag(name: str) -> int:
        value = report.get(name)
        if isinstance(value, bool):
            return 1 if value else 0
        summary_value = summary_mapping.get(name)
        if isinstance(summary_value, bool):
            return 1 if summary_value else 0
        aggregate_key = aggregate_keys.get(name)
        if aggregate_key is not None:
            aggregate_value = _optional_count(report.get(aggregate_key))
            if aggregate_value is not None:
                return aggregate_value
        return 0

    return {
        "bounded_scanned_gcd_expected_minor_combination_count": count(
            "expected_combination_count"
        ),
        "bounded_scanned_gcd_nonzero_minor_count": count("nonzero_minor_count"),
        "bounded_scanned_gcd_zero_minor_count": count("zero_minor_count"),
        "bounded_scanned_gcd_unit_minor_count": count("unit_minor_count"),
        "bounded_scanned_gcd_unique_nonzero_polynomial_count": count(
            "unique_nonzero_polynomial_count"
        ),
        "bounded_scanned_gcd_all_rows_have_nonzero_minor_count": flag(
            "all_rows_have_nonzero_minor"
        ),
        "bounded_scanned_gcd_all_columns_have_nonzero_minor_count": flag(
            "all_columns_have_nonzero_minor"
        ),
    }


def _bounded_scanned_gcd_completion_count(
    report: Mapping[str, Any],
    direct_key: str,
    aggregate_key: str,
) -> int:
    summary = report.get("admissible_minor_summary")
    summary_mapping = summary if isinstance(summary, Mapping) else {}
    value = report.get(direct_key)
    if isinstance(value, bool):
        return 1 if value else 0
    summary_value = summary_mapping.get(direct_key)
    if isinstance(summary_value, bool):
        return 1 if summary_value else 0
    return _optional_count(report.get(aggregate_key)) or 0


def _invariant_status_admissible_minor_fields(
    report: Mapping[str, Any] | None,
) -> dict[str, int]:
    if report is None:
        return {key: 0 for key in _INVARIANT_STATUS_ADMISSIBLE_MINOR_KEYS}
    fields = {
        key: 0
        for key in _INVARIANT_STATUS_ADMISSIBLE_MINOR_KEYS
    }
    fields.update(_bounded_scanned_gcd_admissible_minor_counts(report))
    fields["bounded_scanned_gcd_complete_scan_count"] = (
        _bounded_scanned_gcd_completion_count(
            report,
            "complete_combination_scan",
            "bounded_scanned_gcd_complete_scan_count",
        )
    )
    fields["bounded_scanned_gcd_nonzero_minor_coverage_complete_count"] = (
        _bounded_scanned_gcd_completion_count(
            report,
            "nonzero_minor_coverage_complete",
            "bounded_scanned_gcd_nonzero_minor_coverage_complete_count",
        )
    )
    return fields


def _invariant_status_source_table_registration_fields(
    report: Mapping[str, Any] | None,
) -> dict[str, int]:
    fields = {key: 0 for key in _INVARIANT_STATUS_SOURCE_TABLE_AUDIT_KEYS}
    if (
        report is None
        or report.get("method")
        not in {
            "diagram_fixture_source_table_invariant_audit",
            "homfly_fixture_acceptance_report",
            "multivariable_alexander_fixture_acceptance_report",
        }
    ):
        return fields
    if report.get("method") in {
        "homfly_fixture_acceptance_report",
        "multivariable_alexander_fixture_acceptance_report",
    }:
        fields["source_table_audit_registration_ready_count"] = (
            _optional_count(report.get("source_table_registration_ready_count")) or 0
        )
        fields["source_table_audit_registration_blocked_count"] = (
            _optional_count(report.get("source_table_registration_blocked_count")) or 0
        )
        fields["source_table_audit_registration_blocker_count"] = (
            _optional_count(report.get("source_table_registration_blocker_count")) or 0
        )
        return fields
    blockers = _source_table_audit_registration_blockers(report)
    ready_value = report.get("source_table_registration_ready")
    ready = ready_value if isinstance(ready_value, bool) else len(blockers) == 0
    convergence_summary = report.get("source_table_candidate_convergence_summary")
    partial_certified = report.get(
        "source_table_candidate_convergence_partial_certified"
    )
    if not isinstance(partial_certified, bool) and isinstance(
        convergence_summary,
        Mapping,
    ):
        partial_certified = convergence_summary.get(
            "partial_source_table_convergence_certified"
        )
    full_certified = report.get("source_table_candidate_convergence_full_certified")
    if not isinstance(full_certified, bool) and isinstance(
        convergence_summary,
        Mapping,
    ):
        full_certified = convergence_summary.get(
            "full_source_table_convergence_certified"
        )
    fields["source_table_audit_candidate_convergence_partial_certified_count"] = (
        1 if partial_certified is True else 0
    )
    fields["source_table_audit_candidate_convergence_full_certified_count"] = (
        1 if full_certified is True else 0
    )
    certified_count = _optional_count(
        report.get("source_table_candidate_convergence_certified_invariant_count")
    )
    uncertified_count = _optional_count(
        report.get("source_table_candidate_convergence_uncertified_invariant_count")
    )
    source_seen_count = _optional_count(
        report.get("source_table_candidate_convergence_source_value_seen_invariant_count")
    )
    source_seen_uncertified_count = _optional_count(
        report.get(
            "source_table_candidate_convergence_source_value_seen_but_uncertified_invariant_count"
        )
    )
    if isinstance(convergence_summary, Mapping):
        if certified_count is None:
            certified_count = _optional_count(
                convergence_summary.get("certified_invariant_count")
            )
        if uncertified_count is None:
            uncertified_count = _optional_count(
                convergence_summary.get("uncertified_invariant_count")
            )
        if source_seen_count is None:
            source_seen_count = _optional_count(
                convergence_summary.get("source_value_seen_invariant_count")
            )
        if source_seen_uncertified_count is None:
            source_seen_uncertified_count = _optional_count(
                convergence_summary.get(
                    "source_value_seen_but_uncertified_invariant_count"
                )
            )
    fields["source_table_audit_candidate_convergence_certified_invariant_count"] = (
        certified_count or 0
    )
    fields["source_table_audit_candidate_convergence_uncertified_invariant_count"] = (
        uncertified_count or 0
    )
    fields["source_table_audit_candidate_convergence_source_value_seen_count"] = (
        source_seen_count or 0
    )
    fields[
        "source_table_audit_candidate_convergence_source_value_seen_but_uncertified_count"
    ] = source_seen_uncertified_count or 0
    fields["source_table_audit_registration_ready_count"] = 1 if ready else 0
    fields["source_table_audit_registration_blocked_count"] = 0 if ready else 1
    blocker_count = _optional_count(report.get("source_table_registration_blocker_count"))
    fields["source_table_audit_registration_blocker_count"] = (
        blocker_count if blocker_count is not None else len(blockers)
    )
    return fields


def _source_table_alexander_numerator_counts(
    report: Mapping[str, Any] | None,
) -> dict[str, int]:
    fields = {key: 0 for key in _SOURCE_TABLE_ALEXANDER_NUMERATOR_KEYS}
    if (
        report is None
        or report.get("method") != "multivariable_alexander_fixture_acceptance_report"
    ):
        return fields
    for report_key, output_key in _SOURCE_TABLE_ALEXANDER_NUMERATOR_REPORT_FIELDS.items():
        fields[output_key] = _optional_count(report.get(report_key)) or 0
    return fields


def _source_table_alexander_skipped_common_gcd_attempt_counts(
    report: Mapping[str, Any] | None,
) -> dict[str, int]:
    fields = {
        "source_table_alexander_skipped_common_gcd_attempt_candidate_count": 0,
        "source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count": 0,
        "source_table_alexander_skipped_common_gcd_attempt_method_count": 0,
        "source_table_alexander_skipped_common_gcd_attempt_limit_variant_count": 0,
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count": 0,
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_min": 0,
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_max": 0,
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_divides_all_candidate_count_min": 0,
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_divides_all_candidate_count_max": 0,
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_min": 0,
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max": 0,
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed_count": 0,
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count": 0,
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count": 0,
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min": 0,
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max": 0,
    }
    if report is None:
        return fields

    summaries = _source_table_alexander_skipped_common_gcd_attempt_summaries(report)
    for summary in summaries:
        fields[
            "source_table_alexander_skipped_common_gcd_attempt_candidate_count"
        ] += (
            _optional_count(summary.get("candidate_with_attempt_evidence_count"))
            or 0
        )
        fields[
            "source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count"
        ] += (
            _optional_count(summary.get("not_certified_candidate_count")) or 0
        )
        fields[
            "source_table_alexander_skipped_common_gcd_attempt_method_count"
        ] += (
            _optional_count(summary.get("candidate_method_count")) or 0
        )
        fields[
            "source_table_alexander_skipped_common_gcd_attempt_limit_variant_count"
        ] += (
            _optional_count(summary.get("bounded_search_limit_variant_count"))
            or 0
        )
        for key in (
            "direct_divisor_attempt_evidence_count",
            "direct_divisor_candidate_count_min",
            "direct_divisor_candidate_count_max",
            "direct_divisor_divides_all_candidate_count_min",
            "direct_divisor_divides_all_candidate_count_max",
            "direct_divisor_failed_candidate_count_min",
            "direct_divisor_failed_candidate_count_max",
        ):
            fields[
                f"source_table_alexander_skipped_common_gcd_attempt_{key}"
            ] += (_optional_count(summary.get(key)) or 0)
        if summary.get("direct_divisor_all_candidates_failed") is True:
            fields[
                "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed_count"
            ] += 1
        for key in (
            "support_signature_evidence_count",
            "support_signature_variant_count",
            "support_signature_input_count_min",
            "support_signature_input_count_max",
        ):
            fields[
                f"source_table_alexander_skipped_common_gcd_attempt_{key}"
            ] += (_optional_count(summary.get(key)) or 0)
    return fields


def _source_table_alexander_source_divisibility_counts(
    report: Mapping[str, Any] | None,
) -> dict[str, int]:
    fields = {
        "source_table_alexander_source_divisibility_checked_candidate_count": 0,
        "source_table_alexander_source_divisibility_source_divides_all_candidate_count": 0,
        "source_table_alexander_source_divisibility_source_division_failed_candidate_count": 0,
        "source_table_alexander_source_divisibility_status_variant_count": 0,
        "source_table_alexander_source_divisibility_failed_candidate_witness_count": 0,
        "source_table_alexander_source_divisibility_failed_candidate_witness_truncated": 0,
    }
    if report is None:
        return fields

    summaries = _source_table_alexander_source_divisibility_summaries(report)
    for summary in summaries:
        checked = _optional_count(summary.get("checked_candidate_count")) or 0
        divides_all = (
            _optional_count(summary.get("source_divides_all_candidate_count"))
            or 0
        )
        failed = _optional_count(
            summary.get("source_division_failed_candidate_count")
        )
        if failed is None:
            failed = max(0, checked - divides_all)
        status_rows = summary.get("status_counts")
        if isinstance(status_rows, list):
            status_variant_count = sum(1 for row in status_rows if isinstance(row, Mapping))
        else:
            statuses = summary.get("statuses")
            status_variant_count = len(statuses) if isinstance(statuses, list) else 0

        fields[
            "source_table_alexander_source_divisibility_checked_candidate_count"
        ] += checked
        fields[
            "source_table_alexander_source_divisibility_source_divides_all_candidate_count"
        ] += divides_all
        fields[
            "source_table_alexander_source_divisibility_source_division_failed_candidate_count"
        ] += failed
        fields[
            "source_table_alexander_source_divisibility_status_variant_count"
        ] += status_variant_count

    witness_summaries = (
        _source_table_alexander_source_divisibility_witness_summaries(report)
    )
    for summary in witness_summaries:
        fields[
            "source_table_alexander_source_divisibility_failed_candidate_witness_count"
        ] += _source_table_alexander_failed_candidate_witness_count(summary)
        fields[
            "source_table_alexander_source_divisibility_failed_candidate_witness_truncated"
        ] += _source_table_alexander_failed_candidate_witness_truncated(summary)
    return fields


def _admissible_minor_normalization_counts(
    report: Mapping[str, Any] | None,
) -> dict[str, int]:
    fields = {key: 0 for key in _ADMISSIBLE_MINOR_NORMALIZATION_KEYS}
    if report is None:
        return fields

    nested = report.get("admissible_minor_normalization_evidence")
    has_nested_evidence = isinstance(nested, Mapping)
    is_direct_normalization_audit = (
        report.get("method")
        == "multivariable_alexander_admissible_minor_normalization_audit"
    )
    evidence = nested if isinstance(nested, Mapping) else report

    def count(direct_key: str, evidence_key: str | None = None) -> int:
        value = _optional_count(report.get(direct_key))
        if value is not None:
            return value
        if (
            evidence_key is not None
            and (has_nested_evidence or is_direct_normalization_audit)
        ):
            value = _optional_count(evidence.get(evidence_key))
            if value is not None:
                return value
        return 0

    def flag(direct_key: str, evidence_key: str | None = None) -> int:
        value = report.get(direct_key)
        if isinstance(value, bool):
            return 1 if value else 0
        evidence_lookup = evidence_key if evidence_key is not None else direct_key
        if (
            evidence_key is None
            or has_nested_evidence
            or is_direct_normalization_audit
        ):
            value = evidence.get(evidence_lookup)
            if isinstance(value, bool):
                return 1 if value else 0
        return _optional_count(report.get(direct_key)) or 0

    class_count = _optional_count(
        report.get("admissible_minor_normalization_class_count")
    )
    if class_count is None:
        class_count = _optional_count(evidence.get("normalization_class_count"))
    if class_count is None:
        class_rows = evidence.get("normalization_class_counts")
        if isinstance(class_rows, list):
            class_count = len(class_rows)
    largest_class = _optional_count(
        report.get("admissible_minor_normalization_largest_class_minor_count")
    )
    if largest_class is None:
        largest_class = _optional_count(
            evidence.get("largest_normalization_class_minor_count")
        )
    representative_class = _optional_count(
        report.get("admissible_minor_normalization_representative_class_minor_count")
    )
    if representative_class is None:
        representative_class = _optional_count(
            evidence.get("representative_normalization_class_minor_count")
        )
    nonrepresentative_class_count = _optional_count(
        report.get("admissible_minor_normalization_nonrepresentative_class_count")
    )
    if nonrepresentative_class_count is None:
        nonrepresentative_class_count = _optional_count(
            evidence.get("nonrepresentative_normalization_class_count")
        )

    fields["admissible_minor_normalization_checked_nonzero_minor_count"] = count(
        "admissible_minor_normalization_checked_nonzero_minor_count",
        "checked_nonzero_minor_count",
    )
    fields["admissible_minor_normalization_failed_nonzero_minor_count"] = count(
        "admissible_minor_normalization_failed_nonzero_minor_count",
        "failed_nonzero_minor_count",
    )
    fields["admissible_minor_normalization_all_equivalent_count"] = flag(
        "all_nonzero_minors_laurent_unit_equivalent"
    )
    fields["admissible_minor_normalization_bounded_certified_count"] = flag(
        "bounded_admissible_minor_normalization_certified"
    )
    fields["admissible_minor_normalization_complete_scan_count"] = flag(
        "admissible_minor_normalization_complete_scan_count",
        "complete_combination_scan",
    )
    fields[
        "admissible_minor_normalization_nonzero_minor_coverage_complete_count"
    ] = flag(
        "admissible_minor_normalization_nonzero_minor_coverage_complete_count",
        "nonzero_minor_coverage_complete",
    )
    fields["admissible_minor_normalization_truncated_count"] = flag(
        "admissible_minor_normalization_truncated_count",
        "truncated",
    )
    fields["admissible_minor_normalization_class_count"] = class_count or 0
    fields["admissible_minor_normalization_largest_class_minor_count"] = (
        largest_class or 0
    )
    fields["admissible_minor_normalization_representative_class_minor_count"] = (
        representative_class or 0
    )
    fields["admissible_minor_normalization_nonrepresentative_class_count"] = (
        nonrepresentative_class_count or 0
    )
    return fields


def _append_admissible_minor_scan_note(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    counts = _bounded_scanned_gcd_admissible_minor_counts(report)
    if not any(counts.values()):
        return notes

    complete = bool(_bounded_scanned_gcd_completion_count(
        report,
        "complete_combination_scan",
        "bounded_scanned_gcd_complete_scan_count",
    ))
    nonzero_coverage = bool(_bounded_scanned_gcd_completion_count(
        report,
        "nonzero_minor_coverage_complete",
        "bounded_scanned_gcd_nonzero_minor_coverage_complete_count",
    ))
    return _append_note(
        notes,
        (
            "admissible_minor_scan="
            f"expected={counts['bounded_scanned_gcd_expected_minor_combination_count']}; "
            f"nonzero={counts['bounded_scanned_gcd_nonzero_minor_count']}; "
            f"zero={counts['bounded_scanned_gcd_zero_minor_count']}; "
            f"unit={counts['bounded_scanned_gcd_unit_minor_count']}; "
            "unique_nonzero="
            f"{counts['bounded_scanned_gcd_unique_nonzero_polynomial_count']}; "
            "rows_nonzero="
            f"{counts['bounded_scanned_gcd_all_rows_have_nonzero_minor_count']}; "
            "columns_nonzero="
            f"{counts['bounded_scanned_gcd_all_columns_have_nonzero_minor_count']}; "
            f"complete={complete}; "
            f"nonzero_coverage_complete={nonzero_coverage}"
        ),
    )


def _append_source_table_alexander_acceptance_note(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    checked = (
        _optional_count(
            report.get(
                "source_table_multivariable_alexander_numerator_checked_count"
            )
        )
        or 0
    )
    if checked <= 0:
        return notes
    source_seen = (
        _optional_count(
            report.get(
                "source_table_multivariable_alexander_numerator_source_seen_count"
            )
        )
        or 0
    )
    complete_match = (
        _optional_count(
            report.get(
                "source_table_multivariable_alexander_numerator_complete_match_count"
            )
        )
        or 0
    )
    incomplete_or_unstable = (
        _optional_count(
            report.get(
                "source_table_multivariable_alexander_numerator_incomplete_or_unstable_count"
            )
        )
        or 0
    )
    computed = (
        _optional_count(
            report.get(
                "source_table_multivariable_alexander_numerator_computed_candidate_count"
            )
        )
        or 0
    )
    skipped = (
        _optional_count(
            report.get(
                "source_table_multivariable_alexander_numerator_skipped_candidate_count"
            )
        )
        or 0
    )
    missing = (
        _optional_count(
            report.get(
                "source_table_multivariable_alexander_numerator_missing_candidate_count"
            )
        )
        or 0
    )
    notes = _append_note(
        notes,
        (
            "source_table_alexander_numerator="
            f"checked={checked}; "
            f"source_seen={source_seen}; "
            f"complete_match={complete_match}; "
            f"incomplete_or_unstable={incomplete_or_unstable}; "
            f"computed_candidates={computed}; "
            f"skipped_candidates={skipped}; "
            f"missing_candidates={missing}"
        ),
    )
    link_normalization_checked = (
        _optional_count(
            report.get(
                "source_table_alexander_numerator_link_normalization_checked_count"
            )
        )
        or 0
    )
    if link_normalization_checked > 0:
        link_normalization_ready = (
            _optional_count(
                report.get(
                    "source_table_alexander_numerator_link_normalization_ready_count"
                )
            )
            or 0
        )
        link_normalization_blocked = (
            _optional_count(
                report.get(
                    "source_table_alexander_numerator_link_normalization_blocked_count"
                )
            )
            or 0
        )
        link_normalization_blockers = (
            _optional_count(
                report.get(
                    "source_table_alexander_numerator_link_normalization_blocker_count"
                )
            )
            or 0
        )
        notes = _append_note(
            notes,
            (
                "source_table_alexander_link_normalization="
                f"checked={link_normalization_checked}; "
                f"ready={link_normalization_ready}; "
                f"blocked={link_normalization_blocked}; "
                f"blockers={link_normalization_blockers}"
            ),
        )
    attempt_note = _source_table_alexander_skipped_common_gcd_attempt_note(report)
    if attempt_note:
        notes = _append_note(notes, attempt_note)
    source_divisibility_note = _source_table_alexander_source_divisibility_note(report)
    if source_divisibility_note:
        notes = _append_note(notes, source_divisibility_note)
    return notes


def _source_table_alexander_skipped_common_gcd_attempt_note(
    report: Mapping[str, Any],
) -> str:
    summaries = _source_table_alexander_skipped_common_gcd_attempt_summaries(report)
    if not summaries:
        return ""

    evidence_count = sum(
        _optional_count(summary.get("candidate_with_attempt_evidence_count")) or 0
        for summary in summaries
    )
    if evidence_count <= 0:
        return ""
    not_certified = sum(
        _optional_count(summary.get("not_certified_candidate_count")) or 0
        for summary in summaries
    )
    status_counts: dict[str, int] = {}
    input_counts: list[int] = []
    unique_input_counts: list[int] = []
    direct_divisor_candidate_counts: list[int] = []
    direct_divisor_failed_counts: list[int] = []
    support_signature_input_counts: list[int] = []
    support_signature_rows: dict[tuple[str, ...], int] = {}
    candidate_methods: list[str] = []
    limit_keys: set[tuple] = set()
    limit_variant_count = 0
    direct_divisor_all_failed_count = 0
    support_signature_evidence_count = 0
    for summary in summaries:
        for row in summary.get("status_counts") or []:
            if not isinstance(row, Mapping):
                continue
            status = str(row.get("status") or "")
            if not status:
                continue
            status_counts[status] = status_counts.get(status, 0) + (
                _optional_count(row.get("candidate_count")) or 0
            )
        for key, target in (
            ("input_polynomial_count_min", input_counts),
            ("input_polynomial_count_max", input_counts),
            ("unique_input_polynomial_count_min", unique_input_counts),
            ("unique_input_polynomial_count_max", unique_input_counts),
        ):
            value = _optional_count(summary.get(key))
            if value is not None and value > 0:
                target.append(value)
        for key, target in (
            ("direct_divisor_candidate_count_min", direct_divisor_candidate_counts),
            ("direct_divisor_candidate_count_max", direct_divisor_candidate_counts),
            ("direct_divisor_failed_candidate_count_min", direct_divisor_failed_counts),
            ("direct_divisor_failed_candidate_count_max", direct_divisor_failed_counts),
        ):
            value = _optional_count(summary.get(key))
            if value is not None and value > 0:
                target.append(value)
        if summary.get("direct_divisor_all_candidates_failed") is True:
            direct_divisor_all_failed_count += 1
        support_signature_evidence_count += (
            _optional_count(summary.get("support_signature_evidence_count")) or 0
        )
        for row in summary.get("support_signature_counts") or []:
            if not isinstance(row, Mapping):
                continue
            variables_value = row.get("variables")
            if not isinstance(variables_value, list):
                continue
            signature = tuple(str(variable) for variable in variables_value)
            support_signature_rows[signature] = support_signature_rows.get(
                signature,
                0,
            ) + (_optional_count(row.get("candidate_count")) or 0)
            for key in (
                "input_count_min",
                "input_count_max",
            ):
                value = _optional_count(row.get(key))
                if value is not None and value > 0:
                    support_signature_input_counts.append(value)
        for method in summary.get("candidate_methods_attempted") or []:
            method_text = str(method)
            if method_text and method_text not in candidate_methods:
                candidate_methods.append(method_text)
        limit_variant_count += (
            _optional_count(summary.get("bounded_search_limit_variant_count")) or 0
        )
        limits = summary.get("bounded_search_limits")
        if isinstance(limits, Mapping):
            limit_keys.add(_mapping_key(limits))

    status_text = ",".join(
        f"{status}:{status_counts[status]}" for status in status_counts
    )
    if not status_text:
        status_text = "none"
    if limit_keys:
        limit_variant_count = len(limit_keys)
    input_range = _count_range_text(input_counts)
    unique_input_range = _count_range_text(unique_input_counts)
    support_signature_input_range = _count_range_text(support_signature_input_counts)
    support_signature_text = ",".join(
        f"{'+'.join(signature) if signature else 'none'}:{support_signature_rows[signature]}"
        for signature in sorted(support_signature_rows)
    )
    if not support_signature_text:
        support_signature_text = "none"
    direct_divisor_candidate_range = _count_range_text(direct_divisor_candidate_counts)
    direct_divisor_failed_range = _count_range_text(direct_divisor_failed_counts)
    method_text = ",".join(candidate_methods) if candidate_methods else "none"
    return (
        "source_table_alexander_skipped_common_gcd_attempts="
        f"candidates={evidence_count}; "
        f"not_certified={not_certified}; "
        f"statuses={status_text}; "
        f"input_polynomials={input_range}; "
        f"unique_inputs={unique_input_range}; "
        f"support_signature_evidence={support_signature_evidence_count}; "
        f"support_signatures={support_signature_text}; "
        f"support_signature_inputs={support_signature_input_range}; "
        f"direct_divisor_candidates={direct_divisor_candidate_range}; "
        f"direct_divisor_failed={direct_divisor_failed_range}; "
        f"direct_divisor_all_failed={direct_divisor_all_failed_count}; "
        f"attempt_methods={method_text}; "
        f"limit_variants={limit_variant_count}"
    )


def _source_table_alexander_skipped_common_gcd_attempt_summaries(
    report: Mapping[str, Any],
) -> list[Mapping[str, Any]]:
    direct = report.get("source_table_alexander_skipped_common_gcd_attempt_summary")
    if isinstance(direct, Mapping):
        return [direct]
    comparisons = report.get("comparisons")
    if isinstance(comparisons, Mapping):
        alexander = comparisons.get("multivariable_alexander_numerator")
        if isinstance(alexander, Mapping):
            nested = alexander.get("skipped_common_gcd_attempt_summary")
            if isinstance(nested, Mapping):
                return [nested]

    summaries: list[Mapping[str, Any]] = []
    fixtures = report.get("fixtures")
    if isinstance(fixtures, list):
        for row in fixtures:
            if not isinstance(row, Mapping):
                continue
            audit = row.get("source_table_invariant_audit")
            if not isinstance(audit, Mapping):
                continue
            summaries.extend(
                _source_table_alexander_skipped_common_gcd_attempt_summaries(audit)
            )
    return summaries


def _source_table_alexander_source_divisibility_note(
    report: Mapping[str, Any],
) -> str:
    summaries = _source_table_alexander_source_divisibility_summaries(report)
    if not summaries:
        return ""

    checked = sum(
        _optional_count(summary.get("checked_candidate_count")) or 0
        for summary in summaries
    )
    if checked <= 0:
        return ""
    divides_all = sum(
        _optional_count(summary.get("source_divides_all_candidate_count")) or 0
        for summary in summaries
    )
    failed = sum(
        _optional_count(summary.get("source_division_failed_candidate_count"))
        or 0
        for summary in summaries
    )
    status_counts: dict[str, int] = {}
    failed_input_counts: list[int] = []
    unique_input_counts: list[int] = []
    candidate_indices: list[int] = []
    witness_summaries = (
        _source_table_alexander_source_divisibility_witness_summaries(report)
    )
    witness_count = sum(
        _source_table_alexander_failed_candidate_witness_count(summary)
        for summary in witness_summaries
    )
    witness_truncated = any(
        _source_table_alexander_failed_candidate_witness_truncated(summary)
        for summary in witness_summaries
    )
    first_witness = _first_source_table_alexander_failed_candidate_witness(
        witness_summaries
    )
    first_failed_candidate = _optional_count(
        report.get(
            "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_candidate_index"
        )
    )
    first_failed_input = report.get(
        "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_input_polynomial"
    )
    first_failed_notation = report.get(
        "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_notation"
    )
    if first_failed_notation in (None, ""):
        first_failed_notation = report.get("notation")
    for summary in summaries:
        raw_indices = summary.get("candidate_indices")
        if isinstance(raw_indices, list):
            for value in raw_indices:
                index = _optional_count(value)
                if index is not None:
                    candidate_indices.append(index)
        if first_failed_candidate is None:
            first_failed_candidate = _optional_count(
                summary.get("first_failed_candidate_index")
            )
        if first_failed_input in (None, ""):
            first_failed_input = summary.get("first_failed_input_polynomial")
        for row in summary.get("status_counts") or []:
            if not isinstance(row, Mapping):
                continue
            status = str(row.get("status") or "")
            if not status:
                continue
            status_counts[status] = status_counts.get(status, 0) + (
                _optional_count(row.get("candidate_count")) or 0
            )
        for key, target in (
            ("failed_input_count_min", failed_input_counts),
            ("failed_input_count_max", failed_input_counts),
            ("unique_input_polynomial_count_min", unique_input_counts),
            ("unique_input_polynomial_count_max", unique_input_counts),
        ):
            value = _optional_count(summary.get(key))
            if value is not None and value > 0:
                target.append(value)

    status_text = ",".join(
        f"{status}:{status_counts[status]}" for status in status_counts
    )
    if not status_text:
        status_text = "none"
    note = (
        "source_table_alexander_source_divisibility="
        f"candidates={checked}; "
        f"source_divides_all={divides_all}; "
        f"source_division_failed={failed}; "
        f"statuses={status_text}; "
        f"failed_inputs={_count_range_text(failed_input_counts)}; "
        f"unique_inputs={_count_range_text(unique_input_counts)}"
    )
    unique_candidate_indices = sorted(set(candidate_indices))
    if unique_candidate_indices:
        note += "; candidate_indices=" + ",".join(
            str(index) for index in unique_candidate_indices
        )
    if first_failed_notation not in (None, ""):
        note += f"; first_failed_notation={first_failed_notation}"
    if first_failed_candidate is not None:
        note += f"; first_failed_candidate={first_failed_candidate}"
    if first_failed_input not in (None, ""):
        note += f"; first_failed_input={first_failed_input}"
    if witness_summaries:
        note += f"; failed_candidate_witness_count={witness_count}"
        note += f"; failed_candidate_witness_truncated={witness_truncated}"
    if first_witness is not None:
        first_witness_notation = first_witness.get("notation")
        first_witness_candidate = _optional_count(
            first_witness.get("candidate_index")
        )
        first_witness_status = first_witness.get("status")
        first_input_witness = first_witness.get("first_failed_input_witness")
        first_input_polynomial = None
        if isinstance(first_input_witness, Mapping):
            first_input_polynomial = first_input_witness.get("input_polynomial")
        if first_witness_notation not in (None, ""):
            note += f"; first_failed_candidate_witness_notation={first_witness_notation}"
        if first_witness_candidate is not None:
            note += (
                "; first_failed_candidate_witness_candidate="
                f"{first_witness_candidate}"
            )
        if first_witness_status not in (None, ""):
            note += f"; first_failed_candidate_witness_status={first_witness_status}"
        if first_input_polynomial not in (None, ""):
            note += (
                "; first_failed_candidate_witness_input="
                f"{first_input_polynomial}"
            )
    return note


def _source_table_alexander_source_divisibility_witness_fields(
    report: Mapping[str, Any],
) -> dict[str, Any]:
    summaries = _source_table_alexander_source_divisibility_summaries(report)
    if not summaries:
        return {}

    candidate_indices: list[int] = []
    first_failed_candidate = _optional_count(
        report.get(
            "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_candidate_index"
        )
    )
    first_failed_input = report.get(
        "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_input_polynomial"
    )
    first_failed_notation = report.get(
        "source_table_multivariable_alexander_numerator_source_divisibility_first_failed_notation"
    )
    if first_failed_notation in (None, ""):
        first_failed_notation = report.get("notation")

    for summary in summaries:
        raw_indices = summary.get("candidate_indices")
        if isinstance(raw_indices, list):
            for value in raw_indices:
                index = _optional_count(value)
                if index is not None:
                    candidate_indices.append(index)
        if first_failed_candidate is None:
            first_failed_candidate = _optional_count(
                summary.get("first_failed_candidate_index")
            )
        if first_failed_input in (None, ""):
            first_failed_input = summary.get("first_failed_input_polynomial")

    unique_candidate_indices = sorted(set(candidate_indices))
    return {
        "source_table_alexander_source_divisibility_candidate_indices": (
            ",".join(str(index) for index in unique_candidate_indices)
        ),
        "source_table_alexander_source_divisibility_first_failed_candidate_index": (
            first_failed_candidate if first_failed_candidate is not None else 0
        ),
        "source_table_alexander_source_divisibility_first_failed_notation": str(
            first_failed_notation or ""
        ),
        "source_table_alexander_source_divisibility_first_failed_input_polynomial": str(
            first_failed_input or ""
        ),
    }


def _source_table_alexander_failed_candidate_witness_count(
    summary: Mapping[str, Any],
) -> int:
    count = _optional_count(summary.get("failed_candidate_witness_count"))
    if count is not None:
        return count
    witnesses = _mapping_sequence(summary.get("failed_candidate_witnesses"))
    return len(witnesses)


def _source_table_alexander_failed_candidate_witness_truncated(
    summary: Mapping[str, Any],
) -> int:
    truncated = summary.get("failed_candidate_witness_truncated")
    if isinstance(truncated, bool):
        return 1 if truncated else 0
    consistency = summary.get("failed_candidate_witness_consistency")
    if isinstance(consistency, Mapping):
        truncated = consistency.get("witness_truncated")
        if isinstance(truncated, bool):
            return 1 if truncated else 0
    if (
        "failed_candidate_witness_count" in summary
        and "failed_candidate_witnesses" in summary
    ):
        return (
            1
            if _source_table_alexander_failed_candidate_witness_count(summary)
            > len(_mapping_sequence(summary.get("failed_candidate_witnesses")))
            else 0
        )
    return 0


def _first_source_table_alexander_failed_candidate_witness(
    summaries: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any] | None:
    for summary in summaries:
        first = summary.get("first_failed_candidate_witness")
        if isinstance(first, Mapping):
            return first
        witnesses = _mapping_sequence(summary.get("failed_candidate_witnesses"))
        if witnesses:
            return witnesses[0]
    return None


def _source_table_alexander_prefixed_failed_candidate_witness_summary(
    report: Mapping[str, Any],
) -> Mapping[str, Any] | None:
    prefix = (
        "source_table_multivariable_alexander_numerator_source_divisibility_"
    )
    direct_summary = report.get(f"{prefix}failed_candidate_witness_summary")
    if isinstance(direct_summary, Mapping):
        return direct_summary
    direct_keys = (
        f"{prefix}failed_candidate_witness_count",
        f"{prefix}failed_candidate_witnesses",
        f"{prefix}first_failed_candidate_witness",
        f"{prefix}failed_candidate_witness_truncated",
    )
    if not any(key in report for key in direct_keys):
        return None
    witnesses = _mapping_sequence(report.get(f"{prefix}failed_candidate_witnesses"))
    first = report.get(f"{prefix}first_failed_candidate_witness")
    if not isinstance(first, Mapping):
        first = witnesses[0] if witnesses else None
    count = _optional_count(report.get(f"{prefix}failed_candidate_witness_count"))
    if count is None:
        count = len(witnesses)
    truncated = report.get(f"{prefix}failed_candidate_witness_truncated")
    if not isinstance(truncated, bool):
        truncated = count > len(witnesses)
    return {
        "failed_candidate_witness_count": count,
        "failed_candidate_witness_truncated": truncated,
        "failed_candidate_witnesses": witnesses,
        "first_failed_candidate_witness": first,
    }


def _source_table_alexander_embedded_failed_candidate_witness_summary(
    report: Mapping[str, Any],
) -> Mapping[str, Any] | None:
    for key in (
        "source_table_alexander_source_divisibility_failed_candidate_witness_summary",
        "source_table_alexander_source_numerator_divisibility_failed_candidate_witness_summary",
        "source_numerator_divisibility_failed_candidate_witness_summary",
        "failed_candidate_witness_summary",
    ):
        summary = report.get(key)
        if isinstance(summary, Mapping):
            return summary
    for key in (
        "source_table_alexander_source_numerator_divisibility_summary",
        "source_numerator_divisibility_summary",
    ):
        summary = report.get(key)
        if (
            isinstance(summary, Mapping)
            and "failed_candidate_witness_count" in summary
        ):
            return summary
    return None


def _source_table_alexander_source_divisibility_witness_summaries(
    report: Mapping[str, Any],
) -> list[Mapping[str, Any]]:
    direct = _source_table_alexander_prefixed_failed_candidate_witness_summary(
        report
    )
    if direct is not None:
        return [direct]
    direct = _source_table_alexander_embedded_failed_candidate_witness_summary(
        report
    )
    if direct is not None:
        return [direct]

    comparisons = report.get("comparisons")
    if isinstance(comparisons, Mapping):
        alexander = comparisons.get("multivariable_alexander_numerator")
        if isinstance(alexander, Mapping):
            direct = (
                _source_table_alexander_embedded_failed_candidate_witness_summary(
                    alexander
                )
            )
            if direct is not None:
                return [direct]

    summaries: list[Mapping[str, Any]] = []
    fixtures = report.get("fixtures")
    if isinstance(fixtures, list):
        for row in fixtures:
            if not isinstance(row, Mapping):
                continue
            direct = _source_table_alexander_prefixed_failed_candidate_witness_summary(
                row
            )
            if direct is not None:
                summaries.append(direct)
                continue
            audit = row.get("source_table_invariant_audit")
            if not isinstance(audit, Mapping):
                continue
            summaries.extend(
                _source_table_alexander_source_divisibility_witness_summaries(
                    audit
                )
            )
    return summaries


def _source_table_alexander_source_divisibility_summaries(
    report: Mapping[str, Any],
) -> list[Mapping[str, Any]]:
    direct = report.get("source_table_alexander_source_numerator_divisibility_summary")
    if isinstance(direct, Mapping):
        return [direct]
    comparisons = report.get("comparisons")
    if isinstance(comparisons, Mapping):
        alexander = comparisons.get("multivariable_alexander_numerator")
        if isinstance(alexander, Mapping):
            nested = alexander.get("source_numerator_divisibility_summary")
            if isinstance(nested, Mapping):
                return [nested]

    summaries: list[Mapping[str, Any]] = []
    fixtures = report.get("fixtures")
    if isinstance(fixtures, list):
        for row in fixtures:
            if not isinstance(row, Mapping):
                continue
            audit = row.get("source_table_invariant_audit")
            if not isinstance(audit, Mapping):
                continue
            summaries.extend(
                _source_table_alexander_source_divisibility_summaries(audit)
            )
    return summaries


def _count_range_text(values: list[int]) -> str:
    if not values:
        return "0..0"
    return f"{min(values)}..{max(values)}"


def _mapping_key(mapping: Mapping[str, Any]) -> tuple:
    return tuple(
        (str(key), _mapping_value_key(value))
        for key, value in sorted(mapping.items(), key=lambda item: str(item[0]))
    )


def _mapping_value_key(value: Any):
    if isinstance(value, Mapping):
        return _mapping_key(value)
    if isinstance(value, (list, tuple)):
        return tuple(_mapping_value_key(item) for item in value)
    return value


def _append_admissible_minor_normalization_note(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    if not any(
        key in report
        for key in (
            "bounded_admissible_minor_normalization_certified",
            "all_nonzero_minors_laurent_unit_equivalent",
            "admissible_minor_normalized_representative_polynomial",
        )
    ):
        return notes

    representative = report.get(
        "admissible_minor_normalized_representative_polynomial"
    )
    if representative is None:
        representative = report.get("normalized_representative_polynomial")
    all_equivalent = bool(
        report.get("all_nonzero_minors_laurent_unit_equivalent", False)
    )
    bounded_certified = bool(
        report.get("bounded_admissible_minor_normalization_certified", False)
    )
    checked = _optional_count(
        report.get("admissible_minor_normalization_checked_nonzero_minor_count")
    )
    if checked is None:
        checked = _optional_count(report.get("checked_nonzero_minor_count")) or 0
    failed = _optional_count(
        report.get("admissible_minor_normalization_failed_nonzero_minor_count")
    )
    if failed is None:
        failed = _optional_count(report.get("failed_nonzero_minor_count")) or 0
    class_count = _optional_count(
        report.get("admissible_minor_normalization_class_count")
    )
    if class_count is None:
        class_count = _optional_count(report.get("normalization_class_count"))
    class_rows = report.get("normalization_class_counts")
    if class_count is None and isinstance(class_rows, list):
        class_count = len(class_rows)
    if class_count is None:
        class_count = 0
    largest_class = _optional_count(
        report.get("admissible_minor_normalization_largest_class_minor_count")
    )
    if largest_class is None:
        largest_class = _optional_count(
            report.get("largest_normalization_class_minor_count")
        )
    if largest_class is None and isinstance(class_rows, list):
        row_counts = [
            _optional_count(row.get("minor_count"))
            for row in class_rows
            if isinstance(row, Mapping)
        ]
        largest_class = max(
            (count for count in row_counts if count is not None),
            default=0,
        )
    if largest_class is None:
        largest_class = 0
    mismatch_witness_count = _optional_count(
        report.get("admissible_minor_normalization_mismatch_witness_count")
    )
    if mismatch_witness_count is None:
        mismatch_witness_count = _optional_count(
            report.get("normalization_mismatch_witness_count")
        )
    mismatch_witness_limit = _optional_count(
        report.get("admissible_minor_normalization_mismatch_witness_limit")
    )
    if mismatch_witness_limit is None:
        mismatch_witness_limit = _optional_count(
            report.get("normalization_mismatch_witness_limit")
        )
    mismatch_witness_truncated = report.get(
        "admissible_minor_normalization_mismatch_witness_truncated"
    )
    if mismatch_witness_truncated is None:
        mismatch_witness_truncated = report.get(
            "normalization_mismatch_witness_truncated"
        )
    representative_witness = report.get(
        "admissible_minor_normalization_representative_witness"
    )
    if not isinstance(representative_witness, Mapping):
        representative_witness = report.get("normalization_representative_witness")
    representative_minor = None
    if isinstance(representative_witness, Mapping):
        representative_minor = _optional_count(
            representative_witness.get("minor_index")
        )
    witness_parts = []
    if mismatch_witness_count is not None:
        if mismatch_witness_limit is not None:
            witness_parts.append(
                f"mismatch_witnesses={mismatch_witness_count}/{mismatch_witness_limit}"
            )
        else:
            witness_parts.append(f"mismatch_witnesses={mismatch_witness_count}")
    if isinstance(mismatch_witness_truncated, bool):
        witness_parts.append(
            f"mismatch_witness_truncated={mismatch_witness_truncated}"
        )
    if representative_minor is not None:
        witness_parts.append(f"representative_minor={representative_minor}")
    return _append_note(
        notes,
        (
            "admissible_minor_normalization="
            f"representative={representative or 'none'}; "
            f"all_nonzero_laurent_unit_equivalent={all_equivalent}; "
            f"bounded_certified={bounded_certified}; "
            f"checked_nonzero_minors={checked}; "
            f"failed_nonzero_minors={failed}; "
            f"normalization_classes={class_count}; "
            f"largest_class_minors={largest_class}"
            + (("; " + "; ".join(witness_parts)) if witness_parts else "")
        ),
    )


def _append_blocker_summary_note(
    report: Mapping[str, Any],
    notes: str,
    *,
    blockers_key: str,
    count_key: str,
    first_key: str,
) -> str:
    blocker_values = report.get(blockers_key)
    blockers: list[str] = []
    if isinstance(blocker_values, Sequence) and not isinstance(
        blocker_values,
        (str, bytes),
    ):
        blockers = [str(value) for value in blocker_values if str(value)]

    count = _optional_count(report.get(count_key))
    if count is None and blockers:
        count = len(blockers)
    if count is None:
        return notes

    note = f"{count_key}={count}"
    if blockers:
        note += f"; {first_key}={blockers[0]}"
    return _append_note(notes, note)


def _append_alexander_blocker_notes(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    notes = _append_blocker_summary_note(
        report,
        notes,
        blockers_key="certification_blockers",
        count_key="certification_blocker_count",
        first_key="first_certification_blocker",
    )
    notes = _append_blocker_summary_note(
        report,
        notes,
        blockers_key="admissible_minor_normalization_blockers",
        count_key="admissible_minor_normalization_blocker_count",
        first_key="first_admissible_minor_normalization_blocker",
    )
    return _append_blocker_summary_note(
        report,
        notes,
        blockers_key="full_alexander_completion_blockers",
        count_key="full_alexander_completion_blocker_count",
        first_key="first_full_alexander_completion_blocker",
    )


def _common_gcd_attempt_evidence(report: Mapping[str, Any]) -> Mapping[str, Any] | None:
    evidence = report.get("common_gcd_attempt_evidence")
    if isinstance(evidence, Mapping):
        return evidence
    result = report.get("result")
    if isinstance(result, Mapping):
        evidence = result.get("common_gcd_attempt_evidence")
        if isinstance(evidence, Mapping):
            return evidence
    return None


def _common_gcd_named_evidence(
    report: Mapping[str, Any],
    key: str,
) -> Mapping[str, Any] | None:
    evidence = report.get(key)
    if isinstance(evidence, Mapping):
        return evidence
    result = report.get("result")
    if isinstance(result, Mapping):
        evidence = result.get(key)
        if isinstance(evidence, Mapping):
            return evidence
    return None


def _alexander_common_gcd_evidence_counts(
    report: Mapping[str, Any] | None,
) -> dict[str, int]:
    fields = {key: 0 for key in _ALEXANDER_COMMON_GCD_EVIDENCE_KEYS}
    if report is None:
        return fields

    evidence_entries: list[tuple[str, Mapping[str, Any]]] = []
    attempt = _common_gcd_attempt_evidence(report)
    if attempt is not None:
        evidence_entries.append(("attempt", attempt))
    for key in ("common_gcd_evidence", "quotient_gcd_evidence"):
        evidence = _common_gcd_named_evidence(report, key)
        if evidence is not None:
            evidence_entries.append(("proof", evidence))

    for kind, evidence in evidence_entries:
        if kind == "attempt":
            fields["alexander_common_gcd_attempt_evidence_count"] += 1
        else:
            fields["alexander_common_gcd_proof_evidence_count"] += 1
        for key, field in (
            ("input_polynomial_count", "alexander_common_gcd_input_polynomial_count"),
            (
                "unique_input_polynomial_count",
                "alexander_common_gcd_unique_input_polynomial_count",
            ),
            ("candidate_term_count", "alexander_common_gcd_candidate_term_count"),
            ("divisible_input_count", "alexander_common_gcd_divisible_input_count"),
            ("failed_input_count", "alexander_common_gcd_failed_input_count"),
            ("quotient_count", "alexander_common_gcd_quotient_count"),
            ("quotient_unit_count", "alexander_common_gcd_quotient_unit_count"),
        ):
            value = _optional_count(evidence.get(key))
            if value is not None:
                fields[field] += value
        unique_quotients = _optional_count(evidence.get("unique_quotient_count"))
        if unique_quotients is None:
            unique_quotients = _optional_count(
                evidence.get("unique_quotient_polynomial_count")
            )
        if unique_quotients is not None:
            fields["alexander_common_gcd_unique_quotient_count"] += unique_quotients

        diagnostics = evidence.get("attempt_diagnostics")
        diagnostics_mapping = diagnostics if isinstance(diagnostics, Mapping) else {}
        support_variants = _optional_count(
            diagnostics_mapping.get("support_signature_variant_count")
        )
        if support_variants is not None:
            fields["alexander_common_gcd_support_signature_variant_count"] += (
                support_variants
            )
        direct_summary = diagnostics_mapping.get("direct_scanned_minor_divisor_summary")
        if isinstance(direct_summary, Mapping):
            for key, field in (
                ("candidate_count", "alexander_common_gcd_direct_divisor_candidate_count"),
                (
                    "failed_candidate_count",
                    "alexander_common_gcd_direct_divisor_failed_candidate_count",
                ),
            ):
                value = _optional_count(direct_summary.get(key))
                if value is not None:
                    fields[field] += value
            if direct_summary.get("all_candidates_failed") is True:
                fields[
                    "alexander_common_gcd_direct_divisor_all_candidates_failed_count"
                ] += 1
    return fields


def _term_count_signature_text(rows: Any, count_field: str) -> str:
    if not isinstance(rows, list):
        return "none"
    parts: list[str] = []
    for row in rows:
        if not isinstance(row, Mapping):
            continue
        term_count = _optional_count(row.get("term_count"))
        count = _optional_count(row.get(count_field))
        if term_count is None or count is None:
            continue
        parts.append(f"{term_count}:{count}")
    return ",".join(parts) if parts else "none"


def _count_range_from_mapping(
    mapping: Mapping[str, Any],
    min_key: str,
    max_key: str,
) -> str | None:
    min_value = _optional_count(mapping.get(min_key))
    max_value = _optional_count(mapping.get(max_key))
    if min_value is None and max_value is None:
        return None
    if min_value is None:
        min_value = max_value
    if max_value is None:
        max_value = min_value
    return f"{min_value}..{max_value}"


def _common_gcd_evidence_note(label: str, evidence: Mapping[str, Any]) -> str:
    limits = evidence.get("bounded_search_limits")
    limits_mapping = limits if isinstance(limits, Mapping) else {}
    methods = evidence.get("candidate_methods_attempted")
    method_text = ""
    if isinstance(methods, list):
        method_text = ",".join(str(method) for method in methods if str(method))
    if not method_text:
        method = evidence.get("candidate_method")
        if method:
            method_text = str(method)

    parts: list[str] = []
    status = evidence.get("status")
    if status is not None:
        parts.append(f"status={status}")
    else:
        claim_scope = evidence.get("claim_scope")
        default_scope = "bounded_scanned_fox_minor_common_divisor"
        parts.append(f"claim_scope={claim_scope or default_scope}")

    unique_quotients = _optional_count(evidence.get("unique_quotient_count"))
    if unique_quotients is None:
        unique_quotients = _optional_count(
            evidence.get("unique_quotient_polynomial_count")
        )
    input_terms = _count_range_from_mapping(
        evidence,
        "input_term_count_min",
        "input_term_count_max",
    )
    input_term_signature = _term_count_signature_text(
        evidence.get("input_term_count_signature"),
        "input_count",
    )
    quotient_terms = _count_range_from_mapping(
        evidence,
        "quotient_term_count_min",
        "quotient_term_count_max",
    )
    quotient_term_signature = _term_count_signature_text(
        evidence.get("quotient_term_count_signature"),
        "quotient_count",
    )
    for key, label_text in (
        ("input_polynomial_count", "input_polynomials"),
        ("unique_input_polynomial_count", "unique_input_polynomials"),
        ("common_integer_content", "common_integer_content"),
        ("candidate_term_count", "candidate_terms"),
        ("divisible_input_count", "divisible_inputs"),
        ("failed_input_count", "failed_inputs"),
        ("quotient_count", "quotients"),
        ("quotient_unit_count", "quotient_units"),
    ):
        value = _optional_count(evidence.get(key))
        if value is not None:
            parts.append(f"{label_text}={value}")
    if unique_quotients is not None:
        parts.append(f"unique_quotients={unique_quotients}")
    if input_terms is not None:
        parts.append(f"input_terms={input_terms}")
    if input_term_signature != "none":
        parts.append(f"input_term_signature={input_term_signature}")
    if quotient_terms is not None:
        parts.append(f"quotient_terms={quotient_terms}")
    if quotient_term_signature != "none":
        parts.append(f"quotient_term_signature={quotient_term_signature}")
    for key, label_text in (
        ("max_candidate_terms", "max_candidate_terms"),
        ("sparse_factor_max_candidates", "sparse_factor_max_candidates"),
        ("root_binomial_max_candidates", "root_binomial_max_candidates"),
        ("cofactor_max_candidates", "cofactor_max_candidates"),
        ("optional_symbolic_gcd_max_variables", "optional_symbolic_gcd_max_variables"),
        (
            "optional_symbolic_gcd_max_polynomials",
            "optional_symbolic_gcd_max_polynomials",
        ),
        ("optional_symbolic_gcd_max_total_terms", "optional_symbolic_gcd_max_total_terms"),
    ):
        value = _optional_count(limits_mapping.get(key))
        if value is not None:
            parts.append(f"{label_text}={value}")
    if method_text:
        parts.append(f"attempted_methods={method_text}")

    diagnostics = evidence.get("attempt_diagnostics")
    diagnostics_mapping = diagnostics if isinstance(diagnostics, Mapping) else {}
    support_signature_variants = _optional_count(
        diagnostics_mapping.get("support_signature_variant_count")
    )
    if support_signature_variants is not None:
        parts.append(f"support_signature_variants={support_signature_variants}")
    direct_summary = diagnostics_mapping.get("direct_scanned_minor_divisor_summary")
    if isinstance(direct_summary, Mapping):
        first_failure = direct_summary.get("first_failure")
        first_failure_mapping = (
            first_failure if isinstance(first_failure, Mapping) else {}
        )
        direct_candidate_terms = _count_range_from_mapping(
            direct_summary,
            "candidate_term_count_min",
            "candidate_term_count_max",
        )
        direct_failed_inputs = _count_range_from_mapping(
            direct_summary,
            "failed_input_count_min",
            "failed_input_count_max",
        )
        direct_first_candidate_terms = _optional_count(
            first_failure_mapping.get("candidate_term_count")
        )
        direct_first_input_terms = _optional_count(
            first_failure_mapping.get("failed_input_term_count")
        )
        for key, label_text in (
            ("candidate_count", "direct_divisor_candidates"),
            ("divides_all_candidate_count", "direct_divisor_divides_all"),
            ("failed_candidate_count", "direct_divisor_failed"),
        ):
            value = _optional_count(direct_summary.get(key))
            if value is not None:
                parts.append(f"{label_text}={value}")
        if direct_candidate_terms is not None:
            parts.append(f"direct_divisor_candidate_terms={direct_candidate_terms}")
        if direct_failed_inputs is not None:
            parts.append(f"direct_divisor_failed_inputs={direct_failed_inputs}")
        if "all_candidates_failed" in direct_summary:
            parts.append(
                "direct_divisor_all_failed="
                f"{bool(direct_summary.get('all_candidates_failed'))}"
            )
        if direct_first_candidate_terms is not None:
            parts.append(
                "direct_divisor_first_failure_candidate_terms="
                f"{direct_first_candidate_terms}"
            )
        if direct_first_input_terms is not None:
            parts.append(
                "direct_divisor_first_failure_input_terms="
                f"{direct_first_input_terms}"
            )

    parts.extend(
        [
            "full_admissible_minor_normalization_certified=False",
            "full_invariant_certified=False",
        ]
    )
    return f"{label}=" + "; ".join(parts)


def _append_common_gcd_attempt_note(
    report: Mapping[str, Any],
    notes: str,
) -> str:
    evidence_entries: list[tuple[str, Mapping[str, Any]]] = []
    attempt_evidence = _common_gcd_attempt_evidence(report)
    if attempt_evidence is not None:
        evidence_entries.append(("common_gcd_attempt", attempt_evidence))
    for key in ("common_gcd_evidence", "quotient_gcd_evidence"):
        evidence = _common_gcd_named_evidence(report, key)
        if evidence is not None:
            evidence_entries.append((key, evidence))
    if not evidence_entries:
        return notes
    for label, evidence in evidence_entries:
        notes = _append_note(notes, _common_gcd_evidence_note(label, evidence))
    return notes


def _notes_text(report: Mapping[str, Any]) -> str:
    notes = report.get("notes")
    if isinstance(notes, list):
        return "; ".join(str(note) for note in notes)
    if notes is None:
        return ""
    return str(notes)


def _note_field_value(value: Any) -> str:
    if isinstance(value, bool):
        return str(value).lower()
    if value is None:
        return "unknown"
    return str(value)


def _append_note(notes: str, note: str) -> str:
    return f"{notes}; {note}" if notes else note


def _homfly_run_cap_note(report: Mapping[str, Any]) -> str | None:
    values = {
        "max_crossings": report.get("max_crossings"),
        "initial_depth": report.get("initial_depth"),
        "max_depth": report.get("max_depth"),
        "max_nodes": report.get("max_nodes"),
    }
    if all(value is None for value in values.values()):
        return None
    return (
        "run_caps="
        f"max_crossings={values['max_crossings']}; "
        f"initial_depth={values['initial_depth']}; "
        f"max_depth={values['max_depth']}; "
        f"max_nodes={values['max_nodes']}"
    )


def _display_name(method: str) -> str:
    if method == "homfly_fixture_acceptance_report":
        return "HOMFLY fixture acceptance"
    if method == "homfly_small_diagram_coverage_report":
        return "HOMFLY generated small-diagram coverage"
    if method == "multivariable_alexander_signed_pd_coverage_report":
        return "multi-variable Alexander generated signed-PD coverage"
    if method == "multivariable_alexander_fixture_acceptance_report":
        return "multi-variable Alexander fixture acceptance"
    if method == "signed_pd_role_order_candidates_report":
        return "signed-PD role-order candidates"
    if method == "diagram_fixture_source_table_invariant_audit":
        return "source-table invariant audit"
    if method == "iroll_core_benchmark_matrix":
        return "core benchmark matrix"
    if method == "cross_workstream_validation_pack_audit":
        return "cross-workstream validation-pack audit"
    if method == "imgui_test_stub_framebuffer_smoke":
        return "Dear ImGui test-stub framebuffer smoke"
    if method == "imgui_production_renderer_framebuffer_pack":
        return "Dear ImGui production renderer framebuffer pack"
    if method == "imgui_source_open_request_smoke":
        return "Dear ImGui source open request smoke"
    if method == "validate_table_source_metadata_report":
        return "validate-table source metadata"
    if method == "imgui_signed_pd_snapshot":
        return "Dear ImGui signed-PD snapshot"
    if method == "imgui_signed_pd_recompute_scheduler_smoke":
        return "Dear ImGui signed-PD recompute scheduler smoke"
    if method == "imgui_signed_pd_thread_pool_recompute_scheduler_smoke":
        return "Dear ImGui signed-PD thread-pool recompute scheduler smoke"
    if method == "imgui_real_kernel_loader_smoke":
        return "Dear ImGui real Rust dynamic-loader smoke"
    if method == "imgui_windows_retained_artifacts_manifest":
        return "Dear ImGui Windows retained artifacts manifest"
    if method == "rust_wheel_retained_manifest":
        return "Rust wheel retained metadata manifest"
    return method.replace("_", " ")


def _invariant_display_name(method: str) -> str:
    if method == "homfly_fixture_acceptance_report":
        return "HOMFLY-PT"
    if method == "multivariable_alexander_fixture_acceptance_report":
        return "multi-variable Alexander"
    if method == "diagram_fixture_source_table_invariant_audit":
        return "source-table invariant audit"
    return method.replace("_fixture_acceptance_report", "").replace("_", " ")


def _row_expected_value(
    row: Mapping[str, Any],
    comparison: Mapping[str, Any],
    invariant_name: str,
) -> str:
    if invariant_name == "HOMFLY-PT":
        value = comparison.get("expected_homfly", row.get("expected_homfly"))
    elif invariant_name == "multi-variable Alexander":
        value = comparison.get(
            "expected_multivariable_alexander",
            row.get("expected_multivariable_alexander"),
        )
    else:
        value = comparison.get("expected", row.get("expected"))
    return "" if value is None else str(value)


def _row_observed_value(
    comparison: Mapping[str, Any],
    invariant_name: str,
) -> str:
    if invariant_name == "HOMFLY-PT":
        value = comparison.get("observed_homfly")
    elif invariant_name == "multi-variable Alexander":
        value = comparison.get("observed_multivariable_alexander")
    else:
        value = comparison.get("observed")
    return "" if value is None else str(value)


def _fixture_row_notes(
    row: Mapping[str, Any],
    comparison: Mapping[str, Any],
) -> str:
    parts = []
    for payload in (row, comparison):
        notes = payload.get("notes")
        if isinstance(notes, list):
            parts.extend(str(note) for note in notes if str(note))
        elif notes is not None and str(notes):
            parts.append(str(notes))
    source = row.get("source")
    if source:
        parts.append(f"source: {source}")
    source_url = row.get("source_url")
    if source_url:
        parts.append(f"source_url: {source_url}")
    return "; ".join(dict.fromkeys(parts))


def _fixture_row_source(
    row: Mapping[str, Any],
    comparison: Mapping[str, Any],
) -> str:
    for payload in (row, comparison, _fixture_payload_from_row(row) or {}):
        source = payload.get("source")
        if source:
            return str(source)
    return ""


def _fixture_row_source_url(
    row: Mapping[str, Any],
    comparison: Mapping[str, Any],
) -> str:
    for payload in (row, comparison, _fixture_payload_from_row(row) or {}):
        source_url = payload.get("source_url")
        if source_url:
            return str(source_url)
    return ""


def _fixture_payload_from_row(row: Mapping[str, Any]) -> Mapping[str, Any] | None:
    fixture = row.get("fixture")
    if isinstance(fixture, Mapping):
        return fixture
    comparison = row.get("comparison")
    if isinstance(comparison, Mapping):
        comparison_fixture = comparison.get("fixture")
        if isinstance(comparison_fixture, Mapping):
            return comparison_fixture
    return None


def _backend_display_name(name: str) -> str:
    if name == "numpy":
        return "NumPy"
    if name == "rust":
        return "Rust"
    if name == "gpu":
        return "GPU"
    return name.replace("_", " ").title()


def _backend_capability_text(
    *,
    available: list[str],
    missing: list[str],
    expected_count: int,
) -> str:
    prefix = f"{len(available)}/{expected_count} capabilities"
    if missing:
        return prefix + "; missing: " + ", ".join(missing)
    if available:
        return prefix + "; available: " + ", ".join(available)
    return prefix


def _backend_owned_string_contract_from_entry(
    entry: Mapping[str, Any],
) -> Mapping[str, Any]:
    backend_info = entry.get("backend_info")
    if not isinstance(backend_info, Mapping):
        return {}
    owned_string_reports = backend_info.get("owned_string_reports")
    if not isinstance(owned_string_reports, Mapping):
        return {}
    contract = owned_string_reports.get("owned_string_contract")
    return contract if isinstance(contract, Mapping) else {}


def _backend_owned_string_contract_fields(
    entry: Mapping[str, Any],
) -> dict[str, Any]:
    contract = _backend_owned_string_contract_from_entry(entry)
    contract_version = contract.get("contract_version")
    return {
        "owned_string_contract_schema_version": (
            _optional_count(contract.get("schema_version")) or 0
        ),
        "owned_string_contract_abi_version": (
            _optional_count(contract.get("abi_version")) or 0
        ),
        "owned_string_contract_version_length": (
            len(contract_version) if isinstance(contract_version, str) else 0
        ),
        "owned_string_contract_free_required": (
            _optional_bool(contract.get("free_required")) is True
        ),
        "owned_string_contract_free_accepts_zero_initialized": (
            _optional_bool(contract.get("free_accepts_zero_initialized")) is True
        ),
        "owned_string_contract_borrowed_across_calls": (
            _optional_bool(contract.get("borrowed_across_calls")) is True
        ),
    }


def _backend_invariant_result_handles_from_entry(
    entry: Mapping[str, Any],
) -> Mapping[str, Any]:
    backend_info = entry.get("backend_info")
    if not isinstance(backend_info, Mapping):
        return {}
    invariant_result_handles = backend_info.get("invariant_result_handles")
    return (
        invariant_result_handles
        if isinstance(invariant_result_handles, Mapping)
        else {}
    )


def _backend_invariant_result_handle_readiness_fields(
    entry: Mapping[str, Any],
) -> dict[str, Any]:
    handles = _backend_invariant_result_handles_from_entry(entry)
    readiness = handles.get("readiness_provenance_self_consistency")
    readiness_mapping: Mapping[str, Any] = (
        readiness if isinstance(readiness, Mapping) else {}
    )
    self_consistency = readiness_mapping.get("self_consistency")
    self_consistency_mapping: Mapping[str, Any] = (
        self_consistency if isinstance(self_consistency, Mapping) else {}
    )
    readiness_note = handles.get("readiness_provenance_note")
    return {
        "invariant_result_handles_native_result_handles_complete": (
            _optional_bool(
                handles.get("native_invariant_result_handles_complete")
            )
            is True
        ),
        "invariant_result_handles_complete_result_handle_abi": (
            _optional_bool(handles.get("complete_result_handle_abi")) is True
        ),
        "invariant_result_handles_release_grade_result_handles": (
            _optional_bool(handles.get("release_grade_result_handles")) is True
        ),
        "invariant_result_handles_readiness_provenance_present": bool(
            readiness_mapping
        ),
        "invariant_result_handles_ready_for_native_result_handles": (
            _optional_bool(
                readiness_mapping.get("ready_for_native_result_handles")
            )
            is True
        ),
        "invariant_result_handles_readiness_blocked_by_required_gates": (
            _optional_bool(
                readiness_mapping.get("readiness_blocked_by_required_gates")
            )
            is True
            or _optional_bool(
                self_consistency_mapping.get(
                    "readiness_blocked_by_required_gates"
                )
            )
            is True
        ),
        "invariant_result_handles_readiness_provenance_note_length": (
            len(readiness_note) if isinstance(readiness_note, str) else 0
        ),
    }


def _backend_owned_string_contract_note(entry: Mapping[str, Any]) -> str:
    fields = _backend_owned_string_contract_fields(entry)
    if not any(fields.values()):
        return ""
    return (
        "owned_string_contract: "
        "schema_version="
        f"{fields['owned_string_contract_schema_version']}, "
        "abi_version="
        f"{fields['owned_string_contract_abi_version']}, "
        "contract_version_length="
        f"{fields['owned_string_contract_version_length']}, "
        "free_required="
        f"{str(fields['owned_string_contract_free_required']).lower()}, "
        "free_accepts_zero_initialized="
        f"{str(fields['owned_string_contract_free_accepts_zero_initialized']).lower()}, "
        "borrowed_across_calls="
        f"{str(fields['owned_string_contract_borrowed_across_calls']).lower()}"
    )


def _backend_status_notes(entry: Mapping[str, Any]) -> str:
    parts = []
    module = entry.get("module")
    if module:
        parts.append(f"module: {module}")
    version = entry.get("version")
    if version:
        parts.append(f"version: {version}")
    origin = entry.get("module_origin")
    if origin:
        parts.append(f"origin: {origin}")
    backend_info = entry.get("backend_info")
    if isinstance(backend_info, Mapping):
        device_name = backend_info.get("device_name")
        if device_name:
            parts.append(f"device: {device_name}")
        cupy_version = backend_info.get("cupy_version")
        if cupy_version:
            parts.append(f"cupy: {cupy_version}")
        cuda_runtime = backend_info.get("cuda_runtime_version")
        if cuda_runtime:
            parts.append(f"cuda_runtime: {cuda_runtime}")
        invariant_result_handles = backend_info.get("invariant_result_handles")
        if isinstance(invariant_result_handles, Mapping):
            status = str(invariant_result_handles.get("status", "unknown"))
            homfly = str(
                bool(invariant_result_handles.get("homfly_report_json", False))
            ).lower()
            alexander = str(
                bool(invariant_result_handles.get("alexander_report_json", False))
            ).lower()
            native_claim = str(
                bool(
                    invariant_result_handles.get(
                        "native_computation_claimed",
                        False,
                    )
                )
            ).lower()
            python_boundary = str(
                bool(
                    invariant_result_handles.get(
                        "python_file_recompute_boundary",
                        False,
                    )
                )
            ).lower()
            parts.append(
                "invariant_result_handles: "
                f"status={status}, homfly={homfly}, alexander={alexander}, "
                f"native_claim={native_claim}, python_file_boundary={python_boundary}"
            )
            blocker_count = _optional_count(
                invariant_result_handles.get(
                    "native_invariant_result_handle_blocker_count"
                )
            )
            if blocker_count is not None:
                blockers = invariant_result_handles.get(
                    "native_invariant_result_handle_blockers"
                )
                blocker_note = (
                    "native_invariant_result_handle_blocker_count="
                    f"{blocker_count}"
                )
                if isinstance(blockers, Sequence) and not isinstance(
                    blockers,
                    (str, bytes),
                ):
                    blocker_codes = [
                        str(blocker) for blocker in blockers if str(blocker)
                    ]
                    if blocker_codes:
                        blocker_note += (
                            "; first_native_invariant_result_handle_blocker="
                            f"{blocker_codes[0]}"
                        )
                parts.append(blocker_note)
            gate_count = _optional_count(
                invariant_result_handles.get(
                    "required_native_invariant_handle_gate_count"
                )
            )
            if gate_count is not None:
                parts.append(f"required_native_invariant_handle_gate_count={gate_count}")
            file_recompute_note = _backend_file_recompute_boundary_note(
                invariant_result_handles.get("file_recompute_boundary")
            )
            if file_recompute_note:
                parts.append(file_recompute_note)
            current_boundary_note = _backend_current_file_recompute_boundary_note(
                invariant_result_handles.get("current_file_recompute_boundary")
            )
            if current_boundary_note:
                parts.append(current_boundary_note)
            readiness_note = _backend_readiness_provenance_note(
                invariant_result_handles.get(
                    "readiness_provenance_self_consistency"
                )
            )
            if readiness_note:
                parts.append(readiness_note)
        owned_string_contract_note = _backend_owned_string_contract_note(entry)
        if owned_string_contract_note:
            parts.append(owned_string_contract_note)
    backend_info_error = entry.get("backend_info_error")
    if backend_info_error:
        parts.append(f"backend_info_error: {backend_info_error}")
    missing = entry.get("missing_capabilities")
    if isinstance(missing, list) and missing:
        parts.append("missing: " + ", ".join(str(name) for name in missing))
    if entry.get("explicit_only") is True:
        parts.append("explicit-only backend")
    return "; ".join(parts)


def _backend_file_recompute_boundary_note(value: Any) -> str:
    if not isinstance(value, Mapping):
        return ""

    note_parts: list[str] = []
    for key, label, separator in (
        ("boundary", "boundary", ""),
        ("input_formats", "inputs", "|"),
        ("homfly_cli_command", "homfly_cli", " "),
        ("alexander_cli_command", "alexander_cli", " "),
        ("result_transport", "transport", "|"),
        ("host_reload_payload", "host_reload", ""),
    ):
        text = _backend_boundary_note_value(value.get(key), separator=separator)
        if text:
            note_parts.append(f"{label}={text}")
    if not note_parts:
        return ""
    return "file_recompute_boundary=" + "; ".join(note_parts)


def _backend_current_file_recompute_boundary_note(value: Any) -> str:
    if not isinstance(value, Mapping):
        return ""

    note_parts: list[str] = []
    for key, label, separator in (
        ("boundary", "boundary", ""),
        ("input_formats", "inputs", "|"),
        ("pipeline", "pipeline", " -> "),
        ("host_reload_payload", "host_reload", ""),
    ):
        text = _backend_boundary_note_value(value.get(key), separator=separator)
        if text:
            note_parts.append(f"{label}={text}")
    native_boundary = value.get("native_result_handle_boundary")
    if isinstance(native_boundary, bool):
        note_parts.append(
            f"native_result_handle_boundary={str(native_boundary).lower()}"
        )
    if not note_parts:
        return ""
    return "current_file_recompute_boundary=" + "; ".join(note_parts)


def _backend_readiness_provenance_note(value: Any) -> str:
    if not isinstance(value, Mapping):
        return ""

    note_parts: list[str] = []
    readiness = value.get("readiness")
    if readiness not in (None, ""):
        note_parts.append(f"readiness={readiness}")
    ready = value.get("ready_for_native_result_handles")
    if isinstance(ready, bool):
        note_parts.append(f"ready={str(ready).lower()}")
    host_action = value.get("host_action")
    if host_action not in (None, ""):
        note_parts.append(f"host_action={host_action}")
    python_boundary = value.get("python_file_recompute_boundary")
    if isinstance(python_boundary, bool):
        note_parts.append(
            f"python_file_recompute_boundary={str(python_boundary).lower()}"
        )
    native_boundary = value.get("native_result_handle_boundary")
    if isinstance(native_boundary, bool):
        note_parts.append(
            f"native_result_handle_boundary={str(native_boundary).lower()}"
        )

    consistency = value.get("self_consistency")
    if isinstance(consistency, Mapping):
        for key, label in (
            ("unsupported_row_count", "unsupported_rows"),
            ("per_invariant_link_count", "per_invariant_links"),
            ("required_gate_blocker_link_count", "gate_blocker_links"),
        ):
            count = _optional_count(consistency.get(key))
            if count is not None:
                note_parts.append(f"{label}={count}")
        blocked = consistency.get("readiness_blocked_by_required_gates")
        if isinstance(blocked, bool):
            note_parts.append(
                f"blocked_by_required_gates={str(blocked).lower()}"
            )
        non_claim = consistency.get("native_computation_non_claim_consistent")
        if isinstance(non_claim, bool):
            note_parts.append(
                f"native_non_claim={str(non_claim).lower()}"
            )
    if not note_parts:
        return ""
    return "readiness_provenance=" + "; ".join(note_parts)


def _backend_boundary_note_value(value: Any, *, separator: str) -> str:
    if value in (None, ""):
        return ""
    if isinstance(value, list | tuple):
        if not separator:
            separator = "|"
        return separator.join(str(item) for item in value if str(item))
    return str(value)


def _invariant_status_value(
    *,
    accepted: bool,
    required: int,
    passed: int,
    failed: int,
) -> str:
    if accepted:
        return f"accepted ({passed}/{required} checks)"
    if required == 0:
        return "skipped"
    if passed == 0:
        return f"skipped ({passed}/{required} checks, {failed} failed)"
    return f"incomplete ({passed}/{required} checks, {failed} failed)"


def _invariant_status_skipped(
    report: Mapping[str, Any],
    *,
    accepted: bool,
    passed: int,
) -> bool:
    if accepted:
        return False
    rows = report.get("fixtures")
    if isinstance(rows, list) and rows:
        saw_comparison = False
        all_skipped = True
        for row in rows:
            if not isinstance(row, Mapping):
                continue
            comparison = row.get("comparison")
            if not isinstance(comparison, Mapping):
                continue
            saw_comparison = True
            all_skipped = all_skipped and comparison.get("skipped") is True
        if saw_comparison:
            return all_skipped
    return passed == 0


def _geometry_components_and_notes(
    report: Mapping[str, Any],
) -> tuple[list[dict[str, Any]], list[str]]:
    notes: list[str] = []
    geometry = report.get("geometry")
    if isinstance(geometry, Mapping):
        geometry_components = geometry.get("components")
        if isinstance(geometry_components, list):
            components = _component_payloads_from_rows(
                geometry_components,
                report=report,
                source_prefix="$.geometry.components",
            )
            if components:
                return components, notes
            notes.append("$.geometry.components did not contain valid 3D point rows")

        component = _component_payload_from_mapping(
            geometry,
            report=report,
            index=0,
            source_path="$.geometry",
        )
        if component is not None:
            return [component], notes

    top_level_components = report.get("components")
    if isinstance(top_level_components, list):
        components = _component_payloads_from_rows(
            top_level_components,
            report=report,
            source_prefix="$.components",
        )
        if components:
            return components, notes
        notes.append("$.components did not contain valid 3D point rows")

    centerline = report.get("centerline")
    if isinstance(centerline, Mapping):
        component = _component_payload_from_mapping(
            centerline,
            report=report,
            index=0,
            source_path="$.centerline",
            default_name="centerline",
        )
        if component is not None:
            return [component], notes

    notes.append("no report geometry points were available for ImGui loading")
    return [], notes


def _classification_summary_from_report(
    report: Mapping[str, Any],
) -> dict[str, Any] | None:
    topology = report.get("topology")
    if not isinstance(topology, Mapping):
        return None
    classification = topology.get("classification")
    if not isinstance(classification, Mapping):
        return None
    table_candidate_summary = classification.get("table_candidate_summary")
    if not isinstance(table_candidate_summary, Mapping):
        return None
    if (
        table_candidate_summary.get("stronger_invariants_required") is not True
        and table_candidate_summary.get("source_table_distinguishing_evidence_available")
        is not True
    ):
        return None

    keys = (
        "candidate_count",
        "nontrivial_candidate_count",
        "nontrivial_link_types",
        "nontrivial_notations",
        "source_table_invariant_audit_available_count",
        "source_table_invariant_audit_summary_count",
        "source_table_nontrivial_candidate_count",
        "source_table_nontrivial_candidate_notations",
        "source_table_distinguishing_evidence_available",
        "stronger_invariants_required",
        "source_table_registration_ready_count",
        "source_table_registration_blocked_count",
        "source_table_registration_blocker_count",
        "source_table_registration_blocker_codes",
        "source_table_registration_blocker_code_count",
        "source_table_registration_blocker_code_counts",
        "source_table_registration_blocker_count_signature",
        "source_table_matched_invariant_count",
        "source_table_uncomputed_invariant_count",
        "source_table_mismatched_invariant_count",
        "source_table_unstable_invariant_count",
        "source_table_source_match_resolution_statuses",
        "source_table_source_match_resolution_status_count",
        "source_table_homfly_variant_resolution_statuses",
        "source_table_alexander_skipped_common_gcd_attempt_candidate_count",
        "source_table_alexander_skipped_common_gcd_attempt_not_certified_candidate_count",
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_attempt_evidence_count",
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_min",
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_candidate_count_max",
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_min",
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_failed_candidate_count_max",
        "source_table_alexander_skipped_common_gcd_attempt_direct_divisor_all_candidates_failed_summary_count",
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_evidence_count",
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_variant_count",
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_min",
        "source_table_alexander_skipped_common_gcd_attempt_support_signature_input_count_max",
        "source_table_alexander_source_divisibility_checked_candidate_count",
        "source_table_alexander_source_divisibility_source_divides_all_candidate_count",
        "source_table_alexander_source_divisibility_source_division_failed_candidate_count",
        "source_table_audit_notations",
    )
    summary = {
        "method": "imgui_classification_summary_from_report",
        "source_method": str(classification.get("method", "")),
        "link_type": str(classification.get("link_type", "")),
        "confidence": str(classification.get("confidence", "")),
        "component_count": int(classification.get("component_count", 0) or 0),
        "notes": [
            "classification summary is display metadata copied from the source report",
            "stronger-invariant flags are conservative ambiguity evidence, not an automatic table classification",
        ],
    }
    for key in keys:
        value = table_candidate_summary.get(key)
        if isinstance(value, list):
            summary[key] = list(value)
        elif isinstance(value, bool | int | str):
            summary[key] = value
    blocker_signature = str(
        summary.get("source_table_registration_blocker_count_signature", "") or ""
    )
    if blocker_signature:
        summary["notes"].append(
            f"source_table_registration_blockers={blocker_signature}"
        )
    return summary


def _classification_summary_text(value: Any) -> str:
    if isinstance(value, list):
        return ",".join(str(item) for item in value if str(item))
    if isinstance(value, str):
        return value
    if value is None:
        return ""
    return str(value)


def _classification_summary_item_count(value: Any) -> int:
    if isinstance(value, list):
        return len([item for item in value if str(item)])
    if isinstance(value, str) and value:
        return len([item for item in value.split(",") if item])
    return 0


def _classification_summary_notes_text(value: Any) -> str:
    if isinstance(value, list):
        return "; ".join(str(item) for item in value if str(item))
    if isinstance(value, str):
        return value
    if value is None:
        return ""
    return str(value)


def _component_payloads_from_rows(
    rows: list[Any],
    *,
    report: Mapping[str, Any],
    source_prefix: str,
) -> list[dict[str, Any]]:
    components = []
    for index, row in enumerate(rows):
        if not isinstance(row, Mapping):
            continue
        component = _component_payload_from_mapping(
            row,
            report=report,
            index=index,
            source_path=f"{source_prefix}[{index}]",
        )
        if component is not None:
            components.append(component)
    return components


def _component_payload_from_mapping(
    row: Mapping[str, Any],
    *,
    report: Mapping[str, Any],
    index: int,
    source_path: str,
    default_name: str | None = None,
) -> dict[str, Any] | None:
    points = _coerce_points3d(row.get("points"))
    if not points:
        return None
    closed = _coerce_bool(row.get("closed"), default=False)
    name = row.get("name")
    if name is None or str(name) == "":
        name = _component_name_from_report(report, index, default_name=default_name)
    return {
        "component_index": index,
        "name": str(name),
        "closed": closed,
        "point_count": len(points),
        "points": points,
        "color": _coerce_color(row.get("color")),
        "source_path": source_path,
    }


def _projected_crossing_from_mapping(
    row: Mapping[str, Any],
) -> dict[str, Any] | None:
    sign = _coerce_int(row.get("sign"))
    if sign not in (-1, 1):
        return None
    point2d = _coerce_point(row.get("point2d"), 2)
    if point2d is None:
        return None
    values = {
        "component_a": _coerce_int(row.get("component_a")),
        "segment_a": _coerce_int(row.get("segment_a")),
        "parameter_a": _coerce_float(row.get("parameter_a")),
        "component_b": _coerce_int(row.get("component_b")),
        "segment_b": _coerce_int(row.get("segment_b")),
        "parameter_b": _coerce_float(row.get("parameter_b")),
        "over_component": _coerce_int(row.get("over_component")),
        "over_segment": _coerce_int(row.get("over_segment")),
    }
    if any(value is None for value in values.values()):
        return None
    return {
        "component_a": values["component_a"],
        "segment_a": values["segment_a"],
        "parameter_a": values["parameter_a"],
        "component_b": values["component_b"],
        "segment_b": values["segment_b"],
        "parameter_b": values["parameter_b"],
        "point2d": point2d,
        "over_component": values["over_component"],
        "over_segment": values["over_segment"],
        "sign": sign,
    }


def _contact_overlay_from_mapping(
    row: Mapping[str, Any],
) -> dict[str, Any] | None:
    point3d_a = _coerce_point(row.get("point3d_a"), 3)
    point3d_b = _coerce_point(row.get("point3d_b"), 3)
    if point3d_a is None or point3d_b is None:
        return None
    values = {
        "component_a": _coerce_int(row.get("component_a")),
        "segment_a": _coerce_int(row.get("segment_a")),
        "parameter_a": _coerce_float(row.get("parameter_a")),
        "component_b": _coerce_int(row.get("component_b")),
        "segment_b": _coerce_int(row.get("segment_b")),
        "parameter_b": _coerce_float(row.get("parameter_b")),
        "distance": _coerce_float(row.get("distance")),
    }
    if any(value is None for value in values.values()):
        return None
    return {
        "component_a": values["component_a"],
        "segment_a": values["segment_a"],
        "parameter_a": values["parameter_a"],
        "component_b": values["component_b"],
        "segment_b": values["segment_b"],
        "parameter_b": values["parameter_b"],
        "distance": values["distance"],
        "point3d_a": point3d_a,
        "point3d_b": point3d_b,
    }


def _coerce_points3d(value: Any) -> list[list[float]] | None:
    if not isinstance(value, list):
        return None
    points: list[list[float]] = []
    for item in value:
        point = _coerce_point(item, 3)
        if point is None:
            return None
        points.append(point)
    return points


def _coerce_point(value: Any, length: int) -> list[float] | None:
    if not isinstance(value, list | tuple) or len(value) != length:
        return None
    point = []
    for coordinate in value:
        number = _coerce_float(coordinate)
        if number is None:
            return None
        point.append(number)
    return point


def _coerce_float(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, int | float):
        return None
    number = float(value)
    if not math.isfinite(number):
        return None
    return number


def _coerce_int(value: Any) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    return int(value)


def _coerce_bool(value: Any, *, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, int) and value in (0, 1):
        return bool(value)
    return default


def _coerce_color(value: Any) -> int | None:
    color = _coerce_int(value)
    if color is None or color < 0 or color > 0xFFFFFFFF:
        return None
    return color


def _component_name_from_report(
    report: Mapping[str, Any],
    index: int,
    *,
    default_name: str | None,
) -> str:
    input_section = report.get("input")
    if isinstance(input_section, Mapping):
        names = input_section.get("component_names")
        if isinstance(names, list) and index < len(names) and names[index] is not None:
            return str(names[index])
        name = input_section.get("name")
        if index == 0 and name is not None:
            return str(name)
    if default_name is not None:
        return default_name
    return f"component-{index}"


def _report_name(report: Mapping[str, Any]) -> str:
    input_section = report.get("input")
    if isinstance(input_section, Mapping) and input_section.get("name") is not None:
        return str(input_section["name"])
    return ""


def _report_kind_label(report: Mapping[str, Any]) -> str:
    input_section = report.get("input")
    if isinstance(input_section, Mapping) and "component_count" in input_section:
        return "link"
    if "centerline" in report:
        return "ribbon"
    if isinstance(input_section, Mapping) and "closed" in input_section:
        return "curve"
    return "unknown"
