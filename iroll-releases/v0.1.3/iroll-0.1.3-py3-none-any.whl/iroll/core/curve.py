"""3D polyline data model."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
from numpy.typing import ArrayLike

from iroll.core.types import FloatArray, as_points3d
from iroll.geometry import measures, resample


@dataclass(frozen=True)
class Polyline3D:
    """An ordered 3D point chain.

    Closed curves are stored without repeating the first point at the end.
    """

    points: ArrayLike
    closed: bool = False
    name: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        points = as_points3d(self.points, copy=True)

        if self.closed and len(points) >= 2 and np.allclose(points[0], points[-1]):
            points = points[:-1].copy()

        min_points = 3 if self.closed else 2
        if len(points) < min_points:
            kind = "closed" if self.closed else "open"
            raise ValueError(f"{kind} polylines require at least {min_points} points")

        if np.any(measures.segment_lengths(points, closed=self.closed) <= 1e-12):
            raise ValueError("polylines cannot contain zero-length segments")

        object.__setattr__(self, "points", np.ascontiguousarray(points))
        object.__setattr__(self, "metadata", dict(self.metadata or {}))

    @property
    def point_count(self) -> int:
        return int(self.points.shape[0])

    @property
    def segment_count(self) -> int:
        return self.point_count if self.closed else self.point_count - 1

    def copy_points(self, *, close: bool = False) -> FloatArray:
        if close and self.closed:
            return np.vstack([self.points, self.points[0]])
        return self.points.copy()

    def segment_vectors(self) -> FloatArray:
        return measures.segment_vectors(self.points, closed=self.closed)

    def segment_lengths(self) -> FloatArray:
        return measures.segment_lengths(self.points, closed=self.closed)

    def arc_length(self) -> float:
        return measures.arc_length(self.points, closed=self.closed)

    def cumulative_arclength(self) -> FloatArray:
        return measures.cumulative_arclength(self.points, closed=self.closed)

    def tangents(self) -> FloatArray:
        return measures.tangents(self.points, closed=self.closed)

    def curvature(self) -> FloatArray:
        return measures.curvature(self.points, closed=self.closed)

    def torsion(self) -> FloatArray:
        return measures.torsion(self.points, closed=self.closed)

    def resample_by_count(self, count: int) -> "Polyline3D":
        points = resample.resample_by_count(self.points, count=count, closed=self.closed)
        return Polyline3D(points, closed=self.closed, name=self.name, metadata=self.metadata)

    def resample_by_spacing(self, spacing: float) -> "Polyline3D":
        points = resample.resample_by_spacing(self.points, spacing=spacing, closed=self.closed)
        return Polyline3D(points, closed=self.closed, name=self.name, metadata=self.metadata)

    def geometry_summary(self) -> dict[str, Any]:
        curvature = self.curvature()
        torsion = self.torsion()
        return {
            "name": self.name,
            "closed": self.closed,
            "point_count": self.point_count,
            "segment_count": self.segment_count,
            "arc_length": self.arc_length(),
            "bounding_box": measures.bounding_box(self.points),
            "curvature": measures.summary(curvature),
            "torsion": measures.summary(torsion),
        }
