"""Ribbon data model for twist-style analysis."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
from numpy.typing import ArrayLike

from iroll.core.curve import Polyline3D
from iroll.core.types import normalize_vectors


@dataclass(frozen=True)
class Ribbon3D:
    """A centerline plus one material director per point."""

    centerline: Polyline3D
    directors: ArrayLike
    name: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.centerline, Polyline3D):
            raise TypeError("centerline must be a Polyline3D")

        directors = np.asarray(self.directors, dtype=np.float64)
        if directors.shape != self.centerline.points.shape:
            raise ValueError("directors must have the same shape as centerline points")
        if not np.isfinite(directors).all():
            raise ValueError("directors must contain only finite coordinates")

        normalized = normalize_vectors(directors)
        if np.any(np.linalg.norm(normalized, axis=1) <= 1e-12):
            raise ValueError("directors cannot contain zero vectors")

        object.__setattr__(self, "directors", np.ascontiguousarray(normalized))
        object.__setattr__(self, "metadata", dict(self.metadata or {}))

    @property
    def closed(self) -> bool:
        return self.centerline.closed

    @property
    def point_count(self) -> int:
        return self.centerline.point_count

    def twist(self) -> float:
        from iroll.topology.twist import compute_twist

        return compute_twist(self.centerline.points, self.directors, closed=self.closed)

    def summary(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "closed": self.closed,
            "point_count": self.point_count,
            "twist": self.twist(),
            "method": "discrete_director_rotation",
        }
