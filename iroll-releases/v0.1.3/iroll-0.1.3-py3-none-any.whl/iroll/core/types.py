"""Shared array validation helpers."""

from __future__ import annotations

import numpy as np
from numpy.typing import ArrayLike, NDArray

FloatArray = NDArray[np.float64]


def as_points3d(points: ArrayLike, *, copy: bool = False) -> FloatArray:
    """Return points as a contiguous ``float64[n, 3]`` array."""

    array = np.asarray(points, dtype=np.float64)
    if array.ndim != 2 or array.shape[1] != 3:
        raise ValueError("points must have shape (n, 3)")
    if not np.isfinite(array).all():
        raise ValueError("points must contain only finite coordinates")
    if copy:
        array = array.copy()
    return np.ascontiguousarray(array)


def normalize_vectors(vectors: ArrayLike, *, eps: float = 1e-12) -> FloatArray:
    """Normalize vectors, leaving near-zero vectors as zero."""

    array = np.asarray(vectors, dtype=np.float64)
    norms = np.linalg.norm(array, axis=-1, keepdims=True)
    return np.divide(array, norms, out=np.zeros_like(array), where=norms > eps)
