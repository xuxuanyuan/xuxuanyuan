"""Multi-component link data model."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Sequence

from iroll.core.curve import Polyline3D


@dataclass(frozen=True)
class Link3D:
    """A collection of curve components analyzed as one link."""

    components: Sequence[Polyline3D]
    name: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        components = tuple(self.components)
        if not components:
            raise ValueError("links require at least one component")
        for component in components:
            if not isinstance(component, Polyline3D):
                raise TypeError("link components must be Polyline3D instances")

        object.__setattr__(self, "components", components)
        object.__setattr__(self, "metadata", dict(self.metadata or {}))

    @property
    def component_count(self) -> int:
        return len(self.components)

    @property
    def all_closed(self) -> bool:
        return all(component.closed for component in self.components)

    def component_names(self) -> list[str | None]:
        return [component.name for component in self.components]
