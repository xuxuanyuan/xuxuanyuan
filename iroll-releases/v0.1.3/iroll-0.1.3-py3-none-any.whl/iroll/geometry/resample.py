"""Polyline resampling utilities."""

from __future__ import annotations

import numpy as np
from numpy.typing import ArrayLike

from iroll.core.types import FloatArray, as_points3d
from iroll.geometry.measures import arc_length, cumulative_arclength, segment_lengths


def resample_by_count(points: ArrayLike, *, count: int, closed: bool = False) -> FloatArray:
    points = as_points3d(points)
    minimum = 3 if closed else 2
    if count < minimum:
        raise ValueError(f"count must be at least {minimum}")

    total = arc_length(points, closed=closed)
    if total <= 0.0:
        raise ValueError("cannot resample a zero-length polyline")

    path = _path_points(points, closed=closed)
    cumulative = cumulative_arclength(points, closed=closed)
    if closed:
        targets = np.linspace(0.0, total, count + 1, endpoint=True)[:-1]
    else:
        targets = np.linspace(0.0, total, count, endpoint=True)
    return _interpolate(path, cumulative, targets)


def resample_by_spacing(points: ArrayLike, *, spacing: float, closed: bool = False) -> FloatArray:
    points = as_points3d(points)
    if spacing <= 0.0:
        raise ValueError("spacing must be positive")

    total = arc_length(points, closed=closed)
    if total <= 0.0:
        raise ValueError("cannot resample a zero-length polyline")

    if closed:
        count = max(3, int(np.ceil(total / spacing)))
        return resample_by_count(points, count=count, closed=True)

    inner = np.arange(0.0, total, spacing, dtype=np.float64)
    if inner.size == 0 or not np.isclose(inner[-1], total):
        targets = np.concatenate([inner, [total]])
    else:
        targets = inner

    path = _path_points(points, closed=False)
    cumulative = cumulative_arclength(points, closed=False)
    return _interpolate(path, cumulative, targets)


def _path_points(points: FloatArray, *, closed: bool) -> FloatArray:
    if closed:
        return np.vstack([points, points[0]])
    return points


def _interpolate(path: FloatArray, cumulative: FloatArray, targets: FloatArray) -> FloatArray:
    lengths = np.diff(cumulative)
    indices = np.searchsorted(cumulative, targets, side="right") - 1
    indices = np.clip(indices, 0, len(lengths) - 1)

    local = targets - cumulative[indices]
    fractions = np.divide(
        local,
        lengths[indices],
        out=np.zeros_like(local),
        where=lengths[indices] > 0.0,
    )
    return path[indices] + fractions[:, None] * (path[indices + 1] - path[indices])
