"""Basic geometric measurements for 3D polylines."""

from __future__ import annotations

import numpy as np
from numpy.typing import ArrayLike

from iroll.core.types import FloatArray, as_points3d, normalize_vectors


def segment_vectors(points: ArrayLike, *, closed: bool = False) -> FloatArray:
    points = as_points3d(points)
    if closed:
        return np.roll(points, -1, axis=0) - points
    return points[1:] - points[:-1]


def segment_lengths(points: ArrayLike, *, closed: bool = False) -> FloatArray:
    return np.linalg.norm(segment_vectors(points, closed=closed), axis=1)


def arc_length(points: ArrayLike, *, closed: bool = False) -> float:
    return float(segment_lengths(points, closed=closed).sum())


def cumulative_arclength(points: ArrayLike, *, closed: bool = False) -> FloatArray:
    lengths = segment_lengths(points, closed=closed)
    return np.concatenate([[0.0], np.cumsum(lengths)])


def tangents(points: ArrayLike, *, closed: bool = False) -> FloatArray:
    points = as_points3d(points)
    if closed:
        vectors = np.roll(points, -1, axis=0) - np.roll(points, 1, axis=0)
    else:
        vectors = np.empty_like(points)
        vectors[0] = points[1] - points[0]
        vectors[-1] = points[-1] - points[-2]
        if len(points) > 2:
            vectors[1:-1] = points[2:] - points[:-2]
    return normalize_vectors(vectors)


def curvature(points: ArrayLike, *, closed: bool = False, eps: float = 1e-12) -> FloatArray:
    points = as_points3d(points)
    values = np.zeros(len(points), dtype=np.float64)

    if closed:
        prev_points = np.roll(points, 1, axis=0)
        next_points = np.roll(points, -1, axis=0)
        return _menger_curvature(prev_points, points, next_points, eps=eps)

    if len(points) < 3:
        return values

    values[:] = np.nan
    values[1:-1] = _menger_curvature(points[:-2], points[1:-1], points[2:], eps=eps)
    values[0] = values[1]
    values[-1] = values[-2]
    return values


def torsion(points: ArrayLike, *, closed: bool = False, eps: float = 1e-12) -> FloatArray:
    points = as_points3d(points)
    if len(points) < 4:
        return np.zeros(len(points), dtype=np.float64)

    if closed:
        return _periodic_torsion(points, eps=eps)

    s = _vertex_arclength(points)
    r1 = np.gradient(points, s, axis=0, edge_order=2)
    r2 = np.gradient(r1, s, axis=0, edge_order=2)
    r3 = np.gradient(r2, s, axis=0, edge_order=2)
    return _torsion_from_derivatives(r1, r2, r3, eps=eps)


def summary(values: ArrayLike) -> dict[str, float | None]:
    array = np.asarray(values, dtype=np.float64)
    finite = array[np.isfinite(array)]
    if finite.size == 0:
        return {"min": None, "max": None, "mean": None, "std": None}
    return {
        "min": float(finite.min()),
        "max": float(finite.max()),
        "mean": float(finite.mean()),
        "std": float(finite.std()),
    }


def bounding_box(points: ArrayLike) -> dict[str, list[float] | float]:
    points = as_points3d(points)
    minimum = points.min(axis=0)
    maximum = points.max(axis=0)
    size = maximum - minimum
    return {
        "min": minimum.tolist(),
        "max": maximum.tolist(),
        "size": size.tolist(),
        "diagonal": float(np.linalg.norm(size)),
    }


def _menger_curvature(
    a: FloatArray,
    b: FloatArray,
    c: FloatArray,
    *,
    eps: float,
) -> FloatArray:
    ab = b - a
    bc = c - b
    ac = c - a
    cross_norm = np.linalg.norm(np.cross(ab, bc), axis=1)
    denominator = (
        np.linalg.norm(ab, axis=1)
        * np.linalg.norm(bc, axis=1)
        * np.linalg.norm(ac, axis=1)
    )
    return np.divide(
        2.0 * cross_norm,
        denominator,
        out=np.zeros_like(cross_norm),
        where=denominator > eps,
    )


def _vertex_arclength(points: FloatArray) -> FloatArray:
    lengths = np.linalg.norm(points[1:] - points[:-1], axis=1)
    return np.concatenate([[0.0], np.cumsum(lengths)])


def _periodic_torsion(points: FloatArray, *, eps: float) -> FloatArray:
    total = arc_length(points, closed=True)
    if total <= eps:
        return np.zeros(len(points), dtype=np.float64)

    h = total / len(points)
    r1 = (np.roll(points, -1, axis=0) - np.roll(points, 1, axis=0)) / (2.0 * h)
    r2 = (np.roll(points, -1, axis=0) - 2.0 * points + np.roll(points, 1, axis=0)) / (h**2)
    r3 = (
        np.roll(points, -2, axis=0)
        - 2.0 * np.roll(points, -1, axis=0)
        + 2.0 * np.roll(points, 1, axis=0)
        - np.roll(points, 2, axis=0)
    ) / (2.0 * h**3)
    return _torsion_from_derivatives(r1, r2, r3, eps=eps)


def _torsion_from_derivatives(
    r1: FloatArray,
    r2: FloatArray,
    r3: FloatArray,
    *,
    eps: float,
) -> FloatArray:
    cross = np.cross(r1, r2)
    numerator = np.einsum("ij,ij->i", cross, r3)
    denominator = np.linalg.norm(cross, axis=1) ** 2
    return np.divide(
        numerator,
        denominator,
        out=np.zeros_like(numerator),
        where=denominator > eps,
    )
