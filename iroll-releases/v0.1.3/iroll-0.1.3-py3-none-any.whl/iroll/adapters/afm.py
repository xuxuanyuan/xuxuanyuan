"""Minimal AFM/image tracing helpers."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import ArrayLike

from iroll.core.curve import Polyline3D


@dataclass(frozen=True)
class AFMTraceResult:
    curve: Polyline3D
    threshold: float
    pixel_count: int
    warnings: list[str]

    def to_dict(self) -> dict:
        return {
            "threshold": self.threshold,
            "pixel_count": self.pixel_count,
            "warnings": list(self.warnings),
            "curve": {
                "name": self.curve.name,
                "closed": self.curve.closed,
                "point_count": self.curve.point_count,
            },
        }


def trace_afm_centerline(
    image: ArrayLike,
    *,
    threshold: float | None = None,
    pixel_size: float = 1.0,
    z: float = 0.0,
    sort_axis: str = "x",
    name: str | None = "afm-trace",
) -> AFMTraceResult:
    array = np.asarray(image, dtype=float)
    if array.ndim != 2:
        raise ValueError("AFM tracing expects a 2D grayscale image array")
    if threshold is None:
        threshold = float(array.mean() + array.std())

    rows, cols = np.nonzero(array >= threshold)
    if len(rows) < 2:
        raise ValueError("AFM trace requires at least two foreground pixels")

    if sort_axis == "x":
        order = np.lexsort((rows, cols))
    elif sort_axis == "y":
        order = np.lexsort((cols, rows))
    else:
        raise ValueError("sort_axis must be 'x' or 'y'")

    points = np.column_stack(
        [
            cols[order] * pixel_size,
            rows[order] * pixel_size,
            np.full(len(order), z, dtype=float),
        ]
    )
    warnings = []
    if _foreground_has_branch(array >= threshold):
        warnings.append("foreground skeleton has branch-like pixels")
    return AFMTraceResult(
        curve=Polyline3D(points, closed=False, name=name),
        threshold=float(threshold),
        pixel_count=int(len(order)),
        warnings=warnings,
    )


def _foreground_has_branch(mask: np.ndarray) -> bool:
    rows, cols = np.nonzero(mask)
    foreground = set(zip(rows.tolist(), cols.tolist()))
    for row, col in foreground:
        neighbors = 0
        for drow in (-1, 0, 1):
            for dcol in (-1, 0, 1):
                if drow == 0 and dcol == 0:
                    continue
                if (row + drow, col + dcol) in foreground:
                    neighbors += 1
        if neighbors > 2:
            return True
    return False
