"""Optional adapters for external knot-analysis tools."""

from __future__ import annotations

import importlib.util
from typing import Any

from iroll.core.curve import Polyline3D


class AdapterUnavailableError(RuntimeError):
    """Raised when an optional external adapter is requested but unavailable."""


SUPPORTED_ADAPTERS = {
    "pyknotid": "pyknotid",
    "topoly": "topoly",
}


def list_available_adapters() -> dict[str, dict[str, bool | str]]:
    return {
        name: {
            "module": module,
            "available": importlib.util.find_spec(module) is not None,
        }
        for name, module in SUPPORTED_ADAPTERS.items()
    }


def classify_with_adapter(curve: Polyline3D, *, adapter: str) -> dict[str, Any]:
    if adapter == "pyknotid":
        return _classify_with_pyknotid(curve)
    if adapter == "topoly":
        return _classify_with_topoly(curve)
    raise ValueError("adapter must be 'pyknotid' or 'topoly'")


def _classify_with_pyknotid(curve: Polyline3D) -> dict[str, Any]:
    try:
        from pyknotid.spacecurves import Knot  # type: ignore[import-not-found]
    except ImportError as exc:
        raise AdapterUnavailableError("pyknotid is not installed") from exc

    knot = Knot(curve.copy_points(close=curve.closed))
    payload: dict[str, Any] = {
        "adapter": "pyknotid",
        "available": True,
        "closed": curve.closed,
    }
    if hasattr(knot, "alexander_polynomial"):
        try:
            payload["alexander_polynomial"] = str(knot.alexander_polynomial())
        except Exception as exc:  # pragma: no cover - depends on external package behavior
            payload["error"] = str(exc)
    return payload


def _classify_with_topoly(curve: Polyline3D) -> dict[str, Any]:
    try:
        import topoly  # type: ignore[import-not-found]
    except ImportError as exc:
        raise AdapterUnavailableError("topoly is not installed") from exc

    payload: dict[str, Any] = {
        "adapter": "topoly",
        "available": True,
        "closed": curve.closed,
    }
    if hasattr(topoly, "alexander"):
        try:
            payload["alexander"] = str(topoly.alexander(curve.copy_points(close=curve.closed)))
        except Exception as exc:  # pragma: no cover - depends on external package behavior
            payload["error"] = str(exc)
    elif hasattr(topoly, "get_pd_code"):
        payload["capability"] = "get_pd_code"
    return payload
