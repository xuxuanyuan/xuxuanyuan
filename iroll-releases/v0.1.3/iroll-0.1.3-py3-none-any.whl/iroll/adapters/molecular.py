"""Lightweight molecular-data adapters.

These helpers intentionally avoid Biopython/MDAnalysis imports. Heavier
molecular stacks can wrap these shapes later or live in optional packages.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable

import numpy as np
from numpy.typing import ArrayLike

from iroll.core.curve import Polyline3D


def pdb_centerline_from_text(
    text: str,
    *,
    chain_id: str | None = None,
    atom_names: Iterable[str] = ("P", "C4'", "CA"),
    closed: bool = False,
    name: str | None = None,
) -> Polyline3D:
    atom_name_set = {atom_name.strip() for atom_name in atom_names}
    residues: dict[tuple[str, int, str], list[list[float]]] = {}
    for line in text.splitlines():
        if not (line.startswith("ATOM") or line.startswith("HETATM")):
            continue
        parsed = _parse_pdb_atom_line(line)
        if parsed is None:
            continue
        atom_name, parsed_chain, residue_id, insertion_code, point = parsed
        if chain_id is not None and parsed_chain != chain_id:
            continue
        if atom_name not in atom_name_set:
            continue
        residues.setdefault((parsed_chain, residue_id, insertion_code), []).append(point)

    ordered = [
        np.mean(points, axis=0)
        for _, points in sorted(residues.items(), key=lambda item: item[0])
    ]
    if not ordered:
        raise ValueError("no matching PDB atoms found for centerline extraction")
    return Polyline3D(np.asarray(ordered, dtype=float), closed=closed, name=name)


def load_pdb_centerline(
    path: str | Path,
    *,
    chain_id: str | None = None,
    atom_names: Iterable[str] = ("P", "C4'", "CA"),
    closed: bool = False,
    name: str | None = None,
) -> Polyline3D:
    return pdb_centerline_from_text(
        Path(path).read_text(encoding="utf-8"),
        chain_id=chain_id,
        atom_names=atom_names,
        closed=closed,
        name=name,
    )


def trajectory_curve_reports(
    frames: Iterable[ArrayLike],
    *,
    closed: bool = False,
    backend: str = "auto",
    max_frames: int | None = None,
) -> list[dict]:
    from iroll.topology.analyze import analyze_curve

    reports = []
    for index, frame in enumerate(frames):
        if max_frames is not None and index >= max_frames:
            break
        curve = Polyline3D(frame, closed=closed, name=f"frame-{index}")
        report = analyze_curve(curve, backend=backend)
        report["trajectory"] = {
            "frame_index": index,
        }
        reports.append(report)
    return reports


def _parse_pdb_atom_line(line: str):
    try:
        atom_name = line[12:16].strip()
        chain_id = line[21].strip()
        residue_id = int(line[22:26])
        insertion_code = line[26].strip()
        point = [
            float(line[30:38]),
            float(line[38:46]),
            float(line[46:54]),
        ]
    except (IndexError, ValueError):
        return _parse_tokenized_pdb_atom_line(line)
    if not chain_id:
        fallback = _parse_tokenized_pdb_atom_line(line)
        if fallback is not None:
            return fallback
    return atom_name, chain_id, residue_id, insertion_code, point


def _parse_tokenized_pdb_atom_line(line: str):
    parts = line.split()
    if len(parts) < 9:
        return None
    try:
        atom_name = parts[2]
        chain_id = parts[4]
        residue_id = int(parts[5])
        point = [float(parts[6]), float(parts[7]), float(parts[8])]
    except (IndexError, ValueError):
        return None
    return atom_name, chain_id, residue_id, "", point
