"""Standard validation fixtures."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from iroll.core.curve import Polyline3D
from iroll.core.link import Link3D


@dataclass(frozen=True)
class CurveValidationCase:
    name: str
    curve: Polyline3D
    expected_knot_type: str
    closed: bool = True
    closure: dict | None = None


@dataclass(frozen=True)
class LinkValidationCase:
    name: str
    link: Link3D
    expected_abs_linking: float
    expected_link_type: str


def unknot_curve(*, count: int = 256) -> Polyline3D:
    theta = np.linspace(0.0, 2.0 * np.pi, count, endpoint=False)
    points = np.column_stack([np.cos(theta), np.sin(theta), np.zeros_like(theta)])
    return Polyline3D(points, closed=True, name="unknot")


def trefoil_curve(*, count: int = 512) -> Polyline3D:
    return Polyline3D(_trefoil_points(count), closed=True, name="trefoil")


def figure_eight_curve(*, count: int = 768) -> Polyline3D:
    t = np.linspace(0.0, 2.0 * np.pi, count, endpoint=False)
    points = np.column_stack(
        [
            (2.0 + np.cos(2.0 * t)) * np.cos(3.0 * t),
            (2.0 + np.cos(2.0 * t)) * np.sin(3.0 * t),
            np.sin(4.0 * t),
        ]
    )
    return Polyline3D(points, closed=True, name="figure-eight")


def open_trefoil_curve(*, count: int = 512, trim: int = 20) -> Polyline3D:
    points = _trefoil_points(count)[trim:-trim]
    return Polyline3D(points, closed=False, name="open-trefoil")


def mirror_curve(curve: Polyline3D, *, axis: int = 0, name: str | None = None) -> Polyline3D:
    points = curve.points.copy()
    points[:, axis] *= -1.0
    return Polyline3D(
        points,
        closed=curve.closed,
        name=name or f"mirror-{curve.name or 'curve'}",
        metadata={**curve.metadata, "mirrored_axis": axis},
    )


def hopf_link(*, count: int = 256) -> Link3D:
    t = np.linspace(0.0, 2.0 * np.pi, count, endpoint=False)
    first = np.column_stack([np.cos(t), np.sin(t), np.zeros_like(t)])
    second = np.column_stack([np.zeros_like(t), 1.0 + np.cos(t), np.sin(t)])
    return Link3D(
        [
            Polyline3D(first, closed=True, name="hopf-a"),
            Polyline3D(second, closed=True, name="hopf-b"),
        ],
        name="hopf-link",
    )


def unlink(*, count: int = 256) -> Link3D:
    t = np.linspace(0.0, 2.0 * np.pi, count, endpoint=False)
    first = np.column_stack([np.cos(t), np.sin(t), np.zeros_like(t)])
    second = np.column_stack([3.0 + np.cos(t), np.sin(t), np.zeros_like(t)])
    return Link3D(
        [
            Polyline3D(first, closed=True, name="unlink-a"),
            Polyline3D(second, closed=True, name="unlink-b"),
        ],
        name="unlink",
    )


def standard_curve_cases(*, count: int = 256) -> list[CurveValidationCase]:
    trefoil = trefoil_curve(count=max(count, 256))
    return [
        CurveValidationCase("unknot", unknot_curve(count=count), "unknot"),
        CurveValidationCase("trefoil", trefoil, "trefoil"),
        CurveValidationCase("mirror_trefoil", mirror_curve(trefoil), "trefoil"),
        CurveValidationCase(
            "figure_eight",
            figure_eight_curve(count=max(count, 384)),
            "figure_eight",
        ),
        CurveValidationCase(
            "open_trefoil_direct",
            open_trefoil_curve(count=max(count, 256)),
            "trefoil",
            closed=False,
            closure={"method": "direct"},
        ),
    ]


def standard_link_cases(*, count: int = 256) -> list[LinkValidationCase]:
    return [
        LinkValidationCase("hopf_link", hopf_link(count=count), 1.0, "hopf_link"),
        LinkValidationCase("unlink", unlink(count=count), 0.0, "unlink"),
    ]


def _trefoil_points(count: int) -> np.ndarray:
    t = np.linspace(0.0, 2.0 * np.pi, count, endpoint=False)
    return np.column_stack(
        [
            np.sin(t) + 2.0 * np.sin(2.0 * t),
            np.cos(t) - 2.0 * np.cos(2.0 * t),
            -np.sin(3.0 * t),
        ]
    )
