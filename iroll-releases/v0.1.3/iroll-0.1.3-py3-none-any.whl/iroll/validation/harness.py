"""Validation harness for built-in fixtures."""

from __future__ import annotations

from typing import Any

import numpy as np

from iroll.topology import (
    classify_curve_multi_projection,
    classify_link,
    classify_open_curve,
    linking_matrix,
)
from iroll.validation.fixtures import standard_curve_cases, standard_link_cases


def run_validation(*, count: int = 256) -> dict[str, Any]:
    curve_results = [_validate_curve_case(case) for case in standard_curve_cases(count=count)]
    link_results = [_validate_link_case(case) for case in standard_link_cases(count=count)]
    all_results = curve_results + link_results
    passed = sum(1 for result in all_results if result["passed"])
    return {
        "passed": passed,
        "failed": len(all_results) - passed,
        "total": len(all_results),
        "curve_cases": curve_results,
        "link_cases": link_results,
    }


def _validate_curve_case(case) -> dict[str, Any]:
    if case.closed:
        vote = classify_curve_multi_projection(case.curve)
        observed = vote.selected.knot_type
        detail = vote.to_dict()
    else:
        closure = classify_open_curve(case.curve, closure=case.closure)
        observed = closure["dominant_knot_type"]
        detail = closure
    return {
        "name": case.name,
        "kind": "curve",
        "expected": case.expected_knot_type,
        "observed": observed,
        "passed": observed == case.expected_knot_type,
        "detail": detail,
    }


def _validate_link_case(case) -> dict[str, Any]:
    matrix = linking_matrix(case.link, direction=[0.3, 0.5, 1.0])
    observed = float(abs(matrix[0, 1])) if matrix.shape[0] >= 2 else 0.0
    classification = classify_link(
        case.link,
        direction=[0.3, 0.5, 1.0],
        linking_matrix_values=matrix,
    )
    return {
        "name": case.name,
        "kind": "link",
        "expected_abs_linking": case.expected_abs_linking,
        "observed_abs_linking": observed,
        "expected_link_type": case.expected_link_type,
        "observed_link_type": classification.link_type,
        "passed": bool(
            np.isclose(observed, case.expected_abs_linking)
            and classification.link_type == case.expected_link_type
        ),
        "detail": {
            "linking_matrix": matrix.tolist(),
            "classification": classification.to_dict(),
        },
    }
