"""Load ribbon objects from lightweight JSON files."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from iroll.core.curve import Polyline3D
from iroll.core.ribbon import Ribbon3D
from iroll.core.types import as_points3d


def load_ribbon_json(
    path: str | Path,
    *,
    closed: bool = False,
    name: str | None = None,
) -> Ribbon3D:
    path = Path(path)
    with path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError("ribbon JSON must be an object with 'points' and 'directors'")
    if "points" not in payload or "directors" not in payload:
        raise ValueError("ribbon JSON must contain 'points' and 'directors'")

    points = as_points3d(payload["points"])
    directors = np.asarray(payload["directors"], dtype=np.float64)
    ribbon_name = name if name is not None else payload.get("name")
    centerline = Polyline3D(points, closed=closed, name=ribbon_name)
    return Ribbon3D(
        centerline,
        directors,
        name=ribbon_name,
        metadata=payload.get("metadata", {}),
    )
