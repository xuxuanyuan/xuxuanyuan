"""JSON report serialization."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def dump_report(report: dict[str, Any], *, indent: int | None = 2) -> str:
    return json.dumps(report, indent=indent, sort_keys=True, allow_nan=False)


def write_report(
    report: dict[str, Any],
    path: str | Path | None = None,
    *,
    indent: int | None = 2,
) -> str | None:
    text = dump_report(report, indent=indent)
    if path is None:
        return text

    output_path = Path(path)
    # Binary UTF-8 keeps retained evidence byte-identical on Windows and POSIX;
    # text-mode writes would translate LF to CRLF on Windows and break the raw
    # digest bound into published certification witnesses.
    output_path.write_bytes((text + "\n").encode("utf-8"))
    return None
