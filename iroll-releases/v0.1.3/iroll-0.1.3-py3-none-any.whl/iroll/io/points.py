"""Load 3D point arrays from lightweight file formats."""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

import numpy as np

from iroll.core.types import FloatArray, as_points3d


def load_points(path: str | Path) -> FloatArray:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return load_points_csv(path)
    if suffix == ".json":
        return load_points_json(path)
    raise ValueError("supported point formats are .csv and .json")


def load_points_csv(path: str | Path) -> FloatArray:
    path = Path(path)
    with path.open("r", encoding="utf-8", newline="") as handle:
        sample = handle.read(2048)
        handle.seek(0)
        has_header = csv.Sniffer().has_header(sample) if sample.strip() else False
        if has_header:
            reader = csv.DictReader(handle)
            rows = [_row_from_mapping(row) for row in reader]
        else:
            reader = csv.reader(handle)
            rows = [_row_from_sequence(row) for row in reader if row]
    return as_points3d(rows)


def load_points_json(path: str | Path) -> FloatArray:
    path = Path(path)
    with path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    return as_points3d(_points_from_json(payload))


def _points_from_json(payload: Any) -> Any:
    if isinstance(payload, dict):
        if "points" not in payload:
            raise ValueError("JSON point objects must contain a 'points' field")
        return payload["points"]
    return payload


def _row_from_mapping(row: dict[str, str]) -> list[float]:
    lowered = {key.lower().strip(): value for key, value in row.items() if key is not None}
    if {"x", "y", "z"}.issubset(lowered):
        return [float(lowered["x"]), float(lowered["y"]), float(lowered["z"])]
    values = [value for value in row.values() if value not in (None, "")]
    return _row_from_sequence(values)


def _row_from_sequence(row: list[str]) -> list[float]:
    if len(row) < 3:
        raise ValueError("each point row must contain at least three values")
    return [float(row[0]), float(row[1]), float(row[2])]
