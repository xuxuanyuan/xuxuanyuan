# iroll

iroll is a Python-first computational core for 3D curve, ribbon, knot, and link analysis.

The first implementation focuses on a small, stable foundation:

- validated 3D polyline data structures
- arc length, tangents, curvature, torsion, and resampling
- projection, crossing detection, diagram codes, and first-pass knot/link labels
- clean NumPy array boundaries for future Rust/C++ acceleration
- JSON-friendly result shapes for later CLI, API, and UI layers

## Quickstart

```python
import numpy as np
from iroll import Polyline3D

theta = np.linspace(0.0, 2.0 * np.pi, 256, endpoint=False)
points = np.column_stack([np.cos(theta), np.sin(theta), np.zeros_like(theta)])

curve = Polyline3D(points, closed=True, name="unit-circle")

print(curve.arc_length())
print(curve.curvature().mean())
```

## Development

```bash
python -m pip install -e ".[dev]"
python -m pytest
```

On Windows native-development shells, run the one-time environment installer
after installing or updating Rust/CMake/Ninja/MSVC/CUDA:

```powershell
.\scripts\install-dev-env.ps1
```

This writes a machine-local `scripts/dev-env.local.json` tool cache and checks
stable User PATH entries, so fresh shells can recover tools that are installed
but missing from the inherited environment.

Then load the fixed toolchain entry before interactive native work:

```powershell
. .\scripts\dev-env.ps1
```

For one-shot native commands from a fresh shell or automation, use:

```powershell
.\scripts\dev.ps1 cargo --version
```

## CLI

```bash
iroll analyze-curve points.csv --closed --direction 0,0,1
iroll analyze-link ring-a.json ring-b.json --closed --direction 0.3,0.5,1 -o report.json
iroll analyze-ribbon ribbon.json --backend numpy
iroll validate --points 256
iroll backends
iroll adapters
iroll knot-table
iroll link-table
iroll validate-table table.json --kind knot
iroll render-report report.json -o report.html
iroll imgui-geometry-payload report.json -o imgui-geometry.json
iroll imgui-analysis-payload -o imgui-analysis.json
iroll imgui-invariant-status-payload -o imgui-invariants.json
iroll imgui-fixture-comparison-payload -o imgui-fixtures.json
iroll imgui-signed-pd-payload --report homfly --notation L2a1 -o imgui-signed-pd.json
iroll imgui-kernel-backend-status-payload -o imgui-backends.json
iroll imgui-invariant-status-summary-payload report.json -o imgui-invariant-status.json
iroll imgui-host-payload --geometry-report report.json -o imgui-host.json
iroll rust-unsupported-invariant-result-handle-report --invariant homfly -o rust-unsupported-homfly-handle.json
```

Numeric kernels accept `--backend auto|numpy|rust|gpu`. The base install uses Python, NumPy, and SymPy; SymPy supports the exact all-admissible-minor Alexander certification route. Rust/GPU kernels and the C++/Dear ImGui UI remain optional. `iroll backends` reports backend availability, device details when available, and per-kernel capability/missing-capability maps.
Use `--contact-threshold <distance>` to include near-contact segment pairs in reports.
Use `--include-diagram-matrix` on `analyze-curve` to include the coloring matrix used by the determinant classifier.
Use `--subchain-window-points <n>` with `analyze-curve` to scan local windows.
Use `--adapter pyknotid|topoly` to include optional external-tool output when installed.
Link reports include pairwise linking numbers, component knot classifications, and MVP link labels such as `hopf_link`, `unlink`, or `pairwise_unlink_candidate`.
Use `iroll.reports.assert_valid_report(report)` to check report shape at API or batch-processing boundaries.
Use `iroll.viewer.write_report_html(report, path)` for a static HTML report view.
Open `ui/report-viewer.html` directly in a browser for the standalone WebGL report-viewer prototype.
`examples/imgui-geometry-payload.sample.json` is a generated Hopf-link payload
showing the C++/Dear ImGui geometry bridge shape.
Regenerate it with `python examples/generate_imgui_geometry_payload.py`.
`examples/imgui-host-payload.sample.json` is a generated Hopf-link host bundle
covering geometry, HOMFLY/Alexander summaries, fixture rows, signed-PD rows,
and deterministic backend diagnostics.
Regenerate it with `python examples/generate_imgui_host_payload.py`.
The `imgui-*payload` commands emit host-loadable JSON for the C++/Dear ImGui
embedding layer; mathematical HOMFLY/Alexander evidence remains in the nested
acceptance reports that generate those payloads.
Use `imgui-host-payload` when a C++ host wants one JSON bundle with geometry,
analysis summaries, invariant rows, fixture rows, signed-PD records, and backend
diagnostics. Existing report JSON can be appended with `--analysis-report-json`
for the analysis-summary section or `--invariant-report-json` for the
invariant-status section.
Installed Rust wheels can also expose the unsupported invariant result-handle
lifecycle probe through `rust-unsupported-invariant-result-handle-report`. Feed
that JSON into `imgui-invariant-status-summary-payload` to get a skipped,
zero-check, non-claim `IrollInvariantStatus` row for host review. This is
ownership/report/free lifecycle evidence only; it does not claim native
HOMFLY-PT or Alexander computation.

## Docs

- `docs/api-examples.md`
- `docs/development-environment.md`
- `docs/mathematical-definitions.md`
- `docs/diagram-fixture-conventions.md`
- `docs/limitations.md`
- `docs/report-schema.md`
- `docs/validation-and-robustness.md`
- `docs/rust-kernel-interface.md`
- `docs/ui-plan.md`
- `docs/mvp-completion-checklist.md`
- `docs/post-mvp-execution-plan.md`
- `docs/post-mvp-completion-audit.md`
- `docs/deep-completion-roadmap.md`
- `docs/remaining-deep-completion-plan.md`
- `docs/remaining-deep-execution-status.md`
- `docs/iroll-core-plan.md`
